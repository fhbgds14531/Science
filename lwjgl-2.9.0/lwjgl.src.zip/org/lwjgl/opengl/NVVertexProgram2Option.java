package org.lwjgl.opengl;

public final class NVVertexProgram2Option
{
  public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 35060;
  public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 35061;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexProgram2Option
 * JD-Core Version:    0.7.0.1
 */