package org.lwjgl.opengl;

public final class EXTPackedPixels
{
  public static final int GL_UNSIGNED_BYTE_3_3_2_EXT = 32818;
  public static final int GL_UNSIGNED_SHORT_4_4_4_4_EXT = 32819;
  public static final int GL_UNSIGNED_SHORT_5_5_5_1_EXT = 32820;
  public static final int GL_UNSIGNED_INT_8_8_8_8_EXT = 32821;
  public static final int GL_UNSIGNED_INT_10_10_10_2_EXT = 32822;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTPackedPixels
 * JD-Core Version:    0.7.0.1
 */