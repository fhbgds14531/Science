package org.lwjgl.opengl;

public final class NVTextureEnvCombine4
{
  public static final int GL_COMBINE4_NV = 34051;
  public static final int GL_SOURCE3_RGB_NV = 34179;
  public static final int GL_SOURCE3_ALPHA_NV = 34187;
  public static final int GL_OPERAND3_RGB_NV = 34195;
  public static final int GL_OPERAND3_ALPHA_NV = 34203;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTextureEnvCombine4
 * JD-Core Version:    0.7.0.1
 */