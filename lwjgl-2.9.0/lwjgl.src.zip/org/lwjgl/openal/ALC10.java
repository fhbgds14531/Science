/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.LWJGLException;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public final class ALC10
/*  11:    */ {
/*  12: 61 */   static final HashMap<Long, ALCcontext> contexts = new HashMap();
/*  13: 64 */   static final HashMap<Long, ALCdevice> devices = new HashMap();
/*  14:    */   public static final int ALC_INVALID = 0;
/*  15:    */   public static final int ALC_FALSE = 0;
/*  16:    */   public static final int ALC_TRUE = 1;
/*  17:    */   public static final int ALC_NO_ERROR = 0;
/*  18:    */   public static final int ALC_MAJOR_VERSION = 4096;
/*  19:    */   public static final int ALC_MINOR_VERSION = 4097;
/*  20:    */   public static final int ALC_ATTRIBUTES_SIZE = 4098;
/*  21:    */   public static final int ALC_ALL_ATTRIBUTES = 4099;
/*  22:    */   public static final int ALC_DEFAULT_DEVICE_SPECIFIER = 4100;
/*  23:    */   public static final int ALC_DEVICE_SPECIFIER = 4101;
/*  24:    */   public static final int ALC_EXTENSIONS = 4102;
/*  25:    */   public static final int ALC_FREQUENCY = 4103;
/*  26:    */   public static final int ALC_REFRESH = 4104;
/*  27:    */   public static final int ALC_SYNC = 4105;
/*  28:    */   public static final int ALC_INVALID_DEVICE = 40961;
/*  29:    */   public static final int ALC_INVALID_CONTEXT = 40962;
/*  30:    */   public static final int ALC_INVALID_ENUM = 40963;
/*  31:    */   public static final int ALC_INVALID_VALUE = 40964;
/*  32:    */   public static final int ALC_OUT_OF_MEMORY = 40965;
/*  33:    */   
/*  34:    */   static native void initNativeStubs()
/*  35:    */     throws LWJGLException;
/*  36:    */   
/*  37:    */   public static String alcGetString(ALCdevice device, int pname)
/*  38:    */   {
/*  39:155 */     ByteBuffer buffer = nalcGetString(getDevice(device), pname);
/*  40:156 */     Util.checkALCError(device);
/*  41:157 */     return MemoryUtil.decodeUTF8(buffer);
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native ByteBuffer nalcGetString(long paramLong, int paramInt);
/*  45:    */   
/*  46:    */   public static void alcGetInteger(ALCdevice device, int pname, IntBuffer integerdata)
/*  47:    */   {
/*  48:182 */     BufferChecks.checkDirect(integerdata);
/*  49:183 */     nalcGetIntegerv(getDevice(device), pname, integerdata.remaining(), MemoryUtil.getAddress(integerdata));
/*  50:184 */     Util.checkALCError(device);
/*  51:    */   }
/*  52:    */   
/*  53:    */   static native void nalcGetIntegerv(long paramLong1, int paramInt1, int paramInt2, long paramLong2);
/*  54:    */   
/*  55:    */   public static ALCdevice alcOpenDevice(String devicename)
/*  56:    */   {
/*  57:201 */     ByteBuffer buffer = MemoryUtil.encodeUTF8(devicename);
/*  58:202 */     long device_address = nalcOpenDevice(MemoryUtil.getAddressSafe(buffer));
/*  59:203 */     if (device_address != 0L)
/*  60:    */     {
/*  61:204 */       ALCdevice device = new ALCdevice(device_address);
/*  62:205 */       synchronized (devices)
/*  63:    */       {
/*  64:206 */         devices.put(Long.valueOf(device_address), device);
/*  65:    */       }
/*  66:208 */       return device;
/*  67:    */     }
/*  68:210 */     return null;
/*  69:    */   }
/*  70:    */   
/*  71:    */   static native long nalcOpenDevice(long paramLong);
/*  72:    */   
/*  73:    */   public static boolean alcCloseDevice(ALCdevice device)
/*  74:    */   {
/*  75:224 */     boolean result = nalcCloseDevice(getDevice(device));
/*  76:225 */     synchronized (devices)
/*  77:    */     {
/*  78:226 */       device.setInvalid();
/*  79:227 */       devices.remove(new Long(device.device));
/*  80:    */     }
/*  81:229 */     return result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   static native boolean nalcCloseDevice(long paramLong);
/*  85:    */   
/*  86:    */   public static ALCcontext alcCreateContext(ALCdevice device, IntBuffer attrList)
/*  87:    */   {
/*  88:250 */     long context_address = nalcCreateContext(getDevice(device), MemoryUtil.getAddressSafe(attrList));
/*  89:251 */     Util.checkALCError(device);
/*  90:253 */     if (context_address != 0L)
/*  91:    */     {
/*  92:254 */       ALCcontext context = new ALCcontext(context_address);
/*  93:255 */       synchronized (contexts)
/*  94:    */       {
/*  95:256 */         contexts.put(Long.valueOf(context_address), context);
/*  96:257 */         device.addContext(context);
/*  97:    */       }
/*  98:259 */       return context;
/*  99:    */     }
/* 100:261 */     return null;
/* 101:    */   }
/* 102:    */   
/* 103:    */   static native long nalcCreateContext(long paramLong1, long paramLong2);
/* 104:    */   
/* 105:    */   public static int alcMakeContextCurrent(ALCcontext context)
/* 106:    */   {
/* 107:280 */     return nalcMakeContextCurrent(getContext(context));
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native int nalcMakeContextCurrent(long paramLong);
/* 111:    */   
/* 112:    */   public static void alcProcessContext(ALCcontext context)
/* 113:    */   {
/* 114:296 */     nalcProcessContext(getContext(context));
/* 115:    */   }
/* 116:    */   
/* 117:    */   static native void nalcProcessContext(long paramLong);
/* 118:    */   
/* 119:    */   public static ALCcontext alcGetCurrentContext()
/* 120:    */   {
/* 121:307 */     ALCcontext context = null;
/* 122:308 */     long context_address = nalcGetCurrentContext();
/* 123:309 */     if (context_address != 0L) {
/* 124:310 */       synchronized (contexts)
/* 125:    */       {
/* 126:311 */         context = (ALCcontext)contexts.get(Long.valueOf(context_address));
/* 127:    */       }
/* 128:    */     }
/* 129:314 */     return context;
/* 130:    */   }
/* 131:    */   
/* 132:    */   static native long nalcGetCurrentContext();
/* 133:    */   
/* 134:    */   public static ALCdevice alcGetContextsDevice(ALCcontext context)
/* 135:    */   {
/* 136:324 */     ALCdevice device = null;
/* 137:325 */     long device_address = nalcGetContextsDevice(getContext(context));
/* 138:326 */     if (device_address != 0L) {
/* 139:327 */       synchronized (devices)
/* 140:    */       {
/* 141:328 */         device = (ALCdevice)devices.get(Long.valueOf(device_address));
/* 142:    */       }
/* 143:    */     }
/* 144:331 */     return device;
/* 145:    */   }
/* 146:    */   
/* 147:    */   static native long nalcGetContextsDevice(long paramLong);
/* 148:    */   
/* 149:    */   public static void alcSuspendContext(ALCcontext context)
/* 150:    */   {
/* 151:348 */     nalcSuspendContext(getContext(context));
/* 152:    */   }
/* 153:    */   
/* 154:    */   static native void nalcSuspendContext(long paramLong);
/* 155:    */   
/* 156:    */   public static void alcDestroyContext(ALCcontext context)
/* 157:    */   {
/* 158:359 */     synchronized (contexts)
/* 159:    */     {
/* 160:360 */       ALCdevice device = alcGetContextsDevice(context);
/* 161:361 */       nalcDestroyContext(getContext(context));
/* 162:362 */       device.removeContext(context);
/* 163:363 */       context.setInvalid();
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   static native void nalcDestroyContext(long paramLong);
/* 168:    */   
/* 169:    */   public static int alcGetError(ALCdevice device)
/* 170:    */   {
/* 171:384 */     return nalcGetError(getDevice(device));
/* 172:    */   }
/* 173:    */   
/* 174:    */   static native int nalcGetError(long paramLong);
/* 175:    */   
/* 176:    */   public static boolean alcIsExtensionPresent(ALCdevice device, String extName)
/* 177:    */   {
/* 178:398 */     ByteBuffer buffer = MemoryUtil.encodeASCII(extName);
/* 179:399 */     boolean result = nalcIsExtensionPresent(getDevice(device), MemoryUtil.getAddress(buffer));
/* 180:400 */     Util.checkALCError(device);
/* 181:401 */     return result;
/* 182:    */   }
/* 183:    */   
/* 184:    */   private static native boolean nalcIsExtensionPresent(long paramLong1, long paramLong2);
/* 185:    */   
/* 186:    */   public static int alcGetEnumValue(ALCdevice device, String enumName)
/* 187:    */   {
/* 188:416 */     ByteBuffer buffer = MemoryUtil.encodeASCII(enumName);
/* 189:417 */     int result = nalcGetEnumValue(getDevice(device), MemoryUtil.getAddress(buffer));
/* 190:418 */     Util.checkALCError(device);
/* 191:419 */     return result;
/* 192:    */   }
/* 193:    */   
/* 194:    */   private static native int nalcGetEnumValue(long paramLong1, long paramLong2);
/* 195:    */   
/* 196:    */   static long getDevice(ALCdevice device)
/* 197:    */   {
/* 198:424 */     if (device != null)
/* 199:    */     {
/* 200:425 */       Util.checkALCValidDevice(device);
/* 201:426 */       return device.device;
/* 202:    */     }
/* 203:428 */     return 0L;
/* 204:    */   }
/* 205:    */   
/* 206:    */   static long getContext(ALCcontext context)
/* 207:    */   {
/* 208:432 */     if (context != null)
/* 209:    */     {
/* 210:433 */       Util.checkALCValidContext(context);
/* 211:434 */       return context.context;
/* 212:    */     }
/* 213:436 */     return 0L;
/* 214:    */   }
/* 215:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.ALC10
 * JD-Core Version:    0.7.0.1
 */