/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVGpuProgram4
/*   8:    */ {
/*   9:    */   public static final int GL_PROGRAM_ATTRIB_COMPONENTS_NV = 35078;
/*  10:    */   public static final int GL_PROGRAM_RESULT_COMPONENTS_NV = 35079;
/*  11:    */   public static final int GL_MAX_PROGRAM_ATTRIB_COMPONENTS_NV = 35080;
/*  12:    */   public static final int GL_MAX_PROGRAM_RESULT_COMPONENTS_NV = 35081;
/*  13:    */   public static final int GL_MAX_PROGRAM_GENERIC_ATTRIBS_NV = 36261;
/*  14:    */   public static final int GL_MAX_PROGRAM_GENERIC_RESULTS_NV = 36262;
/*  15:    */   
/*  16:    */   public static void glProgramLocalParameterI4iNV(int target, int index, int x, int y, int z, int w)
/*  17:    */   {
/*  18: 23 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  19: 24 */     long function_pointer = caps.glProgramLocalParameterI4iNV;
/*  20: 25 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  21: 26 */     nglProgramLocalParameterI4iNV(target, index, x, y, z, w, function_pointer);
/*  22:    */   }
/*  23:    */   
/*  24:    */   static native void nglProgramLocalParameterI4iNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  25:    */   
/*  26:    */   public static void glProgramLocalParameterI4NV(int target, int index, IntBuffer params)
/*  27:    */   {
/*  28: 31 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  29: 32 */     long function_pointer = caps.glProgramLocalParameterI4ivNV;
/*  30: 33 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  31: 34 */     BufferChecks.checkBuffer(params, 4);
/*  32: 35 */     nglProgramLocalParameterI4ivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/*  33:    */   }
/*  34:    */   
/*  35:    */   static native void nglProgramLocalParameterI4ivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  36:    */   
/*  37:    */   public static void glProgramLocalParametersI4NV(int target, int index, IntBuffer params)
/*  38:    */   {
/*  39: 40 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  40: 41 */     long function_pointer = caps.glProgramLocalParametersI4ivNV;
/*  41: 42 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  42: 43 */     BufferChecks.checkDirect(params);
/*  43: 44 */     nglProgramLocalParametersI4ivNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static native void nglProgramLocalParametersI4ivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  47:    */   
/*  48:    */   public static void glProgramLocalParameterI4uiNV(int target, int index, int x, int y, int z, int w)
/*  49:    */   {
/*  50: 49 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  51: 50 */     long function_pointer = caps.glProgramLocalParameterI4uiNV;
/*  52: 51 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  53: 52 */     nglProgramLocalParameterI4uiNV(target, index, x, y, z, w, function_pointer);
/*  54:    */   }
/*  55:    */   
/*  56:    */   static native void nglProgramLocalParameterI4uiNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  57:    */   
/*  58:    */   public static void glProgramLocalParameterI4uNV(int target, int index, IntBuffer params)
/*  59:    */   {
/*  60: 57 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  61: 58 */     long function_pointer = caps.glProgramLocalParameterI4uivNV;
/*  62: 59 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  63: 60 */     BufferChecks.checkBuffer(params, 4);
/*  64: 61 */     nglProgramLocalParameterI4uivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/*  65:    */   }
/*  66:    */   
/*  67:    */   static native void nglProgramLocalParameterI4uivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  68:    */   
/*  69:    */   public static void glProgramLocalParametersI4uNV(int target, int index, IntBuffer params)
/*  70:    */   {
/*  71: 66 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  72: 67 */     long function_pointer = caps.glProgramLocalParametersI4uivNV;
/*  73: 68 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  74: 69 */     BufferChecks.checkDirect(params);
/*  75: 70 */     nglProgramLocalParametersI4uivNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/*  76:    */   }
/*  77:    */   
/*  78:    */   static native void nglProgramLocalParametersI4uivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  79:    */   
/*  80:    */   public static void glProgramEnvParameterI4iNV(int target, int index, int x, int y, int z, int w)
/*  81:    */   {
/*  82: 75 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  83: 76 */     long function_pointer = caps.glProgramEnvParameterI4iNV;
/*  84: 77 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  85: 78 */     nglProgramEnvParameterI4iNV(target, index, x, y, z, w, function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglProgramEnvParameterI4iNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  89:    */   
/*  90:    */   public static void glProgramEnvParameterI4NV(int target, int index, IntBuffer params)
/*  91:    */   {
/*  92: 83 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 84 */     long function_pointer = caps.glProgramEnvParameterI4ivNV;
/*  94: 85 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 86 */     BufferChecks.checkBuffer(params, 4);
/*  96: 87 */     nglProgramEnvParameterI4ivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglProgramEnvParameterI4ivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 100:    */   
/* 101:    */   public static void glProgramEnvParametersI4NV(int target, int index, IntBuffer params)
/* 102:    */   {
/* 103: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104: 93 */     long function_pointer = caps.glProgramEnvParametersI4ivNV;
/* 105: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106: 95 */     BufferChecks.checkDirect(params);
/* 107: 96 */     nglProgramEnvParametersI4ivNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglProgramEnvParametersI4ivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static void glProgramEnvParameterI4uiNV(int target, int index, int x, int y, int z, int w)
/* 113:    */   {
/* 114:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:102 */     long function_pointer = caps.glProgramEnvParameterI4uiNV;
/* 116:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:104 */     nglProgramEnvParameterI4uiNV(target, index, x, y, z, w, function_pointer);
/* 118:    */   }
/* 119:    */   
/* 120:    */   static native void nglProgramEnvParameterI4uiNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 121:    */   
/* 122:    */   public static void glProgramEnvParameterI4uNV(int target, int index, IntBuffer params)
/* 123:    */   {
/* 124:109 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:110 */     long function_pointer = caps.glProgramEnvParameterI4uivNV;
/* 126:111 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:112 */     BufferChecks.checkBuffer(params, 4);
/* 128:113 */     nglProgramEnvParameterI4uivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglProgramEnvParameterI4uivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 132:    */   
/* 133:    */   public static void glProgramEnvParametersI4uNV(int target, int index, IntBuffer params)
/* 134:    */   {
/* 135:118 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 136:119 */     long function_pointer = caps.glProgramEnvParametersI4uivNV;
/* 137:120 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 138:121 */     BufferChecks.checkDirect(params);
/* 139:122 */     nglProgramEnvParametersI4uivNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 140:    */   }
/* 141:    */   
/* 142:    */   static native void nglProgramEnvParametersI4uivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 143:    */   
/* 144:    */   public static void glGetProgramLocalParameterINV(int target, int index, IntBuffer params)
/* 145:    */   {
/* 146:127 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 147:128 */     long function_pointer = caps.glGetProgramLocalParameterIivNV;
/* 148:129 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 149:130 */     BufferChecks.checkBuffer(params, 4);
/* 150:131 */     nglGetProgramLocalParameterIivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 151:    */   }
/* 152:    */   
/* 153:    */   static native void nglGetProgramLocalParameterIivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 154:    */   
/* 155:    */   public static void glGetProgramLocalParameterIuNV(int target, int index, IntBuffer params)
/* 156:    */   {
/* 157:136 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 158:137 */     long function_pointer = caps.glGetProgramLocalParameterIuivNV;
/* 159:138 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 160:139 */     BufferChecks.checkBuffer(params, 4);
/* 161:140 */     nglGetProgramLocalParameterIuivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 162:    */   }
/* 163:    */   
/* 164:    */   static native void nglGetProgramLocalParameterIuivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 165:    */   
/* 166:    */   public static void glGetProgramEnvParameterINV(int target, int index, IntBuffer params)
/* 167:    */   {
/* 168:145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 169:146 */     long function_pointer = caps.glGetProgramEnvParameterIivNV;
/* 170:147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 171:148 */     BufferChecks.checkBuffer(params, 4);
/* 172:149 */     nglGetProgramEnvParameterIivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 173:    */   }
/* 174:    */   
/* 175:    */   static native void nglGetProgramEnvParameterIivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 176:    */   
/* 177:    */   public static void glGetProgramEnvParameterIuNV(int target, int index, IntBuffer params)
/* 178:    */   {
/* 179:154 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 180:155 */     long function_pointer = caps.glGetProgramEnvParameterIuivNV;
/* 181:156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 182:157 */     BufferChecks.checkBuffer(params, 4);
/* 183:158 */     nglGetProgramEnvParameterIuivNV(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 184:    */   }
/* 185:    */   
/* 186:    */   static native void nglGetProgramEnvParameterIuivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 187:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVGpuProgram4
 * JD-Core Version:    0.7.0.1
 */