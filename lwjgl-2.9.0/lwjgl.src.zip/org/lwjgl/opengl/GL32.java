/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import java.nio.LongBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class GL32
/*  12:    */ {
/*  13:    */   public static final int GL_CONTEXT_PROFILE_MASK = 37158;
/*  14:    */   public static final int GL_CONTEXT_CORE_PROFILE_BIT = 1;
/*  15:    */   public static final int GL_CONTEXT_COMPATIBILITY_PROFILE_BIT = 2;
/*  16:    */   public static final int GL_MAX_VERTEX_OUTPUT_COMPONENTS = 37154;
/*  17:    */   public static final int GL_MAX_GEOMETRY_INPUT_COMPONENTS = 37155;
/*  18:    */   public static final int GL_MAX_GEOMETRY_OUTPUT_COMPONENTS = 37156;
/*  19:    */   public static final int GL_MAX_FRAGMENT_INPUT_COMPONENTS = 37157;
/*  20:    */   public static final int GL_FIRST_VERTEX_CONVENTION = 36429;
/*  21:    */   public static final int GL_LAST_VERTEX_CONVENTION = 36430;
/*  22:    */   public static final int GL_PROVOKING_VERTEX = 36431;
/*  23:    */   public static final int GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION = 36428;
/*  24:    */   public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 34895;
/*  25:    */   public static final int GL_SAMPLE_POSITION = 36432;
/*  26:    */   public static final int GL_SAMPLE_MASK = 36433;
/*  27:    */   public static final int GL_SAMPLE_MASK_VALUE = 36434;
/*  28:    */   public static final int GL_TEXTURE_2D_MULTISAMPLE = 37120;
/*  29:    */   public static final int GL_PROXY_TEXTURE_2D_MULTISAMPLE = 37121;
/*  30:    */   public static final int GL_TEXTURE_2D_MULTISAMPLE_ARRAY = 37122;
/*  31:    */   public static final int GL_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY = 37123;
/*  32:    */   public static final int GL_MAX_SAMPLE_MASK_WORDS = 36441;
/*  33:    */   public static final int GL_MAX_COLOR_TEXTURE_SAMPLES = 37134;
/*  34:    */   public static final int GL_MAX_DEPTH_TEXTURE_SAMPLES = 37135;
/*  35:    */   public static final int GL_MAX_INTEGER_SAMPLES = 37136;
/*  36:    */   public static final int GL_TEXTURE_BINDING_2D_MULTISAMPLE = 37124;
/*  37:    */   public static final int GL_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY = 37125;
/*  38:    */   public static final int GL_TEXTURE_SAMPLES = 37126;
/*  39:    */   public static final int GL_TEXTURE_FIXED_SAMPLE_LOCATIONS = 37127;
/*  40:    */   public static final int GL_SAMPLER_2D_MULTISAMPLE = 37128;
/*  41:    */   public static final int GL_INT_SAMPLER_2D_MULTISAMPLE = 37129;
/*  42:    */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE = 37130;
/*  43:    */   public static final int GL_SAMPLER_2D_MULTISAMPLE_ARRAY = 37131;
/*  44:    */   public static final int GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY = 37132;
/*  45:    */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY = 37133;
/*  46:    */   public static final int GL_DEPTH_CLAMP = 34383;
/*  47:    */   public static final int GL_GEOMETRY_SHADER = 36313;
/*  48:    */   public static final int GL_GEOMETRY_VERTICES_OUT = 36314;
/*  49:    */   public static final int GL_GEOMETRY_INPUT_TYPE = 36315;
/*  50:    */   public static final int GL_GEOMETRY_OUTPUT_TYPE = 36316;
/*  51:    */   public static final int GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS = 35881;
/*  52:    */   public static final int GL_MAX_VARYING_COMPONENTS = 35659;
/*  53:    */   public static final int GL_MAX_GEOMETRY_UNIFORM_COMPONENTS = 36319;
/*  54:    */   public static final int GL_MAX_GEOMETRY_OUTPUT_VERTICES = 36320;
/*  55:    */   public static final int GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS = 36321;
/*  56:    */   public static final int GL_LINES_ADJACENCY = 10;
/*  57:    */   public static final int GL_LINE_STRIP_ADJACENCY = 11;
/*  58:    */   public static final int GL_TRIANGLES_ADJACENCY = 12;
/*  59:    */   public static final int GL_TRIANGLE_STRIP_ADJACENCY = 13;
/*  60:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS = 36264;
/*  61:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_LAYERED = 36263;
/*  62:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = 36052;
/*  63:    */   public static final int GL_PROGRAM_POINT_SIZE = 34370;
/*  64:    */   public static final int GL_MAX_SERVER_WAIT_TIMEOUT = 37137;
/*  65:    */   public static final int GL_OBJECT_TYPE = 37138;
/*  66:    */   public static final int GL_SYNC_CONDITION = 37139;
/*  67:    */   public static final int GL_SYNC_STATUS = 37140;
/*  68:    */   public static final int GL_SYNC_FLAGS = 37141;
/*  69:    */   public static final int GL_SYNC_FENCE = 37142;
/*  70:    */   public static final int GL_SYNC_GPU_COMMANDS_COMPLETE = 37143;
/*  71:    */   public static final int GL_UNSIGNALED = 37144;
/*  72:    */   public static final int GL_SIGNALED = 37145;
/*  73:    */   public static final int GL_SYNC_FLUSH_COMMANDS_BIT = 1;
/*  74:    */   public static final long GL_TIMEOUT_IGNORED = -1L;
/*  75:    */   public static final int GL_ALREADY_SIGNALED = 37146;
/*  76:    */   public static final int GL_TIMEOUT_EXPIRED = 37147;
/*  77:    */   public static final int GL_CONDITION_SATISFIED = 37148;
/*  78:    */   public static final int GL_WAIT_FAILED = 37149;
/*  79:    */   
/*  80:    */   public static void glGetBufferParameter(int target, int pname, LongBuffer params)
/*  81:    */   {
/*  82:215 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  83:216 */     long function_pointer = caps.glGetBufferParameteri64v;
/*  84:217 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  85:218 */     BufferChecks.checkBuffer(params, 4);
/*  86:219 */     nglGetBufferParameteri64v(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglGetBufferParameteri64v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  90:    */   
/*  91:    */   @Deprecated
/*  92:    */   public static long glGetBufferParameter(int target, int pname)
/*  93:    */   {
/*  94:230 */     return glGetBufferParameteri64(target, pname);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static long glGetBufferParameteri64(int target, int pname)
/*  98:    */   {
/*  99:235 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 100:236 */     long function_pointer = caps.glGetBufferParameteri64v;
/* 101:237 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 102:238 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 103:239 */     nglGetBufferParameteri64v(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 104:240 */     return params.get(0);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static void glDrawElementsBaseVertex(int mode, ByteBuffer indices, int basevertex)
/* 108:    */   {
/* 109:244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110:245 */     long function_pointer = caps.glDrawElementsBaseVertex;
/* 111:246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:247 */     GLChecks.ensureElementVBOdisabled(caps);
/* 113:248 */     BufferChecks.checkDirect(indices);
/* 114:249 */     nglDrawElementsBaseVertex(mode, indices.remaining(), 5121, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static void glDrawElementsBaseVertex(int mode, IntBuffer indices, int basevertex)
/* 118:    */   {
/* 119:252 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 120:253 */     long function_pointer = caps.glDrawElementsBaseVertex;
/* 121:254 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 122:255 */     GLChecks.ensureElementVBOdisabled(caps);
/* 123:256 */     BufferChecks.checkDirect(indices);
/* 124:257 */     nglDrawElementsBaseVertex(mode, indices.remaining(), 5125, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static void glDrawElementsBaseVertex(int mode, ShortBuffer indices, int basevertex)
/* 128:    */   {
/* 129:260 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 130:261 */     long function_pointer = caps.glDrawElementsBaseVertex;
/* 131:262 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 132:263 */     GLChecks.ensureElementVBOdisabled(caps);
/* 133:264 */     BufferChecks.checkDirect(indices);
/* 134:265 */     nglDrawElementsBaseVertex(mode, indices.remaining(), 5123, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 135:    */   }
/* 136:    */   
/* 137:    */   static native void nglDrawElementsBaseVertex(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 138:    */   
/* 139:    */   public static void glDrawElementsBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int basevertex)
/* 140:    */   {
/* 141:269 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 142:270 */     long function_pointer = caps.glDrawElementsBaseVertex;
/* 143:271 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 144:272 */     GLChecks.ensureElementVBOenabled(caps);
/* 145:273 */     nglDrawElementsBaseVertexBO(mode, indices_count, type, indices_buffer_offset, basevertex, function_pointer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   static native void nglDrawElementsBaseVertexBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 149:    */   
/* 150:    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ByteBuffer indices, int basevertex)
/* 151:    */   {
/* 152:278 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 153:279 */     long function_pointer = caps.glDrawRangeElementsBaseVertex;
/* 154:280 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 155:281 */     GLChecks.ensureElementVBOdisabled(caps);
/* 156:282 */     BufferChecks.checkDirect(indices);
/* 157:283 */     nglDrawRangeElementsBaseVertex(mode, start, end, indices.remaining(), 5121, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, IntBuffer indices, int basevertex)
/* 161:    */   {
/* 162:286 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 163:287 */     long function_pointer = caps.glDrawRangeElementsBaseVertex;
/* 164:288 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 165:289 */     GLChecks.ensureElementVBOdisabled(caps);
/* 166:290 */     BufferChecks.checkDirect(indices);
/* 167:291 */     nglDrawRangeElementsBaseVertex(mode, start, end, indices.remaining(), 5125, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ShortBuffer indices, int basevertex)
/* 171:    */   {
/* 172:294 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 173:295 */     long function_pointer = caps.glDrawRangeElementsBaseVertex;
/* 174:296 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 175:297 */     GLChecks.ensureElementVBOdisabled(caps);
/* 176:298 */     BufferChecks.checkDirect(indices);
/* 177:299 */     nglDrawRangeElementsBaseVertex(mode, start, end, indices.remaining(), 5123, MemoryUtil.getAddress(indices), basevertex, function_pointer);
/* 178:    */   }
/* 179:    */   
/* 180:    */   static native void nglDrawRangeElementsBaseVertex(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, int paramInt6, long paramLong2);
/* 181:    */   
/* 182:    */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, int indices_count, int type, long indices_buffer_offset, int basevertex)
/* 183:    */   {
/* 184:303 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 185:304 */     long function_pointer = caps.glDrawRangeElementsBaseVertex;
/* 186:305 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 187:306 */     GLChecks.ensureElementVBOenabled(caps);
/* 188:307 */     nglDrawRangeElementsBaseVertexBO(mode, start, end, indices_count, type, indices_buffer_offset, basevertex, function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglDrawRangeElementsBaseVertexBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, int paramInt6, long paramLong2);
/* 192:    */   
/* 193:    */   public static void glDrawElementsInstancedBaseVertex(int mode, ByteBuffer indices, int primcount, int basevertex)
/* 194:    */   {
/* 195:312 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 196:313 */     long function_pointer = caps.glDrawElementsInstancedBaseVertex;
/* 197:314 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 198:315 */     GLChecks.ensureElementVBOdisabled(caps);
/* 199:316 */     BufferChecks.checkDirect(indices);
/* 200:317 */     nglDrawElementsInstancedBaseVertex(mode, indices.remaining(), 5121, MemoryUtil.getAddress(indices), primcount, basevertex, function_pointer);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public static void glDrawElementsInstancedBaseVertex(int mode, IntBuffer indices, int primcount, int basevertex)
/* 204:    */   {
/* 205:320 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 206:321 */     long function_pointer = caps.glDrawElementsInstancedBaseVertex;
/* 207:322 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 208:323 */     GLChecks.ensureElementVBOdisabled(caps);
/* 209:324 */     BufferChecks.checkDirect(indices);
/* 210:325 */     nglDrawElementsInstancedBaseVertex(mode, indices.remaining(), 5125, MemoryUtil.getAddress(indices), primcount, basevertex, function_pointer);
/* 211:    */   }
/* 212:    */   
/* 213:    */   public static void glDrawElementsInstancedBaseVertex(int mode, ShortBuffer indices, int primcount, int basevertex)
/* 214:    */   {
/* 215:328 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 216:329 */     long function_pointer = caps.glDrawElementsInstancedBaseVertex;
/* 217:330 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 218:331 */     GLChecks.ensureElementVBOdisabled(caps);
/* 219:332 */     BufferChecks.checkDirect(indices);
/* 220:333 */     nglDrawElementsInstancedBaseVertex(mode, indices.remaining(), 5123, MemoryUtil.getAddress(indices), primcount, basevertex, function_pointer);
/* 221:    */   }
/* 222:    */   
/* 223:    */   static native void nglDrawElementsInstancedBaseVertex(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, int paramInt5, long paramLong2);
/* 224:    */   
/* 225:    */   public static void glDrawElementsInstancedBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int primcount, int basevertex)
/* 226:    */   {
/* 227:337 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 228:338 */     long function_pointer = caps.glDrawElementsInstancedBaseVertex;
/* 229:339 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 230:340 */     GLChecks.ensureElementVBOenabled(caps);
/* 231:341 */     nglDrawElementsInstancedBaseVertexBO(mode, indices_count, type, indices_buffer_offset, primcount, basevertex, function_pointer);
/* 232:    */   }
/* 233:    */   
/* 234:    */   static native void nglDrawElementsInstancedBaseVertexBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, int paramInt5, long paramLong2);
/* 235:    */   
/* 236:    */   public static void glProvokingVertex(int mode)
/* 237:    */   {
/* 238:346 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 239:347 */     long function_pointer = caps.glProvokingVertex;
/* 240:348 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 241:349 */     nglProvokingVertex(mode, function_pointer);
/* 242:    */   }
/* 243:    */   
/* 244:    */   static native void nglProvokingVertex(int paramInt, long paramLong);
/* 245:    */   
/* 246:    */   public static void glTexImage2DMultisample(int target, int samples, int internalformat, int width, int height, boolean fixedsamplelocations)
/* 247:    */   {
/* 248:354 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 249:355 */     long function_pointer = caps.glTexImage2DMultisample;
/* 250:356 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 251:357 */     nglTexImage2DMultisample(target, samples, internalformat, width, height, fixedsamplelocations, function_pointer);
/* 252:    */   }
/* 253:    */   
/* 254:    */   static native void nglTexImage2DMultisample(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, long paramLong);
/* 255:    */   
/* 256:    */   public static void glTexImage3DMultisample(int target, int samples, int internalformat, int width, int height, int depth, boolean fixedsamplelocations)
/* 257:    */   {
/* 258:362 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 259:363 */     long function_pointer = caps.glTexImage3DMultisample;
/* 260:364 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 261:365 */     nglTexImage3DMultisample(target, samples, internalformat, width, height, depth, fixedsamplelocations, function_pointer);
/* 262:    */   }
/* 263:    */   
/* 264:    */   static native void nglTexImage3DMultisample(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, long paramLong);
/* 265:    */   
/* 266:    */   public static void glGetMultisample(int pname, int index, FloatBuffer val)
/* 267:    */   {
/* 268:370 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 269:371 */     long function_pointer = caps.glGetMultisamplefv;
/* 270:372 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 271:373 */     BufferChecks.checkBuffer(val, 2);
/* 272:374 */     nglGetMultisamplefv(pname, index, MemoryUtil.getAddress(val), function_pointer);
/* 273:    */   }
/* 274:    */   
/* 275:    */   static native void nglGetMultisamplefv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 276:    */   
/* 277:    */   public static void glSampleMaski(int index, int mask)
/* 278:    */   {
/* 279:379 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 280:380 */     long function_pointer = caps.glSampleMaski;
/* 281:381 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 282:382 */     nglSampleMaski(index, mask, function_pointer);
/* 283:    */   }
/* 284:    */   
/* 285:    */   static native void nglSampleMaski(int paramInt1, int paramInt2, long paramLong);
/* 286:    */   
/* 287:    */   public static void glFramebufferTexture(int target, int attachment, int texture, int level)
/* 288:    */   {
/* 289:387 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 290:388 */     long function_pointer = caps.glFramebufferTexture;
/* 291:389 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 292:390 */     nglFramebufferTexture(target, attachment, texture, level, function_pointer);
/* 293:    */   }
/* 294:    */   
/* 295:    */   static native void nglFramebufferTexture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 296:    */   
/* 297:    */   public static GLSync glFenceSync(int condition, int flags)
/* 298:    */   {
/* 299:395 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 300:396 */     long function_pointer = caps.glFenceSync;
/* 301:397 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 302:398 */     GLSync __result = new GLSync(nglFenceSync(condition, flags, function_pointer));
/* 303:399 */     return __result;
/* 304:    */   }
/* 305:    */   
/* 306:    */   static native long nglFenceSync(int paramInt1, int paramInt2, long paramLong);
/* 307:    */   
/* 308:    */   public static boolean glIsSync(GLSync sync)
/* 309:    */   {
/* 310:404 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 311:405 */     long function_pointer = caps.glIsSync;
/* 312:406 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 313:407 */     boolean __result = nglIsSync(sync.getPointer(), function_pointer);
/* 314:408 */     return __result;
/* 315:    */   }
/* 316:    */   
/* 317:    */   static native boolean nglIsSync(long paramLong1, long paramLong2);
/* 318:    */   
/* 319:    */   public static void glDeleteSync(GLSync sync)
/* 320:    */   {
/* 321:413 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 322:414 */     long function_pointer = caps.glDeleteSync;
/* 323:415 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 324:416 */     nglDeleteSync(sync.getPointer(), function_pointer);
/* 325:    */   }
/* 326:    */   
/* 327:    */   static native void nglDeleteSync(long paramLong1, long paramLong2);
/* 328:    */   
/* 329:    */   public static int glClientWaitSync(GLSync sync, int flags, long timeout)
/* 330:    */   {
/* 331:421 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 332:422 */     long function_pointer = caps.glClientWaitSync;
/* 333:423 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 334:424 */     int __result = nglClientWaitSync(sync.getPointer(), flags, timeout, function_pointer);
/* 335:425 */     return __result;
/* 336:    */   }
/* 337:    */   
/* 338:    */   static native int nglClientWaitSync(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/* 339:    */   
/* 340:    */   public static void glWaitSync(GLSync sync, int flags, long timeout)
/* 341:    */   {
/* 342:430 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 343:431 */     long function_pointer = caps.glWaitSync;
/* 344:432 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 345:433 */     nglWaitSync(sync.getPointer(), flags, timeout, function_pointer);
/* 346:    */   }
/* 347:    */   
/* 348:    */   static native void nglWaitSync(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/* 349:    */   
/* 350:    */   public static void glGetInteger64(int pname, LongBuffer data)
/* 351:    */   {
/* 352:438 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 353:439 */     long function_pointer = caps.glGetInteger64v;
/* 354:440 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 355:441 */     BufferChecks.checkBuffer(data, 1);
/* 356:442 */     nglGetInteger64v(pname, MemoryUtil.getAddress(data), function_pointer);
/* 357:    */   }
/* 358:    */   
/* 359:    */   static native void nglGetInteger64v(int paramInt, long paramLong1, long paramLong2);
/* 360:    */   
/* 361:    */   public static long glGetInteger64(int pname)
/* 362:    */   {
/* 363:448 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 364:449 */     long function_pointer = caps.glGetInteger64v;
/* 365:450 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 366:451 */     LongBuffer data = APIUtil.getBufferLong(caps);
/* 367:452 */     nglGetInteger64v(pname, MemoryUtil.getAddress(data), function_pointer);
/* 368:453 */     return data.get(0);
/* 369:    */   }
/* 370:    */   
/* 371:    */   public static void glGetInteger64(int value, int index, LongBuffer data)
/* 372:    */   {
/* 373:457 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 374:458 */     long function_pointer = caps.glGetInteger64i_v;
/* 375:459 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 376:460 */     BufferChecks.checkBuffer(data, 4);
/* 377:461 */     nglGetInteger64i_v(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 378:    */   }
/* 379:    */   
/* 380:    */   static native void nglGetInteger64i_v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 381:    */   
/* 382:    */   public static long glGetInteger64(int value, int index)
/* 383:    */   {
/* 384:467 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 385:468 */     long function_pointer = caps.glGetInteger64i_v;
/* 386:469 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 387:470 */     LongBuffer data = APIUtil.getBufferLong(caps);
/* 388:471 */     nglGetInteger64i_v(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 389:472 */     return data.get(0);
/* 390:    */   }
/* 391:    */   
/* 392:    */   public static void glGetSync(GLSync sync, int pname, IntBuffer length, IntBuffer values)
/* 393:    */   {
/* 394:476 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 395:477 */     long function_pointer = caps.glGetSynciv;
/* 396:478 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 397:479 */     if (length != null) {
/* 398:480 */       BufferChecks.checkBuffer(length, 1);
/* 399:    */     }
/* 400:481 */     BufferChecks.checkDirect(values);
/* 401:482 */     nglGetSynciv(sync.getPointer(), pname, values.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(values), function_pointer);
/* 402:    */   }
/* 403:    */   
/* 404:    */   static native void nglGetSynciv(long paramLong1, int paramInt1, int paramInt2, long paramLong2, long paramLong3, long paramLong4);
/* 405:    */   
/* 406:    */   @Deprecated
/* 407:    */   public static int glGetSync(GLSync sync, int pname)
/* 408:    */   {
/* 409:493 */     return glGetSynci(sync, pname);
/* 410:    */   }
/* 411:    */   
/* 412:    */   public static int glGetSynci(GLSync sync, int pname)
/* 413:    */   {
/* 414:498 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 415:499 */     long function_pointer = caps.glGetSynciv;
/* 416:500 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 417:501 */     IntBuffer values = APIUtil.getBufferInt(caps);
/* 418:502 */     nglGetSynciv(sync.getPointer(), pname, 1, 0L, MemoryUtil.getAddress(values), function_pointer);
/* 419:503 */     return values.get(0);
/* 420:    */   }
/* 421:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL32
 * JD-Core Version:    0.7.0.1
 */