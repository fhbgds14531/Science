/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBTextureStorageMultisample
/*  6:   */ {
/*  7:   */   public static void glTexStorage2DMultisample(int target, int samples, int internalformat, int width, int height, boolean fixedsamplelocations)
/*  8:   */   {
/*  9:13 */     GL43.glTexStorage2DMultisample(target, samples, internalformat, width, height, fixedsamplelocations);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static void glTexStorage3DMultisample(int target, int samples, int internalformat, int width, int height, int depth, boolean fixedsamplelocations)
/* 13:   */   {
/* 14:17 */     GL43.glTexStorage3DMultisample(target, samples, internalformat, width, height, depth, fixedsamplelocations);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static void glTextureStorage2DMultisampleEXT(int texture, int target, int samples, int internalformat, int width, int height, boolean fixedsamplelocations)
/* 18:   */   {
/* 19:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:22 */     long function_pointer = caps.glTextureStorage2DMultisampleEXT;
/* 21:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:24 */     nglTextureStorage2DMultisampleEXT(texture, target, samples, internalformat, width, height, fixedsamplelocations, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglTextureStorage2DMultisampleEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, long paramLong);
/* 26:   */   
/* 27:   */   public static void glTextureStorage3DMultisampleEXT(int texture, int target, int samples, int internalformat, int width, int height, int depth, boolean fixedsamplelocations)
/* 28:   */   {
/* 29:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:30 */     long function_pointer = caps.glTextureStorage3DMultisampleEXT;
/* 31:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:32 */     nglTextureStorage3DMultisampleEXT(texture, target, samples, internalformat, width, height, depth, fixedsamplelocations, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglTextureStorage3DMultisampleEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, long paramLong);
/* 36:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureStorageMultisample
 * JD-Core Version:    0.7.0.1
 */