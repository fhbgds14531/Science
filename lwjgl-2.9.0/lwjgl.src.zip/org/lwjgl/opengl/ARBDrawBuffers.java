/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class ARBDrawBuffers
/*  8:   */ {
/*  9:   */   public static final int GL_MAX_DRAW_BUFFERS_ARB = 34852;
/* 10:   */   public static final int GL_DRAW_BUFFER0_ARB = 34853;
/* 11:   */   public static final int GL_DRAW_BUFFER1_ARB = 34854;
/* 12:   */   public static final int GL_DRAW_BUFFER2_ARB = 34855;
/* 13:   */   public static final int GL_DRAW_BUFFER3_ARB = 34856;
/* 14:   */   public static final int GL_DRAW_BUFFER4_ARB = 34857;
/* 15:   */   public static final int GL_DRAW_BUFFER5_ARB = 34858;
/* 16:   */   public static final int GL_DRAW_BUFFER6_ARB = 34859;
/* 17:   */   public static final int GL_DRAW_BUFFER7_ARB = 34860;
/* 18:   */   public static final int GL_DRAW_BUFFER8_ARB = 34861;
/* 19:   */   public static final int GL_DRAW_BUFFER9_ARB = 34862;
/* 20:   */   public static final int GL_DRAW_BUFFER10_ARB = 34863;
/* 21:   */   public static final int GL_DRAW_BUFFER11_ARB = 34864;
/* 22:   */   public static final int GL_DRAW_BUFFER12_ARB = 34865;
/* 23:   */   public static final int GL_DRAW_BUFFER13_ARB = 34866;
/* 24:   */   public static final int GL_DRAW_BUFFER14_ARB = 34867;
/* 25:   */   public static final int GL_DRAW_BUFFER15_ARB = 34868;
/* 26:   */   
/* 27:   */   public static void glDrawBuffersARB(IntBuffer buffers)
/* 28:   */   {
/* 29:35 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:36 */     long function_pointer = caps.glDrawBuffersARB;
/* 31:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:38 */     BufferChecks.checkDirect(buffers);
/* 33:39 */     nglDrawBuffersARB(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/* 34:   */   }
/* 35:   */   
/* 36:   */   static native void nglDrawBuffersARB(int paramInt, long paramLong1, long paramLong2);
/* 37:   */   
/* 38:   */   public static void glDrawBuffersARB(int buffer)
/* 39:   */   {
/* 40:45 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 41:46 */     long function_pointer = caps.glDrawBuffersARB;
/* 42:47 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 43:48 */     nglDrawBuffersARB(1, APIUtil.getInt(caps, buffer), function_pointer);
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDrawBuffers
 * JD-Core Version:    0.7.0.1
 */