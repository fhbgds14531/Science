/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.Buffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import org.lwjgl.BufferUtils;
/*   6:    */ import org.lwjgl.LWJGLUtil;
/*   7:    */ 
/*   8:    */ class GLChecks
/*   9:    */ {
/*  10:    */   static int getBufferObjectSize(ContextCapabilities caps, int buffer_enum)
/*  11:    */   {
/*  12: 69 */     return GL15.glGetBufferParameteri(buffer_enum, 34660);
/*  13:    */   }
/*  14:    */   
/*  15:    */   static int getBufferObjectSizeARB(ContextCapabilities caps, int buffer_enum)
/*  16:    */   {
/*  17: 73 */     return ARBBufferObject.glGetBufferParameteriARB(buffer_enum, 34660);
/*  18:    */   }
/*  19:    */   
/*  20:    */   static int getBufferObjectSizeATI(ContextCapabilities caps, int buffer)
/*  21:    */   {
/*  22: 77 */     return ATIVertexArrayObject.glGetObjectBufferiATI(buffer, 34660);
/*  23:    */   }
/*  24:    */   
/*  25:    */   static int getNamedBufferObjectSize(ContextCapabilities caps, int buffer)
/*  26:    */   {
/*  27: 81 */     return EXTDirectStateAccess.glGetNamedBufferParameterEXT(buffer, 34660);
/*  28:    */   }
/*  29:    */   
/*  30:    */   static void ensureArrayVBOdisabled(ContextCapabilities caps)
/*  31:    */   {
/*  32: 86 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).arrayBuffer != 0)) {
/*  33: 87 */       throw new OpenGLException("Cannot use Buffers when Array Buffer Object is enabled");
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   static void ensureArrayVBOenabled(ContextCapabilities caps)
/*  38:    */   {
/*  39: 92 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).arrayBuffer == 0)) {
/*  40: 93 */       throw new OpenGLException("Cannot use offsets when Array Buffer Object is disabled");
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   static void ensureElementVBOdisabled(ContextCapabilities caps)
/*  45:    */   {
/*  46: 98 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getElementArrayBufferBound(caps) != 0)) {
/*  47: 99 */       throw new OpenGLException("Cannot use Buffers when Element Array Buffer Object is enabled");
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   static void ensureElementVBOenabled(ContextCapabilities caps)
/*  52:    */   {
/*  53:104 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getElementArrayBufferBound(caps) == 0)) {
/*  54:105 */       throw new OpenGLException("Cannot use offsets when Element Array Buffer Object is disabled");
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   static void ensureIndirectBOdisabled(ContextCapabilities caps)
/*  59:    */   {
/*  60:110 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).indirectBuffer != 0)) {
/*  61:111 */       throw new OpenGLException("Cannot use Buffers when Draw Indirect Object is enabled");
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   static void ensureIndirectBOenabled(ContextCapabilities caps)
/*  66:    */   {
/*  67:116 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).indirectBuffer == 0)) {
/*  68:117 */       throw new OpenGLException("Cannot use offsets when Draw Indirect Object is disabled");
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   static void ensurePackPBOdisabled(ContextCapabilities caps)
/*  73:    */   {
/*  74:122 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).pixelPackBuffer != 0)) {
/*  75:123 */       throw new OpenGLException("Cannot use Buffers when Pixel Pack Buffer Object is enabled");
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   static void ensurePackPBOenabled(ContextCapabilities caps)
/*  80:    */   {
/*  81:128 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).pixelPackBuffer == 0)) {
/*  82:129 */       throw new OpenGLException("Cannot use offsets when Pixel Pack Buffer Object is disabled");
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   static void ensureUnpackPBOdisabled(ContextCapabilities caps)
/*  87:    */   {
/*  88:134 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).pixelUnpackBuffer != 0)) {
/*  89:135 */       throw new OpenGLException("Cannot use Buffers when Pixel Unpack Buffer Object is enabled");
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   static void ensureUnpackPBOenabled(ContextCapabilities caps)
/*  94:    */   {
/*  95:140 */     if ((LWJGLUtil.CHECKS) && (StateTracker.getReferences(caps).pixelUnpackBuffer == 0)) {
/*  96:141 */       throw new OpenGLException("Cannot use offsets when Pixel Unpack Buffer Object is disabled");
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   static int calculateImageStorage(Buffer buffer, int format, int type, int width, int height, int depth)
/* 101:    */   {
/* 102:156 */     return LWJGLUtil.CHECKS ? calculateImageStorage(format, type, width, height, depth) >> BufferUtils.getElementSizeExponent(buffer) : 0;
/* 103:    */   }
/* 104:    */   
/* 105:    */   static int calculateTexImage1DStorage(Buffer buffer, int format, int type, int width)
/* 106:    */   {
/* 107:160 */     return LWJGLUtil.CHECKS ? calculateTexImage1DStorage(format, type, width) >> BufferUtils.getElementSizeExponent(buffer) : 0;
/* 108:    */   }
/* 109:    */   
/* 110:    */   static int calculateTexImage2DStorage(Buffer buffer, int format, int type, int width, int height)
/* 111:    */   {
/* 112:164 */     return LWJGLUtil.CHECKS ? calculateTexImage2DStorage(format, type, width, height) >> BufferUtils.getElementSizeExponent(buffer) : 0;
/* 113:    */   }
/* 114:    */   
/* 115:    */   static int calculateTexImage3DStorage(Buffer buffer, int format, int type, int width, int height, int depth)
/* 116:    */   {
/* 117:168 */     return LWJGLUtil.CHECKS ? calculateTexImage3DStorage(format, type, width, height, depth) >> BufferUtils.getElementSizeExponent(buffer) : 0;
/* 118:    */   }
/* 119:    */   
/* 120:    */   private static int calculateImageStorage(int format, int type, int width, int height, int depth)
/* 121:    */   {
/* 122:183 */     return calculateBytesPerPixel(format, type) * width * height * depth;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static int calculateTexImage1DStorage(int format, int type, int width)
/* 126:    */   {
/* 127:187 */     return calculateBytesPerPixel(format, type) * width;
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static int calculateTexImage2DStorage(int format, int type, int width, int height)
/* 131:    */   {
/* 132:191 */     return calculateTexImage1DStorage(format, type, width) * height;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static int calculateTexImage3DStorage(int format, int type, int width, int height, int depth)
/* 136:    */   {
/* 137:195 */     return calculateTexImage2DStorage(format, type, width, height) * depth;
/* 138:    */   }
/* 139:    */   
/* 140:    */   private static int calculateBytesPerPixel(int format, int type)
/* 141:    */   {
/* 142:    */     int bpe;
/* 143:200 */     switch (type)
/* 144:    */     {
/* 145:    */     case 5120: 
/* 146:    */     case 5121: 
/* 147:203 */       bpe = 1;
/* 148:204 */       break;
/* 149:    */     case 5122: 
/* 150:    */     case 5123: 
/* 151:207 */       bpe = 2;
/* 152:208 */       break;
/* 153:    */     case 5124: 
/* 154:    */     case 5125: 
/* 155:    */     case 5126: 
/* 156:212 */       bpe = 4;
/* 157:213 */       break;
/* 158:    */     default: 
/* 159:216 */       return 0;
/* 160:    */     }
/* 161:    */     int epp;
/* 162:220 */     switch (format)
/* 163:    */     {
/* 164:    */     case 6406: 
/* 165:    */     case 6409: 
/* 166:223 */       epp = 1;
/* 167:224 */       break;
/* 168:    */     case 6410: 
/* 169:227 */       epp = 2;
/* 170:228 */       break;
/* 171:    */     case 6407: 
/* 172:    */     case 32992: 
/* 173:231 */       epp = 3;
/* 174:232 */       break;
/* 175:    */     case 6408: 
/* 176:    */     case 32768: 
/* 177:    */     case 32993: 
/* 178:236 */       epp = 4;
/* 179:237 */       break;
/* 180:    */     default: 
/* 181:240 */       return 0;
/* 182:    */     }
/* 183:245 */     return bpe * epp;
/* 184:    */   }
/* 185:    */   
/* 186:    */   static int calculateBytesPerCharCode(int type)
/* 187:    */   {
/* 188:251 */     switch (type)
/* 189:    */     {
/* 190:    */     case 5121: 
/* 191:    */     case 37018: 
/* 192:254 */       return 1;
/* 193:    */     case 5123: 
/* 194:    */     case 5127: 
/* 195:    */     case 37019: 
/* 196:258 */       return 2;
/* 197:    */     case 5128: 
/* 198:260 */       return 3;
/* 199:    */     case 5129: 
/* 200:262 */       return 4;
/* 201:    */     }
/* 202:264 */     throw new IllegalArgumentException("Unsupported charcode type: " + type);
/* 203:    */   }
/* 204:    */   
/* 205:    */   static int calculateBytesPerPathName(int pathNameType)
/* 206:    */   {
/* 207:269 */     switch (pathNameType)
/* 208:    */     {
/* 209:    */     case 5120: 
/* 210:    */     case 5121: 
/* 211:    */     case 37018: 
/* 212:273 */       return 1;
/* 213:    */     case 5122: 
/* 214:    */     case 5123: 
/* 215:    */     case 5127: 
/* 216:    */     case 37019: 
/* 217:278 */       return 2;
/* 218:    */     case 5128: 
/* 219:280 */       return 3;
/* 220:    */     case 5124: 
/* 221:    */     case 5125: 
/* 222:    */     case 5126: 
/* 223:    */     case 5129: 
/* 224:285 */       return 4;
/* 225:    */     }
/* 226:287 */     throw new IllegalArgumentException("Unsupported path name type: " + pathNameType);
/* 227:    */   }
/* 228:    */   
/* 229:    */   static int calculateTransformPathValues(int transformType)
/* 230:    */   {
/* 231:292 */     switch (transformType)
/* 232:    */     {
/* 233:    */     case 0: 
/* 234:294 */       return 0;
/* 235:    */     case 37006: 
/* 236:    */     case 37007: 
/* 237:297 */       return 1;
/* 238:    */     case 37008: 
/* 239:299 */       return 2;
/* 240:    */     case 37009: 
/* 241:301 */       return 3;
/* 242:    */     case 37010: 
/* 243:    */     case 37014: 
/* 244:304 */       return 6;
/* 245:    */     case 37012: 
/* 246:    */     case 37016: 
/* 247:307 */       return 12;
/* 248:    */     }
/* 249:309 */     throw new IllegalArgumentException("Unsupported transform type: " + transformType);
/* 250:    */   }
/* 251:    */   
/* 252:    */   static int calculatePathColorGenCoeffsCount(int genMode, int colorFormat)
/* 253:    */   {
/* 254:314 */     int coeffsPerComponent = calculatePathGenCoeffsPerComponent(genMode);
/* 255:316 */     switch (colorFormat)
/* 256:    */     {
/* 257:    */     case 6407: 
/* 258:318 */       return 3 * coeffsPerComponent;
/* 259:    */     case 6408: 
/* 260:320 */       return 4 * coeffsPerComponent;
/* 261:    */     }
/* 262:322 */     return coeffsPerComponent;
/* 263:    */   }
/* 264:    */   
/* 265:    */   static int calculatePathTextGenCoeffsPerComponent(FloatBuffer coeffs, int genMode)
/* 266:    */   {
/* 267:327 */     if (genMode == 0) {
/* 268:328 */       return 0;
/* 269:    */     }
/* 270:330 */     return coeffs.remaining() / calculatePathGenCoeffsPerComponent(genMode);
/* 271:    */   }
/* 272:    */   
/* 273:    */   private static int calculatePathGenCoeffsPerComponent(int genMode)
/* 274:    */   {
/* 275:334 */     switch (genMode)
/* 276:    */     {
/* 277:    */     case 0: 
/* 278:336 */       return 0;
/* 279:    */     case 9217: 
/* 280:    */     case 37002: 
/* 281:339 */       return 3;
/* 282:    */     case 9216: 
/* 283:341 */       return 4;
/* 284:    */     }
/* 285:343 */     throw new IllegalArgumentException("Unsupported gen mode: " + genMode);
/* 286:    */   }
/* 287:    */   
/* 288:    */   static int calculateMetricsSize(int metricQueryMask, int stride)
/* 289:    */   {
/* 290:348 */     if ((LWJGLUtil.DEBUG) && ((stride < 0) || (stride % 4 != 0))) {
/* 291:349 */       throw new IllegalArgumentException("Invalid stride value: " + stride);
/* 292:    */     }
/* 293:351 */     int metrics = Integer.bitCount(metricQueryMask);
/* 294:353 */     if ((LWJGLUtil.DEBUG) && (stride >> 2 < metrics)) {
/* 295:354 */       throw new IllegalArgumentException("The queried metrics do not fit in the specified stride: " + stride);
/* 296:    */     }
/* 297:356 */     return stride == 0 ? metrics : stride >> 2;
/* 298:    */   }
/* 299:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GLChecks
 * JD-Core Version:    0.7.0.1
 */