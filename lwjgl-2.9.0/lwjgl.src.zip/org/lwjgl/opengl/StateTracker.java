/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ 
/*   5:    */ final class StateTracker
/*   6:    */ {
/*   7:    */   private ReferencesStack references_stack;
/*   8:    */   private final StateStack attrib_stack;
/*   9:    */   private boolean insideBeginEnd;
/*  10: 48 */   private final FastIntMap<VAOState> vaoMap = new FastIntMap();
/*  11:    */   
/*  12:    */   StateTracker()
/*  13:    */   {
/*  14: 51 */     this.attrib_stack = new StateStack(0);
/*  15:    */   }
/*  16:    */   
/*  17:    */   void init()
/*  18:    */   {
/*  19: 56 */     this.references_stack = new ReferencesStack();
/*  20:    */   }
/*  21:    */   
/*  22:    */   static void setBeginEnd(ContextCapabilities caps, boolean inside)
/*  23:    */   {
/*  24: 60 */     caps.tracker.insideBeginEnd = inside;
/*  25:    */   }
/*  26:    */   
/*  27:    */   boolean isBeginEnd()
/*  28:    */   {
/*  29: 64 */     return this.insideBeginEnd;
/*  30:    */   }
/*  31:    */   
/*  32:    */   static void popAttrib(ContextCapabilities caps)
/*  33:    */   {
/*  34: 68 */     caps.tracker.doPopAttrib();
/*  35:    */   }
/*  36:    */   
/*  37:    */   private void doPopAttrib()
/*  38:    */   {
/*  39: 72 */     this.references_stack.popState(this.attrib_stack.popState());
/*  40:    */   }
/*  41:    */   
/*  42:    */   static void pushAttrib(ContextCapabilities caps, int mask)
/*  43:    */   {
/*  44: 76 */     caps.tracker.doPushAttrib(mask);
/*  45:    */   }
/*  46:    */   
/*  47:    */   private void doPushAttrib(int mask)
/*  48:    */   {
/*  49: 80 */     this.attrib_stack.pushState(mask);
/*  50: 81 */     this.references_stack.pushState();
/*  51:    */   }
/*  52:    */   
/*  53:    */   static References getReferences(ContextCapabilities caps)
/*  54:    */   {
/*  55: 85 */     return caps.tracker.references_stack.getReferences();
/*  56:    */   }
/*  57:    */   
/*  58:    */   static void bindBuffer(ContextCapabilities caps, int target, int buffer)
/*  59:    */   {
/*  60: 89 */     BaseReferences references = getReferences(caps);
/*  61: 90 */     switch (target)
/*  62:    */     {
/*  63:    */     case 34962: 
/*  64: 92 */       references.arrayBuffer = buffer;
/*  65: 93 */       break;
/*  66:    */     case 34963: 
/*  67: 97 */       if (references.vertexArrayObject != 0) {
/*  68: 98 */         ((VAOState)caps.tracker.vaoMap.get(references.vertexArrayObject)).elementArrayBuffer = buffer;
/*  69:    */       } else {
/*  70:100 */         references.elementArrayBuffer = buffer;
/*  71:    */       }
/*  72:101 */       break;
/*  73:    */     case 35051: 
/*  74:103 */       references.pixelPackBuffer = buffer;
/*  75:104 */       break;
/*  76:    */     case 35052: 
/*  77:106 */       references.pixelUnpackBuffer = buffer;
/*  78:107 */       break;
/*  79:    */     case 36671: 
/*  80:109 */       references.indirectBuffer = buffer;
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   static void bindVAO(ContextCapabilities caps, int array)
/*  85:    */   {
/*  86:115 */     FastIntMap<VAOState> vaoMap = caps.tracker.vaoMap;
/*  87:116 */     if (!vaoMap.containsKey(array)) {
/*  88:117 */       vaoMap.put(array, new VAOState(null));
/*  89:    */     }
/*  90:119 */     getReferences(caps).vertexArrayObject = array;
/*  91:    */   }
/*  92:    */   
/*  93:    */   static void deleteVAO(ContextCapabilities caps, IntBuffer arrays)
/*  94:    */   {
/*  95:123 */     for (int i = arrays.position(); i < arrays.limit(); i++) {
/*  96:124 */       deleteVAO(caps, arrays.get(i));
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   static void deleteVAO(ContextCapabilities caps, int array)
/* 101:    */   {
/* 102:128 */     caps.tracker.vaoMap.remove(array);
/* 103:    */     
/* 104:130 */     BaseReferences references = getReferences(caps);
/* 105:131 */     if (references.vertexArrayObject == array) {
/* 106:132 */       references.vertexArrayObject = 0;
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   static int getElementArrayBufferBound(ContextCapabilities caps)
/* 111:    */   {
/* 112:143 */     BaseReferences references = getReferences(caps);
/* 113:145 */     if (references.vertexArrayObject == 0) {
/* 114:146 */       return references.elementArrayBuffer;
/* 115:    */     }
/* 116:148 */     return ((VAOState)caps.tracker.vaoMap.get(references.vertexArrayObject)).elementArrayBuffer;
/* 117:    */   }
/* 118:    */   
/* 119:    */   private static class VAOState
/* 120:    */   {
/* 121:    */     int elementArrayBuffer;
/* 122:    */   }
/* 123:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.StateTracker
 * JD-Core Version:    0.7.0.1
 */