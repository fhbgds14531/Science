/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import org.lwjgl.LWJGLException;
/*   4:    */ import org.lwjgl.LWJGLUtil;
/*   5:    */ import org.lwjgl.Sys;
/*   6:    */ 
/*   7:    */ public final class AL
/*   8:    */ {
/*   9:    */   static ALCdevice device;
/*  10:    */   static ALCcontext context;
/*  11:    */   private static boolean created;
/*  12:    */   
/*  13:    */   private static native void nCreate(String paramString)
/*  14:    */     throws LWJGLException;
/*  15:    */   
/*  16:    */   private static native void nCreateDefault()
/*  17:    */     throws LWJGLException;
/*  18:    */   
/*  19:    */   private static native void nDestroy();
/*  20:    */   
/*  21:    */   public static boolean isCreated()
/*  22:    */   {
/*  23: 87 */     return created;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static void create(String deviceArguments, int contextFrequency, int contextRefresh, boolean contextSynchronized)
/*  27:    */     throws LWJGLException
/*  28:    */   {
/*  29:102 */     create(deviceArguments, contextFrequency, contextRefresh, contextSynchronized, true);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static void create(String deviceArguments, int contextFrequency, int contextRefresh, boolean contextSynchronized, boolean openDevice)
/*  33:    */     throws LWJGLException
/*  34:    */   {
/*  35:112 */     if (created) {
/*  36:113 */       throw new IllegalStateException("Only one OpenAL context may be instantiated at any one time.");
/*  37:    */     }
/*  38:    */     String libname;
/*  39:    */     String[] library_names;
/*  40:116 */     switch (LWJGLUtil.getPlatform())
/*  41:    */     {
/*  42:    */     case 3: 
/*  43:118 */       libname = "OpenAL32";
/*  44:119 */       library_names = new String[] { "OpenAL64.dll", "OpenAL32.dll" };
/*  45:120 */       break;
/*  46:    */     case 1: 
/*  47:122 */       libname = "openal";
/*  48:123 */       library_names = new String[] { "libopenal64.so", "libopenal.so", "libopenal.so.0" };
/*  49:124 */       break;
/*  50:    */     case 2: 
/*  51:126 */       libname = "openal";
/*  52:127 */       library_names = new String[] { "openal.dylib" };
/*  53:128 */       break;
/*  54:    */     default: 
/*  55:130 */       throw new LWJGLException("Unknown platform: " + LWJGLUtil.getPlatform());
/*  56:    */     }
/*  57:132 */     String[] oalPaths = LWJGLUtil.getLibraryPaths(libname, library_names, AL.class.getClassLoader());
/*  58:133 */     LWJGLUtil.log("Found " + oalPaths.length + " OpenAL paths");
/*  59:134 */     for (String oalPath : oalPaths) {
/*  60:    */       try
/*  61:    */       {
/*  62:136 */         nCreate(oalPath);
/*  63:137 */         created = true;
/*  64:138 */         init(deviceArguments, contextFrequency, contextRefresh, contextSynchronized, openDevice);
/*  65:    */       }
/*  66:    */       catch (LWJGLException e)
/*  67:    */       {
/*  68:141 */         LWJGLUtil.log("Failed to load " + oalPath + ": " + e.getMessage());
/*  69:    */       }
/*  70:    */     }
/*  71:144 */     if ((!created) && (LWJGLUtil.getPlatform() == 2))
/*  72:    */     {
/*  73:146 */       nCreateDefault();
/*  74:147 */       created = true;
/*  75:148 */       init(deviceArguments, contextFrequency, contextRefresh, contextSynchronized, openDevice);
/*  76:    */     }
/*  77:150 */     if (!created) {
/*  78:151 */       throw new LWJGLException("Could not locate OpenAL library.");
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static void init(String deviceArguments, int contextFrequency, int contextRefresh, boolean contextSynchronized, boolean openDevice)
/*  83:    */     throws LWJGLException
/*  84:    */   {
/*  85:    */     try
/*  86:    */     {
/*  87:156 */       AL10.initNativeStubs();
/*  88:157 */       ALC10.initNativeStubs();
/*  89:159 */       if (openDevice)
/*  90:    */       {
/*  91:160 */         device = ALC10.alcOpenDevice(deviceArguments);
/*  92:161 */         if (device == null) {
/*  93:162 */           throw new LWJGLException("Could not open ALC device");
/*  94:    */         }
/*  95:165 */         if (contextFrequency == -1) {
/*  96:166 */           context = ALC10.alcCreateContext(device, null);
/*  97:    */         } else {
/*  98:168 */           context = ALC10.alcCreateContext(device, ALCcontext.createAttributeList(contextFrequency, contextRefresh, contextSynchronized ? 1 : 0));
/*  99:    */         }
/* 100:172 */         ALC10.alcMakeContextCurrent(context);
/* 101:    */       }
/* 102:    */     }
/* 103:    */     catch (LWJGLException e)
/* 104:    */     {
/* 105:175 */       destroy();
/* 106:176 */       throw e;
/* 107:    */     }
/* 108:179 */     ALC11.initialize();
/* 109:188 */     if (ALC10.alcIsExtensionPresent(device, "ALC_EXT_EFX")) {
/* 110:189 */       EFX10.initNativeStubs();
/* 111:    */     }
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static void create()
/* 115:    */     throws LWJGLException
/* 116:    */   {
/* 117:201 */     create(null, 44100, 60, false);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static void destroy()
/* 121:    */   {
/* 122:208 */     if (context != null)
/* 123:    */     {
/* 124:209 */       ALC10.alcMakeContextCurrent(null);
/* 125:210 */       ALC10.alcDestroyContext(context);
/* 126:211 */       context = null;
/* 127:    */     }
/* 128:213 */     if (device != null)
/* 129:    */     {
/* 130:214 */       boolean result = ALC10.alcCloseDevice(device);
/* 131:215 */       device = null;
/* 132:    */     }
/* 133:217 */     resetNativeStubs(AL10.class);
/* 134:218 */     resetNativeStubs(AL11.class);
/* 135:219 */     resetNativeStubs(ALC10.class);
/* 136:220 */     resetNativeStubs(ALC11.class);
/* 137:221 */     resetNativeStubs(EFX10.class);
/* 138:223 */     if (created) {
/* 139:224 */       nDestroy();
/* 140:    */     }
/* 141:225 */     created = false;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static native void resetNativeStubs(Class paramClass);
/* 145:    */   
/* 146:    */   public static ALCcontext getContext()
/* 147:    */   {
/* 148:234 */     return context;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static ALCdevice getDevice()
/* 152:    */   {
/* 153:241 */     return device;
/* 154:    */   }
/* 155:    */   
/* 156:    */   static {}
/* 157:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.AL
 * JD-Core Version:    0.7.0.1
 */