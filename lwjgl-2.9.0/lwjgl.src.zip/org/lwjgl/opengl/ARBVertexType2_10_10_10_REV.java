/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ 
/*   5:    */ public final class ARBVertexType2_10_10_10_REV
/*   6:    */ {
/*   7:    */   public static final int GL_UNSIGNED_INT_2_10_10_10_REV = 33640;
/*   8:    */   public static final int GL_INT_2_10_10_10_REV = 36255;
/*   9:    */   
/*  10:    */   public static void glVertexP2ui(int type, int value)
/*  11:    */   {
/*  12: 22 */     GL33.glVertexP2ui(type, value);
/*  13:    */   }
/*  14:    */   
/*  15:    */   public static void glVertexP3ui(int type, int value)
/*  16:    */   {
/*  17: 26 */     GL33.glVertexP3ui(type, value);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static void glVertexP4ui(int type, int value)
/*  21:    */   {
/*  22: 30 */     GL33.glVertexP4ui(type, value);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static void glVertexP2u(int type, IntBuffer value)
/*  26:    */   {
/*  27: 34 */     GL33.glVertexP2u(type, value);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void glVertexP3u(int type, IntBuffer value)
/*  31:    */   {
/*  32: 38 */     GL33.glVertexP3u(type, value);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void glVertexP4u(int type, IntBuffer value)
/*  36:    */   {
/*  37: 42 */     GL33.glVertexP4u(type, value);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void glTexCoordP1ui(int type, int coords)
/*  41:    */   {
/*  42: 46 */     GL33.glTexCoordP1ui(type, coords);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static void glTexCoordP2ui(int type, int coords)
/*  46:    */   {
/*  47: 50 */     GL33.glTexCoordP2ui(type, coords);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void glTexCoordP3ui(int type, int coords)
/*  51:    */   {
/*  52: 54 */     GL33.glTexCoordP3ui(type, coords);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void glTexCoordP4ui(int type, int coords)
/*  56:    */   {
/*  57: 58 */     GL33.glTexCoordP4ui(type, coords);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void glTexCoordP1u(int type, IntBuffer coords)
/*  61:    */   {
/*  62: 62 */     GL33.glTexCoordP1u(type, coords);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glTexCoordP2u(int type, IntBuffer coords)
/*  66:    */   {
/*  67: 66 */     GL33.glTexCoordP2u(type, coords);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static void glTexCoordP3u(int type, IntBuffer coords)
/*  71:    */   {
/*  72: 70 */     GL33.glTexCoordP3u(type, coords);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void glTexCoordP4u(int type, IntBuffer coords)
/*  76:    */   {
/*  77: 74 */     GL33.glTexCoordP4u(type, coords);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static void glMultiTexCoordP1ui(int texture, int type, int coords)
/*  81:    */   {
/*  82: 78 */     GL33.glMultiTexCoordP1ui(texture, type, coords);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void glMultiTexCoordP2ui(int texture, int type, int coords)
/*  86:    */   {
/*  87: 82 */     GL33.glMultiTexCoordP2ui(texture, type, coords);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void glMultiTexCoordP3ui(int texture, int type, int coords)
/*  91:    */   {
/*  92: 86 */     GL33.glMultiTexCoordP3ui(texture, type, coords);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static void glMultiTexCoordP4ui(int texture, int type, int coords)
/*  96:    */   {
/*  97: 90 */     GL33.glMultiTexCoordP4ui(texture, type, coords);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void glMultiTexCoordP1u(int texture, int type, IntBuffer coords)
/* 101:    */   {
/* 102: 94 */     GL33.glMultiTexCoordP1u(texture, type, coords);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static void glMultiTexCoordP2u(int texture, int type, IntBuffer coords)
/* 106:    */   {
/* 107: 98 */     GL33.glMultiTexCoordP2u(texture, type, coords);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void glMultiTexCoordP3u(int texture, int type, IntBuffer coords)
/* 111:    */   {
/* 112:102 */     GL33.glMultiTexCoordP3u(texture, type, coords);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static void glMultiTexCoordP4u(int texture, int type, IntBuffer coords)
/* 116:    */   {
/* 117:106 */     GL33.glMultiTexCoordP4u(texture, type, coords);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static void glNormalP3ui(int type, int coords)
/* 121:    */   {
/* 122:110 */     GL33.glNormalP3ui(type, coords);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static void glNormalP3u(int type, IntBuffer coords)
/* 126:    */   {
/* 127:114 */     GL33.glNormalP3u(type, coords);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void glColorP3ui(int type, int color)
/* 131:    */   {
/* 132:118 */     GL33.glColorP3ui(type, color);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static void glColorP4ui(int type, int color)
/* 136:    */   {
/* 137:122 */     GL33.glColorP4ui(type, color);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void glColorP3u(int type, IntBuffer color)
/* 141:    */   {
/* 142:126 */     GL33.glColorP3u(type, color);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static void glColorP4u(int type, IntBuffer color)
/* 146:    */   {
/* 147:130 */     GL33.glColorP4u(type, color);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static void glSecondaryColorP3ui(int type, int color)
/* 151:    */   {
/* 152:134 */     GL33.glSecondaryColorP3ui(type, color);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static void glSecondaryColorP3u(int type, IntBuffer color)
/* 156:    */   {
/* 157:138 */     GL33.glSecondaryColorP3u(type, color);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static void glVertexAttribP1ui(int index, int type, boolean normalized, int value)
/* 161:    */   {
/* 162:142 */     GL33.glVertexAttribP1ui(index, type, normalized, value);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static void glVertexAttribP2ui(int index, int type, boolean normalized, int value)
/* 166:    */   {
/* 167:146 */     GL33.glVertexAttribP2ui(index, type, normalized, value);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static void glVertexAttribP3ui(int index, int type, boolean normalized, int value)
/* 171:    */   {
/* 172:150 */     GL33.glVertexAttribP3ui(index, type, normalized, value);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static void glVertexAttribP4ui(int index, int type, boolean normalized, int value)
/* 176:    */   {
/* 177:154 */     GL33.glVertexAttribP4ui(index, type, normalized, value);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static void glVertexAttribP1u(int index, int type, boolean normalized, IntBuffer value)
/* 181:    */   {
/* 182:158 */     GL33.glVertexAttribP1u(index, type, normalized, value);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static void glVertexAttribP2u(int index, int type, boolean normalized, IntBuffer value)
/* 186:    */   {
/* 187:162 */     GL33.glVertexAttribP2u(index, type, normalized, value);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static void glVertexAttribP3u(int index, int type, boolean normalized, IntBuffer value)
/* 191:    */   {
/* 192:166 */     GL33.glVertexAttribP3u(index, type, normalized, value);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static void glVertexAttribP4u(int index, int type, boolean normalized, IntBuffer value)
/* 196:    */   {
/* 197:170 */     GL33.glVertexAttribP4u(index, type, normalized, value);
/* 198:    */   }
/* 199:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexType2_10_10_10_REV
 * JD-Core Version:    0.7.0.1
 */