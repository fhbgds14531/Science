/*    1:     */ package org.lwjgl.openal;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.DoubleBuffer;
/*    5:     */ import java.nio.FloatBuffer;
/*    6:     */ import java.nio.IntBuffer;
/*    7:     */ import java.nio.ShortBuffer;
/*    8:     */ import org.lwjgl.BufferChecks;
/*    9:     */ import org.lwjgl.LWJGLException;
/*   10:     */ import org.lwjgl.MemoryUtil;
/*   11:     */ 
/*   12:     */ public final class AL10
/*   13:     */ {
/*   14:     */   public static final int AL_INVALID = -1;
/*   15:     */   public static final int AL_NONE = 0;
/*   16:     */   public static final int AL_FALSE = 0;
/*   17:     */   public static final int AL_TRUE = 1;
/*   18:     */   public static final int AL_SOURCE_TYPE = 4135;
/*   19:     */   public static final int AL_SOURCE_ABSOLUTE = 513;
/*   20:     */   public static final int AL_SOURCE_RELATIVE = 514;
/*   21:     */   public static final int AL_CONE_INNER_ANGLE = 4097;
/*   22:     */   public static final int AL_CONE_OUTER_ANGLE = 4098;
/*   23:     */   public static final int AL_PITCH = 4099;
/*   24:     */   public static final int AL_POSITION = 4100;
/*   25:     */   public static final int AL_DIRECTION = 4101;
/*   26:     */   public static final int AL_VELOCITY = 4102;
/*   27:     */   public static final int AL_LOOPING = 4103;
/*   28:     */   public static final int AL_BUFFER = 4105;
/*   29:     */   public static final int AL_GAIN = 4106;
/*   30:     */   public static final int AL_MIN_GAIN = 4109;
/*   31:     */   public static final int AL_MAX_GAIN = 4110;
/*   32:     */   public static final int AL_ORIENTATION = 4111;
/*   33:     */   public static final int AL_REFERENCE_DISTANCE = 4128;
/*   34:     */   public static final int AL_ROLLOFF_FACTOR = 4129;
/*   35:     */   public static final int AL_CONE_OUTER_GAIN = 4130;
/*   36:     */   public static final int AL_MAX_DISTANCE = 4131;
/*   37:     */   public static final int AL_CHANNEL_MASK = 12288;
/*   38:     */   public static final int AL_SOURCE_STATE = 4112;
/*   39:     */   public static final int AL_INITIAL = 4113;
/*   40:     */   public static final int AL_PLAYING = 4114;
/*   41:     */   public static final int AL_PAUSED = 4115;
/*   42:     */   public static final int AL_STOPPED = 4116;
/*   43:     */   public static final int AL_BUFFERS_QUEUED = 4117;
/*   44:     */   public static final int AL_BUFFERS_PROCESSED = 4118;
/*   45:     */   public static final int AL_FORMAT_MONO8 = 4352;
/*   46:     */   public static final int AL_FORMAT_MONO16 = 4353;
/*   47:     */   public static final int AL_FORMAT_STEREO8 = 4354;
/*   48:     */   public static final int AL_FORMAT_STEREO16 = 4355;
/*   49:     */   public static final int AL_FORMAT_VORBIS_EXT = 65539;
/*   50:     */   public static final int AL_FREQUENCY = 8193;
/*   51:     */   public static final int AL_BITS = 8194;
/*   52:     */   public static final int AL_CHANNELS = 8195;
/*   53:     */   public static final int AL_SIZE = 8196;
/*   54:     */   /**
/*   55:     */    * @deprecated
/*   56:     */    */
/*   57:     */   public static final int AL_DATA = 8197;
/*   58:     */   public static final int AL_UNUSED = 8208;
/*   59:     */   public static final int AL_PENDING = 8209;
/*   60:     */   public static final int AL_PROCESSED = 8210;
/*   61:     */   public static final int AL_NO_ERROR = 0;
/*   62:     */   public static final int AL_INVALID_NAME = 40961;
/*   63:     */   public static final int AL_INVALID_ENUM = 40962;
/*   64:     */   public static final int AL_INVALID_VALUE = 40963;
/*   65:     */   public static final int AL_INVALID_OPERATION = 40964;
/*   66:     */   public static final int AL_OUT_OF_MEMORY = 40965;
/*   67:     */   public static final int AL_VENDOR = 45057;
/*   68:     */   public static final int AL_VERSION = 45058;
/*   69:     */   public static final int AL_RENDERER = 45059;
/*   70:     */   public static final int AL_EXTENSIONS = 45060;
/*   71:     */   public static final int AL_DOPPLER_FACTOR = 49152;
/*   72:     */   public static final int AL_DOPPLER_VELOCITY = 49153;
/*   73:     */   public static final int AL_DISTANCE_MODEL = 53248;
/*   74:     */   public static final int AL_INVERSE_DISTANCE = 53249;
/*   75:     */   public static final int AL_INVERSE_DISTANCE_CLAMPED = 53250;
/*   76:     */   
/*   77:     */   static native void initNativeStubs()
/*   78:     */     throws LWJGLException;
/*   79:     */   
/*   80:     */   public static void alEnable(int capability)
/*   81:     */   {
/*   82: 341 */     nalEnable(capability);
/*   83:     */   }
/*   84:     */   
/*   85:     */   static native void nalEnable(int paramInt);
/*   86:     */   
/*   87:     */   public static void alDisable(int capability)
/*   88:     */   {
/*   89: 353 */     nalDisable(capability);
/*   90:     */   }
/*   91:     */   
/*   92:     */   static native void nalDisable(int paramInt);
/*   93:     */   
/*   94:     */   public static boolean alIsEnabled(int capability)
/*   95:     */   {
/*   96: 372 */     boolean __result = nalIsEnabled(capability);
/*   97: 373 */     return __result;
/*   98:     */   }
/*   99:     */   
/*  100:     */   static native boolean nalIsEnabled(int paramInt);
/*  101:     */   
/*  102:     */   public static boolean alGetBoolean(int pname)
/*  103:     */   {
/*  104: 391 */     boolean __result = nalGetBoolean(pname);
/*  105: 392 */     return __result;
/*  106:     */   }
/*  107:     */   
/*  108:     */   static native boolean nalGetBoolean(int paramInt);
/*  109:     */   
/*  110:     */   public static int alGetInteger(int pname)
/*  111:     */   {
/*  112: 410 */     int __result = nalGetInteger(pname);
/*  113: 411 */     return __result;
/*  114:     */   }
/*  115:     */   
/*  116:     */   static native int nalGetInteger(int paramInt);
/*  117:     */   
/*  118:     */   public static float alGetFloat(int pname)
/*  119:     */   {
/*  120: 429 */     float __result = nalGetFloat(pname);
/*  121: 430 */     return __result;
/*  122:     */   }
/*  123:     */   
/*  124:     */   static native float nalGetFloat(int paramInt);
/*  125:     */   
/*  126:     */   public static double alGetDouble(int pname)
/*  127:     */   {
/*  128: 448 */     double __result = nalGetDouble(pname);
/*  129: 449 */     return __result;
/*  130:     */   }
/*  131:     */   
/*  132:     */   static native double nalGetDouble(int paramInt);
/*  133:     */   
/*  134:     */   public static void alGetInteger(int pname, IntBuffer data)
/*  135:     */   {
/*  136: 468 */     BufferChecks.checkBuffer(data, 1);
/*  137: 469 */     nalGetIntegerv(pname, MemoryUtil.getAddress(data));
/*  138:     */   }
/*  139:     */   
/*  140:     */   static native void nalGetIntegerv(int paramInt, long paramLong);
/*  141:     */   
/*  142:     */   public static void alGetFloat(int pname, FloatBuffer data)
/*  143:     */   {
/*  144: 488 */     BufferChecks.checkBuffer(data, 1);
/*  145: 489 */     nalGetFloatv(pname, MemoryUtil.getAddress(data));
/*  146:     */   }
/*  147:     */   
/*  148:     */   static native void nalGetFloatv(int paramInt, long paramLong);
/*  149:     */   
/*  150:     */   public static void alGetDouble(int pname, DoubleBuffer data)
/*  151:     */   {
/*  152: 508 */     BufferChecks.checkBuffer(data, 1);
/*  153: 509 */     nalGetDoublev(pname, MemoryUtil.getAddress(data));
/*  154:     */   }
/*  155:     */   
/*  156:     */   static native void nalGetDoublev(int paramInt, long paramLong);
/*  157:     */   
/*  158:     */   public static String alGetString(int pname)
/*  159:     */   {
/*  160: 524 */     String __result = nalGetString(pname);
/*  161: 525 */     return __result;
/*  162:     */   }
/*  163:     */   
/*  164:     */   static native String nalGetString(int paramInt);
/*  165:     */   
/*  166:     */   public static int alGetError()
/*  167:     */   {
/*  168: 607 */     int __result = nalGetError();
/*  169: 608 */     return __result;
/*  170:     */   }
/*  171:     */   
/*  172:     */   static native int nalGetError();
/*  173:     */   
/*  174:     */   public static boolean alIsExtensionPresent(String fname)
/*  175:     */   {
/*  176: 624 */     BufferChecks.checkNotNull(fname);
/*  177: 625 */     boolean __result = nalIsExtensionPresent(fname);
/*  178: 626 */     return __result;
/*  179:     */   }
/*  180:     */   
/*  181:     */   static native boolean nalIsExtensionPresent(String paramString);
/*  182:     */   
/*  183:     */   public static int alGetEnumValue(String ename)
/*  184:     */   {
/*  185: 649 */     BufferChecks.checkNotNull(ename);
/*  186: 650 */     int __result = nalGetEnumValue(ename);
/*  187: 651 */     return __result;
/*  188:     */   }
/*  189:     */   
/*  190:     */   static native int nalGetEnumValue(String paramString);
/*  191:     */   
/*  192:     */   public static void alListeneri(int pname, int value)
/*  193:     */   {
/*  194: 662 */     nalListeneri(pname, value);
/*  195:     */   }
/*  196:     */   
/*  197:     */   static native void nalListeneri(int paramInt1, int paramInt2);
/*  198:     */   
/*  199:     */   public static void alListenerf(int pname, float value)
/*  200:     */   {
/*  201: 673 */     nalListenerf(pname, value);
/*  202:     */   }
/*  203:     */   
/*  204:     */   static native void nalListenerf(int paramInt, float paramFloat);
/*  205:     */   
/*  206:     */   public static void alListener(int pname, FloatBuffer value)
/*  207:     */   {
/*  208: 684 */     BufferChecks.checkBuffer(value, 1);
/*  209: 685 */     nalListenerfv(pname, MemoryUtil.getAddress(value));
/*  210:     */   }
/*  211:     */   
/*  212:     */   static native void nalListenerfv(int paramInt, long paramLong);
/*  213:     */   
/*  214:     */   public static void alListener3f(int pname, float v1, float v2, float v3)
/*  215:     */   {
/*  216: 698 */     nalListener3f(pname, v1, v2, v3);
/*  217:     */   }
/*  218:     */   
/*  219:     */   static native void nalListener3f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3);
/*  220:     */   
/*  221:     */   public static int alGetListeneri(int pname)
/*  222:     */   {
/*  223: 710 */     int __result = nalGetListeneri(pname);
/*  224: 711 */     return __result;
/*  225:     */   }
/*  226:     */   
/*  227:     */   static native int nalGetListeneri(int paramInt);
/*  228:     */   
/*  229:     */   public static float alGetListenerf(int pname)
/*  230:     */   {
/*  231: 723 */     float __result = nalGetListenerf(pname);
/*  232: 724 */     return __result;
/*  233:     */   }
/*  234:     */   
/*  235:     */   static native float nalGetListenerf(int paramInt);
/*  236:     */   
/*  237:     */   public static void alGetListener(int pname, FloatBuffer floatdata)
/*  238:     */   {
/*  239: 736 */     BufferChecks.checkBuffer(floatdata, 1);
/*  240: 737 */     nalGetListenerfv(pname, MemoryUtil.getAddress(floatdata));
/*  241:     */   }
/*  242:     */   
/*  243:     */   static native void nalGetListenerfv(int paramInt, long paramLong);
/*  244:     */   
/*  245:     */   public static void alGenSources(IntBuffer sources)
/*  246:     */   {
/*  247: 747 */     BufferChecks.checkDirect(sources);
/*  248: 748 */     nalGenSources(sources.remaining(), MemoryUtil.getAddress(sources));
/*  249:     */   }
/*  250:     */   
/*  251:     */   static native void nalGenSources(int paramInt, long paramLong);
/*  252:     */   
/*  253:     */   public static int alGenSources()
/*  254:     */   {
/*  255: 754 */     int __result = nalGenSources2(1);
/*  256: 755 */     return __result;
/*  257:     */   }
/*  258:     */   
/*  259:     */   static native int nalGenSources2(int paramInt);
/*  260:     */   
/*  261:     */   public static void alDeleteSources(IntBuffer sources)
/*  262:     */   {
/*  263: 765 */     BufferChecks.checkDirect(sources);
/*  264: 766 */     nalDeleteSources(sources.remaining(), MemoryUtil.getAddress(sources));
/*  265:     */   }
/*  266:     */   
/*  267:     */   static native void nalDeleteSources(int paramInt, long paramLong);
/*  268:     */   
/*  269:     */   public static void alDeleteSources(int source)
/*  270:     */   {
/*  271: 772 */     nalDeleteSources2(1, source);
/*  272:     */   }
/*  273:     */   
/*  274:     */   static native void nalDeleteSources2(int paramInt1, int paramInt2);
/*  275:     */   
/*  276:     */   public static boolean alIsSource(int id)
/*  277:     */   {
/*  278: 783 */     boolean __result = nalIsSource(id);
/*  279: 784 */     return __result;
/*  280:     */   }
/*  281:     */   
/*  282:     */   static native boolean nalIsSource(int paramInt);
/*  283:     */   
/*  284:     */   public static void alSourcei(int source, int pname, int value)
/*  285:     */   {
/*  286: 797 */     nalSourcei(source, pname, value);
/*  287:     */   }
/*  288:     */   
/*  289:     */   static native void nalSourcei(int paramInt1, int paramInt2, int paramInt3);
/*  290:     */   
/*  291:     */   public static void alSourcef(int source, int pname, float value)
/*  292:     */   {
/*  293: 810 */     nalSourcef(source, pname, value);
/*  294:     */   }
/*  295:     */   
/*  296:     */   static native void nalSourcef(int paramInt1, int paramInt2, float paramFloat);
/*  297:     */   
/*  298:     */   public static void alSource(int source, int pname, FloatBuffer value)
/*  299:     */   {
/*  300: 823 */     BufferChecks.checkBuffer(value, 1);
/*  301: 824 */     nalSourcefv(source, pname, MemoryUtil.getAddress(value));
/*  302:     */   }
/*  303:     */   
/*  304:     */   static native void nalSourcefv(int paramInt1, int paramInt2, long paramLong);
/*  305:     */   
/*  306:     */   public static void alSource3f(int source, int pname, float v1, float v2, float v3)
/*  307:     */   {
/*  308: 839 */     nalSource3f(source, pname, v1, v2, v3);
/*  309:     */   }
/*  310:     */   
/*  311:     */   static native void nalSource3f(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3);
/*  312:     */   
/*  313:     */   public static int alGetSourcei(int source, int pname)
/*  314:     */   {
/*  315: 853 */     int __result = nalGetSourcei(source, pname);
/*  316: 854 */     return __result;
/*  317:     */   }
/*  318:     */   
/*  319:     */   static native int nalGetSourcei(int paramInt1, int paramInt2);
/*  320:     */   
/*  321:     */   public static float alGetSourcef(int source, int pname)
/*  322:     */   {
/*  323: 868 */     float __result = nalGetSourcef(source, pname);
/*  324: 869 */     return __result;
/*  325:     */   }
/*  326:     */   
/*  327:     */   static native float nalGetSourcef(int paramInt1, int paramInt2);
/*  328:     */   
/*  329:     */   public static void alGetSource(int source, int pname, FloatBuffer floatdata)
/*  330:     */   {
/*  331: 883 */     BufferChecks.checkBuffer(floatdata, 1);
/*  332: 884 */     nalGetSourcefv(source, pname, MemoryUtil.getAddress(floatdata));
/*  333:     */   }
/*  334:     */   
/*  335:     */   static native void nalGetSourcefv(int paramInt1, int paramInt2, long paramLong);
/*  336:     */   
/*  337:     */   public static void alSourcePlay(IntBuffer sources)
/*  338:     */   {
/*  339: 901 */     BufferChecks.checkDirect(sources);
/*  340: 902 */     nalSourcePlayv(sources.remaining(), MemoryUtil.getAddress(sources));
/*  341:     */   }
/*  342:     */   
/*  343:     */   static native void nalSourcePlayv(int paramInt, long paramLong);
/*  344:     */   
/*  345:     */   public static void alSourcePause(IntBuffer sources)
/*  346:     */   {
/*  347: 915 */     BufferChecks.checkDirect(sources);
/*  348: 916 */     nalSourcePausev(sources.remaining(), MemoryUtil.getAddress(sources));
/*  349:     */   }
/*  350:     */   
/*  351:     */   static native void nalSourcePausev(int paramInt, long paramLong);
/*  352:     */   
/*  353:     */   public static void alSourceStop(IntBuffer sources)
/*  354:     */   {
/*  355: 930 */     BufferChecks.checkDirect(sources);
/*  356: 931 */     nalSourceStopv(sources.remaining(), MemoryUtil.getAddress(sources));
/*  357:     */   }
/*  358:     */   
/*  359:     */   static native void nalSourceStopv(int paramInt, long paramLong);
/*  360:     */   
/*  361:     */   public static void alSourceRewind(IntBuffer sources)
/*  362:     */   {
/*  363: 947 */     BufferChecks.checkDirect(sources);
/*  364: 948 */     nalSourceRewindv(sources.remaining(), MemoryUtil.getAddress(sources));
/*  365:     */   }
/*  366:     */   
/*  367:     */   static native void nalSourceRewindv(int paramInt, long paramLong);
/*  368:     */   
/*  369:     */   public static void alSourcePlay(int source)
/*  370:     */   {
/*  371: 965 */     nalSourcePlay(source);
/*  372:     */   }
/*  373:     */   
/*  374:     */   static native void nalSourcePlay(int paramInt);
/*  375:     */   
/*  376:     */   public static void alSourcePause(int source)
/*  377:     */   {
/*  378: 978 */     nalSourcePause(source);
/*  379:     */   }
/*  380:     */   
/*  381:     */   static native void nalSourcePause(int paramInt);
/*  382:     */   
/*  383:     */   public static void alSourceStop(int source)
/*  384:     */   {
/*  385: 992 */     nalSourceStop(source);
/*  386:     */   }
/*  387:     */   
/*  388:     */   static native void nalSourceStop(int paramInt);
/*  389:     */   
/*  390:     */   public static void alSourceRewind(int source)
/*  391:     */   {
/*  392:1008 */     nalSourceRewind(source);
/*  393:     */   }
/*  394:     */   
/*  395:     */   static native void nalSourceRewind(int paramInt);
/*  396:     */   
/*  397:     */   public static void alGenBuffers(IntBuffer buffers)
/*  398:     */   {
/*  399:1018 */     BufferChecks.checkDirect(buffers);
/*  400:1019 */     nalGenBuffers(buffers.remaining(), MemoryUtil.getAddress(buffers));
/*  401:     */   }
/*  402:     */   
/*  403:     */   static native void nalGenBuffers(int paramInt, long paramLong);
/*  404:     */   
/*  405:     */   public static int alGenBuffers()
/*  406:     */   {
/*  407:1025 */     int __result = nalGenBuffers2(1);
/*  408:1026 */     return __result;
/*  409:     */   }
/*  410:     */   
/*  411:     */   static native int nalGenBuffers2(int paramInt);
/*  412:     */   
/*  413:     */   public static void alDeleteBuffers(IntBuffer buffers)
/*  414:     */   {
/*  415:1047 */     BufferChecks.checkDirect(buffers);
/*  416:1048 */     nalDeleteBuffers(buffers.remaining(), MemoryUtil.getAddress(buffers));
/*  417:     */   }
/*  418:     */   
/*  419:     */   static native void nalDeleteBuffers(int paramInt, long paramLong);
/*  420:     */   
/*  421:     */   public static void alDeleteBuffers(int buffer)
/*  422:     */   {
/*  423:1054 */     nalDeleteBuffers2(1, buffer);
/*  424:     */   }
/*  425:     */   
/*  426:     */   static native void nalDeleteBuffers2(int paramInt1, int paramInt2);
/*  427:     */   
/*  428:     */   public static boolean alIsBuffer(int buffer)
/*  429:     */   {
/*  430:1065 */     boolean __result = nalIsBuffer(buffer);
/*  431:1066 */     return __result;
/*  432:     */   }
/*  433:     */   
/*  434:     */   static native boolean nalIsBuffer(int paramInt);
/*  435:     */   
/*  436:     */   public static void alBufferData(int buffer, int format, ByteBuffer data, int freq)
/*  437:     */   {
/*  438:1098 */     BufferChecks.checkDirect(data);
/*  439:1099 */     nalBufferData(buffer, format, MemoryUtil.getAddress(data), data.remaining(), freq);
/*  440:     */   }
/*  441:     */   
/*  442:     */   public static void alBufferData(int buffer, int format, IntBuffer data, int freq)
/*  443:     */   {
/*  444:1129 */     BufferChecks.checkDirect(data);
/*  445:1130 */     nalBufferData(buffer, format, MemoryUtil.getAddress(data), data.remaining() << 2, freq);
/*  446:     */   }
/*  447:     */   
/*  448:     */   public static void alBufferData(int buffer, int format, ShortBuffer data, int freq)
/*  449:     */   {
/*  450:1160 */     BufferChecks.checkDirect(data);
/*  451:1161 */     nalBufferData(buffer, format, MemoryUtil.getAddress(data), data.remaining() << 1, freq);
/*  452:     */   }
/*  453:     */   
/*  454:     */   static native void nalBufferData(int paramInt1, int paramInt2, long paramLong, int paramInt3, int paramInt4);
/*  455:     */   
/*  456:     */   public static int alGetBufferi(int buffer, int pname)
/*  457:     */   {
/*  458:1174 */     int __result = nalGetBufferi(buffer, pname);
/*  459:1175 */     return __result;
/*  460:     */   }
/*  461:     */   
/*  462:     */   static native int nalGetBufferi(int paramInt1, int paramInt2);
/*  463:     */   
/*  464:     */   public static float alGetBufferf(int buffer, int pname)
/*  465:     */   {
/*  466:1189 */     float __result = nalGetBufferf(buffer, pname);
/*  467:1190 */     return __result;
/*  468:     */   }
/*  469:     */   
/*  470:     */   static native float nalGetBufferf(int paramInt1, int paramInt2);
/*  471:     */   
/*  472:     */   public static void alSourceQueueBuffers(int source, IntBuffer buffers)
/*  473:     */   {
/*  474:1210 */     BufferChecks.checkDirect(buffers);
/*  475:1211 */     nalSourceQueueBuffers(source, buffers.remaining(), MemoryUtil.getAddress(buffers));
/*  476:     */   }
/*  477:     */   
/*  478:     */   static native void nalSourceQueueBuffers(int paramInt1, int paramInt2, long paramLong);
/*  479:     */   
/*  480:     */   public static void alSourceQueueBuffers(int source, int buffer)
/*  481:     */   {
/*  482:1217 */     nalSourceQueueBuffers2(source, 1, buffer);
/*  483:     */   }
/*  484:     */   
/*  485:     */   static native void nalSourceQueueBuffers2(int paramInt1, int paramInt2, int paramInt3);
/*  486:     */   
/*  487:     */   public static void alSourceUnqueueBuffers(int source, IntBuffer buffers)
/*  488:     */   {
/*  489:1241 */     BufferChecks.checkDirect(buffers);
/*  490:1242 */     nalSourceUnqueueBuffers(source, buffers.remaining(), MemoryUtil.getAddress(buffers));
/*  491:     */   }
/*  492:     */   
/*  493:     */   static native void nalSourceUnqueueBuffers(int paramInt1, int paramInt2, long paramLong);
/*  494:     */   
/*  495:     */   public static int alSourceUnqueueBuffers(int source)
/*  496:     */   {
/*  497:1248 */     int __result = nalSourceUnqueueBuffers2(source, 1);
/*  498:1249 */     return __result;
/*  499:     */   }
/*  500:     */   
/*  501:     */   static native int nalSourceUnqueueBuffers2(int paramInt1, int paramInt2);
/*  502:     */   
/*  503:     */   public static void alDistanceModel(int value)
/*  504:     */   {
/*  505:1303 */     nalDistanceModel(value);
/*  506:     */   }
/*  507:     */   
/*  508:     */   static native void nalDistanceModel(int paramInt);
/*  509:     */   
/*  510:     */   public static void alDopplerFactor(float value)
/*  511:     */   {
/*  512:1360 */     nalDopplerFactor(value);
/*  513:     */   }
/*  514:     */   
/*  515:     */   static native void nalDopplerFactor(float paramFloat);
/*  516:     */   
/*  517:     */   public static void alDopplerVelocity(float value)
/*  518:     */   {
/*  519:1417 */     nalDopplerVelocity(value);
/*  520:     */   }
/*  521:     */   
/*  522:     */   static native void nalDopplerVelocity(float paramFloat);
/*  523:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.AL10
 * JD-Core Version:    0.7.0.1
 */