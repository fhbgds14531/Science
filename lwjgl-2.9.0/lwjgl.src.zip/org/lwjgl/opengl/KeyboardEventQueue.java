/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.event.KeyEvent;
/*   5:    */ import java.awt.event.KeyListener;
/*   6:    */ import java.nio.ByteBuffer;
/*   7:    */ 
/*   8:    */ final class KeyboardEventQueue
/*   9:    */   extends EventQueue
/*  10:    */   implements KeyListener
/*  11:    */ {
/*  12: 47 */   private static final int[] KEY_MAP = new int[65535];
/*  13: 49 */   private final byte[] key_states = new byte[256];
/*  14: 52 */   private final ByteBuffer event = ByteBuffer.allocate(18);
/*  15:    */   private final Component component;
/*  16:    */   private boolean has_deferred_event;
/*  17:    */   private long deferred_nanos;
/*  18:    */   private int deferred_key_code;
/*  19:    */   private int deferred_key_location;
/*  20:    */   private byte deferred_key_state;
/*  21:    */   private int deferred_character;
/*  22:    */   
/*  23:    */   static
/*  24:    */   {
/*  25: 64 */     KEY_MAP[48] = 11;
/*  26: 65 */     KEY_MAP[49] = 2;
/*  27: 66 */     KEY_MAP[50] = 3;
/*  28: 67 */     KEY_MAP[51] = 4;
/*  29: 68 */     KEY_MAP[52] = 5;
/*  30: 69 */     KEY_MAP[53] = 6;
/*  31: 70 */     KEY_MAP[54] = 7;
/*  32: 71 */     KEY_MAP[55] = 8;
/*  33: 72 */     KEY_MAP[56] = 9;
/*  34: 73 */     KEY_MAP[57] = 10;
/*  35: 74 */     KEY_MAP[65] = 30;
/*  36:    */     
/*  37: 76 */     KEY_MAP[107] = 78;
/*  38:    */     
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42: 81 */     KEY_MAP[65406] = 184;
/*  43:    */     
/*  44:    */ 
/*  45: 84 */     KEY_MAP[512] = 145;
/*  46: 85 */     KEY_MAP[66] = 48;
/*  47:    */     
/*  48: 87 */     KEY_MAP[92] = 43;
/*  49: 88 */     KEY_MAP[8] = 14;
/*  50:    */     
/*  51:    */ 
/*  52: 91 */     KEY_MAP[67] = 46;
/*  53:    */     
/*  54: 93 */     KEY_MAP[20] = 58;
/*  55: 94 */     KEY_MAP[514] = 144;
/*  56:    */     
/*  57: 96 */     KEY_MAP[93] = 27;
/*  58:    */     
/*  59: 98 */     KEY_MAP[513] = 146;
/*  60: 99 */     KEY_MAP[44] = 51;
/*  61:    */     
/*  62:    */ 
/*  63:102 */     KEY_MAP[28] = 121;
/*  64:    */     
/*  65:    */ 
/*  66:105 */     KEY_MAP[68] = 32;
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:122 */     KEY_MAP[110] = 83;
/*  84:123 */     KEY_MAP[127] = 211;
/*  85:124 */     KEY_MAP[111] = 181;
/*  86:    */     
/*  87:126 */     KEY_MAP[40] = 208;
/*  88:127 */     KEY_MAP[69] = 18;
/*  89:128 */     KEY_MAP[35] = 207;
/*  90:129 */     KEY_MAP[10] = 28;
/*  91:130 */     KEY_MAP[61] = 13;
/*  92:131 */     KEY_MAP[27] = 1;
/*  93:    */     
/*  94:    */ 
/*  95:134 */     KEY_MAP[70] = 33;
/*  96:135 */     KEY_MAP[112] = 59;
/*  97:136 */     KEY_MAP[121] = 68;
/*  98:137 */     KEY_MAP[122] = 87;
/*  99:138 */     KEY_MAP[123] = 88;
/* 100:139 */     KEY_MAP[61440] = 100;
/* 101:140 */     KEY_MAP[61441] = 101;
/* 102:141 */     KEY_MAP[61442] = 102;
/* 103:    */     
/* 104:    */ 
/* 105:    */ 
/* 106:    */ 
/* 107:146 */     KEY_MAP[113] = 60;
/* 108:    */     
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:152 */     KEY_MAP[114] = 61;
/* 114:153 */     KEY_MAP[115] = 62;
/* 115:154 */     KEY_MAP[116] = 63;
/* 116:155 */     KEY_MAP[117] = 64;
/* 117:156 */     KEY_MAP[118] = 65;
/* 118:157 */     KEY_MAP[119] = 66;
/* 119:158 */     KEY_MAP[120] = 67;
/* 120:    */     
/* 121:    */ 
/* 122:    */ 
/* 123:162 */     KEY_MAP[71] = 34;
/* 124:    */     
/* 125:164 */     KEY_MAP[72] = 35;
/* 126:    */     
/* 127:    */ 
/* 128:    */ 
/* 129:168 */     KEY_MAP[36] = 199;
/* 130:169 */     KEY_MAP[73] = 23;
/* 131:    */     
/* 132:171 */     KEY_MAP[''] = 210;
/* 133:    */     
/* 134:173 */     KEY_MAP[74] = 36;
/* 135:    */     
/* 136:    */ 
/* 137:    */ 
/* 138:177 */     KEY_MAP[75] = 37;
/* 139:178 */     KEY_MAP[21] = 112;
/* 140:    */     
/* 141:180 */     KEY_MAP[25] = 148;
/* 142:    */     
/* 143:    */ 
/* 144:    */ 
/* 145:    */ 
/* 146:    */ 
/* 147:186 */     KEY_MAP[76] = 38;
/* 148:187 */     KEY_MAP[37] = 203;
/* 149:    */     
/* 150:    */ 
/* 151:190 */     KEY_MAP[77] = 50;
/* 152:    */     
/* 153:192 */     KEY_MAP[45] = 12;
/* 154:    */     
/* 155:194 */     KEY_MAP[106] = 55;
/* 156:195 */     KEY_MAP[78] = 49;
/* 157:    */     
/* 158:197 */     KEY_MAP[''] = 69;
/* 159:    */     
/* 160:199 */     KEY_MAP[96] = 82;
/* 161:200 */     KEY_MAP[97] = 79;
/* 162:201 */     KEY_MAP[98] = 80;
/* 163:202 */     KEY_MAP[99] = 81;
/* 164:203 */     KEY_MAP[100] = 75;
/* 165:204 */     KEY_MAP[101] = 76;
/* 166:205 */     KEY_MAP[102] = 77;
/* 167:206 */     KEY_MAP[103] = 71;
/* 168:207 */     KEY_MAP[104] = 72;
/* 169:208 */     KEY_MAP[105] = 73;
/* 170:209 */     KEY_MAP[79] = 24;
/* 171:210 */     KEY_MAP[91] = 26;
/* 172:211 */     KEY_MAP[80] = 25;
/* 173:212 */     KEY_MAP[34] = 209;
/* 174:213 */     KEY_MAP[33] = 201;
/* 175:    */     
/* 176:215 */     KEY_MAP[19] = 197;
/* 177:216 */     KEY_MAP[46] = 52;
/* 178:    */     
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:221 */     KEY_MAP[81] = 16;
/* 183:    */     
/* 184:    */ 
/* 185:224 */     KEY_MAP[82] = 19;
/* 186:225 */     KEY_MAP[39] = 205;
/* 187:    */     
/* 188:    */ 
/* 189:228 */     KEY_MAP[83] = 31;
/* 190:229 */     KEY_MAP[''] = 70;
/* 191:230 */     KEY_MAP[59] = 39;
/* 192:231 */     KEY_MAP[108] = 83;
/* 193:    */     
/* 194:233 */     KEY_MAP[47] = 53;
/* 195:234 */     KEY_MAP[32] = 57;
/* 196:235 */     KEY_MAP[65480] = 149;
/* 197:236 */     KEY_MAP[109] = 74;
/* 198:237 */     KEY_MAP[84] = 20;
/* 199:238 */     KEY_MAP[9] = 15;
/* 200:239 */     KEY_MAP[85] = 22;
/* 201:    */     
/* 202:    */ 
/* 203:242 */     KEY_MAP[38] = 200;
/* 204:243 */     KEY_MAP[86] = 47;
/* 205:244 */     KEY_MAP[87] = 17;
/* 206:245 */     KEY_MAP[88] = 45;
/* 207:246 */     KEY_MAP[89] = 21;
/* 208:247 */     KEY_MAP[90] = 44;
/* 209:    */   }
/* 210:    */   
/* 211:    */   KeyboardEventQueue(Component component)
/* 212:    */   {
/* 213:251 */     super(18);
/* 214:252 */     this.component = component;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public void register()
/* 218:    */   {
/* 219:256 */     this.component.addKeyListener(this);
/* 220:    */   }
/* 221:    */   
/* 222:    */   private void putKeyboardEvent(int key_code, byte state, int character, long nanos, boolean repeat)
/* 223:    */   {
/* 224:268 */     this.event.clear();
/* 225:269 */     this.event.putInt(key_code).put(state).putInt(character).putLong(nanos).put((byte)(repeat ? 1 : 0));
/* 226:270 */     this.event.flip();
/* 227:271 */     putEvent(this.event);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public synchronized void poll(ByteBuffer key_down_buffer)
/* 231:    */   {
/* 232:275 */     flushDeferredEvent();
/* 233:276 */     int old_position = key_down_buffer.position();
/* 234:277 */     key_down_buffer.put(this.key_states);
/* 235:278 */     key_down_buffer.position(old_position);
/* 236:    */   }
/* 237:    */   
/* 238:    */   public synchronized void copyEvents(ByteBuffer dest)
/* 239:    */   {
/* 240:282 */     flushDeferredEvent();
/* 241:283 */     super.copyEvents(dest);
/* 242:    */   }
/* 243:    */   
/* 244:    */   private synchronized void handleKey(int key_code, int key_location, byte state, int character, long nanos)
/* 245:    */   {
/* 246:287 */     if (character == 65535) {
/* 247:288 */       character = 0;
/* 248:    */     }
/* 249:289 */     if (state == 1)
/* 250:    */     {
/* 251:290 */       boolean repeat = false;
/* 252:291 */       if (this.has_deferred_event) {
/* 253:292 */         if ((nanos == this.deferred_nanos) && (this.deferred_key_code == key_code) && (this.deferred_key_location == key_location))
/* 254:    */         {
/* 255:294 */           this.has_deferred_event = false;
/* 256:295 */           repeat = true;
/* 257:    */         }
/* 258:    */         else
/* 259:    */         {
/* 260:297 */           flushDeferredEvent();
/* 261:    */         }
/* 262:    */       }
/* 263:299 */       putKeyEvent(key_code, key_location, state, character, nanos, repeat);
/* 264:    */     }
/* 265:    */     else
/* 266:    */     {
/* 267:301 */       flushDeferredEvent();
/* 268:302 */       this.has_deferred_event = true;
/* 269:303 */       this.deferred_nanos = nanos;
/* 270:304 */       this.deferred_key_code = key_code;
/* 271:305 */       this.deferred_key_location = key_location;
/* 272:306 */       this.deferred_key_state = state;
/* 273:307 */       this.deferred_character = character;
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   private void flushDeferredEvent()
/* 278:    */   {
/* 279:312 */     if (this.has_deferred_event)
/* 280:    */     {
/* 281:313 */       putKeyEvent(this.deferred_key_code, this.deferred_key_location, this.deferred_key_state, this.deferred_character, this.deferred_nanos, false);
/* 282:314 */       this.has_deferred_event = false;
/* 283:    */     }
/* 284:    */   }
/* 285:    */   
/* 286:    */   private void putKeyEvent(int key_code, int key_location, byte state, int character, long nanos, boolean repeat)
/* 287:    */   {
/* 288:319 */     int key_code_mapped = getMappedKeyCode(key_code, key_location);
/* 289:321 */     if (this.key_states[key_code_mapped] == state) {
/* 290:322 */       repeat = true;
/* 291:    */     }
/* 292:323 */     this.key_states[key_code_mapped] = state;
/* 293:324 */     int key_int_char = character & 0xFFFF;
/* 294:325 */     putKeyboardEvent(key_code_mapped, state, key_int_char, nanos, repeat);
/* 295:    */   }
/* 296:    */   
/* 297:    */   private int getMappedKeyCode(int key_code, int position)
/* 298:    */   {
/* 299:330 */     switch (key_code)
/* 300:    */     {
/* 301:    */     case 18: 
/* 302:332 */       if (position == 3) {
/* 303:333 */         return 184;
/* 304:    */       }
/* 305:335 */       return 56;
/* 306:    */     case 157: 
/* 307:337 */       if (position == 3) {
/* 308:338 */         return 220;
/* 309:    */       }
/* 310:340 */       return 219;
/* 311:    */     case 16: 
/* 312:342 */       if (position == 3) {
/* 313:343 */         return 54;
/* 314:    */       }
/* 315:345 */       return 42;
/* 316:    */     case 17: 
/* 317:347 */       if (position == 3) {
/* 318:348 */         return 157;
/* 319:    */       }
/* 320:350 */       return 29;
/* 321:    */     }
/* 322:352 */     return KEY_MAP[key_code];
/* 323:    */   }
/* 324:    */   
/* 325:    */   public void keyPressed(KeyEvent e)
/* 326:    */   {
/* 327:357 */     handleKey(e.getKeyCode(), e.getKeyLocation(), (byte)1, e.getKeyChar(), e.getWhen() * 1000000L);
/* 328:    */   }
/* 329:    */   
/* 330:    */   public void keyReleased(KeyEvent e)
/* 331:    */   {
/* 332:361 */     handleKey(e.getKeyCode(), e.getKeyLocation(), (byte)0, 0, e.getWhen() * 1000000L);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public void unregister() {}
/* 336:    */   
/* 337:    */   public void keyTyped(KeyEvent e) {}
/* 338:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.KeyboardEventQueue
 * JD-Core Version:    0.7.0.1
 */