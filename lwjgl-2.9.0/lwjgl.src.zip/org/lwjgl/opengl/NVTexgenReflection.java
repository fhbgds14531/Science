package org.lwjgl.opengl;

public final class NVTexgenReflection
{
  public static final int GL_NORMAL_MAP_NV = 34065;
  public static final int GL_REFLECTION_MAP_NV = 34066;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTexgenReflection
 * JD-Core Version:    0.7.0.1
 */