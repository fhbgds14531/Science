package org.lwjgl.opengl;

public final class NVTextureExpandNormal
{
  public static final int GL_TEXTURE_UNSIGNED_REMAP_MODE_NV = 34959;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTextureExpandNormal
 * JD-Core Version:    0.7.0.1
 */