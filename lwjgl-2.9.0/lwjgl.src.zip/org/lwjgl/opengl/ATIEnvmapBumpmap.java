/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class ATIEnvmapBumpmap
/*  9:   */ {
/* 10:   */   public static final int GL_BUMP_ROT_MATRIX_ATI = 34677;
/* 11:   */   public static final int GL_BUMP_ROT_MATRIX_SIZE_ATI = 34678;
/* 12:   */   public static final int GL_BUMP_NUM_TEX_UNITS_ATI = 34679;
/* 13:   */   public static final int GL_BUMP_TEX_UNITS_ATI = 34680;
/* 14:   */   public static final int GL_DUDV_ATI = 34681;
/* 15:   */   public static final int GL_DU8DV8_ATI = 34682;
/* 16:   */   public static final int GL_BUMP_ENVMAP_ATI = 34683;
/* 17:   */   public static final int GL_BUMP_TARGET_ATI = 34684;
/* 18:   */   
/* 19:   */   public static void glTexBumpParameterATI(int pname, FloatBuffer param)
/* 20:   */   {
/* 21:22 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 22:23 */     long function_pointer = caps.glTexBumpParameterfvATI;
/* 23:24 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 24:25 */     BufferChecks.checkBuffer(param, 4);
/* 25:26 */     nglTexBumpParameterfvATI(pname, MemoryUtil.getAddress(param), function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglTexBumpParameterfvATI(int paramInt, long paramLong1, long paramLong2);
/* 29:   */   
/* 30:   */   public static void glTexBumpParameterATI(int pname, IntBuffer param)
/* 31:   */   {
/* 32:31 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:32 */     long function_pointer = caps.glTexBumpParameterivATI;
/* 34:33 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:34 */     BufferChecks.checkBuffer(param, 4);
/* 36:35 */     nglTexBumpParameterivATI(pname, MemoryUtil.getAddress(param), function_pointer);
/* 37:   */   }
/* 38:   */   
/* 39:   */   static native void nglTexBumpParameterivATI(int paramInt, long paramLong1, long paramLong2);
/* 40:   */   
/* 41:   */   public static void glGetTexBumpParameterATI(int pname, FloatBuffer param)
/* 42:   */   {
/* 43:40 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 44:41 */     long function_pointer = caps.glGetTexBumpParameterfvATI;
/* 45:42 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 46:43 */     BufferChecks.checkBuffer(param, 4);
/* 47:44 */     nglGetTexBumpParameterfvATI(pname, MemoryUtil.getAddress(param), function_pointer);
/* 48:   */   }
/* 49:   */   
/* 50:   */   static native void nglGetTexBumpParameterfvATI(int paramInt, long paramLong1, long paramLong2);
/* 51:   */   
/* 52:   */   public static void glGetTexBumpParameterATI(int pname, IntBuffer param)
/* 53:   */   {
/* 54:49 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 55:50 */     long function_pointer = caps.glGetTexBumpParameterivATI;
/* 56:51 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 57:52 */     BufferChecks.checkBuffer(param, 4);
/* 58:53 */     nglGetTexBumpParameterivATI(pname, MemoryUtil.getAddress(param), function_pointer);
/* 59:   */   }
/* 60:   */   
/* 61:   */   static native void nglGetTexBumpParameterivATI(int paramInt, long paramLong1, long paramLong2);
/* 62:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIEnvmapBumpmap
 * JD-Core Version:    0.7.0.1
 */