/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.awt.Canvas;
/*    4:     */ import java.awt.event.ComponentAdapter;
/*    5:     */ import java.awt.event.ComponentEvent;
/*    6:     */ import java.awt.event.ComponentListener;
/*    7:     */ import java.nio.ByteBuffer;
/*    8:     */ import java.nio.FloatBuffer;
/*    9:     */ import java.security.AccessController;
/*   10:     */ import java.security.PrivilegedAction;
/*   11:     */ import java.util.Arrays;
/*   12:     */ import java.util.HashSet;
/*   13:     */ import org.lwjgl.BufferUtils;
/*   14:     */ import org.lwjgl.LWJGLException;
/*   15:     */ import org.lwjgl.LWJGLUtil;
/*   16:     */ import org.lwjgl.Sys;
/*   17:     */ import org.lwjgl.input.Controllers;
/*   18:     */ import org.lwjgl.input.Keyboard;
/*   19:     */ import org.lwjgl.input.Mouse;
/*   20:     */ 
/*   21:     */ public final class Display
/*   22:     */ {
/*   23:  67 */   private static final Thread shutdown_hook = new Thread()
/*   24:     */   {
/*   25:     */     public void run() {}
/*   26:     */   };
/*   27:     */   private static final DisplayImplementation display_impl;
/*   28:     */   private static final DisplayMode initial_mode;
/*   29:     */   private static Canvas parent;
/*   30:     */   private static DisplayMode current_mode;
/*   31:  86 */   private static int x = -1;
/*   32:     */   private static ByteBuffer[] cached_icons;
/*   33:  95 */   private static int y = -1;
/*   34:  98 */   private static int width = 0;
/*   35: 101 */   private static int height = 0;
/*   36: 104 */   private static String title = "Game";
/*   37:     */   private static boolean fullscreen;
/*   38:     */   private static int swap_interval;
/*   39:     */   private static DrawableLWJGL drawable;
/*   40:     */   private static boolean window_created;
/*   41:     */   private static boolean parent_resized;
/*   42:     */   private static boolean window_resized;
/*   43:     */   private static boolean window_resizable;
/*   44:     */   private static float r;
/*   45:     */   private static float g;
/*   46:     */   private static float b;
/*   47: 126 */   private static final ComponentListener component_listener = new ComponentAdapter()
/*   48:     */   {
/*   49:     */     public void componentResized(ComponentEvent e)
/*   50:     */     {
/*   51: 128 */       synchronized (GlobalLock.lock)
/*   52:     */       {
/*   53: 129 */         Display.access$102(true);
/*   54:     */       }
/*   55:     */     }
/*   56:     */   };
/*   57:     */   
/*   58:     */   static
/*   59:     */   {
/*   60: 135 */     Sys.initialize();
/*   61: 136 */     display_impl = createDisplayImplementation();
/*   62:     */     try
/*   63:     */     {
/*   64: 138 */       current_mode = Display.initial_mode = display_impl.init();
/*   65: 139 */       LWJGLUtil.log("Initial mode: " + initial_mode);
/*   66:     */     }
/*   67:     */     catch (LWJGLException e)
/*   68:     */     {
/*   69: 141 */       throw new RuntimeException(e);
/*   70:     */     }
/*   71:     */   }
/*   72:     */   
/*   73:     */   public static Drawable getDrawable()
/*   74:     */   {
/*   75: 151 */     return drawable;
/*   76:     */   }
/*   77:     */   
/*   78:     */   private static DisplayImplementation createDisplayImplementation()
/*   79:     */   {
/*   80: 155 */     switch ()
/*   81:     */     {
/*   82:     */     case 1: 
/*   83: 157 */       return new LinuxDisplay();
/*   84:     */     case 3: 
/*   85: 159 */       return new WindowsDisplay();
/*   86:     */     case 2: 
/*   87: 161 */       return new MacOSXDisplay();
/*   88:     */     }
/*   89: 163 */     throw new IllegalStateException("Unsupported platform");
/*   90:     */   }
/*   91:     */   
/*   92:     */   public static DisplayMode[] getAvailableDisplayModes()
/*   93:     */     throws LWJGLException
/*   94:     */   {
/*   95: 187 */     synchronized (GlobalLock.lock)
/*   96:     */     {
/*   97: 188 */       DisplayMode[] unfilteredModes = display_impl.getAvailableDisplayModes();
/*   98: 190 */       if (unfilteredModes == null) {
/*   99: 191 */         return new DisplayMode[0];
/*  100:     */       }
/*  101: 195 */       HashSet<DisplayMode> modes = new HashSet(unfilteredModes.length);
/*  102:     */       
/*  103: 197 */       modes.addAll(Arrays.asList(unfilteredModes));
/*  104: 198 */       DisplayMode[] filteredModes = new DisplayMode[modes.size()];
/*  105: 199 */       modes.toArray(filteredModes);
/*  106:     */       
/*  107: 201 */       LWJGLUtil.log("Removed " + (unfilteredModes.length - filteredModes.length) + " duplicate displaymodes");
/*  108:     */       
/*  109: 203 */       return filteredModes;
/*  110:     */     }
/*  111:     */   }
/*  112:     */   
/*  113:     */   public static DisplayMode getDesktopDisplayMode()
/*  114:     */   {
/*  115: 213 */     return initial_mode;
/*  116:     */   }
/*  117:     */   
/*  118:     */   public static DisplayMode getDisplayMode()
/*  119:     */   {
/*  120: 222 */     return current_mode;
/*  121:     */   }
/*  122:     */   
/*  123:     */   public static void setDisplayMode(DisplayMode mode)
/*  124:     */     throws LWJGLException
/*  125:     */   {
/*  126: 237 */     synchronized (GlobalLock.lock)
/*  127:     */     {
/*  128: 238 */       if (mode == null) {
/*  129: 239 */         throw new NullPointerException("mode must be non-null");
/*  130:     */       }
/*  131: 240 */       boolean was_fullscreen = isFullscreen();
/*  132: 241 */       current_mode = mode;
/*  133: 242 */       if (isCreated())
/*  134:     */       {
/*  135: 243 */         destroyWindow();
/*  136:     */         try
/*  137:     */         {
/*  138: 246 */           if ((was_fullscreen) && (!isFullscreen())) {
/*  139: 247 */             display_impl.resetDisplayMode();
/*  140: 248 */           } else if (isFullscreen()) {
/*  141: 249 */             switchDisplayMode();
/*  142:     */           }
/*  143: 250 */           createWindow();
/*  144: 251 */           makeCurrentAndSetSwapInterval();
/*  145:     */         }
/*  146:     */         catch (LWJGLException e)
/*  147:     */         {
/*  148: 253 */           drawable.destroy();
/*  149: 254 */           display_impl.resetDisplayMode();
/*  150: 255 */           throw e;
/*  151:     */         }
/*  152:     */       }
/*  153:     */     }
/*  154:     */   }
/*  155:     */   
/*  156:     */   private static DisplayMode getEffectiveMode()
/*  157:     */   {
/*  158: 262 */     return (!isFullscreen()) && (parent != null) ? new DisplayMode(parent.getWidth(), parent.getHeight()) : current_mode;
/*  159:     */   }
/*  160:     */   
/*  161:     */   private static int getWindowX()
/*  162:     */   {
/*  163: 266 */     if ((!isFullscreen()) && (parent == null))
/*  164:     */     {
/*  165: 268 */       if (x == -1) {
/*  166: 269 */         return Math.max(0, (initial_mode.getWidth() - current_mode.getWidth()) / 2);
/*  167:     */       }
/*  168: 271 */       return x;
/*  169:     */     }
/*  170: 274 */     return 0;
/*  171:     */   }
/*  172:     */   
/*  173:     */   private static int getWindowY()
/*  174:     */   {
/*  175: 279 */     if ((!isFullscreen()) && (parent == null))
/*  176:     */     {
/*  177: 281 */       if (y == -1) {
/*  178: 282 */         return Math.max(0, (initial_mode.getHeight() - current_mode.getHeight()) / 2);
/*  179:     */       }
/*  180: 284 */       return y;
/*  181:     */     }
/*  182: 287 */     return 0;
/*  183:     */   }
/*  184:     */   
/*  185:     */   private static void createWindow()
/*  186:     */     throws LWJGLException
/*  187:     */   {
/*  188: 296 */     if (window_created) {
/*  189: 297 */       return;
/*  190:     */     }
/*  191: 299 */     Canvas tmp_parent = isFullscreen() ? null : parent;
/*  192: 300 */     if ((tmp_parent != null) && (!tmp_parent.isDisplayable())) {
/*  193: 301 */       throw new LWJGLException("Parent.isDisplayable() must be true");
/*  194:     */     }
/*  195: 302 */     if (tmp_parent != null) {
/*  196: 303 */       tmp_parent.addComponentListener(component_listener);
/*  197:     */     }
/*  198: 305 */     DisplayMode mode = getEffectiveMode();
/*  199: 306 */     display_impl.createWindow(drawable, mode, tmp_parent, getWindowX(), getWindowY());
/*  200: 307 */     window_created = true;
/*  201:     */     
/*  202: 309 */     width = getDisplayMode().getWidth();
/*  203: 310 */     height = getDisplayMode().getHeight();
/*  204:     */     
/*  205: 312 */     setTitle(title);
/*  206: 313 */     initControls();
/*  207: 316 */     if (cached_icons != null) {
/*  208: 317 */       setIcon(cached_icons);
/*  209:     */     } else {
/*  210: 319 */       setIcon(new ByteBuffer[] { LWJGLUtil.LWJGLIcon32x32, LWJGLUtil.LWJGLIcon16x16 });
/*  211:     */     }
/*  212:     */   }
/*  213:     */   
/*  214:     */   private static void releaseDrawable()
/*  215:     */   {
/*  216:     */     try
/*  217:     */     {
/*  218: 325 */       Context context = drawable.getContext();
/*  219: 326 */       if ((context != null) && (context.isCurrent()))
/*  220:     */       {
/*  221: 327 */         context.releaseCurrent();
/*  222: 328 */         context.releaseDrawable();
/*  223:     */       }
/*  224:     */     }
/*  225:     */     catch (LWJGLException e)
/*  226:     */     {
/*  227: 331 */       LWJGLUtil.log("Exception occurred while trying to release context: " + e);
/*  228:     */     }
/*  229:     */   }
/*  230:     */   
/*  231:     */   private static void destroyWindow()
/*  232:     */   {
/*  233: 336 */     if (!window_created) {
/*  234: 337 */       return;
/*  235:     */     }
/*  236: 339 */     if (parent != null) {
/*  237: 340 */       parent.removeComponentListener(component_listener);
/*  238:     */     }
/*  239: 342 */     releaseDrawable();
/*  240: 345 */     if (Mouse.isCreated()) {
/*  241: 346 */       Mouse.destroy();
/*  242:     */     }
/*  243: 348 */     if (Keyboard.isCreated()) {
/*  244: 349 */       Keyboard.destroy();
/*  245:     */     }
/*  246: 351 */     display_impl.destroyWindow();
/*  247: 352 */     window_created = false;
/*  248:     */   }
/*  249:     */   
/*  250:     */   private static void switchDisplayMode()
/*  251:     */     throws LWJGLException
/*  252:     */   {
/*  253: 356 */     if (!current_mode.isFullscreenCapable()) {
/*  254: 357 */       throw new IllegalStateException("Only modes acquired from getAvailableDisplayModes() can be used for fullscreen display");
/*  255:     */     }
/*  256: 359 */     display_impl.switchDisplayMode(current_mode);
/*  257:     */   }
/*  258:     */   
/*  259:     */   public static void setDisplayConfiguration(float gamma, float brightness, float contrast)
/*  260:     */     throws LWJGLException
/*  261:     */   {
/*  262: 371 */     synchronized (GlobalLock.lock)
/*  263:     */     {
/*  264: 372 */       if (!isCreated()) {
/*  265: 373 */         throw new LWJGLException("Display not yet created.");
/*  266:     */       }
/*  267: 375 */       if ((brightness < -1.0F) || (brightness > 1.0F)) {
/*  268: 376 */         throw new IllegalArgumentException("Invalid brightness value");
/*  269:     */       }
/*  270: 377 */       if (contrast < 0.0F) {
/*  271: 378 */         throw new IllegalArgumentException("Invalid contrast value");
/*  272:     */       }
/*  273: 379 */       int rampSize = display_impl.getGammaRampLength();
/*  274: 380 */       if (rampSize == 0) {
/*  275: 381 */         throw new LWJGLException("Display configuration not supported");
/*  276:     */       }
/*  277: 383 */       FloatBuffer gammaRamp = BufferUtils.createFloatBuffer(rampSize);
/*  278: 384 */       for (int i = 0; i < rampSize; i++)
/*  279:     */       {
/*  280: 385 */         float intensity = i / (rampSize - 1);
/*  281:     */         
/*  282: 387 */         float rampEntry = (float)Math.pow(intensity, gamma);
/*  283:     */         
/*  284: 389 */         rampEntry += brightness;
/*  285:     */         
/*  286: 391 */         rampEntry = (rampEntry - 0.5F) * contrast + 0.5F;
/*  287: 393 */         if (rampEntry > 1.0F) {
/*  288: 394 */           rampEntry = 1.0F;
/*  289: 395 */         } else if (rampEntry < 0.0F) {
/*  290: 396 */           rampEntry = 0.0F;
/*  291:     */         }
/*  292: 397 */         gammaRamp.put(i, rampEntry);
/*  293:     */       }
/*  294: 399 */       display_impl.setGammaRamp(gammaRamp);
/*  295: 400 */       LWJGLUtil.log("Gamma set, gamma = " + gamma + ", brightness = " + brightness + ", contrast = " + contrast);
/*  296:     */     }
/*  297:     */   }
/*  298:     */   
/*  299:     */   public static void sync(int fps)
/*  300:     */   {
/*  301: 411 */     Sync.sync(fps);
/*  302:     */   }
/*  303:     */   
/*  304:     */   public static String getTitle()
/*  305:     */   {
/*  306: 416 */     synchronized (GlobalLock.lock)
/*  307:     */     {
/*  308: 417 */       return title;
/*  309:     */     }
/*  310:     */   }
/*  311:     */   
/*  312:     */   public static Canvas getParent()
/*  313:     */   {
/*  314: 423 */     synchronized (GlobalLock.lock)
/*  315:     */     {
/*  316: 424 */       return parent;
/*  317:     */     }
/*  318:     */   }
/*  319:     */   
/*  320:     */   public static void setParent(Canvas parent)
/*  321:     */     throws LWJGLException
/*  322:     */   {
/*  323: 439 */     synchronized (GlobalLock.lock)
/*  324:     */     {
/*  325: 440 */       if (parent != parent)
/*  326:     */       {
/*  327: 441 */         parent = parent;
/*  328: 442 */         if (!isCreated()) {
/*  329: 443 */           return;
/*  330:     */         }
/*  331: 444 */         destroyWindow();
/*  332:     */         try
/*  333:     */         {
/*  334: 446 */           if (isFullscreen()) {
/*  335: 447 */             switchDisplayMode();
/*  336:     */           } else {
/*  337: 449 */             display_impl.resetDisplayMode();
/*  338:     */           }
/*  339: 451 */           createWindow();
/*  340: 452 */           makeCurrentAndSetSwapInterval();
/*  341:     */         }
/*  342:     */         catch (LWJGLException e)
/*  343:     */         {
/*  344: 454 */           drawable.destroy();
/*  345: 455 */           display_impl.resetDisplayMode();
/*  346: 456 */           throw e;
/*  347:     */         }
/*  348:     */       }
/*  349:     */     }
/*  350:     */   }
/*  351:     */   
/*  352:     */   public static void setFullscreen(boolean fullscreen)
/*  353:     */     throws LWJGLException
/*  354:     */   {
/*  355: 475 */     setDisplayModeAndFullscreenInternal(fullscreen, current_mode);
/*  356:     */   }
/*  357:     */   
/*  358:     */   public static void setDisplayModeAndFullscreen(DisplayMode mode)
/*  359:     */     throws LWJGLException
/*  360:     */   {
/*  361: 490 */     setDisplayModeAndFullscreenInternal(mode.isFullscreenCapable(), mode);
/*  362:     */   }
/*  363:     */   
/*  364:     */   private static void setDisplayModeAndFullscreenInternal(boolean fullscreen, DisplayMode mode)
/*  365:     */     throws LWJGLException
/*  366:     */   {
/*  367: 494 */     synchronized (GlobalLock.lock)
/*  368:     */     {
/*  369: 495 */       if (mode == null) {
/*  370: 496 */         throw new NullPointerException("mode must be non-null");
/*  371:     */       }
/*  372: 497 */       DisplayMode old_mode = current_mode;
/*  373: 498 */       current_mode = mode;
/*  374: 499 */       boolean was_fullscreen = isFullscreen();
/*  375: 500 */       fullscreen = fullscreen;
/*  376: 501 */       if ((was_fullscreen != isFullscreen()) || (!mode.equals(old_mode)))
/*  377:     */       {
/*  378: 502 */         if (!isCreated()) {
/*  379: 503 */           return;
/*  380:     */         }
/*  381: 504 */         destroyWindow();
/*  382:     */         try
/*  383:     */         {
/*  384: 506 */           if (isFullscreen()) {
/*  385: 507 */             switchDisplayMode();
/*  386:     */           } else {
/*  387: 509 */             display_impl.resetDisplayMode();
/*  388:     */           }
/*  389: 511 */           createWindow();
/*  390: 512 */           makeCurrentAndSetSwapInterval();
/*  391:     */         }
/*  392:     */         catch (LWJGLException e)
/*  393:     */         {
/*  394: 514 */           drawable.destroy();
/*  395: 515 */           display_impl.resetDisplayMode();
/*  396: 516 */           throw e;
/*  397:     */         }
/*  398:     */       }
/*  399:     */     }
/*  400:     */   }
/*  401:     */   
/*  402:     */   public static boolean isFullscreen()
/*  403:     */   {
/*  404: 524 */     synchronized (GlobalLock.lock)
/*  405:     */     {
/*  406: 525 */       return (fullscreen) && (current_mode.isFullscreenCapable());
/*  407:     */     }
/*  408:     */   }
/*  409:     */   
/*  410:     */   public static void setTitle(String newTitle)
/*  411:     */   {
/*  412: 535 */     synchronized (GlobalLock.lock)
/*  413:     */     {
/*  414: 536 */       if (newTitle == null) {
/*  415: 537 */         newTitle = "";
/*  416:     */       }
/*  417: 539 */       title = newTitle;
/*  418: 540 */       if (isCreated()) {
/*  419: 541 */         display_impl.setTitle(title);
/*  420:     */       }
/*  421:     */     }
/*  422:     */   }
/*  423:     */   
/*  424:     */   public static boolean isCloseRequested()
/*  425:     */   {
/*  426: 547 */     synchronized (GlobalLock.lock)
/*  427:     */     {
/*  428: 548 */       if (!isCreated()) {
/*  429: 549 */         throw new IllegalStateException("Cannot determine close requested state of uncreated window");
/*  430:     */       }
/*  431: 550 */       return display_impl.isCloseRequested();
/*  432:     */     }
/*  433:     */   }
/*  434:     */   
/*  435:     */   public static boolean isVisible()
/*  436:     */   {
/*  437: 556 */     synchronized (GlobalLock.lock)
/*  438:     */     {
/*  439: 557 */       if (!isCreated()) {
/*  440: 558 */         throw new IllegalStateException("Cannot determine minimized state of uncreated window");
/*  441:     */       }
/*  442: 559 */       return display_impl.isVisible();
/*  443:     */     }
/*  444:     */   }
/*  445:     */   
/*  446:     */   public static boolean isActive()
/*  447:     */   {
/*  448: 565 */     synchronized (GlobalLock.lock)
/*  449:     */     {
/*  450: 566 */       if (!isCreated()) {
/*  451: 567 */         throw new IllegalStateException("Cannot determine focused state of uncreated window");
/*  452:     */       }
/*  453: 568 */       return display_impl.isActive();
/*  454:     */     }
/*  455:     */   }
/*  456:     */   
/*  457:     */   public static boolean isDirty()
/*  458:     */   {
/*  459: 583 */     synchronized (GlobalLock.lock)
/*  460:     */     {
/*  461: 584 */       if (!isCreated()) {
/*  462: 585 */         throw new IllegalStateException("Cannot determine dirty state of uncreated window");
/*  463:     */       }
/*  464: 586 */       return display_impl.isDirty();
/*  465:     */     }
/*  466:     */   }
/*  467:     */   
/*  468:     */   public static void processMessages()
/*  469:     */   {
/*  470: 596 */     synchronized (GlobalLock.lock)
/*  471:     */     {
/*  472: 597 */       if (!isCreated()) {
/*  473: 598 */         throw new IllegalStateException("Display not created");
/*  474:     */       }
/*  475: 600 */       display_impl.update();
/*  476:     */     }
/*  477: 602 */     pollDevices();
/*  478:     */   }
/*  479:     */   
/*  480:     */   public static void swapBuffers()
/*  481:     */     throws LWJGLException
/*  482:     */   {
/*  483: 612 */     synchronized (GlobalLock.lock)
/*  484:     */     {
/*  485: 613 */       if (!isCreated()) {
/*  486: 614 */         throw new IllegalStateException("Display not created");
/*  487:     */       }
/*  488: 616 */       if (LWJGLUtil.DEBUG) {
/*  489: 617 */         drawable.checkGLError();
/*  490:     */       }
/*  491: 618 */       drawable.swapBuffers();
/*  492:     */     }
/*  493:     */   }
/*  494:     */   
/*  495:     */   public static void update()
/*  496:     */   {
/*  497: 628 */     update(true);
/*  498:     */   }
/*  499:     */   
/*  500:     */   public static void update(boolean processMessages)
/*  501:     */   {
/*  502: 639 */     synchronized (GlobalLock.lock)
/*  503:     */     {
/*  504: 640 */       if (!isCreated()) {
/*  505: 641 */         throw new IllegalStateException("Display not created");
/*  506:     */       }
/*  507: 644 */       if ((display_impl.isVisible()) || (display_impl.isDirty())) {
/*  508:     */         try
/*  509:     */         {
/*  510: 646 */           swapBuffers();
/*  511:     */         }
/*  512:     */         catch (LWJGLException e)
/*  513:     */         {
/*  514: 648 */           throw new RuntimeException(e);
/*  515:     */         }
/*  516:     */       }
/*  517: 652 */       window_resized = (!isFullscreen()) && (parent == null) && (display_impl.wasResized());
/*  518: 654 */       if (window_resized)
/*  519:     */       {
/*  520: 655 */         width = display_impl.getWidth();
/*  521: 656 */         height = display_impl.getHeight();
/*  522:     */       }
/*  523: 659 */       if (parent_resized)
/*  524:     */       {
/*  525: 660 */         reshape();
/*  526: 661 */         parent_resized = false;
/*  527: 662 */         window_resized = true;
/*  528:     */       }
/*  529: 665 */       if (processMessages) {
/*  530: 666 */         processMessages();
/*  531:     */       }
/*  532:     */     }
/*  533:     */   }
/*  534:     */   
/*  535:     */   static void pollDevices()
/*  536:     */   {
/*  537: 672 */     if (Mouse.isCreated())
/*  538:     */     {
/*  539: 673 */       Mouse.poll();
/*  540: 674 */       Mouse.updateCursor();
/*  541:     */     }
/*  542: 677 */     if (Keyboard.isCreated()) {
/*  543: 678 */       Keyboard.poll();
/*  544:     */     }
/*  545: 681 */     if (Controllers.isCreated()) {
/*  546: 682 */       Controllers.poll();
/*  547:     */     }
/*  548:     */   }
/*  549:     */   
/*  550:     */   public static void releaseContext()
/*  551:     */     throws LWJGLException
/*  552:     */   {
/*  553: 692 */     drawable.releaseContext();
/*  554:     */   }
/*  555:     */   
/*  556:     */   public static boolean isCurrent()
/*  557:     */     throws LWJGLException
/*  558:     */   {
/*  559: 697 */     return drawable.isCurrent();
/*  560:     */   }
/*  561:     */   
/*  562:     */   public static void makeCurrent()
/*  563:     */     throws LWJGLException
/*  564:     */   {
/*  565: 706 */     drawable.makeCurrent();
/*  566:     */   }
/*  567:     */   
/*  568:     */   private static void removeShutdownHook()
/*  569:     */   {
/*  570: 710 */     AccessController.doPrivileged(new PrivilegedAction()
/*  571:     */     {
/*  572:     */       public Object run()
/*  573:     */       {
/*  574: 712 */         Runtime.getRuntime().removeShutdownHook(Display.shutdown_hook);
/*  575: 713 */         return null;
/*  576:     */       }
/*  577:     */     });
/*  578:     */   }
/*  579:     */   
/*  580:     */   private static void registerShutdownHook()
/*  581:     */   {
/*  582: 719 */     AccessController.doPrivileged(new PrivilegedAction()
/*  583:     */     {
/*  584:     */       public Object run()
/*  585:     */       {
/*  586: 721 */         Runtime.getRuntime().addShutdownHook(Display.shutdown_hook);
/*  587: 722 */         return null;
/*  588:     */       }
/*  589:     */     });
/*  590:     */   }
/*  591:     */   
/*  592:     */   public static void create()
/*  593:     */     throws LWJGLException
/*  594:     */   {
/*  595: 739 */     create(new PixelFormat());
/*  596:     */   }
/*  597:     */   
/*  598:     */   public static void create(PixelFormat pixel_format)
/*  599:     */     throws LWJGLException
/*  600:     */   {
/*  601: 756 */     synchronized (GlobalLock.lock)
/*  602:     */     {
/*  603: 757 */       create(pixel_format, null, (ContextAttribs)null);
/*  604:     */     }
/*  605:     */   }
/*  606:     */   
/*  607:     */   public static void create(PixelFormat pixel_format, Drawable shared_drawable)
/*  608:     */     throws LWJGLException
/*  609:     */   {
/*  610: 776 */     synchronized (GlobalLock.lock)
/*  611:     */     {
/*  612: 777 */       create(pixel_format, shared_drawable, (ContextAttribs)null);
/*  613:     */     }
/*  614:     */   }
/*  615:     */   
/*  616:     */   public static void create(PixelFormat pixel_format, ContextAttribs attribs)
/*  617:     */     throws LWJGLException
/*  618:     */   {
/*  619: 796 */     synchronized (GlobalLock.lock)
/*  620:     */     {
/*  621: 797 */       create(pixel_format, null, attribs);
/*  622:     */     }
/*  623:     */   }
/*  624:     */   
/*  625:     */   public static void create(PixelFormat pixel_format, Drawable shared_drawable, ContextAttribs attribs)
/*  626:     */     throws LWJGLException
/*  627:     */   {
/*  628: 817 */     synchronized (GlobalLock.lock)
/*  629:     */     {
/*  630: 818 */       if (isCreated()) {
/*  631: 819 */         throw new IllegalStateException("Only one LWJGL context may be instantiated at any one time.");
/*  632:     */       }
/*  633: 820 */       if (pixel_format == null) {
/*  634: 821 */         throw new NullPointerException("pixel_format cannot be null");
/*  635:     */       }
/*  636: 822 */       removeShutdownHook();
/*  637: 823 */       registerShutdownHook();
/*  638: 824 */       if (isFullscreen()) {
/*  639: 825 */         switchDisplayMode();
/*  640:     */       }
/*  641: 827 */       DrawableGL drawable = new DrawableGL()
/*  642:     */       {
/*  643:     */         public void destroy()
/*  644:     */         {
/*  645: 829 */           synchronized (GlobalLock.lock)
/*  646:     */           {
/*  647: 830 */             if (!Display.isCreated()) {
/*  648: 831 */               return;
/*  649:     */             }
/*  650: 833 */             Display.access$300();
/*  651: 834 */             super.destroy();
/*  652: 835 */             Display.access$400();
/*  653: 836 */             Display.access$502(Display.access$602(-1));
/*  654: 837 */             Display.access$702(null);
/*  655: 838 */             Display.access$000();
/*  656: 839 */             Display.access$800();
/*  657:     */           }
/*  658:     */         }
/*  659: 842 */       };
/*  660: 843 */       drawable = drawable;
/*  661:     */       try
/*  662:     */       {
/*  663: 846 */         drawable.setPixelFormat(pixel_format, attribs);
/*  664:     */         try
/*  665:     */         {
/*  666: 848 */           createWindow();
/*  667:     */           try
/*  668:     */           {
/*  669: 850 */             drawable.context = new ContextGL(drawable.peer_info, attribs, shared_drawable != null ? ((DrawableGL)shared_drawable).getContext() : null);
/*  670:     */             try
/*  671:     */             {
/*  672: 852 */               makeCurrentAndSetSwapInterval();
/*  673: 853 */               initContext();
/*  674:     */             }
/*  675:     */             catch (LWJGLException e)
/*  676:     */             {
/*  677: 855 */               drawable.destroy();
/*  678: 856 */               throw e;
/*  679:     */             }
/*  680:     */           }
/*  681:     */           catch (LWJGLException e)
/*  682:     */           {
/*  683: 859 */             destroyWindow();
/*  684: 860 */             throw e;
/*  685:     */           }
/*  686:     */         }
/*  687:     */         catch (LWJGLException e)
/*  688:     */         {
/*  689: 863 */           drawable.destroy();
/*  690: 864 */           throw e;
/*  691:     */         }
/*  692:     */       }
/*  693:     */       catch (LWJGLException e)
/*  694:     */       {
/*  695: 867 */         display_impl.resetDisplayMode();
/*  696: 868 */         throw e;
/*  697:     */       }
/*  698:     */     }
/*  699:     */   }
/*  700:     */   
/*  701:     */   public static void create(PixelFormatLWJGL pixel_format)
/*  702:     */     throws LWJGLException
/*  703:     */   {
/*  704: 888 */     synchronized (GlobalLock.lock)
/*  705:     */     {
/*  706: 889 */       create(pixel_format, null, null);
/*  707:     */     }
/*  708:     */   }
/*  709:     */   
/*  710:     */   public static void create(PixelFormatLWJGL pixel_format, Drawable shared_drawable)
/*  711:     */     throws LWJGLException
/*  712:     */   {
/*  713: 908 */     synchronized (GlobalLock.lock)
/*  714:     */     {
/*  715: 909 */       create(pixel_format, shared_drawable, null);
/*  716:     */     }
/*  717:     */   }
/*  718:     */   
/*  719:     */   public static void create(PixelFormatLWJGL pixel_format, org.lwjgl.opengles.ContextAttribs attribs)
/*  720:     */     throws LWJGLException
/*  721:     */   {
/*  722: 928 */     synchronized (GlobalLock.lock)
/*  723:     */     {
/*  724: 929 */       create(pixel_format, null, attribs);
/*  725:     */     }
/*  726:     */   }
/*  727:     */   
/*  728:     */   public static void create(PixelFormatLWJGL pixel_format, Drawable shared_drawable, org.lwjgl.opengles.ContextAttribs attribs)
/*  729:     */     throws LWJGLException
/*  730:     */   {
/*  731: 949 */     synchronized (GlobalLock.lock)
/*  732:     */     {
/*  733: 950 */       if (isCreated()) {
/*  734: 951 */         throw new IllegalStateException("Only one LWJGL context may be instantiated at any one time.");
/*  735:     */       }
/*  736: 952 */       if (pixel_format == null) {
/*  737: 953 */         throw new NullPointerException("pixel_format cannot be null");
/*  738:     */       }
/*  739: 954 */       removeShutdownHook();
/*  740: 955 */       registerShutdownHook();
/*  741: 956 */       if (isFullscreen()) {
/*  742: 957 */         switchDisplayMode();
/*  743:     */       }
/*  744: 959 */       DrawableGLES drawable = new DrawableGLES()
/*  745:     */       {
/*  746:     */         public void setPixelFormat(PixelFormatLWJGL pf, ContextAttribs attribs)
/*  747:     */           throws LWJGLException
/*  748:     */         {
/*  749: 962 */           throw new UnsupportedOperationException();
/*  750:     */         }
/*  751:     */         
/*  752:     */         public void destroy()
/*  753:     */         {
/*  754: 966 */           synchronized (GlobalLock.lock)
/*  755:     */           {
/*  756: 967 */             if (!Display.isCreated()) {
/*  757: 968 */               return;
/*  758:     */             }
/*  759: 970 */             Display.access$300();
/*  760: 971 */             super.destroy();
/*  761: 972 */             Display.access$400();
/*  762: 973 */             Display.access$502(Display.access$602(-1));
/*  763: 974 */             Display.access$702(null);
/*  764: 975 */             Display.access$000();
/*  765: 976 */             Display.access$800();
/*  766:     */           }
/*  767:     */         }
/*  768: 979 */       };
/*  769: 980 */       drawable = drawable;
/*  770:     */       try
/*  771:     */       {
/*  772: 983 */         drawable.setPixelFormat(pixel_format);
/*  773:     */         try
/*  774:     */         {
/*  775: 985 */           createWindow();
/*  776:     */           try
/*  777:     */           {
/*  778: 987 */             drawable.createContext(attribs, shared_drawable);
/*  779:     */             try
/*  780:     */             {
/*  781: 989 */               makeCurrentAndSetSwapInterval();
/*  782: 990 */               initContext();
/*  783:     */             }
/*  784:     */             catch (LWJGLException e)
/*  785:     */             {
/*  786: 992 */               drawable.destroy();
/*  787: 993 */               throw e;
/*  788:     */             }
/*  789:     */           }
/*  790:     */           catch (LWJGLException e)
/*  791:     */           {
/*  792: 996 */             destroyWindow();
/*  793: 997 */             throw e;
/*  794:     */           }
/*  795:     */         }
/*  796:     */         catch (LWJGLException e)
/*  797:     */         {
/*  798:1000 */           drawable.destroy();
/*  799:1001 */           throw e;
/*  800:     */         }
/*  801:     */       }
/*  802:     */       catch (LWJGLException e)
/*  803:     */       {
/*  804:1004 */         display_impl.resetDisplayMode();
/*  805:1005 */         throw e;
/*  806:     */       }
/*  807:     */     }
/*  808:     */   }
/*  809:     */   
/*  810:     */   public static void setInitialBackground(float red, float green, float blue)
/*  811:     */   {
/*  812:1019 */     r = red;
/*  813:1020 */     g = green;
/*  814:1021 */     b = blue;
/*  815:     */   }
/*  816:     */   
/*  817:     */   private static void makeCurrentAndSetSwapInterval()
/*  818:     */     throws LWJGLException
/*  819:     */   {
/*  820:     */     
/*  821:     */     try
/*  822:     */     {
/*  823:1027 */       drawable.checkGLError();
/*  824:     */     }
/*  825:     */     catch (OpenGLException e)
/*  826:     */     {
/*  827:1029 */       LWJGLUtil.log("OpenGL error during context creation: " + e.getMessage());
/*  828:     */     }
/*  829:1031 */     setSwapInterval(swap_interval);
/*  830:     */   }
/*  831:     */   
/*  832:     */   private static void initContext()
/*  833:     */   {
/*  834:1035 */     drawable.initContext(r, g, b);
/*  835:1036 */     update();
/*  836:     */   }
/*  837:     */   
/*  838:     */   static DisplayImplementation getImplementation()
/*  839:     */   {
/*  840:1040 */     return display_impl;
/*  841:     */   }
/*  842:     */   
/*  843:     */   static boolean getPrivilegedBoolean(String property_name)
/*  844:     */   {
/*  845:1045 */     ((Boolean)AccessController.doPrivileged(new PrivilegedAction()
/*  846:     */     {
/*  847:     */       public Boolean run()
/*  848:     */       {
/*  849:1047 */         return Boolean.valueOf(Boolean.getBoolean(this.val$property_name));
/*  850:     */       }
/*  851:     */     })).booleanValue();
/*  852:     */   }
/*  853:     */   
/*  854:     */   private static void initControls()
/*  855:     */   {
/*  856:1054 */     if (!getPrivilegedBoolean("org.lwjgl.opengl.Display.noinput"))
/*  857:     */     {
/*  858:1055 */       if ((!Mouse.isCreated()) && (!getPrivilegedBoolean("org.lwjgl.opengl.Display.nomouse"))) {
/*  859:     */         try
/*  860:     */         {
/*  861:1057 */           Mouse.create();
/*  862:     */         }
/*  863:     */         catch (LWJGLException e)
/*  864:     */         {
/*  865:1059 */           if (LWJGLUtil.DEBUG) {
/*  866:1060 */             e.printStackTrace(System.err);
/*  867:     */           } else {
/*  868:1062 */             LWJGLUtil.log("Failed to create Mouse: " + e);
/*  869:     */           }
/*  870:     */         }
/*  871:     */       }
/*  872:1066 */       if ((!Keyboard.isCreated()) && (!getPrivilegedBoolean("org.lwjgl.opengl.Display.nokeyboard"))) {
/*  873:     */         try
/*  874:     */         {
/*  875:1068 */           Keyboard.create();
/*  876:     */         }
/*  877:     */         catch (LWJGLException e)
/*  878:     */         {
/*  879:1070 */           if (LWJGLUtil.DEBUG) {
/*  880:1071 */             e.printStackTrace(System.err);
/*  881:     */           } else {
/*  882:1073 */             LWJGLUtil.log("Failed to create Keyboard: " + e);
/*  883:     */           }
/*  884:     */         }
/*  885:     */       }
/*  886:     */     }
/*  887:     */   }
/*  888:     */   
/*  889:     */   public static void destroy()
/*  890:     */   {
/*  891:1085 */     if (isCreated()) {
/*  892:1086 */       drawable.destroy();
/*  893:     */     }
/*  894:     */   }
/*  895:     */   
/*  896:     */   private static void reset()
/*  897:     */   {
/*  898:1096 */     display_impl.resetDisplayMode();
/*  899:1097 */     current_mode = initial_mode;
/*  900:     */   }
/*  901:     */   
/*  902:     */   public static boolean isCreated()
/*  903:     */   {
/*  904:1102 */     synchronized (GlobalLock.lock)
/*  905:     */     {
/*  906:1103 */       return window_created;
/*  907:     */     }
/*  908:     */   }
/*  909:     */   
/*  910:     */   public static void setSwapInterval(int value)
/*  911:     */   {
/*  912:1117 */     synchronized (GlobalLock.lock)
/*  913:     */     {
/*  914:1118 */       swap_interval = value;
/*  915:1119 */       if (isCreated()) {
/*  916:1120 */         drawable.setSwapInterval(swap_interval);
/*  917:     */       }
/*  918:     */     }
/*  919:     */   }
/*  920:     */   
/*  921:     */   public static void setVSyncEnabled(boolean sync)
/*  922:     */   {
/*  923:1132 */     synchronized (GlobalLock.lock)
/*  924:     */     {
/*  925:1133 */       setSwapInterval(sync ? 1 : 0);
/*  926:     */     }
/*  927:     */   }
/*  928:     */   
/*  929:     */   public static void setLocation(int new_x, int new_y)
/*  930:     */   {
/*  931:1148 */     synchronized (GlobalLock.lock)
/*  932:     */     {
/*  933:1150 */       x = new_x;
/*  934:1151 */       y = new_y;
/*  935:1154 */       if ((isCreated()) && (!isFullscreen())) {
/*  936:1155 */         reshape();
/*  937:     */       }
/*  938:     */     }
/*  939:     */   }
/*  940:     */   
/*  941:     */   private static void reshape()
/*  942:     */   {
/*  943:1161 */     DisplayMode mode = getEffectiveMode();
/*  944:1162 */     display_impl.reshape(getWindowX(), getWindowY(), mode.getWidth(), mode.getHeight());
/*  945:     */   }
/*  946:     */   
/*  947:     */   public static String getAdapter()
/*  948:     */   {
/*  949:1172 */     synchronized (GlobalLock.lock)
/*  950:     */     {
/*  951:1173 */       return display_impl.getAdapter();
/*  952:     */     }
/*  953:     */   }
/*  954:     */   
/*  955:     */   public static String getVersion()
/*  956:     */   {
/*  957:1184 */     synchronized (GlobalLock.lock)
/*  958:     */     {
/*  959:1185 */       return display_impl.getVersion();
/*  960:     */     }
/*  961:     */   }
/*  962:     */   
/*  963:     */   public static int setIcon(ByteBuffer[] icons)
/*  964:     */   {
/*  965:1207 */     synchronized (GlobalLock.lock)
/*  966:     */     {
/*  967:1210 */       if (cached_icons != icons)
/*  968:     */       {
/*  969:1211 */         cached_icons = new ByteBuffer[icons.length];
/*  970:1212 */         for (int i = 0; i < icons.length; i++)
/*  971:     */         {
/*  972:1213 */           cached_icons[i] = BufferUtils.createByteBuffer(icons[i].capacity());
/*  973:1214 */           int old_position = icons[i].position();
/*  974:1215 */           cached_icons[i].put(icons[i]);
/*  975:1216 */           icons[i].position(old_position);
/*  976:1217 */           cached_icons[i].flip();
/*  977:     */         }
/*  978:     */       }
/*  979:1221 */       if ((isCreated()) && (parent == null)) {
/*  980:1222 */         return display_impl.setIcon(cached_icons);
/*  981:     */       }
/*  982:1224 */       return 0;
/*  983:     */     }
/*  984:     */   }
/*  985:     */   
/*  986:     */   public static void setResizable(boolean resizable)
/*  987:     */   {
/*  988:1236 */     window_resizable = resizable;
/*  989:1237 */     if (isCreated()) {
/*  990:1238 */       display_impl.setResizable(resizable);
/*  991:     */     }
/*  992:     */   }
/*  993:     */   
/*  994:     */   public static boolean isResizable()
/*  995:     */   {
/*  996:1246 */     return window_resizable;
/*  997:     */   }
/*  998:     */   
/*  999:     */   public static boolean wasResized()
/* 1000:     */   {
/* 1001:1256 */     return window_resized;
/* 1002:     */   }
/* 1003:     */   
/* 1004:     */   public static int getX()
/* 1005:     */   {
/* 1006:1268 */     if (isFullscreen()) {
/* 1007:1269 */       return 0;
/* 1008:     */     }
/* 1009:1272 */     if (parent != null) {
/* 1010:1273 */       return parent.getX();
/* 1011:     */     }
/* 1012:1276 */     return display_impl.getX();
/* 1013:     */   }
/* 1014:     */   
/* 1015:     */   public static int getY()
/* 1016:     */   {
/* 1017:1288 */     if (isFullscreen()) {
/* 1018:1289 */       return 0;
/* 1019:     */     }
/* 1020:1292 */     if (parent != null) {
/* 1021:1293 */       return parent.getY();
/* 1022:     */     }
/* 1023:1296 */     return display_impl.getY();
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   public static int getWidth()
/* 1027:     */   {
/* 1028:1310 */     if (isFullscreen()) {
/* 1029:1311 */       return getDisplayMode().getWidth();
/* 1030:     */     }
/* 1031:1314 */     if (parent != null) {
/* 1032:1315 */       return parent.getWidth();
/* 1033:     */     }
/* 1034:1318 */     return width;
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */   public static int getHeight()
/* 1038:     */   {
/* 1039:1332 */     if (isFullscreen()) {
/* 1040:1333 */       return getDisplayMode().getHeight();
/* 1041:     */     }
/* 1042:1336 */     if (parent != null) {
/* 1043:1337 */       return parent.getHeight();
/* 1044:     */     }
/* 1045:1340 */     return height;
/* 1046:     */   }
/* 1047:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.Display
 * JD-Core Version:    0.7.0.1
 */