/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class AMDSamplePositions
/*  8:   */ {
/*  9:   */   public static final int GL_SUBSAMPLE_DISTANCE_AMD = 34879;
/* 10:   */   
/* 11:   */   public static void glSetMultisampleAMD(int pname, int index, FloatBuffer val)
/* 12:   */   {
/* 13:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:19 */     long function_pointer = caps.glSetMultisamplefvAMD;
/* 15:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:21 */     BufferChecks.checkBuffer(val, 2);
/* 17:22 */     nglSetMultisamplefvAMD(pname, index, MemoryUtil.getAddress(val), function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglSetMultisamplefvAMD(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 21:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDSamplePositions
 * JD-Core Version:    0.7.0.1
 */