/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVConditionalRender
/*  6:   */ {
/*  7:   */   public static final int GL_QUERY_WAIT_NV = 36371;
/*  8:   */   public static final int GL_QUERY_NO_WAIT_NV = 36372;
/*  9:   */   public static final int GL_QUERY_BY_REGION_WAIT_NV = 36373;
/* 10:   */   public static final int GL_QUERY_BY_REGION_NO_WAIT_NV = 36374;
/* 11:   */   
/* 12:   */   public static void glBeginConditionalRenderNV(int id, int mode)
/* 13:   */   {
/* 14:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:22 */     long function_pointer = caps.glBeginConditionalRenderNV;
/* 16:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:24 */     nglBeginConditionalRenderNV(id, mode, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglBeginConditionalRenderNV(int paramInt1, int paramInt2, long paramLong);
/* 21:   */   
/* 22:   */   public static void glEndConditionalRenderNV()
/* 23:   */   {
/* 24:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:30 */     long function_pointer = caps.glEndConditionalRenderNV;
/* 26:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:32 */     nglEndConditionalRenderNV(function_pointer);
/* 28:   */   }
/* 29:   */   
/* 30:   */   static native void nglEndConditionalRenderNV(long paramLong);
/* 31:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVConditionalRender
 * JD-Core Version:    0.7.0.1
 */