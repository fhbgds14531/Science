/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.awt.Graphics;
/*  5:   */ 
/*  6:   */ final class MacOSXGLCanvas
/*  7:   */   extends Canvas
/*  8:   */ {
/*  9:   */   private static final long serialVersionUID = 6916664741667434870L;
/* 10:   */   private boolean canvas_painted;
/* 11:   */   private boolean dirty;
/* 12:   */   
/* 13:   */   public void update(Graphics g)
/* 14:   */   {
/* 15:50 */     paint(g);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void paint(Graphics g)
/* 19:   */   {
/* 20:54 */     synchronized (this)
/* 21:   */     {
/* 22:55 */       this.dirty = true;
/* 23:56 */       this.canvas_painted = true;
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean syncCanvasPainted()
/* 28:   */   {
/* 29:   */     boolean result;
/* 30:62 */     synchronized (this)
/* 31:   */     {
/* 32:63 */       result = this.canvas_painted;
/* 33:64 */       this.canvas_painted = false;
/* 34:   */     }
/* 35:66 */     return result;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public boolean syncIsDirty()
/* 39:   */   {
/* 40:   */     boolean result;
/* 41:71 */     synchronized (this)
/* 42:   */     {
/* 43:72 */       result = this.dirty;
/* 44:73 */       this.dirty = false;
/* 45:   */     }
/* 46:75 */     return result;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXGLCanvas
 * JD-Core Version:    0.7.0.1
 */