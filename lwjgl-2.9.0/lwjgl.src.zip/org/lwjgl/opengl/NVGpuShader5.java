/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.LongBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVGpuShader5
/*   8:    */ {
/*   9:    */   public static final int GL_INT64_NV = 5134;
/*  10:    */   public static final int GL_UNSIGNED_INT64_NV = 5135;
/*  11:    */   public static final int GL_INT8_NV = 36832;
/*  12:    */   public static final int GL_INT8_VEC2_NV = 36833;
/*  13:    */   public static final int GL_INT8_VEC3_NV = 36834;
/*  14:    */   public static final int GL_INT8_VEC4_NV = 36835;
/*  15:    */   public static final int GL_INT16_NV = 36836;
/*  16:    */   public static final int GL_INT16_VEC2_NV = 36837;
/*  17:    */   public static final int GL_INT16_VEC3_NV = 36838;
/*  18:    */   public static final int GL_INT16_VEC4_NV = 36839;
/*  19:    */   public static final int GL_INT64_VEC2_NV = 36841;
/*  20:    */   public static final int GL_INT64_VEC3_NV = 36842;
/*  21:    */   public static final int GL_INT64_VEC4_NV = 36843;
/*  22:    */   public static final int GL_UNSIGNED_INT8_NV = 36844;
/*  23:    */   public static final int GL_UNSIGNED_INT8_VEC2_NV = 36845;
/*  24:    */   public static final int GL_UNSIGNED_INT8_VEC3_NV = 36846;
/*  25:    */   public static final int GL_UNSIGNED_INT8_VEC4_NV = 36847;
/*  26:    */   public static final int GL_UNSIGNED_INT16_NV = 36848;
/*  27:    */   public static final int GL_UNSIGNED_INT16_VEC2_NV = 36849;
/*  28:    */   public static final int GL_UNSIGNED_INT16_VEC3_NV = 36850;
/*  29:    */   public static final int GL_UNSIGNED_INT16_VEC4_NV = 36851;
/*  30:    */   public static final int GL_UNSIGNED_INT64_VEC2_NV = 36853;
/*  31:    */   public static final int GL_UNSIGNED_INT64_VEC3_NV = 36854;
/*  32:    */   public static final int GL_UNSIGNED_INT64_VEC4_NV = 36855;
/*  33:    */   public static final int GL_FLOAT16_NV = 36856;
/*  34:    */   public static final int GL_FLOAT16_VEC2_NV = 36857;
/*  35:    */   public static final int GL_FLOAT16_VEC3_NV = 36858;
/*  36:    */   public static final int GL_FLOAT16_VEC4_NV = 36859;
/*  37:    */   public static final int GL_PATCHES = 14;
/*  38:    */   
/*  39:    */   public static void glUniform1i64NV(int location, long x)
/*  40:    */   {
/*  41: 51 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  42: 52 */     long function_pointer = caps.glUniform1i64NV;
/*  43: 53 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  44: 54 */     nglUniform1i64NV(location, x, function_pointer);
/*  45:    */   }
/*  46:    */   
/*  47:    */   static native void nglUniform1i64NV(int paramInt, long paramLong1, long paramLong2);
/*  48:    */   
/*  49:    */   public static void glUniform2i64NV(int location, long x, long y)
/*  50:    */   {
/*  51: 59 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  52: 60 */     long function_pointer = caps.glUniform2i64NV;
/*  53: 61 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  54: 62 */     nglUniform2i64NV(location, x, y, function_pointer);
/*  55:    */   }
/*  56:    */   
/*  57:    */   static native void nglUniform2i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  58:    */   
/*  59:    */   public static void glUniform3i64NV(int location, long x, long y, long z)
/*  60:    */   {
/*  61: 67 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  62: 68 */     long function_pointer = caps.glUniform3i64NV;
/*  63: 69 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  64: 70 */     nglUniform3i64NV(location, x, y, z, function_pointer);
/*  65:    */   }
/*  66:    */   
/*  67:    */   static native void nglUniform3i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*  68:    */   
/*  69:    */   public static void glUniform4i64NV(int location, long x, long y, long z, long w)
/*  70:    */   {
/*  71: 75 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  72: 76 */     long function_pointer = caps.glUniform4i64NV;
/*  73: 77 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  74: 78 */     nglUniform4i64NV(location, x, y, z, w, function_pointer);
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native void nglUniform4i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  78:    */   
/*  79:    */   public static void glUniform1NV(int location, LongBuffer value)
/*  80:    */   {
/*  81: 83 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  82: 84 */     long function_pointer = caps.glUniform1i64vNV;
/*  83: 85 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  84: 86 */     BufferChecks.checkDirect(value);
/*  85: 87 */     nglUniform1i64vNV(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglUniform1i64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  89:    */   
/*  90:    */   public static void glUniform2NV(int location, LongBuffer value)
/*  91:    */   {
/*  92: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 93 */     long function_pointer = caps.glUniform2i64vNV;
/*  94: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 95 */     BufferChecks.checkDirect(value);
/*  96: 96 */     nglUniform2i64vNV(location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglUniform2i64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 100:    */   
/* 101:    */   public static void glUniform3NV(int location, LongBuffer value)
/* 102:    */   {
/* 103:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104:102 */     long function_pointer = caps.glUniform3i64vNV;
/* 105:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106:104 */     BufferChecks.checkDirect(value);
/* 107:105 */     nglUniform3i64vNV(location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglUniform3i64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static void glUniform4NV(int location, LongBuffer value)
/* 113:    */   {
/* 114:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:111 */     long function_pointer = caps.glUniform4i64vNV;
/* 116:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:113 */     BufferChecks.checkDirect(value);
/* 118:114 */     nglUniform4i64vNV(location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native void nglUniform4i64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 122:    */   
/* 123:    */   public static void glUniform1ui64NV(int location, long x)
/* 124:    */   {
/* 125:119 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:120 */     long function_pointer = caps.glUniform1ui64NV;
/* 127:121 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:122 */     nglUniform1ui64NV(location, x, function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglUniform1ui64NV(int paramInt, long paramLong1, long paramLong2);
/* 132:    */   
/* 133:    */   public static void glUniform2ui64NV(int location, long x, long y)
/* 134:    */   {
/* 135:127 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 136:128 */     long function_pointer = caps.glUniform2ui64NV;
/* 137:129 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 138:130 */     nglUniform2ui64NV(location, x, y, function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglUniform2ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 142:    */   
/* 143:    */   public static void glUniform3ui64NV(int location, long x, long y, long z)
/* 144:    */   {
/* 145:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 146:136 */     long function_pointer = caps.glUniform3ui64NV;
/* 147:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 148:138 */     nglUniform3ui64NV(location, x, y, z, function_pointer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   static native void nglUniform3ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 152:    */   
/* 153:    */   public static void glUniform4ui64NV(int location, long x, long y, long z, long w)
/* 154:    */   {
/* 155:143 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 156:144 */     long function_pointer = caps.glUniform4ui64NV;
/* 157:145 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 158:146 */     nglUniform4ui64NV(location, x, y, z, w, function_pointer);
/* 159:    */   }
/* 160:    */   
/* 161:    */   static native void nglUniform4ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 162:    */   
/* 163:    */   public static void glUniform1uNV(int location, LongBuffer value)
/* 164:    */   {
/* 165:151 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 166:152 */     long function_pointer = caps.glUniform1ui64vNV;
/* 167:153 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 168:154 */     BufferChecks.checkDirect(value);
/* 169:155 */     nglUniform1ui64vNV(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 170:    */   }
/* 171:    */   
/* 172:    */   static native void nglUniform1ui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 173:    */   
/* 174:    */   public static void glUniform2uNV(int location, LongBuffer value)
/* 175:    */   {
/* 176:160 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 177:161 */     long function_pointer = caps.glUniform2ui64vNV;
/* 178:162 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 179:163 */     BufferChecks.checkDirect(value);
/* 180:164 */     nglUniform2ui64vNV(location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 181:    */   }
/* 182:    */   
/* 183:    */   static native void nglUniform2ui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 184:    */   
/* 185:    */   public static void glUniform3uNV(int location, LongBuffer value)
/* 186:    */   {
/* 187:169 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 188:170 */     long function_pointer = caps.glUniform3ui64vNV;
/* 189:171 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 190:172 */     BufferChecks.checkDirect(value);
/* 191:173 */     nglUniform3ui64vNV(location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 192:    */   }
/* 193:    */   
/* 194:    */   static native void nglUniform3ui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 195:    */   
/* 196:    */   public static void glUniform4uNV(int location, LongBuffer value)
/* 197:    */   {
/* 198:178 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 199:179 */     long function_pointer = caps.glUniform4ui64vNV;
/* 200:180 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 201:181 */     BufferChecks.checkDirect(value);
/* 202:182 */     nglUniform4ui64vNV(location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 203:    */   }
/* 204:    */   
/* 205:    */   static native void nglUniform4ui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 206:    */   
/* 207:    */   public static void glGetUniformNV(int program, int location, LongBuffer params)
/* 208:    */   {
/* 209:187 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 210:188 */     long function_pointer = caps.glGetUniformi64vNV;
/* 211:189 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 212:190 */     BufferChecks.checkBuffer(params, 1);
/* 213:191 */     nglGetUniformi64vNV(program, location, MemoryUtil.getAddress(params), function_pointer);
/* 214:    */   }
/* 215:    */   
/* 216:    */   static native void nglGetUniformi64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 217:    */   
/* 218:    */   public static void glGetUniformuNV(int program, int location, LongBuffer params)
/* 219:    */   {
/* 220:196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 221:197 */     long function_pointer = caps.glGetUniformui64vNV;
/* 222:198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 223:199 */     BufferChecks.checkBuffer(params, 1);
/* 224:200 */     nglGetUniformui64vNV(program, location, MemoryUtil.getAddress(params), function_pointer);
/* 225:    */   }
/* 226:    */   
/* 227:    */   static native void nglGetUniformui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 228:    */   
/* 229:    */   public static void glProgramUniform1i64NV(int program, int location, long x)
/* 230:    */   {
/* 231:205 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 232:206 */     long function_pointer = caps.glProgramUniform1i64NV;
/* 233:207 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 234:208 */     nglProgramUniform1i64NV(program, location, x, function_pointer);
/* 235:    */   }
/* 236:    */   
/* 237:    */   static native void nglProgramUniform1i64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 238:    */   
/* 239:    */   public static void glProgramUniform2i64NV(int program, int location, long x, long y)
/* 240:    */   {
/* 241:213 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 242:214 */     long function_pointer = caps.glProgramUniform2i64NV;
/* 243:215 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 244:216 */     nglProgramUniform2i64NV(program, location, x, y, function_pointer);
/* 245:    */   }
/* 246:    */   
/* 247:    */   static native void nglProgramUniform2i64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 248:    */   
/* 249:    */   public static void glProgramUniform3i64NV(int program, int location, long x, long y, long z)
/* 250:    */   {
/* 251:221 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 252:222 */     long function_pointer = caps.glProgramUniform3i64NV;
/* 253:223 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 254:224 */     nglProgramUniform3i64NV(program, location, x, y, z, function_pointer);
/* 255:    */   }
/* 256:    */   
/* 257:    */   static native void nglProgramUniform3i64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 258:    */   
/* 259:    */   public static void glProgramUniform4i64NV(int program, int location, long x, long y, long z, long w)
/* 260:    */   {
/* 261:229 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 262:230 */     long function_pointer = caps.glProgramUniform4i64NV;
/* 263:231 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 264:232 */     nglProgramUniform4i64NV(program, location, x, y, z, w, function_pointer);
/* 265:    */   }
/* 266:    */   
/* 267:    */   static native void nglProgramUniform4i64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 268:    */   
/* 269:    */   public static void glProgramUniform1NV(int program, int location, LongBuffer value)
/* 270:    */   {
/* 271:237 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 272:238 */     long function_pointer = caps.glProgramUniform1i64vNV;
/* 273:239 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 274:240 */     BufferChecks.checkDirect(value);
/* 275:241 */     nglProgramUniform1i64vNV(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 276:    */   }
/* 277:    */   
/* 278:    */   static native void nglProgramUniform1i64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 279:    */   
/* 280:    */   public static void glProgramUniform2NV(int program, int location, LongBuffer value)
/* 281:    */   {
/* 282:246 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 283:247 */     long function_pointer = caps.glProgramUniform2i64vNV;
/* 284:248 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 285:249 */     BufferChecks.checkDirect(value);
/* 286:250 */     nglProgramUniform2i64vNV(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 287:    */   }
/* 288:    */   
/* 289:    */   static native void nglProgramUniform2i64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 290:    */   
/* 291:    */   public static void glProgramUniform3NV(int program, int location, LongBuffer value)
/* 292:    */   {
/* 293:255 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 294:256 */     long function_pointer = caps.glProgramUniform3i64vNV;
/* 295:257 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 296:258 */     BufferChecks.checkDirect(value);
/* 297:259 */     nglProgramUniform3i64vNV(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 298:    */   }
/* 299:    */   
/* 300:    */   static native void nglProgramUniform3i64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 301:    */   
/* 302:    */   public static void glProgramUniform4NV(int program, int location, LongBuffer value)
/* 303:    */   {
/* 304:264 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 305:265 */     long function_pointer = caps.glProgramUniform4i64vNV;
/* 306:266 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 307:267 */     BufferChecks.checkDirect(value);
/* 308:268 */     nglProgramUniform4i64vNV(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 309:    */   }
/* 310:    */   
/* 311:    */   static native void nglProgramUniform4i64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 312:    */   
/* 313:    */   public static void glProgramUniform1ui64NV(int program, int location, long x)
/* 314:    */   {
/* 315:273 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 316:274 */     long function_pointer = caps.glProgramUniform1ui64NV;
/* 317:275 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 318:276 */     nglProgramUniform1ui64NV(program, location, x, function_pointer);
/* 319:    */   }
/* 320:    */   
/* 321:    */   static native void nglProgramUniform1ui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 322:    */   
/* 323:    */   public static void glProgramUniform2ui64NV(int program, int location, long x, long y)
/* 324:    */   {
/* 325:281 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 326:282 */     long function_pointer = caps.glProgramUniform2ui64NV;
/* 327:283 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 328:284 */     nglProgramUniform2ui64NV(program, location, x, y, function_pointer);
/* 329:    */   }
/* 330:    */   
/* 331:    */   static native void nglProgramUniform2ui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 332:    */   
/* 333:    */   public static void glProgramUniform3ui64NV(int program, int location, long x, long y, long z)
/* 334:    */   {
/* 335:289 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 336:290 */     long function_pointer = caps.glProgramUniform3ui64NV;
/* 337:291 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 338:292 */     nglProgramUniform3ui64NV(program, location, x, y, z, function_pointer);
/* 339:    */   }
/* 340:    */   
/* 341:    */   static native void nglProgramUniform3ui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 342:    */   
/* 343:    */   public static void glProgramUniform4ui64NV(int program, int location, long x, long y, long z, long w)
/* 344:    */   {
/* 345:297 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 346:298 */     long function_pointer = caps.glProgramUniform4ui64NV;
/* 347:299 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 348:300 */     nglProgramUniform4ui64NV(program, location, x, y, z, w, function_pointer);
/* 349:    */   }
/* 350:    */   
/* 351:    */   static native void nglProgramUniform4ui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 352:    */   
/* 353:    */   public static void glProgramUniform1uNV(int program, int location, LongBuffer value)
/* 354:    */   {
/* 355:305 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 356:306 */     long function_pointer = caps.glProgramUniform1ui64vNV;
/* 357:307 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 358:308 */     BufferChecks.checkDirect(value);
/* 359:309 */     nglProgramUniform1ui64vNV(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 360:    */   }
/* 361:    */   
/* 362:    */   static native void nglProgramUniform1ui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 363:    */   
/* 364:    */   public static void glProgramUniform2uNV(int program, int location, LongBuffer value)
/* 365:    */   {
/* 366:314 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 367:315 */     long function_pointer = caps.glProgramUniform2ui64vNV;
/* 368:316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 369:317 */     BufferChecks.checkDirect(value);
/* 370:318 */     nglProgramUniform2ui64vNV(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 371:    */   }
/* 372:    */   
/* 373:    */   static native void nglProgramUniform2ui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 374:    */   
/* 375:    */   public static void glProgramUniform3uNV(int program, int location, LongBuffer value)
/* 376:    */   {
/* 377:323 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 378:324 */     long function_pointer = caps.glProgramUniform3ui64vNV;
/* 379:325 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 380:326 */     BufferChecks.checkDirect(value);
/* 381:327 */     nglProgramUniform3ui64vNV(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 382:    */   }
/* 383:    */   
/* 384:    */   static native void nglProgramUniform3ui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 385:    */   
/* 386:    */   public static void glProgramUniform4uNV(int program, int location, LongBuffer value)
/* 387:    */   {
/* 388:332 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 389:333 */     long function_pointer = caps.glProgramUniform4ui64vNV;
/* 390:334 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 391:335 */     BufferChecks.checkDirect(value);
/* 392:336 */     nglProgramUniform4ui64vNV(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 393:    */   }
/* 394:    */   
/* 395:    */   static native void nglProgramUniform4ui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 396:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVGpuShader5
 * JD-Core Version:    0.7.0.1
 */