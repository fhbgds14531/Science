/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ 
/*   6:    */ public final class ARBProgramInterfaceQuery
/*   7:    */ {
/*   8:    */   public static final int GL_UNIFORM = 37601;
/*   9:    */   public static final int GL_UNIFORM_BLOCK = 37602;
/*  10:    */   public static final int GL_PROGRAM_INPUT = 37603;
/*  11:    */   public static final int GL_PROGRAM_OUTPUT = 37604;
/*  12:    */   public static final int GL_BUFFER_VARIABLE = 37605;
/*  13:    */   public static final int GL_SHADER_STORAGE_BLOCK = 37606;
/*  14:    */   public static final int GL_VERTEX_SUBROUTINE = 37608;
/*  15:    */   public static final int GL_TESS_CONTROL_SUBROUTINE = 37609;
/*  16:    */   public static final int GL_TESS_EVALUATION_SUBROUTINE = 37610;
/*  17:    */   public static final int GL_GEOMETRY_SUBROUTINE = 37611;
/*  18:    */   public static final int GL_FRAGMENT_SUBROUTINE = 37612;
/*  19:    */   public static final int GL_COMPUTE_SUBROUTINE = 37613;
/*  20:    */   public static final int GL_VERTEX_SUBROUTINE_UNIFORM = 37614;
/*  21:    */   public static final int GL_TESS_CONTROL_SUBROUTINE_UNIFORM = 37615;
/*  22:    */   public static final int GL_TESS_EVALUATION_SUBROUTINE_UNIFORM = 37616;
/*  23:    */   public static final int GL_GEOMETRY_SUBROUTINE_UNIFORM = 37617;
/*  24:    */   public static final int GL_FRAGMENT_SUBROUTINE_UNIFORM = 37618;
/*  25:    */   public static final int GL_COMPUTE_SUBROUTINE_UNIFORM = 37619;
/*  26:    */   public static final int GL_TRANSFORM_FEEDBACK_VARYING = 37620;
/*  27:    */   public static final int GL_ACTIVE_RESOURCES = 37621;
/*  28:    */   public static final int GL_MAX_NAME_LENGTH = 37622;
/*  29:    */   public static final int GL_MAX_NUM_ACTIVE_VARIABLES = 37623;
/*  30:    */   public static final int GL_MAX_NUM_COMPATIBLE_SUBROUTINES = 37624;
/*  31:    */   public static final int GL_NAME_LENGTH = 37625;
/*  32:    */   public static final int GL_TYPE = 37626;
/*  33:    */   public static final int GL_ARRAY_SIZE = 37627;
/*  34:    */   public static final int GL_OFFSET = 37628;
/*  35:    */   public static final int GL_BLOCK_INDEX = 37629;
/*  36:    */   public static final int GL_ARRAY_STRIDE = 37630;
/*  37:    */   public static final int GL_MATRIX_STRIDE = 37631;
/*  38:    */   public static final int GL_IS_ROW_MAJOR = 37632;
/*  39:    */   public static final int GL_ATOMIC_COUNTER_BUFFER_INDEX = 37633;
/*  40:    */   public static final int GL_BUFFER_BINDING = 37634;
/*  41:    */   public static final int GL_BUFFER_DATA_SIZE = 37635;
/*  42:    */   public static final int GL_NUM_ACTIVE_VARIABLES = 37636;
/*  43:    */   public static final int GL_ACTIVE_VARIABLES = 37637;
/*  44:    */   public static final int GL_REFERENCED_BY_VERTEX_SHADER = 37638;
/*  45:    */   public static final int GL_REFERENCED_BY_TESS_CONTROL_SHADER = 37639;
/*  46:    */   public static final int GL_REFERENCED_BY_TESS_EVALUATION_SHADER = 37640;
/*  47:    */   public static final int GL_REFERENCED_BY_GEOMETRY_SHADER = 37641;
/*  48:    */   public static final int GL_REFERENCED_BY_FRAGMENT_SHADER = 37642;
/*  49:    */   public static final int GL_REFERENCED_BY_COMPUTE_SHADER = 37643;
/*  50:    */   public static final int GL_TOP_LEVEL_ARRAY_SIZE = 37644;
/*  51:    */   public static final int GL_TOP_LEVEL_ARRAY_STRIDE = 37645;
/*  52:    */   public static final int GL_LOCATION = 37646;
/*  53:    */   public static final int GL_LOCATION_INDEX = 37647;
/*  54:    */   public static final int GL_IS_PER_PATCH = 37607;
/*  55:    */   
/*  56:    */   public static void glGetProgramInterface(int program, int programInterface, int pname, IntBuffer params)
/*  57:    */   {
/*  58: 74 */     GL43.glGetProgramInterface(program, programInterface, pname, params);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static int glGetProgramInterfacei(int program, int programInterface, int pname)
/*  62:    */   {
/*  63: 79 */     return GL43.glGetProgramInterfacei(program, programInterface, pname);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static int glGetProgramResourceIndex(int program, int programInterface, ByteBuffer name)
/*  67:    */   {
/*  68: 83 */     return GL43.glGetProgramResourceIndex(program, programInterface, name);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static int glGetProgramResourceIndex(int program, int programInterface, CharSequence name)
/*  72:    */   {
/*  73: 88 */     return GL43.glGetProgramResourceIndex(program, programInterface, name);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static void glGetProgramResourceName(int program, int programInterface, int index, IntBuffer length, ByteBuffer name)
/*  77:    */   {
/*  78: 92 */     GL43.glGetProgramResourceName(program, programInterface, index, length, name);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static String glGetProgramResourceName(int program, int programInterface, int index, int bufSize)
/*  82:    */   {
/*  83: 97 */     return GL43.glGetProgramResourceName(program, programInterface, index, bufSize);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static void glGetProgramResource(int program, int programInterface, int index, IntBuffer props, IntBuffer length, IntBuffer params)
/*  87:    */   {
/*  88:101 */     GL43.glGetProgramResource(program, programInterface, index, props, length, params);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public static int glGetProgramResourceLocation(int program, int programInterface, ByteBuffer name)
/*  92:    */   {
/*  93:105 */     return GL43.glGetProgramResourceLocation(program, programInterface, name);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static int glGetProgramResourceLocation(int program, int programInterface, CharSequence name)
/*  97:    */   {
/*  98:110 */     return GL43.glGetProgramResourceLocation(program, programInterface, name);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static int glGetProgramResourceLocationIndex(int program, int programInterface, ByteBuffer name)
/* 102:    */   {
/* 103:114 */     return GL43.glGetProgramResourceLocationIndex(program, programInterface, name);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static int glGetProgramResourceLocationIndex(int program, int programInterface, CharSequence name)
/* 107:    */   {
/* 108:119 */     return GL43.glGetProgramResourceLocationIndex(program, programInterface, name);
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBProgramInterfaceQuery
 * JD-Core Version:    0.7.0.1
 */