/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferUtils;
/*   5:    */ 
/*   6:    */ public final class RenderTexture
/*   7:    */ {
/*   8:    */   private static final int WGL_BIND_TO_TEXTURE_RGB_ARB = 8304;
/*   9:    */   private static final int WGL_BIND_TO_TEXTURE_RGBA_ARB = 8305;
/*  10:    */   private static final int WGL_TEXTURE_FORMAT_ARB = 8306;
/*  11:    */   private static final int WGL_TEXTURE_TARGET_ARB = 8307;
/*  12:    */   private static final int WGL_MIPMAP_TEXTURE_ARB = 8308;
/*  13:    */   private static final int WGL_TEXTURE_RGB_ARB = 8309;
/*  14:    */   private static final int WGL_TEXTURE_RGBA_ARB = 8310;
/*  15:    */   private static final int WGL_TEXTURE_CUBE_MAP_ARB = 8312;
/*  16:    */   private static final int WGL_TEXTURE_1D_ARB = 8313;
/*  17:    */   private static final int WGL_TEXTURE_2D_ARB = 8314;
/*  18:    */   private static final int WGL_NO_TEXTURE_ARB = 8311;
/*  19:    */   static final int WGL_MIPMAP_LEVEL_ARB = 8315;
/*  20:    */   static final int WGL_CUBE_MAP_FACE_ARB = 8316;
/*  21:    */   static final int WGL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB = 8317;
/*  22:    */   static final int WGL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB = 8318;
/*  23:    */   static final int WGL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB = 8319;
/*  24:    */   static final int WGL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB = 8320;
/*  25:    */   static final int WGL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB = 8321;
/*  26:    */   static final int WGL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB = 8322;
/*  27:    */   static final int WGL_FRONT_LEFT_ARB = 8323;
/*  28:    */   static final int WGL_FRONT_RIGHT_ARB = 8324;
/*  29:    */   static final int WGL_BACK_LEFT_ARB = 8325;
/*  30:    */   static final int WGL_BACK_RIGHT_ARB = 8326;
/*  31:    */   private static final int WGL_BIND_TO_TEXTURE_RECTANGLE_RGB_NV = 8352;
/*  32:    */   private static final int WGL_BIND_TO_TEXTURE_RECTANGLE_RGBA_NV = 8353;
/*  33:    */   private static final int WGL_TEXTURE_RECTANGLE_NV = 8354;
/*  34:    */   private static final int WGL_BIND_TO_TEXTURE_DEPTH_NV = 8355;
/*  35:    */   private static final int WGL_BIND_TO_TEXTURE_RECTANGLE_DEPTH_NV = 8356;
/*  36:    */   private static final int WGL_DEPTH_TEXTURE_FORMAT_NV = 8357;
/*  37:    */   private static final int WGL_TEXTURE_DEPTH_COMPONENT_NV = 8358;
/*  38:    */   static final int WGL_DEPTH_COMPONENT_NV = 8359;
/*  39:    */   public static final int RENDER_TEXTURE_1D = 8313;
/*  40:    */   public static final int RENDER_TEXTURE_2D = 8314;
/*  41:    */   public static final int RENDER_TEXTURE_RECTANGLE = 8354;
/*  42:    */   public static final int RENDER_TEXTURE_CUBE_MAP = 8312;
/*  43:    */   IntBuffer pixelFormatCaps;
/*  44:    */   IntBuffer pBufferAttribs;
/*  45:    */   
/*  46:    */   public RenderTexture(boolean useRGB, boolean useRGBA, boolean useDepth, boolean isRectangle, int target, int mipmaps)
/*  47:    */   {
/*  48:205 */     if ((useRGB) && (useRGBA)) {
/*  49:206 */       throw new IllegalArgumentException("A RenderTexture can't be both RGB and RGBA.");
/*  50:    */     }
/*  51:208 */     if (mipmaps < 0) {
/*  52:209 */       throw new IllegalArgumentException("The mipmap levels can't be negative.");
/*  53:    */     }
/*  54:211 */     if ((isRectangle) && (target != 8354)) {
/*  55:212 */       throw new IllegalArgumentException("When the RenderTexture is rectangle the target must be RENDER_TEXTURE_RECTANGLE.");
/*  56:    */     }
/*  57:214 */     this.pixelFormatCaps = BufferUtils.createIntBuffer(4);
/*  58:215 */     this.pBufferAttribs = BufferUtils.createIntBuffer(8);
/*  59:217 */     if (useRGB)
/*  60:    */     {
/*  61:218 */       this.pixelFormatCaps.put(isRectangle ? 8352 : 8304);
/*  62:219 */       this.pixelFormatCaps.put(1);
/*  63:    */       
/*  64:221 */       this.pBufferAttribs.put(8306);
/*  65:222 */       this.pBufferAttribs.put(8309);
/*  66:    */     }
/*  67:223 */     else if (useRGBA)
/*  68:    */     {
/*  69:224 */       this.pixelFormatCaps.put(isRectangle ? 8353 : 8305);
/*  70:225 */       this.pixelFormatCaps.put(1);
/*  71:    */       
/*  72:227 */       this.pBufferAttribs.put(8306);
/*  73:228 */       this.pBufferAttribs.put(8310);
/*  74:    */     }
/*  75:231 */     if (useDepth)
/*  76:    */     {
/*  77:232 */       this.pixelFormatCaps.put(isRectangle ? 8356 : 8355);
/*  78:233 */       this.pixelFormatCaps.put(1);
/*  79:    */       
/*  80:235 */       this.pBufferAttribs.put(8357);
/*  81:236 */       this.pBufferAttribs.put(8358);
/*  82:    */     }
/*  83:239 */     this.pBufferAttribs.put(8307);
/*  84:240 */     this.pBufferAttribs.put(target);
/*  85:242 */     if (mipmaps != 0)
/*  86:    */     {
/*  87:243 */       this.pBufferAttribs.put(8308);
/*  88:244 */       this.pBufferAttribs.put(mipmaps);
/*  89:    */     }
/*  90:247 */     this.pixelFormatCaps.flip();
/*  91:248 */     this.pBufferAttribs.flip();
/*  92:    */   }
/*  93:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.RenderTexture
 * JD-Core Version:    0.7.0.1
 */