/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class NVTransformFeedback
/*   9:    */ {
/*  10:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_NV = 35982;
/*  11:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_START_NV = 35972;
/*  12:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_SIZE_NV = 35973;
/*  13:    */   public static final int GL_TRANSFORM_FEEDBACK_RECORD_NV = 35974;
/*  14:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_BINDING_NV = 35983;
/*  15:    */   public static final int GL_INTERLEAVED_ATTRIBS_NV = 35980;
/*  16:    */   public static final int GL_SEPARATE_ATTRIBS_NV = 35981;
/*  17:    */   public static final int GL_PRIMITIVES_GENERATED_NV = 35975;
/*  18:    */   public static final int GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_NV = 35976;
/*  19:    */   public static final int GL_RASTERIZER_DISCARD_NV = 35977;
/*  20:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_NV = 35978;
/*  21:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_NV = 35979;
/*  22:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_NV = 35968;
/*  23:    */   public static final int GL_TRANSFORM_FEEDBACK_ATTRIBS_NV = 35966;
/*  24:    */   public static final int GL_ACTIVE_VARYINGS_NV = 35969;
/*  25:    */   public static final int GL_ACTIVE_VARYING_MAX_LENGTH_NV = 35970;
/*  26:    */   public static final int GL_TRANSFORM_FEEDBACK_VARYINGS_NV = 35971;
/*  27:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_MODE_NV = 35967;
/*  28:    */   public static final int GL_BACK_PRIMARY_COLOR_NV = 35959;
/*  29:    */   public static final int GL_BACK_SECONDARY_COLOR_NV = 35960;
/*  30:    */   public static final int GL_TEXTURE_COORD_NV = 35961;
/*  31:    */   public static final int GL_CLIP_DISTANCE_NV = 35962;
/*  32:    */   public static final int GL_VERTEX_ID_NV = 35963;
/*  33:    */   public static final int GL_PRIMITIVE_ID_NV = 35964;
/*  34:    */   public static final int GL_GENERIC_ATTRIB_NV = 35965;
/*  35:    */   public static final int GL_LAYER_NV = 36266;
/*  36:    */   
/*  37:    */   public static void glBindBufferRangeNV(int target, int index, int buffer, long offset, long size)
/*  38:    */   {
/*  39: 91 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  40: 92 */     long function_pointer = caps.glBindBufferRangeNV;
/*  41: 93 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  42: 94 */     nglBindBufferRangeNV(target, index, buffer, offset, size, function_pointer);
/*  43:    */   }
/*  44:    */   
/*  45:    */   static native void nglBindBufferRangeNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/*  46:    */   
/*  47:    */   public static void glBindBufferOffsetNV(int target, int index, int buffer, long offset)
/*  48:    */   {
/*  49: 99 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  50:100 */     long function_pointer = caps.glBindBufferOffsetNV;
/*  51:101 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  52:102 */     nglBindBufferOffsetNV(target, index, buffer, offset, function_pointer);
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native void nglBindBufferOffsetNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  56:    */   
/*  57:    */   public static void glBindBufferBaseNV(int target, int index, int buffer)
/*  58:    */   {
/*  59:107 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60:108 */     long function_pointer = caps.glBindBufferBaseNV;
/*  61:109 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62:110 */     nglBindBufferBaseNV(target, index, buffer, function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   static native void nglBindBufferBaseNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  66:    */   
/*  67:    */   public static void glTransformFeedbackAttribsNV(IntBuffer attribs, int bufferMode)
/*  68:    */   {
/*  69:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  70:116 */     long function_pointer = caps.glTransformFeedbackAttribsNV;
/*  71:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  72:118 */     BufferChecks.checkBuffer(attribs, 3);
/*  73:119 */     nglTransformFeedbackAttribsNV(attribs.remaining() / 3, MemoryUtil.getAddress(attribs), bufferMode, function_pointer);
/*  74:    */   }
/*  75:    */   
/*  76:    */   static native void nglTransformFeedbackAttribsNV(int paramInt1, long paramLong1, int paramInt2, long paramLong2);
/*  77:    */   
/*  78:    */   public static void glTransformFeedbackVaryingsNV(int program, IntBuffer locations, int bufferMode)
/*  79:    */   {
/*  80:124 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  81:125 */     long function_pointer = caps.glTransformFeedbackVaryingsNV;
/*  82:126 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  83:127 */     BufferChecks.checkDirect(locations);
/*  84:128 */     nglTransformFeedbackVaryingsNV(program, locations.remaining(), MemoryUtil.getAddress(locations), bufferMode, function_pointer);
/*  85:    */   }
/*  86:    */   
/*  87:    */   static native void nglTransformFeedbackVaryingsNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  88:    */   
/*  89:    */   public static void glBeginTransformFeedbackNV(int primitiveMode)
/*  90:    */   {
/*  91:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  92:134 */     long function_pointer = caps.glBeginTransformFeedbackNV;
/*  93:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  94:136 */     nglBeginTransformFeedbackNV(primitiveMode, function_pointer);
/*  95:    */   }
/*  96:    */   
/*  97:    */   static native void nglBeginTransformFeedbackNV(int paramInt, long paramLong);
/*  98:    */   
/*  99:    */   public static void glEndTransformFeedbackNV()
/* 100:    */   {
/* 101:141 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 102:142 */     long function_pointer = caps.glEndTransformFeedbackNV;
/* 103:143 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 104:144 */     nglEndTransformFeedbackNV(function_pointer);
/* 105:    */   }
/* 106:    */   
/* 107:    */   static native void nglEndTransformFeedbackNV(long paramLong);
/* 108:    */   
/* 109:    */   public static int glGetVaryingLocationNV(int program, ByteBuffer name)
/* 110:    */   {
/* 111:149 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 112:150 */     long function_pointer = caps.glGetVaryingLocationNV;
/* 113:151 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 114:152 */     BufferChecks.checkDirect(name);
/* 115:153 */     BufferChecks.checkNullTerminated(name);
/* 116:154 */     int __result = nglGetVaryingLocationNV(program, MemoryUtil.getAddress(name), function_pointer);
/* 117:155 */     return __result;
/* 118:    */   }
/* 119:    */   
/* 120:    */   static native int nglGetVaryingLocationNV(int paramInt, long paramLong1, long paramLong2);
/* 121:    */   
/* 122:    */   public static int glGetVaryingLocationNV(int program, CharSequence name)
/* 123:    */   {
/* 124:161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:162 */     long function_pointer = caps.glGetVaryingLocationNV;
/* 126:163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:164 */     int __result = nglGetVaryingLocationNV(program, APIUtil.getBufferNT(caps, name), function_pointer);
/* 128:165 */     return __result;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static void glGetActiveVaryingNV(int program, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/* 132:    */   {
/* 133:169 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 134:170 */     long function_pointer = caps.glGetActiveVaryingNV;
/* 135:171 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 136:172 */     if (length != null) {
/* 137:173 */       BufferChecks.checkBuffer(length, 1);
/* 138:    */     }
/* 139:174 */     BufferChecks.checkBuffer(size, 1);
/* 140:175 */     BufferChecks.checkBuffer(type, 1);
/* 141:176 */     BufferChecks.checkDirect(name);
/* 142:177 */     nglGetActiveVaryingNV(program, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 143:    */   }
/* 144:    */   
/* 145:    */   static native void nglGetActiveVaryingNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 146:    */   
/* 147:    */   public static String glGetActiveVaryingNV(int program, int index, int bufSize, IntBuffer sizeType)
/* 148:    */   {
/* 149:187 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:188 */     long function_pointer = caps.glGetActiveVaryingNV;
/* 151:189 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:190 */     BufferChecks.checkBuffer(sizeType, 2);
/* 153:191 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 154:192 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufSize);
/* 155:193 */     nglGetActiveVaryingNV(program, index, bufSize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(sizeType), MemoryUtil.getAddress(sizeType, sizeType.position() + 1), MemoryUtil.getAddress(name), function_pointer);
/* 156:194 */     name.limit(name_length.get(0));
/* 157:195 */     return APIUtil.getString(caps, name);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static String glGetActiveVaryingNV(int program, int index, int bufSize)
/* 161:    */   {
/* 162:204 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 163:205 */     long function_pointer = caps.glGetActiveVaryingNV;
/* 164:206 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 165:207 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 166:208 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufSize);
/* 167:209 */     nglGetActiveVaryingNV(program, index, bufSize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress0(APIUtil.getBufferInt(caps)), MemoryUtil.getAddress(APIUtil.getBufferInt(caps), 1), MemoryUtil.getAddress(name), function_pointer);
/* 168:210 */     name.limit(name_length.get(0));
/* 169:211 */     return APIUtil.getString(caps, name);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static int glGetActiveVaryingSizeNV(int program, int index)
/* 173:    */   {
/* 174:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 175:221 */     long function_pointer = caps.glGetActiveVaryingNV;
/* 176:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 177:223 */     IntBuffer size = APIUtil.getBufferInt(caps);
/* 178:224 */     nglGetActiveVaryingNV(program, index, 0, 0L, MemoryUtil.getAddress(size), MemoryUtil.getAddress(size, 1), APIUtil.getBufferByte0(caps), function_pointer);
/* 179:225 */     return size.get(0);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static int glGetActiveVaryingTypeNV(int program, int index)
/* 183:    */   {
/* 184:234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 185:235 */     long function_pointer = caps.glGetActiveVaryingNV;
/* 186:236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 187:237 */     IntBuffer type = APIUtil.getBufferInt(caps);
/* 188:238 */     nglGetActiveVaryingNV(program, index, 0, 0L, MemoryUtil.getAddress(type, 1), MemoryUtil.getAddress(type), APIUtil.getBufferByte0(caps), function_pointer);
/* 189:239 */     return type.get(0);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static void glActiveVaryingNV(int program, ByteBuffer name)
/* 193:    */   {
/* 194:243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 195:244 */     long function_pointer = caps.glActiveVaryingNV;
/* 196:245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 197:246 */     BufferChecks.checkDirect(name);
/* 198:247 */     BufferChecks.checkNullTerminated(name);
/* 199:248 */     nglActiveVaryingNV(program, MemoryUtil.getAddress(name), function_pointer);
/* 200:    */   }
/* 201:    */   
/* 202:    */   static native void nglActiveVaryingNV(int paramInt, long paramLong1, long paramLong2);
/* 203:    */   
/* 204:    */   public static void glActiveVaryingNV(int program, CharSequence name)
/* 205:    */   {
/* 206:254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 207:255 */     long function_pointer = caps.glActiveVaryingNV;
/* 208:256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 209:257 */     nglActiveVaryingNV(program, APIUtil.getBufferNT(caps, name), function_pointer);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static void glGetTransformFeedbackVaryingNV(int program, int index, IntBuffer location)
/* 213:    */   {
/* 214:261 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 215:262 */     long function_pointer = caps.glGetTransformFeedbackVaryingNV;
/* 216:263 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 217:264 */     BufferChecks.checkBuffer(location, 1);
/* 218:265 */     nglGetTransformFeedbackVaryingNV(program, index, MemoryUtil.getAddress(location), function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglGetTransformFeedbackVaryingNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 222:    */   
/* 223:    */   public static int glGetTransformFeedbackVaryingNV(int program, int index)
/* 224:    */   {
/* 225:271 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:272 */     long function_pointer = caps.glGetTransformFeedbackVaryingNV;
/* 227:273 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:274 */     IntBuffer location = APIUtil.getBufferInt(caps);
/* 229:275 */     nglGetTransformFeedbackVaryingNV(program, index, MemoryUtil.getAddress(location), function_pointer);
/* 230:276 */     return location.get(0);
/* 231:    */   }
/* 232:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTransformFeedback
 * JD-Core Version:    0.7.0.1
 */