/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class ATIVertexArrayObject
/*  12:    */ {
/*  13:    */   public static final int GL_STATIC_ATI = 34656;
/*  14:    */   public static final int GL_DYNAMIC_ATI = 34657;
/*  15:    */   public static final int GL_PRESERVE_ATI = 34658;
/*  16:    */   public static final int GL_DISCARD_ATI = 34659;
/*  17:    */   public static final int GL_OBJECT_BUFFER_SIZE_ATI = 34660;
/*  18:    */   public static final int GL_OBJECT_BUFFER_USAGE_ATI = 34661;
/*  19:    */   public static final int GL_ARRAY_OBJECT_BUFFER_ATI = 34662;
/*  20:    */   public static final int GL_ARRAY_OBJECT_OFFSET_ATI = 34663;
/*  21:    */   
/*  22:    */   public static int glNewObjectBufferATI(int pPointer_size, int usage)
/*  23:    */   {
/*  24: 22 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  25: 23 */     long function_pointer = caps.glNewObjectBufferATI;
/*  26: 24 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  27: 25 */     int __result = nglNewObjectBufferATI(pPointer_size, 0L, usage, function_pointer);
/*  28: 26 */     return __result;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static int glNewObjectBufferATI(ByteBuffer pPointer, int usage)
/*  32:    */   {
/*  33: 29 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  34: 30 */     long function_pointer = caps.glNewObjectBufferATI;
/*  35: 31 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  36: 32 */     BufferChecks.checkDirect(pPointer);
/*  37: 33 */     int __result = nglNewObjectBufferATI(pPointer.remaining(), MemoryUtil.getAddress(pPointer), usage, function_pointer);
/*  38: 34 */     return __result;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static int glNewObjectBufferATI(DoubleBuffer pPointer, int usage)
/*  42:    */   {
/*  43: 37 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  44: 38 */     long function_pointer = caps.glNewObjectBufferATI;
/*  45: 39 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  46: 40 */     BufferChecks.checkDirect(pPointer);
/*  47: 41 */     int __result = nglNewObjectBufferATI(pPointer.remaining() << 3, MemoryUtil.getAddress(pPointer), usage, function_pointer);
/*  48: 42 */     return __result;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static int glNewObjectBufferATI(FloatBuffer pPointer, int usage)
/*  52:    */   {
/*  53: 45 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  54: 46 */     long function_pointer = caps.glNewObjectBufferATI;
/*  55: 47 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  56: 48 */     BufferChecks.checkDirect(pPointer);
/*  57: 49 */     int __result = nglNewObjectBufferATI(pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), usage, function_pointer);
/*  58: 50 */     return __result;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static int glNewObjectBufferATI(IntBuffer pPointer, int usage)
/*  62:    */   {
/*  63: 53 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  64: 54 */     long function_pointer = caps.glNewObjectBufferATI;
/*  65: 55 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  66: 56 */     BufferChecks.checkDirect(pPointer);
/*  67: 57 */     int __result = nglNewObjectBufferATI(pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), usage, function_pointer);
/*  68: 58 */     return __result;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static int glNewObjectBufferATI(ShortBuffer pPointer, int usage)
/*  72:    */   {
/*  73: 61 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  74: 62 */     long function_pointer = caps.glNewObjectBufferATI;
/*  75: 63 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  76: 64 */     BufferChecks.checkDirect(pPointer);
/*  77: 65 */     int __result = nglNewObjectBufferATI(pPointer.remaining() << 1, MemoryUtil.getAddress(pPointer), usage, function_pointer);
/*  78: 66 */     return __result;
/*  79:    */   }
/*  80:    */   
/*  81:    */   static native int nglNewObjectBufferATI(int paramInt1, long paramLong1, int paramInt2, long paramLong2);
/*  82:    */   
/*  83:    */   public static boolean glIsObjectBufferATI(int buffer)
/*  84:    */   {
/*  85: 71 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  86: 72 */     long function_pointer = caps.glIsObjectBufferATI;
/*  87: 73 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  88: 74 */     boolean __result = nglIsObjectBufferATI(buffer, function_pointer);
/*  89: 75 */     return __result;
/*  90:    */   }
/*  91:    */   
/*  92:    */   static native boolean nglIsObjectBufferATI(int paramInt, long paramLong);
/*  93:    */   
/*  94:    */   public static void glUpdateObjectBufferATI(int buffer, int offset, ByteBuffer pPointer, int preserve)
/*  95:    */   {
/*  96: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  97: 81 */     long function_pointer = caps.glUpdateObjectBufferATI;
/*  98: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  99: 83 */     BufferChecks.checkDirect(pPointer);
/* 100: 84 */     nglUpdateObjectBufferATI(buffer, offset, pPointer.remaining(), MemoryUtil.getAddress(pPointer), preserve, function_pointer);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void glUpdateObjectBufferATI(int buffer, int offset, DoubleBuffer pPointer, int preserve)
/* 104:    */   {
/* 105: 87 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106: 88 */     long function_pointer = caps.glUpdateObjectBufferATI;
/* 107: 89 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108: 90 */     BufferChecks.checkDirect(pPointer);
/* 109: 91 */     nglUpdateObjectBufferATI(buffer, offset, pPointer.remaining() << 3, MemoryUtil.getAddress(pPointer), preserve, function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void glUpdateObjectBufferATI(int buffer, int offset, FloatBuffer pPointer, int preserve)
/* 113:    */   {
/* 114: 94 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115: 95 */     long function_pointer = caps.glUpdateObjectBufferATI;
/* 116: 96 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117: 97 */     BufferChecks.checkDirect(pPointer);
/* 118: 98 */     nglUpdateObjectBufferATI(buffer, offset, pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), preserve, function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static void glUpdateObjectBufferATI(int buffer, int offset, IntBuffer pPointer, int preserve)
/* 122:    */   {
/* 123:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 124:102 */     long function_pointer = caps.glUpdateObjectBufferATI;
/* 125:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:104 */     BufferChecks.checkDirect(pPointer);
/* 127:105 */     nglUpdateObjectBufferATI(buffer, offset, pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), preserve, function_pointer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void glUpdateObjectBufferATI(int buffer, int offset, ShortBuffer pPointer, int preserve)
/* 131:    */   {
/* 132:108 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 133:109 */     long function_pointer = caps.glUpdateObjectBufferATI;
/* 134:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 135:111 */     BufferChecks.checkDirect(pPointer);
/* 136:112 */     nglUpdateObjectBufferATI(buffer, offset, pPointer.remaining() << 1, MemoryUtil.getAddress(pPointer), preserve, function_pointer);
/* 137:    */   }
/* 138:    */   
/* 139:    */   static native void nglUpdateObjectBufferATI(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 140:    */   
/* 141:    */   public static void glGetObjectBufferATI(int buffer, int pname, FloatBuffer params)
/* 142:    */   {
/* 143:117 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 144:118 */     long function_pointer = caps.glGetObjectBufferfvATI;
/* 145:119 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 146:120 */     BufferChecks.checkDirect(params);
/* 147:121 */     nglGetObjectBufferfvATI(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 148:    */   }
/* 149:    */   
/* 150:    */   static native void nglGetObjectBufferfvATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 151:    */   
/* 152:    */   public static void glGetObjectBufferATI(int buffer, int pname, IntBuffer params)
/* 153:    */   {
/* 154:126 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 155:127 */     long function_pointer = caps.glGetObjectBufferivATI;
/* 156:128 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 157:129 */     BufferChecks.checkDirect(params);
/* 158:130 */     nglGetObjectBufferivATI(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 159:    */   }
/* 160:    */   
/* 161:    */   static native void nglGetObjectBufferivATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 162:    */   
/* 163:    */   public static int glGetObjectBufferiATI(int buffer, int pname)
/* 164:    */   {
/* 165:136 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 166:137 */     long function_pointer = caps.glGetObjectBufferivATI;
/* 167:138 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 168:139 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 169:140 */     nglGetObjectBufferivATI(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 170:141 */     return params.get(0);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static void glFreeObjectBufferATI(int buffer)
/* 174:    */   {
/* 175:145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 176:146 */     long function_pointer = caps.glFreeObjectBufferATI;
/* 177:147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 178:148 */     nglFreeObjectBufferATI(buffer, function_pointer);
/* 179:    */   }
/* 180:    */   
/* 181:    */   static native void nglFreeObjectBufferATI(int paramInt, long paramLong);
/* 182:    */   
/* 183:    */   public static void glArrayObjectATI(int array, int size, int type, int stride, int buffer, int offset)
/* 184:    */   {
/* 185:153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 186:154 */     long function_pointer = caps.glArrayObjectATI;
/* 187:155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 188:156 */     nglArrayObjectATI(array, size, type, stride, buffer, offset, function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglArrayObjectATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 192:    */   
/* 193:    */   public static void glGetArrayObjectATI(int array, int pname, FloatBuffer params)
/* 194:    */   {
/* 195:161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 196:162 */     long function_pointer = caps.glGetArrayObjectfvATI;
/* 197:163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 198:164 */     BufferChecks.checkBuffer(params, 4);
/* 199:165 */     nglGetArrayObjectfvATI(array, pname, MemoryUtil.getAddress(params), function_pointer);
/* 200:    */   }
/* 201:    */   
/* 202:    */   static native void nglGetArrayObjectfvATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 203:    */   
/* 204:    */   public static void glGetArrayObjectATI(int array, int pname, IntBuffer params)
/* 205:    */   {
/* 206:170 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 207:171 */     long function_pointer = caps.glGetArrayObjectivATI;
/* 208:172 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 209:173 */     BufferChecks.checkBuffer(params, 4);
/* 210:174 */     nglGetArrayObjectivATI(array, pname, MemoryUtil.getAddress(params), function_pointer);
/* 211:    */   }
/* 212:    */   
/* 213:    */   static native void nglGetArrayObjectivATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 214:    */   
/* 215:    */   public static void glVariantArrayObjectATI(int id, int type, int stride, int buffer, int offset)
/* 216:    */   {
/* 217:179 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 218:180 */     long function_pointer = caps.glVariantArrayObjectATI;
/* 219:181 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 220:182 */     nglVariantArrayObjectATI(id, type, stride, buffer, offset, function_pointer);
/* 221:    */   }
/* 222:    */   
/* 223:    */   static native void nglVariantArrayObjectATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 224:    */   
/* 225:    */   public static void glGetVariantArrayObjectATI(int id, int pname, FloatBuffer params)
/* 226:    */   {
/* 227:187 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 228:188 */     long function_pointer = caps.glGetVariantArrayObjectfvATI;
/* 229:189 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 230:190 */     BufferChecks.checkBuffer(params, 4);
/* 231:191 */     nglGetVariantArrayObjectfvATI(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 232:    */   }
/* 233:    */   
/* 234:    */   static native void nglGetVariantArrayObjectfvATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 235:    */   
/* 236:    */   public static void glGetVariantArrayObjectATI(int id, int pname, IntBuffer params)
/* 237:    */   {
/* 238:196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 239:197 */     long function_pointer = caps.glGetVariantArrayObjectivATI;
/* 240:198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 241:199 */     BufferChecks.checkBuffer(params, 4);
/* 242:200 */     nglGetVariantArrayObjectivATI(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 243:    */   }
/* 244:    */   
/* 245:    */   static native void nglGetVariantArrayObjectivATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 246:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIVertexArrayObject
 * JD-Core Version:    0.7.0.1
 */