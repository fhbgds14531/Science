package org.lwjgl.opengl;

public final class ARBHalfFloatVertex
{
  public static final int GL_HALF_FLOAT = 5131;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBHalfFloatVertex
 * JD-Core Version:    0.7.0.1
 */