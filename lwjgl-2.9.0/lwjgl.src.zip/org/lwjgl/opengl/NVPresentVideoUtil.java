/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.nio.LongBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.LWJGLUtil;
/*   8:    */ 
/*   9:    */ public final class NVPresentVideoUtil
/*  10:    */ {
/*  11:    */   private static void checkExtension()
/*  12:    */   {
/*  13: 54 */     if ((LWJGLUtil.CHECKS) && (!GLContext.getCapabilities().GL_NV_present_video)) {
/*  14: 55 */       throw new IllegalStateException("NV_present_video is not supported");
/*  15:    */     }
/*  16:    */   }
/*  17:    */   
/*  18:    */   private static ByteBuffer getPeerInfo()
/*  19:    */   {
/*  20: 59 */     return ContextGL.getCurrentContext().getPeerInfo().getHandle();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static int glEnumerateVideoDevicesNV(LongBuffer devices)
/*  24:    */   {
/*  25:    */     
/*  26: 76 */     if (devices != null) {
/*  27: 77 */       BufferChecks.checkBuffer(devices, 1);
/*  28:    */     }
/*  29: 78 */     return nglEnumerateVideoDevicesNV(getPeerInfo(), devices, devices == null ? 0 : devices.position());
/*  30:    */   }
/*  31:    */   
/*  32:    */   private static native int nglEnumerateVideoDevicesNV(ByteBuffer paramByteBuffer, LongBuffer paramLongBuffer, int paramInt);
/*  33:    */   
/*  34:    */   public static boolean glBindVideoDeviceNV(int video_slot, long video_device, IntBuffer attrib_list)
/*  35:    */   {
/*  36:    */     
/*  37: 98 */     if (attrib_list != null) {
/*  38: 99 */       BufferChecks.checkNullTerminated(attrib_list);
/*  39:    */     }
/*  40:100 */     return nglBindVideoDeviceNV(getPeerInfo(), video_slot, video_device, attrib_list, attrib_list == null ? 0 : attrib_list.position());
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static native boolean nglBindVideoDeviceNV(ByteBuffer paramByteBuffer, int paramInt1, long paramLong, IntBuffer paramIntBuffer, int paramInt2);
/*  44:    */   
/*  45:    */   public static boolean glQueryContextNV(int attrib, IntBuffer value)
/*  46:    */   {
/*  47:113 */     checkExtension();
/*  48:    */     
/*  49:115 */     BufferChecks.checkBuffer(value, 1);
/*  50:116 */     ContextGL ctx = ContextGL.getCurrentContext();
/*  51:117 */     return nglQueryContextNV(ctx.getPeerInfo().getHandle(), ctx.getHandle(), attrib, value, value.position());
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static native boolean nglQueryContextNV(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, int paramInt1, IntBuffer paramIntBuffer, int paramInt2);
/*  55:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPresentVideoUtil
 * JD-Core Version:    0.7.0.1
 */