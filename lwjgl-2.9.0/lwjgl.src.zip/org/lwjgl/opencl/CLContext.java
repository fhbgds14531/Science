/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import java.util.List;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ import org.lwjgl.opencl.api.CLImageFormat;
/*   7:    */ import org.lwjgl.opencl.api.Filter;
/*   8:    */ import org.lwjgl.opengl.Drawable;
/*   9:    */ 
/*  10:    */ public final class CLContext
/*  11:    */   extends CLObjectChild<CLPlatform>
/*  12:    */ {
/*  13: 49 */   private static final CLContextUtil util = (CLContextUtil)CLPlatform.getInfoUtilInstance(CLContext.class, "CL_CONTEXT_UTIL");
/*  14:    */   private final CLObjectRegistry<CLCommandQueue> clCommandQueues;
/*  15:    */   private final CLObjectRegistry<CLMem> clMems;
/*  16:    */   private final CLObjectRegistry<CLSampler> clSamplers;
/*  17:    */   private final CLObjectRegistry<CLProgram> clPrograms;
/*  18:    */   private final CLObjectRegistry<CLEvent> clEvents;
/*  19:    */   private long contextCallback;
/*  20:    */   private long printfCallback;
/*  21:    */   
/*  22:    */   CLContext(long pointer, CLPlatform platform)
/*  23:    */   {
/*  24: 62 */     super(pointer, platform);
/*  25: 67 */     if (isValid())
/*  26:    */     {
/*  27: 68 */       this.clCommandQueues = new CLObjectRegistry();
/*  28: 69 */       this.clMems = new CLObjectRegistry();
/*  29: 70 */       this.clSamplers = new CLObjectRegistry();
/*  30: 71 */       this.clPrograms = new CLObjectRegistry();
/*  31: 72 */       this.clEvents = new CLObjectRegistry();
/*  32:    */     }
/*  33:    */     else
/*  34:    */     {
/*  35: 74 */       this.clCommandQueues = null;
/*  36: 75 */       this.clMems = null;
/*  37: 76 */       this.clSamplers = null;
/*  38: 77 */       this.clPrograms = null;
/*  39: 78 */       this.clEvents = null;
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public CLCommandQueue getCLCommandQueue(long id)
/*  44:    */   {
/*  45: 89 */     return (CLCommandQueue)this.clCommandQueues.getObject(id);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public CLMem getCLMem(long id)
/*  49:    */   {
/*  50: 98 */     return (CLMem)this.clMems.getObject(id);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public CLSampler getCLSampler(long id)
/*  54:    */   {
/*  55:107 */     return (CLSampler)this.clSamplers.getObject(id);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public CLProgram getCLProgram(long id)
/*  59:    */   {
/*  60:116 */     return (CLProgram)this.clPrograms.getObject(id);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public CLEvent getCLEvent(long id)
/*  64:    */   {
/*  65:125 */     return (CLEvent)this.clEvents.getObject(id);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static CLContext create(CLPlatform platform, List<CLDevice> devices, IntBuffer errcode_ret)
/*  69:    */     throws LWJGLException
/*  70:    */   {
/*  71:141 */     return create(platform, devices, null, null, errcode_ret);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static CLContext create(CLPlatform platform, List<CLDevice> devices, CLContextCallback pfn_notify, IntBuffer errcode_ret)
/*  75:    */     throws LWJGLException
/*  76:    */   {
/*  77:157 */     return create(platform, devices, pfn_notify, null, errcode_ret);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static CLContext create(CLPlatform platform, List<CLDevice> devices, CLContextCallback pfn_notify, Drawable share_drawable, IntBuffer errcode_ret)
/*  81:    */     throws LWJGLException
/*  82:    */   {
/*  83:173 */     return util.create(platform, devices, pfn_notify, share_drawable, errcode_ret);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static CLContext createFromType(CLPlatform platform, long device_type, IntBuffer errcode_ret)
/*  87:    */     throws LWJGLException
/*  88:    */   {
/*  89:188 */     return util.createFromType(platform, device_type, null, null, errcode_ret);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static CLContext createFromType(CLPlatform platform, long device_type, CLContextCallback pfn_notify, IntBuffer errcode_ret)
/*  93:    */     throws LWJGLException
/*  94:    */   {
/*  95:204 */     return util.createFromType(platform, device_type, pfn_notify, null, errcode_ret);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static CLContext createFromType(CLPlatform platform, long device_type, CLContextCallback pfn_notify, Drawable share_drawable, IntBuffer errcode_ret)
/*  99:    */     throws LWJGLException
/* 100:    */   {
/* 101:220 */     return util.createFromType(platform, device_type, pfn_notify, share_drawable, errcode_ret);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public int getInfoInt(int param_name)
/* 105:    */   {
/* 106:231 */     return util.getInfoInt(this, param_name);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public List<CLDevice> getInfoDevices()
/* 110:    */   {
/* 111:240 */     return util.getInfoDevices(this);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public List<CLImageFormat> getSupportedImageFormats(long flags, int image_type)
/* 115:    */   {
/* 116:244 */     return getSupportedImageFormats(flags, image_type, null);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public List<CLImageFormat> getSupportedImageFormats(long flags, int image_type, Filter<CLImageFormat> filter)
/* 120:    */   {
/* 121:248 */     return util.getSupportedImageFormats(this, flags, image_type, filter);
/* 122:    */   }
/* 123:    */   
/* 124:    */   CLObjectRegistry<CLCommandQueue> getCLCommandQueueRegistry()
/* 125:    */   {
/* 126:266 */     return this.clCommandQueues;
/* 127:    */   }
/* 128:    */   
/* 129:    */   CLObjectRegistry<CLMem> getCLMemRegistry()
/* 130:    */   {
/* 131:268 */     return this.clMems;
/* 132:    */   }
/* 133:    */   
/* 134:    */   CLObjectRegistry<CLSampler> getCLSamplerRegistry()
/* 135:    */   {
/* 136:270 */     return this.clSamplers;
/* 137:    */   }
/* 138:    */   
/* 139:    */   CLObjectRegistry<CLProgram> getCLProgramRegistry()
/* 140:    */   {
/* 141:272 */     return this.clPrograms;
/* 142:    */   }
/* 143:    */   
/* 144:    */   CLObjectRegistry<CLEvent> getCLEventRegistry()
/* 145:    */   {
/* 146:274 */     return this.clEvents;
/* 147:    */   }
/* 148:    */   
/* 149:    */   private boolean checkCallback(long callback, int result)
/* 150:    */   {
/* 151:277 */     if ((result == 0) && ((callback == 0L) || (isValid()))) {
/* 152:278 */       return true;
/* 153:    */     }
/* 154:280 */     if (callback != 0L) {
/* 155:281 */       CallbackUtil.deleteGlobalRef(callback);
/* 156:    */     }
/* 157:282 */     return false;
/* 158:    */   }
/* 159:    */   
/* 160:    */   void setContextCallback(long callback)
/* 161:    */   {
/* 162:292 */     if (checkCallback(callback, 0)) {
/* 163:293 */       this.contextCallback = callback;
/* 164:    */     }
/* 165:    */   }
/* 166:    */   
/* 167:    */   void setPrintfCallback(long callback, int result)
/* 168:    */   {
/* 169:303 */     if (checkCallback(callback, result)) {
/* 170:304 */       this.printfCallback = callback;
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   void releaseImpl()
/* 175:    */   {
/* 176:313 */     if (release() > 0) {
/* 177:314 */       return;
/* 178:    */     }
/* 179:316 */     if (this.contextCallback != 0L) {
/* 180:317 */       CallbackUtil.deleteGlobalRef(this.contextCallback);
/* 181:    */     }
/* 182:318 */     if (this.printfCallback != 0L) {
/* 183:319 */       CallbackUtil.deleteGlobalRef(this.printfCallback);
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   static abstract interface CLContextUtil
/* 188:    */     extends InfoUtil<CLContext>
/* 189:    */   {
/* 190:    */     public abstract List<CLDevice> getInfoDevices(CLContext paramCLContext);
/* 191:    */     
/* 192:    */     public abstract CLContext create(CLPlatform paramCLPlatform, List<CLDevice> paramList, CLContextCallback paramCLContextCallback, Drawable paramDrawable, IntBuffer paramIntBuffer)
/* 193:    */       throws LWJGLException;
/* 194:    */     
/* 195:    */     public abstract CLContext createFromType(CLPlatform paramCLPlatform, long paramLong, CLContextCallback paramCLContextCallback, Drawable paramDrawable, IntBuffer paramIntBuffer)
/* 196:    */       throws LWJGLException;
/* 197:    */     
/* 198:    */     public abstract List<CLImageFormat> getSupportedImageFormats(CLContext paramCLContext, long paramLong, int paramInt, Filter<CLImageFormat> paramFilter);
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLContext
 * JD-Core Version:    0.7.0.1
 */