package org.lwjgl.opencl;

public final class KHRDepthImages
{
  public static final int CL_DEPTH = 4285;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRDepthImages
 * JD-Core Version:    0.7.0.1
 */