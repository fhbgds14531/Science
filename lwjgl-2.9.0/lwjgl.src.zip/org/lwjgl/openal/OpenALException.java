/*  1:   */ package org.lwjgl.openal;
/*  2:   */ 
/*  3:   */ public class OpenALException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public OpenALException() {}
/*  9:   */   
/* 10:   */   public OpenALException(int error_code)
/* 11:   */   {
/* 12:58 */     super("OpenAL error: " + AL10.alGetString(error_code) + " (" + error_code + ")");
/* 13:   */   }
/* 14:   */   
/* 15:   */   public OpenALException(String message)
/* 16:   */   {
/* 17:66 */     super(message);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public OpenALException(String message, Throwable cause)
/* 21:   */   {
/* 22:75 */     super(message, cause);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public OpenALException(Throwable cause)
/* 26:   */   {
/* 27:83 */     super(cause);
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.OpenALException
 * JD-Core Version:    0.7.0.1
 */