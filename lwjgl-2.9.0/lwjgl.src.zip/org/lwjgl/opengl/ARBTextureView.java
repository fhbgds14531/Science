/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBTextureView
/*  4:   */ {
/*  5:   */   public static final int GL_TEXTURE_VIEW_MIN_LEVEL = 33499;
/*  6:   */   public static final int GL_TEXTURE_VIEW_NUM_LEVELS = 33500;
/*  7:   */   public static final int GL_TEXTURE_VIEW_MIN_LAYER = 33501;
/*  8:   */   public static final int GL_TEXTURE_VIEW_NUM_LAYERS = 33502;
/*  9:   */   public static final int GL_TEXTURE_IMMUTABLE_LEVELS = 33503;
/* 10:   */   
/* 11:   */   public static void glTextureView(int texture, int target, int origtexture, int internalformat, int minlevel, int numlevels, int minlayer, int numlayers)
/* 12:   */   {
/* 13:23 */     GL43.glTextureView(texture, target, origtexture, internalformat, minlevel, numlevels, minlayer, numlayers);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureView
 * JD-Core Version:    0.7.0.1
 */