package org.lwjgl.opengl;

public final class EXTSharedTexturePalette
{
  public static final int GL_SHARED_TEXTURE_PALETTE_EXT = 33275;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTSharedTexturePalette
 * JD-Core Version:    0.7.0.1
 */