package org.lwjgl.opengl;

public final class EXTPixelBufferObject
  extends ARBBufferObject
{
  public static final int GL_PIXEL_PACK_BUFFER_EXT = 35051;
  public static final int GL_PIXEL_UNPACK_BUFFER_EXT = 35052;
  public static final int GL_PIXEL_PACK_BUFFER_BINDING_EXT = 35053;
  public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTPixelBufferObject
 * JD-Core Version:    0.7.0.1
 */