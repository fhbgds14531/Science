/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import org.lwjgl.PointerWrapperAbstract;
/*   6:    */ 
/*   7:    */ public final class AMDDebugOutputCallback
/*   8:    */   extends PointerWrapperAbstract
/*   9:    */ {
/*  10:    */   private static final int GL_DEBUG_SEVERITY_HIGH_AMD = 37190;
/*  11:    */   private static final int GL_DEBUG_SEVERITY_MEDIUM_AMD = 37191;
/*  12:    */   private static final int GL_DEBUG_SEVERITY_LOW_AMD = 37192;
/*  13:    */   private static final int GL_DEBUG_CATEGORY_API_ERROR_AMD = 37193;
/*  14:    */   private static final int GL_DEBUG_CATEGORY_WINDOW_SYSTEM_AMD = 37194;
/*  15:    */   private static final int GL_DEBUG_CATEGORY_DEPRECATION_AMD = 37195;
/*  16:    */   private static final int GL_DEBUG_CATEGORY_UNDEFINED_BEHAVIOR_AMD = 37196;
/*  17:    */   private static final int GL_DEBUG_CATEGORY_PERFORMANCE_AMD = 37197;
/*  18:    */   private static final int GL_DEBUG_CATEGORY_SHADER_COMPILER_AMD = 37198;
/*  19:    */   private static final int GL_DEBUG_CATEGORY_APPLICATION_AMD = 37199;
/*  20:    */   private static final int GL_DEBUG_CATEGORY_OTHER_AMD = 37200;
/*  21:    */   private static final long CALLBACK_POINTER;
/*  22:    */   private final Handler handler;
/*  23:    */   
/*  24:    */   static
/*  25:    */   {
/*  26: 64 */     long pointer = 0L;
/*  27:    */     try
/*  28:    */     {
/*  29: 67 */       pointer = ((Long)Class.forName("org.lwjgl.opengl.CallbackUtil").getDeclaredMethod("getDebugOutputCallbackAMD", new Class[0]).invoke(null, new Object[0])).longValue();
/*  30:    */     }
/*  31:    */     catch (Exception e) {}
/*  32: 71 */     CALLBACK_POINTER = pointer;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public AMDDebugOutputCallback()
/*  36:    */   {
/*  37: 81 */     this(new Handler()
/*  38:    */     {
/*  39:    */       public void handleMessage(int id, int category, int severity, String message)
/*  40:    */       {
/*  41: 83 */         System.err.println("[LWJGL] AMD_debug_output message");
/*  42: 84 */         System.err.println("\tID: " + id);
/*  43:    */         String description;
/*  44: 87 */         switch (category)
/*  45:    */         {
/*  46:    */         case 37193: 
/*  47: 89 */           description = "API ERROR";
/*  48: 90 */           break;
/*  49:    */         case 37194: 
/*  50: 92 */           description = "WINDOW SYSTEM";
/*  51: 93 */           break;
/*  52:    */         case 37195: 
/*  53: 95 */           description = "DEPRECATION";
/*  54: 96 */           break;
/*  55:    */         case 37196: 
/*  56: 98 */           description = "UNDEFINED BEHAVIOR";
/*  57: 99 */           break;
/*  58:    */         case 37197: 
/*  59:101 */           description = "PERFORMANCE";
/*  60:102 */           break;
/*  61:    */         case 37198: 
/*  62:104 */           description = "SHADER COMPILER";
/*  63:105 */           break;
/*  64:    */         case 37199: 
/*  65:107 */           description = "APPLICATION";
/*  66:108 */           break;
/*  67:    */         case 37200: 
/*  68:110 */           description = "OTHER";
/*  69:111 */           break;
/*  70:    */         default: 
/*  71:113 */           description = printUnknownToken(category);
/*  72:    */         }
/*  73:115 */         System.err.println("\tCategory: " + description);
/*  74:117 */         switch (severity)
/*  75:    */         {
/*  76:    */         case 37190: 
/*  77:119 */           description = "HIGH";
/*  78:120 */           break;
/*  79:    */         case 37191: 
/*  80:122 */           description = "MEDIUM";
/*  81:123 */           break;
/*  82:    */         case 37192: 
/*  83:125 */           description = "LOW";
/*  84:126 */           break;
/*  85:    */         default: 
/*  86:128 */           description = printUnknownToken(severity);
/*  87:    */         }
/*  88:130 */         System.err.println("\tSeverity: " + description);
/*  89:    */         
/*  90:132 */         System.err.println("\tMessage: " + message);
/*  91:    */       }
/*  92:    */       
/*  93:    */       private String printUnknownToken(int token)
/*  94:    */       {
/*  95:136 */         return "Unknown (0x" + Integer.toHexString(token).toUpperCase() + ")";
/*  96:    */       }
/*  97:    */     });
/*  98:    */   }
/*  99:    */   
/* 100:    */   public AMDDebugOutputCallback(Handler handler)
/* 101:    */   {
/* 102:149 */     super(CALLBACK_POINTER);
/* 103:    */     
/* 104:151 */     this.handler = handler;
/* 105:    */   }
/* 106:    */   
/* 107:    */   Handler getHandler()
/* 108:    */   {
/* 109:155 */     return this.handler;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static abstract interface Handler
/* 113:    */   {
/* 114:    */     public abstract void handleMessage(int paramInt1, int paramInt2, int paramInt3, String paramString);
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDDebugOutputCallback
 * JD-Core Version:    0.7.0.1
 */