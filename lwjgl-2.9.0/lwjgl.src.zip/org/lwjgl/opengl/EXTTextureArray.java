/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class EXTTextureArray
/*  4:   */ {
/*  5:   */   public static final int GL_TEXTURE_1D_ARRAY_EXT = 35864;
/*  6:   */   public static final int GL_TEXTURE_2D_ARRAY_EXT = 35866;
/*  7:   */   public static final int GL_PROXY_TEXTURE_2D_ARRAY_EXT = 35867;
/*  8:   */   public static final int GL_PROXY_TEXTURE_1D_ARRAY_EXT = 35865;
/*  9:   */   public static final int GL_TEXTURE_BINDING_1D_ARRAY_EXT = 35868;
/* 10:   */   public static final int GL_TEXTURE_BINDING_2D_ARRAY_EXT = 35869;
/* 11:   */   public static final int GL_MAX_ARRAY_TEXTURE_LAYERS_EXT = 35071;
/* 12:   */   public static final int GL_COMPARE_REF_DEPTH_TO_TEXTURE_EXT = 34894;
/* 13:   */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER_EXT = 36052;
/* 14:   */   public static final int GL_SAMPLER_1D_ARRAY_EXT = 36288;
/* 15:   */   public static final int GL_SAMPLER_2D_ARRAY_EXT = 36289;
/* 16:   */   public static final int GL_SAMPLER_1D_ARRAY_SHADOW_EXT = 36291;
/* 17:   */   public static final int GL_SAMPLER_2D_ARRAY_SHADOW_EXT = 36292;
/* 18:   */   
/* 19:   */   public static void glFramebufferTextureLayerEXT(int target, int attachment, int texture, int level, int layer)
/* 20:   */   {
/* 21:62 */     EXTGeometryShader4.glFramebufferTextureLayerEXT(target, attachment, texture, level, layer);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureArray
 * JD-Core Version:    0.7.0.1
 */