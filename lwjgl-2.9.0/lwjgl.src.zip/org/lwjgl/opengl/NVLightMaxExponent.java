package org.lwjgl.opengl;

public final class NVLightMaxExponent
{
  public static final int GL_MAX_SHININESS_NV = 34052;
  public static final int GL_MAX_SPOT_EXPONENT_NV = 34053;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVLightMaxExponent
 * JD-Core Version:    0.7.0.1
 */