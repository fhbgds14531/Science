/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.security.AccessController;
/*   6:    */ import java.security.PrivilegedActionException;
/*   7:    */ import java.security.PrivilegedExceptionAction;
/*   8:    */ import org.lwjgl.LWJGLException;
/*   9:    */ import org.lwjgl.LWJGLUtil;
/*  10:    */ 
/*  11:    */ final class AWTSurfaceLock
/*  12:    */ {
/*  13:    */   private static final int WAIT_DELAY_MILLIS = 100;
/*  14:    */   private final ByteBuffer lock_buffer;
/*  15:    */   private boolean firstLockSucceeded;
/*  16:    */   
/*  17:    */   AWTSurfaceLock()
/*  18:    */   {
/*  19: 60 */     this.lock_buffer = createHandle();
/*  20:    */   }
/*  21:    */   
/*  22:    */   private static native ByteBuffer createHandle();
/*  23:    */   
/*  24:    */   public ByteBuffer lockAndGetHandle(Canvas component)
/*  25:    */     throws LWJGLException
/*  26:    */   {
/*  27: 66 */     while (!privilegedLockAndInitHandle(component))
/*  28:    */     {
/*  29: 67 */       LWJGLUtil.log("Could not get drawing surface info, retrying...");
/*  30:    */       try
/*  31:    */       {
/*  32: 69 */         Thread.sleep(100L);
/*  33:    */       }
/*  34:    */       catch (InterruptedException e)
/*  35:    */       {
/*  36: 71 */         LWJGLUtil.log("Interrupted while retrying: " + e);
/*  37:    */       }
/*  38:    */     }
/*  39: 75 */     return this.lock_buffer;
/*  40:    */   }
/*  41:    */   
/*  42:    */   private boolean privilegedLockAndInitHandle(final Canvas component)
/*  43:    */     throws LWJGLException
/*  44:    */   {
/*  45: 85 */     if (this.firstLockSucceeded) {
/*  46: 86 */       return lockAndInitHandle(this.lock_buffer, component);
/*  47:    */     }
/*  48:    */     try
/*  49:    */     {
/*  50: 89 */       this.firstLockSucceeded = ((Boolean)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  51:    */       {
/*  52:    */         public Boolean run()
/*  53:    */           throws LWJGLException
/*  54:    */         {
/*  55: 91 */           return Boolean.valueOf(AWTSurfaceLock.lockAndInitHandle(AWTSurfaceLock.this.lock_buffer, component));
/*  56:    */         }
/*  57: 93 */       })).booleanValue();
/*  58: 94 */       return this.firstLockSucceeded;
/*  59:    */     }
/*  60:    */     catch (PrivilegedActionException e)
/*  61:    */     {
/*  62: 96 */       throw ((LWJGLException)e.getException());
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static native boolean lockAndInitHandle(ByteBuffer paramByteBuffer, Canvas paramCanvas)
/*  67:    */     throws LWJGLException;
/*  68:    */   
/*  69:    */   void unlock()
/*  70:    */     throws LWJGLException
/*  71:    */   {
/*  72:103 */     nUnlock(this.lock_buffer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static native void nUnlock(ByteBuffer paramByteBuffer)
/*  76:    */     throws LWJGLException;
/*  77:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AWTSurfaceLock
 * JD-Core Version:    0.7.0.1
 */