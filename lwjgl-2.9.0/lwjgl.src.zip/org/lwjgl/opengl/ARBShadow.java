package org.lwjgl.opengl;

public final class ARBShadow
{
  public static final int GL_TEXTURE_COMPARE_MODE_ARB = 34892;
  public static final int GL_TEXTURE_COMPARE_FUNC_ARB = 34893;
  public static final int GL_COMPARE_R_TO_TEXTURE_ARB = 34894;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShadow
 * JD-Core Version:    0.7.0.1
 */