package org.lwjgl.opengl;

public final class AMDPinnedMemory
{
  public static final int GL_EXTERNAL_VIRTUAL_MEMORY_BUFFER_AMD = 37216;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDPinnedMemory
 * JD-Core Version:    0.7.0.1
 */