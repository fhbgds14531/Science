package org.lwjgl.opengl;

public final class EXTTextureFilterAnisotropic
{
  public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 34046;
  public static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 34047;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureFilterAnisotropic
 * JD-Core Version:    0.7.0.1
 */