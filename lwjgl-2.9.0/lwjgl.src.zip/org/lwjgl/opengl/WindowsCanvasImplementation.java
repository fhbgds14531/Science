/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.awt.GraphicsConfiguration;
/*  5:   */ import java.awt.GraphicsDevice;
/*  6:   */ import java.awt.Toolkit;
/*  7:   */ import java.security.AccessController;
/*  8:   */ import java.security.PrivilegedAction;
/*  9:   */ import org.lwjgl.LWJGLException;
/* 10:   */ import org.lwjgl.LWJGLUtil;
/* 11:   */ 
/* 12:   */ final class WindowsCanvasImplementation
/* 13:   */   implements AWTCanvasImplementation
/* 14:   */ {
/* 15:   */   static
/* 16:   */   {
/* 17:53 */     Toolkit.getDefaultToolkit();
/* 18:54 */     AccessController.doPrivileged(new PrivilegedAction()
/* 19:   */     {
/* 20:   */       public Object run()
/* 21:   */       {
/* 22:   */         try
/* 23:   */         {
/* 24:57 */           System.loadLibrary("jawt");
/* 25:   */         }
/* 26:   */         catch (UnsatisfiedLinkError e)
/* 27:   */         {
/* 28:62 */           LWJGLUtil.log("Failed to load jawt: " + e.getMessage());
/* 29:   */         }
/* 30:64 */         return null;
/* 31:   */       }
/* 32:   */     });
/* 33:   */   }
/* 34:   */   
/* 35:   */   public PeerInfo createPeerInfo(Canvas component, PixelFormat pixel_format, ContextAttribs attribs)
/* 36:   */     throws LWJGLException
/* 37:   */   {
/* 38:70 */     return new WindowsAWTGLCanvasPeerInfo(component, pixel_format);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public GraphicsConfiguration findConfiguration(GraphicsDevice device, PixelFormat pixel_format)
/* 42:   */     throws LWJGLException
/* 43:   */   {
/* 44:83 */     return null;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsCanvasImplementation
 * JD-Core Version:    0.7.0.1
 */