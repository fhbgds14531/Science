/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ 
/*   5:    */ public final class ALCdevice
/*   6:    */ {
/*   7:    */   final long device;
/*   8:    */   private boolean valid;
/*   9: 60 */   private final HashMap<Long, ALCcontext> contexts = new HashMap();
/*  10:    */   
/*  11:    */   ALCdevice(long device)
/*  12:    */   {
/*  13: 68 */     this.device = device;
/*  14: 69 */     this.valid = true;
/*  15:    */   }
/*  16:    */   
/*  17:    */   public boolean equals(Object device)
/*  18:    */   {
/*  19: 76 */     if ((device instanceof ALCdevice)) {
/*  20: 77 */       return ((ALCdevice)device).device == this.device;
/*  21:    */     }
/*  22: 79 */     return super.equals(device);
/*  23:    */   }
/*  24:    */   
/*  25:    */   void addContext(ALCcontext context)
/*  26:    */   {
/*  27: 88 */     synchronized (this.contexts)
/*  28:    */     {
/*  29: 89 */       this.contexts.put(Long.valueOf(context.context), context);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   void removeContext(ALCcontext context)
/*  34:    */   {
/*  35: 99 */     synchronized (this.contexts)
/*  36:    */     {
/*  37:100 */       this.contexts.remove(Long.valueOf(context.context));
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   void setInvalid()
/*  42:    */   {
/*  43:108 */     this.valid = false;
/*  44:109 */     synchronized (this.contexts)
/*  45:    */     {
/*  46:110 */       for (ALCcontext context : this.contexts.values()) {
/*  47:111 */         context.setInvalid();
/*  48:    */       }
/*  49:    */     }
/*  50:113 */     this.contexts.clear();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isValid()
/*  54:    */   {
/*  55:120 */     return this.valid;
/*  56:    */   }
/*  57:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.ALCdevice
 * JD-Core Version:    0.7.0.1
 */