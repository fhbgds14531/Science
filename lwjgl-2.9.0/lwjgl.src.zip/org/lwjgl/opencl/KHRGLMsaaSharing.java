package org.lwjgl.opencl;

public final class KHRGLMsaaSharing
{
  public static final int CL_GL_NUM_SAMPLES = 8210;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRGLMsaaSharing
 * JD-Core Version:    0.7.0.1
 */