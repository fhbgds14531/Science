/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBGeometryShader4
/*  6:   */ {
/*  7:   */   public static final int GL_GEOMETRY_SHADER_ARB = 36313;
/*  8:   */   public static final int GL_GEOMETRY_VERTICES_OUT_ARB = 36314;
/*  9:   */   public static final int GL_GEOMETRY_INPUT_TYPE_ARB = 36315;
/* 10:   */   public static final int GL_GEOMETRY_OUTPUT_TYPE_ARB = 36316;
/* 11:   */   public static final int GL_MAX_GEOMETRY_TEXTURE_IMAGE_UNITS_ARB = 35881;
/* 12:   */   public static final int GL_MAX_GEOMETRY_VARYING_COMPONENTS_ARB = 36317;
/* 13:   */   public static final int GL_MAX_VERTEX_VARYING_COMPONENTS_ARB = 36318;
/* 14:   */   public static final int GL_MAX_VARYING_COMPONENTS_ARB = 35659;
/* 15:   */   public static final int GL_MAX_GEOMETRY_UNIFORM_COMPONENTS_ARB = 36319;
/* 16:   */   public static final int GL_MAX_GEOMETRY_OUTPUT_VERTICES_ARB = 36320;
/* 17:   */   public static final int GL_MAX_GEOMETRY_TOTAL_OUTPUT_COMPONENTS_ARB = 36321;
/* 18:   */   public static final int GL_LINES_ADJACENCY_ARB = 10;
/* 19:   */   public static final int GL_LINE_STRIP_ADJACENCY_ARB = 11;
/* 20:   */   public static final int GL_TRIANGLES_ADJACENCY_ARB = 12;
/* 21:   */   public static final int GL_TRIANGLE_STRIP_ADJACENCY_ARB = 13;
/* 22:   */   public static final int GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS_ARB = 36264;
/* 23:   */   public static final int GL_FRAMEBUFFER_INCOMPLETE_LAYER_COUNT_ARB = 36265;
/* 24:   */   public static final int GL_FRAMEBUFFER_ATTACHMENT_LAYERED_ARB = 36263;
/* 25:   */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER_ARB = 36052;
/* 26:   */   public static final int GL_PROGRAM_POINT_SIZE_ARB = 34370;
/* 27:   */   
/* 28:   */   public static void glProgramParameteriARB(int program, int pname, int value)
/* 29:   */   {
/* 30:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 31:70 */     long function_pointer = caps.glProgramParameteriARB;
/* 32:71 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 33:72 */     nglProgramParameteriARB(program, pname, value, function_pointer);
/* 34:   */   }
/* 35:   */   
/* 36:   */   static native void nglProgramParameteriARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 37:   */   
/* 38:   */   public static void glFramebufferTextureARB(int target, int attachment, int texture, int level)
/* 39:   */   {
/* 40:77 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 41:78 */     long function_pointer = caps.glFramebufferTextureARB;
/* 42:79 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 43:80 */     nglFramebufferTextureARB(target, attachment, texture, level, function_pointer);
/* 44:   */   }
/* 45:   */   
/* 46:   */   static native void nglFramebufferTextureARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 47:   */   
/* 48:   */   public static void glFramebufferTextureLayerARB(int target, int attachment, int texture, int level, int layer)
/* 49:   */   {
/* 50:85 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 51:86 */     long function_pointer = caps.glFramebufferTextureLayerARB;
/* 52:87 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 53:88 */     nglFramebufferTextureLayerARB(target, attachment, texture, level, layer, function_pointer);
/* 54:   */   }
/* 55:   */   
/* 56:   */   static native void nglFramebufferTextureLayerARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 57:   */   
/* 58:   */   public static void glFramebufferTextureFaceARB(int target, int attachment, int texture, int level, int face)
/* 59:   */   {
/* 60:93 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 61:94 */     long function_pointer = caps.glFramebufferTextureFaceARB;
/* 62:95 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 63:96 */     nglFramebufferTextureFaceARB(target, attachment, texture, level, face, function_pointer);
/* 64:   */   }
/* 65:   */   
/* 66:   */   static native void nglFramebufferTextureFaceARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 67:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBGeometryShader4
 * JD-Core Version:    0.7.0.1
 */