/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class EXTPalettedTexture
/*  12:    */ {
/*  13:    */   public static final int GL_COLOR_INDEX1_EXT = 32994;
/*  14:    */   public static final int GL_COLOR_INDEX2_EXT = 32995;
/*  15:    */   public static final int GL_COLOR_INDEX4_EXT = 32996;
/*  16:    */   public static final int GL_COLOR_INDEX8_EXT = 32997;
/*  17:    */   public static final int GL_COLOR_INDEX12_EXT = 32998;
/*  18:    */   public static final int GL_COLOR_INDEX16_EXT = 32999;
/*  19:    */   public static final int GL_COLOR_TABLE_FORMAT_EXT = 32984;
/*  20:    */   public static final int GL_COLOR_TABLE_WIDTH_EXT = 32985;
/*  21:    */   public static final int GL_COLOR_TABLE_RED_SIZE_EXT = 32986;
/*  22:    */   public static final int GL_COLOR_TABLE_GREEN_SIZE_EXT = 32987;
/*  23:    */   public static final int GL_COLOR_TABLE_BLUE_SIZE_EXT = 32988;
/*  24:    */   public static final int GL_COLOR_TABLE_ALPHA_SIZE_EXT = 32989;
/*  25:    */   public static final int GL_COLOR_TABLE_LUMINANCE_SIZE_EXT = 32990;
/*  26:    */   public static final int GL_COLOR_TABLE_INTENSITY_SIZE_EXT = 32991;
/*  27:    */   public static final int GL_TEXTURE_INDEX_SIZE_EXT = 33005;
/*  28:    */   
/*  29:    */   public static void glColorTableEXT(int target, int internalFormat, int width, int format, int type, ByteBuffer data)
/*  30:    */   {
/*  31: 42 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  32: 43 */     long function_pointer = caps.glColorTableEXT;
/*  33: 44 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  34: 45 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, width, 1, 1));
/*  35: 46 */     nglColorTableEXT(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static void glColorTableEXT(int target, int internalFormat, int width, int format, int type, DoubleBuffer data)
/*  39:    */   {
/*  40: 49 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  41: 50 */     long function_pointer = caps.glColorTableEXT;
/*  42: 51 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  43: 52 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, width, 1, 1));
/*  44: 53 */     nglColorTableEXT(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static void glColorTableEXT(int target, int internalFormat, int width, int format, int type, FloatBuffer data)
/*  48:    */   {
/*  49: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  50: 57 */     long function_pointer = caps.glColorTableEXT;
/*  51: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  52: 59 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, width, 1, 1));
/*  53: 60 */     nglColorTableEXT(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static void glColorTableEXT(int target, int internalFormat, int width, int format, int type, IntBuffer data)
/*  57:    */   {
/*  58: 63 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  59: 64 */     long function_pointer = caps.glColorTableEXT;
/*  60: 65 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 66 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, width, 1, 1));
/*  62: 67 */     nglColorTableEXT(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glColorTableEXT(int target, int internalFormat, int width, int format, int type, ShortBuffer data)
/*  66:    */   {
/*  67: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  68: 71 */     long function_pointer = caps.glColorTableEXT;
/*  69: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  70: 73 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, width, 1, 1));
/*  71: 74 */     nglColorTableEXT(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static native void nglColorTableEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  75:    */   
/*  76:    */   public static void glColorSubTableEXT(int target, int start, int count, int format, int type, ByteBuffer data)
/*  77:    */   {
/*  78: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79: 80 */     long function_pointer = caps.glColorSubTableEXT;
/*  80: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81: 82 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, count, 1, 1));
/*  82: 83 */     nglColorSubTableEXT(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void glColorSubTableEXT(int target, int start, int count, int format, int type, DoubleBuffer data)
/*  86:    */   {
/*  87: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  88: 87 */     long function_pointer = caps.glColorSubTableEXT;
/*  89: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  90: 89 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, count, 1, 1));
/*  91: 90 */     nglColorSubTableEXT(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static void glColorSubTableEXT(int target, int start, int count, int format, int type, FloatBuffer data)
/*  95:    */   {
/*  96: 93 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  97: 94 */     long function_pointer = caps.glColorSubTableEXT;
/*  98: 95 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  99: 96 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, count, 1, 1));
/* 100: 97 */     nglColorSubTableEXT(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void glColorSubTableEXT(int target, int start, int count, int format, int type, IntBuffer data)
/* 104:    */   {
/* 105:100 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106:101 */     long function_pointer = caps.glColorSubTableEXT;
/* 107:102 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108:103 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, count, 1, 1));
/* 109:104 */     nglColorSubTableEXT(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void glColorSubTableEXT(int target, int start, int count, int format, int type, ShortBuffer data)
/* 113:    */   {
/* 114:107 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:108 */     long function_pointer = caps.glColorSubTableEXT;
/* 116:109 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:110 */     BufferChecks.checkBuffer(data, GLChecks.calculateImageStorage(data, format, type, count, 1, 1));
/* 118:111 */     nglColorSubTableEXT(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native void nglColorSubTableEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 122:    */   
/* 123:    */   public static void glGetColorTableEXT(int target, int format, int type, ByteBuffer data)
/* 124:    */   {
/* 125:116 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:117 */     long function_pointer = caps.glGetColorTableEXT;
/* 127:118 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:119 */     BufferChecks.checkDirect(data);
/* 129:120 */     nglGetColorTableEXT(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static void glGetColorTableEXT(int target, int format, int type, DoubleBuffer data)
/* 133:    */   {
/* 134:123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 135:124 */     long function_pointer = caps.glGetColorTableEXT;
/* 136:125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 137:126 */     BufferChecks.checkDirect(data);
/* 138:127 */     nglGetColorTableEXT(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static void glGetColorTableEXT(int target, int format, int type, FloatBuffer data)
/* 142:    */   {
/* 143:130 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 144:131 */     long function_pointer = caps.glGetColorTableEXT;
/* 145:132 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 146:133 */     BufferChecks.checkDirect(data);
/* 147:134 */     nglGetColorTableEXT(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static void glGetColorTableEXT(int target, int format, int type, IntBuffer data)
/* 151:    */   {
/* 152:137 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 153:138 */     long function_pointer = caps.glGetColorTableEXT;
/* 154:139 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 155:140 */     BufferChecks.checkDirect(data);
/* 156:141 */     nglGetColorTableEXT(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static void glGetColorTableEXT(int target, int format, int type, ShortBuffer data)
/* 160:    */   {
/* 161:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 162:145 */     long function_pointer = caps.glGetColorTableEXT;
/* 163:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 164:147 */     BufferChecks.checkDirect(data);
/* 165:148 */     nglGetColorTableEXT(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 166:    */   }
/* 167:    */   
/* 168:    */   static native void nglGetColorTableEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 169:    */   
/* 170:    */   public static void glGetColorTableParameterEXT(int target, int pname, IntBuffer params)
/* 171:    */   {
/* 172:153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 173:154 */     long function_pointer = caps.glGetColorTableParameterivEXT;
/* 174:155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 175:156 */     BufferChecks.checkBuffer(params, 4);
/* 176:157 */     nglGetColorTableParameterivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 177:    */   }
/* 178:    */   
/* 179:    */   static native void nglGetColorTableParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 180:    */   
/* 181:    */   public static void glGetColorTableParameterEXT(int target, int pname, FloatBuffer params)
/* 182:    */   {
/* 183:162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 184:163 */     long function_pointer = caps.glGetColorTableParameterfvEXT;
/* 185:164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 186:165 */     BufferChecks.checkBuffer(params, 4);
/* 187:166 */     nglGetColorTableParameterfvEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 188:    */   }
/* 189:    */   
/* 190:    */   static native void nglGetColorTableParameterfvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 191:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTPalettedTexture
 * JD-Core Version:    0.7.0.1
 */