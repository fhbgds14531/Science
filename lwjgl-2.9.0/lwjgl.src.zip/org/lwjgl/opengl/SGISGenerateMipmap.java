package org.lwjgl.opengl;

public final class SGISGenerateMipmap
{
  public static final int GL_GENERATE_MIPMAP_SGIS = 33169;
  public static final int GL_GENERATE_MIPMAP_HINT_SGIS = 33170;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.SGISGenerateMipmap
 * JD-Core Version:    0.7.0.1
 */