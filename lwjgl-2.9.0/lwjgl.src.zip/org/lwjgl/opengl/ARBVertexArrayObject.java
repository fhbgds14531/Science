/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBVertexArrayObject
/*  6:   */ {
/*  7:   */   public static final int GL_VERTEX_ARRAY_BINDING = 34229;
/*  8:   */   
/*  9:   */   public static void glBindVertexArray(int array)
/* 10:   */   {
/* 11:19 */     GL30.glBindVertexArray(array);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void glDeleteVertexArrays(IntBuffer arrays)
/* 15:   */   {
/* 16:23 */     GL30.glDeleteVertexArrays(arrays);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void glDeleteVertexArrays(int array)
/* 20:   */   {
/* 21:28 */     GL30.glDeleteVertexArrays(array);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glGenVertexArrays(IntBuffer arrays)
/* 25:   */   {
/* 26:32 */     GL30.glGenVertexArrays(arrays);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static int glGenVertexArrays()
/* 30:   */   {
/* 31:37 */     return GL30.glGenVertexArrays();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static boolean glIsVertexArray(int array)
/* 35:   */   {
/* 36:41 */     return GL30.glIsVertexArray(array);
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexArrayObject
 * JD-Core Version:    0.7.0.1
 */