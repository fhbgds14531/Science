/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ final class WindowsContextAttribs
/*  4:   */   implements ContextAttribsImplementation
/*  5:   */ {
/*  6:   */   private static final int WGL_CONTEXT_MAJOR_VERSION_ARB = 8337;
/*  7:   */   private static final int WGL_CONTEXT_MINOR_VERSION_ARB = 8338;
/*  8:   */   private static final int WGL_CONTEXT_LAYER_PLANE_ARB = 8339;
/*  9:   */   private static final int WGL_CONTEXT_FLAGS_ARB = 8340;
/* 10:   */   private static final int WGL_CONTEXT_PROFILE_MASK_ARB = 37158;
/* 11:   */   private static final int WGL_CONTEXT_DEBUG_BIT_ARB = 1;
/* 12:   */   private static final int WGL_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB = 2;
/* 13:   */   private static final int WGL_CONTEXT_CORE_PROFILE_BIT_ARB = 1;
/* 14:   */   private static final int WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB = 2;
/* 15:   */   
/* 16:   */   public int getMajorVersionAttrib()
/* 17:   */   {
/* 18:57 */     return 8337;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public int getMinorVersionAttrib()
/* 22:   */   {
/* 23:61 */     return 8338;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int getLayerPlaneAttrib()
/* 27:   */   {
/* 28:65 */     return 8339;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getFlagsAttrib()
/* 32:   */   {
/* 33:69 */     return 8340;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public int getDebugBit()
/* 37:   */   {
/* 38:73 */     return 1;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public int getForwardCompatibleBit()
/* 42:   */   {
/* 43:77 */     return 2;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int getProfileMaskAttrib()
/* 47:   */   {
/* 48:81 */     return 37158;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public int getProfileCoreBit()
/* 52:   */   {
/* 53:85 */     return 1;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public int getProfileCompatibilityBit()
/* 57:   */   {
/* 58:89 */     return 2;
/* 59:   */   }
/* 60:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsContextAttribs
 * JD-Core Version:    0.7.0.1
 */