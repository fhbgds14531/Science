/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ final class GlobalLock
/*  4:   */ {
/*  5:39 */   static final Object lock = new Object();
/*  6:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GlobalLock
 * JD-Core Version:    0.7.0.1
 */