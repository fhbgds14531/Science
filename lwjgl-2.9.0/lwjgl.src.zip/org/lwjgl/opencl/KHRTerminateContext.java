/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class KHRTerminateContext
/*  6:   */ {
/*  7:   */   public static final int CL_DEVICE_TERMINATE_CAPABILITY_KHR = 8207;
/*  8:   */   public static final int CL_CONTEXT_TERMINATE_KHR = 8208;
/*  9:   */   
/* 10:   */   public static int clTerminateContextKHR(CLContext context)
/* 11:   */   {
/* 12:16 */     long function_pointer = CLCapabilities.clTerminateContextKHR;
/* 13:17 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 14:18 */     int __result = nclTerminateContextKHR(context.getPointer(), function_pointer);
/* 15:19 */     return __result;
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native int nclTerminateContextKHR(long paramLong1, long paramLong2);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRTerminateContext
 * JD-Core Version:    0.7.0.1
 */