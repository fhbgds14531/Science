/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.DoubleBuffer;
/*    5:     */ import java.nio.FloatBuffer;
/*    6:     */ import java.nio.IntBuffer;
/*    7:     */ import org.lwjgl.BufferChecks;
/*    8:     */ import org.lwjgl.LWJGLUtil;
/*    9:     */ import org.lwjgl.MemoryUtil;
/*   10:     */ 
/*   11:     */ public final class GL41
/*   12:     */ {
/*   13:     */   public static final int GL_SHADER_COMPILER = 36346;
/*   14:     */   public static final int GL_NUM_SHADER_BINARY_FORMATS = 36345;
/*   15:     */   public static final int GL_MAX_VERTEX_UNIFORM_VECTORS = 36347;
/*   16:     */   public static final int GL_MAX_VARYING_VECTORS = 36348;
/*   17:     */   public static final int GL_MAX_FRAGMENT_UNIFORM_VECTORS = 36349;
/*   18:     */   public static final int GL_IMPLEMENTATION_COLOR_READ_TYPE = 35738;
/*   19:     */   public static final int GL_IMPLEMENTATION_COLOR_READ_FORMAT = 35739;
/*   20:     */   public static final int GL_FIXED = 5132;
/*   21:     */   public static final int GL_LOW_FLOAT = 36336;
/*   22:     */   public static final int GL_MEDIUM_FLOAT = 36337;
/*   23:     */   public static final int GL_HIGH_FLOAT = 36338;
/*   24:     */   public static final int GL_LOW_INT = 36339;
/*   25:     */   public static final int GL_MEDIUM_INT = 36340;
/*   26:     */   public static final int GL_HIGH_INT = 36341;
/*   27:     */   public static final int GL_RGB565 = 36194;
/*   28:     */   public static final int GL_PROGRAM_BINARY_RETRIEVABLE_HINT = 33367;
/*   29:     */   public static final int GL_PROGRAM_BINARY_LENGTH = 34625;
/*   30:     */   public static final int GL_NUM_PROGRAM_BINARY_FORMATS = 34814;
/*   31:     */   public static final int GL_PROGRAM_BINARY_FORMATS = 34815;
/*   32:     */   public static final int GL_VERTEX_SHADER_BIT = 1;
/*   33:     */   public static final int GL_FRAGMENT_SHADER_BIT = 2;
/*   34:     */   public static final int GL_GEOMETRY_SHADER_BIT = 4;
/*   35:     */   public static final int GL_TESS_CONTROL_SHADER_BIT = 8;
/*   36:     */   public static final int GL_TESS_EVALUATION_SHADER_BIT = 16;
/*   37:     */   public static final int GL_ALL_SHADER_BITS = -1;
/*   38:     */   public static final int GL_PROGRAM_SEPARABLE = 33368;
/*   39:     */   public static final int GL_ACTIVE_PROGRAM = 33369;
/*   40:     */   public static final int GL_PROGRAM_PIPELINE_BINDING = 33370;
/*   41:     */   public static final int GL_DOUBLE_VEC2 = 36860;
/*   42:     */   public static final int GL_DOUBLE_VEC3 = 36861;
/*   43:     */   public static final int GL_DOUBLE_VEC4 = 36862;
/*   44:     */   public static final int GL_DOUBLE_MAT2 = 36678;
/*   45:     */   public static final int GL_DOUBLE_MAT3 = 36679;
/*   46:     */   public static final int GL_DOUBLE_MAT4 = 36680;
/*   47:     */   public static final int GL_DOUBLE_MAT2x3 = 36681;
/*   48:     */   public static final int GL_DOUBLE_MAT2x4 = 36682;
/*   49:     */   public static final int GL_DOUBLE_MAT3x2 = 36683;
/*   50:     */   public static final int GL_DOUBLE_MAT3x4 = 36684;
/*   51:     */   public static final int GL_DOUBLE_MAT4x2 = 36685;
/*   52:     */   public static final int GL_DOUBLE_MAT4x3 = 36686;
/*   53:     */   public static final int GL_MAX_VIEWPORTS = 33371;
/*   54:     */   public static final int GL_VIEWPORT_SUBPIXEL_BITS = 33372;
/*   55:     */   public static final int GL_VIEWPORT_BOUNDS_RANGE = 33373;
/*   56:     */   public static final int GL_LAYER_PROVOKING_VERTEX = 33374;
/*   57:     */   public static final int GL_VIEWPORT_INDEX_PROVOKING_VERTEX = 33375;
/*   58:     */   public static final int GL_SCISSOR_BOX = 3088;
/*   59:     */   public static final int GL_VIEWPORT = 2978;
/*   60:     */   public static final int GL_DEPTH_RANGE = 2928;
/*   61:     */   public static final int GL_SCISSOR_TEST = 3089;
/*   62:     */   public static final int GL_FIRST_VERTEX_CONVENTION = 36429;
/*   63:     */   public static final int GL_LAST_VERTEX_CONVENTION = 36430;
/*   64:     */   public static final int GL_PROVOKING_VERTEX = 36431;
/*   65:     */   public static final int GL_UNDEFINED_VERTEX = 33376;
/*   66:     */   
/*   67:     */   public static void glReleaseShaderCompiler()
/*   68:     */   {
/*   69: 146 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   70: 147 */     long function_pointer = caps.glReleaseShaderCompiler;
/*   71: 148 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   72: 149 */     nglReleaseShaderCompiler(function_pointer);
/*   73:     */   }
/*   74:     */   
/*   75:     */   static native void nglReleaseShaderCompiler(long paramLong);
/*   76:     */   
/*   77:     */   public static void glShaderBinary(IntBuffer shaders, int binaryformat, ByteBuffer binary)
/*   78:     */   {
/*   79: 154 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   80: 155 */     long function_pointer = caps.glShaderBinary;
/*   81: 156 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   82: 157 */     BufferChecks.checkDirect(shaders);
/*   83: 158 */     BufferChecks.checkDirect(binary);
/*   84: 159 */     nglShaderBinary(shaders.remaining(), MemoryUtil.getAddress(shaders), binaryformat, MemoryUtil.getAddress(binary), binary.remaining(), function_pointer);
/*   85:     */   }
/*   86:     */   
/*   87:     */   static native void nglShaderBinary(int paramInt1, long paramLong1, int paramInt2, long paramLong2, int paramInt3, long paramLong3);
/*   88:     */   
/*   89:     */   public static void glGetShaderPrecisionFormat(int shadertype, int precisiontype, IntBuffer range, IntBuffer precision)
/*   90:     */   {
/*   91: 164 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   92: 165 */     long function_pointer = caps.glGetShaderPrecisionFormat;
/*   93: 166 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   94: 167 */     BufferChecks.checkBuffer(range, 2);
/*   95: 168 */     BufferChecks.checkBuffer(precision, 1);
/*   96: 169 */     nglGetShaderPrecisionFormat(shadertype, precisiontype, MemoryUtil.getAddress(range), MemoryUtil.getAddress(precision), function_pointer);
/*   97:     */   }
/*   98:     */   
/*   99:     */   static native void nglGetShaderPrecisionFormat(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  100:     */   
/*  101:     */   public static void glDepthRangef(float n, float f)
/*  102:     */   {
/*  103: 174 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  104: 175 */     long function_pointer = caps.glDepthRangef;
/*  105: 176 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  106: 177 */     nglDepthRangef(n, f, function_pointer);
/*  107:     */   }
/*  108:     */   
/*  109:     */   static native void nglDepthRangef(float paramFloat1, float paramFloat2, long paramLong);
/*  110:     */   
/*  111:     */   public static void glClearDepthf(float d)
/*  112:     */   {
/*  113: 182 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  114: 183 */     long function_pointer = caps.glClearDepthf;
/*  115: 184 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  116: 185 */     nglClearDepthf(d, function_pointer);
/*  117:     */   }
/*  118:     */   
/*  119:     */   static native void nglClearDepthf(float paramFloat, long paramLong);
/*  120:     */   
/*  121:     */   public static void glGetProgramBinary(int program, IntBuffer length, IntBuffer binaryFormat, ByteBuffer binary)
/*  122:     */   {
/*  123: 190 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  124: 191 */     long function_pointer = caps.glGetProgramBinary;
/*  125: 192 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  126: 193 */     if (length != null) {
/*  127: 194 */       BufferChecks.checkBuffer(length, 1);
/*  128:     */     }
/*  129: 195 */     BufferChecks.checkBuffer(binaryFormat, 1);
/*  130: 196 */     BufferChecks.checkDirect(binary);
/*  131: 197 */     nglGetProgramBinary(program, binary.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(binaryFormat), MemoryUtil.getAddress(binary), function_pointer);
/*  132:     */   }
/*  133:     */   
/*  134:     */   static native void nglGetProgramBinary(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*  135:     */   
/*  136:     */   public static void glProgramBinary(int program, int binaryFormat, ByteBuffer binary)
/*  137:     */   {
/*  138: 202 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  139: 203 */     long function_pointer = caps.glProgramBinary;
/*  140: 204 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  141: 205 */     BufferChecks.checkDirect(binary);
/*  142: 206 */     nglProgramBinary(program, binaryFormat, MemoryUtil.getAddress(binary), binary.remaining(), function_pointer);
/*  143:     */   }
/*  144:     */   
/*  145:     */   static native void nglProgramBinary(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  146:     */   
/*  147:     */   public static void glProgramParameteri(int program, int pname, int value)
/*  148:     */   {
/*  149: 211 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  150: 212 */     long function_pointer = caps.glProgramParameteri;
/*  151: 213 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  152: 214 */     nglProgramParameteri(program, pname, value, function_pointer);
/*  153:     */   }
/*  154:     */   
/*  155:     */   static native void nglProgramParameteri(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  156:     */   
/*  157:     */   public static void glUseProgramStages(int pipeline, int stages, int program)
/*  158:     */   {
/*  159: 219 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  160: 220 */     long function_pointer = caps.glUseProgramStages;
/*  161: 221 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  162: 222 */     nglUseProgramStages(pipeline, stages, program, function_pointer);
/*  163:     */   }
/*  164:     */   
/*  165:     */   static native void nglUseProgramStages(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  166:     */   
/*  167:     */   public static void glActiveShaderProgram(int pipeline, int program)
/*  168:     */   {
/*  169: 227 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  170: 228 */     long function_pointer = caps.glActiveShaderProgram;
/*  171: 229 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  172: 230 */     nglActiveShaderProgram(pipeline, program, function_pointer);
/*  173:     */   }
/*  174:     */   
/*  175:     */   static native void nglActiveShaderProgram(int paramInt1, int paramInt2, long paramLong);
/*  176:     */   
/*  177:     */   public static int glCreateShaderProgram(int type, ByteBuffer string)
/*  178:     */   {
/*  179: 238 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  180: 239 */     long function_pointer = caps.glCreateShaderProgramv;
/*  181: 240 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  182: 241 */     BufferChecks.checkDirect(string);
/*  183: 242 */     BufferChecks.checkNullTerminated(string);
/*  184: 243 */     int __result = nglCreateShaderProgramv(type, 1, MemoryUtil.getAddress(string), function_pointer);
/*  185: 244 */     return __result;
/*  186:     */   }
/*  187:     */   
/*  188:     */   static native int nglCreateShaderProgramv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  189:     */   
/*  190:     */   public static int glCreateShaderProgram(int type, int count, ByteBuffer strings)
/*  191:     */   {
/*  192: 254 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  193: 255 */     long function_pointer = caps.glCreateShaderProgramv;
/*  194: 256 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  195: 257 */     BufferChecks.checkDirect(strings);
/*  196: 258 */     BufferChecks.checkNullTerminated(strings, count);
/*  197: 259 */     int __result = nglCreateShaderProgramv2(type, count, MemoryUtil.getAddress(strings), function_pointer);
/*  198: 260 */     return __result;
/*  199:     */   }
/*  200:     */   
/*  201:     */   static native int nglCreateShaderProgramv2(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  202:     */   
/*  203:     */   public static int glCreateShaderProgram(int type, ByteBuffer[] strings)
/*  204:     */   {
/*  205: 266 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  206: 267 */     long function_pointer = caps.glCreateShaderProgramv;
/*  207: 268 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  208: 269 */     BufferChecks.checkArray(strings, 1);
/*  209: 270 */     int __result = nglCreateShaderProgramv3(type, strings.length, strings, function_pointer);
/*  210: 271 */     return __result;
/*  211:     */   }
/*  212:     */   
/*  213:     */   static native int nglCreateShaderProgramv3(int paramInt1, int paramInt2, ByteBuffer[] paramArrayOfByteBuffer, long paramLong);
/*  214:     */   
/*  215:     */   public static int glCreateShaderProgram(int type, CharSequence string)
/*  216:     */   {
/*  217: 277 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  218: 278 */     long function_pointer = caps.glCreateShaderProgramv;
/*  219: 279 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  220: 280 */     int __result = nglCreateShaderProgramv(type, 1, APIUtil.getBufferNT(caps, string), function_pointer);
/*  221: 281 */     return __result;
/*  222:     */   }
/*  223:     */   
/*  224:     */   public static int glCreateShaderProgram(int type, CharSequence[] strings)
/*  225:     */   {
/*  226: 286 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  227: 287 */     long function_pointer = caps.glCreateShaderProgramv;
/*  228: 288 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  229: 289 */     BufferChecks.checkArray(strings);
/*  230: 290 */     int __result = nglCreateShaderProgramv2(type, strings.length, APIUtil.getBufferNT(caps, strings), function_pointer);
/*  231: 291 */     return __result;
/*  232:     */   }
/*  233:     */   
/*  234:     */   public static void glBindProgramPipeline(int pipeline)
/*  235:     */   {
/*  236: 295 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  237: 296 */     long function_pointer = caps.glBindProgramPipeline;
/*  238: 297 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  239: 298 */     nglBindProgramPipeline(pipeline, function_pointer);
/*  240:     */   }
/*  241:     */   
/*  242:     */   static native void nglBindProgramPipeline(int paramInt, long paramLong);
/*  243:     */   
/*  244:     */   public static void glDeleteProgramPipelines(IntBuffer pipelines)
/*  245:     */   {
/*  246: 303 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  247: 304 */     long function_pointer = caps.glDeleteProgramPipelines;
/*  248: 305 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  249: 306 */     BufferChecks.checkDirect(pipelines);
/*  250: 307 */     nglDeleteProgramPipelines(pipelines.remaining(), MemoryUtil.getAddress(pipelines), function_pointer);
/*  251:     */   }
/*  252:     */   
/*  253:     */   static native void nglDeleteProgramPipelines(int paramInt, long paramLong1, long paramLong2);
/*  254:     */   
/*  255:     */   public static void glDeleteProgramPipelines(int pipeline)
/*  256:     */   {
/*  257: 313 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  258: 314 */     long function_pointer = caps.glDeleteProgramPipelines;
/*  259: 315 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  260: 316 */     nglDeleteProgramPipelines(1, APIUtil.getInt(caps, pipeline), function_pointer);
/*  261:     */   }
/*  262:     */   
/*  263:     */   public static void glGenProgramPipelines(IntBuffer pipelines)
/*  264:     */   {
/*  265: 320 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  266: 321 */     long function_pointer = caps.glGenProgramPipelines;
/*  267: 322 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  268: 323 */     BufferChecks.checkDirect(pipelines);
/*  269: 324 */     nglGenProgramPipelines(pipelines.remaining(), MemoryUtil.getAddress(pipelines), function_pointer);
/*  270:     */   }
/*  271:     */   
/*  272:     */   static native void nglGenProgramPipelines(int paramInt, long paramLong1, long paramLong2);
/*  273:     */   
/*  274:     */   public static int glGenProgramPipelines()
/*  275:     */   {
/*  276: 330 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  277: 331 */     long function_pointer = caps.glGenProgramPipelines;
/*  278: 332 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  279: 333 */     IntBuffer pipelines = APIUtil.getBufferInt(caps);
/*  280: 334 */     nglGenProgramPipelines(1, MemoryUtil.getAddress(pipelines), function_pointer);
/*  281: 335 */     return pipelines.get(0);
/*  282:     */   }
/*  283:     */   
/*  284:     */   public static boolean glIsProgramPipeline(int pipeline)
/*  285:     */   {
/*  286: 339 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  287: 340 */     long function_pointer = caps.glIsProgramPipeline;
/*  288: 341 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  289: 342 */     boolean __result = nglIsProgramPipeline(pipeline, function_pointer);
/*  290: 343 */     return __result;
/*  291:     */   }
/*  292:     */   
/*  293:     */   static native boolean nglIsProgramPipeline(int paramInt, long paramLong);
/*  294:     */   
/*  295:     */   public static void glGetProgramPipeline(int pipeline, int pname, IntBuffer params)
/*  296:     */   {
/*  297: 348 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  298: 349 */     long function_pointer = caps.glGetProgramPipelineiv;
/*  299: 350 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  300: 351 */     BufferChecks.checkBuffer(params, 1);
/*  301: 352 */     nglGetProgramPipelineiv(pipeline, pname, MemoryUtil.getAddress(params), function_pointer);
/*  302:     */   }
/*  303:     */   
/*  304:     */   static native void nglGetProgramPipelineiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  305:     */   
/*  306:     */   public static int glGetProgramPipelinei(int pipeline, int pname)
/*  307:     */   {
/*  308: 358 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  309: 359 */     long function_pointer = caps.glGetProgramPipelineiv;
/*  310: 360 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  311: 361 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  312: 362 */     nglGetProgramPipelineiv(pipeline, pname, MemoryUtil.getAddress(params), function_pointer);
/*  313: 363 */     return params.get(0);
/*  314:     */   }
/*  315:     */   
/*  316:     */   public static void glProgramUniform1i(int program, int location, int v0)
/*  317:     */   {
/*  318: 367 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  319: 368 */     long function_pointer = caps.glProgramUniform1i;
/*  320: 369 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  321: 370 */     nglProgramUniform1i(program, location, v0, function_pointer);
/*  322:     */   }
/*  323:     */   
/*  324:     */   static native void nglProgramUniform1i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  325:     */   
/*  326:     */   public static void glProgramUniform2i(int program, int location, int v0, int v1)
/*  327:     */   {
/*  328: 375 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  329: 376 */     long function_pointer = caps.glProgramUniform2i;
/*  330: 377 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  331: 378 */     nglProgramUniform2i(program, location, v0, v1, function_pointer);
/*  332:     */   }
/*  333:     */   
/*  334:     */   static native void nglProgramUniform2i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  335:     */   
/*  336:     */   public static void glProgramUniform3i(int program, int location, int v0, int v1, int v2)
/*  337:     */   {
/*  338: 383 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  339: 384 */     long function_pointer = caps.glProgramUniform3i;
/*  340: 385 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  341: 386 */     nglProgramUniform3i(program, location, v0, v1, v2, function_pointer);
/*  342:     */   }
/*  343:     */   
/*  344:     */   static native void nglProgramUniform3i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  345:     */   
/*  346:     */   public static void glProgramUniform4i(int program, int location, int v0, int v1, int v2, int v3)
/*  347:     */   {
/*  348: 391 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  349: 392 */     long function_pointer = caps.glProgramUniform4i;
/*  350: 393 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  351: 394 */     nglProgramUniform4i(program, location, v0, v1, v2, v3, function_pointer);
/*  352:     */   }
/*  353:     */   
/*  354:     */   static native void nglProgramUniform4i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  355:     */   
/*  356:     */   public static void glProgramUniform1f(int program, int location, float v0)
/*  357:     */   {
/*  358: 399 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  359: 400 */     long function_pointer = caps.glProgramUniform1f;
/*  360: 401 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  361: 402 */     nglProgramUniform1f(program, location, v0, function_pointer);
/*  362:     */   }
/*  363:     */   
/*  364:     */   static native void nglProgramUniform1f(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/*  365:     */   
/*  366:     */   public static void glProgramUniform2f(int program, int location, float v0, float v1)
/*  367:     */   {
/*  368: 407 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  369: 408 */     long function_pointer = caps.glProgramUniform2f;
/*  370: 409 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  371: 410 */     nglProgramUniform2f(program, location, v0, v1, function_pointer);
/*  372:     */   }
/*  373:     */   
/*  374:     */   static native void nglProgramUniform2f(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, long paramLong);
/*  375:     */   
/*  376:     */   public static void glProgramUniform3f(int program, int location, float v0, float v1, float v2)
/*  377:     */   {
/*  378: 415 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  379: 416 */     long function_pointer = caps.glProgramUniform3f;
/*  380: 417 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  381: 418 */     nglProgramUniform3f(program, location, v0, v1, v2, function_pointer);
/*  382:     */   }
/*  383:     */   
/*  384:     */   static native void nglProgramUniform3f(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  385:     */   
/*  386:     */   public static void glProgramUniform4f(int program, int location, float v0, float v1, float v2, float v3)
/*  387:     */   {
/*  388: 423 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  389: 424 */     long function_pointer = caps.glProgramUniform4f;
/*  390: 425 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  391: 426 */     nglProgramUniform4f(program, location, v0, v1, v2, v3, function_pointer);
/*  392:     */   }
/*  393:     */   
/*  394:     */   static native void nglProgramUniform4f(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  395:     */   
/*  396:     */   public static void glProgramUniform1d(int program, int location, double v0)
/*  397:     */   {
/*  398: 431 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  399: 432 */     long function_pointer = caps.glProgramUniform1d;
/*  400: 433 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  401: 434 */     nglProgramUniform1d(program, location, v0, function_pointer);
/*  402:     */   }
/*  403:     */   
/*  404:     */   static native void nglProgramUniform1d(int paramInt1, int paramInt2, double paramDouble, long paramLong);
/*  405:     */   
/*  406:     */   public static void glProgramUniform2d(int program, int location, double v0, double v1)
/*  407:     */   {
/*  408: 439 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  409: 440 */     long function_pointer = caps.glProgramUniform2d;
/*  410: 441 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  411: 442 */     nglProgramUniform2d(program, location, v0, v1, function_pointer);
/*  412:     */   }
/*  413:     */   
/*  414:     */   static native void nglProgramUniform2d(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, long paramLong);
/*  415:     */   
/*  416:     */   public static void glProgramUniform3d(int program, int location, double v0, double v1, double v2)
/*  417:     */   {
/*  418: 447 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  419: 448 */     long function_pointer = caps.glProgramUniform3d;
/*  420: 449 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  421: 450 */     nglProgramUniform3d(program, location, v0, v1, v2, function_pointer);
/*  422:     */   }
/*  423:     */   
/*  424:     */   static native void nglProgramUniform3d(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  425:     */   
/*  426:     */   public static void glProgramUniform4d(int program, int location, double v0, double v1, double v2, double v3)
/*  427:     */   {
/*  428: 455 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  429: 456 */     long function_pointer = caps.glProgramUniform4d;
/*  430: 457 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  431: 458 */     nglProgramUniform4d(program, location, v0, v1, v2, v3, function_pointer);
/*  432:     */   }
/*  433:     */   
/*  434:     */   static native void nglProgramUniform4d(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  435:     */   
/*  436:     */   public static void glProgramUniform1(int program, int location, IntBuffer value)
/*  437:     */   {
/*  438: 463 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  439: 464 */     long function_pointer = caps.glProgramUniform1iv;
/*  440: 465 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  441: 466 */     BufferChecks.checkDirect(value);
/*  442: 467 */     nglProgramUniform1iv(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  443:     */   }
/*  444:     */   
/*  445:     */   static native void nglProgramUniform1iv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  446:     */   
/*  447:     */   public static void glProgramUniform2(int program, int location, IntBuffer value)
/*  448:     */   {
/*  449: 472 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  450: 473 */     long function_pointer = caps.glProgramUniform2iv;
/*  451: 474 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  452: 475 */     BufferChecks.checkDirect(value);
/*  453: 476 */     nglProgramUniform2iv(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/*  454:     */   }
/*  455:     */   
/*  456:     */   static native void nglProgramUniform2iv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  457:     */   
/*  458:     */   public static void glProgramUniform3(int program, int location, IntBuffer value)
/*  459:     */   {
/*  460: 481 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  461: 482 */     long function_pointer = caps.glProgramUniform3iv;
/*  462: 483 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  463: 484 */     BufferChecks.checkDirect(value);
/*  464: 485 */     nglProgramUniform3iv(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/*  465:     */   }
/*  466:     */   
/*  467:     */   static native void nglProgramUniform3iv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  468:     */   
/*  469:     */   public static void glProgramUniform4(int program, int location, IntBuffer value)
/*  470:     */   {
/*  471: 490 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  472: 491 */     long function_pointer = caps.glProgramUniform4iv;
/*  473: 492 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  474: 493 */     BufferChecks.checkDirect(value);
/*  475: 494 */     nglProgramUniform4iv(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/*  476:     */   }
/*  477:     */   
/*  478:     */   static native void nglProgramUniform4iv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  479:     */   
/*  480:     */   public static void glProgramUniform1(int program, int location, FloatBuffer value)
/*  481:     */   {
/*  482: 499 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  483: 500 */     long function_pointer = caps.glProgramUniform1fv;
/*  484: 501 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  485: 502 */     BufferChecks.checkDirect(value);
/*  486: 503 */     nglProgramUniform1fv(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  487:     */   }
/*  488:     */   
/*  489:     */   static native void nglProgramUniform1fv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  490:     */   
/*  491:     */   public static void glProgramUniform2(int program, int location, FloatBuffer value)
/*  492:     */   {
/*  493: 508 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  494: 509 */     long function_pointer = caps.glProgramUniform2fv;
/*  495: 510 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  496: 511 */     BufferChecks.checkDirect(value);
/*  497: 512 */     nglProgramUniform2fv(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/*  498:     */   }
/*  499:     */   
/*  500:     */   static native void nglProgramUniform2fv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  501:     */   
/*  502:     */   public static void glProgramUniform3(int program, int location, FloatBuffer value)
/*  503:     */   {
/*  504: 517 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  505: 518 */     long function_pointer = caps.glProgramUniform3fv;
/*  506: 519 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  507: 520 */     BufferChecks.checkDirect(value);
/*  508: 521 */     nglProgramUniform3fv(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/*  509:     */   }
/*  510:     */   
/*  511:     */   static native void nglProgramUniform3fv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  512:     */   
/*  513:     */   public static void glProgramUniform4(int program, int location, FloatBuffer value)
/*  514:     */   {
/*  515: 526 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  516: 527 */     long function_pointer = caps.glProgramUniform4fv;
/*  517: 528 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  518: 529 */     BufferChecks.checkDirect(value);
/*  519: 530 */     nglProgramUniform4fv(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/*  520:     */   }
/*  521:     */   
/*  522:     */   static native void nglProgramUniform4fv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  523:     */   
/*  524:     */   public static void glProgramUniform1(int program, int location, DoubleBuffer value)
/*  525:     */   {
/*  526: 535 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  527: 536 */     long function_pointer = caps.glProgramUniform1dv;
/*  528: 537 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  529: 538 */     BufferChecks.checkDirect(value);
/*  530: 539 */     nglProgramUniform1dv(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  531:     */   }
/*  532:     */   
/*  533:     */   static native void nglProgramUniform1dv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  534:     */   
/*  535:     */   public static void glProgramUniform2(int program, int location, DoubleBuffer value)
/*  536:     */   {
/*  537: 544 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  538: 545 */     long function_pointer = caps.glProgramUniform2dv;
/*  539: 546 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  540: 547 */     BufferChecks.checkDirect(value);
/*  541: 548 */     nglProgramUniform2dv(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/*  542:     */   }
/*  543:     */   
/*  544:     */   static native void nglProgramUniform2dv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  545:     */   
/*  546:     */   public static void glProgramUniform3(int program, int location, DoubleBuffer value)
/*  547:     */   {
/*  548: 553 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  549: 554 */     long function_pointer = caps.glProgramUniform3dv;
/*  550: 555 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  551: 556 */     BufferChecks.checkDirect(value);
/*  552: 557 */     nglProgramUniform3dv(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/*  553:     */   }
/*  554:     */   
/*  555:     */   static native void nglProgramUniform3dv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  556:     */   
/*  557:     */   public static void glProgramUniform4(int program, int location, DoubleBuffer value)
/*  558:     */   {
/*  559: 562 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  560: 563 */     long function_pointer = caps.glProgramUniform4dv;
/*  561: 564 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  562: 565 */     BufferChecks.checkDirect(value);
/*  563: 566 */     nglProgramUniform4dv(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/*  564:     */   }
/*  565:     */   
/*  566:     */   static native void nglProgramUniform4dv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  567:     */   
/*  568:     */   public static void glProgramUniform1ui(int program, int location, int v0)
/*  569:     */   {
/*  570: 571 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  571: 572 */     long function_pointer = caps.glProgramUniform1ui;
/*  572: 573 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  573: 574 */     nglProgramUniform1ui(program, location, v0, function_pointer);
/*  574:     */   }
/*  575:     */   
/*  576:     */   static native void nglProgramUniform1ui(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  577:     */   
/*  578:     */   public static void glProgramUniform2ui(int program, int location, int v0, int v1)
/*  579:     */   {
/*  580: 579 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  581: 580 */     long function_pointer = caps.glProgramUniform2ui;
/*  582: 581 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  583: 582 */     nglProgramUniform2ui(program, location, v0, v1, function_pointer);
/*  584:     */   }
/*  585:     */   
/*  586:     */   static native void nglProgramUniform2ui(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  587:     */   
/*  588:     */   public static void glProgramUniform3ui(int program, int location, int v0, int v1, int v2)
/*  589:     */   {
/*  590: 587 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  591: 588 */     long function_pointer = caps.glProgramUniform3ui;
/*  592: 589 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  593: 590 */     nglProgramUniform3ui(program, location, v0, v1, v2, function_pointer);
/*  594:     */   }
/*  595:     */   
/*  596:     */   static native void nglProgramUniform3ui(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  597:     */   
/*  598:     */   public static void glProgramUniform4ui(int program, int location, int v0, int v1, int v2, int v3)
/*  599:     */   {
/*  600: 595 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  601: 596 */     long function_pointer = caps.glProgramUniform4ui;
/*  602: 597 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  603: 598 */     nglProgramUniform4ui(program, location, v0, v1, v2, v3, function_pointer);
/*  604:     */   }
/*  605:     */   
/*  606:     */   static native void nglProgramUniform4ui(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  607:     */   
/*  608:     */   public static void glProgramUniform1u(int program, int location, IntBuffer value)
/*  609:     */   {
/*  610: 603 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  611: 604 */     long function_pointer = caps.glProgramUniform1uiv;
/*  612: 605 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  613: 606 */     BufferChecks.checkDirect(value);
/*  614: 607 */     nglProgramUniform1uiv(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  615:     */   }
/*  616:     */   
/*  617:     */   static native void nglProgramUniform1uiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  618:     */   
/*  619:     */   public static void glProgramUniform2u(int program, int location, IntBuffer value)
/*  620:     */   {
/*  621: 612 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  622: 613 */     long function_pointer = caps.glProgramUniform2uiv;
/*  623: 614 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  624: 615 */     BufferChecks.checkDirect(value);
/*  625: 616 */     nglProgramUniform2uiv(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/*  626:     */   }
/*  627:     */   
/*  628:     */   static native void nglProgramUniform2uiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  629:     */   
/*  630:     */   public static void glProgramUniform3u(int program, int location, IntBuffer value)
/*  631:     */   {
/*  632: 621 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  633: 622 */     long function_pointer = caps.glProgramUniform3uiv;
/*  634: 623 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  635: 624 */     BufferChecks.checkDirect(value);
/*  636: 625 */     nglProgramUniform3uiv(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/*  637:     */   }
/*  638:     */   
/*  639:     */   static native void nglProgramUniform3uiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  640:     */   
/*  641:     */   public static void glProgramUniform4u(int program, int location, IntBuffer value)
/*  642:     */   {
/*  643: 630 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  644: 631 */     long function_pointer = caps.glProgramUniform4uiv;
/*  645: 632 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  646: 633 */     BufferChecks.checkDirect(value);
/*  647: 634 */     nglProgramUniform4uiv(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/*  648:     */   }
/*  649:     */   
/*  650:     */   static native void nglProgramUniform4uiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  651:     */   
/*  652:     */   public static void glProgramUniformMatrix2(int program, int location, boolean transpose, FloatBuffer value)
/*  653:     */   {
/*  654: 639 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  655: 640 */     long function_pointer = caps.glProgramUniformMatrix2fv;
/*  656: 641 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  657: 642 */     BufferChecks.checkDirect(value);
/*  658: 643 */     nglProgramUniformMatrix2fv(program, location, value.remaining() >> 2, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  659:     */   }
/*  660:     */   
/*  661:     */   static native void nglProgramUniformMatrix2fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  662:     */   
/*  663:     */   public static void glProgramUniformMatrix3(int program, int location, boolean transpose, FloatBuffer value)
/*  664:     */   {
/*  665: 648 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  666: 649 */     long function_pointer = caps.glProgramUniformMatrix3fv;
/*  667: 650 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  668: 651 */     BufferChecks.checkDirect(value);
/*  669: 652 */     nglProgramUniformMatrix3fv(program, location, value.remaining() / 9, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  670:     */   }
/*  671:     */   
/*  672:     */   static native void nglProgramUniformMatrix3fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  673:     */   
/*  674:     */   public static void glProgramUniformMatrix4(int program, int location, boolean transpose, FloatBuffer value)
/*  675:     */   {
/*  676: 657 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  677: 658 */     long function_pointer = caps.glProgramUniformMatrix4fv;
/*  678: 659 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  679: 660 */     BufferChecks.checkDirect(value);
/*  680: 661 */     nglProgramUniformMatrix4fv(program, location, value.remaining() >> 4, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  681:     */   }
/*  682:     */   
/*  683:     */   static native void nglProgramUniformMatrix4fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  684:     */   
/*  685:     */   public static void glProgramUniformMatrix2(int program, int location, boolean transpose, DoubleBuffer value)
/*  686:     */   {
/*  687: 666 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  688: 667 */     long function_pointer = caps.glProgramUniformMatrix2dv;
/*  689: 668 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  690: 669 */     BufferChecks.checkDirect(value);
/*  691: 670 */     nglProgramUniformMatrix2dv(program, location, value.remaining() >> 2, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  692:     */   }
/*  693:     */   
/*  694:     */   static native void nglProgramUniformMatrix2dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  695:     */   
/*  696:     */   public static void glProgramUniformMatrix3(int program, int location, boolean transpose, DoubleBuffer value)
/*  697:     */   {
/*  698: 675 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  699: 676 */     long function_pointer = caps.glProgramUniformMatrix3dv;
/*  700: 677 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  701: 678 */     BufferChecks.checkDirect(value);
/*  702: 679 */     nglProgramUniformMatrix3dv(program, location, value.remaining() / 9, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  703:     */   }
/*  704:     */   
/*  705:     */   static native void nglProgramUniformMatrix3dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  706:     */   
/*  707:     */   public static void glProgramUniformMatrix4(int program, int location, boolean transpose, DoubleBuffer value)
/*  708:     */   {
/*  709: 684 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  710: 685 */     long function_pointer = caps.glProgramUniformMatrix4dv;
/*  711: 686 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  712: 687 */     BufferChecks.checkDirect(value);
/*  713: 688 */     nglProgramUniformMatrix4dv(program, location, value.remaining() >> 4, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  714:     */   }
/*  715:     */   
/*  716:     */   static native void nglProgramUniformMatrix4dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  717:     */   
/*  718:     */   public static void glProgramUniformMatrix2x3(int program, int location, boolean transpose, FloatBuffer value)
/*  719:     */   {
/*  720: 693 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  721: 694 */     long function_pointer = caps.glProgramUniformMatrix2x3fv;
/*  722: 695 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  723: 696 */     BufferChecks.checkDirect(value);
/*  724: 697 */     nglProgramUniformMatrix2x3fv(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  725:     */   }
/*  726:     */   
/*  727:     */   static native void nglProgramUniformMatrix2x3fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  728:     */   
/*  729:     */   public static void glProgramUniformMatrix3x2(int program, int location, boolean transpose, FloatBuffer value)
/*  730:     */   {
/*  731: 702 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  732: 703 */     long function_pointer = caps.glProgramUniformMatrix3x2fv;
/*  733: 704 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  734: 705 */     BufferChecks.checkDirect(value);
/*  735: 706 */     nglProgramUniformMatrix3x2fv(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  736:     */   }
/*  737:     */   
/*  738:     */   static native void nglProgramUniformMatrix3x2fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  739:     */   
/*  740:     */   public static void glProgramUniformMatrix2x4(int program, int location, boolean transpose, FloatBuffer value)
/*  741:     */   {
/*  742: 711 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  743: 712 */     long function_pointer = caps.glProgramUniformMatrix2x4fv;
/*  744: 713 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  745: 714 */     BufferChecks.checkDirect(value);
/*  746: 715 */     nglProgramUniformMatrix2x4fv(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  747:     */   }
/*  748:     */   
/*  749:     */   static native void nglProgramUniformMatrix2x4fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  750:     */   
/*  751:     */   public static void glProgramUniformMatrix4x2(int program, int location, boolean transpose, FloatBuffer value)
/*  752:     */   {
/*  753: 720 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  754: 721 */     long function_pointer = caps.glProgramUniformMatrix4x2fv;
/*  755: 722 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  756: 723 */     BufferChecks.checkDirect(value);
/*  757: 724 */     nglProgramUniformMatrix4x2fv(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  758:     */   }
/*  759:     */   
/*  760:     */   static native void nglProgramUniformMatrix4x2fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  761:     */   
/*  762:     */   public static void glProgramUniformMatrix3x4(int program, int location, boolean transpose, FloatBuffer value)
/*  763:     */   {
/*  764: 729 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  765: 730 */     long function_pointer = caps.glProgramUniformMatrix3x4fv;
/*  766: 731 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  767: 732 */     BufferChecks.checkDirect(value);
/*  768: 733 */     nglProgramUniformMatrix3x4fv(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  769:     */   }
/*  770:     */   
/*  771:     */   static native void nglProgramUniformMatrix3x4fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  772:     */   
/*  773:     */   public static void glProgramUniformMatrix4x3(int program, int location, boolean transpose, FloatBuffer value)
/*  774:     */   {
/*  775: 738 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  776: 739 */     long function_pointer = caps.glProgramUniformMatrix4x3fv;
/*  777: 740 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  778: 741 */     BufferChecks.checkDirect(value);
/*  779: 742 */     nglProgramUniformMatrix4x3fv(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  780:     */   }
/*  781:     */   
/*  782:     */   static native void nglProgramUniformMatrix4x3fv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  783:     */   
/*  784:     */   public static void glProgramUniformMatrix2x3(int program, int location, boolean transpose, DoubleBuffer value)
/*  785:     */   {
/*  786: 747 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  787: 748 */     long function_pointer = caps.glProgramUniformMatrix2x3dv;
/*  788: 749 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  789: 750 */     BufferChecks.checkDirect(value);
/*  790: 751 */     nglProgramUniformMatrix2x3dv(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  791:     */   }
/*  792:     */   
/*  793:     */   static native void nglProgramUniformMatrix2x3dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  794:     */   
/*  795:     */   public static void glProgramUniformMatrix3x2(int program, int location, boolean transpose, DoubleBuffer value)
/*  796:     */   {
/*  797: 756 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  798: 757 */     long function_pointer = caps.glProgramUniformMatrix3x2dv;
/*  799: 758 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  800: 759 */     BufferChecks.checkDirect(value);
/*  801: 760 */     nglProgramUniformMatrix3x2dv(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  802:     */   }
/*  803:     */   
/*  804:     */   static native void nglProgramUniformMatrix3x2dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  805:     */   
/*  806:     */   public static void glProgramUniformMatrix2x4(int program, int location, boolean transpose, DoubleBuffer value)
/*  807:     */   {
/*  808: 765 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  809: 766 */     long function_pointer = caps.glProgramUniformMatrix2x4dv;
/*  810: 767 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  811: 768 */     BufferChecks.checkDirect(value);
/*  812: 769 */     nglProgramUniformMatrix2x4dv(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  813:     */   }
/*  814:     */   
/*  815:     */   static native void nglProgramUniformMatrix2x4dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  816:     */   
/*  817:     */   public static void glProgramUniformMatrix4x2(int program, int location, boolean transpose, DoubleBuffer value)
/*  818:     */   {
/*  819: 774 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  820: 775 */     long function_pointer = caps.glProgramUniformMatrix4x2dv;
/*  821: 776 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  822: 777 */     BufferChecks.checkDirect(value);
/*  823: 778 */     nglProgramUniformMatrix4x2dv(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  824:     */   }
/*  825:     */   
/*  826:     */   static native void nglProgramUniformMatrix4x2dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  827:     */   
/*  828:     */   public static void glProgramUniformMatrix3x4(int program, int location, boolean transpose, DoubleBuffer value)
/*  829:     */   {
/*  830: 783 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  831: 784 */     long function_pointer = caps.glProgramUniformMatrix3x4dv;
/*  832: 785 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  833: 786 */     BufferChecks.checkDirect(value);
/*  834: 787 */     nglProgramUniformMatrix3x4dv(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  835:     */   }
/*  836:     */   
/*  837:     */   static native void nglProgramUniformMatrix3x4dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  838:     */   
/*  839:     */   public static void glProgramUniformMatrix4x3(int program, int location, boolean transpose, DoubleBuffer value)
/*  840:     */   {
/*  841: 792 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  842: 793 */     long function_pointer = caps.glProgramUniformMatrix4x3dv;
/*  843: 794 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  844: 795 */     BufferChecks.checkDirect(value);
/*  845: 796 */     nglProgramUniformMatrix4x3dv(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/*  846:     */   }
/*  847:     */   
/*  848:     */   static native void nglProgramUniformMatrix4x3dv(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/*  849:     */   
/*  850:     */   public static void glValidateProgramPipeline(int pipeline)
/*  851:     */   {
/*  852: 801 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  853: 802 */     long function_pointer = caps.glValidateProgramPipeline;
/*  854: 803 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  855: 804 */     nglValidateProgramPipeline(pipeline, function_pointer);
/*  856:     */   }
/*  857:     */   
/*  858:     */   static native void nglValidateProgramPipeline(int paramInt, long paramLong);
/*  859:     */   
/*  860:     */   public static void glGetProgramPipelineInfoLog(int pipeline, IntBuffer length, ByteBuffer infoLog)
/*  861:     */   {
/*  862: 809 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  863: 810 */     long function_pointer = caps.glGetProgramPipelineInfoLog;
/*  864: 811 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  865: 812 */     if (length != null) {
/*  866: 813 */       BufferChecks.checkBuffer(length, 1);
/*  867:     */     }
/*  868: 814 */     BufferChecks.checkDirect(infoLog);
/*  869: 815 */     nglGetProgramPipelineInfoLog(pipeline, infoLog.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  870:     */   }
/*  871:     */   
/*  872:     */   static native void nglGetProgramPipelineInfoLog(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  873:     */   
/*  874:     */   public static String glGetProgramPipelineInfoLog(int pipeline, int bufSize)
/*  875:     */   {
/*  876: 821 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  877: 822 */     long function_pointer = caps.glGetProgramPipelineInfoLog;
/*  878: 823 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  879: 824 */     IntBuffer infoLog_length = APIUtil.getLengths(caps);
/*  880: 825 */     ByteBuffer infoLog = APIUtil.getBufferByte(caps, bufSize);
/*  881: 826 */     nglGetProgramPipelineInfoLog(pipeline, bufSize, MemoryUtil.getAddress0(infoLog_length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  882: 827 */     infoLog.limit(infoLog_length.get(0));
/*  883: 828 */     return APIUtil.getString(caps, infoLog);
/*  884:     */   }
/*  885:     */   
/*  886:     */   public static void glVertexAttribL1d(int index, double x)
/*  887:     */   {
/*  888: 832 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  889: 833 */     long function_pointer = caps.glVertexAttribL1d;
/*  890: 834 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  891: 835 */     nglVertexAttribL1d(index, x, function_pointer);
/*  892:     */   }
/*  893:     */   
/*  894:     */   static native void nglVertexAttribL1d(int paramInt, double paramDouble, long paramLong);
/*  895:     */   
/*  896:     */   public static void glVertexAttribL2d(int index, double x, double y)
/*  897:     */   {
/*  898: 840 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  899: 841 */     long function_pointer = caps.glVertexAttribL2d;
/*  900: 842 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  901: 843 */     nglVertexAttribL2d(index, x, y, function_pointer);
/*  902:     */   }
/*  903:     */   
/*  904:     */   static native void nglVertexAttribL2d(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/*  905:     */   
/*  906:     */   public static void glVertexAttribL3d(int index, double x, double y, double z)
/*  907:     */   {
/*  908: 848 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  909: 849 */     long function_pointer = caps.glVertexAttribL3d;
/*  910: 850 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  911: 851 */     nglVertexAttribL3d(index, x, y, z, function_pointer);
/*  912:     */   }
/*  913:     */   
/*  914:     */   static native void nglVertexAttribL3d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  915:     */   
/*  916:     */   public static void glVertexAttribL4d(int index, double x, double y, double z, double w)
/*  917:     */   {
/*  918: 856 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  919: 857 */     long function_pointer = caps.glVertexAttribL4d;
/*  920: 858 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  921: 859 */     nglVertexAttribL4d(index, x, y, z, w, function_pointer);
/*  922:     */   }
/*  923:     */   
/*  924:     */   static native void nglVertexAttribL4d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  925:     */   
/*  926:     */   public static void glVertexAttribL1(int index, DoubleBuffer v)
/*  927:     */   {
/*  928: 864 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  929: 865 */     long function_pointer = caps.glVertexAttribL1dv;
/*  930: 866 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  931: 867 */     BufferChecks.checkBuffer(v, 1);
/*  932: 868 */     nglVertexAttribL1dv(index, MemoryUtil.getAddress(v), function_pointer);
/*  933:     */   }
/*  934:     */   
/*  935:     */   static native void nglVertexAttribL1dv(int paramInt, long paramLong1, long paramLong2);
/*  936:     */   
/*  937:     */   public static void glVertexAttribL2(int index, DoubleBuffer v)
/*  938:     */   {
/*  939: 873 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  940: 874 */     long function_pointer = caps.glVertexAttribL2dv;
/*  941: 875 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  942: 876 */     BufferChecks.checkBuffer(v, 2);
/*  943: 877 */     nglVertexAttribL2dv(index, MemoryUtil.getAddress(v), function_pointer);
/*  944:     */   }
/*  945:     */   
/*  946:     */   static native void nglVertexAttribL2dv(int paramInt, long paramLong1, long paramLong2);
/*  947:     */   
/*  948:     */   public static void glVertexAttribL3(int index, DoubleBuffer v)
/*  949:     */   {
/*  950: 882 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  951: 883 */     long function_pointer = caps.glVertexAttribL3dv;
/*  952: 884 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  953: 885 */     BufferChecks.checkBuffer(v, 3);
/*  954: 886 */     nglVertexAttribL3dv(index, MemoryUtil.getAddress(v), function_pointer);
/*  955:     */   }
/*  956:     */   
/*  957:     */   static native void nglVertexAttribL3dv(int paramInt, long paramLong1, long paramLong2);
/*  958:     */   
/*  959:     */   public static void glVertexAttribL4(int index, DoubleBuffer v)
/*  960:     */   {
/*  961: 891 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  962: 892 */     long function_pointer = caps.glVertexAttribL4dv;
/*  963: 893 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  964: 894 */     BufferChecks.checkBuffer(v, 4);
/*  965: 895 */     nglVertexAttribL4dv(index, MemoryUtil.getAddress(v), function_pointer);
/*  966:     */   }
/*  967:     */   
/*  968:     */   static native void nglVertexAttribL4dv(int paramInt, long paramLong1, long paramLong2);
/*  969:     */   
/*  970:     */   public static void glVertexAttribLPointer(int index, int size, int stride, DoubleBuffer pointer)
/*  971:     */   {
/*  972: 900 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  973: 901 */     long function_pointer = caps.glVertexAttribLPointer;
/*  974: 902 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  975: 903 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  976: 904 */     BufferChecks.checkDirect(pointer);
/*  977: 905 */     if (LWJGLUtil.CHECKS) {
/*  978: 905 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = pointer;
/*  979:     */     }
/*  980: 906 */     nglVertexAttribLPointer(index, size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  981:     */   }
/*  982:     */   
/*  983:     */   static native void nglVertexAttribLPointer(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  984:     */   
/*  985:     */   public static void glVertexAttribLPointer(int index, int size, int stride, long pointer_buffer_offset)
/*  986:     */   {
/*  987: 910 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  988: 911 */     long function_pointer = caps.glVertexAttribLPointer;
/*  989: 912 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  990: 913 */     GLChecks.ensureArrayVBOenabled(caps);
/*  991: 914 */     nglVertexAttribLPointerBO(index, size, 5130, stride, pointer_buffer_offset, function_pointer);
/*  992:     */   }
/*  993:     */   
/*  994:     */   static native void nglVertexAttribLPointerBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  995:     */   
/*  996:     */   public static void glGetVertexAttribL(int index, int pname, DoubleBuffer params)
/*  997:     */   {
/*  998: 919 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  999: 920 */     long function_pointer = caps.glGetVertexAttribLdv;
/* 1000: 921 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1001: 922 */     BufferChecks.checkBuffer(params, 4);
/* 1002: 923 */     nglGetVertexAttribLdv(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1003:     */   }
/* 1004:     */   
/* 1005:     */   static native void nglGetVertexAttribLdv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1006:     */   
/* 1007:     */   public static void glViewportArray(int first, FloatBuffer v)
/* 1008:     */   {
/* 1009: 928 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1010: 929 */     long function_pointer = caps.glViewportArrayv;
/* 1011: 930 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1012: 931 */     BufferChecks.checkDirect(v);
/* 1013: 932 */     nglViewportArrayv(first, v.remaining() >> 2, MemoryUtil.getAddress(v), function_pointer);
/* 1014:     */   }
/* 1015:     */   
/* 1016:     */   static native void nglViewportArrayv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1017:     */   
/* 1018:     */   public static void glViewportIndexedf(int index, float x, float y, float w, float h)
/* 1019:     */   {
/* 1020: 937 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1021: 938 */     long function_pointer = caps.glViewportIndexedf;
/* 1022: 939 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1023: 940 */     nglViewportIndexedf(index, x, y, w, h, function_pointer);
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   static native void nglViewportIndexedf(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 1027:     */   
/* 1028:     */   public static void glViewportIndexed(int index, FloatBuffer v)
/* 1029:     */   {
/* 1030: 945 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1031: 946 */     long function_pointer = caps.glViewportIndexedfv;
/* 1032: 947 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1033: 948 */     BufferChecks.checkBuffer(v, 4);
/* 1034: 949 */     nglViewportIndexedfv(index, MemoryUtil.getAddress(v), function_pointer);
/* 1035:     */   }
/* 1036:     */   
/* 1037:     */   static native void nglViewportIndexedfv(int paramInt, long paramLong1, long paramLong2);
/* 1038:     */   
/* 1039:     */   public static void glScissorArray(int first, IntBuffer v)
/* 1040:     */   {
/* 1041: 954 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1042: 955 */     long function_pointer = caps.glScissorArrayv;
/* 1043: 956 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1044: 957 */     BufferChecks.checkDirect(v);
/* 1045: 958 */     nglScissorArrayv(first, v.remaining() >> 2, MemoryUtil.getAddress(v), function_pointer);
/* 1046:     */   }
/* 1047:     */   
/* 1048:     */   static native void nglScissorArrayv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1049:     */   
/* 1050:     */   public static void glScissorIndexed(int index, int left, int bottom, int width, int height)
/* 1051:     */   {
/* 1052: 963 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1053: 964 */     long function_pointer = caps.glScissorIndexed;
/* 1054: 965 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1055: 966 */     nglScissorIndexed(index, left, bottom, width, height, function_pointer);
/* 1056:     */   }
/* 1057:     */   
/* 1058:     */   static native void nglScissorIndexed(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 1059:     */   
/* 1060:     */   public static void glScissorIndexed(int index, IntBuffer v)
/* 1061:     */   {
/* 1062: 971 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1063: 972 */     long function_pointer = caps.glScissorIndexedv;
/* 1064: 973 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1065: 974 */     BufferChecks.checkBuffer(v, 4);
/* 1066: 975 */     nglScissorIndexedv(index, MemoryUtil.getAddress(v), function_pointer);
/* 1067:     */   }
/* 1068:     */   
/* 1069:     */   static native void nglScissorIndexedv(int paramInt, long paramLong1, long paramLong2);
/* 1070:     */   
/* 1071:     */   public static void glDepthRangeArray(int first, DoubleBuffer v)
/* 1072:     */   {
/* 1073: 980 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1074: 981 */     long function_pointer = caps.glDepthRangeArrayv;
/* 1075: 982 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1076: 983 */     BufferChecks.checkDirect(v);
/* 1077: 984 */     nglDepthRangeArrayv(first, v.remaining() >> 1, MemoryUtil.getAddress(v), function_pointer);
/* 1078:     */   }
/* 1079:     */   
/* 1080:     */   static native void nglDepthRangeArrayv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1081:     */   
/* 1082:     */   public static void glDepthRangeIndexed(int index, double n, double f)
/* 1083:     */   {
/* 1084: 989 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1085: 990 */     long function_pointer = caps.glDepthRangeIndexed;
/* 1086: 991 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1087: 992 */     nglDepthRangeIndexed(index, n, f, function_pointer);
/* 1088:     */   }
/* 1089:     */   
/* 1090:     */   static native void nglDepthRangeIndexed(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 1091:     */   
/* 1092:     */   public static void glGetFloat(int target, int index, FloatBuffer data)
/* 1093:     */   {
/* 1094: 997 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1095: 998 */     long function_pointer = caps.glGetFloati_v;
/* 1096: 999 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1097:1000 */     BufferChecks.checkDirect(data);
/* 1098:1001 */     nglGetFloati_v(target, index, MemoryUtil.getAddress(data), function_pointer);
/* 1099:     */   }
/* 1100:     */   
/* 1101:     */   static native void nglGetFloati_v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1102:     */   
/* 1103:     */   public static float glGetFloat(int target, int index)
/* 1104:     */   {
/* 1105:1007 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1106:1008 */     long function_pointer = caps.glGetFloati_v;
/* 1107:1009 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1108:1010 */     FloatBuffer data = APIUtil.getBufferFloat(caps);
/* 1109:1011 */     nglGetFloati_v(target, index, MemoryUtil.getAddress(data), function_pointer);
/* 1110:1012 */     return data.get(0);
/* 1111:     */   }
/* 1112:     */   
/* 1113:     */   public static void glGetDouble(int target, int index, DoubleBuffer data)
/* 1114:     */   {
/* 1115:1016 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1116:1017 */     long function_pointer = caps.glGetDoublei_v;
/* 1117:1018 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1118:1019 */     BufferChecks.checkDirect(data);
/* 1119:1020 */     nglGetDoublei_v(target, index, MemoryUtil.getAddress(data), function_pointer);
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static native void nglGetDoublei_v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1123:     */   
/* 1124:     */   public static double glGetDouble(int target, int index)
/* 1125:     */   {
/* 1126:1026 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1127:1027 */     long function_pointer = caps.glGetDoublei_v;
/* 1128:1028 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1129:1029 */     DoubleBuffer data = APIUtil.getBufferDouble(caps);
/* 1130:1030 */     nglGetDoublei_v(target, index, MemoryUtil.getAddress(data), function_pointer);
/* 1131:1031 */     return data.get(0);
/* 1132:     */   }
/* 1133:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL41
 * JD-Core Version:    0.7.0.1
 */