/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ class ReferencesStack
/*  4:   */ {
/*  5:   */   private References[] references_stack;
/*  6:   */   private int stack_pos;
/*  7:   */   
/*  8:   */   public References getReferences()
/*  9:   */   {
/* 10:41 */     return this.references_stack[this.stack_pos];
/* 11:   */   }
/* 12:   */   
/* 13:   */   public void pushState()
/* 14:   */   {
/* 15:45 */     int pos = ++this.stack_pos;
/* 16:46 */     if (pos == this.references_stack.length) {
/* 17:47 */       growStack();
/* 18:   */     }
/* 19:49 */     this.references_stack[pos].copy(this.references_stack[(pos - 1)], -1);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public References popState(int mask)
/* 23:   */   {
/* 24:53 */     References result = this.references_stack[(this.stack_pos--)];
/* 25:   */     
/* 26:55 */     this.references_stack[this.stack_pos].copy(result, mask ^ 0xFFFFFFFF);
/* 27:56 */     result.clear();
/* 28:   */     
/* 29:58 */     return result;
/* 30:   */   }
/* 31:   */   
/* 32:   */   private void growStack()
/* 33:   */   {
/* 34:62 */     References[] new_references_stack = new References[this.references_stack.length + 1];
/* 35:63 */     System.arraycopy(this.references_stack, 0, new_references_stack, 0, this.references_stack.length);
/* 36:64 */     this.references_stack = new_references_stack;
/* 37:65 */     this.references_stack[(this.references_stack.length - 1)] = new References(GLContext.getCapabilities());
/* 38:   */   }
/* 39:   */   
/* 40:   */   ReferencesStack()
/* 41:   */   {
/* 42:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:70 */     this.references_stack = new References[1];
/* 44:71 */     this.stack_pos = 0;
/* 45:72 */     for (int i = 0; i < this.references_stack.length; i++) {
/* 46:73 */       this.references_stack[i] = new References(caps);
/* 47:   */     }
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ReferencesStack
 * JD-Core Version:    0.7.0.1
 */