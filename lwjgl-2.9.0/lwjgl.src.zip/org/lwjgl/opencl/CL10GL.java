/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ import org.lwjgl.PointerBuffer;
/*   8:    */ 
/*   9:    */ public final class CL10GL
/*  10:    */ {
/*  11:    */   public static final int CL_GL_OBJECT_BUFFER = 8192;
/*  12:    */   public static final int CL_GL_OBJECT_TEXTURE2D = 8193;
/*  13:    */   public static final int CL_GL_OBJECT_TEXTURE3D = 8194;
/*  14:    */   public static final int CL_GL_OBJECT_RENDERBUFFER = 8195;
/*  15:    */   public static final int CL_GL_TEXTURE_TARGET = 8196;
/*  16:    */   public static final int CL_GL_MIPMAP_LEVEL = 8197;
/*  17:    */   
/*  18:    */   public static CLMem clCreateFromGLBuffer(CLContext context, long flags, int bufobj, IntBuffer errcode_ret)
/*  19:    */   {
/*  20: 30 */     long function_pointer = CLCapabilities.clCreateFromGLBuffer;
/*  21: 31 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  22: 32 */     if (errcode_ret != null) {
/*  23: 33 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  24:    */     }
/*  25: 34 */     CLMem __result = new CLMem(nclCreateFromGLBuffer(context.getPointer(), flags, bufobj, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  26: 35 */     return __result;
/*  27:    */   }
/*  28:    */   
/*  29:    */   static native long nclCreateFromGLBuffer(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4);
/*  30:    */   
/*  31:    */   public static CLMem clCreateFromGLTexture2D(CLContext context, long flags, int target, int miplevel, int texture, IntBuffer errcode_ret)
/*  32:    */   {
/*  33: 40 */     long function_pointer = CLCapabilities.clCreateFromGLTexture2D;
/*  34: 41 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  35: 42 */     if (errcode_ret != null) {
/*  36: 43 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  37:    */     }
/*  38: 44 */     CLMem __result = new CLMem(nclCreateFromGLTexture2D(context.getPointer(), flags, target, miplevel, texture, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  39: 45 */     return __result;
/*  40:    */   }
/*  41:    */   
/*  42:    */   static native long nclCreateFromGLTexture2D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, long paramLong3, long paramLong4);
/*  43:    */   
/*  44:    */   public static CLMem clCreateFromGLTexture3D(CLContext context, long flags, int target, int miplevel, int texture, IntBuffer errcode_ret)
/*  45:    */   {
/*  46: 50 */     long function_pointer = CLCapabilities.clCreateFromGLTexture3D;
/*  47: 51 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  48: 52 */     if (errcode_ret != null) {
/*  49: 53 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  50:    */     }
/*  51: 54 */     CLMem __result = new CLMem(nclCreateFromGLTexture3D(context.getPointer(), flags, target, miplevel, texture, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  52: 55 */     return __result;
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native long nclCreateFromGLTexture3D(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, long paramLong3, long paramLong4);
/*  56:    */   
/*  57:    */   public static CLMem clCreateFromGLRenderbuffer(CLContext context, long flags, int renderbuffer, IntBuffer errcode_ret)
/*  58:    */   {
/*  59: 60 */     long function_pointer = CLCapabilities.clCreateFromGLRenderbuffer;
/*  60: 61 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 62 */     if (errcode_ret != null) {
/*  62: 63 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  63:    */     }
/*  64: 64 */     CLMem __result = new CLMem(nclCreateFromGLRenderbuffer(context.getPointer(), flags, renderbuffer, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  65: 65 */     return __result;
/*  66:    */   }
/*  67:    */   
/*  68:    */   static native long nclCreateFromGLRenderbuffer(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4);
/*  69:    */   
/*  70:    */   public static int clGetGLObjectInfo(CLMem memobj, IntBuffer gl_object_type, IntBuffer gl_object_name)
/*  71:    */   {
/*  72: 70 */     long function_pointer = CLCapabilities.clGetGLObjectInfo;
/*  73: 71 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  74: 72 */     if (gl_object_type != null) {
/*  75: 73 */       BufferChecks.checkBuffer(gl_object_type, 1);
/*  76:    */     }
/*  77: 74 */     if (gl_object_name != null) {
/*  78: 75 */       BufferChecks.checkBuffer(gl_object_name, 1);
/*  79:    */     }
/*  80: 76 */     int __result = nclGetGLObjectInfo(memobj.getPointer(), MemoryUtil.getAddressSafe(gl_object_type), MemoryUtil.getAddressSafe(gl_object_name), function_pointer);
/*  81: 77 */     return __result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   static native int nclGetGLObjectInfo(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*  85:    */   
/*  86:    */   public static int clGetGLTextureInfo(CLMem memobj, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  87:    */   {
/*  88: 82 */     long function_pointer = CLCapabilities.clGetGLTextureInfo;
/*  89: 83 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  90: 84 */     if (param_value != null) {
/*  91: 85 */       BufferChecks.checkDirect(param_value);
/*  92:    */     }
/*  93: 86 */     if (param_value_size_ret != null) {
/*  94: 87 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/*  95:    */     }
/*  96: 88 */     int __result = nclGetGLTextureInfo(memobj.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/*  97: 89 */     return __result;
/*  98:    */   }
/*  99:    */   
/* 100:    */   static native int nclGetGLTextureInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 101:    */   
/* 102:    */   public static int clEnqueueAcquireGLObjects(CLCommandQueue command_queue, PointerBuffer mem_objects, PointerBuffer event_wait_list, PointerBuffer event)
/* 103:    */   {
/* 104: 94 */     long function_pointer = CLCapabilities.clEnqueueAcquireGLObjects;
/* 105: 95 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106: 96 */     BufferChecks.checkBuffer(mem_objects, 1);
/* 107: 97 */     if (event_wait_list != null) {
/* 108: 98 */       BufferChecks.checkDirect(event_wait_list);
/* 109:    */     }
/* 110: 99 */     if (event != null) {
/* 111:100 */       BufferChecks.checkBuffer(event, 1);
/* 112:    */     }
/* 113:101 */     int __result = nclEnqueueAcquireGLObjects(command_queue.getPointer(), mem_objects.remaining(), MemoryUtil.getAddress(mem_objects), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 114:102 */     if (__result == 0) {
/* 115:102 */       command_queue.registerCLEvent(event);
/* 116:    */     }
/* 117:103 */     return __result;
/* 118:    */   }
/* 119:    */   
/* 120:    */   static native int nclEnqueueAcquireGLObjects(long paramLong1, int paramInt1, long paramLong2, int paramInt2, long paramLong3, long paramLong4, long paramLong5);
/* 121:    */   
/* 122:    */   public static int clEnqueueAcquireGLObjects(CLCommandQueue command_queue, CLMem mem_object, PointerBuffer event_wait_list, PointerBuffer event)
/* 123:    */   {
/* 124:109 */     long function_pointer = CLCapabilities.clEnqueueAcquireGLObjects;
/* 125:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:111 */     if (event_wait_list != null) {
/* 127:112 */       BufferChecks.checkDirect(event_wait_list);
/* 128:    */     }
/* 129:113 */     if (event != null) {
/* 130:114 */       BufferChecks.checkBuffer(event, 1);
/* 131:    */     }
/* 132:115 */     int __result = nclEnqueueAcquireGLObjects(command_queue.getPointer(), 1, APIUtil.getPointer(mem_object), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 133:116 */     if (__result == 0) {
/* 134:116 */       command_queue.registerCLEvent(event);
/* 135:    */     }
/* 136:117 */     return __result;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static int clEnqueueReleaseGLObjects(CLCommandQueue command_queue, PointerBuffer mem_objects, PointerBuffer event_wait_list, PointerBuffer event)
/* 140:    */   {
/* 141:121 */     long function_pointer = CLCapabilities.clEnqueueReleaseGLObjects;
/* 142:122 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 143:123 */     BufferChecks.checkBuffer(mem_objects, 1);
/* 144:124 */     if (event_wait_list != null) {
/* 145:125 */       BufferChecks.checkDirect(event_wait_list);
/* 146:    */     }
/* 147:126 */     if (event != null) {
/* 148:127 */       BufferChecks.checkBuffer(event, 1);
/* 149:    */     }
/* 150:128 */     int __result = nclEnqueueReleaseGLObjects(command_queue.getPointer(), mem_objects.remaining(), MemoryUtil.getAddress(mem_objects), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 151:129 */     if (__result == 0) {
/* 152:129 */       command_queue.registerCLEvent(event);
/* 153:    */     }
/* 154:130 */     return __result;
/* 155:    */   }
/* 156:    */   
/* 157:    */   static native int nclEnqueueReleaseGLObjects(long paramLong1, int paramInt1, long paramLong2, int paramInt2, long paramLong3, long paramLong4, long paramLong5);
/* 158:    */   
/* 159:    */   public static int clEnqueueReleaseGLObjects(CLCommandQueue command_queue, CLMem mem_object, PointerBuffer event_wait_list, PointerBuffer event)
/* 160:    */   {
/* 161:136 */     long function_pointer = CLCapabilities.clEnqueueReleaseGLObjects;
/* 162:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:138 */     if (event_wait_list != null) {
/* 164:139 */       BufferChecks.checkDirect(event_wait_list);
/* 165:    */     }
/* 166:140 */     if (event != null) {
/* 167:141 */       BufferChecks.checkBuffer(event, 1);
/* 168:    */     }
/* 169:142 */     int __result = nclEnqueueReleaseGLObjects(command_queue.getPointer(), 1, APIUtil.getPointer(mem_object), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 170:143 */     if (__result == 0) {
/* 171:143 */       command_queue.registerCLEvent(event);
/* 172:    */     }
/* 173:144 */     return __result;
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL10GL
 * JD-Core Version:    0.7.0.1
 */