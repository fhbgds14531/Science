package org.lwjgl.opengl;

public final class NVTextureCompressionVTC
{
  public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 33776;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778;
  public static final int GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTextureCompressionVTC
 * JD-Core Version:    0.7.0.1
 */