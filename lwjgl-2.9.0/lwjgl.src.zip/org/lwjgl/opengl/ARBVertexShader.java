/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ import org.lwjgl.MemoryUtil;
/*  12:    */ 
/*  13:    */ public final class ARBVertexShader
/*  14:    */ {
/*  15:    */   public static final int GL_VERTEX_SHADER_ARB = 35633;
/*  16:    */   public static final int GL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB = 35658;
/*  17:    */   public static final int GL_MAX_VARYING_FLOATS_ARB = 35659;
/*  18:    */   public static final int GL_MAX_VERTEX_ATTRIBS_ARB = 34921;
/*  19:    */   public static final int GL_MAX_TEXTURE_IMAGE_UNITS_ARB = 34930;
/*  20:    */   public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660;
/*  21:    */   public static final int GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB = 35661;
/*  22:    */   public static final int GL_MAX_TEXTURE_COORDS_ARB = 34929;
/*  23:    */   public static final int GL_VERTEX_PROGRAM_POINT_SIZE_ARB = 34370;
/*  24:    */   public static final int GL_VERTEX_PROGRAM_TWO_SIDE_ARB = 34371;
/*  25:    */   public static final int GL_OBJECT_ACTIVE_ATTRIBUTES_ARB = 35721;
/*  26:    */   public static final int GL_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB = 35722;
/*  27:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB = 34338;
/*  28:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB = 34339;
/*  29:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB = 34340;
/*  30:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB = 34341;
/*  31:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB = 34922;
/*  32:    */   public static final int GL_CURRENT_VERTEX_ATTRIB_ARB = 34342;
/*  33:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB = 34373;
/*  34:    */   public static final int GL_FLOAT_VEC2_ARB = 35664;
/*  35:    */   public static final int GL_FLOAT_VEC3_ARB = 35665;
/*  36:    */   public static final int GL_FLOAT_VEC4_ARB = 35666;
/*  37:    */   public static final int GL_FLOAT_MAT2_ARB = 35674;
/*  38:    */   public static final int GL_FLOAT_MAT3_ARB = 35675;
/*  39:    */   public static final int GL_FLOAT_MAT4_ARB = 35676;
/*  40:    */   
/*  41:    */   public static void glVertexAttrib1sARB(int index, short v0)
/*  42:    */   {
/*  43: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  44: 71 */     long function_pointer = caps.glVertexAttrib1sARB;
/*  45: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  46: 73 */     nglVertexAttrib1sARB(index, v0, function_pointer);
/*  47:    */   }
/*  48:    */   
/*  49:    */   static native void nglVertexAttrib1sARB(int paramInt, short paramShort, long paramLong);
/*  50:    */   
/*  51:    */   public static void glVertexAttrib1fARB(int index, float v0)
/*  52:    */   {
/*  53: 78 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  54: 79 */     long function_pointer = caps.glVertexAttrib1fARB;
/*  55: 80 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  56: 81 */     nglVertexAttrib1fARB(index, v0, function_pointer);
/*  57:    */   }
/*  58:    */   
/*  59:    */   static native void nglVertexAttrib1fARB(int paramInt, float paramFloat, long paramLong);
/*  60:    */   
/*  61:    */   public static void glVertexAttrib1dARB(int index, double v0)
/*  62:    */   {
/*  63: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  64: 87 */     long function_pointer = caps.glVertexAttrib1dARB;
/*  65: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  66: 89 */     nglVertexAttrib1dARB(index, v0, function_pointer);
/*  67:    */   }
/*  68:    */   
/*  69:    */   static native void nglVertexAttrib1dARB(int paramInt, double paramDouble, long paramLong);
/*  70:    */   
/*  71:    */   public static void glVertexAttrib2sARB(int index, short v0, short v1)
/*  72:    */   {
/*  73: 94 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  74: 95 */     long function_pointer = caps.glVertexAttrib2sARB;
/*  75: 96 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  76: 97 */     nglVertexAttrib2sARB(index, v0, v1, function_pointer);
/*  77:    */   }
/*  78:    */   
/*  79:    */   static native void nglVertexAttrib2sARB(int paramInt, short paramShort1, short paramShort2, long paramLong);
/*  80:    */   
/*  81:    */   public static void glVertexAttrib2fARB(int index, float v0, float v1)
/*  82:    */   {
/*  83:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  84:103 */     long function_pointer = caps.glVertexAttrib2fARB;
/*  85:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  86:105 */     nglVertexAttrib2fARB(index, v0, v1, function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglVertexAttrib2fARB(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*  90:    */   
/*  91:    */   public static void glVertexAttrib2dARB(int index, double v0, double v1)
/*  92:    */   {
/*  93:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  94:111 */     long function_pointer = caps.glVertexAttrib2dARB;
/*  95:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  96:113 */     nglVertexAttrib2dARB(index, v0, v1, function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglVertexAttrib2dARB(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 100:    */   
/* 101:    */   public static void glVertexAttrib3sARB(int index, short v0, short v1, short v2)
/* 102:    */   {
/* 103:118 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104:119 */     long function_pointer = caps.glVertexAttrib3sARB;
/* 105:120 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106:121 */     nglVertexAttrib3sARB(index, v0, v1, v2, function_pointer);
/* 107:    */   }
/* 108:    */   
/* 109:    */   static native void nglVertexAttrib3sARB(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 110:    */   
/* 111:    */   public static void glVertexAttrib3fARB(int index, float v0, float v1, float v2)
/* 112:    */   {
/* 113:126 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 114:127 */     long function_pointer = caps.glVertexAttrib3fARB;
/* 115:128 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 116:129 */     nglVertexAttrib3fARB(index, v0, v1, v2, function_pointer);
/* 117:    */   }
/* 118:    */   
/* 119:    */   static native void nglVertexAttrib3fARB(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 120:    */   
/* 121:    */   public static void glVertexAttrib3dARB(int index, double v0, double v1, double v2)
/* 122:    */   {
/* 123:134 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 124:135 */     long function_pointer = caps.glVertexAttrib3dARB;
/* 125:136 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:137 */     nglVertexAttrib3dARB(index, v0, v1, v2, function_pointer);
/* 127:    */   }
/* 128:    */   
/* 129:    */   static native void nglVertexAttrib3dARB(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 130:    */   
/* 131:    */   public static void glVertexAttrib4sARB(int index, short v0, short v1, short v2, short v3)
/* 132:    */   {
/* 133:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 134:143 */     long function_pointer = caps.glVertexAttrib4sARB;
/* 135:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 136:145 */     nglVertexAttrib4sARB(index, v0, v1, v2, v3, function_pointer);
/* 137:    */   }
/* 138:    */   
/* 139:    */   static native void nglVertexAttrib4sARB(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 140:    */   
/* 141:    */   public static void glVertexAttrib4fARB(int index, float v0, float v1, float v2, float v3)
/* 142:    */   {
/* 143:150 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 144:151 */     long function_pointer = caps.glVertexAttrib4fARB;
/* 145:152 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 146:153 */     nglVertexAttrib4fARB(index, v0, v1, v2, v3, function_pointer);
/* 147:    */   }
/* 148:    */   
/* 149:    */   static native void nglVertexAttrib4fARB(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 150:    */   
/* 151:    */   public static void glVertexAttrib4dARB(int index, double v0, double v1, double v2, double v3)
/* 152:    */   {
/* 153:158 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 154:159 */     long function_pointer = caps.glVertexAttrib4dARB;
/* 155:160 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 156:161 */     nglVertexAttrib4dARB(index, v0, v1, v2, v3, function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static native void nglVertexAttrib4dARB(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 160:    */   
/* 161:    */   public static void glVertexAttrib4NubARB(int index, byte x, byte y, byte z, byte w)
/* 162:    */   {
/* 163:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 164:167 */     long function_pointer = caps.glVertexAttrib4NubARB;
/* 165:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 166:169 */     nglVertexAttrib4NubARB(index, x, y, z, w, function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglVertexAttrib4NubARB(int paramInt, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, long paramLong);
/* 170:    */   
/* 171:    */   public static void glVertexAttribPointerARB(int index, int size, boolean normalized, int stride, DoubleBuffer buffer)
/* 172:    */   {
/* 173:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:175 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 175:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:177 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 177:178 */     BufferChecks.checkDirect(buffer);
/* 178:179 */     if (LWJGLUtil.CHECKS) {
/* 179:179 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 180:    */     }
/* 181:180 */     nglVertexAttribPointerARB(index, size, 5130, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static void glVertexAttribPointerARB(int index, int size, boolean normalized, int stride, FloatBuffer buffer)
/* 185:    */   {
/* 186:183 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 187:184 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 188:185 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 189:186 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 190:187 */     BufferChecks.checkDirect(buffer);
/* 191:188 */     if (LWJGLUtil.CHECKS) {
/* 192:188 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 193:    */     }
/* 194:189 */     nglVertexAttribPointerARB(index, size, 5126, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, ByteBuffer buffer)
/* 198:    */   {
/* 199:192 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:193 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 201:194 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:195 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 203:196 */     BufferChecks.checkDirect(buffer);
/* 204:197 */     if (LWJGLUtil.CHECKS) {
/* 205:197 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 206:    */     }
/* 207:198 */     nglVertexAttribPointerARB(index, size, unsigned ? 5121 : 5120, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, IntBuffer buffer)
/* 211:    */   {
/* 212:201 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 213:202 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 214:203 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 215:204 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 216:205 */     BufferChecks.checkDirect(buffer);
/* 217:206 */     if (LWJGLUtil.CHECKS) {
/* 218:206 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 219:    */     }
/* 220:207 */     nglVertexAttribPointerARB(index, size, unsigned ? 5125 : 5124, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 221:    */   }
/* 222:    */   
/* 223:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, ShortBuffer buffer)
/* 224:    */   {
/* 225:210 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:211 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 227:212 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:213 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 229:214 */     BufferChecks.checkDirect(buffer);
/* 230:215 */     if (LWJGLUtil.CHECKS) {
/* 231:215 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 232:    */     }
/* 233:216 */     nglVertexAttribPointerARB(index, size, unsigned ? 5123 : 5122, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 234:    */   }
/* 235:    */   
/* 236:    */   static native void nglVertexAttribPointerARB(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong1, long paramLong2);
/* 237:    */   
/* 238:    */   public static void glVertexAttribPointerARB(int index, int size, int type, boolean normalized, int stride, long buffer_buffer_offset)
/* 239:    */   {
/* 240:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 241:221 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 242:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 243:223 */     GLChecks.ensureArrayVBOenabled(caps);
/* 244:224 */     nglVertexAttribPointerARBBO(index, size, type, normalized, stride, buffer_buffer_offset, function_pointer);
/* 245:    */   }
/* 246:    */   
/* 247:    */   static native void nglVertexAttribPointerARBBO(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong1, long paramLong2);
/* 248:    */   
/* 249:    */   public static void glVertexAttribPointerARB(int index, int size, int type, boolean normalized, int stride, ByteBuffer buffer)
/* 250:    */   {
/* 251:230 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 252:231 */     long function_pointer = caps.glVertexAttribPointerARB;
/* 253:232 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 254:233 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 255:234 */     BufferChecks.checkDirect(buffer);
/* 256:235 */     if (LWJGLUtil.CHECKS) {
/* 257:235 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 258:    */     }
/* 259:236 */     nglVertexAttribPointerARB(index, size, type, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public static void glEnableVertexAttribArrayARB(int index)
/* 263:    */   {
/* 264:240 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 265:241 */     long function_pointer = caps.glEnableVertexAttribArrayARB;
/* 266:242 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 267:243 */     nglEnableVertexAttribArrayARB(index, function_pointer);
/* 268:    */   }
/* 269:    */   
/* 270:    */   static native void nglEnableVertexAttribArrayARB(int paramInt, long paramLong);
/* 271:    */   
/* 272:    */   public static void glDisableVertexAttribArrayARB(int index)
/* 273:    */   {
/* 274:248 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 275:249 */     long function_pointer = caps.glDisableVertexAttribArrayARB;
/* 276:250 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 277:251 */     nglDisableVertexAttribArrayARB(index, function_pointer);
/* 278:    */   }
/* 279:    */   
/* 280:    */   static native void nglDisableVertexAttribArrayARB(int paramInt, long paramLong);
/* 281:    */   
/* 282:    */   public static void glBindAttribLocationARB(int programObj, int index, ByteBuffer name)
/* 283:    */   {
/* 284:256 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 285:257 */     long function_pointer = caps.glBindAttribLocationARB;
/* 286:258 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 287:259 */     BufferChecks.checkDirect(name);
/* 288:260 */     BufferChecks.checkNullTerminated(name);
/* 289:261 */     nglBindAttribLocationARB(programObj, index, MemoryUtil.getAddress(name), function_pointer);
/* 290:    */   }
/* 291:    */   
/* 292:    */   static native void nglBindAttribLocationARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 293:    */   
/* 294:    */   public static void glBindAttribLocationARB(int programObj, int index, CharSequence name)
/* 295:    */   {
/* 296:267 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 297:268 */     long function_pointer = caps.glBindAttribLocationARB;
/* 298:269 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 299:270 */     nglBindAttribLocationARB(programObj, index, APIUtil.getBufferNT(caps, name), function_pointer);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public static void glGetActiveAttribARB(int programObj, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/* 303:    */   {
/* 304:274 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 305:275 */     long function_pointer = caps.glGetActiveAttribARB;
/* 306:276 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 307:277 */     if (length != null) {
/* 308:278 */       BufferChecks.checkBuffer(length, 1);
/* 309:    */     }
/* 310:279 */     BufferChecks.checkBuffer(size, 1);
/* 311:280 */     BufferChecks.checkBuffer(type, 1);
/* 312:281 */     BufferChecks.checkDirect(name);
/* 313:282 */     nglGetActiveAttribARB(programObj, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 314:    */   }
/* 315:    */   
/* 316:    */   static native void nglGetActiveAttribARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 317:    */   
/* 318:    */   public static String glGetActiveAttribARB(int programObj, int index, int maxLength, IntBuffer sizeType)
/* 319:    */   {
/* 320:292 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 321:293 */     long function_pointer = caps.glGetActiveAttribARB;
/* 322:294 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 323:295 */     BufferChecks.checkBuffer(sizeType, 2);
/* 324:296 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 325:297 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 326:298 */     nglGetActiveAttribARB(programObj, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(sizeType), MemoryUtil.getAddress(sizeType, sizeType.position() + 1), MemoryUtil.getAddress(name), function_pointer);
/* 327:299 */     name.limit(name_length.get(0));
/* 328:300 */     return APIUtil.getString(caps, name);
/* 329:    */   }
/* 330:    */   
/* 331:    */   public static String glGetActiveAttribARB(int programObj, int index, int maxLength)
/* 332:    */   {
/* 333:309 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 334:310 */     long function_pointer = caps.glGetActiveAttribARB;
/* 335:311 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 336:312 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 337:313 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 338:314 */     nglGetActiveAttribARB(programObj, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress0(APIUtil.getBufferInt(caps)), MemoryUtil.getAddress(APIUtil.getBufferInt(caps), 1), MemoryUtil.getAddress(name), function_pointer);
/* 339:315 */     name.limit(name_length.get(0));
/* 340:316 */     return APIUtil.getString(caps, name);
/* 341:    */   }
/* 342:    */   
/* 343:    */   public static int glGetActiveAttribSizeARB(int programObj, int index)
/* 344:    */   {
/* 345:325 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 346:326 */     long function_pointer = caps.glGetActiveAttribARB;
/* 347:327 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 348:328 */     IntBuffer size = APIUtil.getBufferInt(caps);
/* 349:329 */     nglGetActiveAttribARB(programObj, index, 0, 0L, MemoryUtil.getAddress(size), MemoryUtil.getAddress(size, 1), APIUtil.getBufferByte0(caps), function_pointer);
/* 350:330 */     return size.get(0);
/* 351:    */   }
/* 352:    */   
/* 353:    */   public static int glGetActiveAttribTypeARB(int programObj, int index)
/* 354:    */   {
/* 355:339 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 356:340 */     long function_pointer = caps.glGetActiveAttribARB;
/* 357:341 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 358:342 */     IntBuffer type = APIUtil.getBufferInt(caps);
/* 359:343 */     nglGetActiveAttribARB(programObj, index, 0, 0L, MemoryUtil.getAddress(type, 1), MemoryUtil.getAddress(type), APIUtil.getBufferByte0(caps), function_pointer);
/* 360:344 */     return type.get(0);
/* 361:    */   }
/* 362:    */   
/* 363:    */   public static int glGetAttribLocationARB(int programObj, ByteBuffer name)
/* 364:    */   {
/* 365:348 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 366:349 */     long function_pointer = caps.glGetAttribLocationARB;
/* 367:350 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 368:351 */     BufferChecks.checkDirect(name);
/* 369:352 */     BufferChecks.checkNullTerminated(name);
/* 370:353 */     int __result = nglGetAttribLocationARB(programObj, MemoryUtil.getAddress(name), function_pointer);
/* 371:354 */     return __result;
/* 372:    */   }
/* 373:    */   
/* 374:    */   static native int nglGetAttribLocationARB(int paramInt, long paramLong1, long paramLong2);
/* 375:    */   
/* 376:    */   public static int glGetAttribLocationARB(int programObj, CharSequence name)
/* 377:    */   {
/* 378:360 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 379:361 */     long function_pointer = caps.glGetAttribLocationARB;
/* 380:362 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 381:363 */     int __result = nglGetAttribLocationARB(programObj, APIUtil.getBufferNT(caps, name), function_pointer);
/* 382:364 */     return __result;
/* 383:    */   }
/* 384:    */   
/* 385:    */   public static void glGetVertexAttribARB(int index, int pname, FloatBuffer params)
/* 386:    */   {
/* 387:368 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 388:369 */     long function_pointer = caps.glGetVertexAttribfvARB;
/* 389:370 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 390:371 */     BufferChecks.checkBuffer(params, 4);
/* 391:372 */     nglGetVertexAttribfvARB(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 392:    */   }
/* 393:    */   
/* 394:    */   static native void nglGetVertexAttribfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 395:    */   
/* 396:    */   public static void glGetVertexAttribARB(int index, int pname, DoubleBuffer params)
/* 397:    */   {
/* 398:377 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 399:378 */     long function_pointer = caps.glGetVertexAttribdvARB;
/* 400:379 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 401:380 */     BufferChecks.checkBuffer(params, 4);
/* 402:381 */     nglGetVertexAttribdvARB(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 403:    */   }
/* 404:    */   
/* 405:    */   static native void nglGetVertexAttribdvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 406:    */   
/* 407:    */   public static void glGetVertexAttribARB(int index, int pname, IntBuffer params)
/* 408:    */   {
/* 409:386 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 410:387 */     long function_pointer = caps.glGetVertexAttribivARB;
/* 411:388 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 412:389 */     BufferChecks.checkBuffer(params, 4);
/* 413:390 */     nglGetVertexAttribivARB(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 414:    */   }
/* 415:    */   
/* 416:    */   static native void nglGetVertexAttribivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 417:    */   
/* 418:    */   public static ByteBuffer glGetVertexAttribPointerARB(int index, int pname, long result_size)
/* 419:    */   {
/* 420:395 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 421:396 */     long function_pointer = caps.glGetVertexAttribPointervARB;
/* 422:397 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 423:398 */     ByteBuffer __result = nglGetVertexAttribPointervARB(index, pname, result_size, function_pointer);
/* 424:399 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 425:    */   }
/* 426:    */   
/* 427:    */   static native ByteBuffer nglGetVertexAttribPointervARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 428:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexShader
 * JD-Core Version:    0.7.0.1
 */