/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Cursor;
/*   5:    */ import java.awt.Dimension;
/*   6:    */ import java.awt.GraphicsConfiguration;
/*   7:    */ import java.awt.GraphicsDevice;
/*   8:    */ import java.awt.IllegalComponentStateException;
/*   9:    */ import java.awt.MouseInfo;
/*  10:    */ import java.awt.Point;
/*  11:    */ import java.awt.PointerInfo;
/*  12:    */ import java.awt.Robot;
/*  13:    */ import java.awt.Toolkit;
/*  14:    */ import java.awt.image.BufferedImage;
/*  15:    */ import java.nio.IntBuffer;
/*  16:    */ import java.security.AccessController;
/*  17:    */ import java.security.PrivilegedActionException;
/*  18:    */ import java.security.PrivilegedExceptionAction;
/*  19:    */ import org.lwjgl.LWJGLException;
/*  20:    */ import org.lwjgl.LWJGLUtil;
/*  21:    */ 
/*  22:    */ final class AWTUtil
/*  23:    */ {
/*  24:    */   public static boolean hasWheel()
/*  25:    */   {
/*  26: 60 */     return true;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static int getButtonCount()
/*  30:    */   {
/*  31: 64 */     return 3;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static int getNativeCursorCapabilities()
/*  35:    */   {
/*  36: 68 */     if ((LWJGLUtil.getPlatform() != 2) || (LWJGLUtil.isMacOSXEqualsOrBetterThan(10, 4)))
/*  37:    */     {
/*  38: 69 */       int cursor_colors = Toolkit.getDefaultToolkit().getMaximumCursorColors();
/*  39: 70 */       boolean supported = (cursor_colors >= 32767) && (getMaxCursorSize() > 0);
/*  40: 71 */       int caps = supported ? 3 : 4;
/*  41: 72 */       return caps;
/*  42:    */     }
/*  43: 84 */     return 0;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static Robot createRobot(Component component)
/*  47:    */   {
/*  48:    */     try
/*  49:    */     {
/*  50: 90 */       (Robot)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  51:    */       {
/*  52:    */         public Robot run()
/*  53:    */           throws Exception
/*  54:    */         {
/*  55: 92 */           return new Robot(this.val$component.getGraphicsConfiguration().getDevice());
/*  56:    */         }
/*  57:    */       });
/*  58:    */     }
/*  59:    */     catch (PrivilegedActionException e)
/*  60:    */     {
/*  61: 96 */       LWJGLUtil.log("Got exception while creating robot: " + e.getCause());
/*  62:    */     }
/*  63: 97 */     return null;
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static int transformY(Component component, int y)
/*  67:    */   {
/*  68:102 */     return component.getHeight() - 1 - y;
/*  69:    */   }
/*  70:    */   
/*  71:    */   private static Point getPointerLocation(Component component)
/*  72:    */   {
/*  73:    */     try
/*  74:    */     {
/*  75:112 */       GraphicsConfiguration config = component.getGraphicsConfiguration();
/*  76:113 */       if (config != null)
/*  77:    */       {
/*  78:114 */         PointerInfo pointer_info = (PointerInfo)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  79:    */         {
/*  80:    */           public PointerInfo run()
/*  81:    */             throws Exception
/*  82:    */           {
/*  83:116 */             return MouseInfo.getPointerInfo();
/*  84:    */           }
/*  85:118 */         });
/*  86:119 */         GraphicsDevice device = pointer_info.getDevice();
/*  87:120 */         if (device == config.getDevice()) {
/*  88:121 */           return pointer_info.getLocation();
/*  89:    */         }
/*  90:123 */         return null;
/*  91:    */       }
/*  92:    */     }
/*  93:    */     catch (Exception e)
/*  94:    */     {
/*  95:126 */       LWJGLUtil.log("Failed to query pointer location: " + e.getCause());
/*  96:    */     }
/*  97:128 */     return null;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static Point getCursorPosition(Component component)
/* 101:    */   {
/* 102:    */     try
/* 103:    */     {
/* 104:137 */       Point pointer_location = getPointerLocation(component);
/* 105:138 */       if (pointer_location != null)
/* 106:    */       {
/* 107:139 */         Point location = component.getLocationOnScreen();
/* 108:140 */         pointer_location.translate(-location.x, -location.y);
/* 109:141 */         pointer_location.move(pointer_location.x, transformY(component, pointer_location.y));
/* 110:142 */         return pointer_location;
/* 111:    */       }
/* 112:    */     }
/* 113:    */     catch (IllegalComponentStateException e)
/* 114:    */     {
/* 115:145 */       LWJGLUtil.log("Failed to set cursor position: " + e);
/* 116:    */     }
/* 117:    */     catch (NoClassDefFoundError e)
/* 118:    */     {
/* 119:147 */       LWJGLUtil.log("Failed to query cursor position: " + e);
/* 120:    */     }
/* 121:149 */     return null;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static void setCursorPosition(Component component, Robot robot, int x, int y)
/* 125:    */   {
/* 126:153 */     if (robot != null) {
/* 127:    */       try
/* 128:    */       {
/* 129:155 */         Point location = component.getLocationOnScreen();
/* 130:156 */         int transformed_x = location.x + x;
/* 131:157 */         int transformed_y = location.y + transformY(component, y);
/* 132:158 */         robot.mouseMove(transformed_x, transformed_y);
/* 133:    */       }
/* 134:    */       catch (IllegalComponentStateException e)
/* 135:    */       {
/* 136:160 */         LWJGLUtil.log("Failed to set cursor position: " + e);
/* 137:    */       }
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static int getMinCursorSize()
/* 142:    */   {
/* 143:166 */     Dimension min_size = Toolkit.getDefaultToolkit().getBestCursorSize(0, 0);
/* 144:167 */     return Math.max(min_size.width, min_size.height);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static int getMaxCursorSize()
/* 148:    */   {
/* 149:171 */     Dimension max_size = Toolkit.getDefaultToolkit().getBestCursorSize(10000, 10000);
/* 150:172 */     return Math.min(max_size.width, max_size.height);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public static Cursor createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/* 154:    */     throws LWJGLException
/* 155:    */   {
/* 156:177 */     BufferedImage cursor_image = new BufferedImage(width, height, 2);
/* 157:178 */     int[] pixels = new int[images.remaining()];
/* 158:179 */     int old_position = images.position();
/* 159:180 */     images.get(pixels);
/* 160:181 */     images.position(old_position);
/* 161:182 */     cursor_image.setRGB(0, 0, width, height, pixels, 0, width);
/* 162:183 */     return Toolkit.getDefaultToolkit().createCustomCursor(cursor_image, new Point(xHotspot, yHotspot), "LWJGL Custom cursor");
/* 163:    */   }
/* 164:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AWTUtil
 * JD-Core Version:    0.7.0.1
 */