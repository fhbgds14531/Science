/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBWindowPos
/*  6:   */ {
/*  7:   */   public static void glWindowPos2fARB(float x, float y)
/*  8:   */   {
/*  9:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 10:14 */     long function_pointer = caps.glWindowPos2fARB;
/* 11:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 12:16 */     nglWindowPos2fARB(x, y, function_pointer);
/* 13:   */   }
/* 14:   */   
/* 15:   */   static native void nglWindowPos2fARB(float paramFloat1, float paramFloat2, long paramLong);
/* 16:   */   
/* 17:   */   public static void glWindowPos2dARB(double x, double y)
/* 18:   */   {
/* 19:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:22 */     long function_pointer = caps.glWindowPos2dARB;
/* 21:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:24 */     nglWindowPos2dARB(x, y, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglWindowPos2dARB(double paramDouble1, double paramDouble2, long paramLong);
/* 26:   */   
/* 27:   */   public static void glWindowPos2iARB(int x, int y)
/* 28:   */   {
/* 29:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:30 */     long function_pointer = caps.glWindowPos2iARB;
/* 31:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:32 */     nglWindowPos2iARB(x, y, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglWindowPos2iARB(int paramInt1, int paramInt2, long paramLong);
/* 36:   */   
/* 37:   */   public static void glWindowPos2sARB(short x, short y)
/* 38:   */   {
/* 39:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 40:38 */     long function_pointer = caps.glWindowPos2sARB;
/* 41:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 42:40 */     nglWindowPos2sARB(x, y, function_pointer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   static native void nglWindowPos2sARB(short paramShort1, short paramShort2, long paramLong);
/* 46:   */   
/* 47:   */   public static void glWindowPos3fARB(float x, float y, float z)
/* 48:   */   {
/* 49:45 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 50:46 */     long function_pointer = caps.glWindowPos3fARB;
/* 51:47 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 52:48 */     nglWindowPos3fARB(x, y, z, function_pointer);
/* 53:   */   }
/* 54:   */   
/* 55:   */   static native void nglWindowPos3fARB(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 56:   */   
/* 57:   */   public static void glWindowPos3dARB(double x, double y, double z)
/* 58:   */   {
/* 59:53 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 60:54 */     long function_pointer = caps.glWindowPos3dARB;
/* 61:55 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 62:56 */     nglWindowPos3dARB(x, y, z, function_pointer);
/* 63:   */   }
/* 64:   */   
/* 65:   */   static native void nglWindowPos3dARB(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 66:   */   
/* 67:   */   public static void glWindowPos3iARB(int x, int y, int z)
/* 68:   */   {
/* 69:61 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 70:62 */     long function_pointer = caps.glWindowPos3iARB;
/* 71:63 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 72:64 */     nglWindowPos3iARB(x, y, z, function_pointer);
/* 73:   */   }
/* 74:   */   
/* 75:   */   static native void nglWindowPos3iARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 76:   */   
/* 77:   */   public static void glWindowPos3sARB(short x, short y, short z)
/* 78:   */   {
/* 79:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 80:70 */     long function_pointer = caps.glWindowPos3sARB;
/* 81:71 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 82:72 */     nglWindowPos3sARB(x, y, z, function_pointer);
/* 83:   */   }
/* 84:   */   
/* 85:   */   static native void nglWindowPos3sARB(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 86:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBWindowPos
 * JD-Core Version:    0.7.0.1
 */