/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class GREMEDYStringMarker
/*  8:   */ {
/*  9:   */   public static void glStringMarkerGREMEDY(ByteBuffer string)
/* 10:   */   {
/* 11:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 12:14 */     long function_pointer = caps.glStringMarkerGREMEDY;
/* 13:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 14:16 */     BufferChecks.checkDirect(string);
/* 15:17 */     nglStringMarkerGREMEDY(string.remaining(), MemoryUtil.getAddress(string), function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglStringMarkerGREMEDY(int paramInt, long paramLong1, long paramLong2);
/* 19:   */   
/* 20:   */   public static void glStringMarkerGREMEDY(CharSequence string)
/* 21:   */   {
/* 22:23 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:24 */     long function_pointer = caps.glStringMarkerGREMEDY;
/* 24:25 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:26 */     nglStringMarkerGREMEDY(string.length(), APIUtil.getBuffer(caps, string), function_pointer);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GREMEDYStringMarker
 * JD-Core Version:    0.7.0.1
 */