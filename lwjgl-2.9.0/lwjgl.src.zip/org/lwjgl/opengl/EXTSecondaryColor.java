/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.DoubleBuffer;
/*  5:   */ import java.nio.FloatBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.LWJGLUtil;
/*  8:   */ import org.lwjgl.MemoryUtil;
/*  9:   */ 
/* 10:   */ public final class EXTSecondaryColor
/* 11:   */ {
/* 12:   */   public static final int GL_COLOR_SUM_EXT = 33880;
/* 13:   */   public static final int GL_CURRENT_SECONDARY_COLOR_EXT = 33881;
/* 14:   */   public static final int GL_SECONDARY_COLOR_ARRAY_SIZE_EXT = 33882;
/* 15:   */   public static final int GL_SECONDARY_COLOR_ARRAY_TYPE_EXT = 33883;
/* 16:   */   public static final int GL_SECONDARY_COLOR_ARRAY_STRIDE_EXT = 33884;
/* 17:   */   public static final int GL_SECONDARY_COLOR_ARRAY_POINTER_EXT = 33885;
/* 18:   */   public static final int GL_SECONDARY_COLOR_ARRAY_EXT = 33886;
/* 19:   */   
/* 20:   */   public static void glSecondaryColor3bEXT(byte red, byte green, byte blue)
/* 21:   */   {
/* 22:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:22 */     long function_pointer = caps.glSecondaryColor3bEXT;
/* 24:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:24 */     nglSecondaryColor3bEXT(red, green, blue, function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglSecondaryColor3bEXT(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 29:   */   
/* 30:   */   public static void glSecondaryColor3fEXT(float red, float green, float blue)
/* 31:   */   {
/* 32:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:30 */     long function_pointer = caps.glSecondaryColor3fEXT;
/* 34:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:32 */     nglSecondaryColor3fEXT(red, green, blue, function_pointer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   static native void nglSecondaryColor3fEXT(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 39:   */   
/* 40:   */   public static void glSecondaryColor3dEXT(double red, double green, double blue)
/* 41:   */   {
/* 42:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:38 */     long function_pointer = caps.glSecondaryColor3dEXT;
/* 44:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 45:40 */     nglSecondaryColor3dEXT(red, green, blue, function_pointer);
/* 46:   */   }
/* 47:   */   
/* 48:   */   static native void nglSecondaryColor3dEXT(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 49:   */   
/* 50:   */   public static void glSecondaryColor3ubEXT(byte red, byte green, byte blue)
/* 51:   */   {
/* 52:45 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 53:46 */     long function_pointer = caps.glSecondaryColor3ubEXT;
/* 54:47 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 55:48 */     nglSecondaryColor3ubEXT(red, green, blue, function_pointer);
/* 56:   */   }
/* 57:   */   
/* 58:   */   static native void nglSecondaryColor3ubEXT(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 59:   */   
/* 60:   */   public static void glSecondaryColorPointerEXT(int size, int stride, DoubleBuffer pPointer)
/* 61:   */   {
/* 62:53 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 63:54 */     long function_pointer = caps.glSecondaryColorPointerEXT;
/* 64:55 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 65:56 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 66:57 */     BufferChecks.checkDirect(pPointer);
/* 67:58 */     if (LWJGLUtil.CHECKS) {
/* 68:58 */       StateTracker.getReferences(caps).EXT_secondary_color_glSecondaryColorPointerEXT_pPointer = pPointer;
/* 69:   */     }
/* 70:59 */     nglSecondaryColorPointerEXT(size, 5130, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 71:   */   }
/* 72:   */   
/* 73:   */   public static void glSecondaryColorPointerEXT(int size, int stride, FloatBuffer pPointer)
/* 74:   */   {
/* 75:62 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 76:63 */     long function_pointer = caps.glSecondaryColorPointerEXT;
/* 77:64 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 78:65 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 79:66 */     BufferChecks.checkDirect(pPointer);
/* 80:67 */     if (LWJGLUtil.CHECKS) {
/* 81:67 */       StateTracker.getReferences(caps).EXT_secondary_color_glSecondaryColorPointerEXT_pPointer = pPointer;
/* 82:   */     }
/* 83:68 */     nglSecondaryColorPointerEXT(size, 5126, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 84:   */   }
/* 85:   */   
/* 86:   */   public static void glSecondaryColorPointerEXT(int size, boolean unsigned, int stride, ByteBuffer pPointer)
/* 87:   */   {
/* 88:71 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 89:72 */     long function_pointer = caps.glSecondaryColorPointerEXT;
/* 90:73 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 91:74 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 92:75 */     BufferChecks.checkDirect(pPointer);
/* 93:76 */     if (LWJGLUtil.CHECKS) {
/* 94:76 */       StateTracker.getReferences(caps).EXT_secondary_color_glSecondaryColorPointerEXT_pPointer = pPointer;
/* 95:   */     }
/* 96:77 */     nglSecondaryColorPointerEXT(size, unsigned ? 5121 : 5120, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 97:   */   }
/* 98:   */   
/* 99:   */   static native void nglSecondaryColorPointerEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* :0:   */   
/* :1:   */   public static void glSecondaryColorPointerEXT(int size, int type, int stride, long pPointer_buffer_offset)
/* :2:   */   {
/* :3:81 */     ContextCapabilities caps = GLContext.getCapabilities();
/* :4:82 */     long function_pointer = caps.glSecondaryColorPointerEXT;
/* :5:83 */     BufferChecks.checkFunctionAddress(function_pointer);
/* :6:84 */     GLChecks.ensureArrayVBOenabled(caps);
/* :7:85 */     nglSecondaryColorPointerEXTBO(size, type, stride, pPointer_buffer_offset, function_pointer);
/* :8:   */   }
/* :9:   */   
/* ;0:   */   static native void nglSecondaryColorPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* ;1:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTSecondaryColor
 * JD-Core Version:    0.7.0.1
 */