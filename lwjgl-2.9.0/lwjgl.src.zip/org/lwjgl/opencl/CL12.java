/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import java.nio.LongBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ import org.lwjgl.PointerBuffer;
/*  11:    */ 
/*  12:    */ public final class CL12
/*  13:    */ {
/*  14:    */   public static final int CL_COMPILE_PROGRAM_FAILURE = -15;
/*  15:    */   public static final int CL_LINKER_NOT_AVAILABLE = -16;
/*  16:    */   public static final int CL_LINK_PROGRAM_FAILURE = -17;
/*  17:    */   public static final int CL_DEVICE_PARTITION_FAILED = -18;
/*  18:    */   public static final int CL_KERNEL_ARG_INFO_NOT_AVAILABLE = -19;
/*  19:    */   public static final int CL_INVALID_IMAGE_DESCRIPTOR = -65;
/*  20:    */   public static final int CL_INVALID_COMPILER_OPTIONS = -66;
/*  21:    */   public static final int CL_INVALID_LINKER_OPTIONS = -67;
/*  22:    */   public static final int CL_INVALID_DEVICE_PARTITION_COUNT = -68;
/*  23:    */   public static final int CL_VERSION_1_2 = 1;
/*  24:    */   public static final int CL_BLOCKING = 1;
/*  25:    */   public static final int CL_NON_BLOCKING = 0;
/*  26:    */   public static final int CL_DEVICE_TYPE_CUSTOM = 16;
/*  27:    */   public static final int CL_DEVICE_DOUBLE_FP_CONFIG = 4146;
/*  28:    */   public static final int CL_DEVICE_LINKER_AVAILABLE = 4158;
/*  29:    */   public static final int CL_DEVICE_BUILT_IN_KERNELS = 4159;
/*  30:    */   public static final int CL_DEVICE_IMAGE_MAX_BUFFER_SIZE = 4160;
/*  31:    */   public static final int CL_DEVICE_IMAGE_MAX_ARRAY_SIZE = 4161;
/*  32:    */   public static final int CL_DEVICE_PARENT_DEVICE = 4162;
/*  33:    */   public static final int CL_DEVICE_PARTITION_MAX_SUB_DEVICES = 4163;
/*  34:    */   public static final int CL_DEVICE_PARTITION_PROPERTIES = 4164;
/*  35:    */   public static final int CL_DEVICE_PARTITION_AFFINITY_DOMAIN = 4165;
/*  36:    */   public static final int CL_DEVICE_PARTITION_TYPE = 4166;
/*  37:    */   public static final int CL_DEVICE_REFERENCE_COUNT = 4167;
/*  38:    */   public static final int CL_DEVICE_PREFERRED_INTEROP_USER_SYNC = 4168;
/*  39:    */   public static final int CL_DEVICE_PRINTF_BUFFER_SIZE = 4169;
/*  40:    */   public static final int CL_FP_CORRECTLY_ROUNDED_DIVIDE_SQRT = 128;
/*  41:    */   public static final int CL_CONTEXT_INTEROP_USER_SYNC = 4229;
/*  42:    */   public static final int CL_DEVICE_PARTITION_EQUALLY = 4230;
/*  43:    */   public static final int CL_DEVICE_PARTITION_BY_COUNTS = 4231;
/*  44:    */   public static final int CL_DEVICE_PARTITION_BY_COUNTS_LIST_END = 0;
/*  45:    */   public static final int CL_DEVICE_PARTITION_BY_AFFINITY_DOMAIN = 4232;
/*  46:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_NUMA = 1;
/*  47:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_L4_CACHE = 2;
/*  48:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_L3_CACHE = 4;
/*  49:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_L2_CACHE = 8;
/*  50:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_L1_CACHE = 16;
/*  51:    */   public static final int CL_DEVICE_AFFINITY_DOMAIN_NEXT_PARTITIONABLE = 32;
/*  52:    */   public static final int CL_MEM_HOST_WRITE_ONLY = 128;
/*  53:    */   public static final int CL_MEM_HOST_READ_ONLY = 256;
/*  54:    */   public static final int CL_MEM_HOST_NO_ACCESS = 512;
/*  55:    */   public static final int CL_MIGRATE_MEM_OBJECT_HOST = 1;
/*  56:    */   public static final int CL_MIGRATE_MEM_OBJECT_CONTENT_UNDEFINED = 2;
/*  57:    */   public static final int CL_MEM_OBJECT_IMAGE2D_ARRAY = 4339;
/*  58:    */   public static final int CL_MEM_OBJECT_IMAGE1D = 4340;
/*  59:    */   public static final int CL_MEM_OBJECT_IMAGE1D_ARRAY = 4341;
/*  60:    */   public static final int CL_MEM_OBJECT_IMAGE1D_BUFFER = 4342;
/*  61:    */   public static final int CL_IMAGE_ARRAY_SIZE = 4375;
/*  62:    */   public static final int CL_IMAGE_BUFFER = 4376;
/*  63:    */   public static final int CL_IMAGE_NUM_MIP_LEVELS = 4377;
/*  64:    */   public static final int CL_IMAGE_NUM_SAMPLES = 4378;
/*  65:    */   public static final int CL_MAP_WRITE_INVALIDATE_REGION = 4;
/*  66:    */   public static final int CL_PROGRAM_NUM_KERNELS = 4455;
/*  67:    */   public static final int CL_PROGRAM_KERNEL_NAMES = 4456;
/*  68:    */   public static final int CL_PROGRAM_BINARY_TYPE = 4484;
/*  69:    */   public static final int CL_PROGRAM_BINARY_TYPE_NONE = 0;
/*  70:    */   public static final int CL_PROGRAM_BINARY_TYPE_COMPILED_OBJECT = 1;
/*  71:    */   public static final int CL_PROGRAM_BINARY_TYPE_LIBRARY = 2;
/*  72:    */   public static final int CL_PROGRAM_BINARY_TYPE_EXECUTABLE = 4;
/*  73:    */   public static final int CL_KERNEL_ATTRIBUTES = 4501;
/*  74:    */   public static final int CL_KERNEL_ARG_ADDRESS_QUALIFIER = 4502;
/*  75:    */   public static final int CL_KERNEL_ARG_ACCESS_QUALIFIER = 4503;
/*  76:    */   public static final int CL_KERNEL_ARG_TYPE_NAME = 4504;
/*  77:    */   public static final int CL_KERNEL_ARG_TYPE_QUALIFIER = 4505;
/*  78:    */   public static final int CL_KERNEL_ARG_NAME = 4506;
/*  79:    */   public static final int CL_KERNEL_ARG_ADDRESS_GLOBAL = 4506;
/*  80:    */   public static final int CL_KERNEL_ARG_ADDRESS_LOCAL = 4507;
/*  81:    */   public static final int CL_KERNEL_ARG_ADDRESS_CONSTANT = 4508;
/*  82:    */   public static final int CL_KERNEL_ARG_ADDRESS_PRIVATE = 4509;
/*  83:    */   public static final int CL_KERNEL_ARG_ACCESS_READ_ONLY = 4512;
/*  84:    */   public static final int CL_KERNEL_ARG_ACCESS_WRITE_ONLY = 4513;
/*  85:    */   public static final int CL_KERNEL_ARG_ACCESS_READ_WRITE = 4514;
/*  86:    */   public static final int CL_KERNEL_ARG_ACCESS_NONE = 4515;
/*  87:    */   public static final int CL_KERNEL_ARG_TYPE_NONE = 0;
/*  88:    */   public static final int CL_KERNEL_ARG_TYPE_CONST = 1;
/*  89:    */   public static final int CL_KERNEL_ARG_TYPE_RESTRICT = 2;
/*  90:    */   public static final int CL_KERNEL_ARG_TYPE_VOLATILE = 4;
/*  91:    */   public static final int CL_KERNEL_GLOBAL_WORK_SIZE = 4533;
/*  92:    */   public static final int CL_COMMAND_BARRIER = 4613;
/*  93:    */   public static final int CL_COMMAND_MIGRATE_MEM_OBJECTS = 4614;
/*  94:    */   public static final int CL_COMMAND_FILL_BUFFER = 4615;
/*  95:    */   public static final int CL_COMMAND_FILL_IMAGE = 4616;
/*  96:    */   
/*  97:    */   public static int clRetainDevice(CLDevice device)
/*  98:    */   {
/*  99:114 */     long function_pointer = CLCapabilities.clRetainDevice;
/* 100:115 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101:116 */     int __result = nclRetainDevice(device.getPointer(), function_pointer);
/* 102:117 */     if (__result == 0) {
/* 103:117 */       device.retain();
/* 104:    */     }
/* 105:118 */     return __result;
/* 106:    */   }
/* 107:    */   
/* 108:    */   static native int nclRetainDevice(long paramLong1, long paramLong2);
/* 109:    */   
/* 110:    */   public static int clReleaseDevice(CLDevice device)
/* 111:    */   {
/* 112:131 */     long function_pointer = CLCapabilities.clReleaseDevice;
/* 113:132 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 114:133 */     APIUtil.releaseObjects(device);
/* 115:134 */     int __result = nclReleaseDevice(device.getPointer(), function_pointer);
/* 116:135 */     if (__result == 0) {
/* 117:135 */       device.release();
/* 118:    */     }
/* 119:136 */     return __result;
/* 120:    */   }
/* 121:    */   
/* 122:    */   static native int nclReleaseDevice(long paramLong1, long paramLong2);
/* 123:    */   
/* 124:    */   public static int clCreateSubDevices(CLDevice in_device, LongBuffer properties, PointerBuffer out_devices, IntBuffer num_devices_ret)
/* 125:    */   {
/* 126:141 */     long function_pointer = CLCapabilities.clCreateSubDevices;
/* 127:142 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:143 */     BufferChecks.checkDirect(properties);
/* 129:144 */     BufferChecks.checkNullTerminated(properties);
/* 130:145 */     if (out_devices != null) {
/* 131:146 */       BufferChecks.checkDirect(out_devices);
/* 132:    */     }
/* 133:147 */     if (num_devices_ret != null) {
/* 134:148 */       BufferChecks.checkBuffer(num_devices_ret, 1);
/* 135:    */     }
/* 136:149 */     int __result = nclCreateSubDevices(in_device.getPointer(), MemoryUtil.getAddress(properties), out_devices == null ? 0 : out_devices.remaining(), MemoryUtil.getAddressSafe(out_devices), MemoryUtil.getAddressSafe(num_devices_ret), function_pointer);
/* 137:150 */     if ((__result == 0) && (out_devices != null)) {
/* 138:150 */       in_device.registerSubCLDevices(out_devices);
/* 139:    */     }
/* 140:151 */     return __result;
/* 141:    */   }
/* 142:    */   
/* 143:    */   static native int nclCreateSubDevices(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/* 144:    */   
/* 145:    */   public static CLMem clCreateImage(CLContext context, long flags, ByteBuffer image_format, ByteBuffer image_desc, ByteBuffer host_ptr, IntBuffer errcode_ret)
/* 146:    */   {
/* 147:156 */     long function_pointer = CLCapabilities.clCreateImage;
/* 148:157 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 149:158 */     BufferChecks.checkBuffer(image_format, 8);
/* 150:159 */     BufferChecks.checkBuffer(image_desc, 7 * PointerBuffer.getPointerSize() + 8 + PointerBuffer.getPointerSize());
/* 151:160 */     if (host_ptr != null) {
/* 152:161 */       BufferChecks.checkDirect(host_ptr);
/* 153:    */     }
/* 154:162 */     if (errcode_ret != null) {
/* 155:163 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 156:    */     }
/* 157:164 */     CLMem __result = new CLMem(nclCreateImage(context.getPointer(), flags, MemoryUtil.getAddress(image_format), MemoryUtil.getAddress(image_desc), MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 158:165 */     return __result;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public static CLMem clCreateImage(CLContext context, long flags, ByteBuffer image_format, ByteBuffer image_desc, FloatBuffer host_ptr, IntBuffer errcode_ret)
/* 162:    */   {
/* 163:168 */     long function_pointer = CLCapabilities.clCreateImage;
/* 164:169 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 165:170 */     BufferChecks.checkBuffer(image_format, 8);
/* 166:171 */     BufferChecks.checkBuffer(image_desc, 7 * PointerBuffer.getPointerSize() + 8 + PointerBuffer.getPointerSize());
/* 167:172 */     if (host_ptr != null) {
/* 168:173 */       BufferChecks.checkDirect(host_ptr);
/* 169:    */     }
/* 170:174 */     if (errcode_ret != null) {
/* 171:175 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 172:    */     }
/* 173:176 */     CLMem __result = new CLMem(nclCreateImage(context.getPointer(), flags, MemoryUtil.getAddress(image_format), MemoryUtil.getAddress(image_desc), MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 174:177 */     return __result;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static CLMem clCreateImage(CLContext context, long flags, ByteBuffer image_format, ByteBuffer image_desc, IntBuffer host_ptr, IntBuffer errcode_ret)
/* 178:    */   {
/* 179:180 */     long function_pointer = CLCapabilities.clCreateImage;
/* 180:181 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 181:182 */     BufferChecks.checkBuffer(image_format, 8);
/* 182:183 */     BufferChecks.checkBuffer(image_desc, 7 * PointerBuffer.getPointerSize() + 8 + PointerBuffer.getPointerSize());
/* 183:184 */     if (host_ptr != null) {
/* 184:185 */       BufferChecks.checkDirect(host_ptr);
/* 185:    */     }
/* 186:186 */     if (errcode_ret != null) {
/* 187:187 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 188:    */     }
/* 189:188 */     CLMem __result = new CLMem(nclCreateImage(context.getPointer(), flags, MemoryUtil.getAddress(image_format), MemoryUtil.getAddress(image_desc), MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 190:189 */     return __result;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static CLMem clCreateImage(CLContext context, long flags, ByteBuffer image_format, ByteBuffer image_desc, ShortBuffer host_ptr, IntBuffer errcode_ret)
/* 194:    */   {
/* 195:192 */     long function_pointer = CLCapabilities.clCreateImage;
/* 196:193 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 197:194 */     BufferChecks.checkBuffer(image_format, 8);
/* 198:195 */     BufferChecks.checkBuffer(image_desc, 7 * PointerBuffer.getPointerSize() + 8 + PointerBuffer.getPointerSize());
/* 199:196 */     if (host_ptr != null) {
/* 200:197 */       BufferChecks.checkDirect(host_ptr);
/* 201:    */     }
/* 202:198 */     if (errcode_ret != null) {
/* 203:199 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 204:    */     }
/* 205:200 */     CLMem __result = new CLMem(nclCreateImage(context.getPointer(), flags, MemoryUtil.getAddress(image_format), MemoryUtil.getAddress(image_desc), MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 206:201 */     return __result;
/* 207:    */   }
/* 208:    */   
/* 209:    */   static native long nclCreateImage(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/* 210:    */   
/* 211:    */   public static CLProgram clCreateProgramWithBuiltInKernels(CLContext context, PointerBuffer device_list, ByteBuffer kernel_names, IntBuffer errcode_ret)
/* 212:    */   {
/* 213:206 */     long function_pointer = CLCapabilities.clCreateProgramWithBuiltInKernels;
/* 214:207 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 215:208 */     BufferChecks.checkBuffer(device_list, 1);
/* 216:209 */     BufferChecks.checkDirect(kernel_names);
/* 217:210 */     if (errcode_ret != null) {
/* 218:211 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 219:    */     }
/* 220:212 */     CLProgram __result = new CLProgram(nclCreateProgramWithBuiltInKernels(context.getPointer(), device_list.remaining(), MemoryUtil.getAddress(device_list), MemoryUtil.getAddress(kernel_names), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 221:213 */     return __result;
/* 222:    */   }
/* 223:    */   
/* 224:    */   static native long nclCreateProgramWithBuiltInKernels(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 225:    */   
/* 226:    */   public static CLProgram clCreateProgramWithBuiltInKernels(CLContext context, PointerBuffer device_list, CharSequence kernel_names, IntBuffer errcode_ret)
/* 227:    */   {
/* 228:219 */     long function_pointer = CLCapabilities.clCreateProgramWithBuiltInKernels;
/* 229:220 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 230:221 */     BufferChecks.checkBuffer(device_list, 1);
/* 231:222 */     if (errcode_ret != null) {
/* 232:223 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 233:    */     }
/* 234:224 */     CLProgram __result = new CLProgram(nclCreateProgramWithBuiltInKernels(context.getPointer(), device_list.remaining(), MemoryUtil.getAddress(device_list), APIUtil.getBuffer(kernel_names), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 235:225 */     return __result;
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static int clCompileProgram(CLProgram program, PointerBuffer device_list, ByteBuffer options, PointerBuffer input_header, ByteBuffer header_include_name, CLCompileProgramCallback pfn_notify)
/* 239:    */   {
/* 240:232 */     long function_pointer = CLCapabilities.clCompileProgram;
/* 241:233 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 242:234 */     if (device_list != null) {
/* 243:235 */       BufferChecks.checkDirect(device_list);
/* 244:    */     }
/* 245:236 */     BufferChecks.checkDirect(options);
/* 246:237 */     BufferChecks.checkNullTerminated(options);
/* 247:238 */     BufferChecks.checkBuffer(input_header, 1);
/* 248:239 */     BufferChecks.checkDirect(header_include_name);
/* 249:240 */     BufferChecks.checkNullTerminated(header_include_name);
/* 250:241 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 251:242 */     if (pfn_notify != null) {
/* 252:242 */       pfn_notify.setContext((CLContext)program.getParent());
/* 253:    */     }
/* 254:243 */     int __result = 0;
/* 255:    */     try
/* 256:    */     {
/* 257:245 */       __result = nclCompileProgram(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), MemoryUtil.getAddress(options), 1, MemoryUtil.getAddress(input_header), MemoryUtil.getAddress(header_include_name), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 258:246 */       return __result;
/* 259:    */     }
/* 260:    */     finally
/* 261:    */     {
/* 262:248 */       CallbackUtil.checkCallback(__result, user_data);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   static native int nclCompileProgram(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
/* 267:    */   
/* 268:    */   public static int clCompileProgramMulti(CLProgram program, PointerBuffer device_list, ByteBuffer options, PointerBuffer input_headers, ByteBuffer header_include_names, CLCompileProgramCallback pfn_notify)
/* 269:    */   {
/* 270:259 */     long function_pointer = CLCapabilities.clCompileProgram;
/* 271:260 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 272:261 */     if (device_list != null) {
/* 273:262 */       BufferChecks.checkDirect(device_list);
/* 274:    */     }
/* 275:263 */     BufferChecks.checkDirect(options);
/* 276:264 */     BufferChecks.checkNullTerminated(options);
/* 277:265 */     BufferChecks.checkBuffer(input_headers, 1);
/* 278:266 */     BufferChecks.checkDirect(header_include_names);
/* 279:267 */     BufferChecks.checkNullTerminated(header_include_names, input_headers.remaining());
/* 280:268 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 281:269 */     if (pfn_notify != null) {
/* 282:269 */       pfn_notify.setContext((CLContext)program.getParent());
/* 283:    */     }
/* 284:270 */     int __result = 0;
/* 285:    */     try
/* 286:    */     {
/* 287:272 */       __result = nclCompileProgramMulti(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), MemoryUtil.getAddress(options), input_headers.remaining(), MemoryUtil.getAddress(input_headers), MemoryUtil.getAddress(header_include_names), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 288:273 */       return __result;
/* 289:    */     }
/* 290:    */     finally
/* 291:    */     {
/* 292:275 */       CallbackUtil.checkCallback(__result, user_data);
/* 293:    */     }
/* 294:    */   }
/* 295:    */   
/* 296:    */   static native int nclCompileProgramMulti(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
/* 297:    */   
/* 298:    */   public static int clCompileProgram(CLProgram program, PointerBuffer device_list, ByteBuffer options, PointerBuffer input_headers, ByteBuffer[] header_include_names, CLCompileProgramCallback pfn_notify)
/* 299:    */   {
/* 300:282 */     long function_pointer = CLCapabilities.clCompileProgram;
/* 301:283 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 302:284 */     if (device_list != null) {
/* 303:285 */       BufferChecks.checkDirect(device_list);
/* 304:    */     }
/* 305:286 */     BufferChecks.checkDirect(options);
/* 306:287 */     BufferChecks.checkNullTerminated(options);
/* 307:288 */     BufferChecks.checkBuffer(input_headers, header_include_names.length);
/* 308:289 */     BufferChecks.checkArray(header_include_names, 1);
/* 309:290 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 310:291 */     if (pfn_notify != null) {
/* 311:291 */       pfn_notify.setContext((CLContext)program.getParent());
/* 312:    */     }
/* 313:292 */     int __result = 0;
/* 314:    */     try
/* 315:    */     {
/* 316:294 */       __result = nclCompileProgram3(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), MemoryUtil.getAddress(options), header_include_names.length, MemoryUtil.getAddress(input_headers), header_include_names, pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 317:295 */       return __result;
/* 318:    */     }
/* 319:    */     finally
/* 320:    */     {
/* 321:297 */       CallbackUtil.checkCallback(__result, user_data);
/* 322:    */     }
/* 323:    */   }
/* 324:    */   
/* 325:    */   static native int nclCompileProgram3(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, ByteBuffer[] paramArrayOfByteBuffer, long paramLong5, long paramLong6, long paramLong7);
/* 326:    */   
/* 327:    */   public static int clCompileProgram(CLProgram program, PointerBuffer device_list, CharSequence options, PointerBuffer input_header, CharSequence header_include_name, CLCompileProgramCallback pfn_notify)
/* 328:    */   {
/* 329:304 */     long function_pointer = CLCapabilities.clCompileProgram;
/* 330:305 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 331:306 */     if (device_list != null) {
/* 332:307 */       BufferChecks.checkDirect(device_list);
/* 333:    */     }
/* 334:308 */     BufferChecks.checkBuffer(input_header, 1);
/* 335:309 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 336:310 */     if (pfn_notify != null) {
/* 337:310 */       pfn_notify.setContext((CLContext)program.getParent());
/* 338:    */     }
/* 339:311 */     int __result = 0;
/* 340:    */     try
/* 341:    */     {
/* 342:313 */       __result = nclCompileProgram(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), APIUtil.getBufferNT(options), 1, MemoryUtil.getAddress(input_header), APIUtil.getBufferNT(header_include_name), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 343:314 */       return __result;
/* 344:    */     }
/* 345:    */     finally
/* 346:    */     {
/* 347:316 */       CallbackUtil.checkCallback(__result, user_data);
/* 348:    */     }
/* 349:    */   }
/* 350:    */   
/* 351:    */   public static int clCompileProgram(CLProgram program, PointerBuffer device_list, CharSequence options, PointerBuffer input_header, CharSequence[] header_include_name, CLCompileProgramCallback pfn_notify)
/* 352:    */   {
/* 353:322 */     long function_pointer = CLCapabilities.clCompileProgram;
/* 354:323 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 355:324 */     if (device_list != null) {
/* 356:325 */       BufferChecks.checkDirect(device_list);
/* 357:    */     }
/* 358:326 */     BufferChecks.checkBuffer(input_header, 1);
/* 359:327 */     BufferChecks.checkArray(header_include_name);
/* 360:328 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 361:329 */     if (pfn_notify != null) {
/* 362:329 */       pfn_notify.setContext((CLContext)program.getParent());
/* 363:    */     }
/* 364:330 */     int __result = 0;
/* 365:    */     try
/* 366:    */     {
/* 367:332 */       __result = nclCompileProgramMulti(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), APIUtil.getBufferNT(options), input_header.remaining(), MemoryUtil.getAddress(input_header), APIUtil.getBufferNT(header_include_name), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 368:333 */       return __result;
/* 369:    */     }
/* 370:    */     finally
/* 371:    */     {
/* 372:335 */       CallbackUtil.checkCallback(__result, user_data);
/* 373:    */     }
/* 374:    */   }
/* 375:    */   
/* 376:    */   public static CLProgram clLinkProgram(CLContext context, PointerBuffer device_list, ByteBuffer options, PointerBuffer input_programs, CLLinkProgramCallback pfn_notify, IntBuffer errcode_ret)
/* 377:    */   {
/* 378:340 */     long function_pointer = CLCapabilities.clLinkProgram;
/* 379:341 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 380:342 */     if (device_list != null) {
/* 381:343 */       BufferChecks.checkDirect(device_list);
/* 382:    */     }
/* 383:344 */     BufferChecks.checkDirect(options);
/* 384:345 */     BufferChecks.checkNullTerminated(options);
/* 385:346 */     BufferChecks.checkDirect(input_programs);
/* 386:347 */     BufferChecks.checkBuffer(errcode_ret, 1);
/* 387:348 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 388:349 */     if (pfn_notify != null) {
/* 389:349 */       pfn_notify.setContext(context);
/* 390:    */     }
/* 391:350 */     CLProgram __result = null;
/* 392:    */     try
/* 393:    */     {
/* 394:352 */       __result = new CLProgram(nclLinkProgram(context.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), MemoryUtil.getAddress(options), input_programs.remaining(), MemoryUtil.getAddress(input_programs), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddress(errcode_ret), function_pointer), context);
/* 395:353 */       return __result;
/* 396:    */     }
/* 397:    */     finally
/* 398:    */     {
/* 399:355 */       CallbackUtil.checkCallback(errcode_ret.get(errcode_ret.position()), user_data);
/* 400:    */     }
/* 401:    */   }
/* 402:    */   
/* 403:    */   static native long nclLinkProgram(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
/* 404:    */   
/* 405:    */   public static CLProgram clLinkProgram(CLContext context, PointerBuffer device_list, CharSequence options, PointerBuffer input_programs, CLLinkProgramCallback pfn_notify, IntBuffer errcode_ret)
/* 406:    */   {
/* 407:362 */     long function_pointer = CLCapabilities.clLinkProgram;
/* 408:363 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 409:364 */     if (device_list != null) {
/* 410:365 */       BufferChecks.checkDirect(device_list);
/* 411:    */     }
/* 412:366 */     BufferChecks.checkDirect(input_programs);
/* 413:367 */     BufferChecks.checkBuffer(errcode_ret, 1);
/* 414:368 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 415:369 */     if (pfn_notify != null) {
/* 416:369 */       pfn_notify.setContext(context);
/* 417:    */     }
/* 418:370 */     CLProgram __result = null;
/* 419:    */     try
/* 420:    */     {
/* 421:372 */       __result = new CLProgram(nclLinkProgram(context.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), APIUtil.getBufferNT(options), input_programs.remaining(), MemoryUtil.getAddress(input_programs), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddress(errcode_ret), function_pointer), context);
/* 422:373 */       return __result;
/* 423:    */     }
/* 424:    */     finally
/* 425:    */     {
/* 426:375 */       CallbackUtil.checkCallback(errcode_ret.get(errcode_ret.position()), user_data);
/* 427:    */     }
/* 428:    */   }
/* 429:    */   
/* 430:    */   public static int clUnloadPlatformCompiler(CLPlatform platform)
/* 431:    */   {
/* 432:380 */     long function_pointer = CLCapabilities.clUnloadPlatformCompiler;
/* 433:381 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 434:382 */     int __result = nclUnloadPlatformCompiler(platform.getPointer(), function_pointer);
/* 435:383 */     return __result;
/* 436:    */   }
/* 437:    */   
/* 438:    */   static native int nclUnloadPlatformCompiler(long paramLong1, long paramLong2);
/* 439:    */   
/* 440:    */   public static int clGetKernelArgInfo(CLKernel kernel, int arg_indx, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 441:    */   {
/* 442:388 */     long function_pointer = CLCapabilities.clGetKernelArgInfo;
/* 443:389 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 444:390 */     if (param_value != null) {
/* 445:391 */       BufferChecks.checkDirect(param_value);
/* 446:    */     }
/* 447:392 */     if (param_value_size_ret != null) {
/* 448:393 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 449:    */     }
/* 450:394 */     int __result = nclGetKernelArgInfo(kernel.getPointer(), arg_indx, param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 451:395 */     return __result;
/* 452:    */   }
/* 453:    */   
/* 454:    */   static native int nclGetKernelArgInfo(long paramLong1, int paramInt1, int paramInt2, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 455:    */   
/* 456:    */   public static int clEnqueueFillBuffer(CLCommandQueue command_queue, CLMem buffer, ByteBuffer pattern, long offset, long size, PointerBuffer event_wait_list, PointerBuffer event)
/* 457:    */   {
/* 458:400 */     long function_pointer = CLCapabilities.clEnqueueFillBuffer;
/* 459:401 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 460:402 */     BufferChecks.checkDirect(pattern);
/* 461:403 */     if (event_wait_list != null) {
/* 462:404 */       BufferChecks.checkDirect(event_wait_list);
/* 463:    */     }
/* 464:405 */     if (event != null) {
/* 465:406 */       BufferChecks.checkBuffer(event, 1);
/* 466:    */     }
/* 467:407 */     int __result = nclEnqueueFillBuffer(command_queue.getPointer(), buffer.getPointer(), MemoryUtil.getAddress(pattern), pattern.remaining(), offset, size, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 468:408 */     return __result;
/* 469:    */   }
/* 470:    */   
/* 471:    */   static native int nclEnqueueFillBuffer(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt, long paramLong7, long paramLong8, long paramLong9);
/* 472:    */   
/* 473:    */   public static int clEnqueueFillImage(CLCommandQueue command_queue, CLMem image, ByteBuffer fill_color, PointerBuffer origin, PointerBuffer region, PointerBuffer event_wait_list, PointerBuffer event)
/* 474:    */   {
/* 475:413 */     long function_pointer = CLCapabilities.clEnqueueFillImage;
/* 476:414 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 477:415 */     BufferChecks.checkBuffer(fill_color, 16);
/* 478:416 */     BufferChecks.checkBuffer(origin, 3);
/* 479:417 */     BufferChecks.checkBuffer(region, 3);
/* 480:418 */     if (event_wait_list != null) {
/* 481:419 */       BufferChecks.checkDirect(event_wait_list);
/* 482:    */     }
/* 483:420 */     if (event != null) {
/* 484:421 */       BufferChecks.checkBuffer(event, 1);
/* 485:    */     }
/* 486:422 */     int __result = nclEnqueueFillImage(command_queue.getPointer(), image.getPointer(), MemoryUtil.getAddress(fill_color), MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 487:423 */     return __result;
/* 488:    */   }
/* 489:    */   
/* 490:    */   static native int nclEnqueueFillImage(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt, long paramLong6, long paramLong7, long paramLong8);
/* 491:    */   
/* 492:    */   public static int clEnqueueMigrateMemObjects(CLCommandQueue command_queue, PointerBuffer mem_objects, long flags, PointerBuffer event_wait_list, PointerBuffer event)
/* 493:    */   {
/* 494:428 */     long function_pointer = CLCapabilities.clEnqueueMigrateMemObjects;
/* 495:429 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 496:430 */     BufferChecks.checkDirect(mem_objects);
/* 497:431 */     if (event_wait_list != null) {
/* 498:432 */       BufferChecks.checkDirect(event_wait_list);
/* 499:    */     }
/* 500:433 */     if (event != null) {
/* 501:434 */       BufferChecks.checkBuffer(event, 1);
/* 502:    */     }
/* 503:435 */     int __result = nclEnqueueMigrateMemObjects(command_queue.getPointer(), mem_objects.remaining(), MemoryUtil.getAddress(mem_objects), flags, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 504:436 */     return __result;
/* 505:    */   }
/* 506:    */   
/* 507:    */   static native int nclEnqueueMigrateMemObjects(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, long paramLong5, long paramLong6);
/* 508:    */   
/* 509:    */   public static int clEnqueueMarkerWithWaitList(CLCommandQueue command_queue, PointerBuffer event_wait_list, PointerBuffer event)
/* 510:    */   {
/* 511:441 */     long function_pointer = CLCapabilities.clEnqueueMarkerWithWaitList;
/* 512:442 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 513:443 */     if (event_wait_list != null) {
/* 514:444 */       BufferChecks.checkDirect(event_wait_list);
/* 515:    */     }
/* 516:445 */     if (event != null) {
/* 517:446 */       BufferChecks.checkBuffer(event, 1);
/* 518:    */     }
/* 519:447 */     int __result = nclEnqueueMarkerWithWaitList(command_queue.getPointer(), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 520:448 */     return __result;
/* 521:    */   }
/* 522:    */   
/* 523:    */   static native int nclEnqueueMarkerWithWaitList(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/* 524:    */   
/* 525:    */   public static int clEnqueueBarrierWithWaitList(CLCommandQueue command_queue, PointerBuffer event_wait_list, PointerBuffer event)
/* 526:    */   {
/* 527:453 */     long function_pointer = CLCapabilities.clEnqueueBarrierWithWaitList;
/* 528:454 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 529:455 */     if (event_wait_list != null) {
/* 530:456 */       BufferChecks.checkDirect(event_wait_list);
/* 531:    */     }
/* 532:457 */     if (event != null) {
/* 533:458 */       BufferChecks.checkBuffer(event, 1);
/* 534:    */     }
/* 535:459 */     int __result = nclEnqueueBarrierWithWaitList(command_queue.getPointer(), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 536:460 */     return __result;
/* 537:    */   }
/* 538:    */   
/* 539:    */   static native int nclEnqueueBarrierWithWaitList(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/* 540:    */   
/* 541:    */   public static int clSetPrintfCallback(CLContext context, CLPrintfCallback pfn_notify)
/* 542:    */   {
/* 543:465 */     long function_pointer = CLCapabilities.clSetPrintfCallback;
/* 544:466 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 545:467 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 546:468 */     int __result = 0;
/* 547:    */     try
/* 548:    */     {
/* 549:470 */       __result = nclSetPrintfCallback(context.getPointer(), pfn_notify.getPointer(), user_data, function_pointer);
/* 550:471 */       return __result;
/* 551:    */     }
/* 552:    */     finally
/* 553:    */     {
/* 554:473 */       context.setPrintfCallback(user_data, __result);
/* 555:    */     }
/* 556:    */   }
/* 557:    */   
/* 558:    */   static native int nclSetPrintfCallback(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 559:    */   
/* 560:    */   static CLFunctionAddress clGetExtensionFunctionAddressForPlatform(CLPlatform platform, ByteBuffer func_name)
/* 561:    */   {
/* 562:479 */     long function_pointer = CLCapabilities.clGetExtensionFunctionAddressForPlatform;
/* 563:480 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 564:481 */     BufferChecks.checkDirect(func_name);
/* 565:482 */     BufferChecks.checkNullTerminated(func_name);
/* 566:483 */     CLFunctionAddress __result = new CLFunctionAddress(nclGetExtensionFunctionAddressForPlatform(platform.getPointer(), MemoryUtil.getAddress(func_name), function_pointer));
/* 567:484 */     return __result;
/* 568:    */   }
/* 569:    */   
/* 570:    */   static native long nclGetExtensionFunctionAddressForPlatform(long paramLong1, long paramLong2, long paramLong3);
/* 571:    */   
/* 572:    */   static CLFunctionAddress clGetExtensionFunctionAddressForPlatform(CLPlatform platform, CharSequence func_name)
/* 573:    */   {
/* 574:490 */     long function_pointer = CLCapabilities.clGetExtensionFunctionAddressForPlatform;
/* 575:491 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 576:492 */     CLFunctionAddress __result = new CLFunctionAddress(nclGetExtensionFunctionAddressForPlatform(platform.getPointer(), APIUtil.getBufferNT(func_name), function_pointer));
/* 577:493 */     return __result;
/* 578:    */   }
/* 579:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL12
 * JD-Core Version:    0.7.0.1
 */