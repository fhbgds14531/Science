/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ 
/*   8:    */ public final class ARBSeparateShaderObjects
/*   9:    */ {
/*  10:    */   public static final int GL_VERTEX_SHADER_BIT = 1;
/*  11:    */   public static final int GL_FRAGMENT_SHADER_BIT = 2;
/*  12:    */   public static final int GL_GEOMETRY_SHADER_BIT = 4;
/*  13:    */   public static final int GL_TESS_CONTROL_SHADER_BIT = 8;
/*  14:    */   public static final int GL_TESS_EVALUATION_SHADER_BIT = 16;
/*  15:    */   public static final int GL_ALL_SHADER_BITS = -1;
/*  16:    */   public static final int GL_PROGRAM_SEPARABLE = 33368;
/*  17:    */   public static final int GL_ACTIVE_PROGRAM = 33369;
/*  18:    */   public static final int GL_PROGRAM_PIPELINE_BINDING = 33370;
/*  19:    */   
/*  20:    */   public static void glUseProgramStages(int pipeline, int stages, int program)
/*  21:    */   {
/*  22: 40 */     GL41.glUseProgramStages(pipeline, stages, program);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static void glActiveShaderProgram(int pipeline, int program)
/*  26:    */   {
/*  27: 44 */     GL41.glActiveShaderProgram(pipeline, program);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static int glCreateShaderProgram(int type, ByteBuffer string)
/*  31:    */   {
/*  32: 51 */     return GL41.glCreateShaderProgram(type, string);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static int glCreateShaderProgram(int type, int count, ByteBuffer strings)
/*  36:    */   {
/*  37: 60 */     return GL41.glCreateShaderProgram(type, count, strings);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static int glCreateShaderProgram(int type, ByteBuffer[] strings)
/*  41:    */   {
/*  42: 65 */     return GL41.glCreateShaderProgram(type, strings);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static int glCreateShaderProgram(int type, CharSequence string)
/*  46:    */   {
/*  47: 70 */     return GL41.glCreateShaderProgram(type, string);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static int glCreateShaderProgram(int type, CharSequence[] strings)
/*  51:    */   {
/*  52: 75 */     return GL41.glCreateShaderProgram(type, strings);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void glBindProgramPipeline(int pipeline)
/*  56:    */   {
/*  57: 79 */     GL41.glBindProgramPipeline(pipeline);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void glDeleteProgramPipelines(IntBuffer pipelines)
/*  61:    */   {
/*  62: 83 */     GL41.glDeleteProgramPipelines(pipelines);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glDeleteProgramPipelines(int pipeline)
/*  66:    */   {
/*  67: 88 */     GL41.glDeleteProgramPipelines(pipeline);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static void glGenProgramPipelines(IntBuffer pipelines)
/*  71:    */   {
/*  72: 92 */     GL41.glGenProgramPipelines(pipelines);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int glGenProgramPipelines()
/*  76:    */   {
/*  77: 97 */     return GL41.glGenProgramPipelines();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static boolean glIsProgramPipeline(int pipeline)
/*  81:    */   {
/*  82:101 */     return GL41.glIsProgramPipeline(pipeline);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void glProgramParameteri(int program, int pname, int value)
/*  86:    */   {
/*  87:105 */     GL41.glProgramParameteri(program, pname, value);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void glGetProgramPipeline(int pipeline, int pname, IntBuffer params)
/*  91:    */   {
/*  92:109 */     GL41.glGetProgramPipeline(pipeline, pname, params);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static int glGetProgramPipelinei(int pipeline, int pname)
/*  96:    */   {
/*  97:114 */     return GL41.glGetProgramPipelinei(pipeline, pname);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void glProgramUniform1i(int program, int location, int v0)
/* 101:    */   {
/* 102:118 */     GL41.glProgramUniform1i(program, location, v0);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static void glProgramUniform2i(int program, int location, int v0, int v1)
/* 106:    */   {
/* 107:122 */     GL41.glProgramUniform2i(program, location, v0, v1);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void glProgramUniform3i(int program, int location, int v0, int v1, int v2)
/* 111:    */   {
/* 112:126 */     GL41.glProgramUniform3i(program, location, v0, v1, v2);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static void glProgramUniform4i(int program, int location, int v0, int v1, int v2, int v3)
/* 116:    */   {
/* 117:130 */     GL41.glProgramUniform4i(program, location, v0, v1, v2, v3);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static void glProgramUniform1f(int program, int location, float v0)
/* 121:    */   {
/* 122:134 */     GL41.glProgramUniform1f(program, location, v0);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static void glProgramUniform2f(int program, int location, float v0, float v1)
/* 126:    */   {
/* 127:138 */     GL41.glProgramUniform2f(program, location, v0, v1);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void glProgramUniform3f(int program, int location, float v0, float v1, float v2)
/* 131:    */   {
/* 132:142 */     GL41.glProgramUniform3f(program, location, v0, v1, v2);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static void glProgramUniform4f(int program, int location, float v0, float v1, float v2, float v3)
/* 136:    */   {
/* 137:146 */     GL41.glProgramUniform4f(program, location, v0, v1, v2, v3);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void glProgramUniform1d(int program, int location, double v0)
/* 141:    */   {
/* 142:150 */     GL41.glProgramUniform1d(program, location, v0);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static void glProgramUniform2d(int program, int location, double v0, double v1)
/* 146:    */   {
/* 147:154 */     GL41.glProgramUniform2d(program, location, v0, v1);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static void glProgramUniform3d(int program, int location, double v0, double v1, double v2)
/* 151:    */   {
/* 152:158 */     GL41.glProgramUniform3d(program, location, v0, v1, v2);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static void glProgramUniform4d(int program, int location, double v0, double v1, double v2, double v3)
/* 156:    */   {
/* 157:162 */     GL41.glProgramUniform4d(program, location, v0, v1, v2, v3);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static void glProgramUniform1(int program, int location, IntBuffer value)
/* 161:    */   {
/* 162:166 */     GL41.glProgramUniform1(program, location, value);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static void glProgramUniform2(int program, int location, IntBuffer value)
/* 166:    */   {
/* 167:170 */     GL41.glProgramUniform2(program, location, value);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static void glProgramUniform3(int program, int location, IntBuffer value)
/* 171:    */   {
/* 172:174 */     GL41.glProgramUniform3(program, location, value);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static void glProgramUniform4(int program, int location, IntBuffer value)
/* 176:    */   {
/* 177:178 */     GL41.glProgramUniform4(program, location, value);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static void glProgramUniform1(int program, int location, FloatBuffer value)
/* 181:    */   {
/* 182:182 */     GL41.glProgramUniform1(program, location, value);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static void glProgramUniform2(int program, int location, FloatBuffer value)
/* 186:    */   {
/* 187:186 */     GL41.glProgramUniform2(program, location, value);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static void glProgramUniform3(int program, int location, FloatBuffer value)
/* 191:    */   {
/* 192:190 */     GL41.glProgramUniform3(program, location, value);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static void glProgramUniform4(int program, int location, FloatBuffer value)
/* 196:    */   {
/* 197:194 */     GL41.glProgramUniform4(program, location, value);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static void glProgramUniform1(int program, int location, DoubleBuffer value)
/* 201:    */   {
/* 202:198 */     GL41.glProgramUniform1(program, location, value);
/* 203:    */   }
/* 204:    */   
/* 205:    */   public static void glProgramUniform2(int program, int location, DoubleBuffer value)
/* 206:    */   {
/* 207:202 */     GL41.glProgramUniform2(program, location, value);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static void glProgramUniform3(int program, int location, DoubleBuffer value)
/* 211:    */   {
/* 212:206 */     GL41.glProgramUniform3(program, location, value);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static void glProgramUniform4(int program, int location, DoubleBuffer value)
/* 216:    */   {
/* 217:210 */     GL41.glProgramUniform4(program, location, value);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static void glProgramUniform1ui(int program, int location, int v0)
/* 221:    */   {
/* 222:214 */     GL41.glProgramUniform1ui(program, location, v0);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static void glProgramUniform2ui(int program, int location, int v0, int v1)
/* 226:    */   {
/* 227:218 */     GL41.glProgramUniform2ui(program, location, v0, v1);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static void glProgramUniform3ui(int program, int location, int v0, int v1, int v2)
/* 231:    */   {
/* 232:222 */     GL41.glProgramUniform3ui(program, location, v0, v1, v2);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static void glProgramUniform4ui(int program, int location, int v0, int v1, int v2, int v3)
/* 236:    */   {
/* 237:226 */     GL41.glProgramUniform4ui(program, location, v0, v1, v2, v3);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static void glProgramUniform1u(int program, int location, IntBuffer value)
/* 241:    */   {
/* 242:230 */     GL41.glProgramUniform1u(program, location, value);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public static void glProgramUniform2u(int program, int location, IntBuffer value)
/* 246:    */   {
/* 247:234 */     GL41.glProgramUniform2u(program, location, value);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public static void glProgramUniform3u(int program, int location, IntBuffer value)
/* 251:    */   {
/* 252:238 */     GL41.glProgramUniform3u(program, location, value);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public static void glProgramUniform4u(int program, int location, IntBuffer value)
/* 256:    */   {
/* 257:242 */     GL41.glProgramUniform4u(program, location, value);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public static void glProgramUniformMatrix2(int program, int location, boolean transpose, FloatBuffer value)
/* 261:    */   {
/* 262:246 */     GL41.glProgramUniformMatrix2(program, location, transpose, value);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public static void glProgramUniformMatrix3(int program, int location, boolean transpose, FloatBuffer value)
/* 266:    */   {
/* 267:250 */     GL41.glProgramUniformMatrix3(program, location, transpose, value);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public static void glProgramUniformMatrix4(int program, int location, boolean transpose, FloatBuffer value)
/* 271:    */   {
/* 272:254 */     GL41.glProgramUniformMatrix4(program, location, transpose, value);
/* 273:    */   }
/* 274:    */   
/* 275:    */   public static void glProgramUniformMatrix2(int program, int location, boolean transpose, DoubleBuffer value)
/* 276:    */   {
/* 277:258 */     GL41.glProgramUniformMatrix2(program, location, transpose, value);
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static void glProgramUniformMatrix3(int program, int location, boolean transpose, DoubleBuffer value)
/* 281:    */   {
/* 282:262 */     GL41.glProgramUniformMatrix3(program, location, transpose, value);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public static void glProgramUniformMatrix4(int program, int location, boolean transpose, DoubleBuffer value)
/* 286:    */   {
/* 287:266 */     GL41.glProgramUniformMatrix4(program, location, transpose, value);
/* 288:    */   }
/* 289:    */   
/* 290:    */   public static void glProgramUniformMatrix2x3(int program, int location, boolean transpose, FloatBuffer value)
/* 291:    */   {
/* 292:270 */     GL41.glProgramUniformMatrix2x3(program, location, transpose, value);
/* 293:    */   }
/* 294:    */   
/* 295:    */   public static void glProgramUniformMatrix3x2(int program, int location, boolean transpose, FloatBuffer value)
/* 296:    */   {
/* 297:274 */     GL41.glProgramUniformMatrix3x2(program, location, transpose, value);
/* 298:    */   }
/* 299:    */   
/* 300:    */   public static void glProgramUniformMatrix2x4(int program, int location, boolean transpose, FloatBuffer value)
/* 301:    */   {
/* 302:278 */     GL41.glProgramUniformMatrix2x4(program, location, transpose, value);
/* 303:    */   }
/* 304:    */   
/* 305:    */   public static void glProgramUniformMatrix4x2(int program, int location, boolean transpose, FloatBuffer value)
/* 306:    */   {
/* 307:282 */     GL41.glProgramUniformMatrix4x2(program, location, transpose, value);
/* 308:    */   }
/* 309:    */   
/* 310:    */   public static void glProgramUniformMatrix3x4(int program, int location, boolean transpose, FloatBuffer value)
/* 311:    */   {
/* 312:286 */     GL41.glProgramUniformMatrix3x4(program, location, transpose, value);
/* 313:    */   }
/* 314:    */   
/* 315:    */   public static void glProgramUniformMatrix4x3(int program, int location, boolean transpose, FloatBuffer value)
/* 316:    */   {
/* 317:290 */     GL41.glProgramUniformMatrix4x3(program, location, transpose, value);
/* 318:    */   }
/* 319:    */   
/* 320:    */   public static void glProgramUniformMatrix2x3(int program, int location, boolean transpose, DoubleBuffer value)
/* 321:    */   {
/* 322:294 */     GL41.glProgramUniformMatrix2x3(program, location, transpose, value);
/* 323:    */   }
/* 324:    */   
/* 325:    */   public static void glProgramUniformMatrix3x2(int program, int location, boolean transpose, DoubleBuffer value)
/* 326:    */   {
/* 327:298 */     GL41.glProgramUniformMatrix3x2(program, location, transpose, value);
/* 328:    */   }
/* 329:    */   
/* 330:    */   public static void glProgramUniformMatrix2x4(int program, int location, boolean transpose, DoubleBuffer value)
/* 331:    */   {
/* 332:302 */     GL41.glProgramUniformMatrix2x4(program, location, transpose, value);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public static void glProgramUniformMatrix4x2(int program, int location, boolean transpose, DoubleBuffer value)
/* 336:    */   {
/* 337:306 */     GL41.glProgramUniformMatrix4x2(program, location, transpose, value);
/* 338:    */   }
/* 339:    */   
/* 340:    */   public static void glProgramUniformMatrix3x4(int program, int location, boolean transpose, DoubleBuffer value)
/* 341:    */   {
/* 342:310 */     GL41.glProgramUniformMatrix3x4(program, location, transpose, value);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public static void glProgramUniformMatrix4x3(int program, int location, boolean transpose, DoubleBuffer value)
/* 346:    */   {
/* 347:314 */     GL41.glProgramUniformMatrix4x3(program, location, transpose, value);
/* 348:    */   }
/* 349:    */   
/* 350:    */   public static void glValidateProgramPipeline(int pipeline)
/* 351:    */   {
/* 352:318 */     GL41.glValidateProgramPipeline(pipeline);
/* 353:    */   }
/* 354:    */   
/* 355:    */   public static void glGetProgramPipelineInfoLog(int pipeline, IntBuffer length, ByteBuffer infoLog)
/* 356:    */   {
/* 357:322 */     GL41.glGetProgramPipelineInfoLog(pipeline, length, infoLog);
/* 358:    */   }
/* 359:    */   
/* 360:    */   public static String glGetProgramPipelineInfoLog(int pipeline, int bufSize)
/* 361:    */   {
/* 362:327 */     return GL41.glGetProgramPipelineInfoLog(pipeline, bufSize);
/* 363:    */   }
/* 364:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBSeparateShaderObjects
 * JD-Core Version:    0.7.0.1
 */