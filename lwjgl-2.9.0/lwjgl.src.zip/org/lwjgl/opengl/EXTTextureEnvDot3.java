package org.lwjgl.opengl;

public final class EXTTextureEnvDot3
{
  public static final int GL_DOT3_RGB_EXT = 34624;
  public static final int GL_DOT3_RGBA_EXT = 34625;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureEnvDot3
 * JD-Core Version:    0.7.0.1
 */