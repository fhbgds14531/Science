/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ 
/*  6:   */ public final class ARBDrawIndirect
/*  7:   */ {
/*  8:   */   public static final int GL_DRAW_INDIRECT_BUFFER = 36671;
/*  9:   */   public static final int GL_DRAW_INDIRECT_BUFFER_BINDING = 36675;
/* 10:   */   
/* 11:   */   public static void glDrawArraysIndirect(int mode, ByteBuffer indirect)
/* 12:   */   {
/* 13:28 */     GL40.glDrawArraysIndirect(mode, indirect);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static void glDrawArraysIndirect(int mode, long indirect_buffer_offset)
/* 17:   */   {
/* 18:31 */     GL40.glDrawArraysIndirect(mode, indirect_buffer_offset);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static void glDrawArraysIndirect(int mode, IntBuffer indirect)
/* 22:   */   {
/* 23:36 */     GL40.glDrawArraysIndirect(mode, indirect);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static void glDrawElementsIndirect(int mode, int type, ByteBuffer indirect)
/* 27:   */   {
/* 28:40 */     GL40.glDrawElementsIndirect(mode, type, indirect);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void glDrawElementsIndirect(int mode, int type, long indirect_buffer_offset)
/* 32:   */   {
/* 33:43 */     GL40.glDrawElementsIndirect(mode, type, indirect_buffer_offset);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static void glDrawElementsIndirect(int mode, int type, IntBuffer indirect)
/* 37:   */   {
/* 38:48 */     GL40.glDrawElementsIndirect(mode, type, indirect);
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDrawIndirect
 * JD-Core Version:    0.7.0.1
 */