/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.PointerBuffer;
/*   4:    */ 
/*   5:    */ public final class CLDevice
/*   6:    */   extends CLObjectChild<CLDevice>
/*   7:    */ {
/*   8: 43 */   private static final InfoUtil<CLDevice> util = CLPlatform.getInfoUtilInstance(CLDevice.class, "CL_DEVICE_UTIL");
/*   9:    */   private final CLPlatform platform;
/*  10:    */   private final CLObjectRegistry<CLDevice> subCLDevices;
/*  11:    */   private Object caps;
/*  12:    */   
/*  13:    */   CLDevice(long pointer, CLPlatform platform)
/*  14:    */   {
/*  15: 51 */     this(pointer, null, platform);
/*  16:    */   }
/*  17:    */   
/*  18:    */   CLDevice(long pointer, CLDevice parent)
/*  19:    */   {
/*  20: 61 */     this(pointer, parent, parent.getPlatform());
/*  21:    */   }
/*  22:    */   
/*  23:    */   CLDevice(long pointer, CLDevice parent, CLPlatform platform)
/*  24:    */   {
/*  25: 65 */     super(pointer, parent);
/*  26: 67 */     if (isValid())
/*  27:    */     {
/*  28: 68 */       this.platform = platform;
/*  29: 69 */       platform.getCLDeviceRegistry().registerObject(this);
/*  30:    */       
/*  31: 71 */       this.subCLDevices = new CLObjectRegistry();
/*  32: 72 */       if (parent != null) {
/*  33: 73 */         parent.subCLDevices.registerObject(this);
/*  34:    */       }
/*  35:    */     }
/*  36:    */     else
/*  37:    */     {
/*  38: 75 */       this.platform = null;
/*  39: 76 */       this.subCLDevices = null;
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public CLPlatform getPlatform()
/*  44:    */   {
/*  45: 81 */     return this.platform;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public CLDevice getSubCLDevice(long id)
/*  49:    */   {
/*  50: 91 */     return (CLDevice)this.subCLDevices.getObject(id);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String getInfoString(int param_name)
/*  54:    */   {
/*  55:103 */     return util.getInfoString(this, param_name);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public int getInfoInt(int param_name)
/*  59:    */   {
/*  60:114 */     return util.getInfoInt(this, param_name);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean getInfoBoolean(int param_name)
/*  64:    */   {
/*  65:125 */     return util.getInfoInt(this, param_name) != 0;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public long getInfoSize(int param_name)
/*  69:    */   {
/*  70:136 */     return util.getInfoSize(this, param_name);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public long[] getInfoSizeArray(int param_name)
/*  74:    */   {
/*  75:147 */     return util.getInfoSizeArray(this, param_name);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public long getInfoLong(int param_name)
/*  79:    */   {
/*  80:159 */     return util.getInfoLong(this, param_name);
/*  81:    */   }
/*  82:    */   
/*  83:    */   void setCapabilities(Object caps)
/*  84:    */   {
/*  85:165 */     this.caps = caps;
/*  86:    */   }
/*  87:    */   
/*  88:    */   Object getCapabilities()
/*  89:    */   {
/*  90:169 */     return this.caps;
/*  91:    */   }
/*  92:    */   
/*  93:    */   int retain()
/*  94:    */   {
/*  95:173 */     if (getParent() == null) {
/*  96:174 */       return getReferenceCount();
/*  97:    */     }
/*  98:176 */     return super.retain();
/*  99:    */   }
/* 100:    */   
/* 101:    */   int release()
/* 102:    */   {
/* 103:180 */     if (getParent() == null) {
/* 104:181 */       return getReferenceCount();
/* 105:    */     }
/* 106:    */     try
/* 107:    */     {
/* 108:184 */       return super.release();
/* 109:    */     }
/* 110:    */     finally
/* 111:    */     {
/* 112:186 */       if (!isValid()) {
/* 113:187 */         ((CLDevice)getParent()).subCLDevices.unregisterObject(this);
/* 114:    */       }
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   CLObjectRegistry<CLDevice> getSubCLDeviceRegistry()
/* 119:    */   {
/* 120:191 */     return this.subCLDevices;
/* 121:    */   }
/* 122:    */   
/* 123:    */   void registerSubCLDevices(PointerBuffer devices)
/* 124:    */   {
/* 125:199 */     for (int i = devices.position(); i < devices.limit(); i++)
/* 126:    */     {
/* 127:200 */       long pointer = devices.get(i);
/* 128:201 */       if (pointer != 0L) {
/* 129:202 */         new CLDevice(pointer, this);
/* 130:    */       }
/* 131:    */     }
/* 132:    */   }
/* 133:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLDevice
 * JD-Core Version:    0.7.0.1
 */