/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ import org.lwjgl.opencl.CLContext;
/*  5:   */ import org.lwjgl.opencl.CLEvent;
/*  6:   */ 
/*  7:   */ public final class ARBCLEvent
/*  8:   */ {
/*  9:   */   public static final int GL_SYNC_CL_EVENT_ARB = 33344;
/* 10:   */   public static final int GL_SYNC_CL_EVENT_COMPLETE_ARB = 33345;
/* 11:   */   
/* 12:   */   public static GLSync glCreateSyncFromCLeventARB(CLContext context, CLEvent event, int flags)
/* 13:   */   {
/* 14:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:25 */     long function_pointer = caps.glCreateSyncFromCLeventARB;
/* 16:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:27 */     GLSync __result = new GLSync(nglCreateSyncFromCLeventARB(context.getPointer(), event.getPointer(), flags, function_pointer));
/* 18:28 */     return __result;
/* 19:   */   }
/* 20:   */   
/* 21:   */   static native long nglCreateSyncFromCLeventARB(long paramLong1, long paramLong2, int paramInt, long paramLong3);
/* 22:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBCLEvent
 * JD-Core Version:    0.7.0.1
 */