/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.DoubleBuffer;
/*  4:   */ import java.nio.FloatBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class APPLEVertexProgramEvaluators
/*  9:   */ {
/* 10:   */   public static final int GL_VERTEX_ATTRIB_MAP1_APPLE = 35328;
/* 11:   */   public static final int GL_VERTEX_ATTRIB_MAP2_APPLE = 35329;
/* 12:   */   public static final int GL_VERTEX_ATTRIB_MAP1_SIZE_APPLE = 35330;
/* 13:   */   public static final int GL_VERTEX_ATTRIB_MAP1_COEFF_APPLE = 35331;
/* 14:   */   public static final int GL_VERTEX_ATTRIB_MAP1_ORDER_APPLE = 35332;
/* 15:   */   public static final int GL_VERTEX_ATTRIB_MAP1_DOMAIN_APPLE = 35333;
/* 16:   */   public static final int GL_VERTEX_ATTRIB_MAP2_SIZE_APPLE = 35334;
/* 17:   */   public static final int GL_VERTEX_ATTRIB_MAP2_COEFF_APPLE = 35335;
/* 18:   */   public static final int GL_VERTEX_ATTRIB_MAP2_ORDER_APPLE = 35336;
/* 19:   */   public static final int GL_VERTEX_ATTRIB_MAP2_DOMAIN_APPLE = 35337;
/* 20:   */   
/* 21:   */   public static void glEnableVertexAttribAPPLE(int index, int pname)
/* 22:   */   {
/* 23:33 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 24:34 */     long function_pointer = caps.glEnableVertexAttribAPPLE;
/* 25:35 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 26:36 */     nglEnableVertexAttribAPPLE(index, pname, function_pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   static native void nglEnableVertexAttribAPPLE(int paramInt1, int paramInt2, long paramLong);
/* 30:   */   
/* 31:   */   public static void glDisableVertexAttribAPPLE(int index, int pname)
/* 32:   */   {
/* 33:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 34:42 */     long function_pointer = caps.glDisableVertexAttribAPPLE;
/* 35:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:44 */     nglDisableVertexAttribAPPLE(index, pname, function_pointer);
/* 37:   */   }
/* 38:   */   
/* 39:   */   static native void nglDisableVertexAttribAPPLE(int paramInt1, int paramInt2, long paramLong);
/* 40:   */   
/* 41:   */   public static boolean glIsVertexAttribEnabledAPPLE(int index, int pname)
/* 42:   */   {
/* 43:49 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 44:50 */     long function_pointer = caps.glIsVertexAttribEnabledAPPLE;
/* 45:51 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 46:52 */     boolean __result = nglIsVertexAttribEnabledAPPLE(index, pname, function_pointer);
/* 47:53 */     return __result;
/* 48:   */   }
/* 49:   */   
/* 50:   */   static native boolean nglIsVertexAttribEnabledAPPLE(int paramInt1, int paramInt2, long paramLong);
/* 51:   */   
/* 52:   */   public static void glMapVertexAttrib1dAPPLE(int index, int size, double u1, double u2, int stride, int order, DoubleBuffer points)
/* 53:   */   {
/* 54:58 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 55:59 */     long function_pointer = caps.glMapVertexAttrib1dAPPLE;
/* 56:60 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 57:61 */     BufferChecks.checkDirect(points);
/* 58:62 */     nglMapVertexAttrib1dAPPLE(index, size, u1, u2, stride, order, MemoryUtil.getAddress(points), function_pointer);
/* 59:   */   }
/* 60:   */   
/* 61:   */   static native void nglMapVertexAttrib1dAPPLE(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 62:   */   
/* 63:   */   public static void glMapVertexAttrib1fAPPLE(int index, int size, float u1, float u2, int stride, int order, FloatBuffer points)
/* 64:   */   {
/* 65:67 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 66:68 */     long function_pointer = caps.glMapVertexAttrib1fAPPLE;
/* 67:69 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 68:70 */     BufferChecks.checkDirect(points);
/* 69:71 */     nglMapVertexAttrib1fAPPLE(index, size, u1, u2, stride, order, MemoryUtil.getAddress(points), function_pointer);
/* 70:   */   }
/* 71:   */   
/* 72:   */   static native void nglMapVertexAttrib1fAPPLE(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 73:   */   
/* 74:   */   public static void glMapVertexAttrib2dAPPLE(int index, int size, double u1, double u2, int ustride, int uorder, double v1, double v2, int vstride, int vorder, DoubleBuffer points)
/* 75:   */   {
/* 76:76 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 77:77 */     long function_pointer = caps.glMapVertexAttrib2dAPPLE;
/* 78:78 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 79:79 */     BufferChecks.checkDirect(points);
/* 80:80 */     nglMapVertexAttrib2dAPPLE(index, size, u1, u2, ustride, uorder, v1, v2, vstride, vorder, MemoryUtil.getAddress(points), function_pointer);
/* 81:   */   }
/* 82:   */   
/* 83:   */   static native void nglMapVertexAttrib2dAPPLE(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3, int paramInt4, double paramDouble3, double paramDouble4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 84:   */   
/* 85:   */   public static void glMapVertexAttrib2fAPPLE(int index, int size, float u1, float u2, int ustride, int uorder, float v1, float v2, int vstride, int vorder, FloatBuffer points)
/* 86:   */   {
/* 87:85 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 88:86 */     long function_pointer = caps.glMapVertexAttrib2fAPPLE;
/* 89:87 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 90:88 */     BufferChecks.checkDirect(points);
/* 91:89 */     nglMapVertexAttrib2fAPPLE(index, size, u1, u2, ustride, uorder, v1, v2, vstride, vorder, MemoryUtil.getAddress(points), function_pointer);
/* 92:   */   }
/* 93:   */   
/* 94:   */   static native void nglMapVertexAttrib2fAPPLE(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, int paramInt3, int paramInt4, float paramFloat3, float paramFloat4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 95:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEVertexProgramEvaluators
 * JD-Core Version:    0.7.0.1
 */