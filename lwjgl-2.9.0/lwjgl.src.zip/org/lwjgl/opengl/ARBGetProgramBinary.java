/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ 
/*  6:   */ public final class ARBGetProgramBinary
/*  7:   */ {
/*  8:   */   public static final int GL_PROGRAM_BINARY_RETRIEVABLE_HINT = 33367;
/*  9:   */   public static final int GL_PROGRAM_BINARY_LENGTH = 34625;
/* 10:   */   public static final int GL_NUM_PROGRAM_BINARY_FORMATS = 34814;
/* 11:   */   public static final int GL_PROGRAM_BINARY_FORMATS = 34815;
/* 12:   */   
/* 13:   */   public static void glGetProgramBinary(int program, IntBuffer length, IntBuffer binaryFormat, ByteBuffer binary)
/* 14:   */   {
/* 15:31 */     GL41.glGetProgramBinary(program, length, binaryFormat, binary);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static void glProgramBinary(int program, int binaryFormat, ByteBuffer binary)
/* 19:   */   {
/* 20:35 */     GL41.glProgramBinary(program, binaryFormat, binary);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static void glProgramParameteri(int program, int pname, int value)
/* 24:   */   {
/* 25:39 */     GL41.glProgramParameteri(program, pname, value);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBGetProgramBinary
 * JD-Core Version:    0.7.0.1
 */