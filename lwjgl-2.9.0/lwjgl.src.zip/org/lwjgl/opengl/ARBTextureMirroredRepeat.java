package org.lwjgl.opengl;

public final class ARBTextureMirroredRepeat
{
  public static final int GL_MIRRORED_REPEAT_ARB = 33648;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureMirroredRepeat
 * JD-Core Version:    0.7.0.1
 */