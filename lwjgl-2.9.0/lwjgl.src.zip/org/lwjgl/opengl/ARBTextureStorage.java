/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBTextureStorage
/*  6:   */ {
/*  7:   */   public static final int GL_TEXTURE_IMMUTABLE_FORMAT = 37167;
/*  8:   */   
/*  9:   */   public static void glTexStorage1D(int target, int levels, int internalformat, int width)
/* 10:   */   {
/* 11:18 */     GL42.glTexStorage1D(target, levels, internalformat, width);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void glTexStorage2D(int target, int levels, int internalformat, int width, int height)
/* 15:   */   {
/* 16:22 */     GL42.glTexStorage2D(target, levels, internalformat, width, height);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void glTexStorage3D(int target, int levels, int internalformat, int width, int height, int depth)
/* 20:   */   {
/* 21:26 */     GL42.glTexStorage3D(target, levels, internalformat, width, height, depth);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glTextureStorage1DEXT(int texture, int target, int levels, int internalformat, int width)
/* 25:   */   {
/* 26:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:31 */     long function_pointer = caps.glTextureStorage1DEXT;
/* 28:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:33 */     nglTextureStorage1DEXT(texture, target, levels, internalformat, width, function_pointer);
/* 30:   */   }
/* 31:   */   
/* 32:   */   static native void nglTextureStorage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 33:   */   
/* 34:   */   public static void glTextureStorage2DEXT(int texture, int target, int levels, int internalformat, int width, int height)
/* 35:   */   {
/* 36:38 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 37:39 */     long function_pointer = caps.glTextureStorage2DEXT;
/* 38:40 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 39:41 */     nglTextureStorage2DEXT(texture, target, levels, internalformat, width, height, function_pointer);
/* 40:   */   }
/* 41:   */   
/* 42:   */   static native void nglTextureStorage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 43:   */   
/* 44:   */   public static void glTextureStorage3DEXT(int texture, int target, int levels, int internalformat, int width, int height, int depth)
/* 45:   */   {
/* 46:46 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 47:47 */     long function_pointer = caps.glTextureStorage3DEXT;
/* 48:48 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 49:49 */     nglTextureStorage3DEXT(texture, target, levels, internalformat, width, height, depth, function_pointer);
/* 50:   */   }
/* 51:   */   
/* 52:   */   static native void nglTextureStorage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/* 53:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureStorage
 * JD-Core Version:    0.7.0.1
 */