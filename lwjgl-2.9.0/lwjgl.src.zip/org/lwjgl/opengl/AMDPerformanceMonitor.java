/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class AMDPerformanceMonitor
/*   9:    */ {
/*  10:    */   public static final int GL_COUNTER_TYPE_AMD = 35776;
/*  11:    */   public static final int GL_COUNTER_RANGE_AMD = 35777;
/*  12:    */   public static final int GL_UNSIGNED_INT64_AMD = 35778;
/*  13:    */   public static final int GL_PERCENTAGE_AMD = 35779;
/*  14:    */   public static final int GL_PERFMON_RESULT_AVAILABLE_AMD = 35780;
/*  15:    */   public static final int GL_PERFMON_RESULT_SIZE_AMD = 35781;
/*  16:    */   public static final int GL_PERFMON_RESULT_AMD = 35782;
/*  17:    */   
/*  18:    */   public static void glGetPerfMonitorGroupsAMD(IntBuffer numGroups, IntBuffer groups)
/*  19:    */   {
/*  20: 33 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  21: 34 */     long function_pointer = caps.glGetPerfMonitorGroupsAMD;
/*  22: 35 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  23: 36 */     if (numGroups != null) {
/*  24: 37 */       BufferChecks.checkBuffer(numGroups, 1);
/*  25:    */     }
/*  26: 38 */     BufferChecks.checkDirect(groups);
/*  27: 39 */     nglGetPerfMonitorGroupsAMD(MemoryUtil.getAddressSafe(numGroups), groups.remaining(), MemoryUtil.getAddress(groups), function_pointer);
/*  28:    */   }
/*  29:    */   
/*  30:    */   static native void nglGetPerfMonitorGroupsAMD(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/*  31:    */   
/*  32:    */   public static void glGetPerfMonitorCountersAMD(int group, IntBuffer numCounters, IntBuffer maxActiveCounters, IntBuffer counters)
/*  33:    */   {
/*  34: 44 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  35: 45 */     long function_pointer = caps.glGetPerfMonitorCountersAMD;
/*  36: 46 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  37: 47 */     BufferChecks.checkBuffer(numCounters, 1);
/*  38: 48 */     BufferChecks.checkBuffer(maxActiveCounters, 1);
/*  39: 49 */     if (counters != null) {
/*  40: 50 */       BufferChecks.checkDirect(counters);
/*  41:    */     }
/*  42: 51 */     nglGetPerfMonitorCountersAMD(group, MemoryUtil.getAddress(numCounters), MemoryUtil.getAddress(maxActiveCounters), counters == null ? 0 : counters.remaining(), MemoryUtil.getAddressSafe(counters), function_pointer);
/*  43:    */   }
/*  44:    */   
/*  45:    */   static native void nglGetPerfMonitorCountersAMD(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, long paramLong4);
/*  46:    */   
/*  47:    */   public static void glGetPerfMonitorGroupStringAMD(int group, IntBuffer length, ByteBuffer groupString)
/*  48:    */   {
/*  49: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  50: 57 */     long function_pointer = caps.glGetPerfMonitorGroupStringAMD;
/*  51: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  52: 59 */     if (length != null) {
/*  53: 60 */       BufferChecks.checkBuffer(length, 1);
/*  54:    */     }
/*  55: 61 */     if (groupString != null) {
/*  56: 62 */       BufferChecks.checkDirect(groupString);
/*  57:    */     }
/*  58: 63 */     nglGetPerfMonitorGroupStringAMD(group, groupString == null ? 0 : groupString.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddressSafe(groupString), function_pointer);
/*  59:    */   }
/*  60:    */   
/*  61:    */   static native void nglGetPerfMonitorGroupStringAMD(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  62:    */   
/*  63:    */   public static String glGetPerfMonitorGroupStringAMD(int group, int bufSize)
/*  64:    */   {
/*  65: 69 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  66: 70 */     long function_pointer = caps.glGetPerfMonitorGroupStringAMD;
/*  67: 71 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  68: 72 */     IntBuffer groupString_length = APIUtil.getLengths(caps);
/*  69: 73 */     ByteBuffer groupString = APIUtil.getBufferByte(caps, bufSize);
/*  70: 74 */     nglGetPerfMonitorGroupStringAMD(group, bufSize, MemoryUtil.getAddress0(groupString_length), MemoryUtil.getAddress(groupString), function_pointer);
/*  71: 75 */     groupString.limit(groupString_length.get(0));
/*  72: 76 */     return APIUtil.getString(caps, groupString);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void glGetPerfMonitorCounterStringAMD(int group, int counter, IntBuffer length, ByteBuffer counterString)
/*  76:    */   {
/*  77: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  78: 81 */     long function_pointer = caps.glGetPerfMonitorCounterStringAMD;
/*  79: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  80: 83 */     if (length != null) {
/*  81: 84 */       BufferChecks.checkBuffer(length, 1);
/*  82:    */     }
/*  83: 85 */     if (counterString != null) {
/*  84: 86 */       BufferChecks.checkDirect(counterString);
/*  85:    */     }
/*  86: 87 */     nglGetPerfMonitorCounterStringAMD(group, counter, counterString == null ? 0 : counterString.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddressSafe(counterString), function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglGetPerfMonitorCounterStringAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/*  90:    */   
/*  91:    */   public static String glGetPerfMonitorCounterStringAMD(int group, int counter, int bufSize)
/*  92:    */   {
/*  93: 93 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  94: 94 */     long function_pointer = caps.glGetPerfMonitorCounterStringAMD;
/*  95: 95 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  96: 96 */     IntBuffer counterString_length = APIUtil.getLengths(caps);
/*  97: 97 */     ByteBuffer counterString = APIUtil.getBufferByte(caps, bufSize);
/*  98: 98 */     nglGetPerfMonitorCounterStringAMD(group, counter, bufSize, MemoryUtil.getAddress0(counterString_length), MemoryUtil.getAddress(counterString), function_pointer);
/*  99: 99 */     counterString.limit(counterString_length.get(0));
/* 100:100 */     return APIUtil.getString(caps, counterString);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void glGetPerfMonitorCounterInfoAMD(int group, int counter, int pname, ByteBuffer data)
/* 104:    */   {
/* 105:104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106:105 */     long function_pointer = caps.glGetPerfMonitorCounterInfoAMD;
/* 107:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108:107 */     BufferChecks.checkBuffer(data, 16);
/* 109:108 */     nglGetPerfMonitorCounterInfoAMD(group, counter, pname, MemoryUtil.getAddress(data), function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   static native void nglGetPerfMonitorCounterInfoAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 113:    */   
/* 114:    */   public static void glGenPerfMonitorsAMD(IntBuffer monitors)
/* 115:    */   {
/* 116:113 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 117:114 */     long function_pointer = caps.glGenPerfMonitorsAMD;
/* 118:115 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 119:116 */     BufferChecks.checkDirect(monitors);
/* 120:117 */     nglGenPerfMonitorsAMD(monitors.remaining(), MemoryUtil.getAddress(monitors), function_pointer);
/* 121:    */   }
/* 122:    */   
/* 123:    */   static native void nglGenPerfMonitorsAMD(int paramInt, long paramLong1, long paramLong2);
/* 124:    */   
/* 125:    */   public static int glGenPerfMonitorsAMD()
/* 126:    */   {
/* 127:123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 128:124 */     long function_pointer = caps.glGenPerfMonitorsAMD;
/* 129:125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 130:126 */     IntBuffer monitors = APIUtil.getBufferInt(caps);
/* 131:127 */     nglGenPerfMonitorsAMD(1, MemoryUtil.getAddress(monitors), function_pointer);
/* 132:128 */     return monitors.get(0);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static void glDeletePerfMonitorsAMD(IntBuffer monitors)
/* 136:    */   {
/* 137:132 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 138:133 */     long function_pointer = caps.glDeletePerfMonitorsAMD;
/* 139:134 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 140:135 */     BufferChecks.checkDirect(monitors);
/* 141:136 */     nglDeletePerfMonitorsAMD(monitors.remaining(), MemoryUtil.getAddress(monitors), function_pointer);
/* 142:    */   }
/* 143:    */   
/* 144:    */   static native void nglDeletePerfMonitorsAMD(int paramInt, long paramLong1, long paramLong2);
/* 145:    */   
/* 146:    */   public static void glDeletePerfMonitorsAMD(int monitor)
/* 147:    */   {
/* 148:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 149:143 */     long function_pointer = caps.glDeletePerfMonitorsAMD;
/* 150:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 151:145 */     nglDeletePerfMonitorsAMD(1, APIUtil.getInt(caps, monitor), function_pointer);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static void glSelectPerfMonitorCountersAMD(int monitor, boolean enable, int group, IntBuffer counterList)
/* 155:    */   {
/* 156:149 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 157:150 */     long function_pointer = caps.glSelectPerfMonitorCountersAMD;
/* 158:151 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 159:152 */     BufferChecks.checkDirect(counterList);
/* 160:153 */     nglSelectPerfMonitorCountersAMD(monitor, enable, group, counterList.remaining(), MemoryUtil.getAddress(counterList), function_pointer);
/* 161:    */   }
/* 162:    */   
/* 163:    */   static native void nglSelectPerfMonitorCountersAMD(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 164:    */   
/* 165:    */   public static void glSelectPerfMonitorCountersAMD(int monitor, boolean enable, int group, int counter)
/* 166:    */   {
/* 167:159 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 168:160 */     long function_pointer = caps.glSelectPerfMonitorCountersAMD;
/* 169:161 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 170:162 */     nglSelectPerfMonitorCountersAMD(monitor, enable, group, 1, APIUtil.getInt(caps, counter), function_pointer);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static void glBeginPerfMonitorAMD(int monitor)
/* 174:    */   {
/* 175:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 176:167 */     long function_pointer = caps.glBeginPerfMonitorAMD;
/* 177:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 178:169 */     nglBeginPerfMonitorAMD(monitor, function_pointer);
/* 179:    */   }
/* 180:    */   
/* 181:    */   static native void nglBeginPerfMonitorAMD(int paramInt, long paramLong);
/* 182:    */   
/* 183:    */   public static void glEndPerfMonitorAMD(int monitor)
/* 184:    */   {
/* 185:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 186:175 */     long function_pointer = caps.glEndPerfMonitorAMD;
/* 187:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 188:177 */     nglEndPerfMonitorAMD(monitor, function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglEndPerfMonitorAMD(int paramInt, long paramLong);
/* 192:    */   
/* 193:    */   public static void glGetPerfMonitorCounterDataAMD(int monitor, int pname, IntBuffer data, IntBuffer bytesWritten)
/* 194:    */   {
/* 195:182 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 196:183 */     long function_pointer = caps.glGetPerfMonitorCounterDataAMD;
/* 197:184 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 198:185 */     BufferChecks.checkDirect(data);
/* 199:186 */     if (bytesWritten != null) {
/* 200:187 */       BufferChecks.checkBuffer(bytesWritten, 1);
/* 201:    */     }
/* 202:188 */     nglGetPerfMonitorCounterDataAMD(monitor, pname, data.remaining(), MemoryUtil.getAddress(data), MemoryUtil.getAddressSafe(bytesWritten), function_pointer);
/* 203:    */   }
/* 204:    */   
/* 205:    */   static native void nglGetPerfMonitorCounterDataAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/* 206:    */   
/* 207:    */   public static int glGetPerfMonitorCounterDataAMD(int monitor, int pname)
/* 208:    */   {
/* 209:194 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 210:195 */     long function_pointer = caps.glGetPerfMonitorCounterDataAMD;
/* 211:196 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 212:197 */     IntBuffer data = APIUtil.getBufferInt(caps);
/* 213:198 */     nglGetPerfMonitorCounterDataAMD(monitor, pname, 4, MemoryUtil.getAddress(data), 0L, function_pointer);
/* 214:199 */     return data.get(0);
/* 215:    */   }
/* 216:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDPerformanceMonitor
 * JD-Core Version:    0.7.0.1
 */