/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import org.lwjgl.PointerBuffer;
/*   5:    */ 
/*   6:    */ public final class CLProgram
/*   7:    */   extends CLObjectChild<CLContext>
/*   8:    */ {
/*   9: 45 */   private static final CLProgramUtil util = (CLProgramUtil)CLPlatform.getInfoUtilInstance(CLProgram.class, "CL_PROGRAM_UTIL");
/*  10:    */   private final CLObjectRegistry<CLKernel> clKernels;
/*  11:    */   
/*  12:    */   CLProgram(long pointer, CLContext context)
/*  13:    */   {
/*  14: 50 */     super(pointer, context);
/*  15: 52 */     if (isValid())
/*  16:    */     {
/*  17: 53 */       context.getCLProgramRegistry().registerObject(this);
/*  18: 54 */       this.clKernels = new CLObjectRegistry();
/*  19:    */     }
/*  20:    */     else
/*  21:    */     {
/*  22: 56 */       this.clKernels = null;
/*  23:    */     }
/*  24:    */   }
/*  25:    */   
/*  26:    */   public CLKernel getCLKernel(long id)
/*  27:    */   {
/*  28: 67 */     return (CLKernel)this.clKernels.getObject(id);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public CLKernel[] createKernelsInProgram()
/*  32:    */   {
/*  33: 78 */     return util.createKernelsInProgram(this);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getInfoString(int param_name)
/*  37:    */   {
/*  38: 89 */     return util.getInfoString(this, param_name);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int getInfoInt(int param_name)
/*  42:    */   {
/*  43:100 */     return util.getInfoInt(this, param_name);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public long[] getInfoSizeArray(int param_name)
/*  47:    */   {
/*  48:111 */     return util.getInfoSizeArray(this, param_name);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public CLDevice[] getInfoDevices()
/*  52:    */   {
/*  53:120 */     return util.getInfoDevices(this);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public ByteBuffer getInfoBinaries(ByteBuffer target)
/*  57:    */   {
/*  58:135 */     return util.getInfoBinaries(this, target);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public ByteBuffer[] getInfoBinaries(ByteBuffer[] target)
/*  62:    */   {
/*  63:150 */     return util.getInfoBinaries(this, target);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String getBuildInfoString(CLDevice device, int param_name)
/*  67:    */   {
/*  68:163 */     return util.getBuildInfoString(this, device, param_name);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public int getBuildInfoInt(CLDevice device, int param_name)
/*  72:    */   {
/*  73:174 */     return util.getBuildInfoInt(this, device, param_name);
/*  74:    */   }
/*  75:    */   
/*  76:    */   CLObjectRegistry<CLKernel> getCLKernelRegistry()
/*  77:    */   {
/*  78:196 */     return this.clKernels;
/*  79:    */   }
/*  80:    */   
/*  81:    */   void registerCLKernels(PointerBuffer kernels)
/*  82:    */   {
/*  83:204 */     for (int i = kernels.position(); i < kernels.limit(); i++)
/*  84:    */     {
/*  85:205 */       long pointer = kernels.get(i);
/*  86:206 */       if (pointer != 0L) {
/*  87:207 */         new CLKernel(pointer, this);
/*  88:    */       }
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   int release()
/*  93:    */   {
/*  94:    */     try
/*  95:    */     {
/*  96:213 */       return super.release();
/*  97:    */     }
/*  98:    */     finally
/*  99:    */     {
/* 100:215 */       if (!isValid()) {
/* 101:216 */         ((CLContext)getParent()).getCLProgramRegistry().unregisterObject(this);
/* 102:    */       }
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   static abstract interface CLProgramUtil
/* 107:    */     extends InfoUtil<CLProgram>
/* 108:    */   {
/* 109:    */     public abstract CLKernel[] createKernelsInProgram(CLProgram paramCLProgram);
/* 110:    */     
/* 111:    */     public abstract CLDevice[] getInfoDevices(CLProgram paramCLProgram);
/* 112:    */     
/* 113:    */     public abstract ByteBuffer getInfoBinaries(CLProgram paramCLProgram, ByteBuffer paramByteBuffer);
/* 114:    */     
/* 115:    */     public abstract ByteBuffer[] getInfoBinaries(CLProgram paramCLProgram, ByteBuffer[] paramArrayOfByteBuffer);
/* 116:    */     
/* 117:    */     public abstract String getBuildInfoString(CLProgram paramCLProgram, CLDevice paramCLDevice, int paramInt);
/* 118:    */     
/* 119:    */     public abstract int getBuildInfoInt(CLProgram paramCLProgram, CLDevice paramCLDevice, int paramInt);
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLProgram
 * JD-Core Version:    0.7.0.1
 */