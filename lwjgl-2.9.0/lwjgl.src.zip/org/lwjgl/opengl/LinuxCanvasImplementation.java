/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.awt.GraphicsConfiguration;
/*   5:    */ import java.awt.GraphicsDevice;
/*   6:    */ import java.lang.reflect.Method;
/*   7:    */ import java.security.AccessController;
/*   8:    */ import java.security.PrivilegedExceptionAction;
/*   9:    */ import org.lwjgl.LWJGLException;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ 
/*  12:    */ final class LinuxCanvasImplementation
/*  13:    */   implements AWTCanvasImplementation
/*  14:    */ {
/*  15:    */   static int getScreenFromDevice(GraphicsDevice device)
/*  16:    */     throws LWJGLException
/*  17:    */   {
/*  18:    */     try
/*  19:    */     {
/*  20: 53 */       Method getScreen_method = (Method)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  21:    */       {
/*  22:    */         public Method run()
/*  23:    */           throws Exception
/*  24:    */         {
/*  25: 55 */           return this.val$device.getClass().getMethod("getScreen", new Class[0]);
/*  26:    */         }
/*  27: 57 */       });
/*  28: 58 */       Integer screen = (Integer)getScreen_method.invoke(device, new Object[0]);
/*  29: 59 */       return screen.intValue();
/*  30:    */     }
/*  31:    */     catch (Exception e)
/*  32:    */     {
/*  33: 61 */       throw new LWJGLException(e);
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static int getVisualIDFromConfiguration(GraphicsConfiguration configuration)
/*  38:    */     throws LWJGLException
/*  39:    */   {
/*  40:    */     try
/*  41:    */     {
/*  42: 67 */       Method getVisual_method = (Method)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  43:    */       {
/*  44:    */         public Method run()
/*  45:    */           throws Exception
/*  46:    */         {
/*  47: 69 */           return this.val$configuration.getClass().getMethod("getVisual", new Class[0]);
/*  48:    */         }
/*  49: 71 */       });
/*  50: 72 */       Integer visual = (Integer)getVisual_method.invoke(configuration, new Object[0]);
/*  51: 73 */       return visual.intValue();
/*  52:    */     }
/*  53:    */     catch (Exception e)
/*  54:    */     {
/*  55: 75 */       throw new LWJGLException(e);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   public PeerInfo createPeerInfo(Canvas component, PixelFormat pixel_format, ContextAttribs attribs)
/*  60:    */     throws LWJGLException
/*  61:    */   {
/*  62: 80 */     return new LinuxAWTGLCanvasPeerInfo(component);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public GraphicsConfiguration findConfiguration(GraphicsDevice device, PixelFormat pixel_format)
/*  66:    */     throws LWJGLException
/*  67:    */   {
/*  68:    */     try
/*  69:    */     {
/*  70: 90 */       int screen = getScreenFromDevice(device);
/*  71: 91 */       int visual_id_matching_format = findVisualIDFromFormat(screen, pixel_format);
/*  72: 92 */       GraphicsConfiguration[] configurations = device.getConfigurations();
/*  73: 93 */       for (GraphicsConfiguration configuration : configurations)
/*  74:    */       {
/*  75: 94 */         int visual_id = getVisualIDFromConfiguration(configuration);
/*  76: 95 */         if (visual_id == visual_id_matching_format) {
/*  77: 96 */           return configuration;
/*  78:    */         }
/*  79:    */       }
/*  80:    */     }
/*  81:    */     catch (LWJGLException e)
/*  82:    */     {
/*  83: 99 */       LWJGLUtil.log("Got exception while trying to determine configuration: " + e);
/*  84:    */     }
/*  85:101 */     return null;
/*  86:    */   }
/*  87:    */   
/*  88:    */   /* Error */
/*  89:    */   private static int findVisualIDFromFormat(int screen, PixelFormat pixel_format)
/*  90:    */     throws LWJGLException
/*  91:    */   {
/*  92:    */     // Byte code:
/*  93:    */     //   0: invokestatic 28	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  94:    */     //   3: invokestatic 29	org/lwjgl/opengl/GLContext:loadOpenGLLibrary	()V
/*  95:    */     //   6: invokestatic 30	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  96:    */     //   9: invokestatic 31	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  97:    */     //   12: iload_0
/*  98:    */     //   13: aload_1
/*  99:    */     //   14: invokestatic 32	org/lwjgl/opengl/LinuxCanvasImplementation:nFindVisualIDFromFormat	(JILorg/lwjgl/opengl/PixelFormat;)I
/* 100:    */     //   17: istore_2
/* 101:    */     //   18: invokestatic 33	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 102:    */     //   21: invokestatic 34	org/lwjgl/opengl/GLContext:unloadOpenGLLibrary	()V
/* 103:    */     //   24: invokestatic 35	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 104:    */     //   27: iload_2
/* 105:    */     //   28: ireturn
/* 106:    */     //   29: astore_3
/* 107:    */     //   30: invokestatic 33	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 108:    */     //   33: aload_3
/* 109:    */     //   34: athrow
/* 110:    */     //   35: astore 4
/* 111:    */     //   37: invokestatic 34	org/lwjgl/opengl/GLContext:unloadOpenGLLibrary	()V
/* 112:    */     //   40: aload 4
/* 113:    */     //   42: athrow
/* 114:    */     //   43: astore 5
/* 115:    */     //   45: invokestatic 35	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 116:    */     //   48: aload 5
/* 117:    */     //   50: athrow
/* 118:    */     // Line number table:
/* 119:    */     //   Java source line #106	-> byte code offset #0
/* 120:    */     //   Java source line #108	-> byte code offset #3
/* 121:    */     //   Java source line #110	-> byte code offset #6
/* 122:    */     //   Java source line #111	-> byte code offset #9
/* 123:    */     //   Java source line #113	-> byte code offset #18
/* 124:    */     //   Java source line #116	-> byte code offset #21
/* 125:    */     //   Java source line #119	-> byte code offset #24
/* 126:    */     //   Java source line #113	-> byte code offset #29
/* 127:    */     //   Java source line #116	-> byte code offset #35
/* 128:    */     //   Java source line #119	-> byte code offset #43
/* 129:    */     // Local variable table:
/* 130:    */     //   start	length	slot	name	signature
/* 131:    */     //   0	51	0	screen	int
/* 132:    */     //   0	51	1	pixel_format	PixelFormat
/* 133:    */     //   17	11	2	i	int
/* 134:    */     //   29	5	3	localObject1	Object
/* 135:    */     //   35	6	4	localObject2	Object
/* 136:    */     //   43	6	5	localObject3	Object
/* 137:    */     // Exception table:
/* 138:    */     //   from	to	target	type
/* 139:    */     //   6	18	29	finally
/* 140:    */     //   29	30	29	finally
/* 141:    */     //   3	21	35	finally
/* 142:    */     //   29	37	35	finally
/* 143:    */     //   0	24	43	finally
/* 144:    */     //   29	45	43	finally
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static native int nFindVisualIDFromFormat(long paramLong, int paramInt, PixelFormat paramPixelFormat)
/* 148:    */     throws LWJGLException;
/* 149:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxCanvasImplementation
 * JD-Core Version:    0.7.0.1
 */