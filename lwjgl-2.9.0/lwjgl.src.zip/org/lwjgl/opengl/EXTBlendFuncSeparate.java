/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTBlendFuncSeparate
/*  6:   */ {
/*  7:   */   public static final int GL_BLEND_DST_RGB_EXT = 32968;
/*  8:   */   public static final int GL_BLEND_SRC_RGB_EXT = 32969;
/*  9:   */   public static final int GL_BLEND_DST_ALPHA_EXT = 32970;
/* 10:   */   public static final int GL_BLEND_SRC_ALPHA_EXT = 32971;
/* 11:   */   
/* 12:   */   public static void glBlendFuncSeparateEXT(int sfactorRGB, int dfactorRGB, int sfactorAlpha, int dfactorAlpha)
/* 13:   */   {
/* 14:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:19 */     long function_pointer = caps.glBlendFuncSeparateEXT;
/* 16:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:21 */     nglBlendFuncSeparateEXT(sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglBlendFuncSeparateEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 21:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBlendFuncSeparate
 * JD-Core Version:    0.7.0.1
 */