/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ 
/*   9:    */ public final class ARBVertexProgram
/*  10:    */   extends ARBProgram
/*  11:    */ {
/*  12:    */   public static final int GL_VERTEX_PROGRAM_ARB = 34336;
/*  13:    */   public static final int GL_VERTEX_PROGRAM_POINT_SIZE_ARB = 34370;
/*  14:    */   public static final int GL_VERTEX_PROGRAM_TWO_SIDE_ARB = 34371;
/*  15:    */   public static final int GL_COLOR_SUM_ARB = 33880;
/*  16:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB = 34338;
/*  17:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB = 34339;
/*  18:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB = 34340;
/*  19:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB = 34341;
/*  20:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB = 34922;
/*  21:    */   public static final int GL_CURRENT_VERTEX_ATTRIB_ARB = 34342;
/*  22:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB = 34373;
/*  23:    */   public static final int GL_PROGRAM_ADDRESS_REGISTERS_ARB = 34992;
/*  24:    */   public static final int GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB = 34993;
/*  25:    */   public static final int GL_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34994;
/*  26:    */   public static final int GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB = 34995;
/*  27:    */   public static final int GL_MAX_VERTEX_ATTRIBS_ARB = 34921;
/*  28:    */   
/*  29:    */   public static void glVertexAttrib1sARB(int index, short x)
/*  30:    */   {
/*  31: 61 */     ARBVertexShader.glVertexAttrib1sARB(index, x);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static void glVertexAttrib1fARB(int index, float x)
/*  35:    */   {
/*  36: 65 */     ARBVertexShader.glVertexAttrib1fARB(index, x);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static void glVertexAttrib1dARB(int index, double x)
/*  40:    */   {
/*  41: 69 */     ARBVertexShader.glVertexAttrib1dARB(index, x);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void glVertexAttrib2sARB(int index, short x, short y)
/*  45:    */   {
/*  46: 73 */     ARBVertexShader.glVertexAttrib2sARB(index, x, y);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static void glVertexAttrib2fARB(int index, float x, float y)
/*  50:    */   {
/*  51: 77 */     ARBVertexShader.glVertexAttrib2fARB(index, x, y);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static void glVertexAttrib2dARB(int index, double x, double y)
/*  55:    */   {
/*  56: 81 */     ARBVertexShader.glVertexAttrib2dARB(index, x, y);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void glVertexAttrib3sARB(int index, short x, short y, short z)
/*  60:    */   {
/*  61: 85 */     ARBVertexShader.glVertexAttrib3sARB(index, x, y, z);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static void glVertexAttrib3fARB(int index, float x, float y, float z)
/*  65:    */   {
/*  66: 89 */     ARBVertexShader.glVertexAttrib3fARB(index, x, y, z);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static void glVertexAttrib3dARB(int index, double x, double y, double z)
/*  70:    */   {
/*  71: 93 */     ARBVertexShader.glVertexAttrib3dARB(index, x, y, z);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static void glVertexAttrib4sARB(int index, short x, short y, short z, short w)
/*  75:    */   {
/*  76: 97 */     ARBVertexShader.glVertexAttrib4sARB(index, x, y, z, w);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static void glVertexAttrib4fARB(int index, float x, float y, float z, float w)
/*  80:    */   {
/*  81:101 */     ARBVertexShader.glVertexAttrib4fARB(index, x, y, z, w);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static void glVertexAttrib4dARB(int index, double x, double y, double z, double w)
/*  85:    */   {
/*  86:105 */     ARBVertexShader.glVertexAttrib4dARB(index, x, y, z, w);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static void glVertexAttrib4NubARB(int index, byte x, byte y, byte z, byte w)
/*  90:    */   {
/*  91:109 */     ARBVertexShader.glVertexAttrib4NubARB(index, x, y, z, w);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static void glVertexAttribPointerARB(int index, int size, boolean normalized, int stride, DoubleBuffer buffer)
/*  95:    */   {
/*  96:113 */     ARBVertexShader.glVertexAttribPointerARB(index, size, normalized, stride, buffer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static void glVertexAttribPointerARB(int index, int size, boolean normalized, int stride, FloatBuffer buffer)
/* 100:    */   {
/* 101:116 */     ARBVertexShader.glVertexAttribPointerARB(index, size, normalized, stride, buffer);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, ByteBuffer buffer)
/* 105:    */   {
/* 106:119 */     ARBVertexShader.glVertexAttribPointerARB(index, size, unsigned, normalized, stride, buffer);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, IntBuffer buffer)
/* 110:    */   {
/* 111:122 */     ARBVertexShader.glVertexAttribPointerARB(index, size, unsigned, normalized, stride, buffer);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static void glVertexAttribPointerARB(int index, int size, boolean unsigned, boolean normalized, int stride, ShortBuffer buffer)
/* 115:    */   {
/* 116:125 */     ARBVertexShader.glVertexAttribPointerARB(index, size, unsigned, normalized, stride, buffer);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static void glVertexAttribPointerARB(int index, int size, int type, boolean normalized, int stride, long buffer_buffer_offset)
/* 120:    */   {
/* 121:128 */     ARBVertexShader.glVertexAttribPointerARB(index, size, type, normalized, stride, buffer_buffer_offset);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static void glEnableVertexAttribArrayARB(int index)
/* 125:    */   {
/* 126:132 */     ARBVertexShader.glEnableVertexAttribArrayARB(index);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static void glDisableVertexAttribArrayARB(int index)
/* 130:    */   {
/* 131:136 */     ARBVertexShader.glDisableVertexAttribArrayARB(index);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static void glGetVertexAttribARB(int index, int pname, FloatBuffer params)
/* 135:    */   {
/* 136:140 */     ARBVertexShader.glGetVertexAttribARB(index, pname, params);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static void glGetVertexAttribARB(int index, int pname, DoubleBuffer params)
/* 140:    */   {
/* 141:144 */     ARBVertexShader.glGetVertexAttribARB(index, pname, params);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public static void glGetVertexAttribARB(int index, int pname, IntBuffer params)
/* 145:    */   {
/* 146:148 */     ARBVertexShader.glGetVertexAttribARB(index, pname, params);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static ByteBuffer glGetVertexAttribPointerARB(int index, int pname, long result_size)
/* 150:    */   {
/* 151:152 */     return ARBVertexShader.glGetVertexAttribPointerARB(index, pname, result_size);
/* 152:    */   }
/* 153:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexProgram
 * JD-Core Version:    0.7.0.1
 */