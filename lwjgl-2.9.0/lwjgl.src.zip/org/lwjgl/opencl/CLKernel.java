/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ public final class CLKernel
/*   4:    */   extends CLObjectChild<CLProgram>
/*   5:    */ {
/*   6: 41 */   private static final CLKernelUtil util = (CLKernelUtil)CLPlatform.getInfoUtilInstance(CLKernel.class, "CL_KERNEL_UTIL");
/*   7:    */   
/*   8:    */   CLKernel(long pointer, CLProgram program)
/*   9:    */   {
/*  10: 44 */     super(pointer, program);
/*  11: 45 */     if (isValid()) {
/*  12: 46 */       program.getCLKernelRegistry().registerObject(this);
/*  13:    */     }
/*  14:    */   }
/*  15:    */   
/*  16:    */   public CLKernel setArg(int index, byte value)
/*  17:    */   {
/*  18: 63 */     util.setArg(this, index, value);
/*  19: 64 */     return this;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public CLKernel setArg(int index, short value)
/*  23:    */   {
/*  24: 77 */     util.setArg(this, index, value);
/*  25: 78 */     return this;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public CLKernel setArg(int index, int value)
/*  29:    */   {
/*  30: 91 */     util.setArg(this, index, value);
/*  31: 92 */     return this;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public CLKernel setArg(int index, long value)
/*  35:    */   {
/*  36:105 */     util.setArg(this, index, value);
/*  37:106 */     return this;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public CLKernel setArg(int index, float value)
/*  41:    */   {
/*  42:119 */     util.setArg(this, index, value);
/*  43:120 */     return this;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public CLKernel setArg(int index, double value)
/*  47:    */   {
/*  48:133 */     util.setArg(this, index, value);
/*  49:134 */     return this;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public CLKernel setArg(int index, CLObject value)
/*  53:    */   {
/*  54:147 */     util.setArg(this, index, value);
/*  55:148 */     return this;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public CLKernel setArgSize(int index, long size)
/*  59:    */   {
/*  60:160 */     util.setArgSize(this, index, size);
/*  61:161 */     return this;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getInfoString(int param_name)
/*  65:    */   {
/*  66:174 */     return util.getInfoString(this, param_name);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public int getInfoInt(int param_name)
/*  70:    */   {
/*  71:185 */     return util.getInfoInt(this, param_name);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public long getWorkGroupInfoSize(CLDevice device, int param_name)
/*  75:    */   {
/*  76:198 */     return util.getWorkGroupInfoSize(this, device, param_name);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public long[] getWorkGroupInfoSizeArray(CLDevice device, int param_name)
/*  80:    */   {
/*  81:209 */     return util.getWorkGroupInfoSizeArray(this, device, param_name);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public long getWorkGroupInfoLong(CLDevice device, int param_name)
/*  85:    */   {
/*  86:221 */     return util.getWorkGroupInfoLong(this, device, param_name);
/*  87:    */   }
/*  88:    */   
/*  89:    */   int release()
/*  90:    */   {
/*  91:    */     try
/*  92:    */     {
/*  93:255 */       return super.release();
/*  94:    */     }
/*  95:    */     finally
/*  96:    */     {
/*  97:257 */       if (!isValid()) {
/*  98:258 */         ((CLProgram)getParent()).getCLKernelRegistry().unregisterObject(this);
/*  99:    */       }
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   static abstract interface CLKernelUtil
/* 104:    */     extends InfoUtil<CLKernel>
/* 105:    */   {
/* 106:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, byte paramByte);
/* 107:    */     
/* 108:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, short paramShort);
/* 109:    */     
/* 110:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt1, int paramInt2);
/* 111:    */     
/* 112:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, long paramLong);
/* 113:    */     
/* 114:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, float paramFloat);
/* 115:    */     
/* 116:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, double paramDouble);
/* 117:    */     
/* 118:    */     public abstract void setArg(CLKernel paramCLKernel, int paramInt, CLObject paramCLObject);
/* 119:    */     
/* 120:    */     public abstract void setArgSize(CLKernel paramCLKernel, int paramInt, long paramLong);
/* 121:    */     
/* 122:    */     public abstract long getWorkGroupInfoSize(CLKernel paramCLKernel, CLDevice paramCLDevice, int paramInt);
/* 123:    */     
/* 124:    */     public abstract long[] getWorkGroupInfoSizeArray(CLKernel paramCLKernel, CLDevice paramCLDevice, int paramInt);
/* 125:    */     
/* 126:    */     public abstract long getWorkGroupInfoLong(CLKernel paramCLKernel, CLDevice paramCLDevice, int paramInt);
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLKernel
 * JD-Core Version:    0.7.0.1
 */