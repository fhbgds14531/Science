package org.lwjgl.opencl;

public final class EXTAtomicCounters64
{
  public static final int CL_DEVICE_MAX_ATOMIC_COUNTERS_EXT = 16434;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.EXTAtomicCounters64
 * JD-Core Version:    0.7.0.1
 */