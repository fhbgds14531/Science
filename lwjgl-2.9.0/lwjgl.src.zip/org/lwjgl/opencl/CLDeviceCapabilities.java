/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.util.Set;
/*   4:    */ import java.util.StringTokenizer;
/*   5:    */ 
/*   6:    */ public class CLDeviceCapabilities
/*   7:    */ {
/*   8:    */   public final int majorVersion;
/*   9:    */   public final int minorVersion;
/*  10:    */   public final boolean OpenCL11;
/*  11:    */   public final boolean OpenCL12;
/*  12:    */   public final boolean CL_AMD_device_attribute_query;
/*  13:    */   public final boolean CL_AMD_device_memory_flags;
/*  14:    */   public final boolean CL_AMD_fp64;
/*  15:    */   public final boolean CL_AMD_media_ops;
/*  16:    */   public final boolean CL_AMD_media_ops2;
/*  17:    */   public final boolean CL_AMD_offline_devices;
/*  18:    */   public final boolean CL_AMD_popcnt;
/*  19:    */   public final boolean CL_AMD_printf;
/*  20:    */   public final boolean CL_AMD_vec3;
/*  21:    */   final boolean CL_APPLE_ContextLoggingFunctions;
/*  22:    */   public final boolean CL_APPLE_SetMemObjectDestructor;
/*  23:    */   public final boolean CL_APPLE_gl_sharing;
/*  24:    */   public final boolean CL_EXT_atomic_counters_32;
/*  25:    */   public final boolean CL_EXT_atomic_counters_64;
/*  26:    */   public final boolean CL_EXT_device_fission;
/*  27:    */   public final boolean CL_EXT_migrate_memobject;
/*  28:    */   public final boolean CL_INTEL_immediate_execution;
/*  29:    */   public final boolean CL_INTEL_printf;
/*  30:    */   public final boolean CL_INTEL_thread_local_exec;
/*  31:    */   public final boolean CL_KHR_3d_image_writes;
/*  32:    */   public final boolean CL_KHR_byte_addressable_store;
/*  33:    */   public final boolean CL_KHR_depth_images;
/*  34:    */   public final boolean CL_KHR_fp16;
/*  35:    */   public final boolean CL_KHR_fp64;
/*  36:    */   public final boolean CL_KHR_gl_depth_images;
/*  37:    */   public final boolean CL_KHR_gl_event;
/*  38:    */   public final boolean CL_KHR_gl_msaa_sharing;
/*  39:    */   public final boolean CL_KHR_gl_sharing;
/*  40:    */   public final boolean CL_KHR_global_int32_base_atomics;
/*  41:    */   public final boolean CL_KHR_global_int32_extended_atomics;
/*  42:    */   public final boolean CL_KHR_image2d_from_buffer;
/*  43:    */   public final boolean CL_KHR_initialize_memory;
/*  44:    */   public final boolean CL_KHR_int64_base_atomics;
/*  45:    */   public final boolean CL_KHR_int64_extended_atomics;
/*  46:    */   public final boolean CL_KHR_local_int32_base_atomics;
/*  47:    */   public final boolean CL_KHR_local_int32_extended_atomics;
/*  48:    */   public final boolean CL_KHR_select_fprounding_mode;
/*  49:    */   public final boolean CL_KHR_spir;
/*  50:    */   public final boolean CL_KHR_terminate_context;
/*  51:    */   public final boolean CL_NV_compiler_options;
/*  52:    */   public final boolean CL_NV_device_attribute_query;
/*  53:    */   public final boolean CL_NV_pragma_unroll;
/*  54:    */   
/*  55:    */   public CLDeviceCapabilities(CLDevice device)
/*  56:    */   {
/*  57: 59 */     String extensionList = device.getInfoString(4144);
/*  58: 60 */     String version = device.getInfoString(4143);
/*  59: 61 */     if (!version.startsWith("OpenCL ")) {
/*  60: 62 */       throw new RuntimeException("Invalid OpenCL version string: " + version);
/*  61:    */     }
/*  62:    */     try
/*  63:    */     {
/*  64: 65 */       StringTokenizer tokenizer = new StringTokenizer(version.substring(7), ". ");
/*  65:    */       
/*  66: 67 */       this.majorVersion = Integer.parseInt(tokenizer.nextToken());
/*  67: 68 */       this.minorVersion = Integer.parseInt(tokenizer.nextToken());
/*  68:    */       
/*  69: 70 */       this.OpenCL11 = ((1 < this.majorVersion) || ((1 == this.majorVersion) && (1 <= this.minorVersion)));
/*  70: 71 */       this.OpenCL12 = ((1 < this.majorVersion) || ((1 == this.majorVersion) && (2 <= this.minorVersion)));
/*  71:    */     }
/*  72:    */     catch (RuntimeException e)
/*  73:    */     {
/*  74: 73 */       throw new RuntimeException("The major and/or minor OpenCL version \"" + version + "\" is malformed: " + e.getMessage());
/*  75:    */     }
/*  76: 76 */     Set<String> extensions = APIUtil.getExtensions(extensionList);
/*  77: 77 */     this.CL_AMD_device_attribute_query = extensions.contains("cl_amd_device_attribute_query");
/*  78: 78 */     this.CL_AMD_device_memory_flags = extensions.contains("cl_amd_device_memory_flags");
/*  79: 79 */     this.CL_AMD_fp64 = extensions.contains("cl_amd_fp64");
/*  80: 80 */     this.CL_AMD_media_ops = extensions.contains("cl_amd_media_ops");
/*  81: 81 */     this.CL_AMD_media_ops2 = extensions.contains("cl_amd_media_ops2");
/*  82: 82 */     this.CL_AMD_offline_devices = extensions.contains("cl_amd_offline_devices");
/*  83: 83 */     this.CL_AMD_popcnt = extensions.contains("cl_amd_popcnt");
/*  84: 84 */     this.CL_AMD_printf = extensions.contains("cl_amd_printf");
/*  85: 85 */     this.CL_AMD_vec3 = extensions.contains("cl_amd_vec3");
/*  86: 86 */     this.CL_APPLE_ContextLoggingFunctions = ((extensions.contains("cl_apple_contextloggingfunctions")) && (CLCapabilities.CL_APPLE_ContextLoggingFunctions));
/*  87: 87 */     this.CL_APPLE_SetMemObjectDestructor = ((extensions.contains("cl_apple_setmemobjectdestructor")) && (CLCapabilities.CL_APPLE_SetMemObjectDestructor));
/*  88: 88 */     this.CL_APPLE_gl_sharing = ((extensions.contains("cl_apple_gl_sharing")) && (CLCapabilities.CL_APPLE_gl_sharing));
/*  89: 89 */     this.CL_EXT_atomic_counters_32 = extensions.contains("cl_ext_atomic_counters_32");
/*  90: 90 */     this.CL_EXT_atomic_counters_64 = extensions.contains("cl_ext_atomic_counters_64");
/*  91: 91 */     this.CL_EXT_device_fission = ((extensions.contains("cl_ext_device_fission")) && (CLCapabilities.CL_EXT_device_fission));
/*  92: 92 */     this.CL_EXT_migrate_memobject = ((extensions.contains("cl_ext_migrate_memobject")) && (CLCapabilities.CL_EXT_migrate_memobject));
/*  93: 93 */     this.CL_INTEL_immediate_execution = extensions.contains("cl_intel_immediate_execution");
/*  94: 94 */     this.CL_INTEL_printf = extensions.contains("cl_intel_printf");
/*  95: 95 */     this.CL_INTEL_thread_local_exec = extensions.contains("cl_intel_thread_local_exec");
/*  96: 96 */     this.CL_KHR_3d_image_writes = extensions.contains("cl_khr_3d_image_writes");
/*  97: 97 */     this.CL_KHR_byte_addressable_store = extensions.contains("cl_khr_byte_addressable_store");
/*  98: 98 */     this.CL_KHR_depth_images = extensions.contains("cl_khr_depth_images");
/*  99: 99 */     this.CL_KHR_fp16 = extensions.contains("cl_khr_fp16");
/* 100:100 */     this.CL_KHR_fp64 = extensions.contains("cl_khr_fp64");
/* 101:101 */     this.CL_KHR_gl_depth_images = extensions.contains("cl_khr_gl_depth_images");
/* 102:102 */     this.CL_KHR_gl_event = ((extensions.contains("cl_khr_gl_event")) && (CLCapabilities.CL_KHR_gl_event));
/* 103:103 */     this.CL_KHR_gl_msaa_sharing = extensions.contains("cl_khr_gl_msaa_sharing");
/* 104:104 */     this.CL_KHR_gl_sharing = ((extensions.contains("cl_khr_gl_sharing")) && (CLCapabilities.CL_KHR_gl_sharing));
/* 105:105 */     this.CL_KHR_global_int32_base_atomics = extensions.contains("cl_khr_global_int32_base_atomics");
/* 106:106 */     this.CL_KHR_global_int32_extended_atomics = extensions.contains("cl_khr_global_int32_extended_atomics");
/* 107:107 */     this.CL_KHR_image2d_from_buffer = extensions.contains("cl_khr_image2d_from_buffer");
/* 108:108 */     this.CL_KHR_initialize_memory = extensions.contains("cl_khr_initialize_memory");
/* 109:109 */     this.CL_KHR_int64_base_atomics = extensions.contains("cl_khr_int64_base_atomics");
/* 110:110 */     this.CL_KHR_int64_extended_atomics = extensions.contains("cl_khr_int64_extended_atomics");
/* 111:111 */     this.CL_KHR_local_int32_base_atomics = extensions.contains("cl_khr_local_int32_base_atomics");
/* 112:112 */     this.CL_KHR_local_int32_extended_atomics = extensions.contains("cl_khr_local_int32_extended_atomics");
/* 113:113 */     this.CL_KHR_select_fprounding_mode = extensions.contains("cl_khr_select_fprounding_mode");
/* 114:114 */     this.CL_KHR_spir = extensions.contains("cl_khr_spir");
/* 115:115 */     this.CL_KHR_terminate_context = ((extensions.contains("cl_khr_terminate_context")) && (CLCapabilities.CL_KHR_terminate_context));
/* 116:116 */     this.CL_NV_compiler_options = extensions.contains("cl_nv_compiler_options");
/* 117:117 */     this.CL_NV_device_attribute_query = extensions.contains("cl_nv_device_attribute_query");
/* 118:118 */     this.CL_NV_pragma_unroll = extensions.contains("cl_nv_pragma_unroll");
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int getMajorVersion()
/* 122:    */   {
/* 123:122 */     return this.majorVersion;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public int getMinorVersion()
/* 127:    */   {
/* 128:126 */     return this.minorVersion;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public String toString()
/* 132:    */   {
/* 133:130 */     StringBuilder buf = new StringBuilder();
/* 134:    */     
/* 135:132 */     buf.append("OpenCL ").append(this.majorVersion).append('.').append(this.minorVersion);
/* 136:    */     
/* 137:134 */     buf.append(" - Extensions: ");
/* 138:135 */     if (this.CL_AMD_device_attribute_query) {
/* 139:135 */       buf.append("cl_amd_device_attribute_query ");
/* 140:    */     }
/* 141:136 */     if (this.CL_AMD_device_memory_flags) {
/* 142:136 */       buf.append("cl_amd_device_memory_flags ");
/* 143:    */     }
/* 144:137 */     if (this.CL_AMD_fp64) {
/* 145:137 */       buf.append("cl_amd_fp64 ");
/* 146:    */     }
/* 147:138 */     if (this.CL_AMD_media_ops) {
/* 148:138 */       buf.append("cl_amd_media_ops ");
/* 149:    */     }
/* 150:139 */     if (this.CL_AMD_media_ops2) {
/* 151:139 */       buf.append("cl_amd_media_ops2 ");
/* 152:    */     }
/* 153:140 */     if (this.CL_AMD_offline_devices) {
/* 154:140 */       buf.append("cl_amd_offline_devices ");
/* 155:    */     }
/* 156:141 */     if (this.CL_AMD_popcnt) {
/* 157:141 */       buf.append("cl_amd_popcnt ");
/* 158:    */     }
/* 159:142 */     if (this.CL_AMD_printf) {
/* 160:142 */       buf.append("cl_amd_printf ");
/* 161:    */     }
/* 162:143 */     if (this.CL_AMD_vec3) {
/* 163:143 */       buf.append("cl_amd_vec3 ");
/* 164:    */     }
/* 165:144 */     if (this.CL_APPLE_ContextLoggingFunctions) {
/* 166:144 */       buf.append("cl_apple_contextloggingfunctions ");
/* 167:    */     }
/* 168:145 */     if (this.CL_APPLE_SetMemObjectDestructor) {
/* 169:145 */       buf.append("cl_apple_setmemobjectdestructor ");
/* 170:    */     }
/* 171:146 */     if (this.CL_APPLE_gl_sharing) {
/* 172:146 */       buf.append("cl_apple_gl_sharing ");
/* 173:    */     }
/* 174:147 */     if (this.CL_EXT_atomic_counters_32) {
/* 175:147 */       buf.append("cl_ext_atomic_counters_32 ");
/* 176:    */     }
/* 177:148 */     if (this.CL_EXT_atomic_counters_64) {
/* 178:148 */       buf.append("cl_ext_atomic_counters_64 ");
/* 179:    */     }
/* 180:149 */     if (this.CL_EXT_device_fission) {
/* 181:149 */       buf.append("cl_ext_device_fission ");
/* 182:    */     }
/* 183:150 */     if (this.CL_EXT_migrate_memobject) {
/* 184:150 */       buf.append("cl_ext_migrate_memobject ");
/* 185:    */     }
/* 186:151 */     if (this.CL_INTEL_immediate_execution) {
/* 187:151 */       buf.append("cl_intel_immediate_execution ");
/* 188:    */     }
/* 189:152 */     if (this.CL_INTEL_printf) {
/* 190:152 */       buf.append("cl_intel_printf ");
/* 191:    */     }
/* 192:153 */     if (this.CL_INTEL_thread_local_exec) {
/* 193:153 */       buf.append("cl_intel_thread_local_exec ");
/* 194:    */     }
/* 195:154 */     if (this.CL_KHR_3d_image_writes) {
/* 196:154 */       buf.append("cl_khr_3d_image_writes ");
/* 197:    */     }
/* 198:155 */     if (this.CL_KHR_byte_addressable_store) {
/* 199:155 */       buf.append("cl_khr_byte_addressable_store ");
/* 200:    */     }
/* 201:156 */     if (this.CL_KHR_depth_images) {
/* 202:156 */       buf.append("cl_khr_depth_images ");
/* 203:    */     }
/* 204:157 */     if (this.CL_KHR_fp16) {
/* 205:157 */       buf.append("cl_khr_fp16 ");
/* 206:    */     }
/* 207:158 */     if (this.CL_KHR_fp64) {
/* 208:158 */       buf.append("cl_khr_fp64 ");
/* 209:    */     }
/* 210:159 */     if (this.CL_KHR_gl_depth_images) {
/* 211:159 */       buf.append("cl_khr_gl_depth_images ");
/* 212:    */     }
/* 213:160 */     if (this.CL_KHR_gl_event) {
/* 214:160 */       buf.append("cl_khr_gl_event ");
/* 215:    */     }
/* 216:161 */     if (this.CL_KHR_gl_msaa_sharing) {
/* 217:161 */       buf.append("cl_khr_gl_msaa_sharing ");
/* 218:    */     }
/* 219:162 */     if (this.CL_KHR_gl_sharing) {
/* 220:162 */       buf.append("cl_khr_gl_sharing ");
/* 221:    */     }
/* 222:163 */     if (this.CL_KHR_global_int32_base_atomics) {
/* 223:163 */       buf.append("cl_khr_global_int32_base_atomics ");
/* 224:    */     }
/* 225:164 */     if (this.CL_KHR_global_int32_extended_atomics) {
/* 226:164 */       buf.append("cl_khr_global_int32_extended_atomics ");
/* 227:    */     }
/* 228:165 */     if (this.CL_KHR_image2d_from_buffer) {
/* 229:165 */       buf.append("cl_khr_image2d_from_buffer ");
/* 230:    */     }
/* 231:166 */     if (this.CL_KHR_initialize_memory) {
/* 232:166 */       buf.append("cl_khr_initialize_memory ");
/* 233:    */     }
/* 234:167 */     if (this.CL_KHR_int64_base_atomics) {
/* 235:167 */       buf.append("cl_khr_int64_base_atomics ");
/* 236:    */     }
/* 237:168 */     if (this.CL_KHR_int64_extended_atomics) {
/* 238:168 */       buf.append("cl_khr_int64_extended_atomics ");
/* 239:    */     }
/* 240:169 */     if (this.CL_KHR_local_int32_base_atomics) {
/* 241:169 */       buf.append("cl_khr_local_int32_base_atomics ");
/* 242:    */     }
/* 243:170 */     if (this.CL_KHR_local_int32_extended_atomics) {
/* 244:170 */       buf.append("cl_khr_local_int32_extended_atomics ");
/* 245:    */     }
/* 246:171 */     if (this.CL_KHR_select_fprounding_mode) {
/* 247:171 */       buf.append("cl_khr_select_fprounding_mode ");
/* 248:    */     }
/* 249:172 */     if (this.CL_KHR_spir) {
/* 250:172 */       buf.append("cl_khr_spir ");
/* 251:    */     }
/* 252:173 */     if (this.CL_KHR_terminate_context) {
/* 253:173 */       buf.append("cl_khr_terminate_context ");
/* 254:    */     }
/* 255:174 */     if (this.CL_NV_compiler_options) {
/* 256:174 */       buf.append("cl_nv_compiler_options ");
/* 257:    */     }
/* 258:175 */     if (this.CL_NV_device_attribute_query) {
/* 259:175 */       buf.append("cl_nv_device_attribute_query ");
/* 260:    */     }
/* 261:176 */     if (this.CL_NV_pragma_unroll) {
/* 262:176 */       buf.append("cl_nv_pragma_unroll ");
/* 263:    */     }
/* 264:178 */     return buf.toString();
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLDeviceCapabilities
 * JD-Core Version:    0.7.0.1
 */