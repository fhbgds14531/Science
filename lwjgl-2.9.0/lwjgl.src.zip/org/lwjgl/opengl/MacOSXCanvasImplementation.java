/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.awt.GraphicsConfiguration;
/*  5:   */ import java.awt.GraphicsDevice;
/*  6:   */ import org.lwjgl.LWJGLException;
/*  7:   */ 
/*  8:   */ final class MacOSXCanvasImplementation
/*  9:   */   implements AWTCanvasImplementation
/* 10:   */ {
/* 11:   */   public PeerInfo createPeerInfo(Canvas component, PixelFormat pixel_format, ContextAttribs attribs)
/* 12:   */     throws LWJGLException
/* 13:   */   {
/* 14:   */     try
/* 15:   */     {
/* 16:49 */       return new MacOSXAWTGLCanvasPeerInfo(component, pixel_format, attribs, true);
/* 17:   */     }
/* 18:   */     catch (LWJGLException e) {}
/* 19:51 */     return new MacOSXAWTGLCanvasPeerInfo(component, pixel_format, attribs, false);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public GraphicsConfiguration findConfiguration(GraphicsDevice device, PixelFormat pixel_format)
/* 23:   */     throws LWJGLException
/* 24:   */   {
/* 25:64 */     return null;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXCanvasImplementation
 * JD-Core Version:    0.7.0.1
 */