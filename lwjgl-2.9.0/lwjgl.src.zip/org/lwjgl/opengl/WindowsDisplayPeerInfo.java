/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class WindowsDisplayPeerInfo
/*  7:   */   extends WindowsPeerInfo
/*  8:   */ {
/*  9:   */   final boolean egl;
/* 10:   */   
/* 11:   */   WindowsDisplayPeerInfo(boolean egl)
/* 12:   */     throws LWJGLException
/* 13:   */   {
/* 14:49 */     this.egl = egl;
/* 15:51 */     if (egl) {
/* 16:52 */       org.lwjgl.opengles.GLContext.loadOpenGLLibrary();
/* 17:   */     } else {
/* 18:54 */       GLContext.loadOpenGLLibrary();
/* 19:   */     }
/* 20:   */   }
/* 21:   */   
/* 22:   */   void initDC(long hwnd, long hdc)
/* 23:   */     throws LWJGLException
/* 24:   */   {
/* 25:58 */     nInitDC(getHandle(), hwnd, hdc);
/* 26:   */   }
/* 27:   */   
/* 28:   */   private static native void nInitDC(ByteBuffer paramByteBuffer, long paramLong1, long paramLong2);
/* 29:   */   
/* 30:   */   protected void doLockAndInitHandle()
/* 31:   */     throws LWJGLException
/* 32:   */   {}
/* 33:   */   
/* 34:   */   protected void doUnlock()
/* 35:   */     throws LWJGLException
/* 36:   */   {}
/* 37:   */   
/* 38:   */   public void destroy()
/* 39:   */   {
/* 40:71 */     super.destroy();
/* 41:73 */     if (this.egl) {
/* 42:74 */       org.lwjgl.opengles.GLContext.unloadOpenGLLibrary();
/* 43:   */     } else {
/* 44:76 */       GLContext.unloadOpenGLLibrary();
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsDisplayPeerInfo
 * JD-Core Version:    0.7.0.1
 */