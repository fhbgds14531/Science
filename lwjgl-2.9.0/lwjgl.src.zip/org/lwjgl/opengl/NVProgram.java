/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public class NVProgram
/*   9:    */ {
/*  10:    */   public static final int GL_PROGRAM_TARGET_NV = 34374;
/*  11:    */   public static final int GL_PROGRAM_LENGTH_NV = 34343;
/*  12:    */   public static final int GL_PROGRAM_RESIDENT_NV = 34375;
/*  13:    */   public static final int GL_PROGRAM_STRING_NV = 34344;
/*  14:    */   public static final int GL_PROGRAM_ERROR_POSITION_NV = 34379;
/*  15:    */   public static final int GL_PROGRAM_ERROR_STRING_NV = 34932;
/*  16:    */   
/*  17:    */   public static void glLoadProgramNV(int target, int programID, ByteBuffer string)
/*  18:    */   {
/*  19: 35 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  20: 36 */     long function_pointer = caps.glLoadProgramNV;
/*  21: 37 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  22: 38 */     BufferChecks.checkDirect(string);
/*  23: 39 */     nglLoadProgramNV(target, programID, string.remaining(), MemoryUtil.getAddress(string), function_pointer);
/*  24:    */   }
/*  25:    */   
/*  26:    */   static native void nglLoadProgramNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  27:    */   
/*  28:    */   public static void glLoadProgramNV(int target, int programID, CharSequence string)
/*  29:    */   {
/*  30: 45 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  31: 46 */     long function_pointer = caps.glLoadProgramNV;
/*  32: 47 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  33: 48 */     nglLoadProgramNV(target, programID, string.length(), APIUtil.getBuffer(caps, string), function_pointer);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void glBindProgramNV(int target, int programID)
/*  37:    */   {
/*  38: 52 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  39: 53 */     long function_pointer = caps.glBindProgramNV;
/*  40: 54 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  41: 55 */     nglBindProgramNV(target, programID, function_pointer);
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native void nglBindProgramNV(int paramInt1, int paramInt2, long paramLong);
/*  45:    */   
/*  46:    */   public static void glDeleteProgramsNV(IntBuffer programs)
/*  47:    */   {
/*  48: 60 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  49: 61 */     long function_pointer = caps.glDeleteProgramsNV;
/*  50: 62 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  51: 63 */     BufferChecks.checkDirect(programs);
/*  52: 64 */     nglDeleteProgramsNV(programs.remaining(), MemoryUtil.getAddress(programs), function_pointer);
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native void nglDeleteProgramsNV(int paramInt, long paramLong1, long paramLong2);
/*  56:    */   
/*  57:    */   public static void glDeleteProgramsNV(int program)
/*  58:    */   {
/*  59: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 71 */     long function_pointer = caps.glDeleteProgramsNV;
/*  61: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 73 */     nglDeleteProgramsNV(1, APIUtil.getInt(caps, program), function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glGenProgramsNV(IntBuffer programs)
/*  66:    */   {
/*  67: 77 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  68: 78 */     long function_pointer = caps.glGenProgramsNV;
/*  69: 79 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  70: 80 */     BufferChecks.checkDirect(programs);
/*  71: 81 */     nglGenProgramsNV(programs.remaining(), MemoryUtil.getAddress(programs), function_pointer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static native void nglGenProgramsNV(int paramInt, long paramLong1, long paramLong2);
/*  75:    */   
/*  76:    */   public static int glGenProgramsNV()
/*  77:    */   {
/*  78: 87 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79: 88 */     long function_pointer = caps.glGenProgramsNV;
/*  80: 89 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81: 90 */     IntBuffer programs = APIUtil.getBufferInt(caps);
/*  82: 91 */     nglGenProgramsNV(1, MemoryUtil.getAddress(programs), function_pointer);
/*  83: 92 */     return programs.get(0);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static void glGetProgramNV(int programID, int parameterName, IntBuffer params)
/*  87:    */   {
/*  88: 96 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  89: 97 */     long function_pointer = caps.glGetProgramivNV;
/*  90: 98 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  91: 99 */     BufferChecks.checkDirect(params);
/*  92:100 */     nglGetProgramivNV(programID, parameterName, MemoryUtil.getAddress(params), function_pointer);
/*  93:    */   }
/*  94:    */   
/*  95:    */   static native void nglGetProgramivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  96:    */   
/*  97:    */   @Deprecated
/*  98:    */   public static int glGetProgramNV(int programID, int parameterName)
/*  99:    */   {
/* 100:111 */     return glGetProgramiNV(programID, parameterName);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static int glGetProgramiNV(int programID, int parameterName)
/* 104:    */   {
/* 105:116 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106:117 */     long function_pointer = caps.glGetProgramivNV;
/* 107:118 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108:119 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 109:120 */     nglGetProgramivNV(programID, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 110:121 */     return params.get(0);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void glGetProgramStringNV(int programID, int parameterName, ByteBuffer paramString)
/* 114:    */   {
/* 115:125 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116:126 */     long function_pointer = caps.glGetProgramStringNV;
/* 117:127 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:128 */     BufferChecks.checkDirect(paramString);
/* 119:129 */     nglGetProgramStringNV(programID, parameterName, MemoryUtil.getAddress(paramString), function_pointer);
/* 120:    */   }
/* 121:    */   
/* 122:    */   static native void nglGetProgramStringNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 123:    */   
/* 124:    */   public static String glGetProgramStringNV(int programID, int parameterName)
/* 125:    */   {
/* 126:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:136 */     long function_pointer = caps.glGetProgramStringNV;
/* 128:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:138 */     int programLength = glGetProgramiNV(programID, 34343);
/* 130:139 */     ByteBuffer paramString = APIUtil.getBufferByte(caps, programLength);
/* 131:140 */     nglGetProgramStringNV(programID, parameterName, MemoryUtil.getAddress(paramString), function_pointer);
/* 132:141 */     paramString.limit(programLength);
/* 133:142 */     return APIUtil.getString(caps, paramString);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static boolean glIsProgramNV(int programID)
/* 137:    */   {
/* 138:146 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:147 */     long function_pointer = caps.glIsProgramNV;
/* 140:148 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:149 */     boolean __result = nglIsProgramNV(programID, function_pointer);
/* 142:150 */     return __result;
/* 143:    */   }
/* 144:    */   
/* 145:    */   static native boolean nglIsProgramNV(int paramInt, long paramLong);
/* 146:    */   
/* 147:    */   public static boolean glAreProgramsResidentNV(IntBuffer programIDs, ByteBuffer programResidences)
/* 148:    */   {
/* 149:155 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:156 */     long function_pointer = caps.glAreProgramsResidentNV;
/* 151:157 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:158 */     BufferChecks.checkDirect(programIDs);
/* 153:159 */     BufferChecks.checkBuffer(programResidences, programIDs.remaining());
/* 154:160 */     boolean __result = nglAreProgramsResidentNV(programIDs.remaining(), MemoryUtil.getAddress(programIDs), MemoryUtil.getAddress(programResidences), function_pointer);
/* 155:161 */     return __result;
/* 156:    */   }
/* 157:    */   
/* 158:    */   static native boolean nglAreProgramsResidentNV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 159:    */   
/* 160:    */   public static void glRequestResidentProgramsNV(IntBuffer programIDs)
/* 161:    */   {
/* 162:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 163:167 */     long function_pointer = caps.glRequestResidentProgramsNV;
/* 164:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 165:169 */     BufferChecks.checkDirect(programIDs);
/* 166:170 */     nglRequestResidentProgramsNV(programIDs.remaining(), MemoryUtil.getAddress(programIDs), function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglRequestResidentProgramsNV(int paramInt, long paramLong1, long paramLong2);
/* 170:    */   
/* 171:    */   public static void glRequestResidentProgramsNV(int programID)
/* 172:    */   {
/* 173:176 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:177 */     long function_pointer = caps.glRequestResidentProgramsNV;
/* 175:178 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:179 */     nglRequestResidentProgramsNV(1, APIUtil.getInt(caps, programID), function_pointer);
/* 177:    */   }
/* 178:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVProgram
 * JD-Core Version:    0.7.0.1
 */