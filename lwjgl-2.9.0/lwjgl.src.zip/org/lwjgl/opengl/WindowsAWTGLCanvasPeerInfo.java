/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.nio.ByteBuffer;
/*  5:   */ import org.lwjgl.LWJGLException;
/*  6:   */ 
/*  7:   */ final class WindowsAWTGLCanvasPeerInfo
/*  8:   */   extends WindowsPeerInfo
/*  9:   */ {
/* 10:   */   private final Canvas component;
/* 11:48 */   private final AWTSurfaceLock awt_surface = new AWTSurfaceLock();
/* 12:   */   private final PixelFormat pixel_format;
/* 13:   */   private boolean has_pixel_format;
/* 14:   */   
/* 15:   */   WindowsAWTGLCanvasPeerInfo(Canvas component, PixelFormat pixel_format)
/* 16:   */   {
/* 17:53 */     this.component = component;
/* 18:54 */     this.pixel_format = pixel_format;
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected void doLockAndInitHandle()
/* 22:   */     throws LWJGLException
/* 23:   */   {
/* 24:58 */     nInitHandle(this.awt_surface.lockAndGetHandle(this.component), getHandle());
/* 25:59 */     if ((!this.has_pixel_format) && (this.pixel_format != null))
/* 26:   */     {
/* 27:61 */       int format = choosePixelFormat(getHdc(), this.component.getX(), this.component.getY(), this.pixel_format, null, true, true, false, true);
/* 28:62 */       setPixelFormat(getHdc(), format);
/* 29:63 */       this.has_pixel_format = true;
/* 30:   */     }
/* 31:   */   }
/* 32:   */   
/* 33:   */   private static native void nInitHandle(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/* 34:   */     throws LWJGLException;
/* 35:   */   
/* 36:   */   protected void doUnlock()
/* 37:   */     throws LWJGLException
/* 38:   */   {
/* 39:69 */     this.awt_surface.unlock();
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsAWTGLCanvasPeerInfo
 * JD-Core Version:    0.7.0.1
 */