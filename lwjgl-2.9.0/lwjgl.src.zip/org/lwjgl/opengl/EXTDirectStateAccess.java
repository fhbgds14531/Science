/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.ByteOrder;
/*    5:     */ import java.nio.DoubleBuffer;
/*    6:     */ import java.nio.FloatBuffer;
/*    7:     */ import java.nio.IntBuffer;
/*    8:     */ import java.nio.ShortBuffer;
/*    9:     */ import org.lwjgl.BufferChecks;
/*   10:     */ import org.lwjgl.LWJGLUtil;
/*   11:     */ import org.lwjgl.MemoryUtil;
/*   12:     */ 
/*   13:     */ public final class EXTDirectStateAccess
/*   14:     */ {
/*   15:     */   public static final int GL_PROGRAM_MATRIX_EXT = 36397;
/*   16:     */   public static final int GL_TRANSPOSE_PROGRAM_MATRIX_EXT = 36398;
/*   17:     */   public static final int GL_PROGRAM_MATRIX_STACK_DEPTH_EXT = 36399;
/*   18:     */   
/*   19:     */   public static void glClientAttribDefaultEXT(int mask)
/*   20:     */   {
/*   21:  22 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   22:  23 */     long function_pointer = caps.glClientAttribDefaultEXT;
/*   23:  24 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   24:  25 */     nglClientAttribDefaultEXT(mask, function_pointer);
/*   25:     */   }
/*   26:     */   
/*   27:     */   static native void nglClientAttribDefaultEXT(int paramInt, long paramLong);
/*   28:     */   
/*   29:     */   public static void glPushClientAttribDefaultEXT(int mask)
/*   30:     */   {
/*   31:  30 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   32:  31 */     long function_pointer = caps.glPushClientAttribDefaultEXT;
/*   33:  32 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   34:  33 */     nglPushClientAttribDefaultEXT(mask, function_pointer);
/*   35:     */   }
/*   36:     */   
/*   37:     */   static native void nglPushClientAttribDefaultEXT(int paramInt, long paramLong);
/*   38:     */   
/*   39:     */   public static void glMatrixLoadEXT(int matrixMode, FloatBuffer m)
/*   40:     */   {
/*   41:  38 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   42:  39 */     long function_pointer = caps.glMatrixLoadfEXT;
/*   43:  40 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   44:  41 */     BufferChecks.checkBuffer(m, 16);
/*   45:  42 */     nglMatrixLoadfEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/*   46:     */   }
/*   47:     */   
/*   48:     */   static native void nglMatrixLoadfEXT(int paramInt, long paramLong1, long paramLong2);
/*   49:     */   
/*   50:     */   public static void glMatrixLoadEXT(int matrixMode, DoubleBuffer m)
/*   51:     */   {
/*   52:  47 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   53:  48 */     long function_pointer = caps.glMatrixLoaddEXT;
/*   54:  49 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   55:  50 */     BufferChecks.checkBuffer(m, 16);
/*   56:  51 */     nglMatrixLoaddEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/*   57:     */   }
/*   58:     */   
/*   59:     */   static native void nglMatrixLoaddEXT(int paramInt, long paramLong1, long paramLong2);
/*   60:     */   
/*   61:     */   public static void glMatrixMultEXT(int matrixMode, FloatBuffer m)
/*   62:     */   {
/*   63:  56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   64:  57 */     long function_pointer = caps.glMatrixMultfEXT;
/*   65:  58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   66:  59 */     BufferChecks.checkBuffer(m, 16);
/*   67:  60 */     nglMatrixMultfEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/*   68:     */   }
/*   69:     */   
/*   70:     */   static native void nglMatrixMultfEXT(int paramInt, long paramLong1, long paramLong2);
/*   71:     */   
/*   72:     */   public static void glMatrixMultEXT(int matrixMode, DoubleBuffer m)
/*   73:     */   {
/*   74:  65 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   75:  66 */     long function_pointer = caps.glMatrixMultdEXT;
/*   76:  67 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   77:  68 */     BufferChecks.checkBuffer(m, 16);
/*   78:  69 */     nglMatrixMultdEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/*   79:     */   }
/*   80:     */   
/*   81:     */   static native void nglMatrixMultdEXT(int paramInt, long paramLong1, long paramLong2);
/*   82:     */   
/*   83:     */   public static void glMatrixLoadIdentityEXT(int matrixMode)
/*   84:     */   {
/*   85:  74 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   86:  75 */     long function_pointer = caps.glMatrixLoadIdentityEXT;
/*   87:  76 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   88:  77 */     nglMatrixLoadIdentityEXT(matrixMode, function_pointer);
/*   89:     */   }
/*   90:     */   
/*   91:     */   static native void nglMatrixLoadIdentityEXT(int paramInt, long paramLong);
/*   92:     */   
/*   93:     */   public static void glMatrixRotatefEXT(int matrixMode, float angle, float x, float y, float z)
/*   94:     */   {
/*   95:  82 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   96:  83 */     long function_pointer = caps.glMatrixRotatefEXT;
/*   97:  84 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   98:  85 */     nglMatrixRotatefEXT(matrixMode, angle, x, y, z, function_pointer);
/*   99:     */   }
/*  100:     */   
/*  101:     */   static native void nglMatrixRotatefEXT(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  102:     */   
/*  103:     */   public static void glMatrixRotatedEXT(int matrixMode, double angle, double x, double y, double z)
/*  104:     */   {
/*  105:  90 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  106:  91 */     long function_pointer = caps.glMatrixRotatedEXT;
/*  107:  92 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  108:  93 */     nglMatrixRotatedEXT(matrixMode, angle, x, y, z, function_pointer);
/*  109:     */   }
/*  110:     */   
/*  111:     */   static native void nglMatrixRotatedEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  112:     */   
/*  113:     */   public static void glMatrixScalefEXT(int matrixMode, float x, float y, float z)
/*  114:     */   {
/*  115:  98 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  116:  99 */     long function_pointer = caps.glMatrixScalefEXT;
/*  117: 100 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  118: 101 */     nglMatrixScalefEXT(matrixMode, x, y, z, function_pointer);
/*  119:     */   }
/*  120:     */   
/*  121:     */   static native void nglMatrixScalefEXT(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  122:     */   
/*  123:     */   public static void glMatrixScaledEXT(int matrixMode, double x, double y, double z)
/*  124:     */   {
/*  125: 106 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  126: 107 */     long function_pointer = caps.glMatrixScaledEXT;
/*  127: 108 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  128: 109 */     nglMatrixScaledEXT(matrixMode, x, y, z, function_pointer);
/*  129:     */   }
/*  130:     */   
/*  131:     */   static native void nglMatrixScaledEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  132:     */   
/*  133:     */   public static void glMatrixTranslatefEXT(int matrixMode, float x, float y, float z)
/*  134:     */   {
/*  135: 114 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  136: 115 */     long function_pointer = caps.glMatrixTranslatefEXT;
/*  137: 116 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  138: 117 */     nglMatrixTranslatefEXT(matrixMode, x, y, z, function_pointer);
/*  139:     */   }
/*  140:     */   
/*  141:     */   static native void nglMatrixTranslatefEXT(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  142:     */   
/*  143:     */   public static void glMatrixTranslatedEXT(int matrixMode, double x, double y, double z)
/*  144:     */   {
/*  145: 122 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  146: 123 */     long function_pointer = caps.glMatrixTranslatedEXT;
/*  147: 124 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  148: 125 */     nglMatrixTranslatedEXT(matrixMode, x, y, z, function_pointer);
/*  149:     */   }
/*  150:     */   
/*  151:     */   static native void nglMatrixTranslatedEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  152:     */   
/*  153:     */   public static void glMatrixOrthoEXT(int matrixMode, double l, double r, double b, double t, double n, double f)
/*  154:     */   {
/*  155: 130 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  156: 131 */     long function_pointer = caps.glMatrixOrthoEXT;
/*  157: 132 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  158: 133 */     nglMatrixOrthoEXT(matrixMode, l, r, b, t, n, f, function_pointer);
/*  159:     */   }
/*  160:     */   
/*  161:     */   static native void nglMatrixOrthoEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, long paramLong);
/*  162:     */   
/*  163:     */   public static void glMatrixFrustumEXT(int matrixMode, double l, double r, double b, double t, double n, double f)
/*  164:     */   {
/*  165: 138 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  166: 139 */     long function_pointer = caps.glMatrixFrustumEXT;
/*  167: 140 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  168: 141 */     nglMatrixFrustumEXT(matrixMode, l, r, b, t, n, f, function_pointer);
/*  169:     */   }
/*  170:     */   
/*  171:     */   static native void nglMatrixFrustumEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, long paramLong);
/*  172:     */   
/*  173:     */   public static void glMatrixPushEXT(int matrixMode)
/*  174:     */   {
/*  175: 146 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  176: 147 */     long function_pointer = caps.glMatrixPushEXT;
/*  177: 148 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  178: 149 */     nglMatrixPushEXT(matrixMode, function_pointer);
/*  179:     */   }
/*  180:     */   
/*  181:     */   static native void nglMatrixPushEXT(int paramInt, long paramLong);
/*  182:     */   
/*  183:     */   public static void glMatrixPopEXT(int matrixMode)
/*  184:     */   {
/*  185: 154 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  186: 155 */     long function_pointer = caps.glMatrixPopEXT;
/*  187: 156 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  188: 157 */     nglMatrixPopEXT(matrixMode, function_pointer);
/*  189:     */   }
/*  190:     */   
/*  191:     */   static native void nglMatrixPopEXT(int paramInt, long paramLong);
/*  192:     */   
/*  193:     */   public static void glTextureParameteriEXT(int texture, int target, int pname, int param)
/*  194:     */   {
/*  195: 162 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  196: 163 */     long function_pointer = caps.glTextureParameteriEXT;
/*  197: 164 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  198: 165 */     nglTextureParameteriEXT(texture, target, pname, param, function_pointer);
/*  199:     */   }
/*  200:     */   
/*  201:     */   static native void nglTextureParameteriEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  202:     */   
/*  203:     */   public static void glTextureParameterEXT(int texture, int target, int pname, IntBuffer param)
/*  204:     */   {
/*  205: 170 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  206: 171 */     long function_pointer = caps.glTextureParameterivEXT;
/*  207: 172 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  208: 173 */     BufferChecks.checkBuffer(param, 4);
/*  209: 174 */     nglTextureParameterivEXT(texture, target, pname, MemoryUtil.getAddress(param), function_pointer);
/*  210:     */   }
/*  211:     */   
/*  212:     */   static native void nglTextureParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  213:     */   
/*  214:     */   public static void glTextureParameterfEXT(int texture, int target, int pname, float param)
/*  215:     */   {
/*  216: 179 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  217: 180 */     long function_pointer = caps.glTextureParameterfEXT;
/*  218: 181 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  219: 182 */     nglTextureParameterfEXT(texture, target, pname, param, function_pointer);
/*  220:     */   }
/*  221:     */   
/*  222:     */   static native void nglTextureParameterfEXT(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong);
/*  223:     */   
/*  224:     */   public static void glTextureParameterEXT(int texture, int target, int pname, FloatBuffer param)
/*  225:     */   {
/*  226: 187 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  227: 188 */     long function_pointer = caps.glTextureParameterfvEXT;
/*  228: 189 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  229: 190 */     BufferChecks.checkBuffer(param, 4);
/*  230: 191 */     nglTextureParameterfvEXT(texture, target, pname, MemoryUtil.getAddress(param), function_pointer);
/*  231:     */   }
/*  232:     */   
/*  233:     */   static native void nglTextureParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  234:     */   
/*  235:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, ByteBuffer pixels)
/*  236:     */   {
/*  237: 196 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  238: 197 */     long function_pointer = caps.glTextureImage1DEXT;
/*  239: 198 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  240: 199 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  241: 200 */     if (pixels != null) {
/*  242: 201 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/*  243:     */     }
/*  244: 202 */     nglTextureImage1DEXT(texture, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  245:     */   }
/*  246:     */   
/*  247:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, DoubleBuffer pixels)
/*  248:     */   {
/*  249: 205 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  250: 206 */     long function_pointer = caps.glTextureImage1DEXT;
/*  251: 207 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  252: 208 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  253: 209 */     if (pixels != null) {
/*  254: 210 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/*  255:     */     }
/*  256: 211 */     nglTextureImage1DEXT(texture, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  257:     */   }
/*  258:     */   
/*  259:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, FloatBuffer pixels)
/*  260:     */   {
/*  261: 214 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  262: 215 */     long function_pointer = caps.glTextureImage1DEXT;
/*  263: 216 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  264: 217 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  265: 218 */     if (pixels != null) {
/*  266: 219 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/*  267:     */     }
/*  268: 220 */     nglTextureImage1DEXT(texture, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  269:     */   }
/*  270:     */   
/*  271:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, IntBuffer pixels)
/*  272:     */   {
/*  273: 223 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  274: 224 */     long function_pointer = caps.glTextureImage1DEXT;
/*  275: 225 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  276: 226 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  277: 227 */     if (pixels != null) {
/*  278: 228 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/*  279:     */     }
/*  280: 229 */     nglTextureImage1DEXT(texture, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  281:     */   }
/*  282:     */   
/*  283:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, ShortBuffer pixels)
/*  284:     */   {
/*  285: 232 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  286: 233 */     long function_pointer = caps.glTextureImage1DEXT;
/*  287: 234 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  288: 235 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  289: 236 */     if (pixels != null) {
/*  290: 237 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/*  291:     */     }
/*  292: 238 */     nglTextureImage1DEXT(texture, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  293:     */   }
/*  294:     */   
/*  295:     */   static native void nglTextureImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/*  296:     */   
/*  297:     */   public static void glTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int format, int type, long pixels_buffer_offset)
/*  298:     */   {
/*  299: 242 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  300: 243 */     long function_pointer = caps.glTextureImage1DEXT;
/*  301: 244 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  302: 245 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  303: 246 */     nglTextureImage1DEXTBO(texture, target, level, internalformat, width, border, format, type, pixels_buffer_offset, function_pointer);
/*  304:     */   }
/*  305:     */   
/*  306:     */   static native void nglTextureImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/*  307:     */   
/*  308:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, ByteBuffer pixels)
/*  309:     */   {
/*  310: 251 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  311: 252 */     long function_pointer = caps.glTextureImage2DEXT;
/*  312: 253 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  313: 254 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  314: 255 */     if (pixels != null) {
/*  315: 256 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/*  316:     */     }
/*  317: 257 */     nglTextureImage2DEXT(texture, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  318:     */   }
/*  319:     */   
/*  320:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, DoubleBuffer pixels)
/*  321:     */   {
/*  322: 260 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  323: 261 */     long function_pointer = caps.glTextureImage2DEXT;
/*  324: 262 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  325: 263 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  326: 264 */     if (pixels != null) {
/*  327: 265 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/*  328:     */     }
/*  329: 266 */     nglTextureImage2DEXT(texture, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  330:     */   }
/*  331:     */   
/*  332:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, FloatBuffer pixels)
/*  333:     */   {
/*  334: 269 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  335: 270 */     long function_pointer = caps.glTextureImage2DEXT;
/*  336: 271 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  337: 272 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  338: 273 */     if (pixels != null) {
/*  339: 274 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/*  340:     */     }
/*  341: 275 */     nglTextureImage2DEXT(texture, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  342:     */   }
/*  343:     */   
/*  344:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, IntBuffer pixels)
/*  345:     */   {
/*  346: 278 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  347: 279 */     long function_pointer = caps.glTextureImage2DEXT;
/*  348: 280 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  349: 281 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  350: 282 */     if (pixels != null) {
/*  351: 283 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/*  352:     */     }
/*  353: 284 */     nglTextureImage2DEXT(texture, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  354:     */   }
/*  355:     */   
/*  356:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, ShortBuffer pixels)
/*  357:     */   {
/*  358: 287 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  359: 288 */     long function_pointer = caps.glTextureImage2DEXT;
/*  360: 289 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  361: 290 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  362: 291 */     if (pixels != null) {
/*  363: 292 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/*  364:     */     }
/*  365: 293 */     nglTextureImage2DEXT(texture, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  366:     */   }
/*  367:     */   
/*  368:     */   static native void nglTextureImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/*  369:     */   
/*  370:     */   public static void glTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int format, int type, long pixels_buffer_offset)
/*  371:     */   {
/*  372: 297 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  373: 298 */     long function_pointer = caps.glTextureImage2DEXT;
/*  374: 299 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  375: 300 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  376: 301 */     nglTextureImage2DEXTBO(texture, target, level, internalformat, width, height, border, format, type, pixels_buffer_offset, function_pointer);
/*  377:     */   }
/*  378:     */   
/*  379:     */   static native void nglTextureImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/*  380:     */   
/*  381:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, ByteBuffer pixels)
/*  382:     */   {
/*  383: 306 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  384: 307 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  385: 308 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  386: 309 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  387: 310 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/*  388: 311 */     nglTextureSubImage1DEXT(texture, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  389:     */   }
/*  390:     */   
/*  391:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, DoubleBuffer pixels)
/*  392:     */   {
/*  393: 314 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  394: 315 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  395: 316 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  396: 317 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  397: 318 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/*  398: 319 */     nglTextureSubImage1DEXT(texture, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  399:     */   }
/*  400:     */   
/*  401:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, FloatBuffer pixels)
/*  402:     */   {
/*  403: 322 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  404: 323 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  405: 324 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  406: 325 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  407: 326 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/*  408: 327 */     nglTextureSubImage1DEXT(texture, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  409:     */   }
/*  410:     */   
/*  411:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, IntBuffer pixels)
/*  412:     */   {
/*  413: 330 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  414: 331 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  415: 332 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  416: 333 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  417: 334 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/*  418: 335 */     nglTextureSubImage1DEXT(texture, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  419:     */   }
/*  420:     */   
/*  421:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, ShortBuffer pixels)
/*  422:     */   {
/*  423: 338 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  424: 339 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  425: 340 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  426: 341 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  427: 342 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/*  428: 343 */     nglTextureSubImage1DEXT(texture, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  429:     */   }
/*  430:     */   
/*  431:     */   static native void nglTextureSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  432:     */   
/*  433:     */   public static void glTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int type, long pixels_buffer_offset)
/*  434:     */   {
/*  435: 347 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  436: 348 */     long function_pointer = caps.glTextureSubImage1DEXT;
/*  437: 349 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  438: 350 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  439: 351 */     nglTextureSubImage1DEXTBO(texture, target, level, xoffset, width, format, type, pixels_buffer_offset, function_pointer);
/*  440:     */   }
/*  441:     */   
/*  442:     */   static native void nglTextureSubImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  443:     */   
/*  444:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ByteBuffer pixels)
/*  445:     */   {
/*  446: 356 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  447: 357 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  448: 358 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  449: 359 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  450: 360 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/*  451: 361 */     nglTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  452:     */   }
/*  453:     */   
/*  454:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, DoubleBuffer pixels)
/*  455:     */   {
/*  456: 364 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  457: 365 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  458: 366 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  459: 367 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  460: 368 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/*  461: 369 */     nglTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  462:     */   }
/*  463:     */   
/*  464:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, FloatBuffer pixels)
/*  465:     */   {
/*  466: 372 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  467: 373 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  468: 374 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  469: 375 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  470: 376 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/*  471: 377 */     nglTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  472:     */   }
/*  473:     */   
/*  474:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, IntBuffer pixels)
/*  475:     */   {
/*  476: 380 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  477: 381 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  478: 382 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  479: 383 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  480: 384 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/*  481: 385 */     nglTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  482:     */   }
/*  483:     */   
/*  484:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ShortBuffer pixels)
/*  485:     */   {
/*  486: 388 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  487: 389 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  488: 390 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  489: 391 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  490: 392 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/*  491: 393 */     nglTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  492:     */   }
/*  493:     */   
/*  494:     */   static native void nglTextureSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/*  495:     */   
/*  496:     */   public static void glTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, long pixels_buffer_offset)
/*  497:     */   {
/*  498: 397 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  499: 398 */     long function_pointer = caps.glTextureSubImage2DEXT;
/*  500: 399 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  501: 400 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  502: 401 */     nglTextureSubImage2DEXTBO(texture, target, level, xoffset, yoffset, width, height, format, type, pixels_buffer_offset, function_pointer);
/*  503:     */   }
/*  504:     */   
/*  505:     */   static native void nglTextureSubImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/*  506:     */   
/*  507:     */   public static void glCopyTextureImage1DEXT(int texture, int target, int level, int internalformat, int x, int y, int width, int border)
/*  508:     */   {
/*  509: 406 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  510: 407 */     long function_pointer = caps.glCopyTextureImage1DEXT;
/*  511: 408 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  512: 409 */     nglCopyTextureImage1DEXT(texture, target, level, internalformat, x, y, width, border, function_pointer);
/*  513:     */   }
/*  514:     */   
/*  515:     */   static native void nglCopyTextureImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/*  516:     */   
/*  517:     */   public static void glCopyTextureImage2DEXT(int texture, int target, int level, int internalformat, int x, int y, int width, int height, int border)
/*  518:     */   {
/*  519: 414 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  520: 415 */     long function_pointer = caps.glCopyTextureImage2DEXT;
/*  521: 416 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  522: 417 */     nglCopyTextureImage2DEXT(texture, target, level, internalformat, x, y, width, height, border, function_pointer);
/*  523:     */   }
/*  524:     */   
/*  525:     */   static native void nglCopyTextureImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong);
/*  526:     */   
/*  527:     */   public static void glCopyTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int x, int y, int width)
/*  528:     */   {
/*  529: 422 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  530: 423 */     long function_pointer = caps.glCopyTextureSubImage1DEXT;
/*  531: 424 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  532: 425 */     nglCopyTextureSubImage1DEXT(texture, target, level, xoffset, x, y, width, function_pointer);
/*  533:     */   }
/*  534:     */   
/*  535:     */   static native void nglCopyTextureSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/*  536:     */   
/*  537:     */   public static void glCopyTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int x, int y, int width, int height)
/*  538:     */   {
/*  539: 430 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  540: 431 */     long function_pointer = caps.glCopyTextureSubImage2DEXT;
/*  541: 432 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  542: 433 */     nglCopyTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, x, y, width, height, function_pointer);
/*  543:     */   }
/*  544:     */   
/*  545:     */   static native void nglCopyTextureSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong);
/*  546:     */   
/*  547:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, ByteBuffer pixels)
/*  548:     */   {
/*  549: 438 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  550: 439 */     long function_pointer = caps.glGetTextureImageEXT;
/*  551: 440 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  552: 441 */     GLChecks.ensurePackPBOdisabled(caps);
/*  553: 442 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/*  554: 443 */     nglGetTextureImageEXT(texture, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  555:     */   }
/*  556:     */   
/*  557:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, DoubleBuffer pixels)
/*  558:     */   {
/*  559: 446 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  560: 447 */     long function_pointer = caps.glGetTextureImageEXT;
/*  561: 448 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  562: 449 */     GLChecks.ensurePackPBOdisabled(caps);
/*  563: 450 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/*  564: 451 */     nglGetTextureImageEXT(texture, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  565:     */   }
/*  566:     */   
/*  567:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, FloatBuffer pixels)
/*  568:     */   {
/*  569: 454 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  570: 455 */     long function_pointer = caps.glGetTextureImageEXT;
/*  571: 456 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  572: 457 */     GLChecks.ensurePackPBOdisabled(caps);
/*  573: 458 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/*  574: 459 */     nglGetTextureImageEXT(texture, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  575:     */   }
/*  576:     */   
/*  577:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, IntBuffer pixels)
/*  578:     */   {
/*  579: 462 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  580: 463 */     long function_pointer = caps.glGetTextureImageEXT;
/*  581: 464 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  582: 465 */     GLChecks.ensurePackPBOdisabled(caps);
/*  583: 466 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/*  584: 467 */     nglGetTextureImageEXT(texture, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  585:     */   }
/*  586:     */   
/*  587:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, ShortBuffer pixels)
/*  588:     */   {
/*  589: 470 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  590: 471 */     long function_pointer = caps.glGetTextureImageEXT;
/*  591: 472 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  592: 473 */     GLChecks.ensurePackPBOdisabled(caps);
/*  593: 474 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/*  594: 475 */     nglGetTextureImageEXT(texture, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  595:     */   }
/*  596:     */   
/*  597:     */   static native void nglGetTextureImageEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  598:     */   
/*  599:     */   public static void glGetTextureImageEXT(int texture, int target, int level, int format, int type, long pixels_buffer_offset)
/*  600:     */   {
/*  601: 479 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  602: 480 */     long function_pointer = caps.glGetTextureImageEXT;
/*  603: 481 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  604: 482 */     GLChecks.ensurePackPBOenabled(caps);
/*  605: 483 */     nglGetTextureImageEXTBO(texture, target, level, format, type, pixels_buffer_offset, function_pointer);
/*  606:     */   }
/*  607:     */   
/*  608:     */   static native void nglGetTextureImageEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  609:     */   
/*  610:     */   public static void glGetTextureParameterEXT(int texture, int target, int pname, FloatBuffer params)
/*  611:     */   {
/*  612: 488 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  613: 489 */     long function_pointer = caps.glGetTextureParameterfvEXT;
/*  614: 490 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  615: 491 */     BufferChecks.checkBuffer(params, 4);
/*  616: 492 */     nglGetTextureParameterfvEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  617:     */   }
/*  618:     */   
/*  619:     */   static native void nglGetTextureParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  620:     */   
/*  621:     */   public static float glGetTextureParameterfEXT(int texture, int target, int pname)
/*  622:     */   {
/*  623: 498 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  624: 499 */     long function_pointer = caps.glGetTextureParameterfvEXT;
/*  625: 500 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  626: 501 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/*  627: 502 */     nglGetTextureParameterfvEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  628: 503 */     return params.get(0);
/*  629:     */   }
/*  630:     */   
/*  631:     */   public static void glGetTextureParameterEXT(int texture, int target, int pname, IntBuffer params)
/*  632:     */   {
/*  633: 507 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  634: 508 */     long function_pointer = caps.glGetTextureParameterivEXT;
/*  635: 509 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  636: 510 */     BufferChecks.checkBuffer(params, 4);
/*  637: 511 */     nglGetTextureParameterivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  638:     */   }
/*  639:     */   
/*  640:     */   static native void nglGetTextureParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  641:     */   
/*  642:     */   public static int glGetTextureParameteriEXT(int texture, int target, int pname)
/*  643:     */   {
/*  644: 517 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  645: 518 */     long function_pointer = caps.glGetTextureParameterivEXT;
/*  646: 519 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  647: 520 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  648: 521 */     nglGetTextureParameterivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  649: 522 */     return params.get(0);
/*  650:     */   }
/*  651:     */   
/*  652:     */   public static void glGetTextureLevelParameterEXT(int texture, int target, int level, int pname, FloatBuffer params)
/*  653:     */   {
/*  654: 526 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  655: 527 */     long function_pointer = caps.glGetTextureLevelParameterfvEXT;
/*  656: 528 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  657: 529 */     BufferChecks.checkBuffer(params, 4);
/*  658: 530 */     nglGetTextureLevelParameterfvEXT(texture, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/*  659:     */   }
/*  660:     */   
/*  661:     */   static native void nglGetTextureLevelParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  662:     */   
/*  663:     */   public static float glGetTextureLevelParameterfEXT(int texture, int target, int level, int pname)
/*  664:     */   {
/*  665: 536 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  666: 537 */     long function_pointer = caps.glGetTextureLevelParameterfvEXT;
/*  667: 538 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  668: 539 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/*  669: 540 */     nglGetTextureLevelParameterfvEXT(texture, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/*  670: 541 */     return params.get(0);
/*  671:     */   }
/*  672:     */   
/*  673:     */   public static void glGetTextureLevelParameterEXT(int texture, int target, int level, int pname, IntBuffer params)
/*  674:     */   {
/*  675: 545 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  676: 546 */     long function_pointer = caps.glGetTextureLevelParameterivEXT;
/*  677: 547 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  678: 548 */     BufferChecks.checkBuffer(params, 4);
/*  679: 549 */     nglGetTextureLevelParameterivEXT(texture, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/*  680:     */   }
/*  681:     */   
/*  682:     */   static native void nglGetTextureLevelParameterivEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  683:     */   
/*  684:     */   public static int glGetTextureLevelParameteriEXT(int texture, int target, int level, int pname)
/*  685:     */   {
/*  686: 555 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  687: 556 */     long function_pointer = caps.glGetTextureLevelParameterivEXT;
/*  688: 557 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  689: 558 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  690: 559 */     nglGetTextureLevelParameterivEXT(texture, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/*  691: 560 */     return params.get(0);
/*  692:     */   }
/*  693:     */   
/*  694:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, ByteBuffer pixels)
/*  695:     */   {
/*  696: 564 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  697: 565 */     long function_pointer = caps.glTextureImage3DEXT;
/*  698: 566 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  699: 567 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  700: 568 */     if (pixels != null) {
/*  701: 569 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/*  702:     */     }
/*  703: 570 */     nglTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  704:     */   }
/*  705:     */   
/*  706:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, DoubleBuffer pixels)
/*  707:     */   {
/*  708: 573 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  709: 574 */     long function_pointer = caps.glTextureImage3DEXT;
/*  710: 575 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  711: 576 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  712: 577 */     if (pixels != null) {
/*  713: 578 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/*  714:     */     }
/*  715: 579 */     nglTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  716:     */   }
/*  717:     */   
/*  718:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, FloatBuffer pixels)
/*  719:     */   {
/*  720: 582 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  721: 583 */     long function_pointer = caps.glTextureImage3DEXT;
/*  722: 584 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  723: 585 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  724: 586 */     if (pixels != null) {
/*  725: 587 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/*  726:     */     }
/*  727: 588 */     nglTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  728:     */   }
/*  729:     */   
/*  730:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, IntBuffer pixels)
/*  731:     */   {
/*  732: 591 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  733: 592 */     long function_pointer = caps.glTextureImage3DEXT;
/*  734: 593 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  735: 594 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  736: 595 */     if (pixels != null) {
/*  737: 596 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/*  738:     */     }
/*  739: 597 */     nglTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  740:     */   }
/*  741:     */   
/*  742:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, ShortBuffer pixels)
/*  743:     */   {
/*  744: 600 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  745: 601 */     long function_pointer = caps.glTextureImage3DEXT;
/*  746: 602 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  747: 603 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  748: 604 */     if (pixels != null) {
/*  749: 605 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/*  750:     */     }
/*  751: 606 */     nglTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/*  752:     */   }
/*  753:     */   
/*  754:     */   static native void nglTextureImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/*  755:     */   
/*  756:     */   public static void glTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, long pixels_buffer_offset)
/*  757:     */   {
/*  758: 610 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  759: 611 */     long function_pointer = caps.glTextureImage3DEXT;
/*  760: 612 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  761: 613 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  762: 614 */     nglTextureImage3DEXTBO(texture, target, level, internalformat, width, height, depth, border, format, type, pixels_buffer_offset, function_pointer);
/*  763:     */   }
/*  764:     */   
/*  765:     */   static native void nglTextureImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/*  766:     */   
/*  767:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ByteBuffer pixels)
/*  768:     */   {
/*  769: 619 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  770: 620 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  771: 621 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  772: 622 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  773: 623 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/*  774: 624 */     nglTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  775:     */   }
/*  776:     */   
/*  777:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, DoubleBuffer pixels)
/*  778:     */   {
/*  779: 627 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  780: 628 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  781: 629 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  782: 630 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  783: 631 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/*  784: 632 */     nglTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  785:     */   }
/*  786:     */   
/*  787:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, FloatBuffer pixels)
/*  788:     */   {
/*  789: 635 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  790: 636 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  791: 637 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  792: 638 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  793: 639 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/*  794: 640 */     nglTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  795:     */   }
/*  796:     */   
/*  797:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, IntBuffer pixels)
/*  798:     */   {
/*  799: 643 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  800: 644 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  801: 645 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  802: 646 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  803: 647 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/*  804: 648 */     nglTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  805:     */   }
/*  806:     */   
/*  807:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ShortBuffer pixels)
/*  808:     */   {
/*  809: 651 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  810: 652 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  811: 653 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  812: 654 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  813: 655 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/*  814: 656 */     nglTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/*  815:     */   }
/*  816:     */   
/*  817:     */   static native void nglTextureSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/*  818:     */   
/*  819:     */   public static void glTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, long pixels_buffer_offset)
/*  820:     */   {
/*  821: 660 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  822: 661 */     long function_pointer = caps.glTextureSubImage3DEXT;
/*  823: 662 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  824: 663 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  825: 664 */     nglTextureSubImage3DEXTBO(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels_buffer_offset, function_pointer);
/*  826:     */   }
/*  827:     */   
/*  828:     */   static native void nglTextureSubImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/*  829:     */   
/*  830:     */   public static void glCopyTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int x, int y, int width, int height)
/*  831:     */   {
/*  832: 669 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  833: 670 */     long function_pointer = caps.glCopyTextureSubImage3DEXT;
/*  834: 671 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  835: 672 */     nglCopyTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, x, y, width, height, function_pointer);
/*  836:     */   }
/*  837:     */   
/*  838:     */   static native void nglCopyTextureSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong);
/*  839:     */   
/*  840:     */   public static void glBindMultiTextureEXT(int texunit, int target, int texture)
/*  841:     */   {
/*  842: 677 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  843: 678 */     long function_pointer = caps.glBindMultiTextureEXT;
/*  844: 679 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  845: 680 */     nglBindMultiTextureEXT(texunit, target, texture, function_pointer);
/*  846:     */   }
/*  847:     */   
/*  848:     */   static native void nglBindMultiTextureEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  849:     */   
/*  850:     */   public static void glMultiTexCoordPointerEXT(int texunit, int size, int stride, DoubleBuffer pointer)
/*  851:     */   {
/*  852: 685 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  853: 686 */     long function_pointer = caps.glMultiTexCoordPointerEXT;
/*  854: 687 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  855: 688 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  856: 689 */     BufferChecks.checkDirect(pointer);
/*  857: 690 */     nglMultiTexCoordPointerEXT(texunit, size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  858:     */   }
/*  859:     */   
/*  860:     */   public static void glMultiTexCoordPointerEXT(int texunit, int size, int stride, FloatBuffer pointer)
/*  861:     */   {
/*  862: 693 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  863: 694 */     long function_pointer = caps.glMultiTexCoordPointerEXT;
/*  864: 695 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  865: 696 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  866: 697 */     BufferChecks.checkDirect(pointer);
/*  867: 698 */     nglMultiTexCoordPointerEXT(texunit, size, 5126, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  868:     */   }
/*  869:     */   
/*  870:     */   static native void nglMultiTexCoordPointerEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  871:     */   
/*  872:     */   public static void glMultiTexCoordPointerEXT(int texunit, int size, int type, int stride, long pointer_buffer_offset)
/*  873:     */   {
/*  874: 702 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  875: 703 */     long function_pointer = caps.glMultiTexCoordPointerEXT;
/*  876: 704 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  877: 705 */     GLChecks.ensureArrayVBOenabled(caps);
/*  878: 706 */     nglMultiTexCoordPointerEXTBO(texunit, size, type, stride, pointer_buffer_offset, function_pointer);
/*  879:     */   }
/*  880:     */   
/*  881:     */   static native void nglMultiTexCoordPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  882:     */   
/*  883:     */   public static void glMultiTexEnvfEXT(int texunit, int target, int pname, float param)
/*  884:     */   {
/*  885: 711 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  886: 712 */     long function_pointer = caps.glMultiTexEnvfEXT;
/*  887: 713 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  888: 714 */     nglMultiTexEnvfEXT(texunit, target, pname, param, function_pointer);
/*  889:     */   }
/*  890:     */   
/*  891:     */   static native void nglMultiTexEnvfEXT(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong);
/*  892:     */   
/*  893:     */   public static void glMultiTexEnvEXT(int texunit, int target, int pname, FloatBuffer params)
/*  894:     */   {
/*  895: 719 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  896: 720 */     long function_pointer = caps.glMultiTexEnvfvEXT;
/*  897: 721 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  898: 722 */     BufferChecks.checkBuffer(params, 4);
/*  899: 723 */     nglMultiTexEnvfvEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  900:     */   }
/*  901:     */   
/*  902:     */   static native void nglMultiTexEnvfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  903:     */   
/*  904:     */   public static void glMultiTexEnviEXT(int texunit, int target, int pname, int param)
/*  905:     */   {
/*  906: 728 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  907: 729 */     long function_pointer = caps.glMultiTexEnviEXT;
/*  908: 730 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  909: 731 */     nglMultiTexEnviEXT(texunit, target, pname, param, function_pointer);
/*  910:     */   }
/*  911:     */   
/*  912:     */   static native void nglMultiTexEnviEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  913:     */   
/*  914:     */   public static void glMultiTexEnvEXT(int texunit, int target, int pname, IntBuffer params)
/*  915:     */   {
/*  916: 736 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  917: 737 */     long function_pointer = caps.glMultiTexEnvivEXT;
/*  918: 738 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  919: 739 */     BufferChecks.checkBuffer(params, 4);
/*  920: 740 */     nglMultiTexEnvivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  921:     */   }
/*  922:     */   
/*  923:     */   static native void nglMultiTexEnvivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  924:     */   
/*  925:     */   public static void glMultiTexGendEXT(int texunit, int coord, int pname, double param)
/*  926:     */   {
/*  927: 745 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  928: 746 */     long function_pointer = caps.glMultiTexGendEXT;
/*  929: 747 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  930: 748 */     nglMultiTexGendEXT(texunit, coord, pname, param, function_pointer);
/*  931:     */   }
/*  932:     */   
/*  933:     */   static native void nglMultiTexGendEXT(int paramInt1, int paramInt2, int paramInt3, double paramDouble, long paramLong);
/*  934:     */   
/*  935:     */   public static void glMultiTexGenEXT(int texunit, int coord, int pname, DoubleBuffer params)
/*  936:     */   {
/*  937: 753 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  938: 754 */     long function_pointer = caps.glMultiTexGendvEXT;
/*  939: 755 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  940: 756 */     BufferChecks.checkBuffer(params, 4);
/*  941: 757 */     nglMultiTexGendvEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/*  942:     */   }
/*  943:     */   
/*  944:     */   static native void nglMultiTexGendvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  945:     */   
/*  946:     */   public static void glMultiTexGenfEXT(int texunit, int coord, int pname, float param)
/*  947:     */   {
/*  948: 762 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  949: 763 */     long function_pointer = caps.glMultiTexGenfEXT;
/*  950: 764 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  951: 765 */     nglMultiTexGenfEXT(texunit, coord, pname, param, function_pointer);
/*  952:     */   }
/*  953:     */   
/*  954:     */   static native void nglMultiTexGenfEXT(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong);
/*  955:     */   
/*  956:     */   public static void glMultiTexGenEXT(int texunit, int coord, int pname, FloatBuffer params)
/*  957:     */   {
/*  958: 770 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  959: 771 */     long function_pointer = caps.glMultiTexGenfvEXT;
/*  960: 772 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  961: 773 */     BufferChecks.checkBuffer(params, 4);
/*  962: 774 */     nglMultiTexGenfvEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/*  963:     */   }
/*  964:     */   
/*  965:     */   static native void nglMultiTexGenfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  966:     */   
/*  967:     */   public static void glMultiTexGeniEXT(int texunit, int coord, int pname, int param)
/*  968:     */   {
/*  969: 779 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  970: 780 */     long function_pointer = caps.glMultiTexGeniEXT;
/*  971: 781 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  972: 782 */     nglMultiTexGeniEXT(texunit, coord, pname, param, function_pointer);
/*  973:     */   }
/*  974:     */   
/*  975:     */   static native void nglMultiTexGeniEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  976:     */   
/*  977:     */   public static void glMultiTexGenEXT(int texunit, int coord, int pname, IntBuffer params)
/*  978:     */   {
/*  979: 787 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  980: 788 */     long function_pointer = caps.glMultiTexGenivEXT;
/*  981: 789 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  982: 790 */     BufferChecks.checkBuffer(params, 4);
/*  983: 791 */     nglMultiTexGenivEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/*  984:     */   }
/*  985:     */   
/*  986:     */   static native void nglMultiTexGenivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  987:     */   
/*  988:     */   public static void glGetMultiTexEnvEXT(int texunit, int target, int pname, FloatBuffer params)
/*  989:     */   {
/*  990: 796 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  991: 797 */     long function_pointer = caps.glGetMultiTexEnvfvEXT;
/*  992: 798 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  993: 799 */     BufferChecks.checkBuffer(params, 4);
/*  994: 800 */     nglGetMultiTexEnvfvEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  995:     */   }
/*  996:     */   
/*  997:     */   static native void nglGetMultiTexEnvfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  998:     */   
/*  999:     */   public static void glGetMultiTexEnvEXT(int texunit, int target, int pname, IntBuffer params)
/* 1000:     */   {
/* 1001: 805 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1002: 806 */     long function_pointer = caps.glGetMultiTexEnvivEXT;
/* 1003: 807 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1004: 808 */     BufferChecks.checkBuffer(params, 4);
/* 1005: 809 */     nglGetMultiTexEnvivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1006:     */   }
/* 1007:     */   
/* 1008:     */   static native void nglGetMultiTexEnvivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1009:     */   
/* 1010:     */   public static void glGetMultiTexGenEXT(int texunit, int coord, int pname, DoubleBuffer params)
/* 1011:     */   {
/* 1012: 814 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1013: 815 */     long function_pointer = caps.glGetMultiTexGendvEXT;
/* 1014: 816 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1015: 817 */     BufferChecks.checkBuffer(params, 4);
/* 1016: 818 */     nglGetMultiTexGendvEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1017:     */   }
/* 1018:     */   
/* 1019:     */   static native void nglGetMultiTexGendvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1020:     */   
/* 1021:     */   public static void glGetMultiTexGenEXT(int texunit, int coord, int pname, FloatBuffer params)
/* 1022:     */   {
/* 1023: 823 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1024: 824 */     long function_pointer = caps.glGetMultiTexGenfvEXT;
/* 1025: 825 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1026: 826 */     BufferChecks.checkBuffer(params, 4);
/* 1027: 827 */     nglGetMultiTexGenfvEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1028:     */   }
/* 1029:     */   
/* 1030:     */   static native void nglGetMultiTexGenfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1031:     */   
/* 1032:     */   public static void glGetMultiTexGenEXT(int texunit, int coord, int pname, IntBuffer params)
/* 1033:     */   {
/* 1034: 832 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1035: 833 */     long function_pointer = caps.glGetMultiTexGenivEXT;
/* 1036: 834 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1037: 835 */     BufferChecks.checkBuffer(params, 4);
/* 1038: 836 */     nglGetMultiTexGenivEXT(texunit, coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1039:     */   }
/* 1040:     */   
/* 1041:     */   static native void nglGetMultiTexGenivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1042:     */   
/* 1043:     */   public static void glMultiTexParameteriEXT(int texunit, int target, int pname, int param)
/* 1044:     */   {
/* 1045: 841 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1046: 842 */     long function_pointer = caps.glMultiTexParameteriEXT;
/* 1047: 843 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1048: 844 */     nglMultiTexParameteriEXT(texunit, target, pname, param, function_pointer);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   static native void nglMultiTexParameteriEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 1052:     */   
/* 1053:     */   public static void glMultiTexParameterEXT(int texunit, int target, int pname, IntBuffer param)
/* 1054:     */   {
/* 1055: 849 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1056: 850 */     long function_pointer = caps.glMultiTexParameterivEXT;
/* 1057: 851 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1058: 852 */     BufferChecks.checkBuffer(param, 4);
/* 1059: 853 */     nglMultiTexParameterivEXT(texunit, target, pname, MemoryUtil.getAddress(param), function_pointer);
/* 1060:     */   }
/* 1061:     */   
/* 1062:     */   static native void nglMultiTexParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1063:     */   
/* 1064:     */   public static void glMultiTexParameterfEXT(int texunit, int target, int pname, float param)
/* 1065:     */   {
/* 1066: 858 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1067: 859 */     long function_pointer = caps.glMultiTexParameterfEXT;
/* 1068: 860 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1069: 861 */     nglMultiTexParameterfEXT(texunit, target, pname, param, function_pointer);
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   static native void nglMultiTexParameterfEXT(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong);
/* 1073:     */   
/* 1074:     */   public static void glMultiTexParameterEXT(int texunit, int target, int pname, FloatBuffer param)
/* 1075:     */   {
/* 1076: 866 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1077: 867 */     long function_pointer = caps.glMultiTexParameterfvEXT;
/* 1078: 868 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1079: 869 */     BufferChecks.checkBuffer(param, 4);
/* 1080: 870 */     nglMultiTexParameterfvEXT(texunit, target, pname, MemoryUtil.getAddress(param), function_pointer);
/* 1081:     */   }
/* 1082:     */   
/* 1083:     */   static native void nglMultiTexParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1084:     */   
/* 1085:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, ByteBuffer pixels)
/* 1086:     */   {
/* 1087: 875 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1088: 876 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1089: 877 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1090: 878 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1091: 879 */     if (pixels != null) {
/* 1092: 880 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 1093:     */     }
/* 1094: 881 */     nglMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1095:     */   }
/* 1096:     */   
/* 1097:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, DoubleBuffer pixels)
/* 1098:     */   {
/* 1099: 884 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1100: 885 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1101: 886 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1102: 887 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1103: 888 */     if (pixels != null) {
/* 1104: 889 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 1105:     */     }
/* 1106: 890 */     nglMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1107:     */   }
/* 1108:     */   
/* 1109:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, FloatBuffer pixels)
/* 1110:     */   {
/* 1111: 893 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1112: 894 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1113: 895 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1114: 896 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1115: 897 */     if (pixels != null) {
/* 1116: 898 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 1117:     */     }
/* 1118: 899 */     nglMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1119:     */   }
/* 1120:     */   
/* 1121:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, IntBuffer pixels)
/* 1122:     */   {
/* 1123: 902 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1124: 903 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1125: 904 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1126: 905 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1127: 906 */     if (pixels != null) {
/* 1128: 907 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 1129:     */     }
/* 1130: 908 */     nglMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1131:     */   }
/* 1132:     */   
/* 1133:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, ShortBuffer pixels)
/* 1134:     */   {
/* 1135: 911 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1136: 912 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1137: 913 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1138: 914 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1139: 915 */     if (pixels != null) {
/* 1140: 916 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 1141:     */     }
/* 1142: 917 */     nglMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1143:     */   }
/* 1144:     */   
/* 1145:     */   static native void nglMultiTexImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 1146:     */   
/* 1147:     */   public static void glMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int format, int type, long pixels_buffer_offset)
/* 1148:     */   {
/* 1149: 921 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1150: 922 */     long function_pointer = caps.glMultiTexImage1DEXT;
/* 1151: 923 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1152: 924 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1153: 925 */     nglMultiTexImage1DEXTBO(texunit, target, level, internalformat, width, border, format, type, pixels_buffer_offset, function_pointer);
/* 1154:     */   }
/* 1155:     */   
/* 1156:     */   static native void nglMultiTexImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 1157:     */   
/* 1158:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, ByteBuffer pixels)
/* 1159:     */   {
/* 1160: 930 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1161: 931 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1162: 932 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1163: 933 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1164: 934 */     if (pixels != null) {
/* 1165: 935 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 1166:     */     }
/* 1167: 936 */     nglMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1168:     */   }
/* 1169:     */   
/* 1170:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, DoubleBuffer pixels)
/* 1171:     */   {
/* 1172: 939 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1173: 940 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1174: 941 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1175: 942 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1176: 943 */     if (pixels != null) {
/* 1177: 944 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 1178:     */     }
/* 1179: 945 */     nglMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1180:     */   }
/* 1181:     */   
/* 1182:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, FloatBuffer pixels)
/* 1183:     */   {
/* 1184: 948 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1185: 949 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1186: 950 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1187: 951 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1188: 952 */     if (pixels != null) {
/* 1189: 953 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 1190:     */     }
/* 1191: 954 */     nglMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1192:     */   }
/* 1193:     */   
/* 1194:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, IntBuffer pixels)
/* 1195:     */   {
/* 1196: 957 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1197: 958 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1198: 959 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1199: 960 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1200: 961 */     if (pixels != null) {
/* 1201: 962 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 1202:     */     }
/* 1203: 963 */     nglMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1204:     */   }
/* 1205:     */   
/* 1206:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, ShortBuffer pixels)
/* 1207:     */   {
/* 1208: 966 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1209: 967 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1210: 968 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1211: 969 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1212: 970 */     if (pixels != null) {
/* 1213: 971 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 1214:     */     }
/* 1215: 972 */     nglMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1216:     */   }
/* 1217:     */   
/* 1218:     */   static native void nglMultiTexImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 1219:     */   
/* 1220:     */   public static void glMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int format, int type, long pixels_buffer_offset)
/* 1221:     */   {
/* 1222: 976 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1223: 977 */     long function_pointer = caps.glMultiTexImage2DEXT;
/* 1224: 978 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1225: 979 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1226: 980 */     nglMultiTexImage2DEXTBO(texunit, target, level, internalformat, width, height, border, format, type, pixels_buffer_offset, function_pointer);
/* 1227:     */   }
/* 1228:     */   
/* 1229:     */   static native void nglMultiTexImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 1230:     */   
/* 1231:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, ByteBuffer pixels)
/* 1232:     */   {
/* 1233: 985 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1234: 986 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1235: 987 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1236: 988 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1237: 989 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 1238: 990 */     nglMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1239:     */   }
/* 1240:     */   
/* 1241:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, DoubleBuffer pixels)
/* 1242:     */   {
/* 1243: 993 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1244: 994 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1245: 995 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1246: 996 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1247: 997 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 1248: 998 */     nglMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1249:     */   }
/* 1250:     */   
/* 1251:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, FloatBuffer pixels)
/* 1252:     */   {
/* 1253:1001 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1254:1002 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1255:1003 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1256:1004 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1257:1005 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 1258:1006 */     nglMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1259:     */   }
/* 1260:     */   
/* 1261:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, IntBuffer pixels)
/* 1262:     */   {
/* 1263:1009 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1264:1010 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1265:1011 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1266:1012 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1267:1013 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 1268:1014 */     nglMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1269:     */   }
/* 1270:     */   
/* 1271:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, ShortBuffer pixels)
/* 1272:     */   {
/* 1273:1017 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1274:1018 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1275:1019 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1276:1020 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1277:1021 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 1278:1022 */     nglMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1279:     */   }
/* 1280:     */   
/* 1281:     */   static native void nglMultiTexSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 1282:     */   
/* 1283:     */   public static void glMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int type, long pixels_buffer_offset)
/* 1284:     */   {
/* 1285:1026 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1286:1027 */     long function_pointer = caps.glMultiTexSubImage1DEXT;
/* 1287:1028 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1288:1029 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1289:1030 */     nglMultiTexSubImage1DEXTBO(texunit, target, level, xoffset, width, format, type, pixels_buffer_offset, function_pointer);
/* 1290:     */   }
/* 1291:     */   
/* 1292:     */   static native void nglMultiTexSubImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 1293:     */   
/* 1294:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ByteBuffer pixels)
/* 1295:     */   {
/* 1296:1035 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1297:1036 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1298:1037 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1299:1038 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1300:1039 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1301:1040 */     nglMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1302:     */   }
/* 1303:     */   
/* 1304:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, DoubleBuffer pixels)
/* 1305:     */   {
/* 1306:1043 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1307:1044 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1308:1045 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1309:1046 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1310:1047 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1311:1048 */     nglMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1312:     */   }
/* 1313:     */   
/* 1314:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, FloatBuffer pixels)
/* 1315:     */   {
/* 1316:1051 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1317:1052 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1318:1053 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1319:1054 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1320:1055 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1321:1056 */     nglMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1322:     */   }
/* 1323:     */   
/* 1324:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, IntBuffer pixels)
/* 1325:     */   {
/* 1326:1059 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1327:1060 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1328:1061 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1329:1062 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1330:1063 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1331:1064 */     nglMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1332:     */   }
/* 1333:     */   
/* 1334:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ShortBuffer pixels)
/* 1335:     */   {
/* 1336:1067 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1337:1068 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1338:1069 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1339:1070 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1340:1071 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1341:1072 */     nglMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1342:     */   }
/* 1343:     */   
/* 1344:     */   static native void nglMultiTexSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 1345:     */   
/* 1346:     */   public static void glMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, long pixels_buffer_offset)
/* 1347:     */   {
/* 1348:1076 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1349:1077 */     long function_pointer = caps.glMultiTexSubImage2DEXT;
/* 1350:1078 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1351:1079 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1352:1080 */     nglMultiTexSubImage2DEXTBO(texunit, target, level, xoffset, yoffset, width, height, format, type, pixels_buffer_offset, function_pointer);
/* 1353:     */   }
/* 1354:     */   
/* 1355:     */   static native void nglMultiTexSubImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 1356:     */   
/* 1357:     */   public static void glCopyMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int x, int y, int width, int border)
/* 1358:     */   {
/* 1359:1085 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1360:1086 */     long function_pointer = caps.glCopyMultiTexImage1DEXT;
/* 1361:1087 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1362:1088 */     nglCopyMultiTexImage1DEXT(texunit, target, level, internalformat, x, y, width, border, function_pointer);
/* 1363:     */   }
/* 1364:     */   
/* 1365:     */   static native void nglCopyMultiTexImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/* 1366:     */   
/* 1367:     */   public static void glCopyMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int x, int y, int width, int height, int border)
/* 1368:     */   {
/* 1369:1093 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1370:1094 */     long function_pointer = caps.glCopyMultiTexImage2DEXT;
/* 1371:1095 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1372:1096 */     nglCopyMultiTexImage2DEXT(texunit, target, level, internalformat, x, y, width, height, border, function_pointer);
/* 1373:     */   }
/* 1374:     */   
/* 1375:     */   static native void nglCopyMultiTexImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong);
/* 1376:     */   
/* 1377:     */   public static void glCopyMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int x, int y, int width)
/* 1378:     */   {
/* 1379:1101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1380:1102 */     long function_pointer = caps.glCopyMultiTexSubImage1DEXT;
/* 1381:1103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1382:1104 */     nglCopyMultiTexSubImage1DEXT(texunit, target, level, xoffset, x, y, width, function_pointer);
/* 1383:     */   }
/* 1384:     */   
/* 1385:     */   static native void nglCopyMultiTexSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/* 1386:     */   
/* 1387:     */   public static void glCopyMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int x, int y, int width, int height)
/* 1388:     */   {
/* 1389:1109 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1390:1110 */     long function_pointer = caps.glCopyMultiTexSubImage2DEXT;
/* 1391:1111 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1392:1112 */     nglCopyMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, x, y, width, height, function_pointer);
/* 1393:     */   }
/* 1394:     */   
/* 1395:     */   static native void nglCopyMultiTexSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong);
/* 1396:     */   
/* 1397:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, ByteBuffer pixels)
/* 1398:     */   {
/* 1399:1117 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1400:1118 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1401:1119 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1402:1120 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1403:1121 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1404:1122 */     nglGetMultiTexImageEXT(texunit, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1405:     */   }
/* 1406:     */   
/* 1407:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, DoubleBuffer pixels)
/* 1408:     */   {
/* 1409:1125 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1410:1126 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1411:1127 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1412:1128 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1413:1129 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1414:1130 */     nglGetMultiTexImageEXT(texunit, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1415:     */   }
/* 1416:     */   
/* 1417:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, FloatBuffer pixels)
/* 1418:     */   {
/* 1419:1133 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1420:1134 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1421:1135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1422:1136 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1423:1137 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1424:1138 */     nglGetMultiTexImageEXT(texunit, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1425:     */   }
/* 1426:     */   
/* 1427:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, IntBuffer pixels)
/* 1428:     */   {
/* 1429:1141 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1430:1142 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1431:1143 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1432:1144 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1433:1145 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1434:1146 */     nglGetMultiTexImageEXT(texunit, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1435:     */   }
/* 1436:     */   
/* 1437:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, ShortBuffer pixels)
/* 1438:     */   {
/* 1439:1149 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1440:1150 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1441:1151 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1442:1152 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1443:1153 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1444:1154 */     nglGetMultiTexImageEXT(texunit, target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1445:     */   }
/* 1446:     */   
/* 1447:     */   static native void nglGetMultiTexImageEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 1448:     */   
/* 1449:     */   public static void glGetMultiTexImageEXT(int texunit, int target, int level, int format, int type, long pixels_buffer_offset)
/* 1450:     */   {
/* 1451:1158 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1452:1159 */     long function_pointer = caps.glGetMultiTexImageEXT;
/* 1453:1160 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1454:1161 */     GLChecks.ensurePackPBOenabled(caps);
/* 1455:1162 */     nglGetMultiTexImageEXTBO(texunit, target, level, format, type, pixels_buffer_offset, function_pointer);
/* 1456:     */   }
/* 1457:     */   
/* 1458:     */   static native void nglGetMultiTexImageEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 1459:     */   
/* 1460:     */   public static void glGetMultiTexParameterEXT(int texunit, int target, int pname, FloatBuffer params)
/* 1461:     */   {
/* 1462:1167 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1463:1168 */     long function_pointer = caps.glGetMultiTexParameterfvEXT;
/* 1464:1169 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1465:1170 */     BufferChecks.checkBuffer(params, 4);
/* 1466:1171 */     nglGetMultiTexParameterfvEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1467:     */   }
/* 1468:     */   
/* 1469:     */   static native void nglGetMultiTexParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1470:     */   
/* 1471:     */   public static float glGetMultiTexParameterfEXT(int texunit, int target, int pname)
/* 1472:     */   {
/* 1473:1177 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1474:1178 */     long function_pointer = caps.glGetMultiTexParameterfvEXT;
/* 1475:1179 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1476:1180 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1477:1181 */     nglGetMultiTexParameterfvEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1478:1182 */     return params.get(0);
/* 1479:     */   }
/* 1480:     */   
/* 1481:     */   public static void glGetMultiTexParameterEXT(int texunit, int target, int pname, IntBuffer params)
/* 1482:     */   {
/* 1483:1186 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1484:1187 */     long function_pointer = caps.glGetMultiTexParameterivEXT;
/* 1485:1188 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1486:1189 */     BufferChecks.checkBuffer(params, 4);
/* 1487:1190 */     nglGetMultiTexParameterivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1488:     */   }
/* 1489:     */   
/* 1490:     */   static native void nglGetMultiTexParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1491:     */   
/* 1492:     */   public static int glGetMultiTexParameteriEXT(int texunit, int target, int pname)
/* 1493:     */   {
/* 1494:1196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1495:1197 */     long function_pointer = caps.glGetMultiTexParameterivEXT;
/* 1496:1198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1497:1199 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1498:1200 */     nglGetMultiTexParameterivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1499:1201 */     return params.get(0);
/* 1500:     */   }
/* 1501:     */   
/* 1502:     */   public static void glGetMultiTexLevelParameterEXT(int texunit, int target, int level, int pname, FloatBuffer params)
/* 1503:     */   {
/* 1504:1205 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1505:1206 */     long function_pointer = caps.glGetMultiTexLevelParameterfvEXT;
/* 1506:1207 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1507:1208 */     BufferChecks.checkBuffer(params, 4);
/* 1508:1209 */     nglGetMultiTexLevelParameterfvEXT(texunit, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1509:     */   }
/* 1510:     */   
/* 1511:     */   static native void nglGetMultiTexLevelParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1512:     */   
/* 1513:     */   public static float glGetMultiTexLevelParameterfEXT(int texunit, int target, int level, int pname)
/* 1514:     */   {
/* 1515:1215 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1516:1216 */     long function_pointer = caps.glGetMultiTexLevelParameterfvEXT;
/* 1517:1217 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1518:1218 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1519:1219 */     nglGetMultiTexLevelParameterfvEXT(texunit, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1520:1220 */     return params.get(0);
/* 1521:     */   }
/* 1522:     */   
/* 1523:     */   public static void glGetMultiTexLevelParameterEXT(int texunit, int target, int level, int pname, IntBuffer params)
/* 1524:     */   {
/* 1525:1224 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1526:1225 */     long function_pointer = caps.glGetMultiTexLevelParameterivEXT;
/* 1527:1226 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1528:1227 */     BufferChecks.checkBuffer(params, 4);
/* 1529:1228 */     nglGetMultiTexLevelParameterivEXT(texunit, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1530:     */   }
/* 1531:     */   
/* 1532:     */   static native void nglGetMultiTexLevelParameterivEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1533:     */   
/* 1534:     */   public static int glGetMultiTexLevelParameteriEXT(int texunit, int target, int level, int pname)
/* 1535:     */   {
/* 1536:1234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1537:1235 */     long function_pointer = caps.glGetMultiTexLevelParameterivEXT;
/* 1538:1236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1539:1237 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1540:1238 */     nglGetMultiTexLevelParameterivEXT(texunit, target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1541:1239 */     return params.get(0);
/* 1542:     */   }
/* 1543:     */   
/* 1544:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, ByteBuffer pixels)
/* 1545:     */   {
/* 1546:1243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1547:1244 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1548:1245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1549:1246 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1550:1247 */     if (pixels != null) {
/* 1551:1248 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 1552:     */     }
/* 1553:1249 */     nglMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1554:     */   }
/* 1555:     */   
/* 1556:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, DoubleBuffer pixels)
/* 1557:     */   {
/* 1558:1252 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1559:1253 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1560:1254 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1561:1255 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1562:1256 */     if (pixels != null) {
/* 1563:1257 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 1564:     */     }
/* 1565:1258 */     nglMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1566:     */   }
/* 1567:     */   
/* 1568:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, FloatBuffer pixels)
/* 1569:     */   {
/* 1570:1261 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1571:1262 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1572:1263 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1573:1264 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1574:1265 */     if (pixels != null) {
/* 1575:1266 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 1576:     */     }
/* 1577:1267 */     nglMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1578:     */   }
/* 1579:     */   
/* 1580:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, IntBuffer pixels)
/* 1581:     */   {
/* 1582:1270 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1583:1271 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1584:1272 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1585:1273 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1586:1274 */     if (pixels != null) {
/* 1587:1275 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 1588:     */     }
/* 1589:1276 */     nglMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1590:     */   }
/* 1591:     */   
/* 1592:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, ShortBuffer pixels)
/* 1593:     */   {
/* 1594:1279 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1595:1280 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1596:1281 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1597:1282 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1598:1283 */     if (pixels != null) {
/* 1599:1284 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 1600:     */     }
/* 1601:1285 */     nglMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 1602:     */   }
/* 1603:     */   
/* 1604:     */   static native void nglMultiTexImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 1605:     */   
/* 1606:     */   public static void glMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int format, int type, long pixels_buffer_offset)
/* 1607:     */   {
/* 1608:1289 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1609:1290 */     long function_pointer = caps.glMultiTexImage3DEXT;
/* 1610:1291 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1611:1292 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1612:1293 */     nglMultiTexImage3DEXTBO(texunit, target, level, internalformat, width, height, depth, border, format, type, pixels_buffer_offset, function_pointer);
/* 1613:     */   }
/* 1614:     */   
/* 1615:     */   static native void nglMultiTexImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 1616:     */   
/* 1617:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ByteBuffer pixels)
/* 1618:     */   {
/* 1619:1298 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1620:1299 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1621:1300 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1622:1301 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1623:1302 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 1624:1303 */     nglMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1625:     */   }
/* 1626:     */   
/* 1627:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, DoubleBuffer pixels)
/* 1628:     */   {
/* 1629:1306 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1630:1307 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1631:1308 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1632:1309 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1633:1310 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 1634:1311 */     nglMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1635:     */   }
/* 1636:     */   
/* 1637:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, FloatBuffer pixels)
/* 1638:     */   {
/* 1639:1314 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1640:1315 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1641:1316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1642:1317 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1643:1318 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 1644:1319 */     nglMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1645:     */   }
/* 1646:     */   
/* 1647:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, IntBuffer pixels)
/* 1648:     */   {
/* 1649:1322 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1650:1323 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1651:1324 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1652:1325 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1653:1326 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 1654:1327 */     nglMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1655:     */   }
/* 1656:     */   
/* 1657:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ShortBuffer pixels)
/* 1658:     */   {
/* 1659:1330 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1660:1331 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1661:1332 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1662:1333 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1663:1334 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 1664:1335 */     nglMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1665:     */   }
/* 1666:     */   
/* 1667:     */   static native void nglMultiTexSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 1668:     */   
/* 1669:     */   public static void glMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, long pixels_buffer_offset)
/* 1670:     */   {
/* 1671:1339 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1672:1340 */     long function_pointer = caps.glMultiTexSubImage3DEXT;
/* 1673:1341 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1674:1342 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1675:1343 */     nglMultiTexSubImage3DEXTBO(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels_buffer_offset, function_pointer);
/* 1676:     */   }
/* 1677:     */   
/* 1678:     */   static native void nglMultiTexSubImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 1679:     */   
/* 1680:     */   public static void glCopyMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int x, int y, int width, int height)
/* 1681:     */   {
/* 1682:1348 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1683:1349 */     long function_pointer = caps.glCopyMultiTexSubImage3DEXT;
/* 1684:1350 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1685:1351 */     nglCopyMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, x, y, width, height, function_pointer);
/* 1686:     */   }
/* 1687:     */   
/* 1688:     */   static native void nglCopyMultiTexSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong);
/* 1689:     */   
/* 1690:     */   public static void glEnableClientStateIndexedEXT(int array, int index)
/* 1691:     */   {
/* 1692:1356 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1693:1357 */     long function_pointer = caps.glEnableClientStateIndexedEXT;
/* 1694:1358 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1695:1359 */     nglEnableClientStateIndexedEXT(array, index, function_pointer);
/* 1696:     */   }
/* 1697:     */   
/* 1698:     */   static native void nglEnableClientStateIndexedEXT(int paramInt1, int paramInt2, long paramLong);
/* 1699:     */   
/* 1700:     */   public static void glDisableClientStateIndexedEXT(int array, int index)
/* 1701:     */   {
/* 1702:1364 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1703:1365 */     long function_pointer = caps.glDisableClientStateIndexedEXT;
/* 1704:1366 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1705:1367 */     nglDisableClientStateIndexedEXT(array, index, function_pointer);
/* 1706:     */   }
/* 1707:     */   
/* 1708:     */   static native void nglDisableClientStateIndexedEXT(int paramInt1, int paramInt2, long paramLong);
/* 1709:     */   
/* 1710:     */   public static void glEnableClientStateiEXT(int array, int index)
/* 1711:     */   {
/* 1712:1372 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1713:1373 */     long function_pointer = caps.glEnableClientStateiEXT;
/* 1714:1374 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1715:1375 */     nglEnableClientStateiEXT(array, index, function_pointer);
/* 1716:     */   }
/* 1717:     */   
/* 1718:     */   static native void nglEnableClientStateiEXT(int paramInt1, int paramInt2, long paramLong);
/* 1719:     */   
/* 1720:     */   public static void glDisableClientStateiEXT(int array, int index)
/* 1721:     */   {
/* 1722:1380 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1723:1381 */     long function_pointer = caps.glDisableClientStateiEXT;
/* 1724:1382 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1725:1383 */     nglDisableClientStateiEXT(array, index, function_pointer);
/* 1726:     */   }
/* 1727:     */   
/* 1728:     */   static native void nglDisableClientStateiEXT(int paramInt1, int paramInt2, long paramLong);
/* 1729:     */   
/* 1730:     */   public static void glGetFloatIndexedEXT(int pname, int index, FloatBuffer params)
/* 1731:     */   {
/* 1732:1388 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1733:1389 */     long function_pointer = caps.glGetFloatIndexedvEXT;
/* 1734:1390 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1735:1391 */     BufferChecks.checkBuffer(params, 16);
/* 1736:1392 */     nglGetFloatIndexedvEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1737:     */   }
/* 1738:     */   
/* 1739:     */   static native void nglGetFloatIndexedvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1740:     */   
/* 1741:     */   public static float glGetFloatIndexedEXT(int pname, int index)
/* 1742:     */   {
/* 1743:1398 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1744:1399 */     long function_pointer = caps.glGetFloatIndexedvEXT;
/* 1745:1400 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1746:1401 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1747:1402 */     nglGetFloatIndexedvEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1748:1403 */     return params.get(0);
/* 1749:     */   }
/* 1750:     */   
/* 1751:     */   public static void glGetDoubleIndexedEXT(int pname, int index, DoubleBuffer params)
/* 1752:     */   {
/* 1753:1407 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1754:1408 */     long function_pointer = caps.glGetDoubleIndexedvEXT;
/* 1755:1409 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1756:1410 */     BufferChecks.checkBuffer(params, 16);
/* 1757:1411 */     nglGetDoubleIndexedvEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1758:     */   }
/* 1759:     */   
/* 1760:     */   static native void nglGetDoubleIndexedvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1761:     */   
/* 1762:     */   public static double glGetDoubleIndexedEXT(int pname, int index)
/* 1763:     */   {
/* 1764:1417 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1765:1418 */     long function_pointer = caps.glGetDoubleIndexedvEXT;
/* 1766:1419 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1767:1420 */     DoubleBuffer params = APIUtil.getBufferDouble(caps);
/* 1768:1421 */     nglGetDoubleIndexedvEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1769:1422 */     return params.get(0);
/* 1770:     */   }
/* 1771:     */   
/* 1772:     */   public static ByteBuffer glGetPointerIndexedEXT(int pname, int index, long result_size)
/* 1773:     */   {
/* 1774:1426 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1775:1427 */     long function_pointer = caps.glGetPointerIndexedvEXT;
/* 1776:1428 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1777:1429 */     ByteBuffer __result = nglGetPointerIndexedvEXT(pname, index, result_size, function_pointer);
/* 1778:1430 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 1779:     */   }
/* 1780:     */   
/* 1781:     */   static native ByteBuffer nglGetPointerIndexedvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1782:     */   
/* 1783:     */   public static void glGetFloatEXT(int pname, int index, FloatBuffer params)
/* 1784:     */   {
/* 1785:1435 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1786:1436 */     long function_pointer = caps.glGetFloati_vEXT;
/* 1787:1437 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1788:1438 */     BufferChecks.checkBuffer(params, 16);
/* 1789:1439 */     nglGetFloati_vEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1790:     */   }
/* 1791:     */   
/* 1792:     */   static native void nglGetFloati_vEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1793:     */   
/* 1794:     */   public static float glGetFloatEXT(int pname, int index)
/* 1795:     */   {
/* 1796:1445 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1797:1446 */     long function_pointer = caps.glGetFloati_vEXT;
/* 1798:1447 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1799:1448 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1800:1449 */     nglGetFloati_vEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1801:1450 */     return params.get(0);
/* 1802:     */   }
/* 1803:     */   
/* 1804:     */   public static void glGetDoubleEXT(int pname, int index, DoubleBuffer params)
/* 1805:     */   {
/* 1806:1454 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1807:1455 */     long function_pointer = caps.glGetDoublei_vEXT;
/* 1808:1456 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1809:1457 */     BufferChecks.checkBuffer(params, 16);
/* 1810:1458 */     nglGetDoublei_vEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1811:     */   }
/* 1812:     */   
/* 1813:     */   static native void nglGetDoublei_vEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1814:     */   
/* 1815:     */   public static double glGetDoubleEXT(int pname, int index)
/* 1816:     */   {
/* 1817:1464 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1818:1465 */     long function_pointer = caps.glGetDoublei_vEXT;
/* 1819:1466 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1820:1467 */     DoubleBuffer params = APIUtil.getBufferDouble(caps);
/* 1821:1468 */     nglGetDoublei_vEXT(pname, index, MemoryUtil.getAddress(params), function_pointer);
/* 1822:1469 */     return params.get(0);
/* 1823:     */   }
/* 1824:     */   
/* 1825:     */   public static ByteBuffer glGetPointerEXT(int pname, int index, long result_size)
/* 1826:     */   {
/* 1827:1473 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1828:1474 */     long function_pointer = caps.glGetPointeri_vEXT;
/* 1829:1475 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1830:1476 */     ByteBuffer __result = nglGetPointeri_vEXT(pname, index, result_size, function_pointer);
/* 1831:1477 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 1832:     */   }
/* 1833:     */   
/* 1834:     */   static native ByteBuffer nglGetPointeri_vEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1835:     */   
/* 1836:     */   public static void glEnableIndexedEXT(int cap, int index)
/* 1837:     */   {
/* 1838:1482 */     EXTDrawBuffers2.glEnableIndexedEXT(cap, index);
/* 1839:     */   }
/* 1840:     */   
/* 1841:     */   public static void glDisableIndexedEXT(int cap, int index)
/* 1842:     */   {
/* 1843:1486 */     EXTDrawBuffers2.glDisableIndexedEXT(cap, index);
/* 1844:     */   }
/* 1845:     */   
/* 1846:     */   public static boolean glIsEnabledIndexedEXT(int cap, int index)
/* 1847:     */   {
/* 1848:1490 */     return EXTDrawBuffers2.glIsEnabledIndexedEXT(cap, index);
/* 1849:     */   }
/* 1850:     */   
/* 1851:     */   public static void glGetIntegerIndexedEXT(int pname, int index, IntBuffer params)
/* 1852:     */   {
/* 1853:1494 */     EXTDrawBuffers2.glGetIntegerIndexedEXT(pname, index, params);
/* 1854:     */   }
/* 1855:     */   
/* 1856:     */   public static int glGetIntegerIndexedEXT(int pname, int index)
/* 1857:     */   {
/* 1858:1499 */     return EXTDrawBuffers2.glGetIntegerIndexedEXT(pname, index);
/* 1859:     */   }
/* 1860:     */   
/* 1861:     */   public static void glGetBooleanIndexedEXT(int pname, int index, ByteBuffer params)
/* 1862:     */   {
/* 1863:1503 */     EXTDrawBuffers2.glGetBooleanIndexedEXT(pname, index, params);
/* 1864:     */   }
/* 1865:     */   
/* 1866:     */   public static boolean glGetBooleanIndexedEXT(int pname, int index)
/* 1867:     */   {
/* 1868:1508 */     return EXTDrawBuffers2.glGetBooleanIndexedEXT(pname, index);
/* 1869:     */   }
/* 1870:     */   
/* 1871:     */   public static void glNamedProgramStringEXT(int program, int target, int format, ByteBuffer string)
/* 1872:     */   {
/* 1873:1512 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1874:1513 */     long function_pointer = caps.glNamedProgramStringEXT;
/* 1875:1514 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1876:1515 */     BufferChecks.checkDirect(string);
/* 1877:1516 */     nglNamedProgramStringEXT(program, target, format, string.remaining(), MemoryUtil.getAddress(string), function_pointer);
/* 1878:     */   }
/* 1879:     */   
/* 1880:     */   static native void nglNamedProgramStringEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1881:     */   
/* 1882:     */   public static void glNamedProgramStringEXT(int program, int target, int format, CharSequence string)
/* 1883:     */   {
/* 1884:1522 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1885:1523 */     long function_pointer = caps.glNamedProgramStringEXT;
/* 1886:1524 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1887:1525 */     nglNamedProgramStringEXT(program, target, format, string.length(), APIUtil.getBuffer(caps, string), function_pointer);
/* 1888:     */   }
/* 1889:     */   
/* 1890:     */   public static void glNamedProgramLocalParameter4dEXT(int program, int target, int index, double x, double y, double z, double w)
/* 1891:     */   {
/* 1892:1529 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1893:1530 */     long function_pointer = caps.glNamedProgramLocalParameter4dEXT;
/* 1894:1531 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1895:1532 */     nglNamedProgramLocalParameter4dEXT(program, target, index, x, y, z, w, function_pointer);
/* 1896:     */   }
/* 1897:     */   
/* 1898:     */   static native void nglNamedProgramLocalParameter4dEXT(int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 1899:     */   
/* 1900:     */   public static void glNamedProgramLocalParameter4EXT(int program, int target, int index, DoubleBuffer params)
/* 1901:     */   {
/* 1902:1537 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1903:1538 */     long function_pointer = caps.glNamedProgramLocalParameter4dvEXT;
/* 1904:1539 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1905:1540 */     BufferChecks.checkBuffer(params, 4);
/* 1906:1541 */     nglNamedProgramLocalParameter4dvEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 1907:     */   }
/* 1908:     */   
/* 1909:     */   static native void nglNamedProgramLocalParameter4dvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1910:     */   
/* 1911:     */   public static void glNamedProgramLocalParameter4fEXT(int program, int target, int index, float x, float y, float z, float w)
/* 1912:     */   {
/* 1913:1546 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1914:1547 */     long function_pointer = caps.glNamedProgramLocalParameter4fEXT;
/* 1915:1548 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1916:1549 */     nglNamedProgramLocalParameter4fEXT(program, target, index, x, y, z, w, function_pointer);
/* 1917:     */   }
/* 1918:     */   
/* 1919:     */   static native void nglNamedProgramLocalParameter4fEXT(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 1920:     */   
/* 1921:     */   public static void glNamedProgramLocalParameter4EXT(int program, int target, int index, FloatBuffer params)
/* 1922:     */   {
/* 1923:1554 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1924:1555 */     long function_pointer = caps.glNamedProgramLocalParameter4fvEXT;
/* 1925:1556 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1926:1557 */     BufferChecks.checkBuffer(params, 4);
/* 1927:1558 */     nglNamedProgramLocalParameter4fvEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 1928:     */   }
/* 1929:     */   
/* 1930:     */   static native void nglNamedProgramLocalParameter4fvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1931:     */   
/* 1932:     */   public static void glGetNamedProgramLocalParameterEXT(int program, int target, int index, DoubleBuffer params)
/* 1933:     */   {
/* 1934:1563 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1935:1564 */     long function_pointer = caps.glGetNamedProgramLocalParameterdvEXT;
/* 1936:1565 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1937:1566 */     BufferChecks.checkBuffer(params, 4);
/* 1938:1567 */     nglGetNamedProgramLocalParameterdvEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 1939:     */   }
/* 1940:     */   
/* 1941:     */   static native void nglGetNamedProgramLocalParameterdvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1942:     */   
/* 1943:     */   public static void glGetNamedProgramLocalParameterEXT(int program, int target, int index, FloatBuffer params)
/* 1944:     */   {
/* 1945:1572 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1946:1573 */     long function_pointer = caps.glGetNamedProgramLocalParameterfvEXT;
/* 1947:1574 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1948:1575 */     BufferChecks.checkBuffer(params, 4);
/* 1949:1576 */     nglGetNamedProgramLocalParameterfvEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 1950:     */   }
/* 1951:     */   
/* 1952:     */   static native void nglGetNamedProgramLocalParameterfvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1953:     */   
/* 1954:     */   public static void glGetNamedProgramEXT(int program, int target, int pname, IntBuffer params)
/* 1955:     */   {
/* 1956:1581 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1957:1582 */     long function_pointer = caps.glGetNamedProgramivEXT;
/* 1958:1583 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1959:1584 */     BufferChecks.checkBuffer(params, 4);
/* 1960:1585 */     nglGetNamedProgramivEXT(program, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1961:     */   }
/* 1962:     */   
/* 1963:     */   static native void nglGetNamedProgramivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1964:     */   
/* 1965:     */   public static int glGetNamedProgramEXT(int program, int target, int pname)
/* 1966:     */   {
/* 1967:1591 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1968:1592 */     long function_pointer = caps.glGetNamedProgramivEXT;
/* 1969:1593 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1970:1594 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1971:1595 */     nglGetNamedProgramivEXT(program, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1972:1596 */     return params.get(0);
/* 1973:     */   }
/* 1974:     */   
/* 1975:     */   public static void glGetNamedProgramStringEXT(int program, int target, int pname, ByteBuffer string)
/* 1976:     */   {
/* 1977:1600 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1978:1601 */     long function_pointer = caps.glGetNamedProgramStringEXT;
/* 1979:1602 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1980:1603 */     BufferChecks.checkDirect(string);
/* 1981:1604 */     nglGetNamedProgramStringEXT(program, target, pname, MemoryUtil.getAddress(string), function_pointer);
/* 1982:     */   }
/* 1983:     */   
/* 1984:     */   static native void nglGetNamedProgramStringEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1985:     */   
/* 1986:     */   public static String glGetNamedProgramStringEXT(int program, int target, int pname)
/* 1987:     */   {
/* 1988:1610 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1989:1611 */     long function_pointer = caps.glGetNamedProgramStringEXT;
/* 1990:1612 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1991:1613 */     int programLength = glGetNamedProgramEXT(program, target, 34343);
/* 1992:1614 */     ByteBuffer paramString = APIUtil.getBufferByte(caps, programLength);
/* 1993:1615 */     nglGetNamedProgramStringEXT(program, target, pname, MemoryUtil.getAddress(paramString), function_pointer);
/* 1994:1616 */     paramString.limit(programLength);
/* 1995:1617 */     return APIUtil.getString(caps, paramString);
/* 1996:     */   }
/* 1997:     */   
/* 1998:     */   public static void glCompressedTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, ByteBuffer data)
/* 1999:     */   {
/* 2000:1621 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2001:1622 */     long function_pointer = caps.glCompressedTextureImage3DEXT;
/* 2002:1623 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2003:1624 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2004:1625 */     BufferChecks.checkDirect(data);
/* 2005:1626 */     nglCompressedTextureImage3DEXT(texture, target, level, internalformat, width, height, depth, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2006:     */   }
/* 2007:     */   
/* 2008:     */   static native void nglCompressedTextureImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2009:     */   
/* 2010:     */   public static void glCompressedTextureImage3DEXT(int texture, int target, int level, int internalformat, int width, int height, int depth, int border, int data_imageSize, long data_buffer_offset)
/* 2011:     */   {
/* 2012:1630 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2013:1631 */     long function_pointer = caps.glCompressedTextureImage3DEXT;
/* 2014:1632 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2015:1633 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2016:1634 */     nglCompressedTextureImage3DEXTBO(texture, target, level, internalformat, width, height, depth, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2017:     */   }
/* 2018:     */   
/* 2019:     */   static native void nglCompressedTextureImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2020:     */   
/* 2021:     */   public static void glCompressedTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, ByteBuffer data)
/* 2022:     */   {
/* 2023:1639 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2024:1640 */     long function_pointer = caps.glCompressedTextureImage2DEXT;
/* 2025:1641 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2026:1642 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2027:1643 */     BufferChecks.checkDirect(data);
/* 2028:1644 */     nglCompressedTextureImage2DEXT(texture, target, level, internalformat, width, height, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2029:     */   }
/* 2030:     */   
/* 2031:     */   static native void nglCompressedTextureImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 2032:     */   
/* 2033:     */   public static void glCompressedTextureImage2DEXT(int texture, int target, int level, int internalformat, int width, int height, int border, int data_imageSize, long data_buffer_offset)
/* 2034:     */   {
/* 2035:1648 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2036:1649 */     long function_pointer = caps.glCompressedTextureImage2DEXT;
/* 2037:1650 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2038:1651 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2039:1652 */     nglCompressedTextureImage2DEXTBO(texture, target, level, internalformat, width, height, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2040:     */   }
/* 2041:     */   
/* 2042:     */   static native void nglCompressedTextureImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 2043:     */   
/* 2044:     */   public static void glCompressedTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, ByteBuffer data)
/* 2045:     */   {
/* 2046:1657 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2047:1658 */     long function_pointer = caps.glCompressedTextureImage1DEXT;
/* 2048:1659 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2049:1660 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2050:1661 */     BufferChecks.checkDirect(data);
/* 2051:1662 */     nglCompressedTextureImage1DEXT(texture, target, level, internalformat, width, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2052:     */   }
/* 2053:     */   
/* 2054:     */   static native void nglCompressedTextureImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2055:     */   
/* 2056:     */   public static void glCompressedTextureImage1DEXT(int texture, int target, int level, int internalformat, int width, int border, int data_imageSize, long data_buffer_offset)
/* 2057:     */   {
/* 2058:1666 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2059:1667 */     long function_pointer = caps.glCompressedTextureImage1DEXT;
/* 2060:1668 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2061:1669 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2062:1670 */     nglCompressedTextureImage1DEXTBO(texture, target, level, internalformat, width, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2063:     */   }
/* 2064:     */   
/* 2065:     */   static native void nglCompressedTextureImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2066:     */   
/* 2067:     */   public static void glCompressedTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, ByteBuffer data)
/* 2068:     */   {
/* 2069:1675 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2070:1676 */     long function_pointer = caps.glCompressedTextureSubImage3DEXT;
/* 2071:1677 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2072:1678 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2073:1679 */     BufferChecks.checkDirect(data);
/* 2074:1680 */     nglCompressedTextureSubImage3DEXT(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2075:     */   }
/* 2076:     */   
/* 2077:     */   static native void nglCompressedTextureSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 2078:     */   
/* 2079:     */   public static void glCompressedTextureSubImage3DEXT(int texture, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int data_imageSize, long data_buffer_offset)
/* 2080:     */   {
/* 2081:1684 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2082:1685 */     long function_pointer = caps.glCompressedTextureSubImage3DEXT;
/* 2083:1686 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2084:1687 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2085:1688 */     nglCompressedTextureSubImage3DEXTBO(texture, target, level, xoffset, yoffset, zoffset, width, height, depth, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2086:     */   }
/* 2087:     */   
/* 2088:     */   static native void nglCompressedTextureSubImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 2089:     */   
/* 2090:     */   public static void glCompressedTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, ByteBuffer data)
/* 2091:     */   {
/* 2092:1693 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2093:1694 */     long function_pointer = caps.glCompressedTextureSubImage2DEXT;
/* 2094:1695 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2095:1696 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2096:1697 */     BufferChecks.checkDirect(data);
/* 2097:1698 */     nglCompressedTextureSubImage2DEXT(texture, target, level, xoffset, yoffset, width, height, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2098:     */   }
/* 2099:     */   
/* 2100:     */   static native void nglCompressedTextureSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2101:     */   
/* 2102:     */   public static void glCompressedTextureSubImage2DEXT(int texture, int target, int level, int xoffset, int yoffset, int width, int height, int format, int data_imageSize, long data_buffer_offset)
/* 2103:     */   {
/* 2104:1702 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2105:1703 */     long function_pointer = caps.glCompressedTextureSubImage2DEXT;
/* 2106:1704 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2107:1705 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2108:1706 */     nglCompressedTextureSubImage2DEXTBO(texture, target, level, xoffset, yoffset, width, height, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2109:     */   }
/* 2110:     */   
/* 2111:     */   static native void nglCompressedTextureSubImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2112:     */   
/* 2113:     */   public static void glCompressedTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, ByteBuffer data)
/* 2114:     */   {
/* 2115:1711 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2116:1712 */     long function_pointer = caps.glCompressedTextureSubImage1DEXT;
/* 2117:1713 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2118:1714 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2119:1715 */     BufferChecks.checkDirect(data);
/* 2120:1716 */     nglCompressedTextureSubImage1DEXT(texture, target, level, xoffset, width, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2121:     */   }
/* 2122:     */   
/* 2123:     */   static native void nglCompressedTextureSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2124:     */   
/* 2125:     */   public static void glCompressedTextureSubImage1DEXT(int texture, int target, int level, int xoffset, int width, int format, int data_imageSize, long data_buffer_offset)
/* 2126:     */   {
/* 2127:1720 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2128:1721 */     long function_pointer = caps.glCompressedTextureSubImage1DEXT;
/* 2129:1722 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2130:1723 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2131:1724 */     nglCompressedTextureSubImage1DEXTBO(texture, target, level, xoffset, width, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2132:     */   }
/* 2133:     */   
/* 2134:     */   static native void nglCompressedTextureSubImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2135:     */   
/* 2136:     */   public static void glGetCompressedTextureImageEXT(int texture, int target, int level, ByteBuffer img)
/* 2137:     */   {
/* 2138:1729 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2139:1730 */     long function_pointer = caps.glGetCompressedTextureImageEXT;
/* 2140:1731 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2141:1732 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2142:1733 */     BufferChecks.checkDirect(img);
/* 2143:1734 */     nglGetCompressedTextureImageEXT(texture, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2144:     */   }
/* 2145:     */   
/* 2146:     */   public static void glGetCompressedTextureImageEXT(int texture, int target, int level, IntBuffer img)
/* 2147:     */   {
/* 2148:1737 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2149:1738 */     long function_pointer = caps.glGetCompressedTextureImageEXT;
/* 2150:1739 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2151:1740 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2152:1741 */     BufferChecks.checkDirect(img);
/* 2153:1742 */     nglGetCompressedTextureImageEXT(texture, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2154:     */   }
/* 2155:     */   
/* 2156:     */   public static void glGetCompressedTextureImageEXT(int texture, int target, int level, ShortBuffer img)
/* 2157:     */   {
/* 2158:1745 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2159:1746 */     long function_pointer = caps.glGetCompressedTextureImageEXT;
/* 2160:1747 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2161:1748 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2162:1749 */     BufferChecks.checkDirect(img);
/* 2163:1750 */     nglGetCompressedTextureImageEXT(texture, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2164:     */   }
/* 2165:     */   
/* 2166:     */   static native void nglGetCompressedTextureImageEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2167:     */   
/* 2168:     */   public static void glGetCompressedTextureImageEXT(int texture, int target, int level, long img_buffer_offset)
/* 2169:     */   {
/* 2170:1754 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2171:1755 */     long function_pointer = caps.glGetCompressedTextureImageEXT;
/* 2172:1756 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2173:1757 */     GLChecks.ensurePackPBOenabled(caps);
/* 2174:1758 */     nglGetCompressedTextureImageEXTBO(texture, target, level, img_buffer_offset, function_pointer);
/* 2175:     */   }
/* 2176:     */   
/* 2177:     */   static native void nglGetCompressedTextureImageEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2178:     */   
/* 2179:     */   public static void glCompressedMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, ByteBuffer data)
/* 2180:     */   {
/* 2181:1763 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2182:1764 */     long function_pointer = caps.glCompressedMultiTexImage3DEXT;
/* 2183:1765 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2184:1766 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2185:1767 */     BufferChecks.checkDirect(data);
/* 2186:1768 */     nglCompressedMultiTexImage3DEXT(texunit, target, level, internalformat, width, height, depth, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2187:     */   }
/* 2188:     */   
/* 2189:     */   static native void nglCompressedMultiTexImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2190:     */   
/* 2191:     */   public static void glCompressedMultiTexImage3DEXT(int texunit, int target, int level, int internalformat, int width, int height, int depth, int border, int data_imageSize, long data_buffer_offset)
/* 2192:     */   {
/* 2193:1772 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2194:1773 */     long function_pointer = caps.glCompressedMultiTexImage3DEXT;
/* 2195:1774 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2196:1775 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2197:1776 */     nglCompressedMultiTexImage3DEXTBO(texunit, target, level, internalformat, width, height, depth, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2198:     */   }
/* 2199:     */   
/* 2200:     */   static native void nglCompressedMultiTexImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2201:     */   
/* 2202:     */   public static void glCompressedMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, ByteBuffer data)
/* 2203:     */   {
/* 2204:1781 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2205:1782 */     long function_pointer = caps.glCompressedMultiTexImage2DEXT;
/* 2206:1783 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2207:1784 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2208:1785 */     BufferChecks.checkDirect(data);
/* 2209:1786 */     nglCompressedMultiTexImage2DEXT(texunit, target, level, internalformat, width, height, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2210:     */   }
/* 2211:     */   
/* 2212:     */   static native void nglCompressedMultiTexImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 2213:     */   
/* 2214:     */   public static void glCompressedMultiTexImage2DEXT(int texunit, int target, int level, int internalformat, int width, int height, int border, int data_imageSize, long data_buffer_offset)
/* 2215:     */   {
/* 2216:1790 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2217:1791 */     long function_pointer = caps.glCompressedMultiTexImage2DEXT;
/* 2218:1792 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2219:1793 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2220:1794 */     nglCompressedMultiTexImage2DEXTBO(texunit, target, level, internalformat, width, height, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2221:     */   }
/* 2222:     */   
/* 2223:     */   static native void nglCompressedMultiTexImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 2224:     */   
/* 2225:     */   public static void glCompressedMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, ByteBuffer data)
/* 2226:     */   {
/* 2227:1799 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2228:1800 */     long function_pointer = caps.glCompressedMultiTexImage1DEXT;
/* 2229:1801 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2230:1802 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2231:1803 */     BufferChecks.checkDirect(data);
/* 2232:1804 */     nglCompressedMultiTexImage1DEXT(texunit, target, level, internalformat, width, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2233:     */   }
/* 2234:     */   
/* 2235:     */   static native void nglCompressedMultiTexImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2236:     */   
/* 2237:     */   public static void glCompressedMultiTexImage1DEXT(int texunit, int target, int level, int internalformat, int width, int border, int data_imageSize, long data_buffer_offset)
/* 2238:     */   {
/* 2239:1808 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2240:1809 */     long function_pointer = caps.glCompressedMultiTexImage1DEXT;
/* 2241:1810 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2242:1811 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2243:1812 */     nglCompressedMultiTexImage1DEXTBO(texunit, target, level, internalformat, width, border, data_imageSize, data_buffer_offset, function_pointer);
/* 2244:     */   }
/* 2245:     */   
/* 2246:     */   static native void nglCompressedMultiTexImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2247:     */   
/* 2248:     */   public static void glCompressedMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, ByteBuffer data)
/* 2249:     */   {
/* 2250:1817 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2251:1818 */     long function_pointer = caps.glCompressedMultiTexSubImage3DEXT;
/* 2252:1819 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2253:1820 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2254:1821 */     BufferChecks.checkDirect(data);
/* 2255:1822 */     nglCompressedMultiTexSubImage3DEXT(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2256:     */   }
/* 2257:     */   
/* 2258:     */   static native void nglCompressedMultiTexSubImage3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 2259:     */   
/* 2260:     */   public static void glCompressedMultiTexSubImage3DEXT(int texunit, int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int data_imageSize, long data_buffer_offset)
/* 2261:     */   {
/* 2262:1826 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2263:1827 */     long function_pointer = caps.glCompressedMultiTexSubImage3DEXT;
/* 2264:1828 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2265:1829 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2266:1830 */     nglCompressedMultiTexSubImage3DEXTBO(texunit, target, level, xoffset, yoffset, zoffset, width, height, depth, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2267:     */   }
/* 2268:     */   
/* 2269:     */   static native void nglCompressedMultiTexSubImage3DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, long paramLong1, long paramLong2);
/* 2270:     */   
/* 2271:     */   public static void glCompressedMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, ByteBuffer data)
/* 2272:     */   {
/* 2273:1835 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2274:1836 */     long function_pointer = caps.glCompressedMultiTexSubImage2DEXT;
/* 2275:1837 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2276:1838 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2277:1839 */     BufferChecks.checkDirect(data);
/* 2278:1840 */     nglCompressedMultiTexSubImage2DEXT(texunit, target, level, xoffset, yoffset, width, height, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2279:     */   }
/* 2280:     */   
/* 2281:     */   static native void nglCompressedMultiTexSubImage2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2282:     */   
/* 2283:     */   public static void glCompressedMultiTexSubImage2DEXT(int texunit, int target, int level, int xoffset, int yoffset, int width, int height, int format, int data_imageSize, long data_buffer_offset)
/* 2284:     */   {
/* 2285:1844 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2286:1845 */     long function_pointer = caps.glCompressedMultiTexSubImage2DEXT;
/* 2287:1846 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2288:1847 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2289:1848 */     nglCompressedMultiTexSubImage2DEXTBO(texunit, target, level, xoffset, yoffset, width, height, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2290:     */   }
/* 2291:     */   
/* 2292:     */   static native void nglCompressedMultiTexSubImage2DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 2293:     */   
/* 2294:     */   public static void glCompressedMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, ByteBuffer data)
/* 2295:     */   {
/* 2296:1853 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2297:1854 */     long function_pointer = caps.glCompressedMultiTexSubImage1DEXT;
/* 2298:1855 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2299:1856 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2300:1857 */     BufferChecks.checkDirect(data);
/* 2301:1858 */     nglCompressedMultiTexSubImage1DEXT(texunit, target, level, xoffset, width, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2302:     */   }
/* 2303:     */   
/* 2304:     */   static native void nglCompressedMultiTexSubImage1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2305:     */   
/* 2306:     */   public static void glCompressedMultiTexSubImage1DEXT(int texunit, int target, int level, int xoffset, int width, int format, int data_imageSize, long data_buffer_offset)
/* 2307:     */   {
/* 2308:1862 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2309:1863 */     long function_pointer = caps.glCompressedMultiTexSubImage1DEXT;
/* 2310:1864 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2311:1865 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2312:1866 */     nglCompressedMultiTexSubImage1DEXTBO(texunit, target, level, xoffset, width, format, data_imageSize, data_buffer_offset, function_pointer);
/* 2313:     */   }
/* 2314:     */   
/* 2315:     */   static native void nglCompressedMultiTexSubImage1DEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 2316:     */   
/* 2317:     */   public static void glGetCompressedMultiTexImageEXT(int texunit, int target, int level, ByteBuffer img)
/* 2318:     */   {
/* 2319:1871 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2320:1872 */     long function_pointer = caps.glGetCompressedMultiTexImageEXT;
/* 2321:1873 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2322:1874 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2323:1875 */     BufferChecks.checkDirect(img);
/* 2324:1876 */     nglGetCompressedMultiTexImageEXT(texunit, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2325:     */   }
/* 2326:     */   
/* 2327:     */   public static void glGetCompressedMultiTexImageEXT(int texunit, int target, int level, IntBuffer img)
/* 2328:     */   {
/* 2329:1879 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2330:1880 */     long function_pointer = caps.glGetCompressedMultiTexImageEXT;
/* 2331:1881 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2332:1882 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2333:1883 */     BufferChecks.checkDirect(img);
/* 2334:1884 */     nglGetCompressedMultiTexImageEXT(texunit, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2335:     */   }
/* 2336:     */   
/* 2337:     */   public static void glGetCompressedMultiTexImageEXT(int texunit, int target, int level, ShortBuffer img)
/* 2338:     */   {
/* 2339:1887 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2340:1888 */     long function_pointer = caps.glGetCompressedMultiTexImageEXT;
/* 2341:1889 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2342:1890 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2343:1891 */     BufferChecks.checkDirect(img);
/* 2344:1892 */     nglGetCompressedMultiTexImageEXT(texunit, target, level, MemoryUtil.getAddress(img), function_pointer);
/* 2345:     */   }
/* 2346:     */   
/* 2347:     */   static native void nglGetCompressedMultiTexImageEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2348:     */   
/* 2349:     */   public static void glGetCompressedMultiTexImageEXT(int texunit, int target, int level, long img_buffer_offset)
/* 2350:     */   {
/* 2351:1896 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2352:1897 */     long function_pointer = caps.glGetCompressedMultiTexImageEXT;
/* 2353:1898 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2354:1899 */     GLChecks.ensurePackPBOenabled(caps);
/* 2355:1900 */     nglGetCompressedMultiTexImageEXTBO(texunit, target, level, img_buffer_offset, function_pointer);
/* 2356:     */   }
/* 2357:     */   
/* 2358:     */   static native void nglGetCompressedMultiTexImageEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2359:     */   
/* 2360:     */   public static void glMatrixLoadTransposeEXT(int matrixMode, FloatBuffer m)
/* 2361:     */   {
/* 2362:1905 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2363:1906 */     long function_pointer = caps.glMatrixLoadTransposefEXT;
/* 2364:1907 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2365:1908 */     BufferChecks.checkBuffer(m, 16);
/* 2366:1909 */     nglMatrixLoadTransposefEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/* 2367:     */   }
/* 2368:     */   
/* 2369:     */   static native void nglMatrixLoadTransposefEXT(int paramInt, long paramLong1, long paramLong2);
/* 2370:     */   
/* 2371:     */   public static void glMatrixLoadTransposeEXT(int matrixMode, DoubleBuffer m)
/* 2372:     */   {
/* 2373:1914 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2374:1915 */     long function_pointer = caps.glMatrixLoadTransposedEXT;
/* 2375:1916 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2376:1917 */     BufferChecks.checkBuffer(m, 16);
/* 2377:1918 */     nglMatrixLoadTransposedEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/* 2378:     */   }
/* 2379:     */   
/* 2380:     */   static native void nglMatrixLoadTransposedEXT(int paramInt, long paramLong1, long paramLong2);
/* 2381:     */   
/* 2382:     */   public static void glMatrixMultTransposeEXT(int matrixMode, FloatBuffer m)
/* 2383:     */   {
/* 2384:1923 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2385:1924 */     long function_pointer = caps.glMatrixMultTransposefEXT;
/* 2386:1925 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2387:1926 */     BufferChecks.checkBuffer(m, 16);
/* 2388:1927 */     nglMatrixMultTransposefEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/* 2389:     */   }
/* 2390:     */   
/* 2391:     */   static native void nglMatrixMultTransposefEXT(int paramInt, long paramLong1, long paramLong2);
/* 2392:     */   
/* 2393:     */   public static void glMatrixMultTransposeEXT(int matrixMode, DoubleBuffer m)
/* 2394:     */   {
/* 2395:1932 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2396:1933 */     long function_pointer = caps.glMatrixMultTransposedEXT;
/* 2397:1934 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2398:1935 */     BufferChecks.checkBuffer(m, 16);
/* 2399:1936 */     nglMatrixMultTransposedEXT(matrixMode, MemoryUtil.getAddress(m), function_pointer);
/* 2400:     */   }
/* 2401:     */   
/* 2402:     */   static native void nglMatrixMultTransposedEXT(int paramInt, long paramLong1, long paramLong2);
/* 2403:     */   
/* 2404:     */   public static void glNamedBufferDataEXT(int buffer, long data_size, int usage)
/* 2405:     */   {
/* 2406:1941 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2407:1942 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2408:1943 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2409:1944 */     nglNamedBufferDataEXT(buffer, data_size, 0L, usage, function_pointer);
/* 2410:     */   }
/* 2411:     */   
/* 2412:     */   public static void glNamedBufferDataEXT(int buffer, ByteBuffer data, int usage)
/* 2413:     */   {
/* 2414:1947 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2415:1948 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2416:1949 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2417:1950 */     BufferChecks.checkDirect(data);
/* 2418:1951 */     nglNamedBufferDataEXT(buffer, data.remaining(), MemoryUtil.getAddress(data), usage, function_pointer);
/* 2419:     */   }
/* 2420:     */   
/* 2421:     */   public static void glNamedBufferDataEXT(int buffer, DoubleBuffer data, int usage)
/* 2422:     */   {
/* 2423:1954 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2424:1955 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2425:1956 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2426:1957 */     BufferChecks.checkDirect(data);
/* 2427:1958 */     nglNamedBufferDataEXT(buffer, data.remaining() << 3, MemoryUtil.getAddress(data), usage, function_pointer);
/* 2428:     */   }
/* 2429:     */   
/* 2430:     */   public static void glNamedBufferDataEXT(int buffer, FloatBuffer data, int usage)
/* 2431:     */   {
/* 2432:1961 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2433:1962 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2434:1963 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2435:1964 */     BufferChecks.checkDirect(data);
/* 2436:1965 */     nglNamedBufferDataEXT(buffer, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 2437:     */   }
/* 2438:     */   
/* 2439:     */   public static void glNamedBufferDataEXT(int buffer, IntBuffer data, int usage)
/* 2440:     */   {
/* 2441:1968 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2442:1969 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2443:1970 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2444:1971 */     BufferChecks.checkDirect(data);
/* 2445:1972 */     nglNamedBufferDataEXT(buffer, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 2446:     */   }
/* 2447:     */   
/* 2448:     */   public static void glNamedBufferDataEXT(int buffer, ShortBuffer data, int usage)
/* 2449:     */   {
/* 2450:1975 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2451:1976 */     long function_pointer = caps.glNamedBufferDataEXT;
/* 2452:1977 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2453:1978 */     BufferChecks.checkDirect(data);
/* 2454:1979 */     nglNamedBufferDataEXT(buffer, data.remaining() << 1, MemoryUtil.getAddress(data), usage, function_pointer);
/* 2455:     */   }
/* 2456:     */   
/* 2457:     */   static native void nglNamedBufferDataEXT(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 2458:     */   
/* 2459:     */   public static void glNamedBufferSubDataEXT(int buffer, long offset, ByteBuffer data)
/* 2460:     */   {
/* 2461:1984 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2462:1985 */     long function_pointer = caps.glNamedBufferSubDataEXT;
/* 2463:1986 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2464:1987 */     BufferChecks.checkDirect(data);
/* 2465:1988 */     nglNamedBufferSubDataEXT(buffer, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2466:     */   }
/* 2467:     */   
/* 2468:     */   public static void glNamedBufferSubDataEXT(int buffer, long offset, DoubleBuffer data)
/* 2469:     */   {
/* 2470:1991 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2471:1992 */     long function_pointer = caps.glNamedBufferSubDataEXT;
/* 2472:1993 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2473:1994 */     BufferChecks.checkDirect(data);
/* 2474:1995 */     nglNamedBufferSubDataEXT(buffer, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 2475:     */   }
/* 2476:     */   
/* 2477:     */   public static void glNamedBufferSubDataEXT(int buffer, long offset, FloatBuffer data)
/* 2478:     */   {
/* 2479:1998 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2480:1999 */     long function_pointer = caps.glNamedBufferSubDataEXT;
/* 2481:2000 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2482:2001 */     BufferChecks.checkDirect(data);
/* 2483:2002 */     nglNamedBufferSubDataEXT(buffer, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 2484:     */   }
/* 2485:     */   
/* 2486:     */   public static void glNamedBufferSubDataEXT(int buffer, long offset, IntBuffer data)
/* 2487:     */   {
/* 2488:2005 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2489:2006 */     long function_pointer = caps.glNamedBufferSubDataEXT;
/* 2490:2007 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2491:2008 */     BufferChecks.checkDirect(data);
/* 2492:2009 */     nglNamedBufferSubDataEXT(buffer, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 2493:     */   }
/* 2494:     */   
/* 2495:     */   public static void glNamedBufferSubDataEXT(int buffer, long offset, ShortBuffer data)
/* 2496:     */   {
/* 2497:2012 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2498:2013 */     long function_pointer = caps.glNamedBufferSubDataEXT;
/* 2499:2014 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2500:2015 */     BufferChecks.checkDirect(data);
/* 2501:2016 */     nglNamedBufferSubDataEXT(buffer, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 2502:     */   }
/* 2503:     */   
/* 2504:     */   static native void nglNamedBufferSubDataEXT(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 2505:     */   
/* 2506:     */   public static ByteBuffer glMapNamedBufferEXT(int buffer, int access, ByteBuffer old_buffer)
/* 2507:     */   {
/* 2508:2044 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2509:2045 */     long function_pointer = caps.glMapNamedBufferEXT;
/* 2510:2046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2511:2047 */     if (old_buffer != null) {
/* 2512:2048 */       BufferChecks.checkDirect(old_buffer);
/* 2513:     */     }
/* 2514:2049 */     ByteBuffer __result = nglMapNamedBufferEXT(buffer, access, GLChecks.getNamedBufferObjectSize(caps, buffer), old_buffer, function_pointer);
/* 2515:2050 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 2516:     */   }
/* 2517:     */   
/* 2518:     */   public static ByteBuffer glMapNamedBufferEXT(int buffer, int access, long length, ByteBuffer old_buffer)
/* 2519:     */   {
/* 2520:2076 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2521:2077 */     long function_pointer = caps.glMapNamedBufferEXT;
/* 2522:2078 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2523:2079 */     if (old_buffer != null) {
/* 2524:2080 */       BufferChecks.checkDirect(old_buffer);
/* 2525:     */     }
/* 2526:2081 */     ByteBuffer __result = nglMapNamedBufferEXT(buffer, access, length, old_buffer, function_pointer);
/* 2527:2082 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 2528:     */   }
/* 2529:     */   
/* 2530:     */   static native ByteBuffer nglMapNamedBufferEXT(int paramInt1, int paramInt2, long paramLong1, ByteBuffer paramByteBuffer, long paramLong2);
/* 2531:     */   
/* 2532:     */   public static boolean glUnmapNamedBufferEXT(int buffer)
/* 2533:     */   {
/* 2534:2087 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2535:2088 */     long function_pointer = caps.glUnmapNamedBufferEXT;
/* 2536:2089 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2537:2090 */     boolean __result = nglUnmapNamedBufferEXT(buffer, function_pointer);
/* 2538:2091 */     return __result;
/* 2539:     */   }
/* 2540:     */   
/* 2541:     */   static native boolean nglUnmapNamedBufferEXT(int paramInt, long paramLong);
/* 2542:     */   
/* 2543:     */   public static void glGetNamedBufferParameterEXT(int buffer, int pname, IntBuffer params)
/* 2544:     */   {
/* 2545:2096 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2546:2097 */     long function_pointer = caps.glGetNamedBufferParameterivEXT;
/* 2547:2098 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2548:2099 */     BufferChecks.checkBuffer(params, 4);
/* 2549:2100 */     nglGetNamedBufferParameterivEXT(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2550:     */   }
/* 2551:     */   
/* 2552:     */   static native void nglGetNamedBufferParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2553:     */   
/* 2554:     */   public static int glGetNamedBufferParameterEXT(int buffer, int pname)
/* 2555:     */   {
/* 2556:2106 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2557:2107 */     long function_pointer = caps.glGetNamedBufferParameterivEXT;
/* 2558:2108 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2559:2109 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 2560:2110 */     nglGetNamedBufferParameterivEXT(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2561:2111 */     return params.get(0);
/* 2562:     */   }
/* 2563:     */   
/* 2564:     */   public static ByteBuffer glGetNamedBufferPointerEXT(int buffer, int pname)
/* 2565:     */   {
/* 2566:2115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2567:2116 */     long function_pointer = caps.glGetNamedBufferPointervEXT;
/* 2568:2117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2569:2118 */     ByteBuffer __result = nglGetNamedBufferPointervEXT(buffer, pname, GLChecks.getNamedBufferObjectSize(caps, buffer), function_pointer);
/* 2570:2119 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 2571:     */   }
/* 2572:     */   
/* 2573:     */   static native ByteBuffer nglGetNamedBufferPointervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2574:     */   
/* 2575:     */   public static void glGetNamedBufferSubDataEXT(int buffer, long offset, ByteBuffer data)
/* 2576:     */   {
/* 2577:2124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2578:2125 */     long function_pointer = caps.glGetNamedBufferSubDataEXT;
/* 2579:2126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2580:2127 */     BufferChecks.checkDirect(data);
/* 2581:2128 */     nglGetNamedBufferSubDataEXT(buffer, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 2582:     */   }
/* 2583:     */   
/* 2584:     */   public static void glGetNamedBufferSubDataEXT(int buffer, long offset, DoubleBuffer data)
/* 2585:     */   {
/* 2586:2131 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2587:2132 */     long function_pointer = caps.glGetNamedBufferSubDataEXT;
/* 2588:2133 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2589:2134 */     BufferChecks.checkDirect(data);
/* 2590:2135 */     nglGetNamedBufferSubDataEXT(buffer, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 2591:     */   }
/* 2592:     */   
/* 2593:     */   public static void glGetNamedBufferSubDataEXT(int buffer, long offset, FloatBuffer data)
/* 2594:     */   {
/* 2595:2138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2596:2139 */     long function_pointer = caps.glGetNamedBufferSubDataEXT;
/* 2597:2140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2598:2141 */     BufferChecks.checkDirect(data);
/* 2599:2142 */     nglGetNamedBufferSubDataEXT(buffer, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 2600:     */   }
/* 2601:     */   
/* 2602:     */   public static void glGetNamedBufferSubDataEXT(int buffer, long offset, IntBuffer data)
/* 2603:     */   {
/* 2604:2145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2605:2146 */     long function_pointer = caps.glGetNamedBufferSubDataEXT;
/* 2606:2147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2607:2148 */     BufferChecks.checkDirect(data);
/* 2608:2149 */     nglGetNamedBufferSubDataEXT(buffer, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 2609:     */   }
/* 2610:     */   
/* 2611:     */   public static void glGetNamedBufferSubDataEXT(int buffer, long offset, ShortBuffer data)
/* 2612:     */   {
/* 2613:2152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2614:2153 */     long function_pointer = caps.glGetNamedBufferSubDataEXT;
/* 2615:2154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2616:2155 */     BufferChecks.checkDirect(data);
/* 2617:2156 */     nglGetNamedBufferSubDataEXT(buffer, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 2618:     */   }
/* 2619:     */   
/* 2620:     */   static native void nglGetNamedBufferSubDataEXT(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 2621:     */   
/* 2622:     */   public static void glProgramUniform1fEXT(int program, int location, float v0)
/* 2623:     */   {
/* 2624:2161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2625:2162 */     long function_pointer = caps.glProgramUniform1fEXT;
/* 2626:2163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2627:2164 */     nglProgramUniform1fEXT(program, location, v0, function_pointer);
/* 2628:     */   }
/* 2629:     */   
/* 2630:     */   static native void nglProgramUniform1fEXT(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 2631:     */   
/* 2632:     */   public static void glProgramUniform2fEXT(int program, int location, float v0, float v1)
/* 2633:     */   {
/* 2634:2169 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2635:2170 */     long function_pointer = caps.glProgramUniform2fEXT;
/* 2636:2171 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2637:2172 */     nglProgramUniform2fEXT(program, location, v0, v1, function_pointer);
/* 2638:     */   }
/* 2639:     */   
/* 2640:     */   static native void nglProgramUniform2fEXT(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, long paramLong);
/* 2641:     */   
/* 2642:     */   public static void glProgramUniform3fEXT(int program, int location, float v0, float v1, float v2)
/* 2643:     */   {
/* 2644:2177 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2645:2178 */     long function_pointer = caps.glProgramUniform3fEXT;
/* 2646:2179 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2647:2180 */     nglProgramUniform3fEXT(program, location, v0, v1, v2, function_pointer);
/* 2648:     */   }
/* 2649:     */   
/* 2650:     */   static native void nglProgramUniform3fEXT(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 2651:     */   
/* 2652:     */   public static void glProgramUniform4fEXT(int program, int location, float v0, float v1, float v2, float v3)
/* 2653:     */   {
/* 2654:2185 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2655:2186 */     long function_pointer = caps.glProgramUniform4fEXT;
/* 2656:2187 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2657:2188 */     nglProgramUniform4fEXT(program, location, v0, v1, v2, v3, function_pointer);
/* 2658:     */   }
/* 2659:     */   
/* 2660:     */   static native void nglProgramUniform4fEXT(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 2661:     */   
/* 2662:     */   public static void glProgramUniform1iEXT(int program, int location, int v0)
/* 2663:     */   {
/* 2664:2193 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2665:2194 */     long function_pointer = caps.glProgramUniform1iEXT;
/* 2666:2195 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2667:2196 */     nglProgramUniform1iEXT(program, location, v0, function_pointer);
/* 2668:     */   }
/* 2669:     */   
/* 2670:     */   static native void nglProgramUniform1iEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 2671:     */   
/* 2672:     */   public static void glProgramUniform2iEXT(int program, int location, int v0, int v1)
/* 2673:     */   {
/* 2674:2201 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2675:2202 */     long function_pointer = caps.glProgramUniform2iEXT;
/* 2676:2203 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2677:2204 */     nglProgramUniform2iEXT(program, location, v0, v1, function_pointer);
/* 2678:     */   }
/* 2679:     */   
/* 2680:     */   static native void nglProgramUniform2iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 2681:     */   
/* 2682:     */   public static void glProgramUniform3iEXT(int program, int location, int v0, int v1, int v2)
/* 2683:     */   {
/* 2684:2209 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2685:2210 */     long function_pointer = caps.glProgramUniform3iEXT;
/* 2686:2211 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2687:2212 */     nglProgramUniform3iEXT(program, location, v0, v1, v2, function_pointer);
/* 2688:     */   }
/* 2689:     */   
/* 2690:     */   static native void nglProgramUniform3iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 2691:     */   
/* 2692:     */   public static void glProgramUniform4iEXT(int program, int location, int v0, int v1, int v2, int v3)
/* 2693:     */   {
/* 2694:2217 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2695:2218 */     long function_pointer = caps.glProgramUniform4iEXT;
/* 2696:2219 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2697:2220 */     nglProgramUniform4iEXT(program, location, v0, v1, v2, v3, function_pointer);
/* 2698:     */   }
/* 2699:     */   
/* 2700:     */   static native void nglProgramUniform4iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 2701:     */   
/* 2702:     */   public static void glProgramUniform1EXT(int program, int location, FloatBuffer value)
/* 2703:     */   {
/* 2704:2225 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2705:2226 */     long function_pointer = caps.glProgramUniform1fvEXT;
/* 2706:2227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2707:2228 */     BufferChecks.checkDirect(value);
/* 2708:2229 */     nglProgramUniform1fvEXT(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 2709:     */   }
/* 2710:     */   
/* 2711:     */   static native void nglProgramUniform1fvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2712:     */   
/* 2713:     */   public static void glProgramUniform2EXT(int program, int location, FloatBuffer value)
/* 2714:     */   {
/* 2715:2234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2716:2235 */     long function_pointer = caps.glProgramUniform2fvEXT;
/* 2717:2236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2718:2237 */     BufferChecks.checkDirect(value);
/* 2719:2238 */     nglProgramUniform2fvEXT(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 2720:     */   }
/* 2721:     */   
/* 2722:     */   static native void nglProgramUniform2fvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2723:     */   
/* 2724:     */   public static void glProgramUniform3EXT(int program, int location, FloatBuffer value)
/* 2725:     */   {
/* 2726:2243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2727:2244 */     long function_pointer = caps.glProgramUniform3fvEXT;
/* 2728:2245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2729:2246 */     BufferChecks.checkDirect(value);
/* 2730:2247 */     nglProgramUniform3fvEXT(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 2731:     */   }
/* 2732:     */   
/* 2733:     */   static native void nglProgramUniform3fvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2734:     */   
/* 2735:     */   public static void glProgramUniform4EXT(int program, int location, FloatBuffer value)
/* 2736:     */   {
/* 2737:2252 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2738:2253 */     long function_pointer = caps.glProgramUniform4fvEXT;
/* 2739:2254 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2740:2255 */     BufferChecks.checkDirect(value);
/* 2741:2256 */     nglProgramUniform4fvEXT(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 2742:     */   }
/* 2743:     */   
/* 2744:     */   static native void nglProgramUniform4fvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2745:     */   
/* 2746:     */   public static void glProgramUniform1EXT(int program, int location, IntBuffer value)
/* 2747:     */   {
/* 2748:2261 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2749:2262 */     long function_pointer = caps.glProgramUniform1ivEXT;
/* 2750:2263 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2751:2264 */     BufferChecks.checkDirect(value);
/* 2752:2265 */     nglProgramUniform1ivEXT(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 2753:     */   }
/* 2754:     */   
/* 2755:     */   static native void nglProgramUniform1ivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2756:     */   
/* 2757:     */   public static void glProgramUniform2EXT(int program, int location, IntBuffer value)
/* 2758:     */   {
/* 2759:2270 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2760:2271 */     long function_pointer = caps.glProgramUniform2ivEXT;
/* 2761:2272 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2762:2273 */     BufferChecks.checkDirect(value);
/* 2763:2274 */     nglProgramUniform2ivEXT(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 2764:     */   }
/* 2765:     */   
/* 2766:     */   static native void nglProgramUniform2ivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2767:     */   
/* 2768:     */   public static void glProgramUniform3EXT(int program, int location, IntBuffer value)
/* 2769:     */   {
/* 2770:2279 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2771:2280 */     long function_pointer = caps.glProgramUniform3ivEXT;
/* 2772:2281 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2773:2282 */     BufferChecks.checkDirect(value);
/* 2774:2283 */     nglProgramUniform3ivEXT(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 2775:     */   }
/* 2776:     */   
/* 2777:     */   static native void nglProgramUniform3ivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2778:     */   
/* 2779:     */   public static void glProgramUniform4EXT(int program, int location, IntBuffer value)
/* 2780:     */   {
/* 2781:2288 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2782:2289 */     long function_pointer = caps.glProgramUniform4ivEXT;
/* 2783:2290 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2784:2291 */     BufferChecks.checkDirect(value);
/* 2785:2292 */     nglProgramUniform4ivEXT(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 2786:     */   }
/* 2787:     */   
/* 2788:     */   static native void nglProgramUniform4ivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2789:     */   
/* 2790:     */   public static void glProgramUniformMatrix2EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2791:     */   {
/* 2792:2297 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2793:2298 */     long function_pointer = caps.glProgramUniformMatrix2fvEXT;
/* 2794:2299 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2795:2300 */     BufferChecks.checkDirect(value);
/* 2796:2301 */     nglProgramUniformMatrix2fvEXT(program, location, value.remaining() >> 2, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2797:     */   }
/* 2798:     */   
/* 2799:     */   static native void nglProgramUniformMatrix2fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2800:     */   
/* 2801:     */   public static void glProgramUniformMatrix3EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2802:     */   {
/* 2803:2306 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2804:2307 */     long function_pointer = caps.glProgramUniformMatrix3fvEXT;
/* 2805:2308 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2806:2309 */     BufferChecks.checkDirect(value);
/* 2807:2310 */     nglProgramUniformMatrix3fvEXT(program, location, value.remaining() / 9, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2808:     */   }
/* 2809:     */   
/* 2810:     */   static native void nglProgramUniformMatrix3fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2811:     */   
/* 2812:     */   public static void glProgramUniformMatrix4EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2813:     */   {
/* 2814:2315 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2815:2316 */     long function_pointer = caps.glProgramUniformMatrix4fvEXT;
/* 2816:2317 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2817:2318 */     BufferChecks.checkDirect(value);
/* 2818:2319 */     nglProgramUniformMatrix4fvEXT(program, location, value.remaining() >> 4, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2819:     */   }
/* 2820:     */   
/* 2821:     */   static native void nglProgramUniformMatrix4fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2822:     */   
/* 2823:     */   public static void glProgramUniformMatrix2x3EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2824:     */   {
/* 2825:2324 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2826:2325 */     long function_pointer = caps.glProgramUniformMatrix2x3fvEXT;
/* 2827:2326 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2828:2327 */     BufferChecks.checkDirect(value);
/* 2829:2328 */     nglProgramUniformMatrix2x3fvEXT(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2830:     */   }
/* 2831:     */   
/* 2832:     */   static native void nglProgramUniformMatrix2x3fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2833:     */   
/* 2834:     */   public static void glProgramUniformMatrix3x2EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2835:     */   {
/* 2836:2333 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2837:2334 */     long function_pointer = caps.glProgramUniformMatrix3x2fvEXT;
/* 2838:2335 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2839:2336 */     BufferChecks.checkDirect(value);
/* 2840:2337 */     nglProgramUniformMatrix3x2fvEXT(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2841:     */   }
/* 2842:     */   
/* 2843:     */   static native void nglProgramUniformMatrix3x2fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2844:     */   
/* 2845:     */   public static void glProgramUniformMatrix2x4EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2846:     */   {
/* 2847:2342 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2848:2343 */     long function_pointer = caps.glProgramUniformMatrix2x4fvEXT;
/* 2849:2344 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2850:2345 */     BufferChecks.checkDirect(value);
/* 2851:2346 */     nglProgramUniformMatrix2x4fvEXT(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2852:     */   }
/* 2853:     */   
/* 2854:     */   static native void nglProgramUniformMatrix2x4fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2855:     */   
/* 2856:     */   public static void glProgramUniformMatrix4x2EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2857:     */   {
/* 2858:2351 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2859:2352 */     long function_pointer = caps.glProgramUniformMatrix4x2fvEXT;
/* 2860:2353 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2861:2354 */     BufferChecks.checkDirect(value);
/* 2862:2355 */     nglProgramUniformMatrix4x2fvEXT(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2863:     */   }
/* 2864:     */   
/* 2865:     */   static native void nglProgramUniformMatrix4x2fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2866:     */   
/* 2867:     */   public static void glProgramUniformMatrix3x4EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2868:     */   {
/* 2869:2360 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2870:2361 */     long function_pointer = caps.glProgramUniformMatrix3x4fvEXT;
/* 2871:2362 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2872:2363 */     BufferChecks.checkDirect(value);
/* 2873:2364 */     nglProgramUniformMatrix3x4fvEXT(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2874:     */   }
/* 2875:     */   
/* 2876:     */   static native void nglProgramUniformMatrix3x4fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2877:     */   
/* 2878:     */   public static void glProgramUniformMatrix4x3EXT(int program, int location, boolean transpose, FloatBuffer value)
/* 2879:     */   {
/* 2880:2369 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2881:2370 */     long function_pointer = caps.glProgramUniformMatrix4x3fvEXT;
/* 2882:2371 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2883:2372 */     BufferChecks.checkDirect(value);
/* 2884:2373 */     nglProgramUniformMatrix4x3fvEXT(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 2885:     */   }
/* 2886:     */   
/* 2887:     */   static native void nglProgramUniformMatrix4x3fvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 2888:     */   
/* 2889:     */   public static void glTextureBufferEXT(int texture, int target, int internalformat, int buffer)
/* 2890:     */   {
/* 2891:2378 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2892:2379 */     long function_pointer = caps.glTextureBufferEXT;
/* 2893:2380 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2894:2381 */     nglTextureBufferEXT(texture, target, internalformat, buffer, function_pointer);
/* 2895:     */   }
/* 2896:     */   
/* 2897:     */   static native void nglTextureBufferEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 2898:     */   
/* 2899:     */   public static void glMultiTexBufferEXT(int texunit, int target, int internalformat, int buffer)
/* 2900:     */   {
/* 2901:2386 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2902:2387 */     long function_pointer = caps.glMultiTexBufferEXT;
/* 2903:2388 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2904:2389 */     nglMultiTexBufferEXT(texunit, target, internalformat, buffer, function_pointer);
/* 2905:     */   }
/* 2906:     */   
/* 2907:     */   static native void nglMultiTexBufferEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 2908:     */   
/* 2909:     */   public static void glTextureParameterIEXT(int texture, int target, int pname, IntBuffer params)
/* 2910:     */   {
/* 2911:2394 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2912:2395 */     long function_pointer = caps.glTextureParameterIivEXT;
/* 2913:2396 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2914:2397 */     BufferChecks.checkBuffer(params, 4);
/* 2915:2398 */     nglTextureParameterIivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2916:     */   }
/* 2917:     */   
/* 2918:     */   static native void nglTextureParameterIivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2919:     */   
/* 2920:     */   public static void glTextureParameterIEXT(int texture, int target, int pname, int param)
/* 2921:     */   {
/* 2922:2404 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2923:2405 */     long function_pointer = caps.glTextureParameterIivEXT;
/* 2924:2406 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2925:2407 */     nglTextureParameterIivEXT(texture, target, pname, APIUtil.getInt(caps, param), function_pointer);
/* 2926:     */   }
/* 2927:     */   
/* 2928:     */   public static void glTextureParameterIuEXT(int texture, int target, int pname, IntBuffer params)
/* 2929:     */   {
/* 2930:2411 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2931:2412 */     long function_pointer = caps.glTextureParameterIuivEXT;
/* 2932:2413 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2933:2414 */     BufferChecks.checkBuffer(params, 4);
/* 2934:2415 */     nglTextureParameterIuivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2935:     */   }
/* 2936:     */   
/* 2937:     */   static native void nglTextureParameterIuivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2938:     */   
/* 2939:     */   public static void glTextureParameterIuEXT(int texture, int target, int pname, int param)
/* 2940:     */   {
/* 2941:2421 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2942:2422 */     long function_pointer = caps.glTextureParameterIuivEXT;
/* 2943:2423 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2944:2424 */     nglTextureParameterIuivEXT(texture, target, pname, APIUtil.getInt(caps, param), function_pointer);
/* 2945:     */   }
/* 2946:     */   
/* 2947:     */   public static void glGetTextureParameterIEXT(int texture, int target, int pname, IntBuffer params)
/* 2948:     */   {
/* 2949:2428 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2950:2429 */     long function_pointer = caps.glGetTextureParameterIivEXT;
/* 2951:2430 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2952:2431 */     BufferChecks.checkBuffer(params, 4);
/* 2953:2432 */     nglGetTextureParameterIivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2954:     */   }
/* 2955:     */   
/* 2956:     */   static native void nglGetTextureParameterIivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2957:     */   
/* 2958:     */   public static int glGetTextureParameterIiEXT(int texture, int target, int pname)
/* 2959:     */   {
/* 2960:2438 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2961:2439 */     long function_pointer = caps.glGetTextureParameterIivEXT;
/* 2962:2440 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2963:2441 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 2964:2442 */     nglGetTextureParameterIivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2965:2443 */     return params.get(0);
/* 2966:     */   }
/* 2967:     */   
/* 2968:     */   public static void glGetTextureParameterIuEXT(int texture, int target, int pname, IntBuffer params)
/* 2969:     */   {
/* 2970:2447 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2971:2448 */     long function_pointer = caps.glGetTextureParameterIuivEXT;
/* 2972:2449 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2973:2450 */     BufferChecks.checkBuffer(params, 4);
/* 2974:2451 */     nglGetTextureParameterIuivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2975:     */   }
/* 2976:     */   
/* 2977:     */   static native void nglGetTextureParameterIuivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2978:     */   
/* 2979:     */   public static int glGetTextureParameterIuiEXT(int texture, int target, int pname)
/* 2980:     */   {
/* 2981:2457 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2982:2458 */     long function_pointer = caps.glGetTextureParameterIuivEXT;
/* 2983:2459 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2984:2460 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 2985:2461 */     nglGetTextureParameterIuivEXT(texture, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2986:2462 */     return params.get(0);
/* 2987:     */   }
/* 2988:     */   
/* 2989:     */   public static void glMultiTexParameterIEXT(int texunit, int target, int pname, IntBuffer params)
/* 2990:     */   {
/* 2991:2466 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2992:2467 */     long function_pointer = caps.glMultiTexParameterIivEXT;
/* 2993:2468 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2994:2469 */     BufferChecks.checkBuffer(params, 4);
/* 2995:2470 */     nglMultiTexParameterIivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2996:     */   }
/* 2997:     */   
/* 2998:     */   static native void nglMultiTexParameterIivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2999:     */   
/* 3000:     */   public static void glMultiTexParameterIEXT(int texunit, int target, int pname, int param)
/* 3001:     */   {
/* 3002:2476 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3003:2477 */     long function_pointer = caps.glMultiTexParameterIivEXT;
/* 3004:2478 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3005:2479 */     nglMultiTexParameterIivEXT(texunit, target, pname, APIUtil.getInt(caps, param), function_pointer);
/* 3006:     */   }
/* 3007:     */   
/* 3008:     */   public static void glMultiTexParameterIuEXT(int texunit, int target, int pname, IntBuffer params)
/* 3009:     */   {
/* 3010:2483 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3011:2484 */     long function_pointer = caps.glMultiTexParameterIuivEXT;
/* 3012:2485 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3013:2486 */     BufferChecks.checkBuffer(params, 4);
/* 3014:2487 */     nglMultiTexParameterIuivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3015:     */   }
/* 3016:     */   
/* 3017:     */   static native void nglMultiTexParameterIuivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3018:     */   
/* 3019:     */   public static void glMultiTexParameterIuEXT(int texunit, int target, int pname, int param)
/* 3020:     */   {
/* 3021:2493 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3022:2494 */     long function_pointer = caps.glMultiTexParameterIuivEXT;
/* 3023:2495 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3024:2496 */     nglMultiTexParameterIuivEXT(texunit, target, pname, APIUtil.getInt(caps, param), function_pointer);
/* 3025:     */   }
/* 3026:     */   
/* 3027:     */   public static void glGetMultiTexParameterIEXT(int texunit, int target, int pname, IntBuffer params)
/* 3028:     */   {
/* 3029:2500 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3030:2501 */     long function_pointer = caps.glGetMultiTexParameterIivEXT;
/* 3031:2502 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3032:2503 */     BufferChecks.checkBuffer(params, 4);
/* 3033:2504 */     nglGetMultiTexParameterIivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3034:     */   }
/* 3035:     */   
/* 3036:     */   static native void nglGetMultiTexParameterIivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3037:     */   
/* 3038:     */   public static int glGetMultiTexParameterIiEXT(int texunit, int target, int pname)
/* 3039:     */   {
/* 3040:2510 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3041:2511 */     long function_pointer = caps.glGetMultiTexParameterIivEXT;
/* 3042:2512 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3043:2513 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 3044:2514 */     nglGetMultiTexParameterIivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3045:2515 */     return params.get(0);
/* 3046:     */   }
/* 3047:     */   
/* 3048:     */   public static void glGetMultiTexParameterIuEXT(int texunit, int target, int pname, IntBuffer params)
/* 3049:     */   {
/* 3050:2519 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3051:2520 */     long function_pointer = caps.glGetMultiTexParameterIuivEXT;
/* 3052:2521 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3053:2522 */     BufferChecks.checkBuffer(params, 4);
/* 3054:2523 */     nglGetMultiTexParameterIuivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3055:     */   }
/* 3056:     */   
/* 3057:     */   static native void nglGetMultiTexParameterIuivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3058:     */   
/* 3059:     */   public static int glGetMultiTexParameterIuiEXT(int texunit, int target, int pname)
/* 3060:     */   {
/* 3061:2529 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3062:2530 */     long function_pointer = caps.glGetMultiTexParameterIuivEXT;
/* 3063:2531 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3064:2532 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 3065:2533 */     nglGetMultiTexParameterIuivEXT(texunit, target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3066:2534 */     return params.get(0);
/* 3067:     */   }
/* 3068:     */   
/* 3069:     */   public static void glProgramUniform1uiEXT(int program, int location, int v0)
/* 3070:     */   {
/* 3071:2538 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3072:2539 */     long function_pointer = caps.glProgramUniform1uiEXT;
/* 3073:2540 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3074:2541 */     nglProgramUniform1uiEXT(program, location, v0, function_pointer);
/* 3075:     */   }
/* 3076:     */   
/* 3077:     */   static native void nglProgramUniform1uiEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3078:     */   
/* 3079:     */   public static void glProgramUniform2uiEXT(int program, int location, int v0, int v1)
/* 3080:     */   {
/* 3081:2546 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3082:2547 */     long function_pointer = caps.glProgramUniform2uiEXT;
/* 3083:2548 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3084:2549 */     nglProgramUniform2uiEXT(program, location, v0, v1, function_pointer);
/* 3085:     */   }
/* 3086:     */   
/* 3087:     */   static native void nglProgramUniform2uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3088:     */   
/* 3089:     */   public static void glProgramUniform3uiEXT(int program, int location, int v0, int v1, int v2)
/* 3090:     */   {
/* 3091:2554 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3092:2555 */     long function_pointer = caps.glProgramUniform3uiEXT;
/* 3093:2556 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3094:2557 */     nglProgramUniform3uiEXT(program, location, v0, v1, v2, function_pointer);
/* 3095:     */   }
/* 3096:     */   
/* 3097:     */   static native void nglProgramUniform3uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3098:     */   
/* 3099:     */   public static void glProgramUniform4uiEXT(int program, int location, int v0, int v1, int v2, int v3)
/* 3100:     */   {
/* 3101:2562 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3102:2563 */     long function_pointer = caps.glProgramUniform4uiEXT;
/* 3103:2564 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3104:2565 */     nglProgramUniform4uiEXT(program, location, v0, v1, v2, v3, function_pointer);
/* 3105:     */   }
/* 3106:     */   
/* 3107:     */   static native void nglProgramUniform4uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 3108:     */   
/* 3109:     */   public static void glProgramUniform1uEXT(int program, int location, IntBuffer value)
/* 3110:     */   {
/* 3111:2570 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3112:2571 */     long function_pointer = caps.glProgramUniform1uivEXT;
/* 3113:2572 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3114:2573 */     BufferChecks.checkDirect(value);
/* 3115:2574 */     nglProgramUniform1uivEXT(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 3116:     */   }
/* 3117:     */   
/* 3118:     */   static native void nglProgramUniform1uivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3119:     */   
/* 3120:     */   public static void glProgramUniform2uEXT(int program, int location, IntBuffer value)
/* 3121:     */   {
/* 3122:2579 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3123:2580 */     long function_pointer = caps.glProgramUniform2uivEXT;
/* 3124:2581 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3125:2582 */     BufferChecks.checkDirect(value);
/* 3126:2583 */     nglProgramUniform2uivEXT(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 3127:     */   }
/* 3128:     */   
/* 3129:     */   static native void nglProgramUniform2uivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3130:     */   
/* 3131:     */   public static void glProgramUniform3uEXT(int program, int location, IntBuffer value)
/* 3132:     */   {
/* 3133:2588 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3134:2589 */     long function_pointer = caps.glProgramUniform3uivEXT;
/* 3135:2590 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3136:2591 */     BufferChecks.checkDirect(value);
/* 3137:2592 */     nglProgramUniform3uivEXT(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 3138:     */   }
/* 3139:     */   
/* 3140:     */   static native void nglProgramUniform3uivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3141:     */   
/* 3142:     */   public static void glProgramUniform4uEXT(int program, int location, IntBuffer value)
/* 3143:     */   {
/* 3144:2597 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3145:2598 */     long function_pointer = caps.glProgramUniform4uivEXT;
/* 3146:2599 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3147:2600 */     BufferChecks.checkDirect(value);
/* 3148:2601 */     nglProgramUniform4uivEXT(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 3149:     */   }
/* 3150:     */   
/* 3151:     */   static native void nglProgramUniform4uivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3152:     */   
/* 3153:     */   public static void glNamedProgramLocalParameters4EXT(int program, int target, int index, FloatBuffer params)
/* 3154:     */   {
/* 3155:2606 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3156:2607 */     long function_pointer = caps.glNamedProgramLocalParameters4fvEXT;
/* 3157:2608 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3158:2609 */     BufferChecks.checkDirect(params);
/* 3159:2610 */     nglNamedProgramLocalParameters4fvEXT(program, target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 3160:     */   }
/* 3161:     */   
/* 3162:     */   static native void nglNamedProgramLocalParameters4fvEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3163:     */   
/* 3164:     */   public static void glNamedProgramLocalParameterI4iEXT(int program, int target, int index, int x, int y, int z, int w)
/* 3165:     */   {
/* 3166:2615 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3167:2616 */     long function_pointer = caps.glNamedProgramLocalParameterI4iEXT;
/* 3168:2617 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3169:2618 */     nglNamedProgramLocalParameterI4iEXT(program, target, index, x, y, z, w, function_pointer);
/* 3170:     */   }
/* 3171:     */   
/* 3172:     */   static native void nglNamedProgramLocalParameterI4iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/* 3173:     */   
/* 3174:     */   public static void glNamedProgramLocalParameterI4EXT(int program, int target, int index, IntBuffer params)
/* 3175:     */   {
/* 3176:2623 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3177:2624 */     long function_pointer = caps.glNamedProgramLocalParameterI4ivEXT;
/* 3178:2625 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3179:2626 */     BufferChecks.checkBuffer(params, 4);
/* 3180:2627 */     nglNamedProgramLocalParameterI4ivEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 3181:     */   }
/* 3182:     */   
/* 3183:     */   static native void nglNamedProgramLocalParameterI4ivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3184:     */   
/* 3185:     */   public static void glNamedProgramLocalParametersI4EXT(int program, int target, int index, IntBuffer params)
/* 3186:     */   {
/* 3187:2632 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3188:2633 */     long function_pointer = caps.glNamedProgramLocalParametersI4ivEXT;
/* 3189:2634 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3190:2635 */     BufferChecks.checkDirect(params);
/* 3191:2636 */     nglNamedProgramLocalParametersI4ivEXT(program, target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 3192:     */   }
/* 3193:     */   
/* 3194:     */   static native void nglNamedProgramLocalParametersI4ivEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3195:     */   
/* 3196:     */   public static void glNamedProgramLocalParameterI4uiEXT(int program, int target, int index, int x, int y, int z, int w)
/* 3197:     */   {
/* 3198:2641 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3199:2642 */     long function_pointer = caps.glNamedProgramLocalParameterI4uiEXT;
/* 3200:2643 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3201:2644 */     nglNamedProgramLocalParameterI4uiEXT(program, target, index, x, y, z, w, function_pointer);
/* 3202:     */   }
/* 3203:     */   
/* 3204:     */   static native void nglNamedProgramLocalParameterI4uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/* 3205:     */   
/* 3206:     */   public static void glNamedProgramLocalParameterI4uEXT(int program, int target, int index, IntBuffer params)
/* 3207:     */   {
/* 3208:2649 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3209:2650 */     long function_pointer = caps.glNamedProgramLocalParameterI4uivEXT;
/* 3210:2651 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3211:2652 */     BufferChecks.checkBuffer(params, 4);
/* 3212:2653 */     nglNamedProgramLocalParameterI4uivEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 3213:     */   }
/* 3214:     */   
/* 3215:     */   static native void nglNamedProgramLocalParameterI4uivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3216:     */   
/* 3217:     */   public static void glNamedProgramLocalParametersI4uEXT(int program, int target, int index, IntBuffer params)
/* 3218:     */   {
/* 3219:2658 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3220:2659 */     long function_pointer = caps.glNamedProgramLocalParametersI4uivEXT;
/* 3221:2660 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3222:2661 */     BufferChecks.checkDirect(params);
/* 3223:2662 */     nglNamedProgramLocalParametersI4uivEXT(program, target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 3224:     */   }
/* 3225:     */   
/* 3226:     */   static native void nglNamedProgramLocalParametersI4uivEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3227:     */   
/* 3228:     */   public static void glGetNamedProgramLocalParameterIEXT(int program, int target, int index, IntBuffer params)
/* 3229:     */   {
/* 3230:2667 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3231:2668 */     long function_pointer = caps.glGetNamedProgramLocalParameterIivEXT;
/* 3232:2669 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3233:2670 */     BufferChecks.checkBuffer(params, 4);
/* 3234:2671 */     nglGetNamedProgramLocalParameterIivEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 3235:     */   }
/* 3236:     */   
/* 3237:     */   static native void nglGetNamedProgramLocalParameterIivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3238:     */   
/* 3239:     */   public static void glGetNamedProgramLocalParameterIuEXT(int program, int target, int index, IntBuffer params)
/* 3240:     */   {
/* 3241:2676 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3242:2677 */     long function_pointer = caps.glGetNamedProgramLocalParameterIuivEXT;
/* 3243:2678 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3244:2679 */     BufferChecks.checkBuffer(params, 4);
/* 3245:2680 */     nglGetNamedProgramLocalParameterIuivEXT(program, target, index, MemoryUtil.getAddress(params), function_pointer);
/* 3246:     */   }
/* 3247:     */   
/* 3248:     */   static native void nglGetNamedProgramLocalParameterIuivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3249:     */   
/* 3250:     */   public static void glNamedRenderbufferStorageEXT(int renderbuffer, int internalformat, int width, int height)
/* 3251:     */   {
/* 3252:2685 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3253:2686 */     long function_pointer = caps.glNamedRenderbufferStorageEXT;
/* 3254:2687 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3255:2688 */     nglNamedRenderbufferStorageEXT(renderbuffer, internalformat, width, height, function_pointer);
/* 3256:     */   }
/* 3257:     */   
/* 3258:     */   static native void nglNamedRenderbufferStorageEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3259:     */   
/* 3260:     */   public static void glGetNamedRenderbufferParameterEXT(int renderbuffer, int pname, IntBuffer params)
/* 3261:     */   {
/* 3262:2693 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3263:2694 */     long function_pointer = caps.glGetNamedRenderbufferParameterivEXT;
/* 3264:2695 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3265:2696 */     BufferChecks.checkBuffer(params, 4);
/* 3266:2697 */     nglGetNamedRenderbufferParameterivEXT(renderbuffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3267:     */   }
/* 3268:     */   
/* 3269:     */   static native void nglGetNamedRenderbufferParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3270:     */   
/* 3271:     */   public static int glGetNamedRenderbufferParameterEXT(int renderbuffer, int pname)
/* 3272:     */   {
/* 3273:2703 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3274:2704 */     long function_pointer = caps.glGetNamedRenderbufferParameterivEXT;
/* 3275:2705 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3276:2706 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 3277:2707 */     nglGetNamedRenderbufferParameterivEXT(renderbuffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3278:2708 */     return params.get(0);
/* 3279:     */   }
/* 3280:     */   
/* 3281:     */   public static void glNamedRenderbufferStorageMultisampleEXT(int renderbuffer, int samples, int internalformat, int width, int height)
/* 3282:     */   {
/* 3283:2712 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3284:2713 */     long function_pointer = caps.glNamedRenderbufferStorageMultisampleEXT;
/* 3285:2714 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3286:2715 */     nglNamedRenderbufferStorageMultisampleEXT(renderbuffer, samples, internalformat, width, height, function_pointer);
/* 3287:     */   }
/* 3288:     */   
/* 3289:     */   static native void nglNamedRenderbufferStorageMultisampleEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3290:     */   
/* 3291:     */   public static void glNamedRenderbufferStorageMultisampleCoverageEXT(int renderbuffer, int coverageSamples, int colorSamples, int internalformat, int width, int height)
/* 3292:     */   {
/* 3293:2720 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3294:2721 */     long function_pointer = caps.glNamedRenderbufferStorageMultisampleCoverageEXT;
/* 3295:2722 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3296:2723 */     nglNamedRenderbufferStorageMultisampleCoverageEXT(renderbuffer, coverageSamples, colorSamples, internalformat, width, height, function_pointer);
/* 3297:     */   }
/* 3298:     */   
/* 3299:     */   static native void nglNamedRenderbufferStorageMultisampleCoverageEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 3300:     */   
/* 3301:     */   public static int glCheckNamedFramebufferStatusEXT(int framebuffer, int target)
/* 3302:     */   {
/* 3303:2728 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3304:2729 */     long function_pointer = caps.glCheckNamedFramebufferStatusEXT;
/* 3305:2730 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3306:2731 */     int __result = nglCheckNamedFramebufferStatusEXT(framebuffer, target, function_pointer);
/* 3307:2732 */     return __result;
/* 3308:     */   }
/* 3309:     */   
/* 3310:     */   static native int nglCheckNamedFramebufferStatusEXT(int paramInt1, int paramInt2, long paramLong);
/* 3311:     */   
/* 3312:     */   public static void glNamedFramebufferTexture1DEXT(int framebuffer, int attachment, int textarget, int texture, int level)
/* 3313:     */   {
/* 3314:2737 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3315:2738 */     long function_pointer = caps.glNamedFramebufferTexture1DEXT;
/* 3316:2739 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3317:2740 */     nglNamedFramebufferTexture1DEXT(framebuffer, attachment, textarget, texture, level, function_pointer);
/* 3318:     */   }
/* 3319:     */   
/* 3320:     */   static native void nglNamedFramebufferTexture1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3321:     */   
/* 3322:     */   public static void glNamedFramebufferTexture2DEXT(int framebuffer, int attachment, int textarget, int texture, int level)
/* 3323:     */   {
/* 3324:2745 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3325:2746 */     long function_pointer = caps.glNamedFramebufferTexture2DEXT;
/* 3326:2747 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3327:2748 */     nglNamedFramebufferTexture2DEXT(framebuffer, attachment, textarget, texture, level, function_pointer);
/* 3328:     */   }
/* 3329:     */   
/* 3330:     */   static native void nglNamedFramebufferTexture2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3331:     */   
/* 3332:     */   public static void glNamedFramebufferTexture3DEXT(int framebuffer, int attachment, int textarget, int texture, int level, int zoffset)
/* 3333:     */   {
/* 3334:2753 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3335:2754 */     long function_pointer = caps.glNamedFramebufferTexture3DEXT;
/* 3336:2755 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3337:2756 */     nglNamedFramebufferTexture3DEXT(framebuffer, attachment, textarget, texture, level, zoffset, function_pointer);
/* 3338:     */   }
/* 3339:     */   
/* 3340:     */   static native void nglNamedFramebufferTexture3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 3341:     */   
/* 3342:     */   public static void glNamedFramebufferRenderbufferEXT(int framebuffer, int attachment, int renderbuffertarget, int renderbuffer)
/* 3343:     */   {
/* 3344:2761 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3345:2762 */     long function_pointer = caps.glNamedFramebufferRenderbufferEXT;
/* 3346:2763 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3347:2764 */     nglNamedFramebufferRenderbufferEXT(framebuffer, attachment, renderbuffertarget, renderbuffer, function_pointer);
/* 3348:     */   }
/* 3349:     */   
/* 3350:     */   static native void nglNamedFramebufferRenderbufferEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3351:     */   
/* 3352:     */   public static void glGetNamedFramebufferAttachmentParameterEXT(int framebuffer, int attachment, int pname, IntBuffer params)
/* 3353:     */   {
/* 3354:2769 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3355:2770 */     long function_pointer = caps.glGetNamedFramebufferAttachmentParameterivEXT;
/* 3356:2771 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3357:2772 */     BufferChecks.checkBuffer(params, 4);
/* 3358:2773 */     nglGetNamedFramebufferAttachmentParameterivEXT(framebuffer, attachment, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3359:     */   }
/* 3360:     */   
/* 3361:     */   static native void nglGetNamedFramebufferAttachmentParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3362:     */   
/* 3363:     */   public static int glGetNamedFramebufferAttachmentParameterEXT(int framebuffer, int attachment, int pname)
/* 3364:     */   {
/* 3365:2779 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3366:2780 */     long function_pointer = caps.glGetNamedFramebufferAttachmentParameterivEXT;
/* 3367:2781 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3368:2782 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 3369:2783 */     nglGetNamedFramebufferAttachmentParameterivEXT(framebuffer, attachment, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3370:2784 */     return params.get(0);
/* 3371:     */   }
/* 3372:     */   
/* 3373:     */   public static void glGenerateTextureMipmapEXT(int texture, int target)
/* 3374:     */   {
/* 3375:2788 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3376:2789 */     long function_pointer = caps.glGenerateTextureMipmapEXT;
/* 3377:2790 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3378:2791 */     nglGenerateTextureMipmapEXT(texture, target, function_pointer);
/* 3379:     */   }
/* 3380:     */   
/* 3381:     */   static native void nglGenerateTextureMipmapEXT(int paramInt1, int paramInt2, long paramLong);
/* 3382:     */   
/* 3383:     */   public static void glGenerateMultiTexMipmapEXT(int texunit, int target)
/* 3384:     */   {
/* 3385:2796 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3386:2797 */     long function_pointer = caps.glGenerateMultiTexMipmapEXT;
/* 3387:2798 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3388:2799 */     nglGenerateMultiTexMipmapEXT(texunit, target, function_pointer);
/* 3389:     */   }
/* 3390:     */   
/* 3391:     */   static native void nglGenerateMultiTexMipmapEXT(int paramInt1, int paramInt2, long paramLong);
/* 3392:     */   
/* 3393:     */   public static void glFramebufferDrawBufferEXT(int framebuffer, int mode)
/* 3394:     */   {
/* 3395:2804 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3396:2805 */     long function_pointer = caps.glFramebufferDrawBufferEXT;
/* 3397:2806 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3398:2807 */     nglFramebufferDrawBufferEXT(framebuffer, mode, function_pointer);
/* 3399:     */   }
/* 3400:     */   
/* 3401:     */   static native void nglFramebufferDrawBufferEXT(int paramInt1, int paramInt2, long paramLong);
/* 3402:     */   
/* 3403:     */   public static void glFramebufferDrawBuffersEXT(int framebuffer, IntBuffer bufs)
/* 3404:     */   {
/* 3405:2812 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3406:2813 */     long function_pointer = caps.glFramebufferDrawBuffersEXT;
/* 3407:2814 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3408:2815 */     BufferChecks.checkDirect(bufs);
/* 3409:2816 */     nglFramebufferDrawBuffersEXT(framebuffer, bufs.remaining(), MemoryUtil.getAddress(bufs), function_pointer);
/* 3410:     */   }
/* 3411:     */   
/* 3412:     */   static native void nglFramebufferDrawBuffersEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3413:     */   
/* 3414:     */   public static void glFramebufferReadBufferEXT(int framebuffer, int mode)
/* 3415:     */   {
/* 3416:2821 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3417:2822 */     long function_pointer = caps.glFramebufferReadBufferEXT;
/* 3418:2823 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3419:2824 */     nglFramebufferReadBufferEXT(framebuffer, mode, function_pointer);
/* 3420:     */   }
/* 3421:     */   
/* 3422:     */   static native void nglFramebufferReadBufferEXT(int paramInt1, int paramInt2, long paramLong);
/* 3423:     */   
/* 3424:     */   public static void glGetFramebufferParameterEXT(int framebuffer, int pname, IntBuffer param)
/* 3425:     */   {
/* 3426:2829 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3427:2830 */     long function_pointer = caps.glGetFramebufferParameterivEXT;
/* 3428:2831 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3429:2832 */     BufferChecks.checkBuffer(param, 4);
/* 3430:2833 */     nglGetFramebufferParameterivEXT(framebuffer, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3431:     */   }
/* 3432:     */   
/* 3433:     */   static native void nglGetFramebufferParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3434:     */   
/* 3435:     */   public static int glGetFramebufferParameterEXT(int framebuffer, int pname)
/* 3436:     */   {
/* 3437:2839 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3438:2840 */     long function_pointer = caps.glGetFramebufferParameterivEXT;
/* 3439:2841 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3440:2842 */     IntBuffer param = APIUtil.getBufferInt(caps);
/* 3441:2843 */     nglGetFramebufferParameterivEXT(framebuffer, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3442:2844 */     return param.get(0);
/* 3443:     */   }
/* 3444:     */   
/* 3445:     */   public static void glNamedCopyBufferSubDataEXT(int readBuffer, int writeBuffer, long readoffset, long writeoffset, long size)
/* 3446:     */   {
/* 3447:2848 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3448:2849 */     long function_pointer = caps.glNamedCopyBufferSubDataEXT;
/* 3449:2850 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3450:2851 */     nglNamedCopyBufferSubDataEXT(readBuffer, writeBuffer, readoffset, writeoffset, size, function_pointer);
/* 3451:     */   }
/* 3452:     */   
/* 3453:     */   static native void nglNamedCopyBufferSubDataEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 3454:     */   
/* 3455:     */   public static void glNamedFramebufferTextureEXT(int framebuffer, int attachment, int texture, int level)
/* 3456:     */   {
/* 3457:2856 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3458:2857 */     long function_pointer = caps.glNamedFramebufferTextureEXT;
/* 3459:2858 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3460:2859 */     nglNamedFramebufferTextureEXT(framebuffer, attachment, texture, level, function_pointer);
/* 3461:     */   }
/* 3462:     */   
/* 3463:     */   static native void nglNamedFramebufferTextureEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3464:     */   
/* 3465:     */   public static void glNamedFramebufferTextureLayerEXT(int framebuffer, int attachment, int texture, int level, int layer)
/* 3466:     */   {
/* 3467:2864 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3468:2865 */     long function_pointer = caps.glNamedFramebufferTextureLayerEXT;
/* 3469:2866 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3470:2867 */     nglNamedFramebufferTextureLayerEXT(framebuffer, attachment, texture, level, layer, function_pointer);
/* 3471:     */   }
/* 3472:     */   
/* 3473:     */   static native void nglNamedFramebufferTextureLayerEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3474:     */   
/* 3475:     */   public static void glNamedFramebufferTextureFaceEXT(int framebuffer, int attachment, int texture, int level, int face)
/* 3476:     */   {
/* 3477:2872 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3478:2873 */     long function_pointer = caps.glNamedFramebufferTextureFaceEXT;
/* 3479:2874 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3480:2875 */     nglNamedFramebufferTextureFaceEXT(framebuffer, attachment, texture, level, face, function_pointer);
/* 3481:     */   }
/* 3482:     */   
/* 3483:     */   static native void nglNamedFramebufferTextureFaceEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 3484:     */   
/* 3485:     */   public static void glTextureRenderbufferEXT(int texture, int target, int renderbuffer)
/* 3486:     */   {
/* 3487:2880 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3488:2881 */     long function_pointer = caps.glTextureRenderbufferEXT;
/* 3489:2882 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3490:2883 */     nglTextureRenderbufferEXT(texture, target, renderbuffer, function_pointer);
/* 3491:     */   }
/* 3492:     */   
/* 3493:     */   static native void nglTextureRenderbufferEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3494:     */   
/* 3495:     */   public static void glMultiTexRenderbufferEXT(int texunit, int target, int renderbuffer)
/* 3496:     */   {
/* 3497:2888 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3498:2889 */     long function_pointer = caps.glMultiTexRenderbufferEXT;
/* 3499:2890 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3500:2891 */     nglMultiTexRenderbufferEXT(texunit, target, renderbuffer, function_pointer);
/* 3501:     */   }
/* 3502:     */   
/* 3503:     */   static native void nglMultiTexRenderbufferEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3504:     */   
/* 3505:     */   public static void glVertexArrayVertexOffsetEXT(int vaobj, int buffer, int size, int type, int stride, long offset)
/* 3506:     */   {
/* 3507:2896 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3508:2897 */     long function_pointer = caps.glVertexArrayVertexOffsetEXT;
/* 3509:2898 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3510:2899 */     nglVertexArrayVertexOffsetEXT(vaobj, buffer, size, type, stride, offset, function_pointer);
/* 3511:     */   }
/* 3512:     */   
/* 3513:     */   static native void nglVertexArrayVertexOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 3514:     */   
/* 3515:     */   public static void glVertexArrayColorOffsetEXT(int vaobj, int buffer, int size, int type, int stride, long offset)
/* 3516:     */   {
/* 3517:2904 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3518:2905 */     long function_pointer = caps.glVertexArrayColorOffsetEXT;
/* 3519:2906 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3520:2907 */     nglVertexArrayColorOffsetEXT(vaobj, buffer, size, type, stride, offset, function_pointer);
/* 3521:     */   }
/* 3522:     */   
/* 3523:     */   static native void nglVertexArrayColorOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 3524:     */   
/* 3525:     */   public static void glVertexArrayEdgeFlagOffsetEXT(int vaobj, int buffer, int stride, long offset)
/* 3526:     */   {
/* 3527:2912 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3528:2913 */     long function_pointer = caps.glVertexArrayEdgeFlagOffsetEXT;
/* 3529:2914 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3530:2915 */     nglVertexArrayEdgeFlagOffsetEXT(vaobj, buffer, stride, offset, function_pointer);
/* 3531:     */   }
/* 3532:     */   
/* 3533:     */   static native void nglVertexArrayEdgeFlagOffsetEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3534:     */   
/* 3535:     */   public static void glVertexArrayIndexOffsetEXT(int vaobj, int buffer, int type, int stride, long offset)
/* 3536:     */   {
/* 3537:2920 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3538:2921 */     long function_pointer = caps.glVertexArrayIndexOffsetEXT;
/* 3539:2922 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3540:2923 */     nglVertexArrayIndexOffsetEXT(vaobj, buffer, type, stride, offset, function_pointer);
/* 3541:     */   }
/* 3542:     */   
/* 3543:     */   static native void nglVertexArrayIndexOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3544:     */   
/* 3545:     */   public static void glVertexArrayNormalOffsetEXT(int vaobj, int buffer, int type, int stride, long offset)
/* 3546:     */   {
/* 3547:2928 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3548:2929 */     long function_pointer = caps.glVertexArrayNormalOffsetEXT;
/* 3549:2930 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3550:2931 */     nglVertexArrayNormalOffsetEXT(vaobj, buffer, type, stride, offset, function_pointer);
/* 3551:     */   }
/* 3552:     */   
/* 3553:     */   static native void nglVertexArrayNormalOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3554:     */   
/* 3555:     */   public static void glVertexArrayTexCoordOffsetEXT(int vaobj, int buffer, int size, int type, int stride, long offset)
/* 3556:     */   {
/* 3557:2936 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3558:2937 */     long function_pointer = caps.glVertexArrayTexCoordOffsetEXT;
/* 3559:2938 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3560:2939 */     nglVertexArrayTexCoordOffsetEXT(vaobj, buffer, size, type, stride, offset, function_pointer);
/* 3561:     */   }
/* 3562:     */   
/* 3563:     */   static native void nglVertexArrayTexCoordOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 3564:     */   
/* 3565:     */   public static void glVertexArrayMultiTexCoordOffsetEXT(int vaobj, int buffer, int texunit, int size, int type, int stride, long offset)
/* 3566:     */   {
/* 3567:2944 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3568:2945 */     long function_pointer = caps.glVertexArrayMultiTexCoordOffsetEXT;
/* 3569:2946 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3570:2947 */     nglVertexArrayMultiTexCoordOffsetEXT(vaobj, buffer, texunit, size, type, stride, offset, function_pointer);
/* 3571:     */   }
/* 3572:     */   
/* 3573:     */   static native void nglVertexArrayMultiTexCoordOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 3574:     */   
/* 3575:     */   public static void glVertexArrayFogCoordOffsetEXT(int vaobj, int buffer, int type, int stride, long offset)
/* 3576:     */   {
/* 3577:2952 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3578:2953 */     long function_pointer = caps.glVertexArrayFogCoordOffsetEXT;
/* 3579:2954 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3580:2955 */     nglVertexArrayFogCoordOffsetEXT(vaobj, buffer, type, stride, offset, function_pointer);
/* 3581:     */   }
/* 3582:     */   
/* 3583:     */   static native void nglVertexArrayFogCoordOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 3584:     */   
/* 3585:     */   public static void glVertexArraySecondaryColorOffsetEXT(int vaobj, int buffer, int size, int type, int stride, long offset)
/* 3586:     */   {
/* 3587:2960 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3588:2961 */     long function_pointer = caps.glVertexArraySecondaryColorOffsetEXT;
/* 3589:2962 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3590:2963 */     nglVertexArraySecondaryColorOffsetEXT(vaobj, buffer, size, type, stride, offset, function_pointer);
/* 3591:     */   }
/* 3592:     */   
/* 3593:     */   static native void nglVertexArraySecondaryColorOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 3594:     */   
/* 3595:     */   public static void glVertexArrayVertexAttribOffsetEXT(int vaobj, int buffer, int index, int size, int type, boolean normalized, int stride, long offset)
/* 3596:     */   {
/* 3597:2968 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3598:2969 */     long function_pointer = caps.glVertexArrayVertexAttribOffsetEXT;
/* 3599:2970 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3600:2971 */     nglVertexArrayVertexAttribOffsetEXT(vaobj, buffer, index, size, type, normalized, stride, offset, function_pointer);
/* 3601:     */   }
/* 3602:     */   
/* 3603:     */   static native void nglVertexArrayVertexAttribOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6, long paramLong1, long paramLong2);
/* 3604:     */   
/* 3605:     */   public static void glVertexArrayVertexAttribIOffsetEXT(int vaobj, int buffer, int index, int size, int type, int stride, long offset)
/* 3606:     */   {
/* 3607:2976 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3608:2977 */     long function_pointer = caps.glVertexArrayVertexAttribIOffsetEXT;
/* 3609:2978 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3610:2979 */     nglVertexArrayVertexAttribIOffsetEXT(vaobj, buffer, index, size, type, stride, offset, function_pointer);
/* 3611:     */   }
/* 3612:     */   
/* 3613:     */   static native void nglVertexArrayVertexAttribIOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 3614:     */   
/* 3615:     */   public static void glEnableVertexArrayEXT(int vaobj, int array)
/* 3616:     */   {
/* 3617:2984 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3618:2985 */     long function_pointer = caps.glEnableVertexArrayEXT;
/* 3619:2986 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3620:2987 */     nglEnableVertexArrayEXT(vaobj, array, function_pointer);
/* 3621:     */   }
/* 3622:     */   
/* 3623:     */   static native void nglEnableVertexArrayEXT(int paramInt1, int paramInt2, long paramLong);
/* 3624:     */   
/* 3625:     */   public static void glDisableVertexArrayEXT(int vaobj, int array)
/* 3626:     */   {
/* 3627:2992 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3628:2993 */     long function_pointer = caps.glDisableVertexArrayEXT;
/* 3629:2994 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3630:2995 */     nglDisableVertexArrayEXT(vaobj, array, function_pointer);
/* 3631:     */   }
/* 3632:     */   
/* 3633:     */   static native void nglDisableVertexArrayEXT(int paramInt1, int paramInt2, long paramLong);
/* 3634:     */   
/* 3635:     */   public static void glEnableVertexArrayAttribEXT(int vaobj, int index)
/* 3636:     */   {
/* 3637:3000 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3638:3001 */     long function_pointer = caps.glEnableVertexArrayAttribEXT;
/* 3639:3002 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3640:3003 */     nglEnableVertexArrayAttribEXT(vaobj, index, function_pointer);
/* 3641:     */   }
/* 3642:     */   
/* 3643:     */   static native void nglEnableVertexArrayAttribEXT(int paramInt1, int paramInt2, long paramLong);
/* 3644:     */   
/* 3645:     */   public static void glDisableVertexArrayAttribEXT(int vaobj, int index)
/* 3646:     */   {
/* 3647:3008 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3648:3009 */     long function_pointer = caps.glDisableVertexArrayAttribEXT;
/* 3649:3010 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3650:3011 */     nglDisableVertexArrayAttribEXT(vaobj, index, function_pointer);
/* 3651:     */   }
/* 3652:     */   
/* 3653:     */   static native void nglDisableVertexArrayAttribEXT(int paramInt1, int paramInt2, long paramLong);
/* 3654:     */   
/* 3655:     */   public static void glGetVertexArrayIntegerEXT(int vaobj, int pname, IntBuffer param)
/* 3656:     */   {
/* 3657:3016 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3658:3017 */     long function_pointer = caps.glGetVertexArrayIntegervEXT;
/* 3659:3018 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3660:3019 */     BufferChecks.checkBuffer(param, 16);
/* 3661:3020 */     nglGetVertexArrayIntegervEXT(vaobj, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3662:     */   }
/* 3663:     */   
/* 3664:     */   static native void nglGetVertexArrayIntegervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3665:     */   
/* 3666:     */   public static int glGetVertexArrayIntegerEXT(int vaobj, int pname)
/* 3667:     */   {
/* 3668:3026 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3669:3027 */     long function_pointer = caps.glGetVertexArrayIntegervEXT;
/* 3670:3028 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3671:3029 */     IntBuffer param = APIUtil.getBufferInt(caps);
/* 3672:3030 */     nglGetVertexArrayIntegervEXT(vaobj, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3673:3031 */     return param.get(0);
/* 3674:     */   }
/* 3675:     */   
/* 3676:     */   public static ByteBuffer glGetVertexArrayPointerEXT(int vaobj, int pname, long result_size)
/* 3677:     */   {
/* 3678:3035 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3679:3036 */     long function_pointer = caps.glGetVertexArrayPointervEXT;
/* 3680:3037 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3681:3038 */     ByteBuffer __result = nglGetVertexArrayPointervEXT(vaobj, pname, result_size, function_pointer);
/* 3682:3039 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 3683:     */   }
/* 3684:     */   
/* 3685:     */   static native ByteBuffer nglGetVertexArrayPointervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3686:     */   
/* 3687:     */   public static void glGetVertexArrayIntegerEXT(int vaobj, int index, int pname, IntBuffer param)
/* 3688:     */   {
/* 3689:3044 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3690:3045 */     long function_pointer = caps.glGetVertexArrayIntegeri_vEXT;
/* 3691:3046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3692:3047 */     BufferChecks.checkBuffer(param, 16);
/* 3693:3048 */     nglGetVertexArrayIntegeri_vEXT(vaobj, index, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3694:     */   }
/* 3695:     */   
/* 3696:     */   static native void nglGetVertexArrayIntegeri_vEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3697:     */   
/* 3698:     */   public static int glGetVertexArrayIntegeriEXT(int vaobj, int index, int pname)
/* 3699:     */   {
/* 3700:3054 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3701:3055 */     long function_pointer = caps.glGetVertexArrayIntegeri_vEXT;
/* 3702:3056 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3703:3057 */     IntBuffer param = APIUtil.getBufferInt(caps);
/* 3704:3058 */     nglGetVertexArrayIntegeri_vEXT(vaobj, index, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3705:3059 */     return param.get(0);
/* 3706:     */   }
/* 3707:     */   
/* 3708:     */   public static ByteBuffer glGetVertexArrayPointeri_EXT(int vaobj, int index, int pname, long result_size)
/* 3709:     */   {
/* 3710:3063 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3711:3064 */     long function_pointer = caps.glGetVertexArrayPointeri_vEXT;
/* 3712:3065 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3713:3066 */     ByteBuffer __result = nglGetVertexArrayPointeri_vEXT(vaobj, index, pname, result_size, function_pointer);
/* 3714:3067 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 3715:     */   }
/* 3716:     */   
/* 3717:     */   static native ByteBuffer nglGetVertexArrayPointeri_vEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3718:     */   
/* 3719:     */   public static ByteBuffer glMapNamedBufferRangeEXT(int buffer, long offset, long length, int access, ByteBuffer old_buffer)
/* 3720:     */   {
/* 3721:3086 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3722:3087 */     long function_pointer = caps.glMapNamedBufferRangeEXT;
/* 3723:3088 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3724:3089 */     if (old_buffer != null) {
/* 3725:3090 */       BufferChecks.checkDirect(old_buffer);
/* 3726:     */     }
/* 3727:3091 */     ByteBuffer __result = nglMapNamedBufferRangeEXT(buffer, offset, length, access, old_buffer, function_pointer);
/* 3728:3092 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 3729:     */   }
/* 3730:     */   
/* 3731:     */   static native ByteBuffer nglMapNamedBufferRangeEXT(int paramInt1, long paramLong1, long paramLong2, int paramInt2, ByteBuffer paramByteBuffer, long paramLong3);
/* 3732:     */   
/* 3733:     */   public static void glFlushMappedNamedBufferRangeEXT(int buffer, long offset, long length)
/* 3734:     */   {
/* 3735:3097 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3736:3098 */     long function_pointer = caps.glFlushMappedNamedBufferRangeEXT;
/* 3737:3099 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3738:3100 */     nglFlushMappedNamedBufferRangeEXT(buffer, offset, length, function_pointer);
/* 3739:     */   }
/* 3740:     */   
/* 3741:     */   static native void nglFlushMappedNamedBufferRangeEXT(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 3742:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTDirectStateAccess
 * JD-Core Version:    0.7.0.1
 */