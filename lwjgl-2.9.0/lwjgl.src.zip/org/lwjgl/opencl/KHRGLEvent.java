/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ import org.lwjgl.opengl.GLSync;
/*  7:   */ 
/*  8:   */ public final class KHRGLEvent
/*  9:   */ {
/* 10:   */   public static final int CL_COMMAND_GL_FENCE_SYNC_OBJECT_KHR = 8205;
/* 11:   */   
/* 12:   */   public static CLEvent clCreateEventFromGLsyncKHR(CLContext context, GLSync sync, IntBuffer errcode_ret)
/* 13:   */   {
/* 14:19 */     long function_pointer = CLCapabilities.clCreateEventFromGLsyncKHR;
/* 15:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:21 */     if (errcode_ret != null) {
/* 17:22 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 18:   */     }
/* 19:23 */     CLEvent __result = new CLEvent(nclCreateEventFromGLsyncKHR(context.getPointer(), sync.getPointer(), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 20:24 */     return __result;
/* 21:   */   }
/* 22:   */   
/* 23:   */   static native long nclCreateEventFromGLsyncKHR(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 24:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRGLEvent
 * JD-Core Version:    0.7.0.1
 */