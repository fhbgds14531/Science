/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ 
/*  5:   */ public final class APPLEContextLoggingUtil
/*  6:   */ {
/*  7:   */   public static final CLContextCallback SYSTEM_LOG_CALLBACK;
/*  8:   */   public static final CLContextCallback STD_OUT_CALLBACK;
/*  9:   */   public static final CLContextCallback STD_ERR_CALLBACK;
/* 10:   */   
/* 11:   */   static
/* 12:   */   {
/* 13:56 */     if (CLCapabilities.CL_APPLE_ContextLoggingFunctions)
/* 14:   */     {
/* 15:57 */       SYSTEM_LOG_CALLBACK = new CLContextCallback(CallbackUtil.getLogMessageToSystemLogAPPLE())
/* 16:   */       {
/* 17:   */         protected void handleMessage(String errinfo, ByteBuffer private_info)
/* 18:   */         {
/* 19:58 */           throw new UnsupportedOperationException();
/* 20:   */         }
/* 21:60 */       };
/* 22:61 */       STD_OUT_CALLBACK = new CLContextCallback(CallbackUtil.getLogMessageToStdoutAPPLE())
/* 23:   */       {
/* 24:   */         protected void handleMessage(String errinfo, ByteBuffer private_info)
/* 25:   */         {
/* 26:62 */           throw new UnsupportedOperationException();
/* 27:   */         }
/* 28:64 */       };
/* 29:65 */       STD_ERR_CALLBACK = new CLContextCallback(CallbackUtil.getLogMessageToStderrAPPLE())
/* 30:   */       {
/* 31:   */         protected void handleMessage(String errinfo, ByteBuffer private_info)
/* 32:   */         {
/* 33:66 */           throw new UnsupportedOperationException();
/* 34:   */         }
/* 35:   */       };
/* 36:   */     }
/* 37:   */     else
/* 38:   */     {
/* 39:69 */       SYSTEM_LOG_CALLBACK = null;
/* 40:70 */       STD_OUT_CALLBACK = null;
/* 41:71 */       STD_ERR_CALLBACK = null;
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.APPLEContextLoggingUtil
 * JD-Core Version:    0.7.0.1
 */