/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import org.lwjgl.BufferChecks;
/*   8:    */ import org.lwjgl.LWJGLUtil;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class GL14
/*  12:    */ {
/*  13:    */   public static final int GL_GENERATE_MIPMAP = 33169;
/*  14:    */   public static final int GL_GENERATE_MIPMAP_HINT = 33170;
/*  15:    */   public static final int GL_DEPTH_COMPONENT16 = 33189;
/*  16:    */   public static final int GL_DEPTH_COMPONENT24 = 33190;
/*  17:    */   public static final int GL_DEPTH_COMPONENT32 = 33191;
/*  18:    */   public static final int GL_TEXTURE_DEPTH_SIZE = 34890;
/*  19:    */   public static final int GL_DEPTH_TEXTURE_MODE = 34891;
/*  20:    */   public static final int GL_TEXTURE_COMPARE_MODE = 34892;
/*  21:    */   public static final int GL_TEXTURE_COMPARE_FUNC = 34893;
/*  22:    */   public static final int GL_COMPARE_R_TO_TEXTURE = 34894;
/*  23:    */   public static final int GL_FOG_COORDINATE_SOURCE = 33872;
/*  24:    */   public static final int GL_FOG_COORDINATE = 33873;
/*  25:    */   public static final int GL_FRAGMENT_DEPTH = 33874;
/*  26:    */   public static final int GL_CURRENT_FOG_COORDINATE = 33875;
/*  27:    */   public static final int GL_FOG_COORDINATE_ARRAY_TYPE = 33876;
/*  28:    */   public static final int GL_FOG_COORDINATE_ARRAY_STRIDE = 33877;
/*  29:    */   public static final int GL_FOG_COORDINATE_ARRAY_POINTER = 33878;
/*  30:    */   public static final int GL_FOG_COORDINATE_ARRAY = 33879;
/*  31:    */   public static final int GL_POINT_SIZE_MIN = 33062;
/*  32:    */   public static final int GL_POINT_SIZE_MAX = 33063;
/*  33:    */   public static final int GL_POINT_FADE_THRESHOLD_SIZE = 33064;
/*  34:    */   public static final int GL_POINT_DISTANCE_ATTENUATION = 33065;
/*  35:    */   public static final int GL_COLOR_SUM = 33880;
/*  36:    */   public static final int GL_CURRENT_SECONDARY_COLOR = 33881;
/*  37:    */   public static final int GL_SECONDARY_COLOR_ARRAY_SIZE = 33882;
/*  38:    */   public static final int GL_SECONDARY_COLOR_ARRAY_TYPE = 33883;
/*  39:    */   public static final int GL_SECONDARY_COLOR_ARRAY_STRIDE = 33884;
/*  40:    */   public static final int GL_SECONDARY_COLOR_ARRAY_POINTER = 33885;
/*  41:    */   public static final int GL_SECONDARY_COLOR_ARRAY = 33886;
/*  42:    */   public static final int GL_BLEND_DST_RGB = 32968;
/*  43:    */   public static final int GL_BLEND_SRC_RGB = 32969;
/*  44:    */   public static final int GL_BLEND_DST_ALPHA = 32970;
/*  45:    */   public static final int GL_BLEND_SRC_ALPHA = 32971;
/*  46:    */   public static final int GL_INCR_WRAP = 34055;
/*  47:    */   public static final int GL_DECR_WRAP = 34056;
/*  48:    */   public static final int GL_TEXTURE_FILTER_CONTROL = 34048;
/*  49:    */   public static final int GL_TEXTURE_LOD_BIAS = 34049;
/*  50:    */   public static final int GL_MAX_TEXTURE_LOD_BIAS = 34045;
/*  51:    */   public static final int GL_MIRRORED_REPEAT = 33648;
/*  52:    */   public static final int GL_BLEND_COLOR = 32773;
/*  53:    */   public static final int GL_BLEND_EQUATION = 32777;
/*  54:    */   public static final int GL_FUNC_ADD = 32774;
/*  55:    */   public static final int GL_FUNC_SUBTRACT = 32778;
/*  56:    */   public static final int GL_FUNC_REVERSE_SUBTRACT = 32779;
/*  57:    */   public static final int GL_MIN = 32775;
/*  58:    */   public static final int GL_MAX = 32776;
/*  59:    */   
/*  60:    */   public static void glBlendEquation(int mode)
/*  61:    */   {
/*  62: 68 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  63: 69 */     long function_pointer = caps.glBlendEquation;
/*  64: 70 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  65: 71 */     nglBlendEquation(mode, function_pointer);
/*  66:    */   }
/*  67:    */   
/*  68:    */   static native void nglBlendEquation(int paramInt, long paramLong);
/*  69:    */   
/*  70:    */   public static void glBlendColor(float red, float green, float blue, float alpha)
/*  71:    */   {
/*  72: 76 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  73: 77 */     long function_pointer = caps.glBlendColor;
/*  74: 78 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  75: 79 */     nglBlendColor(red, green, blue, alpha, function_pointer);
/*  76:    */   }
/*  77:    */   
/*  78:    */   static native void nglBlendColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  79:    */   
/*  80:    */   public static void glFogCoordf(float coord)
/*  81:    */   {
/*  82: 84 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  83: 85 */     long function_pointer = caps.glFogCoordf;
/*  84: 86 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  85: 87 */     nglFogCoordf(coord, function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglFogCoordf(float paramFloat, long paramLong);
/*  89:    */   
/*  90:    */   public static void glFogCoordd(double coord)
/*  91:    */   {
/*  92: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 93 */     long function_pointer = caps.glFogCoordd;
/*  94: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 95 */     nglFogCoordd(coord, function_pointer);
/*  96:    */   }
/*  97:    */   
/*  98:    */   static native void nglFogCoordd(double paramDouble, long paramLong);
/*  99:    */   
/* 100:    */   public static void glFogCoordPointer(int stride, DoubleBuffer data)
/* 101:    */   {
/* 102:100 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 103:101 */     long function_pointer = caps.glFogCoordPointer;
/* 104:102 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 105:103 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 106:104 */     BufferChecks.checkDirect(data);
/* 107:105 */     if (LWJGLUtil.CHECKS) {
/* 108:105 */       StateTracker.getReferences(caps).GL14_glFogCoordPointer_data = data;
/* 109:    */     }
/* 110:106 */     nglFogCoordPointer(5130, stride, MemoryUtil.getAddress(data), function_pointer);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void glFogCoordPointer(int stride, FloatBuffer data)
/* 114:    */   {
/* 115:109 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116:110 */     long function_pointer = caps.glFogCoordPointer;
/* 117:111 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:112 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 119:113 */     BufferChecks.checkDirect(data);
/* 120:114 */     if (LWJGLUtil.CHECKS) {
/* 121:114 */       StateTracker.getReferences(caps).GL14_glFogCoordPointer_data = data;
/* 122:    */     }
/* 123:115 */     nglFogCoordPointer(5126, stride, MemoryUtil.getAddress(data), function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglFogCoordPointer(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 127:    */   
/* 128:    */   public static void glFogCoordPointer(int type, int stride, long data_buffer_offset)
/* 129:    */   {
/* 130:119 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:120 */     long function_pointer = caps.glFogCoordPointer;
/* 132:121 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:122 */     GLChecks.ensureArrayVBOenabled(caps);
/* 134:123 */     nglFogCoordPointerBO(type, stride, data_buffer_offset, function_pointer);
/* 135:    */   }
/* 136:    */   
/* 137:    */   static native void nglFogCoordPointerBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 138:    */   
/* 139:    */   public static void glMultiDrawArrays(int mode, IntBuffer piFirst, IntBuffer piCount)
/* 140:    */   {
/* 141:128 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 142:129 */     long function_pointer = caps.glMultiDrawArrays;
/* 143:130 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 144:131 */     BufferChecks.checkDirect(piFirst);
/* 145:132 */     BufferChecks.checkBuffer(piCount, piFirst.remaining());
/* 146:133 */     nglMultiDrawArrays(mode, MemoryUtil.getAddress(piFirst), MemoryUtil.getAddress(piCount), piFirst.remaining(), function_pointer);
/* 147:    */   }
/* 148:    */   
/* 149:    */   static native void nglMultiDrawArrays(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 150:    */   
/* 151:    */   public static void glPointParameteri(int pname, int param)
/* 152:    */   {
/* 153:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 154:139 */     long function_pointer = caps.glPointParameteri;
/* 155:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 156:141 */     nglPointParameteri(pname, param, function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static native void nglPointParameteri(int paramInt1, int paramInt2, long paramLong);
/* 160:    */   
/* 161:    */   public static void glPointParameterf(int pname, float param)
/* 162:    */   {
/* 163:146 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 164:147 */     long function_pointer = caps.glPointParameterf;
/* 165:148 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 166:149 */     nglPointParameterf(pname, param, function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglPointParameterf(int paramInt, float paramFloat, long paramLong);
/* 170:    */   
/* 171:    */   public static void glPointParameter(int pname, IntBuffer params)
/* 172:    */   {
/* 173:154 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:155 */     long function_pointer = caps.glPointParameteriv;
/* 175:156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:157 */     BufferChecks.checkBuffer(params, 4);
/* 177:158 */     nglPointParameteriv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 178:    */   }
/* 179:    */   
/* 180:    */   static native void nglPointParameteriv(int paramInt, long paramLong1, long paramLong2);
/* 181:    */   
/* 182:    */   public static void glPointParameter(int pname, FloatBuffer params)
/* 183:    */   {
/* 184:163 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 185:164 */     long function_pointer = caps.glPointParameterfv;
/* 186:165 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 187:166 */     BufferChecks.checkBuffer(params, 4);
/* 188:167 */     nglPointParameterfv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglPointParameterfv(int paramInt, long paramLong1, long paramLong2);
/* 192:    */   
/* 193:    */   public static void glSecondaryColor3b(byte red, byte green, byte blue)
/* 194:    */   {
/* 195:172 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 196:173 */     long function_pointer = caps.glSecondaryColor3b;
/* 197:174 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 198:175 */     nglSecondaryColor3b(red, green, blue, function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   static native void nglSecondaryColor3b(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 202:    */   
/* 203:    */   public static void glSecondaryColor3f(float red, float green, float blue)
/* 204:    */   {
/* 205:180 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 206:181 */     long function_pointer = caps.glSecondaryColor3f;
/* 207:182 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 208:183 */     nglSecondaryColor3f(red, green, blue, function_pointer);
/* 209:    */   }
/* 210:    */   
/* 211:    */   static native void nglSecondaryColor3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 212:    */   
/* 213:    */   public static void glSecondaryColor3d(double red, double green, double blue)
/* 214:    */   {
/* 215:188 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 216:189 */     long function_pointer = caps.glSecondaryColor3d;
/* 217:190 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 218:191 */     nglSecondaryColor3d(red, green, blue, function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglSecondaryColor3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 222:    */   
/* 223:    */   public static void glSecondaryColor3ub(byte red, byte green, byte blue)
/* 224:    */   {
/* 225:196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:197 */     long function_pointer = caps.glSecondaryColor3ub;
/* 227:198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:199 */     nglSecondaryColor3ub(red, green, blue, function_pointer);
/* 229:    */   }
/* 230:    */   
/* 231:    */   static native void nglSecondaryColor3ub(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 232:    */   
/* 233:    */   public static void glSecondaryColorPointer(int size, int stride, DoubleBuffer data)
/* 234:    */   {
/* 235:204 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 236:205 */     long function_pointer = caps.glSecondaryColorPointer;
/* 237:206 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 238:207 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 239:208 */     BufferChecks.checkDirect(data);
/* 240:209 */     nglSecondaryColorPointer(size, 5130, stride, MemoryUtil.getAddress(data), function_pointer);
/* 241:    */   }
/* 242:    */   
/* 243:    */   public static void glSecondaryColorPointer(int size, int stride, FloatBuffer data)
/* 244:    */   {
/* 245:212 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 246:213 */     long function_pointer = caps.glSecondaryColorPointer;
/* 247:214 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 248:215 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 249:216 */     BufferChecks.checkDirect(data);
/* 250:217 */     nglSecondaryColorPointer(size, 5126, stride, MemoryUtil.getAddress(data), function_pointer);
/* 251:    */   }
/* 252:    */   
/* 253:    */   public static void glSecondaryColorPointer(int size, boolean unsigned, int stride, ByteBuffer data)
/* 254:    */   {
/* 255:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 256:221 */     long function_pointer = caps.glSecondaryColorPointer;
/* 257:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 258:223 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 259:224 */     BufferChecks.checkDirect(data);
/* 260:225 */     nglSecondaryColorPointer(size, unsigned ? 5121 : 5120, stride, MemoryUtil.getAddress(data), function_pointer);
/* 261:    */   }
/* 262:    */   
/* 263:    */   static native void nglSecondaryColorPointer(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 264:    */   
/* 265:    */   public static void glSecondaryColorPointer(int size, int type, int stride, long data_buffer_offset)
/* 266:    */   {
/* 267:229 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 268:230 */     long function_pointer = caps.glSecondaryColorPointer;
/* 269:231 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 270:232 */     GLChecks.ensureArrayVBOenabled(caps);
/* 271:233 */     nglSecondaryColorPointerBO(size, type, stride, data_buffer_offset, function_pointer);
/* 272:    */   }
/* 273:    */   
/* 274:    */   static native void nglSecondaryColorPointerBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 275:    */   
/* 276:    */   public static void glBlendFuncSeparate(int sfactorRGB, int dfactorRGB, int sfactorAlpha, int dfactorAlpha)
/* 277:    */   {
/* 278:238 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 279:239 */     long function_pointer = caps.glBlendFuncSeparate;
/* 280:240 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 281:241 */     nglBlendFuncSeparate(sfactorRGB, dfactorRGB, sfactorAlpha, dfactorAlpha, function_pointer);
/* 282:    */   }
/* 283:    */   
/* 284:    */   static native void nglBlendFuncSeparate(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 285:    */   
/* 286:    */   public static void glWindowPos2f(float x, float y)
/* 287:    */   {
/* 288:246 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 289:247 */     long function_pointer = caps.glWindowPos2f;
/* 290:248 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 291:249 */     nglWindowPos2f(x, y, function_pointer);
/* 292:    */   }
/* 293:    */   
/* 294:    */   static native void nglWindowPos2f(float paramFloat1, float paramFloat2, long paramLong);
/* 295:    */   
/* 296:    */   public static void glWindowPos2d(double x, double y)
/* 297:    */   {
/* 298:254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 299:255 */     long function_pointer = caps.glWindowPos2d;
/* 300:256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 301:257 */     nglWindowPos2d(x, y, function_pointer);
/* 302:    */   }
/* 303:    */   
/* 304:    */   static native void nglWindowPos2d(double paramDouble1, double paramDouble2, long paramLong);
/* 305:    */   
/* 306:    */   public static void glWindowPos2i(int x, int y)
/* 307:    */   {
/* 308:262 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 309:263 */     long function_pointer = caps.glWindowPos2i;
/* 310:264 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 311:265 */     nglWindowPos2i(x, y, function_pointer);
/* 312:    */   }
/* 313:    */   
/* 314:    */   static native void nglWindowPos2i(int paramInt1, int paramInt2, long paramLong);
/* 315:    */   
/* 316:    */   public static void glWindowPos3f(float x, float y, float z)
/* 317:    */   {
/* 318:270 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 319:271 */     long function_pointer = caps.glWindowPos3f;
/* 320:272 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 321:273 */     nglWindowPos3f(x, y, z, function_pointer);
/* 322:    */   }
/* 323:    */   
/* 324:    */   static native void nglWindowPos3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 325:    */   
/* 326:    */   public static void glWindowPos3d(double x, double y, double z)
/* 327:    */   {
/* 328:278 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 329:279 */     long function_pointer = caps.glWindowPos3d;
/* 330:280 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 331:281 */     nglWindowPos3d(x, y, z, function_pointer);
/* 332:    */   }
/* 333:    */   
/* 334:    */   static native void nglWindowPos3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 335:    */   
/* 336:    */   public static void glWindowPos3i(int x, int y, int z)
/* 337:    */   {
/* 338:286 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 339:287 */     long function_pointer = caps.glWindowPos3i;
/* 340:288 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 341:289 */     nglWindowPos3i(x, y, z, function_pointer);
/* 342:    */   }
/* 343:    */   
/* 344:    */   static native void nglWindowPos3i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 345:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL14
 * JD-Core Version:    0.7.0.1
 */