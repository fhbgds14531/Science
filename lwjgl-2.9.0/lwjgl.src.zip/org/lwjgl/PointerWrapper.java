package org.lwjgl;

public abstract interface PointerWrapper
{
  public abstract long getPointer();
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.PointerWrapper
 * JD-Core Version:    0.7.0.1
 */