/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class GL12
/*  12:    */ {
/*  13:    */   public static final int GL_TEXTURE_BINDING_3D = 32874;
/*  14:    */   public static final int GL_PACK_SKIP_IMAGES = 32875;
/*  15:    */   public static final int GL_PACK_IMAGE_HEIGHT = 32876;
/*  16:    */   public static final int GL_UNPACK_SKIP_IMAGES = 32877;
/*  17:    */   public static final int GL_UNPACK_IMAGE_HEIGHT = 32878;
/*  18:    */   public static final int GL_TEXTURE_3D = 32879;
/*  19:    */   public static final int GL_PROXY_TEXTURE_3D = 32880;
/*  20:    */   public static final int GL_TEXTURE_DEPTH = 32881;
/*  21:    */   public static final int GL_TEXTURE_WRAP_R = 32882;
/*  22:    */   public static final int GL_MAX_3D_TEXTURE_SIZE = 32883;
/*  23:    */   public static final int GL_BGR = 32992;
/*  24:    */   public static final int GL_BGRA = 32993;
/*  25:    */   public static final int GL_UNSIGNED_BYTE_3_3_2 = 32818;
/*  26:    */   public static final int GL_UNSIGNED_BYTE_2_3_3_REV = 33634;
/*  27:    */   public static final int GL_UNSIGNED_SHORT_5_6_5 = 33635;
/*  28:    */   public static final int GL_UNSIGNED_SHORT_5_6_5_REV = 33636;
/*  29:    */   public static final int GL_UNSIGNED_SHORT_4_4_4_4 = 32819;
/*  30:    */   public static final int GL_UNSIGNED_SHORT_4_4_4_4_REV = 33637;
/*  31:    */   public static final int GL_UNSIGNED_SHORT_5_5_5_1 = 32820;
/*  32:    */   public static final int GL_UNSIGNED_SHORT_1_5_5_5_REV = 33638;
/*  33:    */   public static final int GL_UNSIGNED_INT_8_8_8_8 = 32821;
/*  34:    */   public static final int GL_UNSIGNED_INT_8_8_8_8_REV = 33639;
/*  35:    */   public static final int GL_UNSIGNED_INT_10_10_10_2 = 32822;
/*  36:    */   public static final int GL_UNSIGNED_INT_2_10_10_10_REV = 33640;
/*  37:    */   public static final int GL_RESCALE_NORMAL = 32826;
/*  38:    */   public static final int GL_LIGHT_MODEL_COLOR_CONTROL = 33272;
/*  39:    */   public static final int GL_SINGLE_COLOR = 33273;
/*  40:    */   public static final int GL_SEPARATE_SPECULAR_COLOR = 33274;
/*  41:    */   public static final int GL_CLAMP_TO_EDGE = 33071;
/*  42:    */   public static final int GL_TEXTURE_MIN_LOD = 33082;
/*  43:    */   public static final int GL_TEXTURE_MAX_LOD = 33083;
/*  44:    */   public static final int GL_TEXTURE_BASE_LEVEL = 33084;
/*  45:    */   public static final int GL_TEXTURE_MAX_LEVEL = 33085;
/*  46:    */   public static final int GL_MAX_ELEMENTS_VERTICES = 33000;
/*  47:    */   public static final int GL_MAX_ELEMENTS_INDICES = 33001;
/*  48:    */   public static final int GL_ALIASED_POINT_SIZE_RANGE = 33901;
/*  49:    */   public static final int GL_ALIASED_LINE_WIDTH_RANGE = 33902;
/*  50:    */   public static final int GL_SMOOTH_POINT_SIZE_RANGE = 2834;
/*  51:    */   public static final int GL_SMOOTH_POINT_SIZE_GRANULARITY = 2835;
/*  52:    */   public static final int GL_SMOOTH_LINE_WIDTH_RANGE = 2850;
/*  53:    */   public static final int GL_SMOOTH_LINE_WIDTH_GRANULARITY = 2851;
/*  54:    */   
/*  55:    */   public static void glDrawRangeElements(int mode, int start, int end, ByteBuffer indices)
/*  56:    */   {
/*  57: 63 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  58: 64 */     long function_pointer = caps.glDrawRangeElements;
/*  59: 65 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  60: 66 */     GLChecks.ensureElementVBOdisabled(caps);
/*  61: 67 */     BufferChecks.checkDirect(indices);
/*  62: 68 */     nglDrawRangeElements(mode, start, end, indices.remaining(), 5121, MemoryUtil.getAddress(indices), function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glDrawRangeElements(int mode, int start, int end, IntBuffer indices)
/*  66:    */   {
/*  67: 71 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  68: 72 */     long function_pointer = caps.glDrawRangeElements;
/*  69: 73 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  70: 74 */     GLChecks.ensureElementVBOdisabled(caps);
/*  71: 75 */     BufferChecks.checkDirect(indices);
/*  72: 76 */     nglDrawRangeElements(mode, start, end, indices.remaining(), 5125, MemoryUtil.getAddress(indices), function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void glDrawRangeElements(int mode, int start, int end, ShortBuffer indices)
/*  76:    */   {
/*  77: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  78: 80 */     long function_pointer = caps.glDrawRangeElements;
/*  79: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  80: 82 */     GLChecks.ensureElementVBOdisabled(caps);
/*  81: 83 */     BufferChecks.checkDirect(indices);
/*  82: 84 */     nglDrawRangeElements(mode, start, end, indices.remaining(), 5123, MemoryUtil.getAddress(indices), function_pointer);
/*  83:    */   }
/*  84:    */   
/*  85:    */   static native void nglDrawRangeElements(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  86:    */   
/*  87:    */   public static void glDrawRangeElements(int mode, int start, int end, int indices_count, int type, long indices_buffer_offset)
/*  88:    */   {
/*  89: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  90: 89 */     long function_pointer = caps.glDrawRangeElements;
/*  91: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  92: 91 */     GLChecks.ensureElementVBOenabled(caps);
/*  93: 92 */     nglDrawRangeElementsBO(mode, start, end, indices_count, type, indices_buffer_offset, function_pointer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   static native void nglDrawRangeElementsBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  97:    */   
/*  98:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, ByteBuffer pixels)
/*  99:    */   {
/* 100: 97 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 101: 98 */     long function_pointer = caps.glTexImage3D;
/* 102: 99 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 103:100 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 104:101 */     if (pixels != null) {
/* 105:102 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 106:    */     }
/* 107:103 */     nglTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, DoubleBuffer pixels)
/* 111:    */   {
/* 112:106 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 113:107 */     long function_pointer = caps.glTexImage3D;
/* 114:108 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 115:109 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 116:110 */     if (pixels != null) {
/* 117:111 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 118:    */     }
/* 119:112 */     nglTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, FloatBuffer pixels)
/* 123:    */   {
/* 124:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:116 */     long function_pointer = caps.glTexImage3D;
/* 126:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:118 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 128:119 */     if (pixels != null) {
/* 129:120 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 130:    */     }
/* 131:121 */     nglTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, IntBuffer pixels)
/* 135:    */   {
/* 136:124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 137:125 */     long function_pointer = caps.glTexImage3D;
/* 138:126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 139:127 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 140:128 */     if (pixels != null) {
/* 141:129 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 142:    */     }
/* 143:130 */     nglTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, ShortBuffer pixels)
/* 147:    */   {
/* 148:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 149:134 */     long function_pointer = caps.glTexImage3D;
/* 150:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 151:136 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 152:137 */     if (pixels != null) {
/* 153:138 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage3DStorage(pixels, format, type, width, height, depth));
/* 154:    */     }
/* 155:139 */     nglTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 156:    */   }
/* 157:    */   
/* 158:    */   static native void nglTexImage3D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 159:    */   
/* 160:    */   public static void glTexImage3D(int target, int level, int internalFormat, int width, int height, int depth, int border, int format, int type, long pixels_buffer_offset)
/* 161:    */   {
/* 162:143 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 163:144 */     long function_pointer = caps.glTexImage3D;
/* 164:145 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 165:146 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 166:147 */     nglTexImage3DBO(target, level, internalFormat, width, height, depth, border, format, type, pixels_buffer_offset, function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglTexImage3DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong1, long paramLong2);
/* 170:    */   
/* 171:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ByteBuffer pixels)
/* 172:    */   {
/* 173:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:153 */     long function_pointer = caps.glTexSubImage3D;
/* 175:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:155 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 177:156 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 178:157 */     nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, DoubleBuffer pixels)
/* 182:    */   {
/* 183:160 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 184:161 */     long function_pointer = caps.glTexSubImage3D;
/* 185:162 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 186:163 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 187:164 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 188:165 */     nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, FloatBuffer pixels)
/* 192:    */   {
/* 193:168 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 194:169 */     long function_pointer = caps.glTexSubImage3D;
/* 195:170 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 196:171 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 197:172 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 198:173 */     nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, IntBuffer pixels)
/* 202:    */   {
/* 203:176 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 204:177 */     long function_pointer = caps.glTexSubImage3D;
/* 205:178 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 206:179 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 207:180 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 208:181 */     nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, ShortBuffer pixels)
/* 212:    */   {
/* 213:184 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 214:185 */     long function_pointer = caps.glTexSubImage3D;
/* 215:186 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 216:187 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 217:188 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, depth));
/* 218:189 */     nglTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglTexSubImage3D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 222:    */   
/* 223:    */   public static void glTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int type, long pixels_buffer_offset)
/* 224:    */   {
/* 225:193 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:194 */     long function_pointer = caps.glTexSubImage3D;
/* 227:195 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:196 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 229:197 */     nglTexSubImage3DBO(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels_buffer_offset, function_pointer);
/* 230:    */   }
/* 231:    */   
/* 232:    */   static native void nglTexSubImage3DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 233:    */   
/* 234:    */   public static void glCopyTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int x, int y, int width, int height)
/* 235:    */   {
/* 236:202 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 237:203 */     long function_pointer = caps.glCopyTexSubImage3D;
/* 238:204 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 239:205 */     nglCopyTexSubImage3D(target, level, xoffset, yoffset, zoffset, x, y, width, height, function_pointer);
/* 240:    */   }
/* 241:    */   
/* 242:    */   static native void nglCopyTexSubImage3D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, long paramLong);
/* 243:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL12
 * JD-Core Version:    0.7.0.1
 */