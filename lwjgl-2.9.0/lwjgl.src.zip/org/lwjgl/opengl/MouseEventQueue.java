/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Point;
/*   5:    */ import java.awt.event.MouseEvent;
/*   6:    */ import java.awt.event.MouseListener;
/*   7:    */ import java.awt.event.MouseMotionListener;
/*   8:    */ import java.awt.event.MouseWheelEvent;
/*   9:    */ import java.awt.event.MouseWheelListener;
/*  10:    */ import java.nio.ByteBuffer;
/*  11:    */ import java.nio.IntBuffer;
/*  12:    */ 
/*  13:    */ class MouseEventQueue
/*  14:    */   extends EventQueue
/*  15:    */   implements MouseListener, MouseMotionListener, MouseWheelListener
/*  16:    */ {
/*  17:    */   private static final int WHEEL_SCALE = 120;
/*  18:    */   public static final int NUM_BUTTONS = 3;
/*  19:    */   private final Component component;
/*  20:    */   private boolean grabbed;
/*  21:    */   private int accum_dx;
/*  22:    */   private int accum_dy;
/*  23:    */   private int accum_dz;
/*  24:    */   private int last_x;
/*  25:    */   private int last_y;
/*  26:    */   private boolean saved_control_state;
/*  27: 72 */   private final ByteBuffer event = ByteBuffer.allocate(22);
/*  28: 75 */   private final byte[] buttons = new byte[3];
/*  29:    */   
/*  30:    */   MouseEventQueue(Component component)
/*  31:    */   {
/*  32: 78 */     super(22);
/*  33: 79 */     this.component = component;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public synchronized void register()
/*  37:    */   {
/*  38: 83 */     resetCursorToCenter();
/*  39: 84 */     if (this.component != null)
/*  40:    */     {
/*  41: 85 */       this.component.addMouseListener(this);
/*  42: 86 */       this.component.addMouseMotionListener(this);
/*  43: 87 */       this.component.addMouseWheelListener(this);
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public synchronized void unregister()
/*  48:    */   {
/*  49: 92 */     if (this.component != null)
/*  50:    */     {
/*  51: 93 */       this.component.removeMouseListener(this);
/*  52: 94 */       this.component.removeMouseMotionListener(this);
/*  53: 95 */       this.component.removeMouseWheelListener(this);
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   protected Component getComponent()
/*  58:    */   {
/*  59:100 */     return this.component;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public synchronized void setGrabbed(boolean grabbed)
/*  63:    */   {
/*  64:104 */     this.grabbed = grabbed;
/*  65:105 */     resetCursorToCenter();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public synchronized boolean isGrabbed()
/*  69:    */   {
/*  70:109 */     return this.grabbed;
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected int transformY(int y)
/*  74:    */   {
/*  75:113 */     if (this.component != null) {
/*  76:114 */       return this.component.getHeight() - 1 - y;
/*  77:    */     }
/*  78:116 */     return y;
/*  79:    */   }
/*  80:    */   
/*  81:    */   protected void resetCursorToCenter()
/*  82:    */   {
/*  83:120 */     clearEvents();
/*  84:121 */     this.accum_dx = (this.accum_dy = 0);
/*  85:122 */     if (this.component != null)
/*  86:    */     {
/*  87:123 */       Point cursor_location = AWTUtil.getCursorPosition(this.component);
/*  88:124 */       if (cursor_location != null)
/*  89:    */       {
/*  90:125 */         this.last_x = cursor_location.x;
/*  91:126 */         this.last_y = cursor_location.y;
/*  92:    */       }
/*  93:    */     }
/*  94:    */   }
/*  95:    */   
/*  96:    */   private void putMouseEvent(byte button, byte state, int dz, long nanos)
/*  97:    */   {
/*  98:132 */     if (this.grabbed) {
/*  99:133 */       putMouseEventWithCoords(button, state, 0, 0, dz, nanos);
/* 100:    */     } else {
/* 101:135 */       putMouseEventWithCoords(button, state, this.last_x, this.last_y, dz, nanos);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected void putMouseEventWithCoords(byte button, byte state, int coord1, int coord2, int dz, long nanos)
/* 106:    */   {
/* 107:139 */     this.event.clear();
/* 108:140 */     this.event.put(button).put(state).putInt(coord1).putInt(coord2).putInt(dz).putLong(nanos);
/* 109:141 */     this.event.flip();
/* 110:142 */     putEvent(this.event);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public synchronized void poll(IntBuffer coord_buffer, ByteBuffer buttons_buffer)
/* 114:    */   {
/* 115:146 */     if (this.grabbed)
/* 116:    */     {
/* 117:147 */       coord_buffer.put(0, this.accum_dx);
/* 118:148 */       coord_buffer.put(1, this.accum_dy);
/* 119:    */     }
/* 120:    */     else
/* 121:    */     {
/* 122:150 */       coord_buffer.put(0, this.last_x);
/* 123:151 */       coord_buffer.put(1, this.last_y);
/* 124:    */     }
/* 125:153 */     coord_buffer.put(2, this.accum_dz);
/* 126:154 */     this.accum_dx = (this.accum_dy = this.accum_dz = 0);
/* 127:155 */     int old_position = buttons_buffer.position();
/* 128:156 */     buttons_buffer.put(this.buttons, 0, this.buttons.length);
/* 129:157 */     buttons_buffer.position(old_position);
/* 130:    */   }
/* 131:    */   
/* 132:    */   private void setCursorPos(int x, int y, long nanos)
/* 133:    */   {
/* 134:161 */     y = transformY(y);
/* 135:162 */     if (this.grabbed) {
/* 136:163 */       return;
/* 137:    */     }
/* 138:164 */     int dx = x - this.last_x;
/* 139:165 */     int dy = y - this.last_y;
/* 140:166 */     addDelta(dx, dy);
/* 141:167 */     this.last_x = x;
/* 142:168 */     this.last_y = y;
/* 143:169 */     putMouseEventWithCoords((byte)-1, (byte)0, x, y, 0, nanos);
/* 144:    */   }
/* 145:    */   
/* 146:    */   protected void addDelta(int dx, int dy)
/* 147:    */   {
/* 148:173 */     this.accum_dx += dx;
/* 149:174 */     this.accum_dy += dy;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void mouseClicked(MouseEvent e) {}
/* 153:    */   
/* 154:    */   public void mouseEntered(MouseEvent e) {}
/* 155:    */   
/* 156:    */   public void mouseExited(MouseEvent e) {}
/* 157:    */   
/* 158:    */   private void handleButton(MouseEvent e)
/* 159:    */   {
/* 160:    */     byte state;
/* 161:188 */     switch (e.getID())
/* 162:    */     {
/* 163:    */     case 501: 
/* 164:190 */       state = 1;
/* 165:191 */       break;
/* 166:    */     case 502: 
/* 167:193 */       state = 0;
/* 168:194 */       break;
/* 169:    */     default: 
/* 170:196 */       throw new IllegalArgumentException("Not a valid event ID: " + e.getID());
/* 171:    */     }
/* 172:    */     byte button;
/* 173:199 */     switch (e.getButton())
/* 174:    */     {
/* 175:    */     case 0: 
/* 176:202 */       return;
/* 177:    */     case 1: 
/* 178:205 */       if (state == 1) {
/* 179:206 */         this.saved_control_state = e.isControlDown();
/* 180:    */       }
/* 181:    */       byte button;
/* 182:207 */       if (this.saved_control_state)
/* 183:    */       {
/* 184:208 */         if (this.buttons[1] == state) {
/* 185:209 */           return;
/* 186:    */         }
/* 187:210 */         button = 1;
/* 188:    */       }
/* 189:    */       else
/* 190:    */       {
/* 191:212 */         button = 0;
/* 192:    */       }
/* 193:214 */       break;
/* 194:    */     case 2: 
/* 195:216 */       button = 2;
/* 196:217 */       break;
/* 197:    */     case 3: 
/* 198:219 */       if (this.buttons[1] == state) {
/* 199:220 */         return;
/* 200:    */       }
/* 201:221 */       button = 1;
/* 202:222 */       break;
/* 203:    */     default: 
/* 204:224 */       throw new IllegalArgumentException("Not a valid button: " + e.getButton());
/* 205:    */     }
/* 206:226 */     setButton(button, state, e.getWhen() * 1000000L);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public synchronized void mousePressed(MouseEvent e)
/* 210:    */   {
/* 211:230 */     handleButton(e);
/* 212:    */   }
/* 213:    */   
/* 214:    */   private void setButton(byte button, byte state, long nanos)
/* 215:    */   {
/* 216:234 */     this.buttons[button] = state;
/* 217:235 */     putMouseEvent(button, state, 0, nanos);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public synchronized void mouseReleased(MouseEvent e)
/* 221:    */   {
/* 222:239 */     handleButton(e);
/* 223:    */   }
/* 224:    */   
/* 225:    */   private void handleMotion(MouseEvent e)
/* 226:    */   {
/* 227:243 */     if (this.grabbed) {
/* 228:244 */       updateDeltas(e.getWhen() * 1000000L);
/* 229:    */     } else {
/* 230:246 */       setCursorPos(e.getX(), e.getY(), e.getWhen() * 1000000L);
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */   public synchronized void mouseDragged(MouseEvent e)
/* 235:    */   {
/* 236:251 */     handleMotion(e);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public synchronized void mouseMoved(MouseEvent e)
/* 240:    */   {
/* 241:255 */     handleMotion(e);
/* 242:    */   }
/* 243:    */   
/* 244:    */   private void handleWheel(int amount, long nanos)
/* 245:    */   {
/* 246:259 */     this.accum_dz += amount;
/* 247:260 */     putMouseEvent((byte)-1, (byte)0, amount, nanos);
/* 248:    */   }
/* 249:    */   
/* 250:    */   protected void updateDeltas(long nanos) {}
/* 251:    */   
/* 252:    */   public synchronized void mouseWheelMoved(MouseWheelEvent e)
/* 253:    */   {
/* 254:267 */     int wheel_amount = -e.getWheelRotation() * 120;
/* 255:268 */     handleWheel(wheel_amount, e.getWhen() * 1000000L);
/* 256:    */   }
/* 257:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MouseEventQueue
 * JD-Core Version:    0.7.0.1
 */