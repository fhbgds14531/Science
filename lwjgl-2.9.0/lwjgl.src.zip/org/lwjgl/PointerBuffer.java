/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.nio.Buffer;
/*   5:    */ import java.nio.BufferOverflowException;
/*   6:    */ import java.nio.BufferUnderflowException;
/*   7:    */ import java.nio.ByteBuffer;
/*   8:    */ import java.nio.ByteOrder;
/*   9:    */ import java.nio.IntBuffer;
/*  10:    */ import java.nio.LongBuffer;
/*  11:    */ import java.nio.ReadOnlyBufferException;
/*  12:    */ 
/*  13:    */ public class PointerBuffer
/*  14:    */   implements Comparable
/*  15:    */ {
/*  16:    */   private static final boolean is64Bit;
/*  17:    */   protected final ByteBuffer pointers;
/*  18:    */   protected final Buffer view;
/*  19:    */   protected final IntBuffer view32;
/*  20:    */   protected final LongBuffer view64;
/*  21:    */   
/*  22:    */   static
/*  23:    */   {
/*  24: 49 */     boolean is64 = false;
/*  25:    */     try
/*  26:    */     {
/*  27: 51 */       Method m = Class.forName("org.lwjgl.Sys").getDeclaredMethod("is64Bit", (Class[])null);
/*  28: 52 */       is64 = ((Boolean)m.invoke(null, (Object[])null)).booleanValue();
/*  29:    */     }
/*  30:    */     catch (Throwable t) {}finally
/*  31:    */     {
/*  32: 56 */       is64Bit = is64;
/*  33:    */     }
/*  34:    */   }
/*  35:    */   
/*  36:    */   public PointerBuffer(int capacity)
/*  37:    */   {
/*  38: 72 */     this(BufferUtils.createByteBuffer(capacity * getPointerSize()));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public PointerBuffer(ByteBuffer source)
/*  42:    */   {
/*  43: 83 */     if (LWJGLUtil.CHECKS) {
/*  44: 84 */       checkSource(source);
/*  45:    */     }
/*  46: 86 */     this.pointers = source.slice().order(source.order());
/*  47: 88 */     if (is64Bit)
/*  48:    */     {
/*  49: 89 */       this.view32 = null;
/*  50: 90 */       this.view = (this.view64 = this.pointers.asLongBuffer());
/*  51:    */     }
/*  52:    */     else
/*  53:    */     {
/*  54: 92 */       this.view = (this.view32 = this.pointers.asIntBuffer());
/*  55: 93 */       this.view64 = null;
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   private static void checkSource(ByteBuffer source)
/*  60:    */   {
/*  61: 98 */     if (!source.isDirect()) {
/*  62: 99 */       throw new IllegalArgumentException("The source buffer is not direct.");
/*  63:    */     }
/*  64:101 */     int alignment = is64Bit ? 8 : 4;
/*  65:102 */     if (((MemoryUtil.getAddress0(source) + source.position()) % alignment != 0L) || (source.remaining() % alignment != 0)) {
/*  66:103 */       throw new IllegalArgumentException("The source buffer is not aligned to " + alignment + " bytes.");
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public ByteBuffer getBuffer()
/*  71:    */   {
/*  72:112 */     return this.pointers;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static boolean is64Bit()
/*  76:    */   {
/*  77:117 */     return is64Bit;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static int getPointerSize()
/*  81:    */   {
/*  82:126 */     return is64Bit ? 8 : 4;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public final int capacity()
/*  86:    */   {
/*  87:135 */     return this.view.capacity();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public final int position()
/*  91:    */   {
/*  92:144 */     return this.view.position();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public final int positionByte()
/*  96:    */   {
/*  97:153 */     return position() * getPointerSize();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public final PointerBuffer position(int newPosition)
/* 101:    */   {
/* 102:168 */     this.view.position(newPosition);
/* 103:169 */     return this;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public final int limit()
/* 107:    */   {
/* 108:178 */     return this.view.limit();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public final PointerBuffer limit(int newLimit)
/* 112:    */   {
/* 113:194 */     this.view.limit(newLimit);
/* 114:195 */     return this;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public final PointerBuffer mark()
/* 118:    */   {
/* 119:204 */     this.view.mark();
/* 120:205 */     return this;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public final PointerBuffer reset()
/* 124:    */   {
/* 125:219 */     this.view.reset();
/* 126:220 */     return this;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public final PointerBuffer clear()
/* 130:    */   {
/* 131:241 */     this.view.clear();
/* 132:242 */     return this;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public final PointerBuffer flip()
/* 136:    */   {
/* 137:267 */     this.view.flip();
/* 138:268 */     return this;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public final PointerBuffer rewind()
/* 142:    */   {
/* 143:287 */     this.view.rewind();
/* 144:288 */     return this;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public final int remaining()
/* 148:    */   {
/* 149:298 */     return this.view.remaining();
/* 150:    */   }
/* 151:    */   
/* 152:    */   public final int remainingByte()
/* 153:    */   {
/* 154:308 */     return remaining() * getPointerSize();
/* 155:    */   }
/* 156:    */   
/* 157:    */   public final boolean hasRemaining()
/* 158:    */   {
/* 159:319 */     return this.view.hasRemaining();
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static PointerBuffer allocateDirect(int capacity)
/* 163:    */   {
/* 164:335 */     return new PointerBuffer(capacity);
/* 165:    */   }
/* 166:    */   
/* 167:    */   protected PointerBuffer newInstance(ByteBuffer source)
/* 168:    */   {
/* 169:347 */     return new PointerBuffer(source);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public PointerBuffer slice()
/* 173:    */   {
/* 174:368 */     int pointerSize = getPointerSize();
/* 175:    */     
/* 176:370 */     this.pointers.position(this.view.position() * pointerSize);
/* 177:371 */     this.pointers.limit(this.view.limit() * pointerSize);
/* 178:    */     try
/* 179:    */     {
/* 180:375 */       return newInstance(this.pointers);
/* 181:    */     }
/* 182:    */     finally
/* 183:    */     {
/* 184:377 */       this.pointers.clear();
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   public PointerBuffer duplicate()
/* 189:    */   {
/* 190:397 */     PointerBuffer buffer = newInstance(this.pointers);
/* 191:    */     
/* 192:399 */     buffer.position(this.view.position());
/* 193:400 */     buffer.limit(this.view.limit());
/* 194:    */     
/* 195:402 */     return buffer;
/* 196:    */   }
/* 197:    */   
/* 198:    */   public PointerBuffer asReadOnlyBuffer()
/* 199:    */   {
/* 200:424 */     PointerBuffer buffer = new PointerBufferR(this.pointers);
/* 201:    */     
/* 202:426 */     buffer.position(this.view.position());
/* 203:427 */     buffer.limit(this.view.limit());
/* 204:    */     
/* 205:429 */     return buffer;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean isReadOnly()
/* 209:    */   {
/* 210:433 */     return false;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public long get()
/* 214:    */   {
/* 215:445 */     if (is64Bit) {
/* 216:446 */       return this.view64.get();
/* 217:    */     }
/* 218:448 */     return this.view32.get() & 0xFFFFFFFF;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public PointerBuffer put(long l)
/* 222:    */   {
/* 223:465 */     if (is64Bit) {
/* 224:466 */       this.view64.put(l);
/* 225:    */     } else {
/* 226:468 */       this.view32.put((int)l);
/* 227:    */     }
/* 228:469 */     return this;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public PointerBuffer put(PointerWrapper pointer)
/* 232:    */   {
/* 233:478 */     return put(pointer.getPointer());
/* 234:    */   }
/* 235:    */   
/* 236:    */   public static void put(ByteBuffer target, long l)
/* 237:    */   {
/* 238:488 */     if (is64Bit) {
/* 239:489 */       target.putLong(l);
/* 240:    */     } else {
/* 241:491 */       target.putInt((int)l);
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   public long get(int index)
/* 246:    */   {
/* 247:506 */     if (is64Bit) {
/* 248:507 */       return this.view64.get(index);
/* 249:    */     }
/* 250:509 */     return this.view32.get(index) & 0xFFFFFFFF;
/* 251:    */   }
/* 252:    */   
/* 253:    */   public PointerBuffer put(int index, long l)
/* 254:    */   {
/* 255:528 */     if (is64Bit) {
/* 256:529 */       this.view64.put(index, l);
/* 257:    */     } else {
/* 258:531 */       this.view32.put(index, (int)l);
/* 259:    */     }
/* 260:532 */     return this;
/* 261:    */   }
/* 262:    */   
/* 263:    */   public PointerBuffer put(int index, PointerWrapper pointer)
/* 264:    */   {
/* 265:541 */     return put(index, pointer.getPointer());
/* 266:    */   }
/* 267:    */   
/* 268:    */   public static void put(ByteBuffer target, int index, long l)
/* 269:    */   {
/* 270:552 */     if (is64Bit) {
/* 271:553 */       target.putLong(index, l);
/* 272:    */     } else {
/* 273:555 */       target.putInt(index, (int)l);
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   public PointerBuffer get(long[] dst, int offset, int length)
/* 278:    */   {
/* 279:602 */     if (is64Bit)
/* 280:    */     {
/* 281:603 */       this.view64.get(dst, offset, length);
/* 282:    */     }
/* 283:    */     else
/* 284:    */     {
/* 285:605 */       checkBounds(offset, length, dst.length);
/* 286:606 */       if (length > this.view32.remaining()) {
/* 287:607 */         throw new BufferUnderflowException();
/* 288:    */       }
/* 289:608 */       int end = offset + length;
/* 290:609 */       for (int i = offset; i < end; i++) {
/* 291:610 */         dst[i] = (this.view32.get() & 0xFFFFFFFF);
/* 292:    */       }
/* 293:    */     }
/* 294:613 */     return this;
/* 295:    */   }
/* 296:    */   
/* 297:    */   public PointerBuffer get(long[] dst)
/* 298:    */   {
/* 299:632 */     return get(dst, 0, dst.length);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public PointerBuffer put(PointerBuffer src)
/* 303:    */   {
/* 304:671 */     if (is64Bit) {
/* 305:672 */       this.view64.put(src.view64);
/* 306:    */     } else {
/* 307:674 */       this.view32.put(src.view32);
/* 308:    */     }
/* 309:675 */     return this;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public PointerBuffer put(long[] src, int offset, int length)
/* 313:    */   {
/* 314:719 */     if (is64Bit)
/* 315:    */     {
/* 316:720 */       this.view64.put(src, offset, length);
/* 317:    */     }
/* 318:    */     else
/* 319:    */     {
/* 320:722 */       checkBounds(offset, length, src.length);
/* 321:723 */       if (length > this.view32.remaining()) {
/* 322:724 */         throw new BufferOverflowException();
/* 323:    */       }
/* 324:725 */       int end = offset + length;
/* 325:726 */       for (int i = offset; i < end; i++) {
/* 326:727 */         this.view32.put((int)src[i]);
/* 327:    */       }
/* 328:    */     }
/* 329:730 */     return this;
/* 330:    */   }
/* 331:    */   
/* 332:    */   public final PointerBuffer put(long[] src)
/* 333:    */   {
/* 334:750 */     return put(src, 0, src.length);
/* 335:    */   }
/* 336:    */   
/* 337:    */   public PointerBuffer compact()
/* 338:    */   {
/* 339:776 */     if (is64Bit) {
/* 340:777 */       this.view64.compact();
/* 341:    */     } else {
/* 342:779 */       this.view32.compact();
/* 343:    */     }
/* 344:780 */     return this;
/* 345:    */   }
/* 346:    */   
/* 347:    */   public ByteOrder order()
/* 348:    */   {
/* 349:796 */     if (is64Bit) {
/* 350:797 */       return this.view64.order();
/* 351:    */     }
/* 352:799 */     return this.view32.order();
/* 353:    */   }
/* 354:    */   
/* 355:    */   public String toString()
/* 356:    */   {
/* 357:808 */     StringBuilder sb = new StringBuilder(48);
/* 358:809 */     sb.append(getClass().getName());
/* 359:810 */     sb.append("[pos=");
/* 360:811 */     sb.append(position());
/* 361:812 */     sb.append(" lim=");
/* 362:813 */     sb.append(limit());
/* 363:814 */     sb.append(" cap=");
/* 364:815 */     sb.append(capacity());
/* 365:816 */     sb.append("]");
/* 366:817 */     return sb.toString();
/* 367:    */   }
/* 368:    */   
/* 369:    */   public int hashCode()
/* 370:    */   {
/* 371:834 */     int h = 1;
/* 372:835 */     int p = position();
/* 373:836 */     for (int i = limit() - 1; i >= p; i--) {
/* 374:837 */       h = 31 * h + (int)get(i);
/* 375:    */     }
/* 376:838 */     return h;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public boolean equals(Object ob)
/* 380:    */   {
/* 381:867 */     if (!(ob instanceof PointerBuffer)) {
/* 382:868 */       return false;
/* 383:    */     }
/* 384:869 */     PointerBuffer that = (PointerBuffer)ob;
/* 385:870 */     if (remaining() != that.remaining()) {
/* 386:871 */       return false;
/* 387:    */     }
/* 388:872 */     int p = position();
/* 389:873 */     int i = limit() - 1;
/* 390:873 */     for (int j = that.limit() - 1; i >= p; j--)
/* 391:    */     {
/* 392:874 */       long v1 = get(i);
/* 393:875 */       long v2 = that.get(j);
/* 394:876 */       if (v1 != v2) {
/* 395:877 */         return false;
/* 396:    */       }
/* 397:873 */       i--;
/* 398:    */     }
/* 399:880 */     return true;
/* 400:    */   }
/* 401:    */   
/* 402:    */   public int compareTo(Object o)
/* 403:    */   {
/* 404:896 */     PointerBuffer that = (PointerBuffer)o;
/* 405:897 */     int n = position() + Math.min(remaining(), that.remaining());
/* 406:898 */     int i = position();
/* 407:898 */     for (int j = that.position(); i < n; j++)
/* 408:    */     {
/* 409:899 */       long v1 = get(i);
/* 410:900 */       long v2 = that.get(j);
/* 411:901 */       if (v1 != v2)
/* 412:    */       {
/* 413:903 */         if (v1 < v2) {
/* 414:904 */           return -1;
/* 415:    */         }
/* 416:905 */         return 1;
/* 417:    */       }
/* 418:898 */       i++;
/* 419:    */     }
/* 420:907 */     return remaining() - that.remaining();
/* 421:    */   }
/* 422:    */   
/* 423:    */   private static void checkBounds(int off, int len, int size)
/* 424:    */   {
/* 425:911 */     if ((off | len | off + len | size - (off + len)) < 0) {
/* 426:912 */       throw new IndexOutOfBoundsException();
/* 427:    */     }
/* 428:    */   }
/* 429:    */   
/* 430:    */   private static final class PointerBufferR
/* 431:    */     extends PointerBuffer
/* 432:    */   {
/* 433:    */     PointerBufferR(ByteBuffer source)
/* 434:    */     {
/* 435:923 */       super();
/* 436:    */     }
/* 437:    */     
/* 438:    */     public boolean isReadOnly()
/* 439:    */     {
/* 440:927 */       return true;
/* 441:    */     }
/* 442:    */     
/* 443:    */     protected PointerBuffer newInstance(ByteBuffer source)
/* 444:    */     {
/* 445:931 */       return new PointerBufferR(source);
/* 446:    */     }
/* 447:    */     
/* 448:    */     public PointerBuffer asReadOnlyBuffer()
/* 449:    */     {
/* 450:935 */       return duplicate();
/* 451:    */     }
/* 452:    */     
/* 453:    */     public PointerBuffer put(long l)
/* 454:    */     {
/* 455:939 */       throw new ReadOnlyBufferException();
/* 456:    */     }
/* 457:    */     
/* 458:    */     public PointerBuffer put(int index, long l)
/* 459:    */     {
/* 460:943 */       throw new ReadOnlyBufferException();
/* 461:    */     }
/* 462:    */     
/* 463:    */     public PointerBuffer put(PointerBuffer src)
/* 464:    */     {
/* 465:947 */       throw new ReadOnlyBufferException();
/* 466:    */     }
/* 467:    */     
/* 468:    */     public PointerBuffer put(long[] src, int offset, int length)
/* 469:    */     {
/* 470:951 */       throw new ReadOnlyBufferException();
/* 471:    */     }
/* 472:    */     
/* 473:    */     public PointerBuffer compact()
/* 474:    */     {
/* 475:955 */       throw new ReadOnlyBufferException();
/* 476:    */     }
/* 477:    */   }
/* 478:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.PointerBuffer
 * JD-Core Version:    0.7.0.1
 */