/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ public final class CLEvent
/*   4:    */   extends CLObjectChild<CLContext>
/*   5:    */ {
/*   6: 41 */   private static final CLEventUtil util = (CLEventUtil)CLPlatform.getInfoUtilInstance(CLEvent.class, "CL_EVENT_UTIL");
/*   7:    */   private final CLCommandQueue queue;
/*   8:    */   
/*   9:    */   CLEvent(long pointer, CLContext context)
/*  10:    */   {
/*  11: 46 */     this(pointer, context, null);
/*  12:    */   }
/*  13:    */   
/*  14:    */   CLEvent(long pointer, CLCommandQueue queue)
/*  15:    */   {
/*  16: 50 */     this(pointer, (CLContext)queue.getParent(), queue);
/*  17:    */   }
/*  18:    */   
/*  19:    */   CLEvent(long pointer, CLContext context, CLCommandQueue queue)
/*  20:    */   {
/*  21: 54 */     super(pointer, context);
/*  22: 55 */     if (isValid())
/*  23:    */     {
/*  24: 56 */       this.queue = queue;
/*  25: 57 */       if (queue == null) {
/*  26: 58 */         context.getCLEventRegistry().registerObject(this);
/*  27:    */       } else {
/*  28: 60 */         queue.getCLEventRegistry().registerObject(this);
/*  29:    */       }
/*  30:    */     }
/*  31:    */     else
/*  32:    */     {
/*  33: 62 */       this.queue = null;
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public CLCommandQueue getCLCommandQueue()
/*  38:    */   {
/*  39: 72 */     return this.queue;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public int getInfoInt(int param_name)
/*  43:    */   {
/*  44: 85 */     return util.getInfoInt(this, param_name);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public long getProfilingInfoLong(int param_name)
/*  48:    */   {
/*  49: 99 */     return util.getProfilingInfoLong(this, param_name);
/*  50:    */   }
/*  51:    */   
/*  52:    */   CLObjectRegistry<CLEvent> getParentRegistry()
/*  53:    */   {
/*  54:112 */     if (this.queue == null) {
/*  55:113 */       return ((CLContext)getParent()).getCLEventRegistry();
/*  56:    */     }
/*  57:115 */     return this.queue.getCLEventRegistry();
/*  58:    */   }
/*  59:    */   
/*  60:    */   int release()
/*  61:    */   {
/*  62:    */     try
/*  63:    */     {
/*  64:120 */       return super.release();
/*  65:    */     }
/*  66:    */     finally
/*  67:    */     {
/*  68:122 */       if (!isValid()) {
/*  69:123 */         if (this.queue == null) {
/*  70:124 */           ((CLContext)getParent()).getCLEventRegistry().unregisterObject(this);
/*  71:    */         } else {
/*  72:126 */           this.queue.getCLEventRegistry().unregisterObject(this);
/*  73:    */         }
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   static abstract interface CLEventUtil
/*  79:    */     extends InfoUtil<CLEvent>
/*  80:    */   {
/*  81:    */     public abstract long getProfilingInfoLong(CLEvent paramCLEvent, int paramInt);
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLEvent
 * JD-Core Version:    0.7.0.1
 */