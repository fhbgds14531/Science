/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTStencilClearTag
/*  6:   */ {
/*  7:   */   public static final int GL_STENCIL_TAG_BITS_EXT = 35058;
/*  8:   */   public static final int GL_STENCIL_CLEAR_TAG_VALUE_EXT = 35059;
/*  9:   */   
/* 10:   */   public static void glStencilClearTagEXT(int stencilTagBits, int stencilClearTag)
/* 11:   */   {
/* 12:25 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:26 */     long function_pointer = caps.glStencilClearTagEXT;
/* 14:27 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:28 */     nglStencilClearTagEXT(stencilTagBits, stencilClearTag, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglStencilClearTagEXT(int paramInt1, int paramInt2, long paramLong);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTStencilClearTag
 * JD-Core Version:    0.7.0.1
 */