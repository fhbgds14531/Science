/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class MacOSXPbufferPeerInfo
/*  7:   */   extends MacOSXPeerInfo
/*  8:   */ {
/*  9:   */   MacOSXPbufferPeerInfo(int width, int height, PixelFormat pixel_format, ContextAttribs attribs)
/* 10:   */     throws LWJGLException
/* 11:   */   {
/* 12:46 */     super(pixel_format, attribs, false, false, true, false);
/* 13:47 */     nCreate(getHandle(), width, height);
/* 14:   */   }
/* 15:   */   
/* 16:   */   private static native void nCreate(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2)
/* 17:   */     throws LWJGLException;
/* 18:   */   
/* 19:   */   public void destroy()
/* 20:   */   {
/* 21:52 */     nDestroy(getHandle());
/* 22:   */   }
/* 23:   */   
/* 24:   */   private static native void nDestroy(ByteBuffer paramByteBuffer);
/* 25:   */   
/* 26:   */   protected void doLockAndInitHandle()
/* 27:   */     throws LWJGLException
/* 28:   */   {}
/* 29:   */   
/* 30:   */   protected void doUnlock()
/* 31:   */     throws LWJGLException
/* 32:   */   {}
/* 33:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXPbufferPeerInfo
 * JD-Core Version:    0.7.0.1
 */