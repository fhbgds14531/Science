/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.MemoryUtil;
/*   8:    */ 
/*   9:    */ public final class NVPathRendering
/*  10:    */ {
/*  11:    */   public static final int GL_CLOSE_PATH_NV = 0;
/*  12:    */   public static final int GL_MOVE_TO_NV = 2;
/*  13:    */   public static final int GL_RELATIVE_MOVE_TO_NV = 3;
/*  14:    */   public static final int GL_LINE_TO_NV = 4;
/*  15:    */   public static final int GL_RELATIVE_LINE_TO_NV = 5;
/*  16:    */   public static final int GL_HORIZONTAL_LINE_TO_NV = 6;
/*  17:    */   public static final int GL_RELATIVE_HORIZONTAL_LINE_TO_NV = 7;
/*  18:    */   public static final int GL_VERTICAL_LINE_TO_NV = 8;
/*  19:    */   public static final int GL_RELATIVE_VERTICAL_LINE_TO_NV = 9;
/*  20:    */   public static final int GL_QUADRATIC_CURVE_TO_NV = 10;
/*  21:    */   public static final int GL_RELATIVE_QUADRATIC_CURVE_TO_NV = 11;
/*  22:    */   public static final int GL_CUBIC_CURVE_TO_NV = 12;
/*  23:    */   public static final int GL_RELATIVE_CUBIC_CURVE_TO_NV = 13;
/*  24:    */   public static final int GL_SMOOTH_QUADRATIC_CURVE_TO_NV = 14;
/*  25:    */   public static final int GL_RELATIVE_SMOOTH_QUADRATIC_CURVE_TO_NV = 15;
/*  26:    */   public static final int GL_SMOOTH_CUBIC_CURVE_TO_NV = 16;
/*  27:    */   public static final int GL_RELATIVE_SMOOTH_CUBIC_CURVE_TO_NV = 17;
/*  28:    */   public static final int GL_SMALL_CCW_ARC_TO_NV = 18;
/*  29:    */   public static final int GL_RELATIVE_SMALL_CCW_ARC_TO_NV = 19;
/*  30:    */   public static final int GL_SMALL_CW_ARC_TO_NV = 20;
/*  31:    */   public static final int GL_RELATIVE_SMALL_CW_ARC_TO_NV = 21;
/*  32:    */   public static final int GL_LARGE_CCW_ARC_TO_NV = 22;
/*  33:    */   public static final int GL_RELATIVE_LARGE_CCW_ARC_TO_NV = 23;
/*  34:    */   public static final int GL_LARGE_CW_ARC_TO_NV = 24;
/*  35:    */   public static final int GL_RELATIVE_LARGE_CW_ARC_TO_NV = 25;
/*  36:    */   public static final int GL_CIRCULAR_CCW_ARC_TO_NV = 248;
/*  37:    */   public static final int GL_CIRCULAR_CW_ARC_TO_NV = 250;
/*  38:    */   public static final int GL_CIRCULAR_TANGENT_ARC_TO_NV = 252;
/*  39:    */   public static final int GL_ARC_TO_NV = 254;
/*  40:    */   public static final int GL_RELATIVE_ARC_TO_NV = 255;
/*  41:    */   public static final int GL_PATH_FORMAT_SVG_NV = 36976;
/*  42:    */   public static final int GL_PATH_FORMAT_PS_NV = 36977;
/*  43:    */   public static final int GL_STANDARD_FONT_NAME_NV = 36978;
/*  44:    */   public static final int GL_SYSTEM_FONT_NAME_NV = 36979;
/*  45:    */   public static final int GL_FILE_NAME_NV = 36980;
/*  46:    */   public static final int GL_SKIP_MISSING_GLYPH_NV = 37033;
/*  47:    */   public static final int GL_USE_MISSING_GLYPH_NV = 37034;
/*  48:    */   public static final int GL_PATH_STROKE_WIDTH_NV = 36981;
/*  49:    */   public static final int GL_PATH_INITIAL_END_CAP_NV = 36983;
/*  50:    */   public static final int GL_PATH_TERMINAL_END_CAP_NV = 36984;
/*  51:    */   public static final int GL_PATH_JOIN_STYLE_NV = 36985;
/*  52:    */   public static final int GL_PATH_MITER_LIMIT_NV = 36986;
/*  53:    */   public static final int GL_PATH_INITIAL_DASH_CAP_NV = 36988;
/*  54:    */   public static final int GL_PATH_TERMINAL_DASH_CAP_NV = 36989;
/*  55:    */   public static final int GL_PATH_DASH_OFFSET_NV = 36990;
/*  56:    */   public static final int GL_PATH_CLIENT_LENGTH_NV = 36991;
/*  57:    */   public static final int GL_PATH_DASH_OFFSET_RESET_NV = 37044;
/*  58:    */   public static final int GL_PATH_FILL_MODE_NV = 36992;
/*  59:    */   public static final int GL_PATH_FILL_MASK_NV = 36993;
/*  60:    */   public static final int GL_PATH_FILL_COVER_MODE_NV = 36994;
/*  61:    */   public static final int GL_PATH_STROKE_COVER_MODE_NV = 36995;
/*  62:    */   public static final int GL_PATH_STROKE_MASK_NV = 36996;
/*  63:    */   public static final int GL_PATH_END_CAPS_NV = 36982;
/*  64:    */   public static final int GL_PATH_DASH_CAPS_NV = 36987;
/*  65:    */   public static final int GL_COUNT_UP_NV = 37000;
/*  66:    */   public static final int GL_COUNT_DOWN_NV = 37001;
/*  67:    */   public static final int GL_PRIMARY_COLOR = 34167;
/*  68:    */   public static final int GL_PRIMARY_COLOR_NV = 34092;
/*  69:    */   public static final int GL_SECONDARY_COLOR_NV = 34093;
/*  70:    */   public static final int GL_PATH_OBJECT_BOUNDING_BOX_NV = 37002;
/*  71:    */   public static final int GL_CONVEX_HULL_NV = 37003;
/*  72:    */   public static final int GL_BOUNDING_BOX_NV = 37005;
/*  73:    */   public static final int GL_TRANSLATE_X_NV = 37006;
/*  74:    */   public static final int GL_TRANSLATE_Y_NV = 37007;
/*  75:    */   public static final int GL_TRANSLATE_2D_NV = 37008;
/*  76:    */   public static final int GL_TRANSLATE_3D_NV = 37009;
/*  77:    */   public static final int GL_AFFINE_2D_NV = 37010;
/*  78:    */   public static final int GL_AFFINE_3D_NV = 37012;
/*  79:    */   public static final int GL_TRANSPOSE_AFFINE_2D_NV = 37014;
/*  80:    */   public static final int GL_TRANSPOSE_AFFINE_3D_NV = 37016;
/*  81:    */   public static final int GL_UTF8_NV = 37018;
/*  82:    */   public static final int GL_UTF16_NV = 37019;
/*  83:    */   public static final int GL_BOUNDING_BOX_OF_BOUNDING_BOXES_NV = 37020;
/*  84:    */   public static final int GL_PATH_COMMAND_COUNT_NV = 37021;
/*  85:    */   public static final int GL_PATH_COORD_COUNT_NV = 37022;
/*  86:    */   public static final int GL_PATH_DASH_ARRAY_COUNT_NV = 37023;
/*  87:    */   public static final int GL_PATH_COMPUTED_LENGTH_NV = 37024;
/*  88:    */   public static final int GL_PATH_FILL_BOUNDING_BOX_NV = 37025;
/*  89:    */   public static final int GL_PATH_STROKE_BOUNDING_BOX_NV = 37026;
/*  90:    */   public static final int GL_SQUARE_NV = 37027;
/*  91:    */   public static final int GL_ROUND_NV = 37028;
/*  92:    */   public static final int GL_TRIANGULAR_NV = 37029;
/*  93:    */   public static final int GL_BEVEL_NV = 37030;
/*  94:    */   public static final int GL_MITER_REVERT_NV = 37031;
/*  95:    */   public static final int GL_MITER_TRUNCATE_NV = 37032;
/*  96:    */   public static final int GL_MOVE_TO_RESETS_NV = 37045;
/*  97:    */   public static final int GL_MOVE_TO_CONTINUES_NV = 37046;
/*  98:    */   public static final int GL_BOLD_BIT_NV = 1;
/*  99:    */   public static final int GL_ITALIC_BIT_NV = 2;
/* 100:    */   public static final int GL_PATH_ERROR_POSITION_NV = 37035;
/* 101:    */   public static final int GL_PATH_FOG_GEN_MODE_NV = 37036;
/* 102:    */   public static final int GL_PATH_STENCIL_FUNC_NV = 37047;
/* 103:    */   public static final int GL_PATH_STENCIL_REF_NV = 37048;
/* 104:    */   public static final int GL_PATH_STENCIL_VALUE_MASK_NV = 37049;
/* 105:    */   public static final int GL_PATH_STENCIL_DEPTH_OFFSET_FACTOR_NV = 37053;
/* 106:    */   public static final int GL_PATH_STENCIL_DEPTH_OFFSET_UNITS_NV = 37054;
/* 107:    */   public static final int GL_PATH_COVER_DEPTH_FUNC_NV = 37055;
/* 108:    */   public static final int GL_GLYPH_WIDTH_BIT_NV = 1;
/* 109:    */   public static final int GL_GLYPH_HEIGHT_BIT_NV = 2;
/* 110:    */   public static final int GL_GLYPH_HORIZONTAL_BEARING_X_BIT_NV = 4;
/* 111:    */   public static final int GL_GLYPH_HORIZONTAL_BEARING_Y_BIT_NV = 8;
/* 112:    */   public static final int GL_GLYPH_HORIZONTAL_BEARING_ADVANCE_BIT_NV = 16;
/* 113:    */   public static final int GL_GLYPH_VERTICAL_BEARING_X_BIT_NV = 32;
/* 114:    */   public static final int GL_GLYPH_VERTICAL_BEARING_Y_BIT_NV = 64;
/* 115:    */   public static final int GL_GLYPH_VERTICAL_BEARING_ADVANCE_BIT_NV = 128;
/* 116:    */   public static final int GL_GLYPH_HAS_KERNING_NV = 256;
/* 117:    */   public static final int GL_FONT_X_MIN_BOUNDS_NV = 65536;
/* 118:    */   public static final int GL_FONT_Y_MIN_BOUNDS_NV = 131072;
/* 119:    */   public static final int GL_FONT_X_MAX_BOUNDS_NV = 262144;
/* 120:    */   public static final int GL_FONT_Y_MAX_BOUNDS_NV = 524288;
/* 121:    */   public static final int GL_FONT_UNITS_PER_EM_NV = 1048576;
/* 122:    */   public static final int GL_FONT_ASCENDER_NV = 2097152;
/* 123:    */   public static final int GL_FONT_DESCENDER_NV = 4194304;
/* 124:    */   public static final int GL_FONT_HEIGHT_NV = 8388608;
/* 125:    */   public static final int GL_FONT_MAX_ADVANCE_WIDTH_NV = 16777216;
/* 126:    */   public static final int GL_FONT_MAX_ADVANCE_HEIGHT_NV = 33554432;
/* 127:    */   public static final int GL_FONT_UNDERLINE_POSITION_NV = 67108864;
/* 128:    */   public static final int GL_FONT_UNDERLINE_THICKNESS_NV = 134217728;
/* 129:    */   public static final int GL_FONT_HAS_KERNING_NV = 268435456;
/* 130:    */   public static final int GL_ACCUM_ADJACENT_PAIRS_NV = 37037;
/* 131:    */   public static final int GL_ADJACENT_PAIRS_NV = 37038;
/* 132:    */   public static final int GL_FIRST_TO_REST_NV = 37039;
/* 133:    */   public static final int GL_PATH_GEN_MODE_NV = 37040;
/* 134:    */   public static final int GL_PATH_GEN_COEFF_NV = 37041;
/* 135:    */   public static final int GL_PATH_GEN_COLOR_FORMAT_NV = 37042;
/* 136:    */   public static final int GL_PATH_GEN_COMPONENTS_NV = 37043;
/* 137:    */   
/* 138:    */   public static void glPathCommandsNV(int path, ByteBuffer commands, int coordType, ByteBuffer coords)
/* 139:    */   {
/* 140:254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 141:255 */     long function_pointer = caps.glPathCommandsNV;
/* 142:256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 143:257 */     BufferChecks.checkDirect(commands);
/* 144:258 */     BufferChecks.checkDirect(coords);
/* 145:259 */     nglPathCommandsNV(path, commands.remaining(), MemoryUtil.getAddress(commands), coords.remaining(), coordType, MemoryUtil.getAddress(coords), function_pointer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   static native void nglPathCommandsNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2, long paramLong3);
/* 149:    */   
/* 150:    */   public static void glPathCoordsNV(int path, int coordType, ByteBuffer coords)
/* 151:    */   {
/* 152:264 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 153:265 */     long function_pointer = caps.glPathCoordsNV;
/* 154:266 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 155:267 */     BufferChecks.checkDirect(coords);
/* 156:268 */     nglPathCoordsNV(path, coords.remaining(), coordType, MemoryUtil.getAddress(coords), function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static native void nglPathCoordsNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 160:    */   
/* 161:    */   public static void glPathSubCommandsNV(int path, int commandStart, int commandsToDelete, ByteBuffer commands, int coordType, ByteBuffer coords)
/* 162:    */   {
/* 163:273 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 164:274 */     long function_pointer = caps.glPathSubCommandsNV;
/* 165:275 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 166:276 */     BufferChecks.checkDirect(commands);
/* 167:277 */     BufferChecks.checkDirect(coords);
/* 168:278 */     nglPathSubCommandsNV(path, commandStart, commandsToDelete, commands.remaining(), MemoryUtil.getAddress(commands), coords.remaining(), coordType, MemoryUtil.getAddress(coords), function_pointer);
/* 169:    */   }
/* 170:    */   
/* 171:    */   static native void nglPathSubCommandsNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, int paramInt5, int paramInt6, long paramLong2, long paramLong3);
/* 172:    */   
/* 173:    */   public static void glPathSubCoordsNV(int path, int coordStart, int coordType, ByteBuffer coords)
/* 174:    */   {
/* 175:283 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 176:284 */     long function_pointer = caps.glPathSubCoordsNV;
/* 177:285 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 178:286 */     BufferChecks.checkDirect(coords);
/* 179:287 */     nglPathSubCoordsNV(path, coordStart, coords.remaining(), coordType, MemoryUtil.getAddress(coords), function_pointer);
/* 180:    */   }
/* 181:    */   
/* 182:    */   static native void nglPathSubCoordsNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 183:    */   
/* 184:    */   public static void glPathStringNV(int path, int format, ByteBuffer pathString)
/* 185:    */   {
/* 186:292 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 187:293 */     long function_pointer = caps.glPathStringNV;
/* 188:294 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 189:295 */     BufferChecks.checkDirect(pathString);
/* 190:296 */     nglPathStringNV(path, format, pathString.remaining(), MemoryUtil.getAddress(pathString), function_pointer);
/* 191:    */   }
/* 192:    */   
/* 193:    */   static native void nglPathStringNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 194:    */   
/* 195:    */   public static void glPathGlyphsNV(int firstPathName, int fontTarget, ByteBuffer fontName, int fontStyle, int type, ByteBuffer charcodes, int handleMissingGlyphs, int pathParameterTemplate, float emScale)
/* 196:    */   {
/* 197:301 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 198:302 */     long function_pointer = caps.glPathGlyphsNV;
/* 199:303 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 200:304 */     BufferChecks.checkDirect(fontName);
/* 201:305 */     BufferChecks.checkNullTerminated(fontName);
/* 202:306 */     BufferChecks.checkDirect(charcodes);
/* 203:307 */     nglPathGlyphsNV(firstPathName, fontTarget, MemoryUtil.getAddress(fontName), fontStyle, charcodes.remaining() / GLChecks.calculateBytesPerCharCode(type), type, MemoryUtil.getAddress(charcodes), handleMissingGlyphs, pathParameterTemplate, emScale, function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   static native void nglPathGlyphsNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, long paramLong2, int paramInt6, int paramInt7, float paramFloat, long paramLong3);
/* 207:    */   
/* 208:    */   public static void glPathGlyphRangeNV(int firstPathName, int fontTarget, ByteBuffer fontName, int fontStyle, int firstGlyph, int numGlyphs, int handleMissingGlyphs, int pathParameterTemplate, float emScale)
/* 209:    */   {
/* 210:312 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 211:313 */     long function_pointer = caps.glPathGlyphRangeNV;
/* 212:314 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 213:315 */     BufferChecks.checkDirect(fontName);
/* 214:316 */     BufferChecks.checkNullTerminated(fontName);
/* 215:317 */     nglPathGlyphRangeNV(firstPathName, fontTarget, MemoryUtil.getAddress(fontName), fontStyle, firstGlyph, numGlyphs, handleMissingGlyphs, pathParameterTemplate, emScale, function_pointer);
/* 216:    */   }
/* 217:    */   
/* 218:    */   static native void nglPathGlyphRangeNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, float paramFloat, long paramLong2);
/* 219:    */   
/* 220:    */   public static void glWeightPathsNV(int resultPath, IntBuffer paths, FloatBuffer weights)
/* 221:    */   {
/* 222:322 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 223:323 */     long function_pointer = caps.glWeightPathsNV;
/* 224:324 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 225:325 */     BufferChecks.checkDirect(paths);
/* 226:326 */     BufferChecks.checkBuffer(weights, paths.remaining());
/* 227:327 */     nglWeightPathsNV(resultPath, paths.remaining(), MemoryUtil.getAddress(paths), MemoryUtil.getAddress(weights), function_pointer);
/* 228:    */   }
/* 229:    */   
/* 230:    */   static native void nglWeightPathsNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 231:    */   
/* 232:    */   public static void glCopyPathNV(int resultPath, int srcPath)
/* 233:    */   {
/* 234:332 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 235:333 */     long function_pointer = caps.glCopyPathNV;
/* 236:334 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 237:335 */     nglCopyPathNV(resultPath, srcPath, function_pointer);
/* 238:    */   }
/* 239:    */   
/* 240:    */   static native void nglCopyPathNV(int paramInt1, int paramInt2, long paramLong);
/* 241:    */   
/* 242:    */   public static void glInterpolatePathsNV(int resultPath, int pathA, int pathB, float weight)
/* 243:    */   {
/* 244:340 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 245:341 */     long function_pointer = caps.glInterpolatePathsNV;
/* 246:342 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 247:343 */     nglInterpolatePathsNV(resultPath, pathA, pathB, weight, function_pointer);
/* 248:    */   }
/* 249:    */   
/* 250:    */   static native void nglInterpolatePathsNV(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong);
/* 251:    */   
/* 252:    */   public static void glTransformPathNV(int resultPath, int srcPath, int transformType, FloatBuffer transformValues)
/* 253:    */   {
/* 254:348 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 255:349 */     long function_pointer = caps.glTransformPathNV;
/* 256:350 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 257:351 */     if (transformValues != null) {
/* 258:352 */       BufferChecks.checkBuffer(transformValues, GLChecks.calculateTransformPathValues(transformType));
/* 259:    */     }
/* 260:353 */     nglTransformPathNV(resultPath, srcPath, transformType, MemoryUtil.getAddressSafe(transformValues), function_pointer);
/* 261:    */   }
/* 262:    */   
/* 263:    */   static native void nglTransformPathNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 264:    */   
/* 265:    */   public static void glPathParameterNV(int path, int pname, IntBuffer value)
/* 266:    */   {
/* 267:358 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 268:359 */     long function_pointer = caps.glPathParameterivNV;
/* 269:360 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 270:361 */     BufferChecks.checkBuffer(value, 4);
/* 271:362 */     nglPathParameterivNV(path, pname, MemoryUtil.getAddress(value), function_pointer);
/* 272:    */   }
/* 273:    */   
/* 274:    */   static native void nglPathParameterivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 275:    */   
/* 276:    */   public static void glPathParameteriNV(int path, int pname, int value)
/* 277:    */   {
/* 278:367 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 279:368 */     long function_pointer = caps.glPathParameteriNV;
/* 280:369 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 281:370 */     nglPathParameteriNV(path, pname, value, function_pointer);
/* 282:    */   }
/* 283:    */   
/* 284:    */   static native void nglPathParameteriNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 285:    */   
/* 286:    */   public static void glPathParameterfNV(int path, int pname, IntBuffer value)
/* 287:    */   {
/* 288:375 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 289:376 */     long function_pointer = caps.glPathParameterfvNV;
/* 290:377 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 291:378 */     BufferChecks.checkBuffer(value, 4);
/* 292:379 */     nglPathParameterfvNV(path, pname, MemoryUtil.getAddress(value), function_pointer);
/* 293:    */   }
/* 294:    */   
/* 295:    */   static native void nglPathParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 296:    */   
/* 297:    */   public static void glPathParameterfNV(int path, int pname, float value)
/* 298:    */   {
/* 299:384 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 300:385 */     long function_pointer = caps.glPathParameterfNV;
/* 301:386 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 302:387 */     nglPathParameterfNV(path, pname, value, function_pointer);
/* 303:    */   }
/* 304:    */   
/* 305:    */   static native void nglPathParameterfNV(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 306:    */   
/* 307:    */   public static void glPathDashArrayNV(int path, FloatBuffer dashArray)
/* 308:    */   {
/* 309:392 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 310:393 */     long function_pointer = caps.glPathDashArrayNV;
/* 311:394 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 312:395 */     BufferChecks.checkDirect(dashArray);
/* 313:396 */     nglPathDashArrayNV(path, dashArray.remaining(), MemoryUtil.getAddress(dashArray), function_pointer);
/* 314:    */   }
/* 315:    */   
/* 316:    */   static native void nglPathDashArrayNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 317:    */   
/* 318:    */   public static int glGenPathsNV(int range)
/* 319:    */   {
/* 320:401 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 321:402 */     long function_pointer = caps.glGenPathsNV;
/* 322:403 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 323:404 */     int __result = nglGenPathsNV(range, function_pointer);
/* 324:405 */     return __result;
/* 325:    */   }
/* 326:    */   
/* 327:    */   static native int nglGenPathsNV(int paramInt, long paramLong);
/* 328:    */   
/* 329:    */   public static void glDeletePathsNV(int path, int range)
/* 330:    */   {
/* 331:410 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 332:411 */     long function_pointer = caps.glDeletePathsNV;
/* 333:412 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 334:413 */     nglDeletePathsNV(path, range, function_pointer);
/* 335:    */   }
/* 336:    */   
/* 337:    */   static native void nglDeletePathsNV(int paramInt1, int paramInt2, long paramLong);
/* 338:    */   
/* 339:    */   public static boolean glIsPathNV(int path)
/* 340:    */   {
/* 341:418 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 342:419 */     long function_pointer = caps.glIsPathNV;
/* 343:420 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 344:421 */     boolean __result = nglIsPathNV(path, function_pointer);
/* 345:422 */     return __result;
/* 346:    */   }
/* 347:    */   
/* 348:    */   static native boolean nglIsPathNV(int paramInt, long paramLong);
/* 349:    */   
/* 350:    */   public static void glPathStencilFuncNV(int func, int ref, int mask)
/* 351:    */   {
/* 352:427 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 353:428 */     long function_pointer = caps.glPathStencilFuncNV;
/* 354:429 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 355:430 */     nglPathStencilFuncNV(func, ref, mask, function_pointer);
/* 356:    */   }
/* 357:    */   
/* 358:    */   static native void nglPathStencilFuncNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 359:    */   
/* 360:    */   public static void glPathStencilDepthOffsetNV(float factor, int units)
/* 361:    */   {
/* 362:435 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 363:436 */     long function_pointer = caps.glPathStencilDepthOffsetNV;
/* 364:437 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 365:438 */     nglPathStencilDepthOffsetNV(factor, units, function_pointer);
/* 366:    */   }
/* 367:    */   
/* 368:    */   static native void nglPathStencilDepthOffsetNV(float paramFloat, int paramInt, long paramLong);
/* 369:    */   
/* 370:    */   public static void glStencilFillPathNV(int path, int fillMode, int mask)
/* 371:    */   {
/* 372:443 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 373:444 */     long function_pointer = caps.glStencilFillPathNV;
/* 374:445 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 375:446 */     nglStencilFillPathNV(path, fillMode, mask, function_pointer);
/* 376:    */   }
/* 377:    */   
/* 378:    */   static native void nglStencilFillPathNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 379:    */   
/* 380:    */   public static void glStencilStrokePathNV(int path, int reference, int mask)
/* 381:    */   {
/* 382:451 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 383:452 */     long function_pointer = caps.glStencilStrokePathNV;
/* 384:453 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 385:454 */     nglStencilStrokePathNV(path, reference, mask, function_pointer);
/* 386:    */   }
/* 387:    */   
/* 388:    */   static native void nglStencilStrokePathNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 389:    */   
/* 390:    */   public static void glStencilFillPathInstancedNV(int pathNameType, ByteBuffer paths, int pathBase, int fillMode, int mask, int transformType, FloatBuffer transformValues)
/* 391:    */   {
/* 392:459 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 393:460 */     long function_pointer = caps.glStencilFillPathInstancedNV;
/* 394:461 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 395:462 */     BufferChecks.checkDirect(paths);
/* 396:463 */     if (transformValues != null) {
/* 397:464 */       BufferChecks.checkBuffer(transformValues, GLChecks.calculateTransformPathValues(transformType));
/* 398:    */     }
/* 399:465 */     nglStencilFillPathInstancedNV(paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType), pathNameType, MemoryUtil.getAddress(paths), pathBase, fillMode, mask, transformType, MemoryUtil.getAddressSafe(transformValues), function_pointer);
/* 400:    */   }
/* 401:    */   
/* 402:    */   static native void nglStencilFillPathInstancedNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong2, long paramLong3);
/* 403:    */   
/* 404:    */   public static void glStencilStrokePathInstancedNV(int pathNameType, ByteBuffer paths, int pathBase, int reference, int mask, int transformType, FloatBuffer transformValues)
/* 405:    */   {
/* 406:470 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 407:471 */     long function_pointer = caps.glStencilStrokePathInstancedNV;
/* 408:472 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 409:473 */     BufferChecks.checkDirect(paths);
/* 410:474 */     if (transformValues != null) {
/* 411:475 */       BufferChecks.checkBuffer(transformValues, GLChecks.calculateTransformPathValues(transformType));
/* 412:    */     }
/* 413:476 */     nglStencilStrokePathInstancedNV(paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType), pathNameType, MemoryUtil.getAddress(paths), pathBase, reference, mask, transformType, MemoryUtil.getAddressSafe(transformValues), function_pointer);
/* 414:    */   }
/* 415:    */   
/* 416:    */   static native void nglStencilStrokePathInstancedNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong2, long paramLong3);
/* 417:    */   
/* 418:    */   public static void glPathCoverDepthFuncNV(int zfunc)
/* 419:    */   {
/* 420:481 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 421:482 */     long function_pointer = caps.glPathCoverDepthFuncNV;
/* 422:483 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 423:484 */     nglPathCoverDepthFuncNV(zfunc, function_pointer);
/* 424:    */   }
/* 425:    */   
/* 426:    */   static native void nglPathCoverDepthFuncNV(int paramInt, long paramLong);
/* 427:    */   
/* 428:    */   public static void glPathColorGenNV(int color, int genMode, int colorFormat, FloatBuffer coeffs)
/* 429:    */   {
/* 430:489 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 431:490 */     long function_pointer = caps.glPathColorGenNV;
/* 432:491 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 433:492 */     if (coeffs != null) {
/* 434:493 */       BufferChecks.checkBuffer(coeffs, GLChecks.calculatePathColorGenCoeffsCount(genMode, colorFormat));
/* 435:    */     }
/* 436:494 */     nglPathColorGenNV(color, genMode, colorFormat, MemoryUtil.getAddressSafe(coeffs), function_pointer);
/* 437:    */   }
/* 438:    */   
/* 439:    */   static native void nglPathColorGenNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 440:    */   
/* 441:    */   public static void glPathTexGenNV(int texCoordSet, int genMode, FloatBuffer coeffs)
/* 442:    */   {
/* 443:499 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 444:500 */     long function_pointer = caps.glPathTexGenNV;
/* 445:501 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 446:502 */     if (coeffs != null) {
/* 447:503 */       BufferChecks.checkDirect(coeffs);
/* 448:    */     }
/* 449:504 */     nglPathTexGenNV(texCoordSet, genMode, GLChecks.calculatePathTextGenCoeffsPerComponent(coeffs, genMode), MemoryUtil.getAddressSafe(coeffs), function_pointer);
/* 450:    */   }
/* 451:    */   
/* 452:    */   static native void nglPathTexGenNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 453:    */   
/* 454:    */   public static void glPathFogGenNV(int genMode)
/* 455:    */   {
/* 456:509 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 457:510 */     long function_pointer = caps.glPathFogGenNV;
/* 458:511 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 459:512 */     nglPathFogGenNV(genMode, function_pointer);
/* 460:    */   }
/* 461:    */   
/* 462:    */   static native void nglPathFogGenNV(int paramInt, long paramLong);
/* 463:    */   
/* 464:    */   public static void glCoverFillPathNV(int path, int coverMode)
/* 465:    */   {
/* 466:517 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 467:518 */     long function_pointer = caps.glCoverFillPathNV;
/* 468:519 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 469:520 */     nglCoverFillPathNV(path, coverMode, function_pointer);
/* 470:    */   }
/* 471:    */   
/* 472:    */   static native void nglCoverFillPathNV(int paramInt1, int paramInt2, long paramLong);
/* 473:    */   
/* 474:    */   public static void glCoverStrokePathNV(int name, int coverMode)
/* 475:    */   {
/* 476:525 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 477:526 */     long function_pointer = caps.glCoverStrokePathNV;
/* 478:527 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 479:528 */     nglCoverStrokePathNV(name, coverMode, function_pointer);
/* 480:    */   }
/* 481:    */   
/* 482:    */   static native void nglCoverStrokePathNV(int paramInt1, int paramInt2, long paramLong);
/* 483:    */   
/* 484:    */   public static void glCoverFillPathInstancedNV(int pathNameType, ByteBuffer paths, int pathBase, int coverMode, int transformType, FloatBuffer transformValues)
/* 485:    */   {
/* 486:533 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 487:534 */     long function_pointer = caps.glCoverFillPathInstancedNV;
/* 488:535 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 489:536 */     BufferChecks.checkDirect(paths);
/* 490:537 */     if (transformValues != null) {
/* 491:538 */       BufferChecks.checkBuffer(transformValues, GLChecks.calculateTransformPathValues(transformType));
/* 492:    */     }
/* 493:539 */     nglCoverFillPathInstancedNV(paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType), pathNameType, MemoryUtil.getAddress(paths), pathBase, coverMode, transformType, MemoryUtil.getAddressSafe(transformValues), function_pointer);
/* 494:    */   }
/* 495:    */   
/* 496:    */   static native void nglCoverFillPathInstancedNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, long paramLong2, long paramLong3);
/* 497:    */   
/* 498:    */   public static void glCoverStrokePathInstancedNV(int pathNameType, ByteBuffer paths, int pathBase, int coverMode, int transformType, FloatBuffer transformValues)
/* 499:    */   {
/* 500:544 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 501:545 */     long function_pointer = caps.glCoverStrokePathInstancedNV;
/* 502:546 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 503:547 */     BufferChecks.checkDirect(paths);
/* 504:548 */     if (transformValues != null) {
/* 505:549 */       BufferChecks.checkBuffer(transformValues, GLChecks.calculateTransformPathValues(transformType));
/* 506:    */     }
/* 507:550 */     nglCoverStrokePathInstancedNV(paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType), pathNameType, MemoryUtil.getAddress(paths), pathBase, coverMode, transformType, MemoryUtil.getAddressSafe(transformValues), function_pointer);
/* 508:    */   }
/* 509:    */   
/* 510:    */   static native void nglCoverStrokePathInstancedNV(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, long paramLong2, long paramLong3);
/* 511:    */   
/* 512:    */   public static void glGetPathParameterNV(int name, int param, IntBuffer value)
/* 513:    */   {
/* 514:555 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 515:556 */     long function_pointer = caps.glGetPathParameterivNV;
/* 516:557 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 517:558 */     BufferChecks.checkBuffer(value, 4);
/* 518:559 */     nglGetPathParameterivNV(name, param, MemoryUtil.getAddress(value), function_pointer);
/* 519:    */   }
/* 520:    */   
/* 521:    */   static native void nglGetPathParameterivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 522:    */   
/* 523:    */   public static int glGetPathParameteriNV(int name, int param)
/* 524:    */   {
/* 525:565 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 526:566 */     long function_pointer = caps.glGetPathParameterivNV;
/* 527:567 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 528:568 */     IntBuffer value = APIUtil.getBufferInt(caps);
/* 529:569 */     nglGetPathParameterivNV(name, param, MemoryUtil.getAddress(value), function_pointer);
/* 530:570 */     return value.get(0);
/* 531:    */   }
/* 532:    */   
/* 533:    */   public static void glGetPathParameterfvNV(int name, int param, FloatBuffer value)
/* 534:    */   {
/* 535:574 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 536:575 */     long function_pointer = caps.glGetPathParameterfvNV;
/* 537:576 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 538:577 */     BufferChecks.checkBuffer(value, 4);
/* 539:578 */     nglGetPathParameterfvNV(name, param, MemoryUtil.getAddress(value), function_pointer);
/* 540:    */   }
/* 541:    */   
/* 542:    */   static native void nglGetPathParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 543:    */   
/* 544:    */   public static float glGetPathParameterfNV(int name, int param)
/* 545:    */   {
/* 546:584 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 547:585 */     long function_pointer = caps.glGetPathParameterfvNV;
/* 548:586 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 549:587 */     FloatBuffer value = APIUtil.getBufferFloat(caps);
/* 550:588 */     nglGetPathParameterfvNV(name, param, MemoryUtil.getAddress(value), function_pointer);
/* 551:589 */     return value.get(0);
/* 552:    */   }
/* 553:    */   
/* 554:    */   public static void glGetPathCommandsNV(int name, ByteBuffer commands)
/* 555:    */   {
/* 556:593 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 557:594 */     long function_pointer = caps.glGetPathCommandsNV;
/* 558:595 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 559:596 */     BufferChecks.checkDirect(commands);
/* 560:597 */     nglGetPathCommandsNV(name, MemoryUtil.getAddress(commands), function_pointer);
/* 561:    */   }
/* 562:    */   
/* 563:    */   static native void nglGetPathCommandsNV(int paramInt, long paramLong1, long paramLong2);
/* 564:    */   
/* 565:    */   public static void glGetPathCoordsNV(int name, FloatBuffer coords)
/* 566:    */   {
/* 567:602 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 568:603 */     long function_pointer = caps.glGetPathCoordsNV;
/* 569:604 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 570:605 */     BufferChecks.checkDirect(coords);
/* 571:606 */     nglGetPathCoordsNV(name, MemoryUtil.getAddress(coords), function_pointer);
/* 572:    */   }
/* 573:    */   
/* 574:    */   static native void nglGetPathCoordsNV(int paramInt, long paramLong1, long paramLong2);
/* 575:    */   
/* 576:    */   public static void glGetPathDashArrayNV(int name, FloatBuffer dashArray)
/* 577:    */   {
/* 578:611 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 579:612 */     long function_pointer = caps.glGetPathDashArrayNV;
/* 580:613 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 581:614 */     BufferChecks.checkDirect(dashArray);
/* 582:615 */     nglGetPathDashArrayNV(name, MemoryUtil.getAddress(dashArray), function_pointer);
/* 583:    */   }
/* 584:    */   
/* 585:    */   static native void nglGetPathDashArrayNV(int paramInt, long paramLong1, long paramLong2);
/* 586:    */   
/* 587:    */   public static void glGetPathMetricsNV(int metricQueryMask, int pathNameType, ByteBuffer paths, int pathBase, int stride, FloatBuffer metrics)
/* 588:    */   {
/* 589:620 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 590:621 */     long function_pointer = caps.glGetPathMetricsNV;
/* 591:622 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 592:623 */     BufferChecks.checkDirect(paths);
/* 593:624 */     BufferChecks.checkBuffer(metrics, GLChecks.calculateMetricsSize(metricQueryMask, stride));
/* 594:625 */     nglGetPathMetricsNV(metricQueryMask, paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType), pathNameType, MemoryUtil.getAddress(paths), pathBase, stride, MemoryUtil.getAddress(metrics), function_pointer);
/* 595:    */   }
/* 596:    */   
/* 597:    */   static native void nglGetPathMetricsNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, int paramInt5, long paramLong2, long paramLong3);
/* 598:    */   
/* 599:    */   public static void glGetPathMetricRangeNV(int metricQueryMask, int fistPathName, int numPaths, int stride, FloatBuffer metrics)
/* 600:    */   {
/* 601:630 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 602:631 */     long function_pointer = caps.glGetPathMetricRangeNV;
/* 603:632 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 604:633 */     BufferChecks.checkBuffer(metrics, GLChecks.calculateMetricsSize(metricQueryMask, stride));
/* 605:634 */     nglGetPathMetricRangeNV(metricQueryMask, fistPathName, numPaths, stride, MemoryUtil.getAddress(metrics), function_pointer);
/* 606:    */   }
/* 607:    */   
/* 608:    */   static native void nglGetPathMetricRangeNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 609:    */   
/* 610:    */   public static void glGetPathSpacingNV(int pathListMode, int pathNameType, ByteBuffer paths, int pathBase, float advanceScale, float kerningScale, int transformType, FloatBuffer returnedSpacing)
/* 611:    */   {
/* 612:639 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 613:640 */     long function_pointer = caps.glGetPathSpacingNV;
/* 614:641 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 615:642 */     int numPaths = paths.remaining() / GLChecks.calculateBytesPerPathName(pathNameType);
/* 616:643 */     BufferChecks.checkDirect(paths);
/* 617:644 */     BufferChecks.checkBuffer(returnedSpacing, numPaths - 1);
/* 618:645 */     nglGetPathSpacingNV(pathListMode, numPaths, pathNameType, MemoryUtil.getAddress(paths), pathBase, advanceScale, kerningScale, transformType, MemoryUtil.getAddress(returnedSpacing), function_pointer);
/* 619:    */   }
/* 620:    */   
/* 621:    */   static native void nglGetPathSpacingNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, float paramFloat1, float paramFloat2, int paramInt5, long paramLong2, long paramLong3);
/* 622:    */   
/* 623:    */   public static void glGetPathColorGenNV(int color, int pname, IntBuffer value)
/* 624:    */   {
/* 625:650 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 626:651 */     long function_pointer = caps.glGetPathColorGenivNV;
/* 627:652 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 628:653 */     BufferChecks.checkBuffer(value, 16);
/* 629:654 */     nglGetPathColorGenivNV(color, pname, MemoryUtil.getAddress(value), function_pointer);
/* 630:    */   }
/* 631:    */   
/* 632:    */   static native void nglGetPathColorGenivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 633:    */   
/* 634:    */   public static int glGetPathColorGeniNV(int color, int pname)
/* 635:    */   {
/* 636:660 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 637:661 */     long function_pointer = caps.glGetPathColorGenivNV;
/* 638:662 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 639:663 */     IntBuffer value = APIUtil.getBufferInt(caps);
/* 640:664 */     nglGetPathColorGenivNV(color, pname, MemoryUtil.getAddress(value), function_pointer);
/* 641:665 */     return value.get(0);
/* 642:    */   }
/* 643:    */   
/* 644:    */   public static void glGetPathColorGenNV(int color, int pname, FloatBuffer value)
/* 645:    */   {
/* 646:669 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 647:670 */     long function_pointer = caps.glGetPathColorGenfvNV;
/* 648:671 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 649:672 */     BufferChecks.checkBuffer(value, 16);
/* 650:673 */     nglGetPathColorGenfvNV(color, pname, MemoryUtil.getAddress(value), function_pointer);
/* 651:    */   }
/* 652:    */   
/* 653:    */   static native void nglGetPathColorGenfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 654:    */   
/* 655:    */   public static float glGetPathColorGenfNV(int color, int pname)
/* 656:    */   {
/* 657:679 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 658:680 */     long function_pointer = caps.glGetPathColorGenfvNV;
/* 659:681 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 660:682 */     FloatBuffer value = APIUtil.getBufferFloat(caps);
/* 661:683 */     nglGetPathColorGenfvNV(color, pname, MemoryUtil.getAddress(value), function_pointer);
/* 662:684 */     return value.get(0);
/* 663:    */   }
/* 664:    */   
/* 665:    */   public static void glGetPathTexGenNV(int texCoordSet, int pname, IntBuffer value)
/* 666:    */   {
/* 667:688 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 668:689 */     long function_pointer = caps.glGetPathTexGenivNV;
/* 669:690 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 670:691 */     BufferChecks.checkBuffer(value, 16);
/* 671:692 */     nglGetPathTexGenivNV(texCoordSet, pname, MemoryUtil.getAddress(value), function_pointer);
/* 672:    */   }
/* 673:    */   
/* 674:    */   static native void nglGetPathTexGenivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 675:    */   
/* 676:    */   public static int glGetPathTexGeniNV(int texCoordSet, int pname)
/* 677:    */   {
/* 678:698 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 679:699 */     long function_pointer = caps.glGetPathTexGenivNV;
/* 680:700 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 681:701 */     IntBuffer value = APIUtil.getBufferInt(caps);
/* 682:702 */     nglGetPathTexGenivNV(texCoordSet, pname, MemoryUtil.getAddress(value), function_pointer);
/* 683:703 */     return value.get(0);
/* 684:    */   }
/* 685:    */   
/* 686:    */   public static void glGetPathTexGenNV(int texCoordSet, int pname, FloatBuffer value)
/* 687:    */   {
/* 688:707 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 689:708 */     long function_pointer = caps.glGetPathTexGenfvNV;
/* 690:709 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 691:710 */     BufferChecks.checkBuffer(value, 16);
/* 692:711 */     nglGetPathTexGenfvNV(texCoordSet, pname, MemoryUtil.getAddress(value), function_pointer);
/* 693:    */   }
/* 694:    */   
/* 695:    */   static native void nglGetPathTexGenfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 696:    */   
/* 697:    */   public static float glGetPathTexGenfNV(int texCoordSet, int pname)
/* 698:    */   {
/* 699:717 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 700:718 */     long function_pointer = caps.glGetPathTexGenfvNV;
/* 701:719 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 702:720 */     FloatBuffer value = APIUtil.getBufferFloat(caps);
/* 703:721 */     nglGetPathTexGenfvNV(texCoordSet, pname, MemoryUtil.getAddress(value), function_pointer);
/* 704:722 */     return value.get(0);
/* 705:    */   }
/* 706:    */   
/* 707:    */   public static boolean glIsPointInFillPathNV(int path, int mask, float x, float y)
/* 708:    */   {
/* 709:726 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 710:727 */     long function_pointer = caps.glIsPointInFillPathNV;
/* 711:728 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 712:729 */     boolean __result = nglIsPointInFillPathNV(path, mask, x, y, function_pointer);
/* 713:730 */     return __result;
/* 714:    */   }
/* 715:    */   
/* 716:    */   static native boolean nglIsPointInFillPathNV(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, long paramLong);
/* 717:    */   
/* 718:    */   public static boolean glIsPointInStrokePathNV(int path, float x, float y)
/* 719:    */   {
/* 720:735 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 721:736 */     long function_pointer = caps.glIsPointInStrokePathNV;
/* 722:737 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 723:738 */     boolean __result = nglIsPointInStrokePathNV(path, x, y, function_pointer);
/* 724:739 */     return __result;
/* 725:    */   }
/* 726:    */   
/* 727:    */   static native boolean nglIsPointInStrokePathNV(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/* 728:    */   
/* 729:    */   public static float glGetPathLengthNV(int path, int startSegment, int numSegments)
/* 730:    */   {
/* 731:744 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 732:745 */     long function_pointer = caps.glGetPathLengthNV;
/* 733:746 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 734:747 */     float __result = nglGetPathLengthNV(path, startSegment, numSegments, function_pointer);
/* 735:748 */     return __result;
/* 736:    */   }
/* 737:    */   
/* 738:    */   static native float nglGetPathLengthNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 739:    */   
/* 740:    */   public static boolean glPointAlongPathNV(int path, int startSegment, int numSegments, float distance, FloatBuffer x, FloatBuffer y, FloatBuffer tangentX, FloatBuffer tangentY)
/* 741:    */   {
/* 742:753 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 743:754 */     long function_pointer = caps.glPointAlongPathNV;
/* 744:755 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 745:756 */     if (x != null) {
/* 746:757 */       BufferChecks.checkBuffer(x, 1);
/* 747:    */     }
/* 748:758 */     if (y != null) {
/* 749:759 */       BufferChecks.checkBuffer(y, 1);
/* 750:    */     }
/* 751:760 */     if (tangentX != null) {
/* 752:761 */       BufferChecks.checkBuffer(tangentX, 1);
/* 753:    */     }
/* 754:762 */     if (tangentY != null) {
/* 755:763 */       BufferChecks.checkBuffer(tangentY, 1);
/* 756:    */     }
/* 757:764 */     boolean __result = nglPointAlongPathNV(path, startSegment, numSegments, distance, MemoryUtil.getAddressSafe(x), MemoryUtil.getAddressSafe(y), MemoryUtil.getAddressSafe(tangentX), MemoryUtil.getAddressSafe(tangentY), function_pointer);
/* 758:765 */     return __result;
/* 759:    */   }
/* 760:    */   
/* 761:    */   static native boolean nglPointAlongPathNV(int paramInt1, int paramInt2, int paramInt3, float paramFloat, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 762:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPathRendering
 * JD-Core Version:    0.7.0.1
 */