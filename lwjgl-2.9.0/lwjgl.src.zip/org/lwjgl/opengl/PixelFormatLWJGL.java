package org.lwjgl.opengl;

public abstract interface PixelFormatLWJGL {}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.PixelFormatLWJGL
 * JD-Core Version:    0.7.0.1
 */