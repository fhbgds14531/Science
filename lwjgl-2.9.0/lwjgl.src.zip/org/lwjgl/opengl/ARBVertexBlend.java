/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.LWJGLUtil;
/*  10:    */ import org.lwjgl.MemoryUtil;
/*  11:    */ 
/*  12:    */ public final class ARBVertexBlend
/*  13:    */ {
/*  14:    */   public static final int GL_MAX_VERTEX_UNITS_ARB = 34468;
/*  15:    */   public static final int GL_ACTIVE_VERTEX_UNITS_ARB = 34469;
/*  16:    */   public static final int GL_WEIGHT_SUM_UNITY_ARB = 34470;
/*  17:    */   public static final int GL_VERTEX_BLEND_ARB = 34471;
/*  18:    */   public static final int GL_CURRENT_WEIGHT_ARB = 34472;
/*  19:    */   public static final int GL_WEIGHT_ARRAY_TYPE_ARB = 34473;
/*  20:    */   public static final int GL_WEIGHT_ARRAY_STRIDE_ARB = 34474;
/*  21:    */   public static final int GL_WEIGHT_ARRAY_SIZE_ARB = 34475;
/*  22:    */   public static final int GL_WEIGHT_ARRAY_POINTER_ARB = 34476;
/*  23:    */   public static final int GL_WEIGHT_ARRAY_ARB = 34477;
/*  24:    */   public static final int GL_MODELVIEW0_ARB = 5888;
/*  25:    */   public static final int GL_MODELVIEW1_ARB = 34058;
/*  26:    */   public static final int GL_MODELVIEW2_ARB = 34594;
/*  27:    */   public static final int GL_MODELVIEW3_ARB = 34595;
/*  28:    */   public static final int GL_MODELVIEW4_ARB = 34596;
/*  29:    */   public static final int GL_MODELVIEW5_ARB = 34597;
/*  30:    */   public static final int GL_MODELVIEW6_ARB = 34598;
/*  31:    */   public static final int GL_MODELVIEW7_ARB = 34599;
/*  32:    */   public static final int GL_MODELVIEW8_ARB = 34600;
/*  33:    */   public static final int GL_MODELVIEW9_ARB = 34601;
/*  34:    */   public static final int GL_MODELVIEW10_ARB = 34602;
/*  35:    */   public static final int GL_MODELVIEW11_ARB = 34603;
/*  36:    */   public static final int GL_MODELVIEW12_ARB = 34604;
/*  37:    */   public static final int GL_MODELVIEW13_ARB = 34605;
/*  38:    */   public static final int GL_MODELVIEW14_ARB = 34606;
/*  39:    */   public static final int GL_MODELVIEW15_ARB = 34607;
/*  40:    */   public static final int GL_MODELVIEW16_ARB = 34608;
/*  41:    */   public static final int GL_MODELVIEW17_ARB = 34609;
/*  42:    */   public static final int GL_MODELVIEW18_ARB = 34610;
/*  43:    */   public static final int GL_MODELVIEW19_ARB = 34611;
/*  44:    */   public static final int GL_MODELVIEW20_ARB = 34612;
/*  45:    */   public static final int GL_MODELVIEW21_ARB = 34613;
/*  46:    */   public static final int GL_MODELVIEW22_ARB = 34614;
/*  47:    */   public static final int GL_MODELVIEW23_ARB = 34615;
/*  48:    */   public static final int GL_MODELVIEW24_ARB = 34616;
/*  49:    */   public static final int GL_MODELVIEW25_ARB = 34617;
/*  50:    */   public static final int GL_MODELVIEW26_ARB = 34618;
/*  51:    */   public static final int GL_MODELVIEW27_ARB = 34619;
/*  52:    */   public static final int GL_MODELVIEW28_ARB = 34620;
/*  53:    */   public static final int GL_MODELVIEW29_ARB = 34621;
/*  54:    */   public static final int GL_MODELVIEW30_ARB = 34622;
/*  55:    */   public static final int GL_MODELVIEW31_ARB = 34623;
/*  56:    */   
/*  57:    */   public static void glWeightARB(ByteBuffer pWeights)
/*  58:    */   {
/*  59: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 57 */     long function_pointer = caps.glWeightbvARB;
/*  61: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 59 */     BufferChecks.checkDirect(pWeights);
/*  63: 60 */     nglWeightbvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/*  64:    */   }
/*  65:    */   
/*  66:    */   static native void nglWeightbvARB(int paramInt, long paramLong1, long paramLong2);
/*  67:    */   
/*  68:    */   public static void glWeightARB(ShortBuffer pWeights)
/*  69:    */   {
/*  70: 65 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  71: 66 */     long function_pointer = caps.glWeightsvARB;
/*  72: 67 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  73: 68 */     BufferChecks.checkDirect(pWeights);
/*  74: 69 */     nglWeightsvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native void nglWeightsvARB(int paramInt, long paramLong1, long paramLong2);
/*  78:    */   
/*  79:    */   public static void glWeightARB(IntBuffer pWeights)
/*  80:    */   {
/*  81: 74 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  82: 75 */     long function_pointer = caps.glWeightivARB;
/*  83: 76 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  84: 77 */     BufferChecks.checkDirect(pWeights);
/*  85: 78 */     nglWeightivARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglWeightivARB(int paramInt, long paramLong1, long paramLong2);
/*  89:    */   
/*  90:    */   public static void glWeightARB(FloatBuffer pWeights)
/*  91:    */   {
/*  92: 83 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 84 */     long function_pointer = caps.glWeightfvARB;
/*  94: 85 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 86 */     BufferChecks.checkDirect(pWeights);
/*  96: 87 */     nglWeightfvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglWeightfvARB(int paramInt, long paramLong1, long paramLong2);
/* 100:    */   
/* 101:    */   public static void glWeightARB(DoubleBuffer pWeights)
/* 102:    */   {
/* 103: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104: 93 */     long function_pointer = caps.glWeightdvARB;
/* 105: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106: 95 */     BufferChecks.checkDirect(pWeights);
/* 107: 96 */     nglWeightdvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglWeightdvARB(int paramInt, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static void glWeightuARB(ByteBuffer pWeights)
/* 113:    */   {
/* 114:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:102 */     long function_pointer = caps.glWeightubvARB;
/* 116:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:104 */     BufferChecks.checkDirect(pWeights);
/* 118:105 */     nglWeightubvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native void nglWeightubvARB(int paramInt, long paramLong1, long paramLong2);
/* 122:    */   
/* 123:    */   public static void glWeightuARB(ShortBuffer pWeights)
/* 124:    */   {
/* 125:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:111 */     long function_pointer = caps.glWeightusvARB;
/* 127:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:113 */     BufferChecks.checkDirect(pWeights);
/* 129:114 */     nglWeightusvARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/* 130:    */   }
/* 131:    */   
/* 132:    */   static native void nglWeightusvARB(int paramInt, long paramLong1, long paramLong2);
/* 133:    */   
/* 134:    */   public static void glWeightuARB(IntBuffer pWeights)
/* 135:    */   {
/* 136:119 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 137:120 */     long function_pointer = caps.glWeightuivARB;
/* 138:121 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 139:122 */     BufferChecks.checkDirect(pWeights);
/* 140:123 */     nglWeightuivARB(pWeights.remaining(), MemoryUtil.getAddress(pWeights), function_pointer);
/* 141:    */   }
/* 142:    */   
/* 143:    */   static native void nglWeightuivARB(int paramInt, long paramLong1, long paramLong2);
/* 144:    */   
/* 145:    */   public static void glWeightPointerARB(int size, int stride, DoubleBuffer pPointer)
/* 146:    */   {
/* 147:128 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 148:129 */     long function_pointer = caps.glWeightPointerARB;
/* 149:130 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 150:131 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 151:132 */     BufferChecks.checkDirect(pPointer);
/* 152:133 */     if (LWJGLUtil.CHECKS) {
/* 153:133 */       StateTracker.getReferences(caps).ARB_vertex_blend_glWeightPointerARB_pPointer = pPointer;
/* 154:    */     }
/* 155:134 */     nglWeightPointerARB(size, 5130, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static void glWeightPointerARB(int size, int stride, FloatBuffer pPointer)
/* 159:    */   {
/* 160:137 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:138 */     long function_pointer = caps.glWeightPointerARB;
/* 162:139 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:140 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 164:141 */     BufferChecks.checkDirect(pPointer);
/* 165:142 */     if (LWJGLUtil.CHECKS) {
/* 166:142 */       StateTracker.getReferences(caps).ARB_vertex_blend_glWeightPointerARB_pPointer = pPointer;
/* 167:    */     }
/* 168:143 */     nglWeightPointerARB(size, 5126, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static void glWeightPointerARB(int size, boolean unsigned, int stride, ByteBuffer pPointer)
/* 172:    */   {
/* 173:146 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:147 */     long function_pointer = caps.glWeightPointerARB;
/* 175:148 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:149 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 177:150 */     BufferChecks.checkDirect(pPointer);
/* 178:151 */     if (LWJGLUtil.CHECKS) {
/* 179:151 */       StateTracker.getReferences(caps).ARB_vertex_blend_glWeightPointerARB_pPointer = pPointer;
/* 180:    */     }
/* 181:152 */     nglWeightPointerARB(size, unsigned ? 5121 : 5120, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static void glWeightPointerARB(int size, boolean unsigned, int stride, IntBuffer pPointer)
/* 185:    */   {
/* 186:155 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 187:156 */     long function_pointer = caps.glWeightPointerARB;
/* 188:157 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 189:158 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 190:159 */     BufferChecks.checkDirect(pPointer);
/* 191:160 */     if (LWJGLUtil.CHECKS) {
/* 192:160 */       StateTracker.getReferences(caps).ARB_vertex_blend_glWeightPointerARB_pPointer = pPointer;
/* 193:    */     }
/* 194:161 */     nglWeightPointerARB(size, unsigned ? 5125 : 5124, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static void glWeightPointerARB(int size, boolean unsigned, int stride, ShortBuffer pPointer)
/* 198:    */   {
/* 199:164 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:165 */     long function_pointer = caps.glWeightPointerARB;
/* 201:166 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:167 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 203:168 */     BufferChecks.checkDirect(pPointer);
/* 204:169 */     if (LWJGLUtil.CHECKS) {
/* 205:169 */       StateTracker.getReferences(caps).ARB_vertex_blend_glWeightPointerARB_pPointer = pPointer;
/* 206:    */     }
/* 207:170 */     nglWeightPointerARB(size, unsigned ? 5123 : 5122, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   static native void nglWeightPointerARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 211:    */   
/* 212:    */   public static void glWeightPointerARB(int size, int type, int stride, long pPointer_buffer_offset)
/* 213:    */   {
/* 214:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 215:175 */     long function_pointer = caps.glWeightPointerARB;
/* 216:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 217:177 */     GLChecks.ensureArrayVBOenabled(caps);
/* 218:178 */     nglWeightPointerARBBO(size, type, stride, pPointer_buffer_offset, function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglWeightPointerARBBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 222:    */   
/* 223:    */   public static void glVertexBlendARB(int count)
/* 224:    */   {
/* 225:183 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:184 */     long function_pointer = caps.glVertexBlendARB;
/* 227:185 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:186 */     nglVertexBlendARB(count, function_pointer);
/* 229:    */   }
/* 230:    */   
/* 231:    */   static native void nglVertexBlendARB(int paramInt, long paramLong);
/* 232:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexBlend
 * JD-Core Version:    0.7.0.1
 */