/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ import org.lwjgl.MemoryUtil;
/*  12:    */ 
/*  13:    */ public final class EXTVertexShader
/*  14:    */ {
/*  15:    */   public static final int GL_VERTEX_SHADER_EXT = 34688;
/*  16:    */   public static final int GL_VERTEX_SHADER_BINDING_EXT = 34689;
/*  17:    */   public static final int GL_OP_INDEX_EXT = 34690;
/*  18:    */   public static final int GL_OP_NEGATE_EXT = 34691;
/*  19:    */   public static final int GL_OP_DOT3_EXT = 34692;
/*  20:    */   public static final int GL_OP_DOT4_EXT = 34693;
/*  21:    */   public static final int GL_OP_MUL_EXT = 34694;
/*  22:    */   public static final int GL_OP_ADD_EXT = 34695;
/*  23:    */   public static final int GL_OP_MADD_EXT = 34696;
/*  24:    */   public static final int GL_OP_FRAC_EXT = 34697;
/*  25:    */   public static final int GL_OP_MAX_EXT = 34698;
/*  26:    */   public static final int GL_OP_MIN_EXT = 34699;
/*  27:    */   public static final int GL_OP_SET_GE_EXT = 34700;
/*  28:    */   public static final int GL_OP_SET_LT_EXT = 34701;
/*  29:    */   public static final int GL_OP_CLAMP_EXT = 34702;
/*  30:    */   public static final int GL_OP_FLOOR_EXT = 34703;
/*  31:    */   public static final int GL_OP_ROUND_EXT = 34704;
/*  32:    */   public static final int GL_OP_EXP_BASE_2_EXT = 34705;
/*  33:    */   public static final int GL_OP_LOG_BASE_2_EXT = 34706;
/*  34:    */   public static final int GL_OP_POWER_EXT = 34707;
/*  35:    */   public static final int GL_OP_RECIP_EXT = 34708;
/*  36:    */   public static final int GL_OP_RECIP_SQRT_EXT = 34709;
/*  37:    */   public static final int GL_OP_SUB_EXT = 34710;
/*  38:    */   public static final int GL_OP_CROSS_PRODUCT_EXT = 34711;
/*  39:    */   public static final int GL_OP_MULTIPLY_MATRIX_EXT = 34712;
/*  40:    */   public static final int GL_OP_MOV_EXT = 34713;
/*  41:    */   public static final int GL_OUTPUT_VERTEX_EXT = 34714;
/*  42:    */   public static final int GL_OUTPUT_COLOR0_EXT = 34715;
/*  43:    */   public static final int GL_OUTPUT_COLOR1_EXT = 34716;
/*  44:    */   public static final int GL_OUTPUT_TEXTURE_COORD0_EXT = 34717;
/*  45:    */   public static final int GL_OUTPUT_TEXTURE_COORD1_EXT = 34718;
/*  46:    */   public static final int GL_OUTPUT_TEXTURE_COORD2_EXT = 34719;
/*  47:    */   public static final int GL_OUTPUT_TEXTURE_COORD3_EXT = 34720;
/*  48:    */   public static final int GL_OUTPUT_TEXTURE_COORD4_EXT = 34721;
/*  49:    */   public static final int GL_OUTPUT_TEXTURE_COORD5_EXT = 34722;
/*  50:    */   public static final int GL_OUTPUT_TEXTURE_COORD6_EXT = 34723;
/*  51:    */   public static final int GL_OUTPUT_TEXTURE_COORD7_EXT = 34724;
/*  52:    */   public static final int GL_OUTPUT_TEXTURE_COORD8_EXT = 34725;
/*  53:    */   public static final int GL_OUTPUT_TEXTURE_COORD9_EXT = 34726;
/*  54:    */   public static final int GL_OUTPUT_TEXTURE_COORD10_EXT = 34727;
/*  55:    */   public static final int GL_OUTPUT_TEXTURE_COORD11_EXT = 34728;
/*  56:    */   public static final int GL_OUTPUT_TEXTURE_COORD12_EXT = 34729;
/*  57:    */   public static final int GL_OUTPUT_TEXTURE_COORD13_EXT = 34730;
/*  58:    */   public static final int GL_OUTPUT_TEXTURE_COORD14_EXT = 34731;
/*  59:    */   public static final int GL_OUTPUT_TEXTURE_COORD15_EXT = 34732;
/*  60:    */   public static final int GL_OUTPUT_TEXTURE_COORD16_EXT = 34733;
/*  61:    */   public static final int GL_OUTPUT_TEXTURE_COORD17_EXT = 34734;
/*  62:    */   public static final int GL_OUTPUT_TEXTURE_COORD18_EXT = 34735;
/*  63:    */   public static final int GL_OUTPUT_TEXTURE_COORD19_EXT = 34736;
/*  64:    */   public static final int GL_OUTPUT_TEXTURE_COORD20_EXT = 34737;
/*  65:    */   public static final int GL_OUTPUT_TEXTURE_COORD21_EXT = 34738;
/*  66:    */   public static final int GL_OUTPUT_TEXTURE_COORD22_EXT = 34739;
/*  67:    */   public static final int GL_OUTPUT_TEXTURE_COORD23_EXT = 34740;
/*  68:    */   public static final int GL_OUTPUT_TEXTURE_COORD24_EXT = 34741;
/*  69:    */   public static final int GL_OUTPUT_TEXTURE_COORD25_EXT = 34742;
/*  70:    */   public static final int GL_OUTPUT_TEXTURE_COORD26_EXT = 34743;
/*  71:    */   public static final int GL_OUTPUT_TEXTURE_COORD27_EXT = 34744;
/*  72:    */   public static final int GL_OUTPUT_TEXTURE_COORD28_EXT = 34745;
/*  73:    */   public static final int GL_OUTPUT_TEXTURE_COORD29_EXT = 34746;
/*  74:    */   public static final int GL_OUTPUT_TEXTURE_COORD30_EXT = 34747;
/*  75:    */   public static final int GL_OUTPUT_TEXTURE_COORD31_EXT = 34748;
/*  76:    */   public static final int GL_OUTPUT_FOG_EXT = 34749;
/*  77:    */   public static final int GL_SCALAR_EXT = 34750;
/*  78:    */   public static final int GL_VECTOR_EXT = 34751;
/*  79:    */   public static final int GL_MATRIX_EXT = 34752;
/*  80:    */   public static final int GL_VARIANT_EXT = 34753;
/*  81:    */   public static final int GL_INVARIANT_EXT = 34754;
/*  82:    */   public static final int GL_LOCAL_CONSTANT_EXT = 34755;
/*  83:    */   public static final int GL_LOCAL_EXT = 34756;
/*  84:    */   public static final int GL_MAX_VERTEX_SHADER_INSTRUCTIONS_EXT = 34757;
/*  85:    */   public static final int GL_MAX_VERTEX_SHADER_VARIANTS_EXT = 34758;
/*  86:    */   public static final int GL_MAX_VERTEX_SHADER_INVARIANTS_EXT = 34759;
/*  87:    */   public static final int GL_MAX_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34760;
/*  88:    */   public static final int GL_MAX_VERTEX_SHADER_LOCALS_EXT = 34761;
/*  89:    */   public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_INSTRUCTIONS_EXT = 34762;
/*  90:    */   public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_VARIANTS_EXT = 34763;
/*  91:    */   public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_INVARIANTS_EXT = 34764;
/*  92:    */   public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34765;
/*  93:    */   public static final int GL_MAX_OPTIMIZED_VERTEX_SHADER_LOCALS_EXT = 34766;
/*  94:    */   public static final int GL_VERTEX_SHADER_INSTRUCTIONS_EXT = 34767;
/*  95:    */   public static final int GL_VERTEX_SHADER_VARIANTS_EXT = 34768;
/*  96:    */   public static final int GL_VERTEX_SHADER_INVARIANTS_EXT = 34769;
/*  97:    */   public static final int GL_VERTEX_SHADER_LOCAL_CONSTANTS_EXT = 34770;
/*  98:    */   public static final int GL_VERTEX_SHADER_LOCALS_EXT = 34771;
/*  99:    */   public static final int GL_VERTEX_SHADER_OPTIMIZED_EXT = 34772;
/* 100:    */   public static final int GL_X_EXT = 34773;
/* 101:    */   public static final int GL_Y_EXT = 34774;
/* 102:    */   public static final int GL_Z_EXT = 34775;
/* 103:    */   public static final int GL_W_EXT = 34776;
/* 104:    */   public static final int GL_NEGATIVE_X_EXT = 34777;
/* 105:    */   public static final int GL_NEGATIVE_Y_EXT = 34778;
/* 106:    */   public static final int GL_NEGATIVE_Z_EXT = 34779;
/* 107:    */   public static final int GL_NEGATIVE_W_EXT = 34780;
/* 108:    */   public static final int GL_ZERO_EXT = 34781;
/* 109:    */   public static final int GL_ONE_EXT = 34782;
/* 110:    */   public static final int GL_NEGATIVE_ONE_EXT = 34783;
/* 111:    */   public static final int GL_NORMALIZED_RANGE_EXT = 34784;
/* 112:    */   public static final int GL_FULL_RANGE_EXT = 34785;
/* 113:    */   public static final int GL_CURRENT_VERTEX_EXT = 34786;
/* 114:    */   public static final int GL_MVP_MATRIX_EXT = 34787;
/* 115:    */   public static final int GL_VARIANT_VALUE_EXT = 34788;
/* 116:    */   public static final int GL_VARIANT_DATATYPE_EXT = 34789;
/* 117:    */   public static final int GL_VARIANT_ARRAY_STRIDE_EXT = 34790;
/* 118:    */   public static final int GL_VARIANT_ARRAY_TYPE_EXT = 34791;
/* 119:    */   public static final int GL_VARIANT_ARRAY_EXT = 34792;
/* 120:    */   public static final int GL_VARIANT_ARRAY_POINTER_EXT = 34793;
/* 121:    */   public static final int GL_INVARIANT_VALUE_EXT = 34794;
/* 122:    */   public static final int GL_INVARIANT_DATATYPE_EXT = 34795;
/* 123:    */   public static final int GL_LOCAL_CONSTANT_VALUE_EXT = 34796;
/* 124:    */   public static final int GL_LOCAL_CONSTANT_DATATYPE_EXT = 34797;
/* 125:    */   
/* 126:    */   public static void glBeginVertexShaderEXT()
/* 127:    */   {
/* 128:124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 129:125 */     long function_pointer = caps.glBeginVertexShaderEXT;
/* 130:126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 131:127 */     nglBeginVertexShaderEXT(function_pointer);
/* 132:    */   }
/* 133:    */   
/* 134:    */   static native void nglBeginVertexShaderEXT(long paramLong);
/* 135:    */   
/* 136:    */   public static void glEndVertexShaderEXT()
/* 137:    */   {
/* 138:132 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:133 */     long function_pointer = caps.glEndVertexShaderEXT;
/* 140:134 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:135 */     nglEndVertexShaderEXT(function_pointer);
/* 142:    */   }
/* 143:    */   
/* 144:    */   static native void nglEndVertexShaderEXT(long paramLong);
/* 145:    */   
/* 146:    */   public static void glBindVertexShaderEXT(int id)
/* 147:    */   {
/* 148:140 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 149:141 */     long function_pointer = caps.glBindVertexShaderEXT;
/* 150:142 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 151:143 */     nglBindVertexShaderEXT(id, function_pointer);
/* 152:    */   }
/* 153:    */   
/* 154:    */   static native void nglBindVertexShaderEXT(int paramInt, long paramLong);
/* 155:    */   
/* 156:    */   public static int glGenVertexShadersEXT(int range)
/* 157:    */   {
/* 158:148 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 159:149 */     long function_pointer = caps.glGenVertexShadersEXT;
/* 160:150 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 161:151 */     int __result = nglGenVertexShadersEXT(range, function_pointer);
/* 162:152 */     return __result;
/* 163:    */   }
/* 164:    */   
/* 165:    */   static native int nglGenVertexShadersEXT(int paramInt, long paramLong);
/* 166:    */   
/* 167:    */   public static void glDeleteVertexShaderEXT(int id)
/* 168:    */   {
/* 169:157 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 170:158 */     long function_pointer = caps.glDeleteVertexShaderEXT;
/* 171:159 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 172:160 */     nglDeleteVertexShaderEXT(id, function_pointer);
/* 173:    */   }
/* 174:    */   
/* 175:    */   static native void nglDeleteVertexShaderEXT(int paramInt, long paramLong);
/* 176:    */   
/* 177:    */   public static void glShaderOp1EXT(int op, int res, int arg1)
/* 178:    */   {
/* 179:165 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 180:166 */     long function_pointer = caps.glShaderOp1EXT;
/* 181:167 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 182:168 */     nglShaderOp1EXT(op, res, arg1, function_pointer);
/* 183:    */   }
/* 184:    */   
/* 185:    */   static native void nglShaderOp1EXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 186:    */   
/* 187:    */   public static void glShaderOp2EXT(int op, int res, int arg1, int arg2)
/* 188:    */   {
/* 189:173 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 190:174 */     long function_pointer = caps.glShaderOp2EXT;
/* 191:175 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 192:176 */     nglShaderOp2EXT(op, res, arg1, arg2, function_pointer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   static native void nglShaderOp2EXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 196:    */   
/* 197:    */   public static void glShaderOp3EXT(int op, int res, int arg1, int arg2, int arg3)
/* 198:    */   {
/* 199:181 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:182 */     long function_pointer = caps.glShaderOp3EXT;
/* 201:183 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:184 */     nglShaderOp3EXT(op, res, arg1, arg2, arg3, function_pointer);
/* 203:    */   }
/* 204:    */   
/* 205:    */   static native void nglShaderOp3EXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 206:    */   
/* 207:    */   public static void glSwizzleEXT(int res, int in, int outX, int outY, int outZ, int outW)
/* 208:    */   {
/* 209:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 210:190 */     long function_pointer = caps.glSwizzleEXT;
/* 211:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 212:192 */     nglSwizzleEXT(res, in, outX, outY, outZ, outW, function_pointer);
/* 213:    */   }
/* 214:    */   
/* 215:    */   static native void nglSwizzleEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 216:    */   
/* 217:    */   public static void glWriteMaskEXT(int res, int in, int outX, int outY, int outZ, int outW)
/* 218:    */   {
/* 219:197 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 220:198 */     long function_pointer = caps.glWriteMaskEXT;
/* 221:199 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 222:200 */     nglWriteMaskEXT(res, in, outX, outY, outZ, outW, function_pointer);
/* 223:    */   }
/* 224:    */   
/* 225:    */   static native void nglWriteMaskEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 226:    */   
/* 227:    */   public static void glInsertComponentEXT(int res, int src, int num)
/* 228:    */   {
/* 229:205 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 230:206 */     long function_pointer = caps.glInsertComponentEXT;
/* 231:207 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 232:208 */     nglInsertComponentEXT(res, src, num, function_pointer);
/* 233:    */   }
/* 234:    */   
/* 235:    */   static native void nglInsertComponentEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 236:    */   
/* 237:    */   public static void glExtractComponentEXT(int res, int src, int num)
/* 238:    */   {
/* 239:213 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 240:214 */     long function_pointer = caps.glExtractComponentEXT;
/* 241:215 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 242:216 */     nglExtractComponentEXT(res, src, num, function_pointer);
/* 243:    */   }
/* 244:    */   
/* 245:    */   static native void nglExtractComponentEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 246:    */   
/* 247:    */   public static int glGenSymbolsEXT(int dataType, int storageType, int range, int components)
/* 248:    */   {
/* 249:221 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 250:222 */     long function_pointer = caps.glGenSymbolsEXT;
/* 251:223 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 252:224 */     int __result = nglGenSymbolsEXT(dataType, storageType, range, components, function_pointer);
/* 253:225 */     return __result;
/* 254:    */   }
/* 255:    */   
/* 256:    */   static native int nglGenSymbolsEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 257:    */   
/* 258:    */   public static void glSetInvariantEXT(int id, DoubleBuffer pAddr)
/* 259:    */   {
/* 260:230 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 261:231 */     long function_pointer = caps.glSetInvariantEXT;
/* 262:232 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 263:233 */     BufferChecks.checkBuffer(pAddr, 4);
/* 264:234 */     nglSetInvariantEXT(id, 5130, MemoryUtil.getAddress(pAddr), function_pointer);
/* 265:    */   }
/* 266:    */   
/* 267:    */   public static void glSetInvariantEXT(int id, FloatBuffer pAddr)
/* 268:    */   {
/* 269:237 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 270:238 */     long function_pointer = caps.glSetInvariantEXT;
/* 271:239 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 272:240 */     BufferChecks.checkBuffer(pAddr, 4);
/* 273:241 */     nglSetInvariantEXT(id, 5126, MemoryUtil.getAddress(pAddr), function_pointer);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public static void glSetInvariantEXT(int id, boolean unsigned, ByteBuffer pAddr)
/* 277:    */   {
/* 278:244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 279:245 */     long function_pointer = caps.glSetInvariantEXT;
/* 280:246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 281:247 */     BufferChecks.checkBuffer(pAddr, 4);
/* 282:248 */     nglSetInvariantEXT(id, unsigned ? 5121 : 5120, MemoryUtil.getAddress(pAddr), function_pointer);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public static void glSetInvariantEXT(int id, boolean unsigned, IntBuffer pAddr)
/* 286:    */   {
/* 287:251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 288:252 */     long function_pointer = caps.glSetInvariantEXT;
/* 289:253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 290:254 */     BufferChecks.checkBuffer(pAddr, 4);
/* 291:255 */     nglSetInvariantEXT(id, unsigned ? 5125 : 5124, MemoryUtil.getAddress(pAddr), function_pointer);
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static void glSetInvariantEXT(int id, boolean unsigned, ShortBuffer pAddr)
/* 295:    */   {
/* 296:258 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 297:259 */     long function_pointer = caps.glSetInvariantEXT;
/* 298:260 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 299:261 */     BufferChecks.checkBuffer(pAddr, 4);
/* 300:262 */     nglSetInvariantEXT(id, unsigned ? 5123 : 5122, MemoryUtil.getAddress(pAddr), function_pointer);
/* 301:    */   }
/* 302:    */   
/* 303:    */   static native void nglSetInvariantEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 304:    */   
/* 305:    */   public static void glSetLocalConstantEXT(int id, DoubleBuffer pAddr)
/* 306:    */   {
/* 307:267 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 308:268 */     long function_pointer = caps.glSetLocalConstantEXT;
/* 309:269 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 310:270 */     BufferChecks.checkBuffer(pAddr, 4);
/* 311:271 */     nglSetLocalConstantEXT(id, 5130, MemoryUtil.getAddress(pAddr), function_pointer);
/* 312:    */   }
/* 313:    */   
/* 314:    */   public static void glSetLocalConstantEXT(int id, FloatBuffer pAddr)
/* 315:    */   {
/* 316:274 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 317:275 */     long function_pointer = caps.glSetLocalConstantEXT;
/* 318:276 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 319:277 */     BufferChecks.checkBuffer(pAddr, 4);
/* 320:278 */     nglSetLocalConstantEXT(id, 5126, MemoryUtil.getAddress(pAddr), function_pointer);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public static void glSetLocalConstantEXT(int id, boolean unsigned, ByteBuffer pAddr)
/* 324:    */   {
/* 325:281 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 326:282 */     long function_pointer = caps.glSetLocalConstantEXT;
/* 327:283 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 328:284 */     BufferChecks.checkBuffer(pAddr, 4);
/* 329:285 */     nglSetLocalConstantEXT(id, unsigned ? 5121 : 5120, MemoryUtil.getAddress(pAddr), function_pointer);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public static void glSetLocalConstantEXT(int id, boolean unsigned, IntBuffer pAddr)
/* 333:    */   {
/* 334:288 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 335:289 */     long function_pointer = caps.glSetLocalConstantEXT;
/* 336:290 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 337:291 */     BufferChecks.checkBuffer(pAddr, 4);
/* 338:292 */     nglSetLocalConstantEXT(id, unsigned ? 5125 : 5124, MemoryUtil.getAddress(pAddr), function_pointer);
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static void glSetLocalConstantEXT(int id, boolean unsigned, ShortBuffer pAddr)
/* 342:    */   {
/* 343:295 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 344:296 */     long function_pointer = caps.glSetLocalConstantEXT;
/* 345:297 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 346:298 */     BufferChecks.checkBuffer(pAddr, 4);
/* 347:299 */     nglSetLocalConstantEXT(id, unsigned ? 5123 : 5122, MemoryUtil.getAddress(pAddr), function_pointer);
/* 348:    */   }
/* 349:    */   
/* 350:    */   static native void nglSetLocalConstantEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 351:    */   
/* 352:    */   public static void glVariantEXT(int id, ByteBuffer pAddr)
/* 353:    */   {
/* 354:304 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 355:305 */     long function_pointer = caps.glVariantbvEXT;
/* 356:306 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 357:307 */     BufferChecks.checkBuffer(pAddr, 4);
/* 358:308 */     nglVariantbvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 359:    */   }
/* 360:    */   
/* 361:    */   static native void nglVariantbvEXT(int paramInt, long paramLong1, long paramLong2);
/* 362:    */   
/* 363:    */   public static void glVariantEXT(int id, ShortBuffer pAddr)
/* 364:    */   {
/* 365:313 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 366:314 */     long function_pointer = caps.glVariantsvEXT;
/* 367:315 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 368:316 */     BufferChecks.checkBuffer(pAddr, 4);
/* 369:317 */     nglVariantsvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 370:    */   }
/* 371:    */   
/* 372:    */   static native void nglVariantsvEXT(int paramInt, long paramLong1, long paramLong2);
/* 373:    */   
/* 374:    */   public static void glVariantEXT(int id, IntBuffer pAddr)
/* 375:    */   {
/* 376:322 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 377:323 */     long function_pointer = caps.glVariantivEXT;
/* 378:324 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 379:325 */     BufferChecks.checkBuffer(pAddr, 4);
/* 380:326 */     nglVariantivEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 381:    */   }
/* 382:    */   
/* 383:    */   static native void nglVariantivEXT(int paramInt, long paramLong1, long paramLong2);
/* 384:    */   
/* 385:    */   public static void glVariantEXT(int id, FloatBuffer pAddr)
/* 386:    */   {
/* 387:331 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 388:332 */     long function_pointer = caps.glVariantfvEXT;
/* 389:333 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 390:334 */     BufferChecks.checkBuffer(pAddr, 4);
/* 391:335 */     nglVariantfvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 392:    */   }
/* 393:    */   
/* 394:    */   static native void nglVariantfvEXT(int paramInt, long paramLong1, long paramLong2);
/* 395:    */   
/* 396:    */   public static void glVariantEXT(int id, DoubleBuffer pAddr)
/* 397:    */   {
/* 398:340 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 399:341 */     long function_pointer = caps.glVariantdvEXT;
/* 400:342 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 401:343 */     BufferChecks.checkBuffer(pAddr, 4);
/* 402:344 */     nglVariantdvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 403:    */   }
/* 404:    */   
/* 405:    */   static native void nglVariantdvEXT(int paramInt, long paramLong1, long paramLong2);
/* 406:    */   
/* 407:    */   public static void glVariantuEXT(int id, ByteBuffer pAddr)
/* 408:    */   {
/* 409:349 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 410:350 */     long function_pointer = caps.glVariantubvEXT;
/* 411:351 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 412:352 */     BufferChecks.checkBuffer(pAddr, 4);
/* 413:353 */     nglVariantubvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 414:    */   }
/* 415:    */   
/* 416:    */   static native void nglVariantubvEXT(int paramInt, long paramLong1, long paramLong2);
/* 417:    */   
/* 418:    */   public static void glVariantuEXT(int id, ShortBuffer pAddr)
/* 419:    */   {
/* 420:358 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 421:359 */     long function_pointer = caps.glVariantusvEXT;
/* 422:360 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 423:361 */     BufferChecks.checkBuffer(pAddr, 4);
/* 424:362 */     nglVariantusvEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 425:    */   }
/* 426:    */   
/* 427:    */   static native void nglVariantusvEXT(int paramInt, long paramLong1, long paramLong2);
/* 428:    */   
/* 429:    */   public static void glVariantuEXT(int id, IntBuffer pAddr)
/* 430:    */   {
/* 431:367 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 432:368 */     long function_pointer = caps.glVariantuivEXT;
/* 433:369 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 434:370 */     BufferChecks.checkBuffer(pAddr, 4);
/* 435:371 */     nglVariantuivEXT(id, MemoryUtil.getAddress(pAddr), function_pointer);
/* 436:    */   }
/* 437:    */   
/* 438:    */   static native void nglVariantuivEXT(int paramInt, long paramLong1, long paramLong2);
/* 439:    */   
/* 440:    */   public static void glVariantPointerEXT(int id, int stride, DoubleBuffer pAddr)
/* 441:    */   {
/* 442:376 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 443:377 */     long function_pointer = caps.glVariantPointerEXT;
/* 444:378 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 445:379 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 446:380 */     BufferChecks.checkDirect(pAddr);
/* 447:381 */     if (LWJGLUtil.CHECKS) {
/* 448:381 */       StateTracker.getReferences(caps).EXT_vertex_shader_glVariantPointerEXT_pAddr = pAddr;
/* 449:    */     }
/* 450:382 */     nglVariantPointerEXT(id, 5130, stride, MemoryUtil.getAddress(pAddr), function_pointer);
/* 451:    */   }
/* 452:    */   
/* 453:    */   public static void glVariantPointerEXT(int id, int stride, FloatBuffer pAddr)
/* 454:    */   {
/* 455:385 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 456:386 */     long function_pointer = caps.glVariantPointerEXT;
/* 457:387 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 458:388 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 459:389 */     BufferChecks.checkDirect(pAddr);
/* 460:390 */     if (LWJGLUtil.CHECKS) {
/* 461:390 */       StateTracker.getReferences(caps).EXT_vertex_shader_glVariantPointerEXT_pAddr = pAddr;
/* 462:    */     }
/* 463:391 */     nglVariantPointerEXT(id, 5126, stride, MemoryUtil.getAddress(pAddr), function_pointer);
/* 464:    */   }
/* 465:    */   
/* 466:    */   public static void glVariantPointerEXT(int id, boolean unsigned, int stride, ByteBuffer pAddr)
/* 467:    */   {
/* 468:394 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 469:395 */     long function_pointer = caps.glVariantPointerEXT;
/* 470:396 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 471:397 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 472:398 */     BufferChecks.checkDirect(pAddr);
/* 473:399 */     if (LWJGLUtil.CHECKS) {
/* 474:399 */       StateTracker.getReferences(caps).EXT_vertex_shader_glVariantPointerEXT_pAddr = pAddr;
/* 475:    */     }
/* 476:400 */     nglVariantPointerEXT(id, unsigned ? 5121 : 5120, stride, MemoryUtil.getAddress(pAddr), function_pointer);
/* 477:    */   }
/* 478:    */   
/* 479:    */   public static void glVariantPointerEXT(int id, boolean unsigned, int stride, IntBuffer pAddr)
/* 480:    */   {
/* 481:403 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 482:404 */     long function_pointer = caps.glVariantPointerEXT;
/* 483:405 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 484:406 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 485:407 */     BufferChecks.checkDirect(pAddr);
/* 486:408 */     if (LWJGLUtil.CHECKS) {
/* 487:408 */       StateTracker.getReferences(caps).EXT_vertex_shader_glVariantPointerEXT_pAddr = pAddr;
/* 488:    */     }
/* 489:409 */     nglVariantPointerEXT(id, unsigned ? 5125 : 5124, stride, MemoryUtil.getAddress(pAddr), function_pointer);
/* 490:    */   }
/* 491:    */   
/* 492:    */   public static void glVariantPointerEXT(int id, boolean unsigned, int stride, ShortBuffer pAddr)
/* 493:    */   {
/* 494:412 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 495:413 */     long function_pointer = caps.glVariantPointerEXT;
/* 496:414 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 497:415 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 498:416 */     BufferChecks.checkDirect(pAddr);
/* 499:417 */     if (LWJGLUtil.CHECKS) {
/* 500:417 */       StateTracker.getReferences(caps).EXT_vertex_shader_glVariantPointerEXT_pAddr = pAddr;
/* 501:    */     }
/* 502:418 */     nglVariantPointerEXT(id, unsigned ? 5123 : 5122, stride, MemoryUtil.getAddress(pAddr), function_pointer);
/* 503:    */   }
/* 504:    */   
/* 505:    */   static native void nglVariantPointerEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 506:    */   
/* 507:    */   public static void glVariantPointerEXT(int id, int type, int stride, long pAddr_buffer_offset)
/* 508:    */   {
/* 509:422 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 510:423 */     long function_pointer = caps.glVariantPointerEXT;
/* 511:424 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 512:425 */     GLChecks.ensureArrayVBOenabled(caps);
/* 513:426 */     nglVariantPointerEXTBO(id, type, stride, pAddr_buffer_offset, function_pointer);
/* 514:    */   }
/* 515:    */   
/* 516:    */   static native void nglVariantPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 517:    */   
/* 518:    */   public static void glEnableVariantClientStateEXT(int id)
/* 519:    */   {
/* 520:431 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 521:432 */     long function_pointer = caps.glEnableVariantClientStateEXT;
/* 522:433 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 523:434 */     nglEnableVariantClientStateEXT(id, function_pointer);
/* 524:    */   }
/* 525:    */   
/* 526:    */   static native void nglEnableVariantClientStateEXT(int paramInt, long paramLong);
/* 527:    */   
/* 528:    */   public static void glDisableVariantClientStateEXT(int id)
/* 529:    */   {
/* 530:439 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 531:440 */     long function_pointer = caps.glDisableVariantClientStateEXT;
/* 532:441 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 533:442 */     nglDisableVariantClientStateEXT(id, function_pointer);
/* 534:    */   }
/* 535:    */   
/* 536:    */   static native void nglDisableVariantClientStateEXT(int paramInt, long paramLong);
/* 537:    */   
/* 538:    */   public static int glBindLightParameterEXT(int light, int value)
/* 539:    */   {
/* 540:447 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 541:448 */     long function_pointer = caps.glBindLightParameterEXT;
/* 542:449 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 543:450 */     int __result = nglBindLightParameterEXT(light, value, function_pointer);
/* 544:451 */     return __result;
/* 545:    */   }
/* 546:    */   
/* 547:    */   static native int nglBindLightParameterEXT(int paramInt1, int paramInt2, long paramLong);
/* 548:    */   
/* 549:    */   public static int glBindMaterialParameterEXT(int face, int value)
/* 550:    */   {
/* 551:456 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 552:457 */     long function_pointer = caps.glBindMaterialParameterEXT;
/* 553:458 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 554:459 */     int __result = nglBindMaterialParameterEXT(face, value, function_pointer);
/* 555:460 */     return __result;
/* 556:    */   }
/* 557:    */   
/* 558:    */   static native int nglBindMaterialParameterEXT(int paramInt1, int paramInt2, long paramLong);
/* 559:    */   
/* 560:    */   public static int glBindTexGenParameterEXT(int unit, int coord, int value)
/* 561:    */   {
/* 562:465 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 563:466 */     long function_pointer = caps.glBindTexGenParameterEXT;
/* 564:467 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 565:468 */     int __result = nglBindTexGenParameterEXT(unit, coord, value, function_pointer);
/* 566:469 */     return __result;
/* 567:    */   }
/* 568:    */   
/* 569:    */   static native int nglBindTexGenParameterEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 570:    */   
/* 571:    */   public static int glBindTextureUnitParameterEXT(int unit, int value)
/* 572:    */   {
/* 573:474 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 574:475 */     long function_pointer = caps.glBindTextureUnitParameterEXT;
/* 575:476 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 576:477 */     int __result = nglBindTextureUnitParameterEXT(unit, value, function_pointer);
/* 577:478 */     return __result;
/* 578:    */   }
/* 579:    */   
/* 580:    */   static native int nglBindTextureUnitParameterEXT(int paramInt1, int paramInt2, long paramLong);
/* 581:    */   
/* 582:    */   public static int glBindParameterEXT(int value)
/* 583:    */   {
/* 584:483 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 585:484 */     long function_pointer = caps.glBindParameterEXT;
/* 586:485 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 587:486 */     int __result = nglBindParameterEXT(value, function_pointer);
/* 588:487 */     return __result;
/* 589:    */   }
/* 590:    */   
/* 591:    */   static native int nglBindParameterEXT(int paramInt, long paramLong);
/* 592:    */   
/* 593:    */   public static boolean glIsVariantEnabledEXT(int id, int cap)
/* 594:    */   {
/* 595:492 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 596:493 */     long function_pointer = caps.glIsVariantEnabledEXT;
/* 597:494 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 598:495 */     boolean __result = nglIsVariantEnabledEXT(id, cap, function_pointer);
/* 599:496 */     return __result;
/* 600:    */   }
/* 601:    */   
/* 602:    */   static native boolean nglIsVariantEnabledEXT(int paramInt1, int paramInt2, long paramLong);
/* 603:    */   
/* 604:    */   public static void glGetVariantBooleanEXT(int id, int value, ByteBuffer pbData)
/* 605:    */   {
/* 606:501 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 607:502 */     long function_pointer = caps.glGetVariantBooleanvEXT;
/* 608:503 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 609:504 */     BufferChecks.checkBuffer(pbData, 4);
/* 610:505 */     nglGetVariantBooleanvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 611:    */   }
/* 612:    */   
/* 613:    */   static native void nglGetVariantBooleanvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 614:    */   
/* 615:    */   public static void glGetVariantIntegerEXT(int id, int value, IntBuffer pbData)
/* 616:    */   {
/* 617:510 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 618:511 */     long function_pointer = caps.glGetVariantIntegervEXT;
/* 619:512 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 620:513 */     BufferChecks.checkBuffer(pbData, 4);
/* 621:514 */     nglGetVariantIntegervEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 622:    */   }
/* 623:    */   
/* 624:    */   static native void nglGetVariantIntegervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 625:    */   
/* 626:    */   public static void glGetVariantFloatEXT(int id, int value, FloatBuffer pbData)
/* 627:    */   {
/* 628:519 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 629:520 */     long function_pointer = caps.glGetVariantFloatvEXT;
/* 630:521 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 631:522 */     BufferChecks.checkBuffer(pbData, 4);
/* 632:523 */     nglGetVariantFloatvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 633:    */   }
/* 634:    */   
/* 635:    */   static native void nglGetVariantFloatvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 636:    */   
/* 637:    */   public static ByteBuffer glGetVariantPointerEXT(int id, int value, long result_size)
/* 638:    */   {
/* 639:528 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 640:529 */     long function_pointer = caps.glGetVariantPointervEXT;
/* 641:530 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 642:531 */     ByteBuffer __result = nglGetVariantPointervEXT(id, value, result_size, function_pointer);
/* 643:532 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 644:    */   }
/* 645:    */   
/* 646:    */   static native ByteBuffer nglGetVariantPointervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 647:    */   
/* 648:    */   public static void glGetInvariantBooleanEXT(int id, int value, ByteBuffer pbData)
/* 649:    */   {
/* 650:537 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 651:538 */     long function_pointer = caps.glGetInvariantBooleanvEXT;
/* 652:539 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 653:540 */     BufferChecks.checkBuffer(pbData, 4);
/* 654:541 */     nglGetInvariantBooleanvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 655:    */   }
/* 656:    */   
/* 657:    */   static native void nglGetInvariantBooleanvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 658:    */   
/* 659:    */   public static void glGetInvariantIntegerEXT(int id, int value, IntBuffer pbData)
/* 660:    */   {
/* 661:546 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 662:547 */     long function_pointer = caps.glGetInvariantIntegervEXT;
/* 663:548 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 664:549 */     BufferChecks.checkBuffer(pbData, 4);
/* 665:550 */     nglGetInvariantIntegervEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 666:    */   }
/* 667:    */   
/* 668:    */   static native void nglGetInvariantIntegervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 669:    */   
/* 670:    */   public static void glGetInvariantFloatEXT(int id, int value, FloatBuffer pbData)
/* 671:    */   {
/* 672:555 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 673:556 */     long function_pointer = caps.glGetInvariantFloatvEXT;
/* 674:557 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 675:558 */     BufferChecks.checkBuffer(pbData, 4);
/* 676:559 */     nglGetInvariantFloatvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 677:    */   }
/* 678:    */   
/* 679:    */   static native void nglGetInvariantFloatvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 680:    */   
/* 681:    */   public static void glGetLocalConstantBooleanEXT(int id, int value, ByteBuffer pbData)
/* 682:    */   {
/* 683:564 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 684:565 */     long function_pointer = caps.glGetLocalConstantBooleanvEXT;
/* 685:566 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 686:567 */     BufferChecks.checkBuffer(pbData, 4);
/* 687:568 */     nglGetLocalConstantBooleanvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 688:    */   }
/* 689:    */   
/* 690:    */   static native void nglGetLocalConstantBooleanvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 691:    */   
/* 692:    */   public static void glGetLocalConstantIntegerEXT(int id, int value, IntBuffer pbData)
/* 693:    */   {
/* 694:573 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 695:574 */     long function_pointer = caps.glGetLocalConstantIntegervEXT;
/* 696:575 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 697:576 */     BufferChecks.checkBuffer(pbData, 4);
/* 698:577 */     nglGetLocalConstantIntegervEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 699:    */   }
/* 700:    */   
/* 701:    */   static native void nglGetLocalConstantIntegervEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 702:    */   
/* 703:    */   public static void glGetLocalConstantFloatEXT(int id, int value, FloatBuffer pbData)
/* 704:    */   {
/* 705:582 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 706:583 */     long function_pointer = caps.glGetLocalConstantFloatvEXT;
/* 707:584 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 708:585 */     BufferChecks.checkBuffer(pbData, 4);
/* 709:586 */     nglGetLocalConstantFloatvEXT(id, value, MemoryUtil.getAddress(pbData), function_pointer);
/* 710:    */   }
/* 711:    */   
/* 712:    */   static native void nglGetLocalConstantFloatvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 713:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTVertexShader
 * JD-Core Version:    0.7.0.1
 */