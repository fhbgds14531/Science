/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.DoubleBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ 
/*  6:   */ public final class ARBVertexAttrib64bit
/*  7:   */ {
/*  8:   */   public static final int GL_DOUBLE_VEC2 = 36860;
/*  9:   */   public static final int GL_DOUBLE_VEC3 = 36861;
/* 10:   */   public static final int GL_DOUBLE_VEC4 = 36862;
/* 11:   */   public static final int GL_DOUBLE_MAT2 = 36678;
/* 12:   */   public static final int GL_DOUBLE_MAT3 = 36679;
/* 13:   */   public static final int GL_DOUBLE_MAT4 = 36680;
/* 14:   */   public static final int GL_DOUBLE_MAT2x3 = 36681;
/* 15:   */   public static final int GL_DOUBLE_MAT2x4 = 36682;
/* 16:   */   public static final int GL_DOUBLE_MAT3x2 = 36683;
/* 17:   */   public static final int GL_DOUBLE_MAT3x4 = 36684;
/* 18:   */   public static final int GL_DOUBLE_MAT4x2 = 36685;
/* 19:   */   public static final int GL_DOUBLE_MAT4x3 = 36686;
/* 20:   */   
/* 21:   */   public static void glVertexAttribL1d(int index, double x)
/* 22:   */   {
/* 23:29 */     GL41.glVertexAttribL1d(index, x);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static void glVertexAttribL2d(int index, double x, double y)
/* 27:   */   {
/* 28:33 */     GL41.glVertexAttribL2d(index, x, y);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void glVertexAttribL3d(int index, double x, double y, double z)
/* 32:   */   {
/* 33:37 */     GL41.glVertexAttribL3d(index, x, y, z);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static void glVertexAttribL4d(int index, double x, double y, double z, double w)
/* 37:   */   {
/* 38:41 */     GL41.glVertexAttribL4d(index, x, y, z, w);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static void glVertexAttribL1(int index, DoubleBuffer v)
/* 42:   */   {
/* 43:45 */     GL41.glVertexAttribL1(index, v);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static void glVertexAttribL2(int index, DoubleBuffer v)
/* 47:   */   {
/* 48:49 */     GL41.glVertexAttribL2(index, v);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public static void glVertexAttribL3(int index, DoubleBuffer v)
/* 52:   */   {
/* 53:53 */     GL41.glVertexAttribL3(index, v);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static void glVertexAttribL4(int index, DoubleBuffer v)
/* 57:   */   {
/* 58:57 */     GL41.glVertexAttribL4(index, v);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public static void glVertexAttribLPointer(int index, int size, int stride, DoubleBuffer pointer)
/* 62:   */   {
/* 63:61 */     GL41.glVertexAttribLPointer(index, size, stride, pointer);
/* 64:   */   }
/* 65:   */   
/* 66:   */   public static void glVertexAttribLPointer(int index, int size, int stride, long pointer_buffer_offset)
/* 67:   */   {
/* 68:64 */     GL41.glVertexAttribLPointer(index, size, stride, pointer_buffer_offset);
/* 69:   */   }
/* 70:   */   
/* 71:   */   public static void glGetVertexAttribL(int index, int pname, DoubleBuffer params)
/* 72:   */   {
/* 73:68 */     GL41.glGetVertexAttribL(index, pname, params);
/* 74:   */   }
/* 75:   */   
/* 76:   */   public static void glVertexArrayVertexAttribLOffsetEXT(int vaobj, int buffer, int index, int size, int type, int stride, long offset)
/* 77:   */   {
/* 78:72 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 79:73 */     long function_pointer = caps.glVertexArrayVertexAttribLOffsetEXT;
/* 80:74 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 81:75 */     nglVertexArrayVertexAttribLOffsetEXT(vaobj, buffer, index, size, type, stride, offset, function_pointer);
/* 82:   */   }
/* 83:   */   
/* 84:   */   static native void nglVertexArrayVertexAttribLOffsetEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 85:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexAttrib64bit
 * JD-Core Version:    0.7.0.1
 */