/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ import org.lwjgl.LWJGLUtil;
/*   7:    */ import org.lwjgl.PointerBuffer;
/*   8:    */ import org.lwjgl.Sys;
/*   9:    */ 
/*  10:    */ final class ContextGL
/*  11:    */   implements Context
/*  12:    */ {
/*  13:    */   private Thread thread;
/*  14:    */   private boolean destroy_requested;
/*  15:    */   private boolean destroyed;
/*  16:    */   private final boolean forwardCompatible;
/*  17:    */   private final ContextAttribs contextAttribs;
/*  18:    */   private final PeerInfo peer_info;
/*  19:    */   private final ByteBuffer handle;
/*  20: 63 */   private static final ThreadLocal<ContextGL> current_context_local = new ThreadLocal();
/*  21:    */   
/*  22:    */   static
/*  23:    */   {
/*  24: 81 */     Sys.initialize();
/*  25:    */   }
/*  26:    */   
/*  27: 82 */   private static final ContextImplementation implementation = createImplementation();
/*  28:    */   
/*  29:    */   private static ContextImplementation createImplementation()
/*  30:    */   {
/*  31: 86 */     switch ()
/*  32:    */     {
/*  33:    */     case 1: 
/*  34: 88 */       return new LinuxContextImplementation();
/*  35:    */     case 3: 
/*  36: 90 */       return new WindowsContextImplementation();
/*  37:    */     case 2: 
/*  38: 92 */       return new MacOSXContextImplementation();
/*  39:    */     }
/*  40: 94 */     throw new IllegalStateException("Unsupported platform");
/*  41:    */   }
/*  42:    */   
/*  43:    */   PeerInfo getPeerInfo()
/*  44:    */   {
/*  45: 99 */     return this.peer_info;
/*  46:    */   }
/*  47:    */   
/*  48:    */   ContextAttribs getContextAttribs()
/*  49:    */   {
/*  50:103 */     return this.contextAttribs;
/*  51:    */   }
/*  52:    */   
/*  53:    */   static ContextGL getCurrentContext()
/*  54:    */   {
/*  55:107 */     return (ContextGL)current_context_local.get();
/*  56:    */   }
/*  57:    */   
/*  58:    */   ContextGL(PeerInfo peer_info, ContextAttribs attribs, ContextGL shared_context)
/*  59:    */     throws LWJGLException
/*  60:    */   {
/*  61:112 */     ContextGL context_lock = shared_context != null ? shared_context : this;
/*  62:115 */     synchronized (context_lock)
/*  63:    */     {
/*  64:116 */       if ((shared_context != null) && (shared_context.destroyed)) {
/*  65:117 */         throw new IllegalArgumentException("Shared context is destroyed");
/*  66:    */       }
/*  67:118 */       GLContext.loadOpenGLLibrary();
/*  68:    */       try
/*  69:    */       {
/*  70:120 */         this.peer_info = peer_info;
/*  71:121 */         this.contextAttribs = attribs;
/*  72:    */         IntBuffer attribList;
/*  73:124 */         if (attribs != null)
/*  74:    */         {
/*  75:125 */           IntBuffer attribList = attribs.getAttribList();
/*  76:126 */           this.forwardCompatible = attribs.isForwardCompatible();
/*  77:    */         }
/*  78:    */         else
/*  79:    */         {
/*  80:128 */           attribList = null;
/*  81:129 */           this.forwardCompatible = false;
/*  82:    */         }
/*  83:132 */         this.handle = implementation.create(peer_info, attribList, shared_context != null ? shared_context.handle : null);
/*  84:    */       }
/*  85:    */       catch (LWJGLException e)
/*  86:    */       {
/*  87:134 */         GLContext.unloadOpenGLLibrary();
/*  88:135 */         throw e;
/*  89:    */       }
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void releaseCurrent()
/*  94:    */     throws LWJGLException
/*  95:    */   {
/*  96:142 */     ContextGL current_context = getCurrentContext();
/*  97:143 */     if (current_context != null)
/*  98:    */     {
/*  99:144 */       implementation.releaseCurrentContext();
/* 100:145 */       GLContext.useContext(null);
/* 101:146 */       current_context_local.set(null);
/* 102:147 */       synchronized (current_context)
/* 103:    */       {
/* 104:148 */         current_context.thread = null;
/* 105:149 */         current_context.checkDestroy();
/* 106:    */       }
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   public synchronized void releaseDrawable()
/* 111:    */     throws LWJGLException
/* 112:    */   {
/* 113:161 */     if (this.destroyed) {
/* 114:162 */       throw new IllegalStateException("Context is destroyed");
/* 115:    */     }
/* 116:163 */     implementation.releaseDrawable(getHandle());
/* 117:    */   }
/* 118:    */   
/* 119:    */   public synchronized void update()
/* 120:    */   {
/* 121:168 */     if (this.destroyed) {
/* 122:169 */       throw new IllegalStateException("Context is destroyed");
/* 123:    */     }
/* 124:170 */     implementation.update(getHandle());
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static void swapBuffers()
/* 128:    */     throws LWJGLException
/* 129:    */   {
/* 130:175 */     implementation.swapBuffers();
/* 131:    */   }
/* 132:    */   
/* 133:    */   private boolean canAccess()
/* 134:    */   {
/* 135:179 */     return (this.thread == null) || (Thread.currentThread() == this.thread);
/* 136:    */   }
/* 137:    */   
/* 138:    */   private void checkAccess()
/* 139:    */   {
/* 140:183 */     if (!canAccess()) {
/* 141:184 */       throw new IllegalStateException("From thread " + Thread.currentThread() + ": " + this.thread + " already has the context current");
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public synchronized void makeCurrent()
/* 146:    */     throws LWJGLException
/* 147:    */   {
/* 148:189 */     checkAccess();
/* 149:190 */     if (this.destroyed) {
/* 150:191 */       throw new IllegalStateException("Context is destroyed");
/* 151:    */     }
/* 152:192 */     this.thread = Thread.currentThread();
/* 153:193 */     current_context_local.set(this);
/* 154:194 */     implementation.makeCurrent(this.peer_info, this.handle);
/* 155:195 */     GLContext.useContext(this, this.forwardCompatible);
/* 156:    */   }
/* 157:    */   
/* 158:    */   ByteBuffer getHandle()
/* 159:    */   {
/* 160:199 */     return this.handle;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public synchronized boolean isCurrent()
/* 164:    */     throws LWJGLException
/* 165:    */   {
/* 166:204 */     if (this.destroyed) {
/* 167:205 */       throw new IllegalStateException("Context is destroyed");
/* 168:    */     }
/* 169:206 */     return implementation.isCurrent(this.handle);
/* 170:    */   }
/* 171:    */   
/* 172:    */   private void checkDestroy()
/* 173:    */   {
/* 174:210 */     if ((!this.destroyed) && (this.destroy_requested)) {
/* 175:    */       try
/* 176:    */       {
/* 177:212 */         releaseDrawable();
/* 178:213 */         implementation.destroy(this.peer_info, this.handle);
/* 179:214 */         CallbackUtil.unregisterCallbacks(this);
/* 180:215 */         this.destroyed = true;
/* 181:216 */         this.thread = null;
/* 182:217 */         GLContext.unloadOpenGLLibrary();
/* 183:    */       }
/* 184:    */       catch (LWJGLException e)
/* 185:    */       {
/* 186:219 */         LWJGLUtil.log("Exception occurred while destroying context: " + e);
/* 187:    */       }
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static void setSwapInterval(int value)
/* 192:    */   {
/* 193:232 */     implementation.setSwapInterval(value);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public synchronized void forceDestroy()
/* 197:    */     throws LWJGLException
/* 198:    */   {
/* 199:241 */     checkAccess();
/* 200:242 */     destroy();
/* 201:    */   }
/* 202:    */   
/* 203:    */   public synchronized void destroy()
/* 204:    */     throws LWJGLException
/* 205:    */   {
/* 206:250 */     if (this.destroyed) {
/* 207:251 */       return;
/* 208:    */     }
/* 209:252 */     this.destroy_requested = true;
/* 210:253 */     boolean was_current = isCurrent();
/* 211:254 */     int error = 0;
/* 212:255 */     if (was_current)
/* 213:    */     {
/* 214:256 */       if ((GLContext.getCapabilities() != null) && (GLContext.getCapabilities().OpenGL11)) {
/* 215:257 */         error = GL11.glGetError();
/* 216:    */       }
/* 217:258 */       releaseCurrent();
/* 218:    */     }
/* 219:260 */     checkDestroy();
/* 220:261 */     if ((was_current) && (error != 0)) {
/* 221:262 */       throw new OpenGLException(error);
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   public synchronized void setCLSharingProperties(PointerBuffer properties)
/* 226:    */     throws LWJGLException
/* 227:    */   {
/* 228:266 */     ByteBuffer peer_handle = this.peer_info.lockAndGetHandle();
/* 229:    */     try
/* 230:    */     {
/* 231:268 */       switch (LWJGLUtil.getPlatform())
/* 232:    */       {
/* 233:    */       case 3: 
/* 234:270 */         WindowsContextImplementation implWindows = (WindowsContextImplementation)implementation;
/* 235:271 */         properties.put(8200L).put(implWindows.getHGLRC(this.handle));
/* 236:272 */         properties.put(8203L).put(implWindows.getHDC(peer_handle));
/* 237:273 */         break;
/* 238:    */       case 1: 
/* 239:275 */         LinuxContextImplementation implLinux = (LinuxContextImplementation)implementation;
/* 240:276 */         properties.put(8200L).put(implLinux.getGLXContext(this.handle));
/* 241:277 */         properties.put(8202L).put(implLinux.getDisplay(peer_handle));
/* 242:278 */         break;
/* 243:    */       case 2: 
/* 244:280 */         if (LWJGLUtil.isMacOSXEqualsOrBetterThan(10, 6))
/* 245:    */         {
/* 246:282 */           MacOSXContextImplementation implMacOSX = (MacOSXContextImplementation)implementation;
/* 247:283 */           long CGLShareGroup = implMacOSX.getCGLShareGroup(this.handle);
/* 248:284 */           properties.put(268435456L).put(CGLShareGroup);
/* 249:    */         }
/* 250:285 */         break;
/* 251:    */       }
/* 252:288 */       throw new UnsupportedOperationException("CL/GL context sharing is not supported on this platform.");
/* 253:    */     }
/* 254:    */     finally
/* 255:    */     {
/* 256:291 */       this.peer_info.unlock();
/* 257:    */     }
/* 258:    */   }
/* 259:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ContextGL
 * JD-Core Version:    0.7.0.1
 */