/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.IntBuffer;
/*    5:     */ import java.nio.LongBuffer;
/*    6:     */ import org.lwjgl.BufferChecks;
/*    7:     */ import org.lwjgl.MemoryUtil;
/*    8:     */ import org.lwjgl.PointerWrapper;
/*    9:     */ 
/*   10:     */ public final class GL43
/*   11:     */ {
/*   12:     */   public static final int GL_NUM_SHADING_LANGUAGE_VERSIONS = 33513;
/*   13:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_LONG = 34638;
/*   14:     */   public static final int GL_COMPRESSED_RGB8_ETC2 = 37492;
/*   15:     */   public static final int GL_COMPRESSED_SRGB8_ETC2 = 37493;
/*   16:     */   public static final int GL_COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37494;
/*   17:     */   public static final int GL_COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37495;
/*   18:     */   public static final int GL_COMPRESSED_RGBA8_ETC2_EAC = 37496;
/*   19:     */   public static final int GL_COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = 37497;
/*   20:     */   public static final int GL_COMPRESSED_R11_EAC = 37488;
/*   21:     */   public static final int GL_COMPRESSED_SIGNED_R11_EAC = 37489;
/*   22:     */   public static final int GL_COMPRESSED_RG11_EAC = 37490;
/*   23:     */   public static final int GL_COMPRESSED_SIGNED_RG11_EAC = 37491;
/*   24:     */   public static final int GL_PRIMITIVE_RESTART_FIXED_INDEX = 36201;
/*   25:     */   public static final int GL_ANY_SAMPLES_PASSED_CONSERVATIVE = 36202;
/*   26:     */   public static final int GL_MAX_ELEMENT_INDEX = 36203;
/*   27:     */   public static final int GL_COMPUTE_SHADER = 37305;
/*   28:     */   public static final int GL_MAX_COMPUTE_UNIFORM_BLOCKS = 37307;
/*   29:     */   public static final int GL_MAX_COMPUTE_TEXTURE_IMAGE_UNITS = 37308;
/*   30:     */   public static final int GL_MAX_COMPUTE_IMAGE_UNIFORMS = 37309;
/*   31:     */   public static final int GL_MAX_COMPUTE_SHARED_MEMORY_SIZE = 33378;
/*   32:     */   public static final int GL_MAX_COMPUTE_UNIFORM_COMPONENTS = 33379;
/*   33:     */   public static final int GL_MAX_COMPUTE_ATOMIC_COUNTER_BUFFERS = 33380;
/*   34:     */   public static final int GL_MAX_COMPUTE_ATOMIC_COUNTERS = 33381;
/*   35:     */   public static final int GL_MAX_COMBINED_COMPUTE_UNIFORM_COMPONENTS = 33382;
/*   36:     */   public static final int GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS = 37099;
/*   37:     */   public static final int GL_MAX_COMPUTE_WORK_GROUP_COUNT = 37310;
/*   38:     */   public static final int GL_MAX_COMPUTE_WORK_GROUP_SIZE = 37311;
/*   39:     */   public static final int GL_COMPUTE_WORK_GROUP_SIZE = 33383;
/*   40:     */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_COMPUTE_SHADER = 37100;
/*   41:     */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_COMPUTE_SHADER = 37101;
/*   42:     */   public static final int GL_DISPATCH_INDIRECT_BUFFER = 37102;
/*   43:     */   public static final int GL_DISPATCH_INDIRECT_BUFFER_BINDING = 37103;
/*   44:     */   public static final int GL_COMPUTE_SHADER_BIT = 32;
/*   45:     */   public static final int GL_DEBUG_OUTPUT = 37600;
/*   46:     */   public static final int GL_DEBUG_OUTPUT_SYNCHRONOUS = 33346;
/*   47:     */   public static final int GL_CONTEXT_FLAG_DEBUG_BIT = 2;
/*   48:     */   public static final int GL_MAX_DEBUG_MESSAGE_LENGTH = 37187;
/*   49:     */   public static final int GL_MAX_DEBUG_LOGGED_MESSAGES = 37188;
/*   50:     */   public static final int GL_DEBUG_LOGGED_MESSAGES = 37189;
/*   51:     */   public static final int GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH = 33347;
/*   52:     */   public static final int GL_MAX_DEBUG_GROUP_STACK_DEPTH = 33388;
/*   53:     */   public static final int GL_DEBUG_GROUP_STACK_DEPTH = 33389;
/*   54:     */   public static final int GL_MAX_LABEL_LENGTH = 33512;
/*   55:     */   public static final int GL_DEBUG_CALLBACK_FUNCTION = 33348;
/*   56:     */   public static final int GL_DEBUG_CALLBACK_USER_PARAM = 33349;
/*   57:     */   public static final int GL_DEBUG_SOURCE_API = 33350;
/*   58:     */   public static final int GL_DEBUG_SOURCE_WINDOW_SYSTEM = 33351;
/*   59:     */   public static final int GL_DEBUG_SOURCE_SHADER_COMPILER = 33352;
/*   60:     */   public static final int GL_DEBUG_SOURCE_THIRD_PARTY = 33353;
/*   61:     */   public static final int GL_DEBUG_SOURCE_APPLICATION = 33354;
/*   62:     */   public static final int GL_DEBUG_SOURCE_OTHER = 33355;
/*   63:     */   public static final int GL_DEBUG_TYPE_ERROR = 33356;
/*   64:     */   public static final int GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR = 33357;
/*   65:     */   public static final int GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR = 33358;
/*   66:     */   public static final int GL_DEBUG_TYPE_PORTABILITY = 33359;
/*   67:     */   public static final int GL_DEBUG_TYPE_PERFORMANCE = 33360;
/*   68:     */   public static final int GL_DEBUG_TYPE_OTHER = 33361;
/*   69:     */   public static final int GL_DEBUG_TYPE_MARKER = 33384;
/*   70:     */   public static final int GL_DEBUG_TYPE_PUSH_GROUP = 33385;
/*   71:     */   public static final int GL_DEBUG_TYPE_POP_GROUP = 33386;
/*   72:     */   public static final int GL_DEBUG_SEVERITY_HIGH = 37190;
/*   73:     */   public static final int GL_DEBUG_SEVERITY_MEDIUM = 37191;
/*   74:     */   public static final int GL_DEBUG_SEVERITY_LOW = 37192;
/*   75:     */   public static final int GL_DEBUG_SEVERITY_NOTIFICATION = 33387;
/*   76:     */   public static final int GL_STACK_UNDERFLOW = 1284;
/*   77:     */   public static final int GL_STACK_OVERFLOW = 1283;
/*   78:     */   public static final int GL_BUFFER = 33504;
/*   79:     */   public static final int GL_SHADER = 33505;
/*   80:     */   public static final int GL_PROGRAM = 33506;
/*   81:     */   public static final int GL_QUERY = 33507;
/*   82:     */   public static final int GL_PROGRAM_PIPELINE = 33508;
/*   83:     */   public static final int GL_SAMPLER = 33510;
/*   84:     */   public static final int GL_DISPLAY_LIST = 33511;
/*   85:     */   public static final int GL_MAX_UNIFORM_LOCATIONS = 33390;
/*   86:     */   public static final int GL_FRAMEBUFFER_DEFAULT_WIDTH = 37648;
/*   87:     */   public static final int GL_FRAMEBUFFER_DEFAULT_HEIGHT = 37649;
/*   88:     */   public static final int GL_FRAMEBUFFER_DEFAULT_LAYERS = 37650;
/*   89:     */   public static final int GL_FRAMEBUFFER_DEFAULT_SAMPLES = 37651;
/*   90:     */   public static final int GL_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS = 37652;
/*   91:     */   public static final int GL_MAX_FRAMEBUFFER_WIDTH = 37653;
/*   92:     */   public static final int GL_MAX_FRAMEBUFFER_HEIGHT = 37654;
/*   93:     */   public static final int GL_MAX_FRAMEBUFFER_LAYERS = 37655;
/*   94:     */   public static final int GL_MAX_FRAMEBUFFER_SAMPLES = 37656;
/*   95:     */   public static final int GL_TEXTURE_1D = 3552;
/*   96:     */   public static final int GL_TEXTURE_1D_ARRAY = 35864;
/*   97:     */   public static final int GL_TEXTURE_2D = 3553;
/*   98:     */   public static final int GL_TEXTURE_2D_ARRAY = 35866;
/*   99:     */   public static final int GL_TEXTURE_3D = 32879;
/*  100:     */   public static final int GL_TEXTURE_CUBE_MAP = 34067;
/*  101:     */   public static final int GL_TEXTURE_CUBE_MAP_ARRAY = 36873;
/*  102:     */   public static final int GL_TEXTURE_RECTANGLE = 34037;
/*  103:     */   public static final int GL_TEXTURE_BUFFER = 35882;
/*  104:     */   public static final int GL_RENDERBUFFER = 36161;
/*  105:     */   public static final int GL_TEXTURE_2D_MULTISAMPLE = 37120;
/*  106:     */   public static final int GL_TEXTURE_2D_MULTISAMPLE_ARRAY = 37122;
/*  107:     */   public static final int GL_SAMPLES = 32937;
/*  108:     */   public static final int GL_NUM_SAMPLE_COUNTS = 37760;
/*  109:     */   public static final int GL_INTERNALFORMAT_SUPPORTED = 33391;
/*  110:     */   public static final int GL_INTERNALFORMAT_PREFERRED = 33392;
/*  111:     */   public static final int GL_INTERNALFORMAT_RED_SIZE = 33393;
/*  112:     */   public static final int GL_INTERNALFORMAT_GREEN_SIZE = 33394;
/*  113:     */   public static final int GL_INTERNALFORMAT_BLUE_SIZE = 33395;
/*  114:     */   public static final int GL_INTERNALFORMAT_ALPHA_SIZE = 33396;
/*  115:     */   public static final int GL_INTERNALFORMAT_DEPTH_SIZE = 33397;
/*  116:     */   public static final int GL_INTERNALFORMAT_STENCIL_SIZE = 33398;
/*  117:     */   public static final int GL_INTERNALFORMAT_SHARED_SIZE = 33399;
/*  118:     */   public static final int GL_INTERNALFORMAT_RED_TYPE = 33400;
/*  119:     */   public static final int GL_INTERNALFORMAT_GREEN_TYPE = 33401;
/*  120:     */   public static final int GL_INTERNALFORMAT_BLUE_TYPE = 33402;
/*  121:     */   public static final int GL_INTERNALFORMAT_ALPHA_TYPE = 33403;
/*  122:     */   public static final int GL_INTERNALFORMAT_DEPTH_TYPE = 33404;
/*  123:     */   public static final int GL_INTERNALFORMAT_STENCIL_TYPE = 33405;
/*  124:     */   public static final int GL_MAX_WIDTH = 33406;
/*  125:     */   public static final int GL_MAX_HEIGHT = 33407;
/*  126:     */   public static final int GL_MAX_DEPTH = 33408;
/*  127:     */   public static final int GL_MAX_LAYERS = 33409;
/*  128:     */   public static final int GL_MAX_COMBINED_DIMENSIONS = 33410;
/*  129:     */   public static final int GL_COLOR_COMPONENTS = 33411;
/*  130:     */   public static final int GL_DEPTH_COMPONENTS = 33412;
/*  131:     */   public static final int GL_STENCIL_COMPONENTS = 33413;
/*  132:     */   public static final int GL_COLOR_RENDERABLE = 33414;
/*  133:     */   public static final int GL_DEPTH_RENDERABLE = 33415;
/*  134:     */   public static final int GL_STENCIL_RENDERABLE = 33416;
/*  135:     */   public static final int GL_FRAMEBUFFER_RENDERABLE = 33417;
/*  136:     */   public static final int GL_FRAMEBUFFER_RENDERABLE_LAYERED = 33418;
/*  137:     */   public static final int GL_FRAMEBUFFER_BLEND = 33419;
/*  138:     */   public static final int GL_READ_PIXELS = 33420;
/*  139:     */   public static final int GL_READ_PIXELS_FORMAT = 33421;
/*  140:     */   public static final int GL_READ_PIXELS_TYPE = 33422;
/*  141:     */   public static final int GL_TEXTURE_IMAGE_FORMAT = 33423;
/*  142:     */   public static final int GL_TEXTURE_IMAGE_TYPE = 33424;
/*  143:     */   public static final int GL_GET_TEXTURE_IMAGE_FORMAT = 33425;
/*  144:     */   public static final int GL_GET_TEXTURE_IMAGE_TYPE = 33426;
/*  145:     */   public static final int GL_MIPMAP = 33427;
/*  146:     */   public static final int GL_MANUAL_GENERATE_MIPMAP = 33428;
/*  147:     */   public static final int GL_AUTO_GENERATE_MIPMAP = 33429;
/*  148:     */   public static final int GL_COLOR_ENCODING = 33430;
/*  149:     */   public static final int GL_SRGB_READ = 33431;
/*  150:     */   public static final int GL_SRGB_WRITE = 33432;
/*  151:     */   public static final int GL_SRGB_DECODE_ARB = 33433;
/*  152:     */   public static final int GL_FILTER = 33434;
/*  153:     */   public static final int GL_VERTEX_TEXTURE = 33435;
/*  154:     */   public static final int GL_TESS_CONTROL_TEXTURE = 33436;
/*  155:     */   public static final int GL_TESS_EVALUATION_TEXTURE = 33437;
/*  156:     */   public static final int GL_GEOMETRY_TEXTURE = 33438;
/*  157:     */   public static final int GL_FRAGMENT_TEXTURE = 33439;
/*  158:     */   public static final int GL_COMPUTE_TEXTURE = 33440;
/*  159:     */   public static final int GL_TEXTURE_SHADOW = 33441;
/*  160:     */   public static final int GL_TEXTURE_GATHER = 33442;
/*  161:     */   public static final int GL_TEXTURE_GATHER_SHADOW = 33443;
/*  162:     */   public static final int GL_SHADER_IMAGE_LOAD = 33444;
/*  163:     */   public static final int GL_SHADER_IMAGE_STORE = 33445;
/*  164:     */   public static final int GL_SHADER_IMAGE_ATOMIC = 33446;
/*  165:     */   public static final int GL_IMAGE_TEXEL_SIZE = 33447;
/*  166:     */   public static final int GL_IMAGE_COMPATIBILITY_CLASS = 33448;
/*  167:     */   public static final int GL_IMAGE_PIXEL_FORMAT = 33449;
/*  168:     */   public static final int GL_IMAGE_PIXEL_TYPE = 33450;
/*  169:     */   public static final int GL_IMAGE_FORMAT_COMPATIBILITY_TYPE = 37063;
/*  170:     */   public static final int GL_SIMULTANEOUS_TEXTURE_AND_DEPTH_TEST = 33452;
/*  171:     */   public static final int GL_SIMULTANEOUS_TEXTURE_AND_STENCIL_TEST = 33453;
/*  172:     */   public static final int GL_SIMULTANEOUS_TEXTURE_AND_DEPTH_WRITE = 33454;
/*  173:     */   public static final int GL_SIMULTANEOUS_TEXTURE_AND_STENCIL_WRITE = 33455;
/*  174:     */   public static final int GL_TEXTURE_COMPRESSED = 34465;
/*  175:     */   public static final int GL_TEXTURE_COMPRESSED_BLOCK_WIDTH = 33457;
/*  176:     */   public static final int GL_TEXTURE_COMPRESSED_BLOCK_HEIGHT = 33458;
/*  177:     */   public static final int GL_TEXTURE_COMPRESSED_BLOCK_SIZE = 33459;
/*  178:     */   public static final int GL_CLEAR_BUFFER = 33460;
/*  179:     */   public static final int GL_TEXTURE_VIEW = 33461;
/*  180:     */   public static final int GL_VIEW_COMPATIBILITY_CLASS = 33462;
/*  181:     */   public static final int GL_FULL_SUPPORT = 33463;
/*  182:     */   public static final int GL_CAVEAT_SUPPORT = 33464;
/*  183:     */   public static final int GL_IMAGE_CLASS_4_X_32 = 33465;
/*  184:     */   public static final int GL_IMAGE_CLASS_2_X_32 = 33466;
/*  185:     */   public static final int GL_IMAGE_CLASS_1_X_32 = 33467;
/*  186:     */   public static final int GL_IMAGE_CLASS_4_X_16 = 33468;
/*  187:     */   public static final int GL_IMAGE_CLASS_2_X_16 = 33469;
/*  188:     */   public static final int GL_IMAGE_CLASS_1_X_16 = 33470;
/*  189:     */   public static final int GL_IMAGE_CLASS_4_X_8 = 33471;
/*  190:     */   public static final int GL_IMAGE_CLASS_2_X_8 = 33472;
/*  191:     */   public static final int GL_IMAGE_CLASS_1_X_8 = 33473;
/*  192:     */   public static final int GL_IMAGE_CLASS_11_11_10 = 33474;
/*  193:     */   public static final int GL_IMAGE_CLASS_10_10_10_2 = 33475;
/*  194:     */   public static final int GL_VIEW_CLASS_128_BITS = 33476;
/*  195:     */   public static final int GL_VIEW_CLASS_96_BITS = 33477;
/*  196:     */   public static final int GL_VIEW_CLASS_64_BITS = 33478;
/*  197:     */   public static final int GL_VIEW_CLASS_48_BITS = 33479;
/*  198:     */   public static final int GL_VIEW_CLASS_32_BITS = 33480;
/*  199:     */   public static final int GL_VIEW_CLASS_24_BITS = 33481;
/*  200:     */   public static final int GL_VIEW_CLASS_16_BITS = 33482;
/*  201:     */   public static final int GL_VIEW_CLASS_8_BITS = 33483;
/*  202:     */   public static final int GL_VIEW_CLASS_S3TC_DXT1_RGB = 33484;
/*  203:     */   public static final int GL_VIEW_CLASS_S3TC_DXT1_RGBA = 33485;
/*  204:     */   public static final int GL_VIEW_CLASS_S3TC_DXT3_RGBA = 33486;
/*  205:     */   public static final int GL_VIEW_CLASS_S3TC_DXT5_RGBA = 33487;
/*  206:     */   public static final int GL_VIEW_CLASS_RGTC1_RED = 33488;
/*  207:     */   public static final int GL_VIEW_CLASS_RGTC2_RG = 33489;
/*  208:     */   public static final int GL_VIEW_CLASS_BPTC_UNORM = 33490;
/*  209:     */   public static final int GL_VIEW_CLASS_BPTC_FLOAT = 33491;
/*  210:     */   public static final int GL_UNIFORM = 37601;
/*  211:     */   public static final int GL_UNIFORM_BLOCK = 37602;
/*  212:     */   public static final int GL_PROGRAM_INPUT = 37603;
/*  213:     */   public static final int GL_PROGRAM_OUTPUT = 37604;
/*  214:     */   public static final int GL_BUFFER_VARIABLE = 37605;
/*  215:     */   public static final int GL_SHADER_STORAGE_BLOCK = 37606;
/*  216:     */   public static final int GL_VERTEX_SUBROUTINE = 37608;
/*  217:     */   public static final int GL_TESS_CONTROL_SUBROUTINE = 37609;
/*  218:     */   public static final int GL_TESS_EVALUATION_SUBROUTINE = 37610;
/*  219:     */   public static final int GL_GEOMETRY_SUBROUTINE = 37611;
/*  220:     */   public static final int GL_FRAGMENT_SUBROUTINE = 37612;
/*  221:     */   public static final int GL_COMPUTE_SUBROUTINE = 37613;
/*  222:     */   public static final int GL_VERTEX_SUBROUTINE_UNIFORM = 37614;
/*  223:     */   public static final int GL_TESS_CONTROL_SUBROUTINE_UNIFORM = 37615;
/*  224:     */   public static final int GL_TESS_EVALUATION_SUBROUTINE_UNIFORM = 37616;
/*  225:     */   public static final int GL_GEOMETRY_SUBROUTINE_UNIFORM = 37617;
/*  226:     */   public static final int GL_FRAGMENT_SUBROUTINE_UNIFORM = 37618;
/*  227:     */   public static final int GL_COMPUTE_SUBROUTINE_UNIFORM = 37619;
/*  228:     */   public static final int GL_TRANSFORM_FEEDBACK_VARYING = 37620;
/*  229:     */   public static final int GL_ACTIVE_RESOURCES = 37621;
/*  230:     */   public static final int GL_MAX_NAME_LENGTH = 37622;
/*  231:     */   public static final int GL_MAX_NUM_ACTIVE_VARIABLES = 37623;
/*  232:     */   public static final int GL_MAX_NUM_COMPATIBLE_SUBROUTINES = 37624;
/*  233:     */   public static final int GL_NAME_LENGTH = 37625;
/*  234:     */   public static final int GL_TYPE = 37626;
/*  235:     */   public static final int GL_ARRAY_SIZE = 37627;
/*  236:     */   public static final int GL_OFFSET = 37628;
/*  237:     */   public static final int GL_BLOCK_INDEX = 37629;
/*  238:     */   public static final int GL_ARRAY_STRIDE = 37630;
/*  239:     */   public static final int GL_MATRIX_STRIDE = 37631;
/*  240:     */   public static final int GL_IS_ROW_MAJOR = 37632;
/*  241:     */   public static final int GL_ATOMIC_COUNTER_BUFFER_INDEX = 37633;
/*  242:     */   public static final int GL_BUFFER_BINDING = 37634;
/*  243:     */   public static final int GL_BUFFER_DATA_SIZE = 37635;
/*  244:     */   public static final int GL_NUM_ACTIVE_VARIABLES = 37636;
/*  245:     */   public static final int GL_ACTIVE_VARIABLES = 37637;
/*  246:     */   public static final int GL_REFERENCED_BY_VERTEX_SHADER = 37638;
/*  247:     */   public static final int GL_REFERENCED_BY_TESS_CONTROL_SHADER = 37639;
/*  248:     */   public static final int GL_REFERENCED_BY_TESS_EVALUATION_SHADER = 37640;
/*  249:     */   public static final int GL_REFERENCED_BY_GEOMETRY_SHADER = 37641;
/*  250:     */   public static final int GL_REFERENCED_BY_FRAGMENT_SHADER = 37642;
/*  251:     */   public static final int GL_REFERENCED_BY_COMPUTE_SHADER = 37643;
/*  252:     */   public static final int GL_TOP_LEVEL_ARRAY_SIZE = 37644;
/*  253:     */   public static final int GL_TOP_LEVEL_ARRAY_STRIDE = 37645;
/*  254:     */   public static final int GL_LOCATION = 37646;
/*  255:     */   public static final int GL_LOCATION_INDEX = 37647;
/*  256:     */   public static final int GL_IS_PER_PATCH = 37607;
/*  257:     */   public static final int GL_SHADER_STORAGE_BUFFER = 37074;
/*  258:     */   public static final int GL_SHADER_STORAGE_BUFFER_BINDING = 37075;
/*  259:     */   public static final int GL_SHADER_STORAGE_BUFFER_START = 37076;
/*  260:     */   public static final int GL_SHADER_STORAGE_BUFFER_SIZE = 37077;
/*  261:     */   public static final int GL_MAX_VERTEX_SHADER_STORAGE_BLOCKS = 37078;
/*  262:     */   public static final int GL_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS = 37079;
/*  263:     */   public static final int GL_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS = 37080;
/*  264:     */   public static final int GL_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS = 37081;
/*  265:     */   public static final int GL_MAX_FRAGMENT_SHADER_STORAGE_BLOCKS = 37082;
/*  266:     */   public static final int GL_MAX_COMPUTE_SHADER_STORAGE_BLOCKS = 37083;
/*  267:     */   public static final int GL_MAX_COMBINED_SHADER_STORAGE_BLOCKS = 37084;
/*  268:     */   public static final int GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS = 37085;
/*  269:     */   public static final int GL_MAX_SHADER_STORAGE_BLOCK_SIZE = 37086;
/*  270:     */   public static final int GL_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT = 37087;
/*  271:     */   public static final int GL_SHADER_STORAGE_BARRIER_BIT = 8192;
/*  272:     */   public static final int GL_MAX_COMBINED_SHADER_OUTPUT_RESOURCES = 36665;
/*  273:     */   public static final int GL_DEPTH_STENCIL_TEXTURE_MODE = 37098;
/*  274:     */   public static final int GL_TEXTURE_BUFFER_OFFSET = 37277;
/*  275:     */   public static final int GL_TEXTURE_BUFFER_SIZE = 37278;
/*  276:     */   public static final int GL_TEXTURE_BUFFER_OFFSET_ALIGNMENT = 37279;
/*  277:     */   public static final int GL_TEXTURE_VIEW_MIN_LEVEL = 33499;
/*  278:     */   public static final int GL_TEXTURE_VIEW_NUM_LEVELS = 33500;
/*  279:     */   public static final int GL_TEXTURE_VIEW_MIN_LAYER = 33501;
/*  280:     */   public static final int GL_TEXTURE_VIEW_NUM_LAYERS = 33502;
/*  281:     */   public static final int GL_TEXTURE_IMMUTABLE_LEVELS = 33503;
/*  282:     */   public static final int GL_VERTEX_ATTRIB_BINDING = 33492;
/*  283:     */   public static final int GL_VERTEX_ATTRIB_RELATIVE_OFFSET = 33493;
/*  284:     */   public static final int GL_VERTEX_BINDING_DIVISOR = 33494;
/*  285:     */   public static final int GL_VERTEX_BINDING_OFFSET = 33495;
/*  286:     */   public static final int GL_VERTEX_BINDING_STRIDE = 33496;
/*  287:     */   public static final int GL_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET = 33497;
/*  288:     */   public static final int GL_MAX_VERTEX_ATTRIB_BINDINGS = 33498;
/*  289:     */   
/*  290:     */   public static void glClearBufferData(int target, int internalformat, int format, int type, ByteBuffer data)
/*  291:     */   {
/*  292: 515 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  293: 516 */     long function_pointer = caps.glClearBufferData;
/*  294: 517 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  295: 518 */     BufferChecks.checkBuffer(data, 1);
/*  296: 519 */     nglClearBufferData(target, internalformat, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  297:     */   }
/*  298:     */   
/*  299:     */   static native void nglClearBufferData(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  300:     */   
/*  301:     */   public static void glClearBufferSubData(int target, int internalformat, long offset, int format, int type, ByteBuffer data)
/*  302:     */   {
/*  303: 524 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  304: 525 */     long function_pointer = caps.glClearBufferSubData;
/*  305: 526 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  306: 527 */     BufferChecks.checkDirect(data);
/*  307: 528 */     nglClearBufferSubData(target, internalformat, offset, data.remaining(), format, type, MemoryUtil.getAddress(data), function_pointer);
/*  308:     */   }
/*  309:     */   
/*  310:     */   static native void nglClearBufferSubData(int paramInt1, int paramInt2, long paramLong1, long paramLong2, int paramInt3, int paramInt4, long paramLong3, long paramLong4);
/*  311:     */   
/*  312:     */   public static void glDispatchCompute(int num_groups_x, int num_groups_y, int num_groups_z)
/*  313:     */   {
/*  314: 533 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  315: 534 */     long function_pointer = caps.glDispatchCompute;
/*  316: 535 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  317: 536 */     nglDispatchCompute(num_groups_x, num_groups_y, num_groups_z, function_pointer);
/*  318:     */   }
/*  319:     */   
/*  320:     */   static native void nglDispatchCompute(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  321:     */   
/*  322:     */   public static void glDispatchComputeIndirect(long indirect)
/*  323:     */   {
/*  324: 541 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  325: 542 */     long function_pointer = caps.glDispatchComputeIndirect;
/*  326: 543 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  327: 544 */     nglDispatchComputeIndirect(indirect, function_pointer);
/*  328:     */   }
/*  329:     */   
/*  330:     */   static native void nglDispatchComputeIndirect(long paramLong1, long paramLong2);
/*  331:     */   
/*  332:     */   public static void glCopyImageSubData(int srcName, int srcTarget, int srcLevel, int srcX, int srcY, int srcZ, int dstName, int dstTarget, int dstLevel, int dstX, int dstY, int dstZ, int srcWidth, int srcHeight, int srcDepth)
/*  333:     */   {
/*  334: 549 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  335: 550 */     long function_pointer = caps.glCopyImageSubData;
/*  336: 551 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  337: 552 */     nglCopyImageSubData(srcName, srcTarget, srcLevel, srcX, srcY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY, dstZ, srcWidth, srcHeight, srcDepth, function_pointer);
/*  338:     */   }
/*  339:     */   
/*  340:     */   static native void nglCopyImageSubData(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, long paramLong);
/*  341:     */   
/*  342:     */   public static void glDebugMessageControl(int source, int type, int severity, IntBuffer ids, boolean enabled)
/*  343:     */   {
/*  344: 557 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  345: 558 */     long function_pointer = caps.glDebugMessageControl;
/*  346: 559 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  347: 560 */     if (ids != null) {
/*  348: 561 */       BufferChecks.checkDirect(ids);
/*  349:     */     }
/*  350: 562 */     nglDebugMessageControl(source, type, severity, ids == null ? 0 : ids.remaining(), MemoryUtil.getAddressSafe(ids), enabled, function_pointer);
/*  351:     */   }
/*  352:     */   
/*  353:     */   static native void nglDebugMessageControl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, boolean paramBoolean, long paramLong2);
/*  354:     */   
/*  355:     */   public static void glDebugMessageInsert(int source, int type, int id, int severity, ByteBuffer buf)
/*  356:     */   {
/*  357: 567 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  358: 568 */     long function_pointer = caps.glDebugMessageInsert;
/*  359: 569 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  360: 570 */     BufferChecks.checkDirect(buf);
/*  361: 571 */     nglDebugMessageInsert(source, type, id, severity, buf.remaining(), MemoryUtil.getAddress(buf), function_pointer);
/*  362:     */   }
/*  363:     */   
/*  364:     */   static native void nglDebugMessageInsert(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  365:     */   
/*  366:     */   public static void glDebugMessageInsert(int source, int type, int id, int severity, CharSequence buf)
/*  367:     */   {
/*  368: 577 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  369: 578 */     long function_pointer = caps.glDebugMessageInsert;
/*  370: 579 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  371: 580 */     nglDebugMessageInsert(source, type, id, severity, buf.length(), APIUtil.getBuffer(caps, buf), function_pointer);
/*  372:     */   }
/*  373:     */   
/*  374:     */   public static void glDebugMessageCallback(KHRDebugCallback callback)
/*  375:     */   {
/*  376: 591 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  377: 592 */     long function_pointer = caps.glDebugMessageCallback;
/*  378: 593 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  379: 594 */     long userParam = callback == null ? 0L : CallbackUtil.createGlobalRef(callback.getHandler());
/*  380: 595 */     CallbackUtil.registerContextCallbackKHR(userParam);
/*  381: 596 */     nglDebugMessageCallback(callback == null ? 0L : callback.getPointer(), userParam, function_pointer);
/*  382:     */   }
/*  383:     */   
/*  384:     */   static native void nglDebugMessageCallback(long paramLong1, long paramLong2, long paramLong3);
/*  385:     */   
/*  386:     */   public static int glGetDebugMessageLog(int count, IntBuffer sources, IntBuffer types, IntBuffer ids, IntBuffer severities, IntBuffer lengths, ByteBuffer messageLog)
/*  387:     */   {
/*  388: 601 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  389: 602 */     long function_pointer = caps.glGetDebugMessageLog;
/*  390: 603 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  391: 604 */     if (sources != null) {
/*  392: 605 */       BufferChecks.checkBuffer(sources, count);
/*  393:     */     }
/*  394: 606 */     if (types != null) {
/*  395: 607 */       BufferChecks.checkBuffer(types, count);
/*  396:     */     }
/*  397: 608 */     if (ids != null) {
/*  398: 609 */       BufferChecks.checkBuffer(ids, count);
/*  399:     */     }
/*  400: 610 */     if (severities != null) {
/*  401: 611 */       BufferChecks.checkBuffer(severities, count);
/*  402:     */     }
/*  403: 612 */     if (lengths != null) {
/*  404: 613 */       BufferChecks.checkBuffer(lengths, count);
/*  405:     */     }
/*  406: 614 */     if (messageLog != null) {
/*  407: 615 */       BufferChecks.checkDirect(messageLog);
/*  408:     */     }
/*  409: 616 */     int __result = nglGetDebugMessageLog(count, messageLog == null ? 0 : messageLog.remaining(), MemoryUtil.getAddressSafe(sources), MemoryUtil.getAddressSafe(types), MemoryUtil.getAddressSafe(ids), MemoryUtil.getAddressSafe(severities), MemoryUtil.getAddressSafe(lengths), MemoryUtil.getAddressSafe(messageLog), function_pointer);
/*  410: 617 */     return __result;
/*  411:     */   }
/*  412:     */   
/*  413:     */   static native int nglGetDebugMessageLog(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/*  414:     */   
/*  415:     */   public static void glPushDebugGroup(int source, int id, ByteBuffer message)
/*  416:     */   {
/*  417: 622 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  418: 623 */     long function_pointer = caps.glPushDebugGroup;
/*  419: 624 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  420: 625 */     BufferChecks.checkDirect(message);
/*  421: 626 */     nglPushDebugGroup(source, id, message.remaining(), MemoryUtil.getAddress(message), function_pointer);
/*  422:     */   }
/*  423:     */   
/*  424:     */   static native void nglPushDebugGroup(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  425:     */   
/*  426:     */   public static void glPushDebugGroup(int source, int id, CharSequence message)
/*  427:     */   {
/*  428: 632 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  429: 633 */     long function_pointer = caps.glPushDebugGroup;
/*  430: 634 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  431: 635 */     nglPushDebugGroup(source, id, message.length(), APIUtil.getBuffer(caps, message), function_pointer);
/*  432:     */   }
/*  433:     */   
/*  434:     */   public static void glPopDebugGroup()
/*  435:     */   {
/*  436: 639 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  437: 640 */     long function_pointer = caps.glPopDebugGroup;
/*  438: 641 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  439: 642 */     nglPopDebugGroup(function_pointer);
/*  440:     */   }
/*  441:     */   
/*  442:     */   static native void nglPopDebugGroup(long paramLong);
/*  443:     */   
/*  444:     */   public static void glObjectLabel(int identifier, int name, ByteBuffer label)
/*  445:     */   {
/*  446: 647 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  447: 648 */     long function_pointer = caps.glObjectLabel;
/*  448: 649 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  449: 650 */     if (label != null) {
/*  450: 651 */       BufferChecks.checkDirect(label);
/*  451:     */     }
/*  452: 652 */     nglObjectLabel(identifier, name, label == null ? 0 : label.remaining(), MemoryUtil.getAddressSafe(label), function_pointer);
/*  453:     */   }
/*  454:     */   
/*  455:     */   static native void nglObjectLabel(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  456:     */   
/*  457:     */   public static void glObjectLabel(int identifier, int name, CharSequence label)
/*  458:     */   {
/*  459: 658 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  460: 659 */     long function_pointer = caps.glObjectLabel;
/*  461: 660 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  462: 661 */     nglObjectLabel(identifier, name, label.length(), APIUtil.getBuffer(caps, label), function_pointer);
/*  463:     */   }
/*  464:     */   
/*  465:     */   public static void glGetObjectLabel(int identifier, int name, IntBuffer length, ByteBuffer label)
/*  466:     */   {
/*  467: 665 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  468: 666 */     long function_pointer = caps.glGetObjectLabel;
/*  469: 667 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  470: 668 */     if (length != null) {
/*  471: 669 */       BufferChecks.checkBuffer(length, 1);
/*  472:     */     }
/*  473: 670 */     BufferChecks.checkDirect(label);
/*  474: 671 */     nglGetObjectLabel(identifier, name, label.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(label), function_pointer);
/*  475:     */   }
/*  476:     */   
/*  477:     */   static native void nglGetObjectLabel(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/*  478:     */   
/*  479:     */   public static String glGetObjectLabel(int identifier, int name, int bufSize)
/*  480:     */   {
/*  481: 677 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  482: 678 */     long function_pointer = caps.glGetObjectLabel;
/*  483: 679 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  484: 680 */     IntBuffer label_length = APIUtil.getLengths(caps);
/*  485: 681 */     ByteBuffer label = APIUtil.getBufferByte(caps, bufSize);
/*  486: 682 */     nglGetObjectLabel(identifier, name, bufSize, MemoryUtil.getAddress0(label_length), MemoryUtil.getAddress(label), function_pointer);
/*  487: 683 */     label.limit(label_length.get(0));
/*  488: 684 */     return APIUtil.getString(caps, label);
/*  489:     */   }
/*  490:     */   
/*  491:     */   public static void glObjectPtrLabel(PointerWrapper ptr, ByteBuffer label)
/*  492:     */   {
/*  493: 688 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  494: 689 */     long function_pointer = caps.glObjectPtrLabel;
/*  495: 690 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  496: 691 */     if (label != null) {
/*  497: 692 */       BufferChecks.checkDirect(label);
/*  498:     */     }
/*  499: 693 */     nglObjectPtrLabel(ptr.getPointer(), label == null ? 0 : label.remaining(), MemoryUtil.getAddressSafe(label), function_pointer);
/*  500:     */   }
/*  501:     */   
/*  502:     */   static native void nglObjectPtrLabel(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/*  503:     */   
/*  504:     */   public static void glObjectPtrLabel(PointerWrapper ptr, CharSequence label)
/*  505:     */   {
/*  506: 699 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  507: 700 */     long function_pointer = caps.glObjectPtrLabel;
/*  508: 701 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  509: 702 */     nglObjectPtrLabel(ptr.getPointer(), label.length(), APIUtil.getBuffer(caps, label), function_pointer);
/*  510:     */   }
/*  511:     */   
/*  512:     */   public static void glGetObjectPtrLabel(PointerWrapper ptr, IntBuffer length, ByteBuffer label)
/*  513:     */   {
/*  514: 706 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  515: 707 */     long function_pointer = caps.glGetObjectPtrLabel;
/*  516: 708 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  517: 709 */     if (length != null) {
/*  518: 710 */       BufferChecks.checkBuffer(length, 1);
/*  519:     */     }
/*  520: 711 */     BufferChecks.checkDirect(label);
/*  521: 712 */     nglGetObjectPtrLabel(ptr.getPointer(), label.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(label), function_pointer);
/*  522:     */   }
/*  523:     */   
/*  524:     */   static native void nglGetObjectPtrLabel(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/*  525:     */   
/*  526:     */   public static String glGetObjectPtrLabel(PointerWrapper ptr, int bufSize)
/*  527:     */   {
/*  528: 718 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  529: 719 */     long function_pointer = caps.glGetObjectPtrLabel;
/*  530: 720 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  531: 721 */     IntBuffer label_length = APIUtil.getLengths(caps);
/*  532: 722 */     ByteBuffer label = APIUtil.getBufferByte(caps, bufSize);
/*  533: 723 */     nglGetObjectPtrLabel(ptr.getPointer(), bufSize, MemoryUtil.getAddress0(label_length), MemoryUtil.getAddress(label), function_pointer);
/*  534: 724 */     label.limit(label_length.get(0));
/*  535: 725 */     return APIUtil.getString(caps, label);
/*  536:     */   }
/*  537:     */   
/*  538:     */   public static void glFramebufferParameteri(int target, int pname, int param)
/*  539:     */   {
/*  540: 729 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  541: 730 */     long function_pointer = caps.glFramebufferParameteri;
/*  542: 731 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  543: 732 */     nglFramebufferParameteri(target, pname, param, function_pointer);
/*  544:     */   }
/*  545:     */   
/*  546:     */   static native void nglFramebufferParameteri(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  547:     */   
/*  548:     */   public static void glGetFramebufferParameter(int target, int pname, IntBuffer params)
/*  549:     */   {
/*  550: 737 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  551: 738 */     long function_pointer = caps.glGetFramebufferParameteriv;
/*  552: 739 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  553: 740 */     BufferChecks.checkBuffer(params, 1);
/*  554: 741 */     nglGetFramebufferParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  555:     */   }
/*  556:     */   
/*  557:     */   static native void nglGetFramebufferParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  558:     */   
/*  559:     */   public static int glGetFramebufferParameteri(int target, int pname)
/*  560:     */   {
/*  561: 747 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  562: 748 */     long function_pointer = caps.glGetFramebufferParameteriv;
/*  563: 749 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  564: 750 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  565: 751 */     nglGetFramebufferParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  566: 752 */     return params.get(0);
/*  567:     */   }
/*  568:     */   
/*  569:     */   public static void glGetInternalformat(int target, int internalformat, int pname, LongBuffer params)
/*  570:     */   {
/*  571: 756 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  572: 757 */     long function_pointer = caps.glGetInternalformati64v;
/*  573: 758 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  574: 759 */     BufferChecks.checkDirect(params);
/*  575: 760 */     nglGetInternalformati64v(target, internalformat, pname, params.remaining(), MemoryUtil.getAddress(params), function_pointer);
/*  576:     */   }
/*  577:     */   
/*  578:     */   static native void nglGetInternalformati64v(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  579:     */   
/*  580:     */   public static long glGetInternalformati64(int target, int internalformat, int pname)
/*  581:     */   {
/*  582: 766 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  583: 767 */     long function_pointer = caps.glGetInternalformati64v;
/*  584: 768 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  585: 769 */     LongBuffer params = APIUtil.getBufferLong(caps);
/*  586: 770 */     nglGetInternalformati64v(target, internalformat, pname, 1, MemoryUtil.getAddress(params), function_pointer);
/*  587: 771 */     return params.get(0);
/*  588:     */   }
/*  589:     */   
/*  590:     */   public static void glInvalidateTexSubImage(int texture, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth)
/*  591:     */   {
/*  592: 775 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  593: 776 */     long function_pointer = caps.glInvalidateTexSubImage;
/*  594: 777 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  595: 778 */     nglInvalidateTexSubImage(texture, level, xoffset, yoffset, zoffset, width, height, depth, function_pointer);
/*  596:     */   }
/*  597:     */   
/*  598:     */   static native void nglInvalidateTexSubImage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/*  599:     */   
/*  600:     */   public static void glInvalidateTexImage(int texture, int level)
/*  601:     */   {
/*  602: 783 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  603: 784 */     long function_pointer = caps.glInvalidateTexImage;
/*  604: 785 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  605: 786 */     nglInvalidateTexImage(texture, level, function_pointer);
/*  606:     */   }
/*  607:     */   
/*  608:     */   static native void nglInvalidateTexImage(int paramInt1, int paramInt2, long paramLong);
/*  609:     */   
/*  610:     */   public static void glInvalidateBufferSubData(int buffer, long offset, long length)
/*  611:     */   {
/*  612: 791 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  613: 792 */     long function_pointer = caps.glInvalidateBufferSubData;
/*  614: 793 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  615: 794 */     nglInvalidateBufferSubData(buffer, offset, length, function_pointer);
/*  616:     */   }
/*  617:     */   
/*  618:     */   static native void nglInvalidateBufferSubData(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  619:     */   
/*  620:     */   public static void glInvalidateBufferData(int buffer)
/*  621:     */   {
/*  622: 799 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  623: 800 */     long function_pointer = caps.glInvalidateBufferData;
/*  624: 801 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  625: 802 */     nglInvalidateBufferData(buffer, function_pointer);
/*  626:     */   }
/*  627:     */   
/*  628:     */   static native void nglInvalidateBufferData(int paramInt, long paramLong);
/*  629:     */   
/*  630:     */   public static void glInvalidateFramebuffer(int target, IntBuffer attachments)
/*  631:     */   {
/*  632: 807 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  633: 808 */     long function_pointer = caps.glInvalidateFramebuffer;
/*  634: 809 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  635: 810 */     BufferChecks.checkDirect(attachments);
/*  636: 811 */     nglInvalidateFramebuffer(target, attachments.remaining(), MemoryUtil.getAddress(attachments), function_pointer);
/*  637:     */   }
/*  638:     */   
/*  639:     */   static native void nglInvalidateFramebuffer(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  640:     */   
/*  641:     */   public static void glInvalidateSubFramebuffer(int target, IntBuffer attachments, int x, int y, int width, int height)
/*  642:     */   {
/*  643: 816 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  644: 817 */     long function_pointer = caps.glInvalidateSubFramebuffer;
/*  645: 818 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  646: 819 */     BufferChecks.checkDirect(attachments);
/*  647: 820 */     nglInvalidateSubFramebuffer(target, attachments.remaining(), MemoryUtil.getAddress(attachments), x, y, width, height, function_pointer);
/*  648:     */   }
/*  649:     */   
/*  650:     */   static native void nglInvalidateSubFramebuffer(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong2);
/*  651:     */   
/*  652:     */   public static void glMultiDrawArraysIndirect(int mode, ByteBuffer indirect, int primcount, int stride)
/*  653:     */   {
/*  654: 825 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  655: 826 */     long function_pointer = caps.glMultiDrawArraysIndirect;
/*  656: 827 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  657: 828 */     GLChecks.ensureIndirectBOdisabled(caps);
/*  658: 829 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 16 : stride) * primcount);
/*  659: 830 */     nglMultiDrawArraysIndirect(mode, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/*  660:     */   }
/*  661:     */   
/*  662:     */   static native void nglMultiDrawArraysIndirect(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2);
/*  663:     */   
/*  664:     */   public static void glMultiDrawArraysIndirect(int mode, long indirect_buffer_offset, int primcount, int stride)
/*  665:     */   {
/*  666: 834 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  667: 835 */     long function_pointer = caps.glMultiDrawArraysIndirect;
/*  668: 836 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  669: 837 */     GLChecks.ensureIndirectBOenabled(caps);
/*  670: 838 */     nglMultiDrawArraysIndirectBO(mode, indirect_buffer_offset, primcount, stride, function_pointer);
/*  671:     */   }
/*  672:     */   
/*  673:     */   static native void nglMultiDrawArraysIndirectBO(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2);
/*  674:     */   
/*  675:     */   public static void glMultiDrawArraysIndirect(int mode, IntBuffer indirect, int primcount, int stride)
/*  676:     */   {
/*  677: 844 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  678: 845 */     long function_pointer = caps.glMultiDrawArraysIndirect;
/*  679: 846 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  680: 847 */     GLChecks.ensureIndirectBOdisabled(caps);
/*  681: 848 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 4 : stride >> 2) * primcount);
/*  682: 849 */     nglMultiDrawArraysIndirect(mode, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/*  683:     */   }
/*  684:     */   
/*  685:     */   public static void glMultiDrawElementsIndirect(int mode, int type, ByteBuffer indirect, int primcount, int stride)
/*  686:     */   {
/*  687: 853 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  688: 854 */     long function_pointer = caps.glMultiDrawElementsIndirect;
/*  689: 855 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  690: 856 */     GLChecks.ensureIndirectBOdisabled(caps);
/*  691: 857 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 20 : stride) * primcount);
/*  692: 858 */     nglMultiDrawElementsIndirect(mode, type, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/*  693:     */   }
/*  694:     */   
/*  695:     */   static native void nglMultiDrawElementsIndirect(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2);
/*  696:     */   
/*  697:     */   public static void glMultiDrawElementsIndirect(int mode, int type, long indirect_buffer_offset, int primcount, int stride)
/*  698:     */   {
/*  699: 862 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  700: 863 */     long function_pointer = caps.glMultiDrawElementsIndirect;
/*  701: 864 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  702: 865 */     GLChecks.ensureIndirectBOenabled(caps);
/*  703: 866 */     nglMultiDrawElementsIndirectBO(mode, type, indirect_buffer_offset, primcount, stride, function_pointer);
/*  704:     */   }
/*  705:     */   
/*  706:     */   static native void nglMultiDrawElementsIndirectBO(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2);
/*  707:     */   
/*  708:     */   public static void glMultiDrawElementsIndirect(int mode, int type, IntBuffer indirect, int primcount, int stride)
/*  709:     */   {
/*  710: 872 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  711: 873 */     long function_pointer = caps.glMultiDrawElementsIndirect;
/*  712: 874 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  713: 875 */     GLChecks.ensureIndirectBOdisabled(caps);
/*  714: 876 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 5 : stride >> 2) * primcount);
/*  715: 877 */     nglMultiDrawElementsIndirect(mode, type, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/*  716:     */   }
/*  717:     */   
/*  718:     */   public static void glGetProgramInterface(int program, int programInterface, int pname, IntBuffer params)
/*  719:     */   {
/*  720: 881 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  721: 882 */     long function_pointer = caps.glGetProgramInterfaceiv;
/*  722: 883 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  723: 884 */     BufferChecks.checkBuffer(params, 1);
/*  724: 885 */     nglGetProgramInterfaceiv(program, programInterface, pname, MemoryUtil.getAddress(params), function_pointer);
/*  725:     */   }
/*  726:     */   
/*  727:     */   static native void nglGetProgramInterfaceiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  728:     */   
/*  729:     */   public static int glGetProgramInterfacei(int program, int programInterface, int pname)
/*  730:     */   {
/*  731: 891 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  732: 892 */     long function_pointer = caps.glGetProgramInterfaceiv;
/*  733: 893 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  734: 894 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  735: 895 */     nglGetProgramInterfaceiv(program, programInterface, pname, MemoryUtil.getAddress(params), function_pointer);
/*  736: 896 */     return params.get(0);
/*  737:     */   }
/*  738:     */   
/*  739:     */   public static int glGetProgramResourceIndex(int program, int programInterface, ByteBuffer name)
/*  740:     */   {
/*  741: 900 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  742: 901 */     long function_pointer = caps.glGetProgramResourceIndex;
/*  743: 902 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  744: 903 */     BufferChecks.checkDirect(name);
/*  745: 904 */     BufferChecks.checkNullTerminated(name);
/*  746: 905 */     int __result = nglGetProgramResourceIndex(program, programInterface, MemoryUtil.getAddress(name), function_pointer);
/*  747: 906 */     return __result;
/*  748:     */   }
/*  749:     */   
/*  750:     */   static native int nglGetProgramResourceIndex(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  751:     */   
/*  752:     */   public static int glGetProgramResourceIndex(int program, int programInterface, CharSequence name)
/*  753:     */   {
/*  754: 912 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  755: 913 */     long function_pointer = caps.glGetProgramResourceIndex;
/*  756: 914 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  757: 915 */     int __result = nglGetProgramResourceIndex(program, programInterface, APIUtil.getBufferNT(caps, name), function_pointer);
/*  758: 916 */     return __result;
/*  759:     */   }
/*  760:     */   
/*  761:     */   public static void glGetProgramResourceName(int program, int programInterface, int index, IntBuffer length, ByteBuffer name)
/*  762:     */   {
/*  763: 920 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  764: 921 */     long function_pointer = caps.glGetProgramResourceName;
/*  765: 922 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  766: 923 */     if (length != null) {
/*  767: 924 */       BufferChecks.checkBuffer(length, 1);
/*  768:     */     }
/*  769: 925 */     if (name != null) {
/*  770: 926 */       BufferChecks.checkDirect(name);
/*  771:     */     }
/*  772: 927 */     nglGetProgramResourceName(program, programInterface, index, name == null ? 0 : name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddressSafe(name), function_pointer);
/*  773:     */   }
/*  774:     */   
/*  775:     */   static native void nglGetProgramResourceName(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2, long paramLong3);
/*  776:     */   
/*  777:     */   public static String glGetProgramResourceName(int program, int programInterface, int index, int bufSize)
/*  778:     */   {
/*  779: 933 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  780: 934 */     long function_pointer = caps.glGetProgramResourceName;
/*  781: 935 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  782: 936 */     IntBuffer name_length = APIUtil.getLengths(caps);
/*  783: 937 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufSize);
/*  784: 938 */     nglGetProgramResourceName(program, programInterface, index, bufSize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(name), function_pointer);
/*  785: 939 */     name.limit(name_length.get(0));
/*  786: 940 */     return APIUtil.getString(caps, name);
/*  787:     */   }
/*  788:     */   
/*  789:     */   public static void glGetProgramResource(int program, int programInterface, int index, IntBuffer props, IntBuffer length, IntBuffer params)
/*  790:     */   {
/*  791: 944 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  792: 945 */     long function_pointer = caps.glGetProgramResourceiv;
/*  793: 946 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  794: 947 */     BufferChecks.checkDirect(props);
/*  795: 948 */     if (length != null) {
/*  796: 949 */       BufferChecks.checkBuffer(length, 1);
/*  797:     */     }
/*  798: 950 */     BufferChecks.checkDirect(params);
/*  799: 951 */     nglGetProgramResourceiv(program, programInterface, index, props.remaining(), MemoryUtil.getAddress(props), params.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(params), function_pointer);
/*  800:     */   }
/*  801:     */   
/*  802:     */   static native void nglGetProgramResourceiv(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, int paramInt5, long paramLong2, long paramLong3, long paramLong4);
/*  803:     */   
/*  804:     */   public static int glGetProgramResourceLocation(int program, int programInterface, ByteBuffer name)
/*  805:     */   {
/*  806: 956 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  807: 957 */     long function_pointer = caps.glGetProgramResourceLocation;
/*  808: 958 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  809: 959 */     BufferChecks.checkDirect(name);
/*  810: 960 */     BufferChecks.checkNullTerminated(name);
/*  811: 961 */     int __result = nglGetProgramResourceLocation(program, programInterface, MemoryUtil.getAddress(name), function_pointer);
/*  812: 962 */     return __result;
/*  813:     */   }
/*  814:     */   
/*  815:     */   static native int nglGetProgramResourceLocation(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  816:     */   
/*  817:     */   public static int glGetProgramResourceLocation(int program, int programInterface, CharSequence name)
/*  818:     */   {
/*  819: 968 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  820: 969 */     long function_pointer = caps.glGetProgramResourceLocation;
/*  821: 970 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  822: 971 */     int __result = nglGetProgramResourceLocation(program, programInterface, APIUtil.getBufferNT(caps, name), function_pointer);
/*  823: 972 */     return __result;
/*  824:     */   }
/*  825:     */   
/*  826:     */   public static int glGetProgramResourceLocationIndex(int program, int programInterface, ByteBuffer name)
/*  827:     */   {
/*  828: 976 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  829: 977 */     long function_pointer = caps.glGetProgramResourceLocationIndex;
/*  830: 978 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  831: 979 */     BufferChecks.checkDirect(name);
/*  832: 980 */     BufferChecks.checkNullTerminated(name);
/*  833: 981 */     int __result = nglGetProgramResourceLocationIndex(program, programInterface, MemoryUtil.getAddress(name), function_pointer);
/*  834: 982 */     return __result;
/*  835:     */   }
/*  836:     */   
/*  837:     */   static native int nglGetProgramResourceLocationIndex(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  838:     */   
/*  839:     */   public static int glGetProgramResourceLocationIndex(int program, int programInterface, CharSequence name)
/*  840:     */   {
/*  841: 988 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  842: 989 */     long function_pointer = caps.glGetProgramResourceLocationIndex;
/*  843: 990 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  844: 991 */     int __result = nglGetProgramResourceLocationIndex(program, programInterface, APIUtil.getBufferNT(caps, name), function_pointer);
/*  845: 992 */     return __result;
/*  846:     */   }
/*  847:     */   
/*  848:     */   public static void glShaderStorageBlockBinding(int program, int storageBlockIndex, int storageBlockBinding)
/*  849:     */   {
/*  850: 996 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  851: 997 */     long function_pointer = caps.glShaderStorageBlockBinding;
/*  852: 998 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  853: 999 */     nglShaderStorageBlockBinding(program, storageBlockIndex, storageBlockBinding, function_pointer);
/*  854:     */   }
/*  855:     */   
/*  856:     */   static native void nglShaderStorageBlockBinding(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  857:     */   
/*  858:     */   public static void glTexBufferRange(int target, int internalformat, int buffer, long offset, long size)
/*  859:     */   {
/*  860:1004 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  861:1005 */     long function_pointer = caps.glTexBufferRange;
/*  862:1006 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  863:1007 */     nglTexBufferRange(target, internalformat, buffer, offset, size, function_pointer);
/*  864:     */   }
/*  865:     */   
/*  866:     */   static native void nglTexBufferRange(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/*  867:     */   
/*  868:     */   public static void glTexStorage2DMultisample(int target, int samples, int internalformat, int width, int height, boolean fixedsamplelocations)
/*  869:     */   {
/*  870:1012 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  871:1013 */     long function_pointer = caps.glTexStorage2DMultisample;
/*  872:1014 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  873:1015 */     nglTexStorage2DMultisample(target, samples, internalformat, width, height, fixedsamplelocations, function_pointer);
/*  874:     */   }
/*  875:     */   
/*  876:     */   static native void nglTexStorage2DMultisample(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, long paramLong);
/*  877:     */   
/*  878:     */   public static void glTexStorage3DMultisample(int target, int samples, int internalformat, int width, int height, int depth, boolean fixedsamplelocations)
/*  879:     */   {
/*  880:1020 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  881:1021 */     long function_pointer = caps.glTexStorage3DMultisample;
/*  882:1022 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  883:1023 */     nglTexStorage3DMultisample(target, samples, internalformat, width, height, depth, fixedsamplelocations, function_pointer);
/*  884:     */   }
/*  885:     */   
/*  886:     */   static native void nglTexStorage3DMultisample(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, long paramLong);
/*  887:     */   
/*  888:     */   public static void glTextureView(int texture, int target, int origtexture, int internalformat, int minlevel, int numlevels, int minlayer, int numlayers)
/*  889:     */   {
/*  890:1028 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  891:1029 */     long function_pointer = caps.glTextureView;
/*  892:1030 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  893:1031 */     nglTextureView(texture, target, origtexture, internalformat, minlevel, numlevels, minlayer, numlayers, function_pointer);
/*  894:     */   }
/*  895:     */   
/*  896:     */   static native void nglTextureView(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/*  897:     */   
/*  898:     */   public static void glBindVertexBuffer(int bindingindex, int buffer, long offset, int stride)
/*  899:     */   {
/*  900:1036 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  901:1037 */     long function_pointer = caps.glBindVertexBuffer;
/*  902:1038 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  903:1039 */     nglBindVertexBuffer(bindingindex, buffer, offset, stride, function_pointer);
/*  904:     */   }
/*  905:     */   
/*  906:     */   static native void nglBindVertexBuffer(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  907:     */   
/*  908:     */   public static void glVertexAttribFormat(int attribindex, int size, int type, boolean normalized, int relativeoffset)
/*  909:     */   {
/*  910:1044 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  911:1045 */     long function_pointer = caps.glVertexAttribFormat;
/*  912:1046 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  913:1047 */     nglVertexAttribFormat(attribindex, size, type, normalized, relativeoffset, function_pointer);
/*  914:     */   }
/*  915:     */   
/*  916:     */   static native void nglVertexAttribFormat(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong);
/*  917:     */   
/*  918:     */   public static void glVertexAttribIFormat(int attribindex, int size, int type, int relativeoffset)
/*  919:     */   {
/*  920:1052 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  921:1053 */     long function_pointer = caps.glVertexAttribIFormat;
/*  922:1054 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  923:1055 */     nglVertexAttribIFormat(attribindex, size, type, relativeoffset, function_pointer);
/*  924:     */   }
/*  925:     */   
/*  926:     */   static native void nglVertexAttribIFormat(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  927:     */   
/*  928:     */   public static void glVertexAttribLFormat(int attribindex, int size, int type, int relativeoffset)
/*  929:     */   {
/*  930:1060 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  931:1061 */     long function_pointer = caps.glVertexAttribLFormat;
/*  932:1062 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  933:1063 */     nglVertexAttribLFormat(attribindex, size, type, relativeoffset, function_pointer);
/*  934:     */   }
/*  935:     */   
/*  936:     */   static native void nglVertexAttribLFormat(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  937:     */   
/*  938:     */   public static void glVertexAttribBinding(int attribindex, int bindingindex)
/*  939:     */   {
/*  940:1068 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  941:1069 */     long function_pointer = caps.glVertexAttribBinding;
/*  942:1070 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  943:1071 */     nglVertexAttribBinding(attribindex, bindingindex, function_pointer);
/*  944:     */   }
/*  945:     */   
/*  946:     */   static native void nglVertexAttribBinding(int paramInt1, int paramInt2, long paramLong);
/*  947:     */   
/*  948:     */   public static void glVertexBindingDivisor(int bindingindex, int divisor)
/*  949:     */   {
/*  950:1076 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  951:1077 */     long function_pointer = caps.glVertexBindingDivisor;
/*  952:1078 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  953:1079 */     nglVertexBindingDivisor(bindingindex, divisor, function_pointer);
/*  954:     */   }
/*  955:     */   
/*  956:     */   static native void nglVertexBindingDivisor(int paramInt1, int paramInt2, long paramLong);
/*  957:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL43
 * JD-Core Version:    0.7.0.1
 */