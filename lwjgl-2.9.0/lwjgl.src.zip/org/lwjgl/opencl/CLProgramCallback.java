/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerWrapperAbstract;
/*  4:   */ 
/*  5:   */ abstract class CLProgramCallback
/*  6:   */   extends PointerWrapperAbstract
/*  7:   */ {
/*  8:   */   private CLContext context;
/*  9:   */   
/* 10:   */   protected CLProgramCallback()
/* 11:   */   {
/* 12:46 */     super(CallbackUtil.getProgramCallback());
/* 13:   */   }
/* 14:   */   
/* 15:   */   final void setContext(CLContext context)
/* 16:   */   {
/* 17:55 */     this.context = context;
/* 18:   */   }
/* 19:   */   
/* 20:   */   private void handleMessage(long program_address)
/* 21:   */   {
/* 22:64 */     handleMessage(this.context.getCLProgram(program_address));
/* 23:   */   }
/* 24:   */   
/* 25:   */   protected abstract void handleMessage(CLProgram paramCLProgram);
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLProgramCallback
 * JD-Core Version:    0.7.0.1
 */