package org.lwjgl.opengl;

public final class ARBTextureEnvDot3
{
  public static final int GL_DOT3_RGB_ARB = 34478;
  public static final int GL_DOT3_RGBA_ARB = 34479;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureEnvDot3
 * JD-Core Version:    0.7.0.1
 */