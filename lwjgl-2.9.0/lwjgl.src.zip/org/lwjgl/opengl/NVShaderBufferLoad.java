/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.LongBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVShaderBufferLoad
/*   8:    */ {
/*   9:    */   public static final int GL_BUFFER_GPU_ADDRESS_NV = 36637;
/*  10:    */   public static final int GL_GPU_ADDRESS_NV = 36660;
/*  11:    */   public static final int GL_MAX_SHADER_BUFFER_ADDRESS_NV = 36661;
/*  12:    */   
/*  13:    */   public static void glMakeBufferResidentNV(int target, int access)
/*  14:    */   {
/*  15: 29 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  16: 30 */     long function_pointer = caps.glMakeBufferResidentNV;
/*  17: 31 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  18: 32 */     nglMakeBufferResidentNV(target, access, function_pointer);
/*  19:    */   }
/*  20:    */   
/*  21:    */   static native void nglMakeBufferResidentNV(int paramInt1, int paramInt2, long paramLong);
/*  22:    */   
/*  23:    */   public static void glMakeBufferNonResidentNV(int target)
/*  24:    */   {
/*  25: 37 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  26: 38 */     long function_pointer = caps.glMakeBufferNonResidentNV;
/*  27: 39 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  28: 40 */     nglMakeBufferNonResidentNV(target, function_pointer);
/*  29:    */   }
/*  30:    */   
/*  31:    */   static native void nglMakeBufferNonResidentNV(int paramInt, long paramLong);
/*  32:    */   
/*  33:    */   public static boolean glIsBufferResidentNV(int target)
/*  34:    */   {
/*  35: 45 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 46 */     long function_pointer = caps.glIsBufferResidentNV;
/*  37: 47 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 48 */     boolean __result = nglIsBufferResidentNV(target, function_pointer);
/*  39: 49 */     return __result;
/*  40:    */   }
/*  41:    */   
/*  42:    */   static native boolean nglIsBufferResidentNV(int paramInt, long paramLong);
/*  43:    */   
/*  44:    */   public static void glMakeNamedBufferResidentNV(int buffer, int access)
/*  45:    */   {
/*  46: 54 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  47: 55 */     long function_pointer = caps.glMakeNamedBufferResidentNV;
/*  48: 56 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  49: 57 */     nglMakeNamedBufferResidentNV(buffer, access, function_pointer);
/*  50:    */   }
/*  51:    */   
/*  52:    */   static native void nglMakeNamedBufferResidentNV(int paramInt1, int paramInt2, long paramLong);
/*  53:    */   
/*  54:    */   public static void glMakeNamedBufferNonResidentNV(int buffer)
/*  55:    */   {
/*  56: 62 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  57: 63 */     long function_pointer = caps.glMakeNamedBufferNonResidentNV;
/*  58: 64 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  59: 65 */     nglMakeNamedBufferNonResidentNV(buffer, function_pointer);
/*  60:    */   }
/*  61:    */   
/*  62:    */   static native void nglMakeNamedBufferNonResidentNV(int paramInt, long paramLong);
/*  63:    */   
/*  64:    */   public static boolean glIsNamedBufferResidentNV(int buffer)
/*  65:    */   {
/*  66: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  67: 71 */     long function_pointer = caps.glIsNamedBufferResidentNV;
/*  68: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  69: 73 */     boolean __result = nglIsNamedBufferResidentNV(buffer, function_pointer);
/*  70: 74 */     return __result;
/*  71:    */   }
/*  72:    */   
/*  73:    */   static native boolean nglIsNamedBufferResidentNV(int paramInt, long paramLong);
/*  74:    */   
/*  75:    */   public static void glGetBufferParameteruNV(int target, int pname, LongBuffer params)
/*  76:    */   {
/*  77: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  78: 80 */     long function_pointer = caps.glGetBufferParameterui64vNV;
/*  79: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  80: 82 */     BufferChecks.checkBuffer(params, 1);
/*  81: 83 */     nglGetBufferParameterui64vNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  82:    */   }
/*  83:    */   
/*  84:    */   static native void nglGetBufferParameterui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  85:    */   
/*  86:    */   public static long glGetBufferParameterui64NV(int target, int pname)
/*  87:    */   {
/*  88: 89 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  89: 90 */     long function_pointer = caps.glGetBufferParameterui64vNV;
/*  90: 91 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  91: 92 */     LongBuffer params = APIUtil.getBufferLong(caps);
/*  92: 93 */     nglGetBufferParameterui64vNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  93: 94 */     return params.get(0);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static void glGetNamedBufferParameteruNV(int buffer, int pname, LongBuffer params)
/*  97:    */   {
/*  98: 98 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  99: 99 */     long function_pointer = caps.glGetNamedBufferParameterui64vNV;
/* 100:100 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101:101 */     BufferChecks.checkBuffer(params, 1);
/* 102:102 */     nglGetNamedBufferParameterui64vNV(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 103:    */   }
/* 104:    */   
/* 105:    */   static native void nglGetNamedBufferParameterui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 106:    */   
/* 107:    */   public static long glGetNamedBufferParameterui64NV(int buffer, int pname)
/* 108:    */   {
/* 109:108 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110:109 */     long function_pointer = caps.glGetNamedBufferParameterui64vNV;
/* 111:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:111 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 113:112 */     nglGetNamedBufferParameterui64vNV(buffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 114:113 */     return params.get(0);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static void glGetIntegeruNV(int value, LongBuffer result)
/* 118:    */   {
/* 119:117 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 120:118 */     long function_pointer = caps.glGetIntegerui64vNV;
/* 121:119 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 122:120 */     BufferChecks.checkBuffer(result, 1);
/* 123:121 */     nglGetIntegerui64vNV(value, MemoryUtil.getAddress(result), function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglGetIntegerui64vNV(int paramInt, long paramLong1, long paramLong2);
/* 127:    */   
/* 128:    */   public static long glGetIntegerui64NV(int value)
/* 129:    */   {
/* 130:127 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:128 */     long function_pointer = caps.glGetIntegerui64vNV;
/* 132:129 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:130 */     LongBuffer result = APIUtil.getBufferLong(caps);
/* 134:131 */     nglGetIntegerui64vNV(value, MemoryUtil.getAddress(result), function_pointer);
/* 135:132 */     return result.get(0);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static void glUniformui64NV(int location, long value)
/* 139:    */   {
/* 140:136 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 141:137 */     long function_pointer = caps.glUniformui64NV;
/* 142:138 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 143:139 */     nglUniformui64NV(location, value, function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   static native void nglUniformui64NV(int paramInt, long paramLong1, long paramLong2);
/* 147:    */   
/* 148:    */   public static void glUniformuNV(int location, LongBuffer value)
/* 149:    */   {
/* 150:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 151:145 */     long function_pointer = caps.glUniformui64vNV;
/* 152:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 153:147 */     BufferChecks.checkDirect(value);
/* 154:148 */     nglUniformui64vNV(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 155:    */   }
/* 156:    */   
/* 157:    */   static native void nglUniformui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 158:    */   
/* 159:    */   public static void glGetUniformuNV(int program, int location, LongBuffer params)
/* 160:    */   {
/* 161:153 */     NVGpuShader5.glGetUniformuNV(program, location, params);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static void glProgramUniformui64NV(int program, int location, long value)
/* 165:    */   {
/* 166:157 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 167:158 */     long function_pointer = caps.glProgramUniformui64NV;
/* 168:159 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 169:160 */     nglProgramUniformui64NV(program, location, value, function_pointer);
/* 170:    */   }
/* 171:    */   
/* 172:    */   static native void nglProgramUniformui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 173:    */   
/* 174:    */   public static void glProgramUniformuNV(int program, int location, LongBuffer value)
/* 175:    */   {
/* 176:165 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 177:166 */     long function_pointer = caps.glProgramUniformui64vNV;
/* 178:167 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 179:168 */     BufferChecks.checkDirect(value);
/* 180:169 */     nglProgramUniformui64vNV(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 181:    */   }
/* 182:    */   
/* 183:    */   static native void nglProgramUniformui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 184:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVShaderBufferLoad
 * JD-Core Version:    0.7.0.1
 */