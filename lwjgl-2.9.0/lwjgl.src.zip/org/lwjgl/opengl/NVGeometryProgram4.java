/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVGeometryProgram4
/*  6:   */ {
/*  7:   */   public static final int GL_GEOMETRY_PROGRAM_NV = 35878;
/*  8:   */   public static final int GL_MAX_PROGRAM_OUTPUT_VERTICES_NV = 35879;
/*  9:   */   public static final int GL_MAX_PROGRAM_TOTAL_OUTPUT_COMPONENTS_NV = 35880;
/* 10:   */   
/* 11:   */   public static void glProgramVertexLimitNV(int target, int limit)
/* 12:   */   {
/* 13:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:27 */     long function_pointer = caps.glProgramVertexLimitNV;
/* 15:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:29 */     nglProgramVertexLimitNV(target, limit, function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nglProgramVertexLimitNV(int paramInt1, int paramInt2, long paramLong);
/* 20:   */   
/* 21:   */   public static void glFramebufferTextureEXT(int target, int attachment, int texture, int level)
/* 22:   */   {
/* 23:34 */     EXTGeometryShader4.glFramebufferTextureEXT(target, attachment, texture, level);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public static void glFramebufferTextureLayerEXT(int target, int attachment, int texture, int level, int layer)
/* 27:   */   {
/* 28:38 */     EXTGeometryShader4.glFramebufferTextureLayerEXT(target, attachment, texture, level, layer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void glFramebufferTextureFaceEXT(int target, int attachment, int texture, int level, int face)
/* 32:   */   {
/* 33:42 */     EXTGeometryShader4.glFramebufferTextureFaceEXT(target, attachment, texture, level, face);
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVGeometryProgram4
 * JD-Core Version:    0.7.0.1
 */