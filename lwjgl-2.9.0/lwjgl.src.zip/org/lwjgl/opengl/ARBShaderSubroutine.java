/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ 
/*   6:    */ public final class ARBShaderSubroutine
/*   7:    */ {
/*   8:    */   public static final int GL_ACTIVE_SUBROUTINES = 36325;
/*   9:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORMS = 36326;
/*  10:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS = 36423;
/*  11:    */   public static final int GL_ACTIVE_SUBROUTINE_MAX_LENGTH = 36424;
/*  12:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH = 36425;
/*  13:    */   public static final int GL_MAX_SUBROUTINES = 36327;
/*  14:    */   public static final int GL_MAX_SUBROUTINE_UNIFORM_LOCATIONS = 36328;
/*  15:    */   public static final int GL_NUM_COMPATIBLE_SUBROUTINES = 36426;
/*  16:    */   public static final int GL_COMPATIBLE_SUBROUTINES = 36427;
/*  17:    */   public static final int GL_UNIFORM_SIZE = 35384;
/*  18:    */   public static final int GL_UNIFORM_NAME_LENGTH = 35385;
/*  19:    */   
/*  20:    */   public static int glGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name)
/*  21:    */   {
/*  22: 37 */     return GL40.glGetSubroutineUniformLocation(program, shadertype, name);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static int glGetSubroutineUniformLocation(int program, int shadertype, CharSequence name)
/*  26:    */   {
/*  27: 42 */     return GL40.glGetSubroutineUniformLocation(program, shadertype, name);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static int glGetSubroutineIndex(int program, int shadertype, ByteBuffer name)
/*  31:    */   {
/*  32: 46 */     return GL40.glGetSubroutineIndex(program, shadertype, name);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static int glGetSubroutineIndex(int program, int shadertype, CharSequence name)
/*  36:    */   {
/*  37: 51 */     return GL40.glGetSubroutineIndex(program, shadertype, name);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname, IntBuffer values)
/*  41:    */   {
/*  42: 55 */     GL40.glGetActiveSubroutineUniform(program, shadertype, index, pname, values);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static int glGetActiveSubroutineUniformi(int program, int shadertype, int index, int pname)
/*  46:    */   {
/*  47: 60 */     return GL40.glGetActiveSubroutineUniformi(program, shadertype, index, pname);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void glGetActiveSubroutineUniformName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name)
/*  51:    */   {
/*  52: 64 */     GL40.glGetActiveSubroutineUniformName(program, shadertype, index, length, name);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static String glGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize)
/*  56:    */   {
/*  57: 69 */     return GL40.glGetActiveSubroutineUniformName(program, shadertype, index, bufsize);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void glGetActiveSubroutineName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name)
/*  61:    */   {
/*  62: 73 */     GL40.glGetActiveSubroutineName(program, shadertype, index, length, name);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static String glGetActiveSubroutineName(int program, int shadertype, int index, int bufsize)
/*  66:    */   {
/*  67: 78 */     return GL40.glGetActiveSubroutineName(program, shadertype, index, bufsize);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static void glUniformSubroutinesu(int shadertype, IntBuffer indices)
/*  71:    */   {
/*  72: 82 */     GL40.glUniformSubroutinesu(shadertype, indices);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void glGetUniformSubroutineu(int shadertype, int location, IntBuffer params)
/*  76:    */   {
/*  77: 86 */     GL40.glGetUniformSubroutineu(shadertype, location, params);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static int glGetUniformSubroutineui(int shadertype, int location)
/*  81:    */   {
/*  82: 91 */     return GL40.glGetUniformSubroutineui(shadertype, location);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void glGetProgramStage(int program, int shadertype, int pname, IntBuffer values)
/*  86:    */   {
/*  87: 95 */     GL40.glGetProgramStage(program, shadertype, pname, values);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static int glGetProgramStagei(int program, int shadertype, int pname)
/*  91:    */   {
/*  92:100 */     return GL40.glGetProgramStagei(program, shadertype, pname);
/*  93:    */   }
/*  94:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShaderSubroutine
 * JD-Core Version:    0.7.0.1
 */