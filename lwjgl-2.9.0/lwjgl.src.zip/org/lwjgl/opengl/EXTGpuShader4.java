/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.nio.ShortBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.LWJGLUtil;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public final class EXTGpuShader4
/*  11:    */ {
/*  12:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_INTEGER_EXT = 35069;
/*  13:    */   public static final int GL_SAMPLER_1D_ARRAY_EXT = 36288;
/*  14:    */   public static final int GL_SAMPLER_2D_ARRAY_EXT = 36289;
/*  15:    */   public static final int GL_SAMPLER_BUFFER_EXT = 36290;
/*  16:    */   public static final int GL_SAMPLER_1D_ARRAY_SHADOW_EXT = 36291;
/*  17:    */   public static final int GL_SAMPLER_2D_ARRAY_SHADOW_EXT = 36292;
/*  18:    */   public static final int GL_SAMPLER_CUBE_SHADOW_EXT = 36293;
/*  19:    */   public static final int GL_UNSIGNED_INT_VEC2_EXT = 36294;
/*  20:    */   public static final int GL_UNSIGNED_INT_VEC3_EXT = 36295;
/*  21:    */   public static final int GL_UNSIGNED_INT_VEC4_EXT = 36296;
/*  22:    */   public static final int GL_INT_SAMPLER_1D_EXT = 36297;
/*  23:    */   public static final int GL_INT_SAMPLER_2D_EXT = 36298;
/*  24:    */   public static final int GL_INT_SAMPLER_3D_EXT = 36299;
/*  25:    */   public static final int GL_INT_SAMPLER_CUBE_EXT = 36300;
/*  26:    */   public static final int GL_INT_SAMPLER_2D_RECT_EXT = 36301;
/*  27:    */   public static final int GL_INT_SAMPLER_1D_ARRAY_EXT = 36302;
/*  28:    */   public static final int GL_INT_SAMPLER_2D_ARRAY_EXT = 36303;
/*  29:    */   public static final int GL_INT_SAMPLER_BUFFER_EXT = 36304;
/*  30:    */   public static final int GL_UNSIGNED_INT_SAMPLER_1D_EXT = 36305;
/*  31:    */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_EXT = 36306;
/*  32:    */   public static final int GL_UNSIGNED_INT_SAMPLER_3D_EXT = 36307;
/*  33:    */   public static final int GL_UNSIGNED_INT_SAMPLER_CUBE_EXT = 36308;
/*  34:    */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_RECT_EXT = 36309;
/*  35:    */   public static final int GL_UNSIGNED_INT_SAMPLER_1D_ARRAY_EXT = 36310;
/*  36:    */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_ARRAY_EXT = 36311;
/*  37:    */   public static final int GL_UNSIGNED_INT_SAMPLER_BUFFER_EXT = 36312;
/*  38:    */   public static final int GL_MIN_PROGRAM_TEXEL_OFFSET_EXT = 35076;
/*  39:    */   public static final int GL_MAX_PROGRAM_TEXEL_OFFSET_EXT = 35077;
/*  40:    */   
/*  41:    */   public static void glVertexAttribI1iEXT(int index, int x)
/*  42:    */   {
/*  43: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  44: 57 */     long function_pointer = caps.glVertexAttribI1iEXT;
/*  45: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  46: 59 */     nglVertexAttribI1iEXT(index, x, function_pointer);
/*  47:    */   }
/*  48:    */   
/*  49:    */   static native void nglVertexAttribI1iEXT(int paramInt1, int paramInt2, long paramLong);
/*  50:    */   
/*  51:    */   public static void glVertexAttribI2iEXT(int index, int x, int y)
/*  52:    */   {
/*  53: 64 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  54: 65 */     long function_pointer = caps.glVertexAttribI2iEXT;
/*  55: 66 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  56: 67 */     nglVertexAttribI2iEXT(index, x, y, function_pointer);
/*  57:    */   }
/*  58:    */   
/*  59:    */   static native void nglVertexAttribI2iEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  60:    */   
/*  61:    */   public static void glVertexAttribI3iEXT(int index, int x, int y, int z)
/*  62:    */   {
/*  63: 72 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  64: 73 */     long function_pointer = caps.glVertexAttribI3iEXT;
/*  65: 74 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  66: 75 */     nglVertexAttribI3iEXT(index, x, y, z, function_pointer);
/*  67:    */   }
/*  68:    */   
/*  69:    */   static native void nglVertexAttribI3iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  70:    */   
/*  71:    */   public static void glVertexAttribI4iEXT(int index, int x, int y, int z, int w)
/*  72:    */   {
/*  73: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  74: 81 */     long function_pointer = caps.glVertexAttribI4iEXT;
/*  75: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  76: 83 */     nglVertexAttribI4iEXT(index, x, y, z, w, function_pointer);
/*  77:    */   }
/*  78:    */   
/*  79:    */   static native void nglVertexAttribI4iEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  80:    */   
/*  81:    */   public static void glVertexAttribI1uiEXT(int index, int x)
/*  82:    */   {
/*  83: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  84: 89 */     long function_pointer = caps.glVertexAttribI1uiEXT;
/*  85: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  86: 91 */     nglVertexAttribI1uiEXT(index, x, function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglVertexAttribI1uiEXT(int paramInt1, int paramInt2, long paramLong);
/*  90:    */   
/*  91:    */   public static void glVertexAttribI2uiEXT(int index, int x, int y)
/*  92:    */   {
/*  93: 96 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  94: 97 */     long function_pointer = caps.glVertexAttribI2uiEXT;
/*  95: 98 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  96: 99 */     nglVertexAttribI2uiEXT(index, x, y, function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglVertexAttribI2uiEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 100:    */   
/* 101:    */   public static void glVertexAttribI3uiEXT(int index, int x, int y, int z)
/* 102:    */   {
/* 103:104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104:105 */     long function_pointer = caps.glVertexAttribI3uiEXT;
/* 105:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106:107 */     nglVertexAttribI3uiEXT(index, x, y, z, function_pointer);
/* 107:    */   }
/* 108:    */   
/* 109:    */   static native void nglVertexAttribI3uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 110:    */   
/* 111:    */   public static void glVertexAttribI4uiEXT(int index, int x, int y, int z, int w)
/* 112:    */   {
/* 113:112 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 114:113 */     long function_pointer = caps.glVertexAttribI4uiEXT;
/* 115:114 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 116:115 */     nglVertexAttribI4uiEXT(index, x, y, z, w, function_pointer);
/* 117:    */   }
/* 118:    */   
/* 119:    */   static native void nglVertexAttribI4uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 120:    */   
/* 121:    */   public static void glVertexAttribI1EXT(int index, IntBuffer v)
/* 122:    */   {
/* 123:120 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 124:121 */     long function_pointer = caps.glVertexAttribI1ivEXT;
/* 125:122 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:123 */     BufferChecks.checkBuffer(v, 1);
/* 127:124 */     nglVertexAttribI1ivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   static native void nglVertexAttribI1ivEXT(int paramInt, long paramLong1, long paramLong2);
/* 131:    */   
/* 132:    */   public static void glVertexAttribI2EXT(int index, IntBuffer v)
/* 133:    */   {
/* 134:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 135:130 */     long function_pointer = caps.glVertexAttribI2ivEXT;
/* 136:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 137:132 */     BufferChecks.checkBuffer(v, 2);
/* 138:133 */     nglVertexAttribI2ivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglVertexAttribI2ivEXT(int paramInt, long paramLong1, long paramLong2);
/* 142:    */   
/* 143:    */   public static void glVertexAttribI3EXT(int index, IntBuffer v)
/* 144:    */   {
/* 145:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 146:139 */     long function_pointer = caps.glVertexAttribI3ivEXT;
/* 147:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 148:141 */     BufferChecks.checkBuffer(v, 3);
/* 149:142 */     nglVertexAttribI3ivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 150:    */   }
/* 151:    */   
/* 152:    */   static native void nglVertexAttribI3ivEXT(int paramInt, long paramLong1, long paramLong2);
/* 153:    */   
/* 154:    */   public static void glVertexAttribI4EXT(int index, IntBuffer v)
/* 155:    */   {
/* 156:147 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 157:148 */     long function_pointer = caps.glVertexAttribI4ivEXT;
/* 158:149 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 159:150 */     BufferChecks.checkBuffer(v, 4);
/* 160:151 */     nglVertexAttribI4ivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 161:    */   }
/* 162:    */   
/* 163:    */   static native void nglVertexAttribI4ivEXT(int paramInt, long paramLong1, long paramLong2);
/* 164:    */   
/* 165:    */   public static void glVertexAttribI1uEXT(int index, IntBuffer v)
/* 166:    */   {
/* 167:156 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 168:157 */     long function_pointer = caps.glVertexAttribI1uivEXT;
/* 169:158 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 170:159 */     BufferChecks.checkBuffer(v, 1);
/* 171:160 */     nglVertexAttribI1uivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 172:    */   }
/* 173:    */   
/* 174:    */   static native void nglVertexAttribI1uivEXT(int paramInt, long paramLong1, long paramLong2);
/* 175:    */   
/* 176:    */   public static void glVertexAttribI2uEXT(int index, IntBuffer v)
/* 177:    */   {
/* 178:165 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 179:166 */     long function_pointer = caps.glVertexAttribI2uivEXT;
/* 180:167 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 181:168 */     BufferChecks.checkBuffer(v, 2);
/* 182:169 */     nglVertexAttribI2uivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 183:    */   }
/* 184:    */   
/* 185:    */   static native void nglVertexAttribI2uivEXT(int paramInt, long paramLong1, long paramLong2);
/* 186:    */   
/* 187:    */   public static void glVertexAttribI3uEXT(int index, IntBuffer v)
/* 188:    */   {
/* 189:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 190:175 */     long function_pointer = caps.glVertexAttribI3uivEXT;
/* 191:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 192:177 */     BufferChecks.checkBuffer(v, 3);
/* 193:178 */     nglVertexAttribI3uivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 194:    */   }
/* 195:    */   
/* 196:    */   static native void nglVertexAttribI3uivEXT(int paramInt, long paramLong1, long paramLong2);
/* 197:    */   
/* 198:    */   public static void glVertexAttribI4uEXT(int index, IntBuffer v)
/* 199:    */   {
/* 200:183 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 201:184 */     long function_pointer = caps.glVertexAttribI4uivEXT;
/* 202:185 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 203:186 */     BufferChecks.checkBuffer(v, 4);
/* 204:187 */     nglVertexAttribI4uivEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 205:    */   }
/* 206:    */   
/* 207:    */   static native void nglVertexAttribI4uivEXT(int paramInt, long paramLong1, long paramLong2);
/* 208:    */   
/* 209:    */   public static void glVertexAttribI4EXT(int index, ByteBuffer v)
/* 210:    */   {
/* 211:192 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 212:193 */     long function_pointer = caps.glVertexAttribI4bvEXT;
/* 213:194 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 214:195 */     BufferChecks.checkBuffer(v, 4);
/* 215:196 */     nglVertexAttribI4bvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 216:    */   }
/* 217:    */   
/* 218:    */   static native void nglVertexAttribI4bvEXT(int paramInt, long paramLong1, long paramLong2);
/* 219:    */   
/* 220:    */   public static void glVertexAttribI4EXT(int index, ShortBuffer v)
/* 221:    */   {
/* 222:201 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 223:202 */     long function_pointer = caps.glVertexAttribI4svEXT;
/* 224:203 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 225:204 */     BufferChecks.checkBuffer(v, 4);
/* 226:205 */     nglVertexAttribI4svEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 227:    */   }
/* 228:    */   
/* 229:    */   static native void nglVertexAttribI4svEXT(int paramInt, long paramLong1, long paramLong2);
/* 230:    */   
/* 231:    */   public static void glVertexAttribI4uEXT(int index, ByteBuffer v)
/* 232:    */   {
/* 233:210 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 234:211 */     long function_pointer = caps.glVertexAttribI4ubvEXT;
/* 235:212 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 236:213 */     BufferChecks.checkBuffer(v, 4);
/* 237:214 */     nglVertexAttribI4ubvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 238:    */   }
/* 239:    */   
/* 240:    */   static native void nglVertexAttribI4ubvEXT(int paramInt, long paramLong1, long paramLong2);
/* 241:    */   
/* 242:    */   public static void glVertexAttribI4uEXT(int index, ShortBuffer v)
/* 243:    */   {
/* 244:219 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 245:220 */     long function_pointer = caps.glVertexAttribI4usvEXT;
/* 246:221 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 247:222 */     BufferChecks.checkBuffer(v, 4);
/* 248:223 */     nglVertexAttribI4usvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 249:    */   }
/* 250:    */   
/* 251:    */   static native void nglVertexAttribI4usvEXT(int paramInt, long paramLong1, long paramLong2);
/* 252:    */   
/* 253:    */   public static void glVertexAttribIPointerEXT(int index, int size, int type, int stride, ByteBuffer buffer)
/* 254:    */   {
/* 255:228 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 256:229 */     long function_pointer = caps.glVertexAttribIPointerEXT;
/* 257:230 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 258:231 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 259:232 */     BufferChecks.checkDirect(buffer);
/* 260:233 */     if (LWJGLUtil.CHECKS) {
/* 261:233 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 262:    */     }
/* 263:234 */     nglVertexAttribIPointerEXT(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static void glVertexAttribIPointerEXT(int index, int size, int type, int stride, IntBuffer buffer)
/* 267:    */   {
/* 268:237 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 269:238 */     long function_pointer = caps.glVertexAttribIPointerEXT;
/* 270:239 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 271:240 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 272:241 */     BufferChecks.checkDirect(buffer);
/* 273:242 */     if (LWJGLUtil.CHECKS) {
/* 274:242 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 275:    */     }
/* 276:243 */     nglVertexAttribIPointerEXT(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 277:    */   }
/* 278:    */   
/* 279:    */   public static void glVertexAttribIPointerEXT(int index, int size, int type, int stride, ShortBuffer buffer)
/* 280:    */   {
/* 281:246 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 282:247 */     long function_pointer = caps.glVertexAttribIPointerEXT;
/* 283:248 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 284:249 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 285:250 */     BufferChecks.checkDirect(buffer);
/* 286:251 */     if (LWJGLUtil.CHECKS) {
/* 287:251 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 288:    */     }
/* 289:252 */     nglVertexAttribIPointerEXT(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 290:    */   }
/* 291:    */   
/* 292:    */   static native void nglVertexAttribIPointerEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 293:    */   
/* 294:    */   public static void glVertexAttribIPointerEXT(int index, int size, int type, int stride, long buffer_buffer_offset)
/* 295:    */   {
/* 296:256 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 297:257 */     long function_pointer = caps.glVertexAttribIPointerEXT;
/* 298:258 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 299:259 */     GLChecks.ensureArrayVBOenabled(caps);
/* 300:260 */     nglVertexAttribIPointerEXTBO(index, size, type, stride, buffer_buffer_offset, function_pointer);
/* 301:    */   }
/* 302:    */   
/* 303:    */   static native void nglVertexAttribIPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 304:    */   
/* 305:    */   public static void glGetVertexAttribIEXT(int index, int pname, IntBuffer params)
/* 306:    */   {
/* 307:265 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 308:266 */     long function_pointer = caps.glGetVertexAttribIivEXT;
/* 309:267 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 310:268 */     BufferChecks.checkBuffer(params, 4);
/* 311:269 */     nglGetVertexAttribIivEXT(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 312:    */   }
/* 313:    */   
/* 314:    */   static native void nglGetVertexAttribIivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 315:    */   
/* 316:    */   public static void glGetVertexAttribIuEXT(int index, int pname, IntBuffer params)
/* 317:    */   {
/* 318:274 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 319:275 */     long function_pointer = caps.glGetVertexAttribIuivEXT;
/* 320:276 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 321:277 */     BufferChecks.checkBuffer(params, 4);
/* 322:278 */     nglGetVertexAttribIuivEXT(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 323:    */   }
/* 324:    */   
/* 325:    */   static native void nglGetVertexAttribIuivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 326:    */   
/* 327:    */   public static void glUniform1uiEXT(int location, int v0)
/* 328:    */   {
/* 329:283 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 330:284 */     long function_pointer = caps.glUniform1uiEXT;
/* 331:285 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 332:286 */     nglUniform1uiEXT(location, v0, function_pointer);
/* 333:    */   }
/* 334:    */   
/* 335:    */   static native void nglUniform1uiEXT(int paramInt1, int paramInt2, long paramLong);
/* 336:    */   
/* 337:    */   public static void glUniform2uiEXT(int location, int v0, int v1)
/* 338:    */   {
/* 339:291 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 340:292 */     long function_pointer = caps.glUniform2uiEXT;
/* 341:293 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 342:294 */     nglUniform2uiEXT(location, v0, v1, function_pointer);
/* 343:    */   }
/* 344:    */   
/* 345:    */   static native void nglUniform2uiEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 346:    */   
/* 347:    */   public static void glUniform3uiEXT(int location, int v0, int v1, int v2)
/* 348:    */   {
/* 349:299 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 350:300 */     long function_pointer = caps.glUniform3uiEXT;
/* 351:301 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 352:302 */     nglUniform3uiEXT(location, v0, v1, v2, function_pointer);
/* 353:    */   }
/* 354:    */   
/* 355:    */   static native void nglUniform3uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 356:    */   
/* 357:    */   public static void glUniform4uiEXT(int location, int v0, int v1, int v2, int v3)
/* 358:    */   {
/* 359:307 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 360:308 */     long function_pointer = caps.glUniform4uiEXT;
/* 361:309 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 362:310 */     nglUniform4uiEXT(location, v0, v1, v2, v3, function_pointer);
/* 363:    */   }
/* 364:    */   
/* 365:    */   static native void nglUniform4uiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 366:    */   
/* 367:    */   public static void glUniform1uEXT(int location, IntBuffer value)
/* 368:    */   {
/* 369:315 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 370:316 */     long function_pointer = caps.glUniform1uivEXT;
/* 371:317 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 372:318 */     BufferChecks.checkDirect(value);
/* 373:319 */     nglUniform1uivEXT(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 374:    */   }
/* 375:    */   
/* 376:    */   static native void nglUniform1uivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 377:    */   
/* 378:    */   public static void glUniform2uEXT(int location, IntBuffer value)
/* 379:    */   {
/* 380:324 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 381:325 */     long function_pointer = caps.glUniform2uivEXT;
/* 382:326 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 383:327 */     BufferChecks.checkDirect(value);
/* 384:328 */     nglUniform2uivEXT(location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 385:    */   }
/* 386:    */   
/* 387:    */   static native void nglUniform2uivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 388:    */   
/* 389:    */   public static void glUniform3uEXT(int location, IntBuffer value)
/* 390:    */   {
/* 391:333 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 392:334 */     long function_pointer = caps.glUniform3uivEXT;
/* 393:335 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 394:336 */     BufferChecks.checkDirect(value);
/* 395:337 */     nglUniform3uivEXT(location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 396:    */   }
/* 397:    */   
/* 398:    */   static native void nglUniform3uivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 399:    */   
/* 400:    */   public static void glUniform4uEXT(int location, IntBuffer value)
/* 401:    */   {
/* 402:342 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 403:343 */     long function_pointer = caps.glUniform4uivEXT;
/* 404:344 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 405:345 */     BufferChecks.checkDirect(value);
/* 406:346 */     nglUniform4uivEXT(location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 407:    */   }
/* 408:    */   
/* 409:    */   static native void nglUniform4uivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 410:    */   
/* 411:    */   public static void glGetUniformuEXT(int program, int location, IntBuffer params)
/* 412:    */   {
/* 413:351 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 414:352 */     long function_pointer = caps.glGetUniformuivEXT;
/* 415:353 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 416:354 */     BufferChecks.checkDirect(params);
/* 417:355 */     nglGetUniformuivEXT(program, location, MemoryUtil.getAddress(params), function_pointer);
/* 418:    */   }
/* 419:    */   
/* 420:    */   static native void nglGetUniformuivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 421:    */   
/* 422:    */   public static void glBindFragDataLocationEXT(int program, int colorNumber, ByteBuffer name)
/* 423:    */   {
/* 424:360 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 425:361 */     long function_pointer = caps.glBindFragDataLocationEXT;
/* 426:362 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 427:363 */     BufferChecks.checkDirect(name);
/* 428:364 */     BufferChecks.checkNullTerminated(name);
/* 429:365 */     nglBindFragDataLocationEXT(program, colorNumber, MemoryUtil.getAddress(name), function_pointer);
/* 430:    */   }
/* 431:    */   
/* 432:    */   static native void nglBindFragDataLocationEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 433:    */   
/* 434:    */   public static void glBindFragDataLocationEXT(int program, int colorNumber, CharSequence name)
/* 435:    */   {
/* 436:371 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 437:372 */     long function_pointer = caps.glBindFragDataLocationEXT;
/* 438:373 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 439:374 */     nglBindFragDataLocationEXT(program, colorNumber, APIUtil.getBufferNT(caps, name), function_pointer);
/* 440:    */   }
/* 441:    */   
/* 442:    */   public static int glGetFragDataLocationEXT(int program, ByteBuffer name)
/* 443:    */   {
/* 444:378 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 445:379 */     long function_pointer = caps.glGetFragDataLocationEXT;
/* 446:380 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 447:381 */     BufferChecks.checkDirect(name);
/* 448:382 */     BufferChecks.checkNullTerminated(name);
/* 449:383 */     int __result = nglGetFragDataLocationEXT(program, MemoryUtil.getAddress(name), function_pointer);
/* 450:384 */     return __result;
/* 451:    */   }
/* 452:    */   
/* 453:    */   static native int nglGetFragDataLocationEXT(int paramInt, long paramLong1, long paramLong2);
/* 454:    */   
/* 455:    */   public static int glGetFragDataLocationEXT(int program, CharSequence name)
/* 456:    */   {
/* 457:390 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 458:391 */     long function_pointer = caps.glGetFragDataLocationEXT;
/* 459:392 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 460:393 */     int __result = nglGetFragDataLocationEXT(program, APIUtil.getBufferNT(caps, name), function_pointer);
/* 461:394 */     return __result;
/* 462:    */   }
/* 463:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTGpuShader4
 * JD-Core Version:    0.7.0.1
 */