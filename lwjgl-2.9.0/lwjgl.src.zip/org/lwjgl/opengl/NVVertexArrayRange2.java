package org.lwjgl.opengl;

public final class NVVertexArrayRange2
{
  public static final int GL_VERTEX_ARRAY_RANGE_WITHOUT_FLUSH_NV = 34099;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexArrayRange2
 * JD-Core Version:    0.7.0.1
 */