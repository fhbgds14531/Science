/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class ARBShadingLanguageInclude
/*   9:    */ {
/*  10:    */   public static final int GL_SHADER_INCLUDE_ARB = 36270;
/*  11:    */   public static final int GL_NAMED_STRING_LENGTH_ARB = 36329;
/*  12:    */   public static final int GL_NAMED_STRING_TYPE_ARB = 36330;
/*  13:    */   
/*  14:    */   public static void glNamedStringARB(int type, ByteBuffer name, ByteBuffer string)
/*  15:    */   {
/*  16: 24 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  17: 25 */     long function_pointer = caps.glNamedStringARB;
/*  18: 26 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  19: 27 */     BufferChecks.checkDirect(name);
/*  20: 28 */     BufferChecks.checkDirect(string);
/*  21: 29 */     nglNamedStringARB(type, name.remaining(), MemoryUtil.getAddress(name), string.remaining(), MemoryUtil.getAddress(string), function_pointer);
/*  22:    */   }
/*  23:    */   
/*  24:    */   static native void nglNamedStringARB(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2, long paramLong3);
/*  25:    */   
/*  26:    */   public static void glNamedStringARB(int type, CharSequence name, CharSequence string)
/*  27:    */   {
/*  28: 35 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  29: 36 */     long function_pointer = caps.glNamedStringARB;
/*  30: 37 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  31: 38 */     nglNamedStringARB(type, name.length(), APIUtil.getBuffer(caps, name), string.length(), APIUtil.getBuffer(caps, string, name.length()), function_pointer);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static void glDeleteNamedStringARB(ByteBuffer name)
/*  35:    */   {
/*  36: 42 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  37: 43 */     long function_pointer = caps.glDeleteNamedStringARB;
/*  38: 44 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  39: 45 */     BufferChecks.checkDirect(name);
/*  40: 46 */     nglDeleteNamedStringARB(name.remaining(), MemoryUtil.getAddress(name), function_pointer);
/*  41:    */   }
/*  42:    */   
/*  43:    */   static native void nglDeleteNamedStringARB(int paramInt, long paramLong1, long paramLong2);
/*  44:    */   
/*  45:    */   public static void glDeleteNamedStringARB(CharSequence name)
/*  46:    */   {
/*  47: 52 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  48: 53 */     long function_pointer = caps.glDeleteNamedStringARB;
/*  49: 54 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  50: 55 */     nglDeleteNamedStringARB(name.length(), APIUtil.getBuffer(caps, name), function_pointer);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static void glCompileShaderIncludeARB(int shader, int count, ByteBuffer path)
/*  54:    */   {
/*  55: 59 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  56: 60 */     long function_pointer = caps.glCompileShaderIncludeARB;
/*  57: 61 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  58: 62 */     BufferChecks.checkDirect(path);
/*  59: 63 */     BufferChecks.checkNullTerminated(path, count);
/*  60: 64 */     nglCompileShaderIncludeARB(shader, count, MemoryUtil.getAddress(path), 0L, function_pointer);
/*  61:    */   }
/*  62:    */   
/*  63:    */   static native void nglCompileShaderIncludeARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  64:    */   
/*  65:    */   public static void glCompileShaderIncludeARB(int shader, CharSequence[] path)
/*  66:    */   {
/*  67: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  68: 71 */     long function_pointer = caps.glCompileShaderIncludeARB;
/*  69: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  70: 73 */     BufferChecks.checkArray(path);
/*  71: 74 */     nglCompileShaderIncludeARB2(shader, path.length, APIUtil.getBuffer(caps, path), APIUtil.getLengths(caps, path), function_pointer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static native void nglCompileShaderIncludeARB2(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  75:    */   
/*  76:    */   public static boolean glIsNamedStringARB(ByteBuffer name)
/*  77:    */   {
/*  78: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79: 80 */     long function_pointer = caps.glIsNamedStringARB;
/*  80: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81: 82 */     BufferChecks.checkDirect(name);
/*  82: 83 */     boolean __result = nglIsNamedStringARB(name.remaining(), MemoryUtil.getAddress(name), function_pointer);
/*  83: 84 */     return __result;
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native boolean nglIsNamedStringARB(int paramInt, long paramLong1, long paramLong2);
/*  87:    */   
/*  88:    */   public static boolean glIsNamedStringARB(CharSequence name)
/*  89:    */   {
/*  90: 90 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91: 91 */     long function_pointer = caps.glIsNamedStringARB;
/*  92: 92 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93: 93 */     boolean __result = nglIsNamedStringARB(name.length(), APIUtil.getBuffer(caps, name), function_pointer);
/*  94: 94 */     return __result;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void glGetNamedStringARB(ByteBuffer name, IntBuffer stringlen, ByteBuffer string)
/*  98:    */   {
/*  99: 98 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 100: 99 */     long function_pointer = caps.glGetNamedStringARB;
/* 101:100 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 102:101 */     BufferChecks.checkDirect(name);
/* 103:102 */     if (stringlen != null) {
/* 104:103 */       BufferChecks.checkBuffer(stringlen, 1);
/* 105:    */     }
/* 106:104 */     BufferChecks.checkDirect(string);
/* 107:105 */     nglGetNamedStringARB(name.remaining(), MemoryUtil.getAddress(name), string.remaining(), MemoryUtil.getAddressSafe(stringlen), MemoryUtil.getAddress(string), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglGetNamedStringARB(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3, long paramLong4);
/* 111:    */   
/* 112:    */   public static void glGetNamedStringARB(CharSequence name, IntBuffer stringlen, ByteBuffer string)
/* 113:    */   {
/* 114:111 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:112 */     long function_pointer = caps.glGetNamedStringARB;
/* 116:113 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:114 */     if (stringlen != null) {
/* 118:115 */       BufferChecks.checkBuffer(stringlen, 1);
/* 119:    */     }
/* 120:116 */     BufferChecks.checkDirect(string);
/* 121:117 */     nglGetNamedStringARB(name.length(), APIUtil.getBuffer(caps, name), string.remaining(), MemoryUtil.getAddressSafe(stringlen), MemoryUtil.getAddress(string), function_pointer);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static String glGetNamedStringARB(CharSequence name, int bufSize)
/* 125:    */   {
/* 126:122 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:123 */     long function_pointer = caps.glGetNamedStringARB;
/* 128:124 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:125 */     IntBuffer string_length = APIUtil.getLengths(caps);
/* 130:126 */     ByteBuffer string = APIUtil.getBufferByte(caps, bufSize + name.length());
/* 131:127 */     nglGetNamedStringARB(name.length(), APIUtil.getBuffer(caps, name), bufSize, MemoryUtil.getAddress0(string_length), MemoryUtil.getAddress(string), function_pointer);
/* 132:128 */     string.limit(name.length() + string_length.get(0));
/* 133:129 */     return APIUtil.getString(caps, string);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static void glGetNamedStringARB(ByteBuffer name, int pname, IntBuffer params)
/* 137:    */   {
/* 138:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:134 */     long function_pointer = caps.glGetNamedStringivARB;
/* 140:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:136 */     BufferChecks.checkDirect(name);
/* 142:137 */     BufferChecks.checkBuffer(params, 1);
/* 143:138 */     nglGetNamedStringivARB(name.remaining(), MemoryUtil.getAddress(name), pname, MemoryUtil.getAddress(params), function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   static native void nglGetNamedStringivARB(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3);
/* 147:    */   
/* 148:    */   public static void glGetNamedStringiARB(CharSequence name, int pname, IntBuffer params)
/* 149:    */   {
/* 150:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 151:145 */     long function_pointer = caps.glGetNamedStringivARB;
/* 152:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 153:147 */     BufferChecks.checkBuffer(params, 1);
/* 154:148 */     nglGetNamedStringivARB(name.length(), APIUtil.getBuffer(caps, name), pname, MemoryUtil.getAddress(params), function_pointer);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static int glGetNamedStringiARB(CharSequence name, int pname)
/* 158:    */   {
/* 159:153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 160:154 */     long function_pointer = caps.glGetNamedStringivARB;
/* 161:155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 162:156 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 163:157 */     nglGetNamedStringivARB(name.length(), APIUtil.getBuffer(caps, name), pname, MemoryUtil.getAddress(params), function_pointer);
/* 164:158 */     return params.get(0);
/* 165:    */   }
/* 166:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShadingLanguageInclude
 * JD-Core Version:    0.7.0.1
 */