/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.LWJGLException;
/*  4:   */ import org.lwjgl.Sys;
/*  5:   */ 
/*  6:   */ final class WindowsRegistry
/*  7:   */ {
/*  8:   */   static final int HKEY_CLASSES_ROOT = 1;
/*  9:   */   static final int HKEY_CURRENT_USER = 2;
/* 10:   */   static final int HKEY_LOCAL_MACHINE = 3;
/* 11:   */   static final int HKEY_USERS = 4;
/* 12:   */   
/* 13:   */   static String queryRegistrationKey(int root_key, String subkey, String value)
/* 14:   */     throws LWJGLException
/* 15:   */   {
/* 16:56 */     switch (root_key)
/* 17:   */     {
/* 18:   */     case 1: 
/* 19:   */     case 2: 
/* 20:   */     case 3: 
/* 21:   */     case 4: 
/* 22:   */       break;
/* 23:   */     default: 
/* 24:63 */       throw new IllegalArgumentException("Invalid enum: " + root_key);
/* 25:   */     }
/* 26:65 */     return nQueryRegistrationKey(root_key, subkey, value);
/* 27:   */   }
/* 28:   */   
/* 29:   */   private static native String nQueryRegistrationKey(int paramInt, String paramString1, String paramString2)
/* 30:   */     throws LWJGLException;
/* 31:   */   
/* 32:   */   static {}
/* 33:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsRegistry
 * JD-Core Version:    0.7.0.1
 */