/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.util.HashSet;
/*    4:     */ import java.util.Set;
/*    5:     */ import org.lwjgl.LWJGLException;
/*    6:     */ import org.lwjgl.LWJGLUtil;
/*    7:     */ 
/*    8:     */ public class ContextCapabilities
/*    9:     */ {
/*   10:     */   static final boolean DEBUG = false;
/*   11:  12 */   final APIUtil util = new APIUtil();
/*   12:  13 */   final StateTracker tracker = new StateTracker();
/*   13:     */   public final boolean GL_AMD_blend_minmax_factor;
/*   14:     */   public final boolean GL_AMD_conservative_depth;
/*   15:     */   public final boolean GL_AMD_debug_output;
/*   16:     */   public final boolean GL_AMD_depth_clamp_separate;
/*   17:     */   public final boolean GL_AMD_draw_buffers_blend;
/*   18:     */   public final boolean GL_AMD_multi_draw_indirect;
/*   19:     */   public final boolean GL_AMD_name_gen_delete;
/*   20:     */   public final boolean GL_AMD_performance_monitor;
/*   21:     */   public final boolean GL_AMD_pinned_memory;
/*   22:     */   public final boolean GL_AMD_query_buffer_object;
/*   23:     */   public final boolean GL_AMD_sample_positions;
/*   24:     */   public final boolean GL_AMD_seamless_cubemap_per_texture;
/*   25:     */   public final boolean GL_AMD_shader_stencil_export;
/*   26:     */   public final boolean GL_AMD_shader_trinary_minmax;
/*   27:     */   public final boolean GL_AMD_sparse_texture;
/*   28:     */   public final boolean GL_AMD_stencil_operation_extended;
/*   29:     */   public final boolean GL_AMD_texture_texture4;
/*   30:     */   public final boolean GL_AMD_transform_feedback3_lines_triangles;
/*   31:     */   public final boolean GL_AMD_vertex_shader_layer;
/*   32:     */   public final boolean GL_AMD_vertex_shader_tessellator;
/*   33:     */   public final boolean GL_AMD_vertex_shader_viewport_index;
/*   34:     */   public final boolean GL_APPLE_aux_depth_stencil;
/*   35:     */   public final boolean GL_APPLE_client_storage;
/*   36:     */   public final boolean GL_APPLE_element_array;
/*   37:     */   public final boolean GL_APPLE_fence;
/*   38:     */   public final boolean GL_APPLE_float_pixels;
/*   39:     */   public final boolean GL_APPLE_flush_buffer_range;
/*   40:     */   public final boolean GL_APPLE_object_purgeable;
/*   41:     */   public final boolean GL_APPLE_packed_pixels;
/*   42:     */   public final boolean GL_APPLE_rgb_422;
/*   43:     */   public final boolean GL_APPLE_row_bytes;
/*   44:     */   public final boolean GL_APPLE_texture_range;
/*   45:     */   public final boolean GL_APPLE_vertex_array_object;
/*   46:     */   public final boolean GL_APPLE_vertex_array_range;
/*   47:     */   public final boolean GL_APPLE_vertex_program_evaluators;
/*   48:     */   public final boolean GL_APPLE_ycbcr_422;
/*   49:     */   public final boolean GL_ARB_ES2_compatibility;
/*   50:     */   public final boolean GL_ARB_ES3_compatibility;
/*   51:     */   public final boolean GL_ARB_arrays_of_arrays;
/*   52:     */   public final boolean GL_ARB_base_instance;
/*   53:     */   public final boolean GL_ARB_blend_func_extended;
/*   54:     */   public final boolean GL_ARB_cl_event;
/*   55:     */   public final boolean GL_ARB_clear_buffer_object;
/*   56:     */   public final boolean GL_ARB_color_buffer_float;
/*   57:     */   public final boolean GL_ARB_compatibility;
/*   58:     */   public final boolean GL_ARB_compressed_texture_pixel_storage;
/*   59:     */   public final boolean GL_ARB_compute_shader;
/*   60:     */   public final boolean GL_ARB_conservative_depth;
/*   61:     */   public final boolean GL_ARB_copy_buffer;
/*   62:     */   public final boolean GL_ARB_copy_image;
/*   63:     */   public final boolean GL_ARB_debug_output;
/*   64:     */   public final boolean GL_ARB_depth_buffer_float;
/*   65:     */   public final boolean GL_ARB_depth_clamp;
/*   66:     */   public final boolean GL_ARB_depth_texture;
/*   67:     */   public final boolean GL_ARB_draw_buffers;
/*   68:     */   public final boolean GL_ARB_draw_buffers_blend;
/*   69:     */   public final boolean GL_ARB_draw_elements_base_vertex;
/*   70:     */   public final boolean GL_ARB_draw_indirect;
/*   71:     */   public final boolean GL_ARB_draw_instanced;
/*   72:     */   public final boolean GL_ARB_explicit_attrib_location;
/*   73:     */   public final boolean GL_ARB_explicit_uniform_location;
/*   74:     */   public final boolean GL_ARB_fragment_coord_conventions;
/*   75:     */   public final boolean GL_ARB_fragment_layer_viewport;
/*   76:     */   public final boolean GL_ARB_fragment_program;
/*   77:     */   public final boolean GL_ARB_fragment_program_shadow;
/*   78:     */   public final boolean GL_ARB_fragment_shader;
/*   79:     */   public final boolean GL_ARB_framebuffer_no_attachments;
/*   80:     */   public final boolean GL_ARB_framebuffer_object;
/*   81:     */   public final boolean GL_ARB_framebuffer_sRGB;
/*   82:     */   public final boolean GL_ARB_geometry_shader4;
/*   83:     */   public final boolean GL_ARB_get_program_binary;
/*   84:     */   public final boolean GL_ARB_gpu_shader5;
/*   85:     */   public final boolean GL_ARB_gpu_shader_fp64;
/*   86:     */   public final boolean GL_ARB_half_float_pixel;
/*   87:     */   public final boolean GL_ARB_half_float_vertex;
/*   88:     */   public final boolean GL_ARB_imaging;
/*   89:     */   public final boolean GL_ARB_instanced_arrays;
/*   90:     */   public final boolean GL_ARB_internalformat_query;
/*   91:     */   public final boolean GL_ARB_internalformat_query2;
/*   92:     */   public final boolean GL_ARB_invalidate_subdata;
/*   93:     */   public final boolean GL_ARB_map_buffer_alignment;
/*   94:     */   public final boolean GL_ARB_map_buffer_range;
/*   95:     */   public final boolean GL_ARB_matrix_palette;
/*   96:     */   public final boolean GL_ARB_multi_draw_indirect;
/*   97:     */   public final boolean GL_ARB_multisample;
/*   98:     */   public final boolean GL_ARB_multitexture;
/*   99:     */   public final boolean GL_ARB_occlusion_query;
/*  100:     */   public final boolean GL_ARB_occlusion_query2;
/*  101:     */   public final boolean GL_ARB_pixel_buffer_object;
/*  102:     */   public final boolean GL_ARB_point_parameters;
/*  103:     */   public final boolean GL_ARB_point_sprite;
/*  104:     */   public final boolean GL_ARB_program_interface_query;
/*  105:     */   public final boolean GL_ARB_provoking_vertex;
/*  106:     */   public final boolean GL_ARB_robust_buffer_access_behavior;
/*  107:     */   public final boolean GL_ARB_robustness;
/*  108:     */   public final boolean GL_ARB_robustness_isolation;
/*  109:     */   public final boolean GL_ARB_sample_shading;
/*  110:     */   public final boolean GL_ARB_sampler_objects;
/*  111:     */   public final boolean GL_ARB_seamless_cube_map;
/*  112:     */   public final boolean GL_ARB_separate_shader_objects;
/*  113:     */   public final boolean GL_ARB_shader_atomic_counters;
/*  114:     */   public final boolean GL_ARB_shader_bit_encoding;
/*  115:     */   public final boolean GL_ARB_shader_image_load_store;
/*  116:     */   public final boolean GL_ARB_shader_image_size;
/*  117:     */   public final boolean GL_ARB_shader_objects;
/*  118:     */   public final boolean GL_ARB_shader_precision;
/*  119:     */   public final boolean GL_ARB_shader_stencil_export;
/*  120:     */   public final boolean GL_ARB_shader_storage_buffer_object;
/*  121:     */   public final boolean GL_ARB_shader_subroutine;
/*  122:     */   public final boolean GL_ARB_shader_texture_lod;
/*  123:     */   public final boolean GL_ARB_shading_language_100;
/*  124:     */   public final boolean GL_ARB_shading_language_420pack;
/*  125:     */   public final boolean GL_ARB_shading_language_include;
/*  126:     */   public final boolean GL_ARB_shading_language_packing;
/*  127:     */   public final boolean GL_ARB_shadow;
/*  128:     */   public final boolean GL_ARB_shadow_ambient;
/*  129:     */   public final boolean GL_ARB_stencil_texturing;
/*  130:     */   public final boolean GL_ARB_sync;
/*  131:     */   public final boolean GL_ARB_tessellation_shader;
/*  132:     */   public final boolean GL_ARB_texture_border_clamp;
/*  133:     */   public final boolean GL_ARB_texture_buffer_object;
/*  134:     */   public final boolean GL_ARB_texture_buffer_object_rgb32;
/*  135:     */   public final boolean GL_ARB_texture_buffer_range;
/*  136:     */   public final boolean GL_ARB_texture_compression;
/*  137:     */   public final boolean GL_ARB_texture_compression_bptc;
/*  138:     */   public final boolean GL_ARB_texture_compression_rgtc;
/*  139:     */   public final boolean GL_ARB_texture_cube_map;
/*  140:     */   public final boolean GL_ARB_texture_cube_map_array;
/*  141:     */   public final boolean GL_ARB_texture_env_add;
/*  142:     */   public final boolean GL_ARB_texture_env_combine;
/*  143:     */   public final boolean GL_ARB_texture_env_crossbar;
/*  144:     */   public final boolean GL_ARB_texture_env_dot3;
/*  145:     */   public final boolean GL_ARB_texture_float;
/*  146:     */   public final boolean GL_ARB_texture_gather;
/*  147:     */   public final boolean GL_ARB_texture_mirrored_repeat;
/*  148:     */   public final boolean GL_ARB_texture_multisample;
/*  149:     */   public final boolean GL_ARB_texture_non_power_of_two;
/*  150:     */   public final boolean GL_ARB_texture_query_levels;
/*  151:     */   public final boolean GL_ARB_texture_query_lod;
/*  152:     */   public final boolean GL_ARB_texture_rectangle;
/*  153:     */   public final boolean GL_ARB_texture_rg;
/*  154:     */   public final boolean GL_ARB_texture_rgb10_a2ui;
/*  155:     */   public final boolean GL_ARB_texture_storage;
/*  156:     */   public final boolean GL_ARB_texture_storage_multisample;
/*  157:     */   public final boolean GL_ARB_texture_swizzle;
/*  158:     */   public final boolean GL_ARB_texture_view;
/*  159:     */   public final boolean GL_ARB_timer_query;
/*  160:     */   public final boolean GL_ARB_transform_feedback2;
/*  161:     */   public final boolean GL_ARB_transform_feedback3;
/*  162:     */   public final boolean GL_ARB_transform_feedback_instanced;
/*  163:     */   public final boolean GL_ARB_transpose_matrix;
/*  164:     */   public final boolean GL_ARB_uniform_buffer_object;
/*  165:     */   public final boolean GL_ARB_vertex_array_bgra;
/*  166:     */   public final boolean GL_ARB_vertex_array_object;
/*  167:     */   public final boolean GL_ARB_vertex_attrib_64bit;
/*  168:     */   public final boolean GL_ARB_vertex_attrib_binding;
/*  169:     */   public final boolean GL_ARB_vertex_blend;
/*  170:     */   public final boolean GL_ARB_vertex_buffer_object;
/*  171:     */   public final boolean GL_ARB_vertex_program;
/*  172:     */   public final boolean GL_ARB_vertex_shader;
/*  173:     */   public final boolean GL_ARB_vertex_type_2_10_10_10_rev;
/*  174:     */   public final boolean GL_ARB_viewport_array;
/*  175:     */   public final boolean GL_ARB_window_pos;
/*  176:     */   public final boolean GL_ATI_draw_buffers;
/*  177:     */   public final boolean GL_ATI_element_array;
/*  178:     */   public final boolean GL_ATI_envmap_bumpmap;
/*  179:     */   public final boolean GL_ATI_fragment_shader;
/*  180:     */   public final boolean GL_ATI_map_object_buffer;
/*  181:     */   public final boolean GL_ATI_meminfo;
/*  182:     */   public final boolean GL_ATI_pn_triangles;
/*  183:     */   public final boolean GL_ATI_separate_stencil;
/*  184:     */   public final boolean GL_ATI_shader_texture_lod;
/*  185:     */   public final boolean GL_ATI_text_fragment_shader;
/*  186:     */   public final boolean GL_ATI_texture_compression_3dc;
/*  187:     */   public final boolean GL_ATI_texture_env_combine3;
/*  188:     */   public final boolean GL_ATI_texture_float;
/*  189:     */   public final boolean GL_ATI_texture_mirror_once;
/*  190:     */   public final boolean GL_ATI_vertex_array_object;
/*  191:     */   public final boolean GL_ATI_vertex_attrib_array_object;
/*  192:     */   public final boolean GL_ATI_vertex_streams;
/*  193:     */   public final boolean GL_EXT_abgr;
/*  194:     */   public final boolean GL_EXT_bgra;
/*  195:     */   public final boolean GL_EXT_bindable_uniform;
/*  196:     */   public final boolean GL_EXT_blend_color;
/*  197:     */   public final boolean GL_EXT_blend_equation_separate;
/*  198:     */   public final boolean GL_EXT_blend_func_separate;
/*  199:     */   public final boolean GL_EXT_blend_minmax;
/*  200:     */   public final boolean GL_EXT_blend_subtract;
/*  201:     */   public final boolean GL_EXT_Cg_shader;
/*  202:     */   public final boolean GL_EXT_compiled_vertex_array;
/*  203:     */   public final boolean GL_EXT_depth_bounds_test;
/*  204:     */   public final boolean GL_EXT_direct_state_access;
/*  205:     */   public final boolean GL_EXT_draw_buffers2;
/*  206:     */   public final boolean GL_EXT_draw_instanced;
/*  207:     */   public final boolean GL_EXT_draw_range_elements;
/*  208:     */   public final boolean GL_EXT_fog_coord;
/*  209:     */   public final boolean GL_EXT_framebuffer_blit;
/*  210:     */   public final boolean GL_EXT_framebuffer_multisample;
/*  211:     */   public final boolean GL_EXT_framebuffer_multisample_blit_scaled;
/*  212:     */   public final boolean GL_EXT_framebuffer_object;
/*  213:     */   public final boolean GL_EXT_framebuffer_sRGB;
/*  214:     */   public final boolean GL_EXT_geometry_shader4;
/*  215:     */   public final boolean GL_EXT_gpu_program_parameters;
/*  216:     */   public final boolean GL_EXT_gpu_shader4;
/*  217:     */   public final boolean GL_EXT_multi_draw_arrays;
/*  218:     */   public final boolean GL_EXT_packed_depth_stencil;
/*  219:     */   public final boolean GL_EXT_packed_float;
/*  220:     */   public final boolean GL_EXT_packed_pixels;
/*  221:     */   public final boolean GL_EXT_paletted_texture;
/*  222:     */   public final boolean GL_EXT_pixel_buffer_object;
/*  223:     */   public final boolean GL_EXT_point_parameters;
/*  224:     */   public final boolean GL_EXT_provoking_vertex;
/*  225:     */   public final boolean GL_EXT_rescale_normal;
/*  226:     */   public final boolean GL_EXT_secondary_color;
/*  227:     */   public final boolean GL_EXT_separate_shader_objects;
/*  228:     */   public final boolean GL_EXT_separate_specular_color;
/*  229:     */   public final boolean GL_EXT_shader_image_load_store;
/*  230:     */   public final boolean GL_EXT_shadow_funcs;
/*  231:     */   public final boolean GL_EXT_shared_texture_palette;
/*  232:     */   public final boolean GL_EXT_stencil_clear_tag;
/*  233:     */   public final boolean GL_EXT_stencil_two_side;
/*  234:     */   public final boolean GL_EXT_stencil_wrap;
/*  235:     */   public final boolean GL_EXT_texture_3d;
/*  236:     */   public final boolean GL_EXT_texture_array;
/*  237:     */   public final boolean GL_EXT_texture_buffer_object;
/*  238:     */   public final boolean GL_EXT_texture_compression_latc;
/*  239:     */   public final boolean GL_EXT_texture_compression_rgtc;
/*  240:     */   public final boolean GL_EXT_texture_compression_s3tc;
/*  241:     */   public final boolean GL_EXT_texture_env_combine;
/*  242:     */   public final boolean GL_EXT_texture_env_dot3;
/*  243:     */   public final boolean GL_EXT_texture_filter_anisotropic;
/*  244:     */   public final boolean GL_EXT_texture_integer;
/*  245:     */   public final boolean GL_EXT_texture_lod_bias;
/*  246:     */   public final boolean GL_EXT_texture_mirror_clamp;
/*  247:     */   public final boolean GL_EXT_texture_rectangle;
/*  248:     */   public final boolean GL_EXT_texture_sRGB;
/*  249:     */   public final boolean GL_EXT_texture_sRGB_decode;
/*  250:     */   public final boolean GL_EXT_texture_shared_exponent;
/*  251:     */   public final boolean GL_EXT_texture_snorm;
/*  252:     */   public final boolean GL_EXT_texture_swizzle;
/*  253:     */   public final boolean GL_EXT_timer_query;
/*  254:     */   public final boolean GL_EXT_transform_feedback;
/*  255:     */   public final boolean GL_EXT_vertex_array_bgra;
/*  256:     */   public final boolean GL_EXT_vertex_attrib_64bit;
/*  257:     */   public final boolean GL_EXT_vertex_shader;
/*  258:     */   public final boolean GL_EXT_vertex_weighting;
/*  259:     */   public final boolean OpenGL11;
/*  260:     */   public final boolean OpenGL12;
/*  261:     */   public final boolean OpenGL13;
/*  262:     */   public final boolean OpenGL14;
/*  263:     */   public final boolean OpenGL15;
/*  264:     */   public final boolean OpenGL20;
/*  265:     */   public final boolean OpenGL21;
/*  266:     */   public final boolean OpenGL30;
/*  267:     */   public final boolean OpenGL31;
/*  268:     */   public final boolean OpenGL32;
/*  269:     */   public final boolean OpenGL33;
/*  270:     */   public final boolean OpenGL40;
/*  271:     */   public final boolean OpenGL41;
/*  272:     */   public final boolean OpenGL42;
/*  273:     */   public final boolean OpenGL43;
/*  274:     */   public final boolean GL_GREMEDY_frame_terminator;
/*  275:     */   public final boolean GL_GREMEDY_string_marker;
/*  276:     */   public final boolean GL_HP_occlusion_test;
/*  277:     */   public final boolean GL_IBM_rasterpos_clip;
/*  278:     */   public final boolean GL_INTEL_map_texture;
/*  279:     */   public final boolean GL_KHR_debug;
/*  280:     */   public final boolean GL_KHR_texture_compression_astc_ldr;
/*  281:     */   public final boolean GL_NVX_gpu_memory_info;
/*  282:     */   public final boolean GL_NV_bindless_texture;
/*  283:     */   public final boolean GL_NV_blend_square;
/*  284:     */   public final boolean GL_NV_compute_program5;
/*  285:     */   public final boolean GL_NV_conditional_render;
/*  286:     */   public final boolean GL_NV_copy_depth_to_color;
/*  287:     */   public final boolean GL_NV_copy_image;
/*  288:     */   public final boolean GL_NV_deep_texture3D;
/*  289:     */   public final boolean GL_NV_depth_buffer_float;
/*  290:     */   public final boolean GL_NV_depth_clamp;
/*  291:     */   public final boolean GL_NV_draw_texture;
/*  292:     */   public final boolean GL_NV_evaluators;
/*  293:     */   public final boolean GL_NV_explicit_multisample;
/*  294:     */   public final boolean GL_NV_fence;
/*  295:     */   public final boolean GL_NV_float_buffer;
/*  296:     */   public final boolean GL_NV_fog_distance;
/*  297:     */   public final boolean GL_NV_fragment_program;
/*  298:     */   public final boolean GL_NV_fragment_program2;
/*  299:     */   public final boolean GL_NV_fragment_program4;
/*  300:     */   public final boolean GL_NV_fragment_program_option;
/*  301:     */   public final boolean GL_NV_framebuffer_multisample_coverage;
/*  302:     */   public final boolean GL_NV_geometry_program4;
/*  303:     */   public final boolean GL_NV_geometry_shader4;
/*  304:     */   public final boolean GL_NV_gpu_program4;
/*  305:     */   public final boolean GL_NV_gpu_program5;
/*  306:     */   public final boolean GL_NV_gpu_shader5;
/*  307:     */   public final boolean GL_NV_half_float;
/*  308:     */   public final boolean GL_NV_light_max_exponent;
/*  309:     */   public final boolean GL_NV_multisample_coverage;
/*  310:     */   public final boolean GL_NV_multisample_filter_hint;
/*  311:     */   public final boolean GL_NV_occlusion_query;
/*  312:     */   public final boolean GL_NV_packed_depth_stencil;
/*  313:     */   public final boolean GL_NV_parameter_buffer_object;
/*  314:     */   public final boolean GL_NV_parameter_buffer_object2;
/*  315:     */   public final boolean GL_NV_path_rendering;
/*  316:     */   public final boolean GL_NV_pixel_data_range;
/*  317:     */   public final boolean GL_NV_point_sprite;
/*  318:     */   public final boolean GL_NV_present_video;
/*  319:     */   public final boolean GL_NV_primitive_restart;
/*  320:     */   public final boolean GL_NV_register_combiners;
/*  321:     */   public final boolean GL_NV_register_combiners2;
/*  322:     */   public final boolean GL_NV_shader_atomic_counters;
/*  323:     */   public final boolean GL_NV_shader_atomic_float;
/*  324:     */   public final boolean GL_NV_shader_buffer_load;
/*  325:     */   public final boolean GL_NV_shader_buffer_store;
/*  326:     */   public final boolean GL_NV_shader_storage_buffer_object;
/*  327:     */   public final boolean GL_NV_tessellation_program5;
/*  328:     */   public final boolean GL_NV_texgen_reflection;
/*  329:     */   public final boolean GL_NV_texture_barrier;
/*  330:     */   public final boolean GL_NV_texture_compression_vtc;
/*  331:     */   public final boolean GL_NV_texture_env_combine4;
/*  332:     */   public final boolean GL_NV_texture_expand_normal;
/*  333:     */   public final boolean GL_NV_texture_multisample;
/*  334:     */   public final boolean GL_NV_texture_rectangle;
/*  335:     */   public final boolean GL_NV_texture_shader;
/*  336:     */   public final boolean GL_NV_texture_shader2;
/*  337:     */   public final boolean GL_NV_texture_shader3;
/*  338:     */   public final boolean GL_NV_transform_feedback;
/*  339:     */   public final boolean GL_NV_transform_feedback2;
/*  340:     */   public final boolean GL_NV_vertex_array_range;
/*  341:     */   public final boolean GL_NV_vertex_array_range2;
/*  342:     */   public final boolean GL_NV_vertex_attrib_integer_64bit;
/*  343:     */   public final boolean GL_NV_vertex_buffer_unified_memory;
/*  344:     */   public final boolean GL_NV_vertex_program;
/*  345:     */   public final boolean GL_NV_vertex_program1_1;
/*  346:     */   public final boolean GL_NV_vertex_program2;
/*  347:     */   public final boolean GL_NV_vertex_program2_option;
/*  348:     */   public final boolean GL_NV_vertex_program3;
/*  349:     */   public final boolean GL_NV_vertex_program4;
/*  350:     */   public final boolean GL_NV_video_capture;
/*  351:     */   public final boolean GL_SGIS_generate_mipmap;
/*  352:     */   public final boolean GL_SGIS_texture_lod;
/*  353:     */   public final boolean GL_SUN_slice_accum;
/*  354:     */   long glDebugMessageEnableAMD;
/*  355:     */   long glDebugMessageInsertAMD;
/*  356:     */   long glDebugMessageCallbackAMD;
/*  357:     */   long glGetDebugMessageLogAMD;
/*  358:     */   long glBlendFuncIndexedAMD;
/*  359:     */   long glBlendFuncSeparateIndexedAMD;
/*  360:     */   long glBlendEquationIndexedAMD;
/*  361:     */   long glBlendEquationSeparateIndexedAMD;
/*  362:     */   long glMultiDrawArraysIndirectAMD;
/*  363:     */   long glMultiDrawElementsIndirectAMD;
/*  364:     */   long glGenNamesAMD;
/*  365:     */   long glDeleteNamesAMD;
/*  366:     */   long glIsNameAMD;
/*  367:     */   long glGetPerfMonitorGroupsAMD;
/*  368:     */   long glGetPerfMonitorCountersAMD;
/*  369:     */   long glGetPerfMonitorGroupStringAMD;
/*  370:     */   long glGetPerfMonitorCounterStringAMD;
/*  371:     */   long glGetPerfMonitorCounterInfoAMD;
/*  372:     */   long glGenPerfMonitorsAMD;
/*  373:     */   long glDeletePerfMonitorsAMD;
/*  374:     */   long glSelectPerfMonitorCountersAMD;
/*  375:     */   long glBeginPerfMonitorAMD;
/*  376:     */   long glEndPerfMonitorAMD;
/*  377:     */   long glGetPerfMonitorCounterDataAMD;
/*  378:     */   long glSetMultisamplefvAMD;
/*  379:     */   long glTexStorageSparseAMD;
/*  380:     */   long glTextureStorageSparseAMD;
/*  381:     */   long glStencilOpValueAMD;
/*  382:     */   long glTessellationFactorAMD;
/*  383:     */   long glTessellationModeAMD;
/*  384:     */   long glElementPointerAPPLE;
/*  385:     */   long glDrawElementArrayAPPLE;
/*  386:     */   long glDrawRangeElementArrayAPPLE;
/*  387:     */   long glMultiDrawElementArrayAPPLE;
/*  388:     */   long glMultiDrawRangeElementArrayAPPLE;
/*  389:     */   long glGenFencesAPPLE;
/*  390:     */   long glDeleteFencesAPPLE;
/*  391:     */   long glSetFenceAPPLE;
/*  392:     */   long glIsFenceAPPLE;
/*  393:     */   long glTestFenceAPPLE;
/*  394:     */   long glFinishFenceAPPLE;
/*  395:     */   long glTestObjectAPPLE;
/*  396:     */   long glFinishObjectAPPLE;
/*  397:     */   long glBufferParameteriAPPLE;
/*  398:     */   long glFlushMappedBufferRangeAPPLE;
/*  399:     */   long glObjectPurgeableAPPLE;
/*  400:     */   long glObjectUnpurgeableAPPLE;
/*  401:     */   long glGetObjectParameterivAPPLE;
/*  402:     */   long glTextureRangeAPPLE;
/*  403:     */   long glGetTexParameterPointervAPPLE;
/*  404:     */   long glBindVertexArrayAPPLE;
/*  405:     */   long glDeleteVertexArraysAPPLE;
/*  406:     */   long glGenVertexArraysAPPLE;
/*  407:     */   long glIsVertexArrayAPPLE;
/*  408:     */   long glVertexArrayRangeAPPLE;
/*  409:     */   long glFlushVertexArrayRangeAPPLE;
/*  410:     */   long glVertexArrayParameteriAPPLE;
/*  411:     */   long glEnableVertexAttribAPPLE;
/*  412:     */   long glDisableVertexAttribAPPLE;
/*  413:     */   long glIsVertexAttribEnabledAPPLE;
/*  414:     */   long glMapVertexAttrib1dAPPLE;
/*  415:     */   long glMapVertexAttrib1fAPPLE;
/*  416:     */   long glMapVertexAttrib2dAPPLE;
/*  417:     */   long glMapVertexAttrib2fAPPLE;
/*  418:     */   long glBindBufferARB;
/*  419:     */   long glDeleteBuffersARB;
/*  420:     */   long glGenBuffersARB;
/*  421:     */   long glIsBufferARB;
/*  422:     */   long glBufferDataARB;
/*  423:     */   long glBufferSubDataARB;
/*  424:     */   long glGetBufferSubDataARB;
/*  425:     */   long glMapBufferARB;
/*  426:     */   long glUnmapBufferARB;
/*  427:     */   long glGetBufferParameterivARB;
/*  428:     */   long glGetBufferPointervARB;
/*  429:     */   long glCreateSyncFromCLeventARB;
/*  430:     */   long glClearNamedBufferDataEXT;
/*  431:     */   long glClearNamedBufferSubDataEXT;
/*  432:     */   long glClampColorARB;
/*  433:     */   long glDebugMessageControlARB;
/*  434:     */   long glDebugMessageInsertARB;
/*  435:     */   long glDebugMessageCallbackARB;
/*  436:     */   long glGetDebugMessageLogARB;
/*  437:     */   long glDrawBuffersARB;
/*  438:     */   long glBlendEquationiARB;
/*  439:     */   long glBlendEquationSeparateiARB;
/*  440:     */   long glBlendFunciARB;
/*  441:     */   long glBlendFuncSeparateiARB;
/*  442:     */   long glDrawArraysInstancedARB;
/*  443:     */   long glDrawElementsInstancedARB;
/*  444:     */   long glNamedFramebufferParameteriEXT;
/*  445:     */   long glGetNamedFramebufferParameterivEXT;
/*  446:     */   long glProgramParameteriARB;
/*  447:     */   long glFramebufferTextureARB;
/*  448:     */   long glFramebufferTextureLayerARB;
/*  449:     */   long glFramebufferTextureFaceARB;
/*  450:     */   long glProgramUniform1dEXT;
/*  451:     */   long glProgramUniform2dEXT;
/*  452:     */   long glProgramUniform3dEXT;
/*  453:     */   long glProgramUniform4dEXT;
/*  454:     */   long glProgramUniform1dvEXT;
/*  455:     */   long glProgramUniform2dvEXT;
/*  456:     */   long glProgramUniform3dvEXT;
/*  457:     */   long glProgramUniform4dvEXT;
/*  458:     */   long glProgramUniformMatrix2dvEXT;
/*  459:     */   long glProgramUniformMatrix3dvEXT;
/*  460:     */   long glProgramUniformMatrix4dvEXT;
/*  461:     */   long glProgramUniformMatrix2x3dvEXT;
/*  462:     */   long glProgramUniformMatrix2x4dvEXT;
/*  463:     */   long glProgramUniformMatrix3x2dvEXT;
/*  464:     */   long glProgramUniformMatrix3x4dvEXT;
/*  465:     */   long glProgramUniformMatrix4x2dvEXT;
/*  466:     */   long glProgramUniformMatrix4x3dvEXT;
/*  467:     */   long glColorTable;
/*  468:     */   long glColorSubTable;
/*  469:     */   long glColorTableParameteriv;
/*  470:     */   long glColorTableParameterfv;
/*  471:     */   long glCopyColorSubTable;
/*  472:     */   long glCopyColorTable;
/*  473:     */   long glGetColorTable;
/*  474:     */   long glGetColorTableParameteriv;
/*  475:     */   long glGetColorTableParameterfv;
/*  476:     */   long glHistogram;
/*  477:     */   long glResetHistogram;
/*  478:     */   long glGetHistogram;
/*  479:     */   long glGetHistogramParameterfv;
/*  480:     */   long glGetHistogramParameteriv;
/*  481:     */   long glMinmax;
/*  482:     */   long glResetMinmax;
/*  483:     */   long glGetMinmax;
/*  484:     */   long glGetMinmaxParameterfv;
/*  485:     */   long glGetMinmaxParameteriv;
/*  486:     */   long glConvolutionFilter1D;
/*  487:     */   long glConvolutionFilter2D;
/*  488:     */   long glConvolutionParameterf;
/*  489:     */   long glConvolutionParameterfv;
/*  490:     */   long glConvolutionParameteri;
/*  491:     */   long glConvolutionParameteriv;
/*  492:     */   long glCopyConvolutionFilter1D;
/*  493:     */   long glCopyConvolutionFilter2D;
/*  494:     */   long glGetConvolutionFilter;
/*  495:     */   long glGetConvolutionParameterfv;
/*  496:     */   long glGetConvolutionParameteriv;
/*  497:     */   long glSeparableFilter2D;
/*  498:     */   long glGetSeparableFilter;
/*  499:     */   long glVertexAttribDivisorARB;
/*  500:     */   long glCurrentPaletteMatrixARB;
/*  501:     */   long glMatrixIndexPointerARB;
/*  502:     */   long glMatrixIndexubvARB;
/*  503:     */   long glMatrixIndexusvARB;
/*  504:     */   long glMatrixIndexuivARB;
/*  505:     */   long glSampleCoverageARB;
/*  506:     */   long glClientActiveTextureARB;
/*  507:     */   long glActiveTextureARB;
/*  508:     */   long glMultiTexCoord1fARB;
/*  509:     */   long glMultiTexCoord1dARB;
/*  510:     */   long glMultiTexCoord1iARB;
/*  511:     */   long glMultiTexCoord1sARB;
/*  512:     */   long glMultiTexCoord2fARB;
/*  513:     */   long glMultiTexCoord2dARB;
/*  514:     */   long glMultiTexCoord2iARB;
/*  515:     */   long glMultiTexCoord2sARB;
/*  516:     */   long glMultiTexCoord3fARB;
/*  517:     */   long glMultiTexCoord3dARB;
/*  518:     */   long glMultiTexCoord3iARB;
/*  519:     */   long glMultiTexCoord3sARB;
/*  520:     */   long glMultiTexCoord4fARB;
/*  521:     */   long glMultiTexCoord4dARB;
/*  522:     */   long glMultiTexCoord4iARB;
/*  523:     */   long glMultiTexCoord4sARB;
/*  524:     */   long glGenQueriesARB;
/*  525:     */   long glDeleteQueriesARB;
/*  526:     */   long glIsQueryARB;
/*  527:     */   long glBeginQueryARB;
/*  528:     */   long glEndQueryARB;
/*  529:     */   long glGetQueryivARB;
/*  530:     */   long glGetQueryObjectivARB;
/*  531:     */   long glGetQueryObjectuivARB;
/*  532:     */   long glPointParameterfARB;
/*  533:     */   long glPointParameterfvARB;
/*  534:     */   long glProgramStringARB;
/*  535:     */   long glBindProgramARB;
/*  536:     */   long glDeleteProgramsARB;
/*  537:     */   long glGenProgramsARB;
/*  538:     */   long glProgramEnvParameter4fARB;
/*  539:     */   long glProgramEnvParameter4dARB;
/*  540:     */   long glProgramEnvParameter4fvARB;
/*  541:     */   long glProgramEnvParameter4dvARB;
/*  542:     */   long glProgramLocalParameter4fARB;
/*  543:     */   long glProgramLocalParameter4dARB;
/*  544:     */   long glProgramLocalParameter4fvARB;
/*  545:     */   long glProgramLocalParameter4dvARB;
/*  546:     */   long glGetProgramEnvParameterfvARB;
/*  547:     */   long glGetProgramEnvParameterdvARB;
/*  548:     */   long glGetProgramLocalParameterfvARB;
/*  549:     */   long glGetProgramLocalParameterdvARB;
/*  550:     */   long glGetProgramivARB;
/*  551:     */   long glGetProgramStringARB;
/*  552:     */   long glIsProgramARB;
/*  553:     */   long glGetGraphicsResetStatusARB;
/*  554:     */   long glGetnMapdvARB;
/*  555:     */   long glGetnMapfvARB;
/*  556:     */   long glGetnMapivARB;
/*  557:     */   long glGetnPixelMapfvARB;
/*  558:     */   long glGetnPixelMapuivARB;
/*  559:     */   long glGetnPixelMapusvARB;
/*  560:     */   long glGetnPolygonStippleARB;
/*  561:     */   long glGetnTexImageARB;
/*  562:     */   long glReadnPixelsARB;
/*  563:     */   long glGetnColorTableARB;
/*  564:     */   long glGetnConvolutionFilterARB;
/*  565:     */   long glGetnSeparableFilterARB;
/*  566:     */   long glGetnHistogramARB;
/*  567:     */   long glGetnMinmaxARB;
/*  568:     */   long glGetnCompressedTexImageARB;
/*  569:     */   long glGetnUniformfvARB;
/*  570:     */   long glGetnUniformivARB;
/*  571:     */   long glGetnUniformuivARB;
/*  572:     */   long glGetnUniformdvARB;
/*  573:     */   long glMinSampleShadingARB;
/*  574:     */   long glDeleteObjectARB;
/*  575:     */   long glGetHandleARB;
/*  576:     */   long glDetachObjectARB;
/*  577:     */   long glCreateShaderObjectARB;
/*  578:     */   long glShaderSourceARB;
/*  579:     */   long glCompileShaderARB;
/*  580:     */   long glCreateProgramObjectARB;
/*  581:     */   long glAttachObjectARB;
/*  582:     */   long glLinkProgramARB;
/*  583:     */   long glUseProgramObjectARB;
/*  584:     */   long glValidateProgramARB;
/*  585:     */   long glUniform1fARB;
/*  586:     */   long glUniform2fARB;
/*  587:     */   long glUniform3fARB;
/*  588:     */   long glUniform4fARB;
/*  589:     */   long glUniform1iARB;
/*  590:     */   long glUniform2iARB;
/*  591:     */   long glUniform3iARB;
/*  592:     */   long glUniform4iARB;
/*  593:     */   long glUniform1fvARB;
/*  594:     */   long glUniform2fvARB;
/*  595:     */   long glUniform3fvARB;
/*  596:     */   long glUniform4fvARB;
/*  597:     */   long glUniform1ivARB;
/*  598:     */   long glUniform2ivARB;
/*  599:     */   long glUniform3ivARB;
/*  600:     */   long glUniform4ivARB;
/*  601:     */   long glUniformMatrix2fvARB;
/*  602:     */   long glUniformMatrix3fvARB;
/*  603:     */   long glUniformMatrix4fvARB;
/*  604:     */   long glGetObjectParameterfvARB;
/*  605:     */   long glGetObjectParameterivARB;
/*  606:     */   long glGetInfoLogARB;
/*  607:     */   long glGetAttachedObjectsARB;
/*  608:     */   long glGetUniformLocationARB;
/*  609:     */   long glGetActiveUniformARB;
/*  610:     */   long glGetUniformfvARB;
/*  611:     */   long glGetUniformivARB;
/*  612:     */   long glGetShaderSourceARB;
/*  613:     */   long glNamedStringARB;
/*  614:     */   long glDeleteNamedStringARB;
/*  615:     */   long glCompileShaderIncludeARB;
/*  616:     */   long glIsNamedStringARB;
/*  617:     */   long glGetNamedStringARB;
/*  618:     */   long glGetNamedStringivARB;
/*  619:     */   long glTexBufferARB;
/*  620:     */   long glTextureBufferRangeEXT;
/*  621:     */   long glCompressedTexImage1DARB;
/*  622:     */   long glCompressedTexImage2DARB;
/*  623:     */   long glCompressedTexImage3DARB;
/*  624:     */   long glCompressedTexSubImage1DARB;
/*  625:     */   long glCompressedTexSubImage2DARB;
/*  626:     */   long glCompressedTexSubImage3DARB;
/*  627:     */   long glGetCompressedTexImageARB;
/*  628:     */   long glTextureStorage1DEXT;
/*  629:     */   long glTextureStorage2DEXT;
/*  630:     */   long glTextureStorage3DEXT;
/*  631:     */   long glTextureStorage2DMultisampleEXT;
/*  632:     */   long glTextureStorage3DMultisampleEXT;
/*  633:     */   long glLoadTransposeMatrixfARB;
/*  634:     */   long glMultTransposeMatrixfARB;
/*  635:     */   long glVertexArrayVertexAttribLOffsetEXT;
/*  636:     */   long glWeightbvARB;
/*  637:     */   long glWeightsvARB;
/*  638:     */   long glWeightivARB;
/*  639:     */   long glWeightfvARB;
/*  640:     */   long glWeightdvARB;
/*  641:     */   long glWeightubvARB;
/*  642:     */   long glWeightusvARB;
/*  643:     */   long glWeightuivARB;
/*  644:     */   long glWeightPointerARB;
/*  645:     */   long glVertexBlendARB;
/*  646:     */   long glVertexAttrib1sARB;
/*  647:     */   long glVertexAttrib1fARB;
/*  648:     */   long glVertexAttrib1dARB;
/*  649:     */   long glVertexAttrib2sARB;
/*  650:     */   long glVertexAttrib2fARB;
/*  651:     */   long glVertexAttrib2dARB;
/*  652:     */   long glVertexAttrib3sARB;
/*  653:     */   long glVertexAttrib3fARB;
/*  654:     */   long glVertexAttrib3dARB;
/*  655:     */   long glVertexAttrib4sARB;
/*  656:     */   long glVertexAttrib4fARB;
/*  657:     */   long glVertexAttrib4dARB;
/*  658:     */   long glVertexAttrib4NubARB;
/*  659:     */   long glVertexAttribPointerARB;
/*  660:     */   long glEnableVertexAttribArrayARB;
/*  661:     */   long glDisableVertexAttribArrayARB;
/*  662:     */   long glBindAttribLocationARB;
/*  663:     */   long glGetActiveAttribARB;
/*  664:     */   long glGetAttribLocationARB;
/*  665:     */   long glGetVertexAttribfvARB;
/*  666:     */   long glGetVertexAttribdvARB;
/*  667:     */   long glGetVertexAttribivARB;
/*  668:     */   long glGetVertexAttribPointervARB;
/*  669:     */   long glWindowPos2fARB;
/*  670:     */   long glWindowPos2dARB;
/*  671:     */   long glWindowPos2iARB;
/*  672:     */   long glWindowPos2sARB;
/*  673:     */   long glWindowPos3fARB;
/*  674:     */   long glWindowPos3dARB;
/*  675:     */   long glWindowPos3iARB;
/*  676:     */   long glWindowPos3sARB;
/*  677:     */   long glDrawBuffersATI;
/*  678:     */   long glElementPointerATI;
/*  679:     */   long glDrawElementArrayATI;
/*  680:     */   long glDrawRangeElementArrayATI;
/*  681:     */   long glTexBumpParameterfvATI;
/*  682:     */   long glTexBumpParameterivATI;
/*  683:     */   long glGetTexBumpParameterfvATI;
/*  684:     */   long glGetTexBumpParameterivATI;
/*  685:     */   long glGenFragmentShadersATI;
/*  686:     */   long glBindFragmentShaderATI;
/*  687:     */   long glDeleteFragmentShaderATI;
/*  688:     */   long glBeginFragmentShaderATI;
/*  689:     */   long glEndFragmentShaderATI;
/*  690:     */   long glPassTexCoordATI;
/*  691:     */   long glSampleMapATI;
/*  692:     */   long glColorFragmentOp1ATI;
/*  693:     */   long glColorFragmentOp2ATI;
/*  694:     */   long glColorFragmentOp3ATI;
/*  695:     */   long glAlphaFragmentOp1ATI;
/*  696:     */   long glAlphaFragmentOp2ATI;
/*  697:     */   long glAlphaFragmentOp3ATI;
/*  698:     */   long glSetFragmentShaderConstantATI;
/*  699:     */   long glMapObjectBufferATI;
/*  700:     */   long glUnmapObjectBufferATI;
/*  701:     */   long glPNTrianglesfATI;
/*  702:     */   long glPNTrianglesiATI;
/*  703:     */   long glStencilOpSeparateATI;
/*  704:     */   long glStencilFuncSeparateATI;
/*  705:     */   long glNewObjectBufferATI;
/*  706:     */   long glIsObjectBufferATI;
/*  707:     */   long glUpdateObjectBufferATI;
/*  708:     */   long glGetObjectBufferfvATI;
/*  709:     */   long glGetObjectBufferivATI;
/*  710:     */   long glFreeObjectBufferATI;
/*  711:     */   long glArrayObjectATI;
/*  712:     */   long glGetArrayObjectfvATI;
/*  713:     */   long glGetArrayObjectivATI;
/*  714:     */   long glVariantArrayObjectATI;
/*  715:     */   long glGetVariantArrayObjectfvATI;
/*  716:     */   long glGetVariantArrayObjectivATI;
/*  717:     */   long glVertexAttribArrayObjectATI;
/*  718:     */   long glGetVertexAttribArrayObjectfvATI;
/*  719:     */   long glGetVertexAttribArrayObjectivATI;
/*  720:     */   long glVertexStream2fATI;
/*  721:     */   long glVertexStream2dATI;
/*  722:     */   long glVertexStream2iATI;
/*  723:     */   long glVertexStream2sATI;
/*  724:     */   long glVertexStream3fATI;
/*  725:     */   long glVertexStream3dATI;
/*  726:     */   long glVertexStream3iATI;
/*  727:     */   long glVertexStream3sATI;
/*  728:     */   long glVertexStream4fATI;
/*  729:     */   long glVertexStream4dATI;
/*  730:     */   long glVertexStream4iATI;
/*  731:     */   long glVertexStream4sATI;
/*  732:     */   long glNormalStream3bATI;
/*  733:     */   long glNormalStream3fATI;
/*  734:     */   long glNormalStream3dATI;
/*  735:     */   long glNormalStream3iATI;
/*  736:     */   long glNormalStream3sATI;
/*  737:     */   long glClientActiveVertexStreamATI;
/*  738:     */   long glVertexBlendEnvfATI;
/*  739:     */   long glVertexBlendEnviATI;
/*  740:     */   long glUniformBufferEXT;
/*  741:     */   long glGetUniformBufferSizeEXT;
/*  742:     */   long glGetUniformOffsetEXT;
/*  743:     */   long glBlendColorEXT;
/*  744:     */   long glBlendEquationSeparateEXT;
/*  745:     */   long glBlendFuncSeparateEXT;
/*  746:     */   long glBlendEquationEXT;
/*  747:     */   long glLockArraysEXT;
/*  748:     */   long glUnlockArraysEXT;
/*  749:     */   long glDepthBoundsEXT;
/*  750:     */   long glClientAttribDefaultEXT;
/*  751:     */   long glPushClientAttribDefaultEXT;
/*  752:     */   long glMatrixLoadfEXT;
/*  753:     */   long glMatrixLoaddEXT;
/*  754:     */   long glMatrixMultfEXT;
/*  755:     */   long glMatrixMultdEXT;
/*  756:     */   long glMatrixLoadIdentityEXT;
/*  757:     */   long glMatrixRotatefEXT;
/*  758:     */   long glMatrixRotatedEXT;
/*  759:     */   long glMatrixScalefEXT;
/*  760:     */   long glMatrixScaledEXT;
/*  761:     */   long glMatrixTranslatefEXT;
/*  762:     */   long glMatrixTranslatedEXT;
/*  763:     */   long glMatrixOrthoEXT;
/*  764:     */   long glMatrixFrustumEXT;
/*  765:     */   long glMatrixPushEXT;
/*  766:     */   long glMatrixPopEXT;
/*  767:     */   long glTextureParameteriEXT;
/*  768:     */   long glTextureParameterivEXT;
/*  769:     */   long glTextureParameterfEXT;
/*  770:     */   long glTextureParameterfvEXT;
/*  771:     */   long glTextureImage1DEXT;
/*  772:     */   long glTextureImage2DEXT;
/*  773:     */   long glTextureSubImage1DEXT;
/*  774:     */   long glTextureSubImage2DEXT;
/*  775:     */   long glCopyTextureImage1DEXT;
/*  776:     */   long glCopyTextureImage2DEXT;
/*  777:     */   long glCopyTextureSubImage1DEXT;
/*  778:     */   long glCopyTextureSubImage2DEXT;
/*  779:     */   long glGetTextureImageEXT;
/*  780:     */   long glGetTextureParameterfvEXT;
/*  781:     */   long glGetTextureParameterivEXT;
/*  782:     */   long glGetTextureLevelParameterfvEXT;
/*  783:     */   long glGetTextureLevelParameterivEXT;
/*  784:     */   long glTextureImage3DEXT;
/*  785:     */   long glTextureSubImage3DEXT;
/*  786:     */   long glCopyTextureSubImage3DEXT;
/*  787:     */   long glBindMultiTextureEXT;
/*  788:     */   long glMultiTexCoordPointerEXT;
/*  789:     */   long glMultiTexEnvfEXT;
/*  790:     */   long glMultiTexEnvfvEXT;
/*  791:     */   long glMultiTexEnviEXT;
/*  792:     */   long glMultiTexEnvivEXT;
/*  793:     */   long glMultiTexGendEXT;
/*  794:     */   long glMultiTexGendvEXT;
/*  795:     */   long glMultiTexGenfEXT;
/*  796:     */   long glMultiTexGenfvEXT;
/*  797:     */   long glMultiTexGeniEXT;
/*  798:     */   long glMultiTexGenivEXT;
/*  799:     */   long glGetMultiTexEnvfvEXT;
/*  800:     */   long glGetMultiTexEnvivEXT;
/*  801:     */   long glGetMultiTexGendvEXT;
/*  802:     */   long glGetMultiTexGenfvEXT;
/*  803:     */   long glGetMultiTexGenivEXT;
/*  804:     */   long glMultiTexParameteriEXT;
/*  805:     */   long glMultiTexParameterivEXT;
/*  806:     */   long glMultiTexParameterfEXT;
/*  807:     */   long glMultiTexParameterfvEXT;
/*  808:     */   long glMultiTexImage1DEXT;
/*  809:     */   long glMultiTexImage2DEXT;
/*  810:     */   long glMultiTexSubImage1DEXT;
/*  811:     */   long glMultiTexSubImage2DEXT;
/*  812:     */   long glCopyMultiTexImage1DEXT;
/*  813:     */   long glCopyMultiTexImage2DEXT;
/*  814:     */   long glCopyMultiTexSubImage1DEXT;
/*  815:     */   long glCopyMultiTexSubImage2DEXT;
/*  816:     */   long glGetMultiTexImageEXT;
/*  817:     */   long glGetMultiTexParameterfvEXT;
/*  818:     */   long glGetMultiTexParameterivEXT;
/*  819:     */   long glGetMultiTexLevelParameterfvEXT;
/*  820:     */   long glGetMultiTexLevelParameterivEXT;
/*  821:     */   long glMultiTexImage3DEXT;
/*  822:     */   long glMultiTexSubImage3DEXT;
/*  823:     */   long glCopyMultiTexSubImage3DEXT;
/*  824:     */   long glEnableClientStateIndexedEXT;
/*  825:     */   long glDisableClientStateIndexedEXT;
/*  826:     */   long glEnableClientStateiEXT;
/*  827:     */   long glDisableClientStateiEXT;
/*  828:     */   long glGetFloatIndexedvEXT;
/*  829:     */   long glGetDoubleIndexedvEXT;
/*  830:     */   long glGetPointerIndexedvEXT;
/*  831:     */   long glGetFloati_vEXT;
/*  832:     */   long glGetDoublei_vEXT;
/*  833:     */   long glGetPointeri_vEXT;
/*  834:     */   long glNamedProgramStringEXT;
/*  835:     */   long glNamedProgramLocalParameter4dEXT;
/*  836:     */   long glNamedProgramLocalParameter4dvEXT;
/*  837:     */   long glNamedProgramLocalParameter4fEXT;
/*  838:     */   long glNamedProgramLocalParameter4fvEXT;
/*  839:     */   long glGetNamedProgramLocalParameterdvEXT;
/*  840:     */   long glGetNamedProgramLocalParameterfvEXT;
/*  841:     */   long glGetNamedProgramivEXT;
/*  842:     */   long glGetNamedProgramStringEXT;
/*  843:     */   long glCompressedTextureImage3DEXT;
/*  844:     */   long glCompressedTextureImage2DEXT;
/*  845:     */   long glCompressedTextureImage1DEXT;
/*  846:     */   long glCompressedTextureSubImage3DEXT;
/*  847:     */   long glCompressedTextureSubImage2DEXT;
/*  848:     */   long glCompressedTextureSubImage1DEXT;
/*  849:     */   long glGetCompressedTextureImageEXT;
/*  850:     */   long glCompressedMultiTexImage3DEXT;
/*  851:     */   long glCompressedMultiTexImage2DEXT;
/*  852:     */   long glCompressedMultiTexImage1DEXT;
/*  853:     */   long glCompressedMultiTexSubImage3DEXT;
/*  854:     */   long glCompressedMultiTexSubImage2DEXT;
/*  855:     */   long glCompressedMultiTexSubImage1DEXT;
/*  856:     */   long glGetCompressedMultiTexImageEXT;
/*  857:     */   long glMatrixLoadTransposefEXT;
/*  858:     */   long glMatrixLoadTransposedEXT;
/*  859:     */   long glMatrixMultTransposefEXT;
/*  860:     */   long glMatrixMultTransposedEXT;
/*  861:     */   long glNamedBufferDataEXT;
/*  862:     */   long glNamedBufferSubDataEXT;
/*  863:     */   long glMapNamedBufferEXT;
/*  864:     */   long glUnmapNamedBufferEXT;
/*  865:     */   long glGetNamedBufferParameterivEXT;
/*  866:     */   long glGetNamedBufferPointervEXT;
/*  867:     */   long glGetNamedBufferSubDataEXT;
/*  868:     */   long glProgramUniform1fEXT;
/*  869:     */   long glProgramUniform2fEXT;
/*  870:     */   long glProgramUniform3fEXT;
/*  871:     */   long glProgramUniform4fEXT;
/*  872:     */   long glProgramUniform1iEXT;
/*  873:     */   long glProgramUniform2iEXT;
/*  874:     */   long glProgramUniform3iEXT;
/*  875:     */   long glProgramUniform4iEXT;
/*  876:     */   long glProgramUniform1fvEXT;
/*  877:     */   long glProgramUniform2fvEXT;
/*  878:     */   long glProgramUniform3fvEXT;
/*  879:     */   long glProgramUniform4fvEXT;
/*  880:     */   long glProgramUniform1ivEXT;
/*  881:     */   long glProgramUniform2ivEXT;
/*  882:     */   long glProgramUniform3ivEXT;
/*  883:     */   long glProgramUniform4ivEXT;
/*  884:     */   long glProgramUniformMatrix2fvEXT;
/*  885:     */   long glProgramUniformMatrix3fvEXT;
/*  886:     */   long glProgramUniformMatrix4fvEXT;
/*  887:     */   long glProgramUniformMatrix2x3fvEXT;
/*  888:     */   long glProgramUniformMatrix3x2fvEXT;
/*  889:     */   long glProgramUniformMatrix2x4fvEXT;
/*  890:     */   long glProgramUniformMatrix4x2fvEXT;
/*  891:     */   long glProgramUniformMatrix3x4fvEXT;
/*  892:     */   long glProgramUniformMatrix4x3fvEXT;
/*  893:     */   long glTextureBufferEXT;
/*  894:     */   long glMultiTexBufferEXT;
/*  895:     */   long glTextureParameterIivEXT;
/*  896:     */   long glTextureParameterIuivEXT;
/*  897:     */   long glGetTextureParameterIivEXT;
/*  898:     */   long glGetTextureParameterIuivEXT;
/*  899:     */   long glMultiTexParameterIivEXT;
/*  900:     */   long glMultiTexParameterIuivEXT;
/*  901:     */   long glGetMultiTexParameterIivEXT;
/*  902:     */   long glGetMultiTexParameterIuivEXT;
/*  903:     */   long glProgramUniform1uiEXT;
/*  904:     */   long glProgramUniform2uiEXT;
/*  905:     */   long glProgramUniform3uiEXT;
/*  906:     */   long glProgramUniform4uiEXT;
/*  907:     */   long glProgramUniform1uivEXT;
/*  908:     */   long glProgramUniform2uivEXT;
/*  909:     */   long glProgramUniform3uivEXT;
/*  910:     */   long glProgramUniform4uivEXT;
/*  911:     */   long glNamedProgramLocalParameters4fvEXT;
/*  912:     */   long glNamedProgramLocalParameterI4iEXT;
/*  913:     */   long glNamedProgramLocalParameterI4ivEXT;
/*  914:     */   long glNamedProgramLocalParametersI4ivEXT;
/*  915:     */   long glNamedProgramLocalParameterI4uiEXT;
/*  916:     */   long glNamedProgramLocalParameterI4uivEXT;
/*  917:     */   long glNamedProgramLocalParametersI4uivEXT;
/*  918:     */   long glGetNamedProgramLocalParameterIivEXT;
/*  919:     */   long glGetNamedProgramLocalParameterIuivEXT;
/*  920:     */   long glNamedRenderbufferStorageEXT;
/*  921:     */   long glGetNamedRenderbufferParameterivEXT;
/*  922:     */   long glNamedRenderbufferStorageMultisampleEXT;
/*  923:     */   long glNamedRenderbufferStorageMultisampleCoverageEXT;
/*  924:     */   long glCheckNamedFramebufferStatusEXT;
/*  925:     */   long glNamedFramebufferTexture1DEXT;
/*  926:     */   long glNamedFramebufferTexture2DEXT;
/*  927:     */   long glNamedFramebufferTexture3DEXT;
/*  928:     */   long glNamedFramebufferRenderbufferEXT;
/*  929:     */   long glGetNamedFramebufferAttachmentParameterivEXT;
/*  930:     */   long glGenerateTextureMipmapEXT;
/*  931:     */   long glGenerateMultiTexMipmapEXT;
/*  932:     */   long glFramebufferDrawBufferEXT;
/*  933:     */   long glFramebufferDrawBuffersEXT;
/*  934:     */   long glFramebufferReadBufferEXT;
/*  935:     */   long glGetFramebufferParameterivEXT;
/*  936:     */   long glNamedCopyBufferSubDataEXT;
/*  937:     */   long glNamedFramebufferTextureEXT;
/*  938:     */   long glNamedFramebufferTextureLayerEXT;
/*  939:     */   long glNamedFramebufferTextureFaceEXT;
/*  940:     */   long glTextureRenderbufferEXT;
/*  941:     */   long glMultiTexRenderbufferEXT;
/*  942:     */   long glVertexArrayVertexOffsetEXT;
/*  943:     */   long glVertexArrayColorOffsetEXT;
/*  944:     */   long glVertexArrayEdgeFlagOffsetEXT;
/*  945:     */   long glVertexArrayIndexOffsetEXT;
/*  946:     */   long glVertexArrayNormalOffsetEXT;
/*  947:     */   long glVertexArrayTexCoordOffsetEXT;
/*  948:     */   long glVertexArrayMultiTexCoordOffsetEXT;
/*  949:     */   long glVertexArrayFogCoordOffsetEXT;
/*  950:     */   long glVertexArraySecondaryColorOffsetEXT;
/*  951:     */   long glVertexArrayVertexAttribOffsetEXT;
/*  952:     */   long glVertexArrayVertexAttribIOffsetEXT;
/*  953:     */   long glEnableVertexArrayEXT;
/*  954:     */   long glDisableVertexArrayEXT;
/*  955:     */   long glEnableVertexArrayAttribEXT;
/*  956:     */   long glDisableVertexArrayAttribEXT;
/*  957:     */   long glGetVertexArrayIntegervEXT;
/*  958:     */   long glGetVertexArrayPointervEXT;
/*  959:     */   long glGetVertexArrayIntegeri_vEXT;
/*  960:     */   long glGetVertexArrayPointeri_vEXT;
/*  961:     */   long glMapNamedBufferRangeEXT;
/*  962:     */   long glFlushMappedNamedBufferRangeEXT;
/*  963:     */   long glColorMaskIndexedEXT;
/*  964:     */   long glGetBooleanIndexedvEXT;
/*  965:     */   long glGetIntegerIndexedvEXT;
/*  966:     */   long glEnableIndexedEXT;
/*  967:     */   long glDisableIndexedEXT;
/*  968:     */   long glIsEnabledIndexedEXT;
/*  969:     */   long glDrawArraysInstancedEXT;
/*  970:     */   long glDrawElementsInstancedEXT;
/*  971:     */   long glDrawRangeElementsEXT;
/*  972:     */   long glFogCoordfEXT;
/*  973:     */   long glFogCoorddEXT;
/*  974:     */   long glFogCoordPointerEXT;
/*  975:     */   long glBlitFramebufferEXT;
/*  976:     */   long glRenderbufferStorageMultisampleEXT;
/*  977:     */   long glIsRenderbufferEXT;
/*  978:     */   long glBindRenderbufferEXT;
/*  979:     */   long glDeleteRenderbuffersEXT;
/*  980:     */   long glGenRenderbuffersEXT;
/*  981:     */   long glRenderbufferStorageEXT;
/*  982:     */   long glGetRenderbufferParameterivEXT;
/*  983:     */   long glIsFramebufferEXT;
/*  984:     */   long glBindFramebufferEXT;
/*  985:     */   long glDeleteFramebuffersEXT;
/*  986:     */   long glGenFramebuffersEXT;
/*  987:     */   long glCheckFramebufferStatusEXT;
/*  988:     */   long glFramebufferTexture1DEXT;
/*  989:     */   long glFramebufferTexture2DEXT;
/*  990:     */   long glFramebufferTexture3DEXT;
/*  991:     */   long glFramebufferRenderbufferEXT;
/*  992:     */   long glGetFramebufferAttachmentParameterivEXT;
/*  993:     */   long glGenerateMipmapEXT;
/*  994:     */   long glProgramParameteriEXT;
/*  995:     */   long glFramebufferTextureEXT;
/*  996:     */   long glFramebufferTextureLayerEXT;
/*  997:     */   long glFramebufferTextureFaceEXT;
/*  998:     */   long glProgramEnvParameters4fvEXT;
/*  999:     */   long glProgramLocalParameters4fvEXT;
/* 1000:     */   long glVertexAttribI1iEXT;
/* 1001:     */   long glVertexAttribI2iEXT;
/* 1002:     */   long glVertexAttribI3iEXT;
/* 1003:     */   long glVertexAttribI4iEXT;
/* 1004:     */   long glVertexAttribI1uiEXT;
/* 1005:     */   long glVertexAttribI2uiEXT;
/* 1006:     */   long glVertexAttribI3uiEXT;
/* 1007:     */   long glVertexAttribI4uiEXT;
/* 1008:     */   long glVertexAttribI1ivEXT;
/* 1009:     */   long glVertexAttribI2ivEXT;
/* 1010:     */   long glVertexAttribI3ivEXT;
/* 1011:     */   long glVertexAttribI4ivEXT;
/* 1012:     */   long glVertexAttribI1uivEXT;
/* 1013:     */   long glVertexAttribI2uivEXT;
/* 1014:     */   long glVertexAttribI3uivEXT;
/* 1015:     */   long glVertexAttribI4uivEXT;
/* 1016:     */   long glVertexAttribI4bvEXT;
/* 1017:     */   long glVertexAttribI4svEXT;
/* 1018:     */   long glVertexAttribI4ubvEXT;
/* 1019:     */   long glVertexAttribI4usvEXT;
/* 1020:     */   long glVertexAttribIPointerEXT;
/* 1021:     */   long glGetVertexAttribIivEXT;
/* 1022:     */   long glGetVertexAttribIuivEXT;
/* 1023:     */   long glUniform1uiEXT;
/* 1024:     */   long glUniform2uiEXT;
/* 1025:     */   long glUniform3uiEXT;
/* 1026:     */   long glUniform4uiEXT;
/* 1027:     */   long glUniform1uivEXT;
/* 1028:     */   long glUniform2uivEXT;
/* 1029:     */   long glUniform3uivEXT;
/* 1030:     */   long glUniform4uivEXT;
/* 1031:     */   long glGetUniformuivEXT;
/* 1032:     */   long glBindFragDataLocationEXT;
/* 1033:     */   long glGetFragDataLocationEXT;
/* 1034:     */   long glMultiDrawArraysEXT;
/* 1035:     */   long glColorTableEXT;
/* 1036:     */   long glColorSubTableEXT;
/* 1037:     */   long glGetColorTableEXT;
/* 1038:     */   long glGetColorTableParameterivEXT;
/* 1039:     */   long glGetColorTableParameterfvEXT;
/* 1040:     */   long glPointParameterfEXT;
/* 1041:     */   long glPointParameterfvEXT;
/* 1042:     */   long glProvokingVertexEXT;
/* 1043:     */   long glSecondaryColor3bEXT;
/* 1044:     */   long glSecondaryColor3fEXT;
/* 1045:     */   long glSecondaryColor3dEXT;
/* 1046:     */   long glSecondaryColor3ubEXT;
/* 1047:     */   long glSecondaryColorPointerEXT;
/* 1048:     */   long glUseShaderProgramEXT;
/* 1049:     */   long glActiveProgramEXT;
/* 1050:     */   long glCreateShaderProgramEXT;
/* 1051:     */   long glBindImageTextureEXT;
/* 1052:     */   long glMemoryBarrierEXT;
/* 1053:     */   long glStencilClearTagEXT;
/* 1054:     */   long glActiveStencilFaceEXT;
/* 1055:     */   long glTexBufferEXT;
/* 1056:     */   long glClearColorIiEXT;
/* 1057:     */   long glClearColorIuiEXT;
/* 1058:     */   long glTexParameterIivEXT;
/* 1059:     */   long glTexParameterIuivEXT;
/* 1060:     */   long glGetTexParameterIivEXT;
/* 1061:     */   long glGetTexParameterIuivEXT;
/* 1062:     */   long glGetQueryObjecti64vEXT;
/* 1063:     */   long glGetQueryObjectui64vEXT;
/* 1064:     */   long glBindBufferRangeEXT;
/* 1065:     */   long glBindBufferOffsetEXT;
/* 1066:     */   long glBindBufferBaseEXT;
/* 1067:     */   long glBeginTransformFeedbackEXT;
/* 1068:     */   long glEndTransformFeedbackEXT;
/* 1069:     */   long glTransformFeedbackVaryingsEXT;
/* 1070:     */   long glGetTransformFeedbackVaryingEXT;
/* 1071:     */   long glVertexAttribL1dEXT;
/* 1072:     */   long glVertexAttribL2dEXT;
/* 1073:     */   long glVertexAttribL3dEXT;
/* 1074:     */   long glVertexAttribL4dEXT;
/* 1075:     */   long glVertexAttribL1dvEXT;
/* 1076:     */   long glVertexAttribL2dvEXT;
/* 1077:     */   long glVertexAttribL3dvEXT;
/* 1078:     */   long glVertexAttribL4dvEXT;
/* 1079:     */   long glVertexAttribLPointerEXT;
/* 1080:     */   long glGetVertexAttribLdvEXT;
/* 1081:     */   long glBeginVertexShaderEXT;
/* 1082:     */   long glEndVertexShaderEXT;
/* 1083:     */   long glBindVertexShaderEXT;
/* 1084:     */   long glGenVertexShadersEXT;
/* 1085:     */   long glDeleteVertexShaderEXT;
/* 1086:     */   long glShaderOp1EXT;
/* 1087:     */   long glShaderOp2EXT;
/* 1088:     */   long glShaderOp3EXT;
/* 1089:     */   long glSwizzleEXT;
/* 1090:     */   long glWriteMaskEXT;
/* 1091:     */   long glInsertComponentEXT;
/* 1092:     */   long glExtractComponentEXT;
/* 1093:     */   long glGenSymbolsEXT;
/* 1094:     */   long glSetInvariantEXT;
/* 1095:     */   long glSetLocalConstantEXT;
/* 1096:     */   long glVariantbvEXT;
/* 1097:     */   long glVariantsvEXT;
/* 1098:     */   long glVariantivEXT;
/* 1099:     */   long glVariantfvEXT;
/* 1100:     */   long glVariantdvEXT;
/* 1101:     */   long glVariantubvEXT;
/* 1102:     */   long glVariantusvEXT;
/* 1103:     */   long glVariantuivEXT;
/* 1104:     */   long glVariantPointerEXT;
/* 1105:     */   long glEnableVariantClientStateEXT;
/* 1106:     */   long glDisableVariantClientStateEXT;
/* 1107:     */   long glBindLightParameterEXT;
/* 1108:     */   long glBindMaterialParameterEXT;
/* 1109:     */   long glBindTexGenParameterEXT;
/* 1110:     */   long glBindTextureUnitParameterEXT;
/* 1111:     */   long glBindParameterEXT;
/* 1112:     */   long glIsVariantEnabledEXT;
/* 1113:     */   long glGetVariantBooleanvEXT;
/* 1114:     */   long glGetVariantIntegervEXT;
/* 1115:     */   long glGetVariantFloatvEXT;
/* 1116:     */   long glGetVariantPointervEXT;
/* 1117:     */   long glGetInvariantBooleanvEXT;
/* 1118:     */   long glGetInvariantIntegervEXT;
/* 1119:     */   long glGetInvariantFloatvEXT;
/* 1120:     */   long glGetLocalConstantBooleanvEXT;
/* 1121:     */   long glGetLocalConstantIntegervEXT;
/* 1122:     */   long glGetLocalConstantFloatvEXT;
/* 1123:     */   long glVertexWeightfEXT;
/* 1124:     */   long glVertexWeightPointerEXT;
/* 1125:     */   long glAccum;
/* 1126:     */   long glAlphaFunc;
/* 1127:     */   long glClearColor;
/* 1128:     */   long glClearAccum;
/* 1129:     */   long glClear;
/* 1130:     */   long glCallLists;
/* 1131:     */   long glCallList;
/* 1132:     */   long glBlendFunc;
/* 1133:     */   long glBitmap;
/* 1134:     */   long glBindTexture;
/* 1135:     */   long glPrioritizeTextures;
/* 1136:     */   long glAreTexturesResident;
/* 1137:     */   long glBegin;
/* 1138:     */   long glEnd;
/* 1139:     */   long glArrayElement;
/* 1140:     */   long glClearDepth;
/* 1141:     */   long glDeleteLists;
/* 1142:     */   long glDeleteTextures;
/* 1143:     */   long glCullFace;
/* 1144:     */   long glCopyTexSubImage2D;
/* 1145:     */   long glCopyTexSubImage1D;
/* 1146:     */   long glCopyTexImage2D;
/* 1147:     */   long glCopyTexImage1D;
/* 1148:     */   long glCopyPixels;
/* 1149:     */   long glColorPointer;
/* 1150:     */   long glColorMaterial;
/* 1151:     */   long glColorMask;
/* 1152:     */   long glColor3b;
/* 1153:     */   long glColor3f;
/* 1154:     */   long glColor3d;
/* 1155:     */   long glColor3ub;
/* 1156:     */   long glColor4b;
/* 1157:     */   long glColor4f;
/* 1158:     */   long glColor4d;
/* 1159:     */   long glColor4ub;
/* 1160:     */   long glClipPlane;
/* 1161:     */   long glClearStencil;
/* 1162:     */   long glEvalPoint1;
/* 1163:     */   long glEvalPoint2;
/* 1164:     */   long glEvalMesh1;
/* 1165:     */   long glEvalMesh2;
/* 1166:     */   long glEvalCoord1f;
/* 1167:     */   long glEvalCoord1d;
/* 1168:     */   long glEvalCoord2f;
/* 1169:     */   long glEvalCoord2d;
/* 1170:     */   long glEnableClientState;
/* 1171:     */   long glDisableClientState;
/* 1172:     */   long glEnable;
/* 1173:     */   long glDisable;
/* 1174:     */   long glEdgeFlagPointer;
/* 1175:     */   long glEdgeFlag;
/* 1176:     */   long glDrawPixels;
/* 1177:     */   long glDrawElements;
/* 1178:     */   long glDrawBuffer;
/* 1179:     */   long glDrawArrays;
/* 1180:     */   long glDepthRange;
/* 1181:     */   long glDepthMask;
/* 1182:     */   long glDepthFunc;
/* 1183:     */   long glFeedbackBuffer;
/* 1184:     */   long glGetPixelMapfv;
/* 1185:     */   long glGetPixelMapuiv;
/* 1186:     */   long glGetPixelMapusv;
/* 1187:     */   long glGetMaterialfv;
/* 1188:     */   long glGetMaterialiv;
/* 1189:     */   long glGetMapfv;
/* 1190:     */   long glGetMapdv;
/* 1191:     */   long glGetMapiv;
/* 1192:     */   long glGetLightfv;
/* 1193:     */   long glGetLightiv;
/* 1194:     */   long glGetError;
/* 1195:     */   long glGetClipPlane;
/* 1196:     */   long glGetBooleanv;
/* 1197:     */   long glGetDoublev;
/* 1198:     */   long glGetFloatv;
/* 1199:     */   long glGetIntegerv;
/* 1200:     */   long glGenTextures;
/* 1201:     */   long glGenLists;
/* 1202:     */   long glFrustum;
/* 1203:     */   long glFrontFace;
/* 1204:     */   long glFogf;
/* 1205:     */   long glFogi;
/* 1206:     */   long glFogfv;
/* 1207:     */   long glFogiv;
/* 1208:     */   long glFlush;
/* 1209:     */   long glFinish;
/* 1210:     */   long glGetPointerv;
/* 1211:     */   long glIsEnabled;
/* 1212:     */   long glInterleavedArrays;
/* 1213:     */   long glInitNames;
/* 1214:     */   long glHint;
/* 1215:     */   long glGetTexParameterfv;
/* 1216:     */   long glGetTexParameteriv;
/* 1217:     */   long glGetTexLevelParameterfv;
/* 1218:     */   long glGetTexLevelParameteriv;
/* 1219:     */   long glGetTexImage;
/* 1220:     */   long glGetTexGeniv;
/* 1221:     */   long glGetTexGenfv;
/* 1222:     */   long glGetTexGendv;
/* 1223:     */   long glGetTexEnviv;
/* 1224:     */   long glGetTexEnvfv;
/* 1225:     */   long glGetString;
/* 1226:     */   long glGetPolygonStipple;
/* 1227:     */   long glIsList;
/* 1228:     */   long glMaterialf;
/* 1229:     */   long glMateriali;
/* 1230:     */   long glMaterialfv;
/* 1231:     */   long glMaterialiv;
/* 1232:     */   long glMapGrid1f;
/* 1233:     */   long glMapGrid1d;
/* 1234:     */   long glMapGrid2f;
/* 1235:     */   long glMapGrid2d;
/* 1236:     */   long glMap2f;
/* 1237:     */   long glMap2d;
/* 1238:     */   long glMap1f;
/* 1239:     */   long glMap1d;
/* 1240:     */   long glLogicOp;
/* 1241:     */   long glLoadName;
/* 1242:     */   long glLoadMatrixf;
/* 1243:     */   long glLoadMatrixd;
/* 1244:     */   long glLoadIdentity;
/* 1245:     */   long glListBase;
/* 1246:     */   long glLineWidth;
/* 1247:     */   long glLineStipple;
/* 1248:     */   long glLightModelf;
/* 1249:     */   long glLightModeli;
/* 1250:     */   long glLightModelfv;
/* 1251:     */   long glLightModeliv;
/* 1252:     */   long glLightf;
/* 1253:     */   long glLighti;
/* 1254:     */   long glLightfv;
/* 1255:     */   long glLightiv;
/* 1256:     */   long glIsTexture;
/* 1257:     */   long glMatrixMode;
/* 1258:     */   long glPolygonStipple;
/* 1259:     */   long glPolygonOffset;
/* 1260:     */   long glPolygonMode;
/* 1261:     */   long glPointSize;
/* 1262:     */   long glPixelZoom;
/* 1263:     */   long glPixelTransferf;
/* 1264:     */   long glPixelTransferi;
/* 1265:     */   long glPixelStoref;
/* 1266:     */   long glPixelStorei;
/* 1267:     */   long glPixelMapfv;
/* 1268:     */   long glPixelMapuiv;
/* 1269:     */   long glPixelMapusv;
/* 1270:     */   long glPassThrough;
/* 1271:     */   long glOrtho;
/* 1272:     */   long glNormalPointer;
/* 1273:     */   long glNormal3b;
/* 1274:     */   long glNormal3f;
/* 1275:     */   long glNormal3d;
/* 1276:     */   long glNormal3i;
/* 1277:     */   long glNewList;
/* 1278:     */   long glEndList;
/* 1279:     */   long glMultMatrixf;
/* 1280:     */   long glMultMatrixd;
/* 1281:     */   long glShadeModel;
/* 1282:     */   long glSelectBuffer;
/* 1283:     */   long glScissor;
/* 1284:     */   long glScalef;
/* 1285:     */   long glScaled;
/* 1286:     */   long glRotatef;
/* 1287:     */   long glRotated;
/* 1288:     */   long glRenderMode;
/* 1289:     */   long glRectf;
/* 1290:     */   long glRectd;
/* 1291:     */   long glRecti;
/* 1292:     */   long glReadPixels;
/* 1293:     */   long glReadBuffer;
/* 1294:     */   long glRasterPos2f;
/* 1295:     */   long glRasterPos2d;
/* 1296:     */   long glRasterPos2i;
/* 1297:     */   long glRasterPos3f;
/* 1298:     */   long glRasterPos3d;
/* 1299:     */   long glRasterPos3i;
/* 1300:     */   long glRasterPos4f;
/* 1301:     */   long glRasterPos4d;
/* 1302:     */   long glRasterPos4i;
/* 1303:     */   long glPushName;
/* 1304:     */   long glPopName;
/* 1305:     */   long glPushMatrix;
/* 1306:     */   long glPopMatrix;
/* 1307:     */   long glPushClientAttrib;
/* 1308:     */   long glPopClientAttrib;
/* 1309:     */   long glPushAttrib;
/* 1310:     */   long glPopAttrib;
/* 1311:     */   long glStencilFunc;
/* 1312:     */   long glVertexPointer;
/* 1313:     */   long glVertex2f;
/* 1314:     */   long glVertex2d;
/* 1315:     */   long glVertex2i;
/* 1316:     */   long glVertex3f;
/* 1317:     */   long glVertex3d;
/* 1318:     */   long glVertex3i;
/* 1319:     */   long glVertex4f;
/* 1320:     */   long glVertex4d;
/* 1321:     */   long glVertex4i;
/* 1322:     */   long glTranslatef;
/* 1323:     */   long glTranslated;
/* 1324:     */   long glTexImage1D;
/* 1325:     */   long glTexImage2D;
/* 1326:     */   long glTexSubImage1D;
/* 1327:     */   long glTexSubImage2D;
/* 1328:     */   long glTexParameterf;
/* 1329:     */   long glTexParameteri;
/* 1330:     */   long glTexParameterfv;
/* 1331:     */   long glTexParameteriv;
/* 1332:     */   long glTexGenf;
/* 1333:     */   long glTexGend;
/* 1334:     */   long glTexGenfv;
/* 1335:     */   long glTexGendv;
/* 1336:     */   long glTexGeni;
/* 1337:     */   long glTexGeniv;
/* 1338:     */   long glTexEnvf;
/* 1339:     */   long glTexEnvi;
/* 1340:     */   long glTexEnvfv;
/* 1341:     */   long glTexEnviv;
/* 1342:     */   long glTexCoordPointer;
/* 1343:     */   long glTexCoord1f;
/* 1344:     */   long glTexCoord1d;
/* 1345:     */   long glTexCoord2f;
/* 1346:     */   long glTexCoord2d;
/* 1347:     */   long glTexCoord3f;
/* 1348:     */   long glTexCoord3d;
/* 1349:     */   long glTexCoord4f;
/* 1350:     */   long glTexCoord4d;
/* 1351:     */   long glStencilOp;
/* 1352:     */   long glStencilMask;
/* 1353:     */   long glViewport;
/* 1354:     */   long glDrawRangeElements;
/* 1355:     */   long glTexImage3D;
/* 1356:     */   long glTexSubImage3D;
/* 1357:     */   long glCopyTexSubImage3D;
/* 1358:     */   long glActiveTexture;
/* 1359:     */   long glClientActiveTexture;
/* 1360:     */   long glCompressedTexImage1D;
/* 1361:     */   long glCompressedTexImage2D;
/* 1362:     */   long glCompressedTexImage3D;
/* 1363:     */   long glCompressedTexSubImage1D;
/* 1364:     */   long glCompressedTexSubImage2D;
/* 1365:     */   long glCompressedTexSubImage3D;
/* 1366:     */   long glGetCompressedTexImage;
/* 1367:     */   long glMultiTexCoord1f;
/* 1368:     */   long glMultiTexCoord1d;
/* 1369:     */   long glMultiTexCoord2f;
/* 1370:     */   long glMultiTexCoord2d;
/* 1371:     */   long glMultiTexCoord3f;
/* 1372:     */   long glMultiTexCoord3d;
/* 1373:     */   long glMultiTexCoord4f;
/* 1374:     */   long glMultiTexCoord4d;
/* 1375:     */   long glLoadTransposeMatrixf;
/* 1376:     */   long glLoadTransposeMatrixd;
/* 1377:     */   long glMultTransposeMatrixf;
/* 1378:     */   long glMultTransposeMatrixd;
/* 1379:     */   long glSampleCoverage;
/* 1380:     */   long glBlendEquation;
/* 1381:     */   long glBlendColor;
/* 1382:     */   long glFogCoordf;
/* 1383:     */   long glFogCoordd;
/* 1384:     */   long glFogCoordPointer;
/* 1385:     */   long glMultiDrawArrays;
/* 1386:     */   long glPointParameteri;
/* 1387:     */   long glPointParameterf;
/* 1388:     */   long glPointParameteriv;
/* 1389:     */   long glPointParameterfv;
/* 1390:     */   long glSecondaryColor3b;
/* 1391:     */   long glSecondaryColor3f;
/* 1392:     */   long glSecondaryColor3d;
/* 1393:     */   long glSecondaryColor3ub;
/* 1394:     */   long glSecondaryColorPointer;
/* 1395:     */   long glBlendFuncSeparate;
/* 1396:     */   long glWindowPos2f;
/* 1397:     */   long glWindowPos2d;
/* 1398:     */   long glWindowPos2i;
/* 1399:     */   long glWindowPos3f;
/* 1400:     */   long glWindowPos3d;
/* 1401:     */   long glWindowPos3i;
/* 1402:     */   long glBindBuffer;
/* 1403:     */   long glDeleteBuffers;
/* 1404:     */   long glGenBuffers;
/* 1405:     */   long glIsBuffer;
/* 1406:     */   long glBufferData;
/* 1407:     */   long glBufferSubData;
/* 1408:     */   long glGetBufferSubData;
/* 1409:     */   long glMapBuffer;
/* 1410:     */   long glUnmapBuffer;
/* 1411:     */   long glGetBufferParameteriv;
/* 1412:     */   long glGetBufferPointerv;
/* 1413:     */   long glGenQueries;
/* 1414:     */   long glDeleteQueries;
/* 1415:     */   long glIsQuery;
/* 1416:     */   long glBeginQuery;
/* 1417:     */   long glEndQuery;
/* 1418:     */   long glGetQueryiv;
/* 1419:     */   long glGetQueryObjectiv;
/* 1420:     */   long glGetQueryObjectuiv;
/* 1421:     */   long glShaderSource;
/* 1422:     */   long glCreateShader;
/* 1423:     */   long glIsShader;
/* 1424:     */   long glCompileShader;
/* 1425:     */   long glDeleteShader;
/* 1426:     */   long glCreateProgram;
/* 1427:     */   long glIsProgram;
/* 1428:     */   long glAttachShader;
/* 1429:     */   long glDetachShader;
/* 1430:     */   long glLinkProgram;
/* 1431:     */   long glUseProgram;
/* 1432:     */   long glValidateProgram;
/* 1433:     */   long glDeleteProgram;
/* 1434:     */   long glUniform1f;
/* 1435:     */   long glUniform2f;
/* 1436:     */   long glUniform3f;
/* 1437:     */   long glUniform4f;
/* 1438:     */   long glUniform1i;
/* 1439:     */   long glUniform2i;
/* 1440:     */   long glUniform3i;
/* 1441:     */   long glUniform4i;
/* 1442:     */   long glUniform1fv;
/* 1443:     */   long glUniform2fv;
/* 1444:     */   long glUniform3fv;
/* 1445:     */   long glUniform4fv;
/* 1446:     */   long glUniform1iv;
/* 1447:     */   long glUniform2iv;
/* 1448:     */   long glUniform3iv;
/* 1449:     */   long glUniform4iv;
/* 1450:     */   long glUniformMatrix2fv;
/* 1451:     */   long glUniformMatrix3fv;
/* 1452:     */   long glUniformMatrix4fv;
/* 1453:     */   long glGetShaderiv;
/* 1454:     */   long glGetProgramiv;
/* 1455:     */   long glGetShaderInfoLog;
/* 1456:     */   long glGetProgramInfoLog;
/* 1457:     */   long glGetAttachedShaders;
/* 1458:     */   long glGetUniformLocation;
/* 1459:     */   long glGetActiveUniform;
/* 1460:     */   long glGetUniformfv;
/* 1461:     */   long glGetUniformiv;
/* 1462:     */   long glGetShaderSource;
/* 1463:     */   long glVertexAttrib1s;
/* 1464:     */   long glVertexAttrib1f;
/* 1465:     */   long glVertexAttrib1d;
/* 1466:     */   long glVertexAttrib2s;
/* 1467:     */   long glVertexAttrib2f;
/* 1468:     */   long glVertexAttrib2d;
/* 1469:     */   long glVertexAttrib3s;
/* 1470:     */   long glVertexAttrib3f;
/* 1471:     */   long glVertexAttrib3d;
/* 1472:     */   long glVertexAttrib4s;
/* 1473:     */   long glVertexAttrib4f;
/* 1474:     */   long glVertexAttrib4d;
/* 1475:     */   long glVertexAttrib4Nub;
/* 1476:     */   long glVertexAttribPointer;
/* 1477:     */   long glEnableVertexAttribArray;
/* 1478:     */   long glDisableVertexAttribArray;
/* 1479:     */   long glGetVertexAttribfv;
/* 1480:     */   long glGetVertexAttribdv;
/* 1481:     */   long glGetVertexAttribiv;
/* 1482:     */   long glGetVertexAttribPointerv;
/* 1483:     */   long glBindAttribLocation;
/* 1484:     */   long glGetActiveAttrib;
/* 1485:     */   long glGetAttribLocation;
/* 1486:     */   long glDrawBuffers;
/* 1487:     */   long glStencilOpSeparate;
/* 1488:     */   long glStencilFuncSeparate;
/* 1489:     */   long glStencilMaskSeparate;
/* 1490:     */   long glBlendEquationSeparate;
/* 1491:     */   long glUniformMatrix2x3fv;
/* 1492:     */   long glUniformMatrix3x2fv;
/* 1493:     */   long glUniformMatrix2x4fv;
/* 1494:     */   long glUniformMatrix4x2fv;
/* 1495:     */   long glUniformMatrix3x4fv;
/* 1496:     */   long glUniformMatrix4x3fv;
/* 1497:     */   long glGetStringi;
/* 1498:     */   long glClearBufferfv;
/* 1499:     */   long glClearBufferiv;
/* 1500:     */   long glClearBufferuiv;
/* 1501:     */   long glClearBufferfi;
/* 1502:     */   long glVertexAttribI1i;
/* 1503:     */   long glVertexAttribI2i;
/* 1504:     */   long glVertexAttribI3i;
/* 1505:     */   long glVertexAttribI4i;
/* 1506:     */   long glVertexAttribI1ui;
/* 1507:     */   long glVertexAttribI2ui;
/* 1508:     */   long glVertexAttribI3ui;
/* 1509:     */   long glVertexAttribI4ui;
/* 1510:     */   long glVertexAttribI1iv;
/* 1511:     */   long glVertexAttribI2iv;
/* 1512:     */   long glVertexAttribI3iv;
/* 1513:     */   long glVertexAttribI4iv;
/* 1514:     */   long glVertexAttribI1uiv;
/* 1515:     */   long glVertexAttribI2uiv;
/* 1516:     */   long glVertexAttribI3uiv;
/* 1517:     */   long glVertexAttribI4uiv;
/* 1518:     */   long glVertexAttribI4bv;
/* 1519:     */   long glVertexAttribI4sv;
/* 1520:     */   long glVertexAttribI4ubv;
/* 1521:     */   long glVertexAttribI4usv;
/* 1522:     */   long glVertexAttribIPointer;
/* 1523:     */   long glGetVertexAttribIiv;
/* 1524:     */   long glGetVertexAttribIuiv;
/* 1525:     */   long glUniform1ui;
/* 1526:     */   long glUniform2ui;
/* 1527:     */   long glUniform3ui;
/* 1528:     */   long glUniform4ui;
/* 1529:     */   long glUniform1uiv;
/* 1530:     */   long glUniform2uiv;
/* 1531:     */   long glUniform3uiv;
/* 1532:     */   long glUniform4uiv;
/* 1533:     */   long glGetUniformuiv;
/* 1534:     */   long glBindFragDataLocation;
/* 1535:     */   long glGetFragDataLocation;
/* 1536:     */   long glBeginConditionalRender;
/* 1537:     */   long glEndConditionalRender;
/* 1538:     */   long glMapBufferRange;
/* 1539:     */   long glFlushMappedBufferRange;
/* 1540:     */   long glClampColor;
/* 1541:     */   long glIsRenderbuffer;
/* 1542:     */   long glBindRenderbuffer;
/* 1543:     */   long glDeleteRenderbuffers;
/* 1544:     */   long glGenRenderbuffers;
/* 1545:     */   long glRenderbufferStorage;
/* 1546:     */   long glGetRenderbufferParameteriv;
/* 1547:     */   long glIsFramebuffer;
/* 1548:     */   long glBindFramebuffer;
/* 1549:     */   long glDeleteFramebuffers;
/* 1550:     */   long glGenFramebuffers;
/* 1551:     */   long glCheckFramebufferStatus;
/* 1552:     */   long glFramebufferTexture1D;
/* 1553:     */   long glFramebufferTexture2D;
/* 1554:     */   long glFramebufferTexture3D;
/* 1555:     */   long glFramebufferRenderbuffer;
/* 1556:     */   long glGetFramebufferAttachmentParameteriv;
/* 1557:     */   long glGenerateMipmap;
/* 1558:     */   long glRenderbufferStorageMultisample;
/* 1559:     */   long glBlitFramebuffer;
/* 1560:     */   long glTexParameterIiv;
/* 1561:     */   long glTexParameterIuiv;
/* 1562:     */   long glGetTexParameterIiv;
/* 1563:     */   long glGetTexParameterIuiv;
/* 1564:     */   long glFramebufferTextureLayer;
/* 1565:     */   long glColorMaski;
/* 1566:     */   long glGetBooleani_v;
/* 1567:     */   long glGetIntegeri_v;
/* 1568:     */   long glEnablei;
/* 1569:     */   long glDisablei;
/* 1570:     */   long glIsEnabledi;
/* 1571:     */   long glBindBufferRange;
/* 1572:     */   long glBindBufferBase;
/* 1573:     */   long glBeginTransformFeedback;
/* 1574:     */   long glEndTransformFeedback;
/* 1575:     */   long glTransformFeedbackVaryings;
/* 1576:     */   long glGetTransformFeedbackVarying;
/* 1577:     */   long glBindVertexArray;
/* 1578:     */   long glDeleteVertexArrays;
/* 1579:     */   long glGenVertexArrays;
/* 1580:     */   long glIsVertexArray;
/* 1581:     */   long glDrawArraysInstanced;
/* 1582:     */   long glDrawElementsInstanced;
/* 1583:     */   long glCopyBufferSubData;
/* 1584:     */   long glPrimitiveRestartIndex;
/* 1585:     */   long glTexBuffer;
/* 1586:     */   long glGetUniformIndices;
/* 1587:     */   long glGetActiveUniformsiv;
/* 1588:     */   long glGetActiveUniformName;
/* 1589:     */   long glGetUniformBlockIndex;
/* 1590:     */   long glGetActiveUniformBlockiv;
/* 1591:     */   long glGetActiveUniformBlockName;
/* 1592:     */   long glUniformBlockBinding;
/* 1593:     */   long glGetBufferParameteri64v;
/* 1594:     */   long glDrawElementsBaseVertex;
/* 1595:     */   long glDrawRangeElementsBaseVertex;
/* 1596:     */   long glDrawElementsInstancedBaseVertex;
/* 1597:     */   long glProvokingVertex;
/* 1598:     */   long glTexImage2DMultisample;
/* 1599:     */   long glTexImage3DMultisample;
/* 1600:     */   long glGetMultisamplefv;
/* 1601:     */   long glSampleMaski;
/* 1602:     */   long glFramebufferTexture;
/* 1603:     */   long glFenceSync;
/* 1604:     */   long glIsSync;
/* 1605:     */   long glDeleteSync;
/* 1606:     */   long glClientWaitSync;
/* 1607:     */   long glWaitSync;
/* 1608:     */   long glGetInteger64v;
/* 1609:     */   long glGetInteger64i_v;
/* 1610:     */   long glGetSynciv;
/* 1611:     */   long glBindFragDataLocationIndexed;
/* 1612:     */   long glGetFragDataIndex;
/* 1613:     */   long glGenSamplers;
/* 1614:     */   long glDeleteSamplers;
/* 1615:     */   long glIsSampler;
/* 1616:     */   long glBindSampler;
/* 1617:     */   long glSamplerParameteri;
/* 1618:     */   long glSamplerParameterf;
/* 1619:     */   long glSamplerParameteriv;
/* 1620:     */   long glSamplerParameterfv;
/* 1621:     */   long glSamplerParameterIiv;
/* 1622:     */   long glSamplerParameterIuiv;
/* 1623:     */   long glGetSamplerParameteriv;
/* 1624:     */   long glGetSamplerParameterfv;
/* 1625:     */   long glGetSamplerParameterIiv;
/* 1626:     */   long glGetSamplerParameterIuiv;
/* 1627:     */   long glQueryCounter;
/* 1628:     */   long glGetQueryObjecti64v;
/* 1629:     */   long glGetQueryObjectui64v;
/* 1630:     */   long glVertexAttribDivisor;
/* 1631:     */   long glVertexP2ui;
/* 1632:     */   long glVertexP3ui;
/* 1633:     */   long glVertexP4ui;
/* 1634:     */   long glVertexP2uiv;
/* 1635:     */   long glVertexP3uiv;
/* 1636:     */   long glVertexP4uiv;
/* 1637:     */   long glTexCoordP1ui;
/* 1638:     */   long glTexCoordP2ui;
/* 1639:     */   long glTexCoordP3ui;
/* 1640:     */   long glTexCoordP4ui;
/* 1641:     */   long glTexCoordP1uiv;
/* 1642:     */   long glTexCoordP2uiv;
/* 1643:     */   long glTexCoordP3uiv;
/* 1644:     */   long glTexCoordP4uiv;
/* 1645:     */   long glMultiTexCoordP1ui;
/* 1646:     */   long glMultiTexCoordP2ui;
/* 1647:     */   long glMultiTexCoordP3ui;
/* 1648:     */   long glMultiTexCoordP4ui;
/* 1649:     */   long glMultiTexCoordP1uiv;
/* 1650:     */   long glMultiTexCoordP2uiv;
/* 1651:     */   long glMultiTexCoordP3uiv;
/* 1652:     */   long glMultiTexCoordP4uiv;
/* 1653:     */   long glNormalP3ui;
/* 1654:     */   long glNormalP3uiv;
/* 1655:     */   long glColorP3ui;
/* 1656:     */   long glColorP4ui;
/* 1657:     */   long glColorP3uiv;
/* 1658:     */   long glColorP4uiv;
/* 1659:     */   long glSecondaryColorP3ui;
/* 1660:     */   long glSecondaryColorP3uiv;
/* 1661:     */   long glVertexAttribP1ui;
/* 1662:     */   long glVertexAttribP2ui;
/* 1663:     */   long glVertexAttribP3ui;
/* 1664:     */   long glVertexAttribP4ui;
/* 1665:     */   long glVertexAttribP1uiv;
/* 1666:     */   long glVertexAttribP2uiv;
/* 1667:     */   long glVertexAttribP3uiv;
/* 1668:     */   long glVertexAttribP4uiv;
/* 1669:     */   long glBlendEquationi;
/* 1670:     */   long glBlendEquationSeparatei;
/* 1671:     */   long glBlendFunci;
/* 1672:     */   long glBlendFuncSeparatei;
/* 1673:     */   long glDrawArraysIndirect;
/* 1674:     */   long glDrawElementsIndirect;
/* 1675:     */   long glUniform1d;
/* 1676:     */   long glUniform2d;
/* 1677:     */   long glUniform3d;
/* 1678:     */   long glUniform4d;
/* 1679:     */   long glUniform1dv;
/* 1680:     */   long glUniform2dv;
/* 1681:     */   long glUniform3dv;
/* 1682:     */   long glUniform4dv;
/* 1683:     */   long glUniformMatrix2dv;
/* 1684:     */   long glUniformMatrix3dv;
/* 1685:     */   long glUniformMatrix4dv;
/* 1686:     */   long glUniformMatrix2x3dv;
/* 1687:     */   long glUniformMatrix2x4dv;
/* 1688:     */   long glUniformMatrix3x2dv;
/* 1689:     */   long glUniformMatrix3x4dv;
/* 1690:     */   long glUniformMatrix4x2dv;
/* 1691:     */   long glUniformMatrix4x3dv;
/* 1692:     */   long glGetUniformdv;
/* 1693:     */   long glMinSampleShading;
/* 1694:     */   long glGetSubroutineUniformLocation;
/* 1695:     */   long glGetSubroutineIndex;
/* 1696:     */   long glGetActiveSubroutineUniformiv;
/* 1697:     */   long glGetActiveSubroutineUniformName;
/* 1698:     */   long glGetActiveSubroutineName;
/* 1699:     */   long glUniformSubroutinesuiv;
/* 1700:     */   long glGetUniformSubroutineuiv;
/* 1701:     */   long glGetProgramStageiv;
/* 1702:     */   long glPatchParameteri;
/* 1703:     */   long glPatchParameterfv;
/* 1704:     */   long glBindTransformFeedback;
/* 1705:     */   long glDeleteTransformFeedbacks;
/* 1706:     */   long glGenTransformFeedbacks;
/* 1707:     */   long glIsTransformFeedback;
/* 1708:     */   long glPauseTransformFeedback;
/* 1709:     */   long glResumeTransformFeedback;
/* 1710:     */   long glDrawTransformFeedback;
/* 1711:     */   long glDrawTransformFeedbackStream;
/* 1712:     */   long glBeginQueryIndexed;
/* 1713:     */   long glEndQueryIndexed;
/* 1714:     */   long glGetQueryIndexediv;
/* 1715:     */   long glReleaseShaderCompiler;
/* 1716:     */   long glShaderBinary;
/* 1717:     */   long glGetShaderPrecisionFormat;
/* 1718:     */   long glDepthRangef;
/* 1719:     */   long glClearDepthf;
/* 1720:     */   long glGetProgramBinary;
/* 1721:     */   long glProgramBinary;
/* 1722:     */   long glProgramParameteri;
/* 1723:     */   long glUseProgramStages;
/* 1724:     */   long glActiveShaderProgram;
/* 1725:     */   long glCreateShaderProgramv;
/* 1726:     */   long glBindProgramPipeline;
/* 1727:     */   long glDeleteProgramPipelines;
/* 1728:     */   long glGenProgramPipelines;
/* 1729:     */   long glIsProgramPipeline;
/* 1730:     */   long glGetProgramPipelineiv;
/* 1731:     */   long glProgramUniform1i;
/* 1732:     */   long glProgramUniform2i;
/* 1733:     */   long glProgramUniform3i;
/* 1734:     */   long glProgramUniform4i;
/* 1735:     */   long glProgramUniform1f;
/* 1736:     */   long glProgramUniform2f;
/* 1737:     */   long glProgramUniform3f;
/* 1738:     */   long glProgramUniform4f;
/* 1739:     */   long glProgramUniform1d;
/* 1740:     */   long glProgramUniform2d;
/* 1741:     */   long glProgramUniform3d;
/* 1742:     */   long glProgramUniform4d;
/* 1743:     */   long glProgramUniform1iv;
/* 1744:     */   long glProgramUniform2iv;
/* 1745:     */   long glProgramUniform3iv;
/* 1746:     */   long glProgramUniform4iv;
/* 1747:     */   long glProgramUniform1fv;
/* 1748:     */   long glProgramUniform2fv;
/* 1749:     */   long glProgramUniform3fv;
/* 1750:     */   long glProgramUniform4fv;
/* 1751:     */   long glProgramUniform1dv;
/* 1752:     */   long glProgramUniform2dv;
/* 1753:     */   long glProgramUniform3dv;
/* 1754:     */   long glProgramUniform4dv;
/* 1755:     */   long glProgramUniform1ui;
/* 1756:     */   long glProgramUniform2ui;
/* 1757:     */   long glProgramUniform3ui;
/* 1758:     */   long glProgramUniform4ui;
/* 1759:     */   long glProgramUniform1uiv;
/* 1760:     */   long glProgramUniform2uiv;
/* 1761:     */   long glProgramUniform3uiv;
/* 1762:     */   long glProgramUniform4uiv;
/* 1763:     */   long glProgramUniformMatrix2fv;
/* 1764:     */   long glProgramUniformMatrix3fv;
/* 1765:     */   long glProgramUniformMatrix4fv;
/* 1766:     */   long glProgramUniformMatrix2dv;
/* 1767:     */   long glProgramUniformMatrix3dv;
/* 1768:     */   long glProgramUniformMatrix4dv;
/* 1769:     */   long glProgramUniformMatrix2x3fv;
/* 1770:     */   long glProgramUniformMatrix3x2fv;
/* 1771:     */   long glProgramUniformMatrix2x4fv;
/* 1772:     */   long glProgramUniformMatrix4x2fv;
/* 1773:     */   long glProgramUniformMatrix3x4fv;
/* 1774:     */   long glProgramUniformMatrix4x3fv;
/* 1775:     */   long glProgramUniformMatrix2x3dv;
/* 1776:     */   long glProgramUniformMatrix3x2dv;
/* 1777:     */   long glProgramUniformMatrix2x4dv;
/* 1778:     */   long glProgramUniformMatrix4x2dv;
/* 1779:     */   long glProgramUniformMatrix3x4dv;
/* 1780:     */   long glProgramUniformMatrix4x3dv;
/* 1781:     */   long glValidateProgramPipeline;
/* 1782:     */   long glGetProgramPipelineInfoLog;
/* 1783:     */   long glVertexAttribL1d;
/* 1784:     */   long glVertexAttribL2d;
/* 1785:     */   long glVertexAttribL3d;
/* 1786:     */   long glVertexAttribL4d;
/* 1787:     */   long glVertexAttribL1dv;
/* 1788:     */   long glVertexAttribL2dv;
/* 1789:     */   long glVertexAttribL3dv;
/* 1790:     */   long glVertexAttribL4dv;
/* 1791:     */   long glVertexAttribLPointer;
/* 1792:     */   long glGetVertexAttribLdv;
/* 1793:     */   long glViewportArrayv;
/* 1794:     */   long glViewportIndexedf;
/* 1795:     */   long glViewportIndexedfv;
/* 1796:     */   long glScissorArrayv;
/* 1797:     */   long glScissorIndexed;
/* 1798:     */   long glScissorIndexedv;
/* 1799:     */   long glDepthRangeArrayv;
/* 1800:     */   long glDepthRangeIndexed;
/* 1801:     */   long glGetFloati_v;
/* 1802:     */   long glGetDoublei_v;
/* 1803:     */   long glGetActiveAtomicCounterBufferiv;
/* 1804:     */   long glTexStorage1D;
/* 1805:     */   long glTexStorage2D;
/* 1806:     */   long glTexStorage3D;
/* 1807:     */   long glDrawTransformFeedbackInstanced;
/* 1808:     */   long glDrawTransformFeedbackStreamInstanced;
/* 1809:     */   long glDrawArraysInstancedBaseInstance;
/* 1810:     */   long glDrawElementsInstancedBaseInstance;
/* 1811:     */   long glDrawElementsInstancedBaseVertexBaseInstance;
/* 1812:     */   long glBindImageTexture;
/* 1813:     */   long glMemoryBarrier;
/* 1814:     */   long glGetInternalformativ;
/* 1815:     */   long glClearBufferData;
/* 1816:     */   long glClearBufferSubData;
/* 1817:     */   long glDispatchCompute;
/* 1818:     */   long glDispatchComputeIndirect;
/* 1819:     */   long glCopyImageSubData;
/* 1820:     */   long glDebugMessageControl;
/* 1821:     */   long glDebugMessageInsert;
/* 1822:     */   long glDebugMessageCallback;
/* 1823:     */   long glGetDebugMessageLog;
/* 1824:     */   long glPushDebugGroup;
/* 1825:     */   long glPopDebugGroup;
/* 1826:     */   long glObjectLabel;
/* 1827:     */   long glGetObjectLabel;
/* 1828:     */   long glObjectPtrLabel;
/* 1829:     */   long glGetObjectPtrLabel;
/* 1830:     */   long glFramebufferParameteri;
/* 1831:     */   long glGetFramebufferParameteriv;
/* 1832:     */   long glGetInternalformati64v;
/* 1833:     */   long glInvalidateTexSubImage;
/* 1834:     */   long glInvalidateTexImage;
/* 1835:     */   long glInvalidateBufferSubData;
/* 1836:     */   long glInvalidateBufferData;
/* 1837:     */   long glInvalidateFramebuffer;
/* 1838:     */   long glInvalidateSubFramebuffer;
/* 1839:     */   long glMultiDrawArraysIndirect;
/* 1840:     */   long glMultiDrawElementsIndirect;
/* 1841:     */   long glGetProgramInterfaceiv;
/* 1842:     */   long glGetProgramResourceIndex;
/* 1843:     */   long glGetProgramResourceName;
/* 1844:     */   long glGetProgramResourceiv;
/* 1845:     */   long glGetProgramResourceLocation;
/* 1846:     */   long glGetProgramResourceLocationIndex;
/* 1847:     */   long glShaderStorageBlockBinding;
/* 1848:     */   long glTexBufferRange;
/* 1849:     */   long glTexStorage2DMultisample;
/* 1850:     */   long glTexStorage3DMultisample;
/* 1851:     */   long glTextureView;
/* 1852:     */   long glBindVertexBuffer;
/* 1853:     */   long glVertexAttribFormat;
/* 1854:     */   long glVertexAttribIFormat;
/* 1855:     */   long glVertexAttribLFormat;
/* 1856:     */   long glVertexAttribBinding;
/* 1857:     */   long glVertexBindingDivisor;
/* 1858:     */   long glFrameTerminatorGREMEDY;
/* 1859:     */   long glStringMarkerGREMEDY;
/* 1860:     */   long glMapTexture2DINTEL;
/* 1861:     */   long glUnmapTexture2DINTEL;
/* 1862:     */   long glSyncTextureINTEL;
/* 1863:     */   long glGetTextureHandleNV;
/* 1864:     */   long glGetTextureSamplerHandleNV;
/* 1865:     */   long glMakeTextureHandleResidentNV;
/* 1866:     */   long glMakeTextureHandleNonResidentNV;
/* 1867:     */   long glGetImageHandleNV;
/* 1868:     */   long glMakeImageHandleResidentNV;
/* 1869:     */   long glMakeImageHandleNonResidentNV;
/* 1870:     */   long glUniformHandleui64NV;
/* 1871:     */   long glUniformHandleui64vNV;
/* 1872:     */   long glProgramUniformHandleui64NV;
/* 1873:     */   long glProgramUniformHandleui64vNV;
/* 1874:     */   long glIsTextureHandleResidentNV;
/* 1875:     */   long glIsImageHandleResidentNV;
/* 1876:     */   long glBeginConditionalRenderNV;
/* 1877:     */   long glEndConditionalRenderNV;
/* 1878:     */   long glCopyImageSubDataNV;
/* 1879:     */   long glDepthRangedNV;
/* 1880:     */   long glClearDepthdNV;
/* 1881:     */   long glDepthBoundsdNV;
/* 1882:     */   long glDrawTextureNV;
/* 1883:     */   long glGetMapControlPointsNV;
/* 1884:     */   long glMapControlPointsNV;
/* 1885:     */   long glMapParameterfvNV;
/* 1886:     */   long glMapParameterivNV;
/* 1887:     */   long glGetMapParameterfvNV;
/* 1888:     */   long glGetMapParameterivNV;
/* 1889:     */   long glGetMapAttribParameterfvNV;
/* 1890:     */   long glGetMapAttribParameterivNV;
/* 1891:     */   long glEvalMapsNV;
/* 1892:     */   long glGetMultisamplefvNV;
/* 1893:     */   long glSampleMaskIndexedNV;
/* 1894:     */   long glTexRenderbufferNV;
/* 1895:     */   long glGenFencesNV;
/* 1896:     */   long glDeleteFencesNV;
/* 1897:     */   long glSetFenceNV;
/* 1898:     */   long glTestFenceNV;
/* 1899:     */   long glFinishFenceNV;
/* 1900:     */   long glIsFenceNV;
/* 1901:     */   long glGetFenceivNV;
/* 1902:     */   long glProgramNamedParameter4fNV;
/* 1903:     */   long glProgramNamedParameter4dNV;
/* 1904:     */   long glGetProgramNamedParameterfvNV;
/* 1905:     */   long glGetProgramNamedParameterdvNV;
/* 1906:     */   long glRenderbufferStorageMultisampleCoverageNV;
/* 1907:     */   long glProgramVertexLimitNV;
/* 1908:     */   long glProgramLocalParameterI4iNV;
/* 1909:     */   long glProgramLocalParameterI4ivNV;
/* 1910:     */   long glProgramLocalParametersI4ivNV;
/* 1911:     */   long glProgramLocalParameterI4uiNV;
/* 1912:     */   long glProgramLocalParameterI4uivNV;
/* 1913:     */   long glProgramLocalParametersI4uivNV;
/* 1914:     */   long glProgramEnvParameterI4iNV;
/* 1915:     */   long glProgramEnvParameterI4ivNV;
/* 1916:     */   long glProgramEnvParametersI4ivNV;
/* 1917:     */   long glProgramEnvParameterI4uiNV;
/* 1918:     */   long glProgramEnvParameterI4uivNV;
/* 1919:     */   long glProgramEnvParametersI4uivNV;
/* 1920:     */   long glGetProgramLocalParameterIivNV;
/* 1921:     */   long glGetProgramLocalParameterIuivNV;
/* 1922:     */   long glGetProgramEnvParameterIivNV;
/* 1923:     */   long glGetProgramEnvParameterIuivNV;
/* 1924:     */   long glUniform1i64NV;
/* 1925:     */   long glUniform2i64NV;
/* 1926:     */   long glUniform3i64NV;
/* 1927:     */   long glUniform4i64NV;
/* 1928:     */   long glUniform1i64vNV;
/* 1929:     */   long glUniform2i64vNV;
/* 1930:     */   long glUniform3i64vNV;
/* 1931:     */   long glUniform4i64vNV;
/* 1932:     */   long glUniform1ui64NV;
/* 1933:     */   long glUniform2ui64NV;
/* 1934:     */   long glUniform3ui64NV;
/* 1935:     */   long glUniform4ui64NV;
/* 1936:     */   long glUniform1ui64vNV;
/* 1937:     */   long glUniform2ui64vNV;
/* 1938:     */   long glUniform3ui64vNV;
/* 1939:     */   long glUniform4ui64vNV;
/* 1940:     */   long glGetUniformi64vNV;
/* 1941:     */   long glGetUniformui64vNV;
/* 1942:     */   long glProgramUniform1i64NV;
/* 1943:     */   long glProgramUniform2i64NV;
/* 1944:     */   long glProgramUniform3i64NV;
/* 1945:     */   long glProgramUniform4i64NV;
/* 1946:     */   long glProgramUniform1i64vNV;
/* 1947:     */   long glProgramUniform2i64vNV;
/* 1948:     */   long glProgramUniform3i64vNV;
/* 1949:     */   long glProgramUniform4i64vNV;
/* 1950:     */   long glProgramUniform1ui64NV;
/* 1951:     */   long glProgramUniform2ui64NV;
/* 1952:     */   long glProgramUniform3ui64NV;
/* 1953:     */   long glProgramUniform4ui64NV;
/* 1954:     */   long glProgramUniform1ui64vNV;
/* 1955:     */   long glProgramUniform2ui64vNV;
/* 1956:     */   long glProgramUniform3ui64vNV;
/* 1957:     */   long glProgramUniform4ui64vNV;
/* 1958:     */   long glVertex2hNV;
/* 1959:     */   long glVertex3hNV;
/* 1960:     */   long glVertex4hNV;
/* 1961:     */   long glNormal3hNV;
/* 1962:     */   long glColor3hNV;
/* 1963:     */   long glColor4hNV;
/* 1964:     */   long glTexCoord1hNV;
/* 1965:     */   long glTexCoord2hNV;
/* 1966:     */   long glTexCoord3hNV;
/* 1967:     */   long glTexCoord4hNV;
/* 1968:     */   long glMultiTexCoord1hNV;
/* 1969:     */   long glMultiTexCoord2hNV;
/* 1970:     */   long glMultiTexCoord3hNV;
/* 1971:     */   long glMultiTexCoord4hNV;
/* 1972:     */   long glFogCoordhNV;
/* 1973:     */   long glSecondaryColor3hNV;
/* 1974:     */   long glVertexWeighthNV;
/* 1975:     */   long glVertexAttrib1hNV;
/* 1976:     */   long glVertexAttrib2hNV;
/* 1977:     */   long glVertexAttrib3hNV;
/* 1978:     */   long glVertexAttrib4hNV;
/* 1979:     */   long glVertexAttribs1hvNV;
/* 1980:     */   long glVertexAttribs2hvNV;
/* 1981:     */   long glVertexAttribs3hvNV;
/* 1982:     */   long glVertexAttribs4hvNV;
/* 1983:     */   long glGenOcclusionQueriesNV;
/* 1984:     */   long glDeleteOcclusionQueriesNV;
/* 1985:     */   long glIsOcclusionQueryNV;
/* 1986:     */   long glBeginOcclusionQueryNV;
/* 1987:     */   long glEndOcclusionQueryNV;
/* 1988:     */   long glGetOcclusionQueryuivNV;
/* 1989:     */   long glGetOcclusionQueryivNV;
/* 1990:     */   long glProgramBufferParametersfvNV;
/* 1991:     */   long glProgramBufferParametersIivNV;
/* 1992:     */   long glProgramBufferParametersIuivNV;
/* 1993:     */   long glPathCommandsNV;
/* 1994:     */   long glPathCoordsNV;
/* 1995:     */   long glPathSubCommandsNV;
/* 1996:     */   long glPathSubCoordsNV;
/* 1997:     */   long glPathStringNV;
/* 1998:     */   long glPathGlyphsNV;
/* 1999:     */   long glPathGlyphRangeNV;
/* 2000:     */   long glWeightPathsNV;
/* 2001:     */   long glCopyPathNV;
/* 2002:     */   long glInterpolatePathsNV;
/* 2003:     */   long glTransformPathNV;
/* 2004:     */   long glPathParameterivNV;
/* 2005:     */   long glPathParameteriNV;
/* 2006:     */   long glPathParameterfvNV;
/* 2007:     */   long glPathParameterfNV;
/* 2008:     */   long glPathDashArrayNV;
/* 2009:     */   long glGenPathsNV;
/* 2010:     */   long glDeletePathsNV;
/* 2011:     */   long glIsPathNV;
/* 2012:     */   long glPathStencilFuncNV;
/* 2013:     */   long glPathStencilDepthOffsetNV;
/* 2014:     */   long glStencilFillPathNV;
/* 2015:     */   long glStencilStrokePathNV;
/* 2016:     */   long glStencilFillPathInstancedNV;
/* 2017:     */   long glStencilStrokePathInstancedNV;
/* 2018:     */   long glPathCoverDepthFuncNV;
/* 2019:     */   long glPathColorGenNV;
/* 2020:     */   long glPathTexGenNV;
/* 2021:     */   long glPathFogGenNV;
/* 2022:     */   long glCoverFillPathNV;
/* 2023:     */   long glCoverStrokePathNV;
/* 2024:     */   long glCoverFillPathInstancedNV;
/* 2025:     */   long glCoverStrokePathInstancedNV;
/* 2026:     */   long glGetPathParameterivNV;
/* 2027:     */   long glGetPathParameterfvNV;
/* 2028:     */   long glGetPathCommandsNV;
/* 2029:     */   long glGetPathCoordsNV;
/* 2030:     */   long glGetPathDashArrayNV;
/* 2031:     */   long glGetPathMetricsNV;
/* 2032:     */   long glGetPathMetricRangeNV;
/* 2033:     */   long glGetPathSpacingNV;
/* 2034:     */   long glGetPathColorGenivNV;
/* 2035:     */   long glGetPathColorGenfvNV;
/* 2036:     */   long glGetPathTexGenivNV;
/* 2037:     */   long glGetPathTexGenfvNV;
/* 2038:     */   long glIsPointInFillPathNV;
/* 2039:     */   long glIsPointInStrokePathNV;
/* 2040:     */   long glGetPathLengthNV;
/* 2041:     */   long glPointAlongPathNV;
/* 2042:     */   long glPixelDataRangeNV;
/* 2043:     */   long glFlushPixelDataRangeNV;
/* 2044:     */   long glPointParameteriNV;
/* 2045:     */   long glPointParameterivNV;
/* 2046:     */   long glPresentFrameKeyedNV;
/* 2047:     */   long glPresentFrameDualFillNV;
/* 2048:     */   long glGetVideoivNV;
/* 2049:     */   long glGetVideouivNV;
/* 2050:     */   long glGetVideoi64vNV;
/* 2051:     */   long glGetVideoui64vNV;
/* 2052:     */   long glPrimitiveRestartNV;
/* 2053:     */   long glPrimitiveRestartIndexNV;
/* 2054:     */   long glLoadProgramNV;
/* 2055:     */   long glBindProgramNV;
/* 2056:     */   long glDeleteProgramsNV;
/* 2057:     */   long glGenProgramsNV;
/* 2058:     */   long glGetProgramivNV;
/* 2059:     */   long glGetProgramStringNV;
/* 2060:     */   long glIsProgramNV;
/* 2061:     */   long glAreProgramsResidentNV;
/* 2062:     */   long glRequestResidentProgramsNV;
/* 2063:     */   long glCombinerParameterfNV;
/* 2064:     */   long glCombinerParameterfvNV;
/* 2065:     */   long glCombinerParameteriNV;
/* 2066:     */   long glCombinerParameterivNV;
/* 2067:     */   long glCombinerInputNV;
/* 2068:     */   long glCombinerOutputNV;
/* 2069:     */   long glFinalCombinerInputNV;
/* 2070:     */   long glGetCombinerInputParameterfvNV;
/* 2071:     */   long glGetCombinerInputParameterivNV;
/* 2072:     */   long glGetCombinerOutputParameterfvNV;
/* 2073:     */   long glGetCombinerOutputParameterivNV;
/* 2074:     */   long glGetFinalCombinerInputParameterfvNV;
/* 2075:     */   long glGetFinalCombinerInputParameterivNV;
/* 2076:     */   long glCombinerStageParameterfvNV;
/* 2077:     */   long glGetCombinerStageParameterfvNV;
/* 2078:     */   long glMakeBufferResidentNV;
/* 2079:     */   long glMakeBufferNonResidentNV;
/* 2080:     */   long glIsBufferResidentNV;
/* 2081:     */   long glMakeNamedBufferResidentNV;
/* 2082:     */   long glMakeNamedBufferNonResidentNV;
/* 2083:     */   long glIsNamedBufferResidentNV;
/* 2084:     */   long glGetBufferParameterui64vNV;
/* 2085:     */   long glGetNamedBufferParameterui64vNV;
/* 2086:     */   long glGetIntegerui64vNV;
/* 2087:     */   long glUniformui64NV;
/* 2088:     */   long glUniformui64vNV;
/* 2089:     */   long glProgramUniformui64NV;
/* 2090:     */   long glProgramUniformui64vNV;
/* 2091:     */   long glTextureBarrierNV;
/* 2092:     */   long glTexImage2DMultisampleCoverageNV;
/* 2093:     */   long glTexImage3DMultisampleCoverageNV;
/* 2094:     */   long glTextureImage2DMultisampleNV;
/* 2095:     */   long glTextureImage3DMultisampleNV;
/* 2096:     */   long glTextureImage2DMultisampleCoverageNV;
/* 2097:     */   long glTextureImage3DMultisampleCoverageNV;
/* 2098:     */   long glBindBufferRangeNV;
/* 2099:     */   long glBindBufferOffsetNV;
/* 2100:     */   long glBindBufferBaseNV;
/* 2101:     */   long glTransformFeedbackAttribsNV;
/* 2102:     */   long glTransformFeedbackVaryingsNV;
/* 2103:     */   long glBeginTransformFeedbackNV;
/* 2104:     */   long glEndTransformFeedbackNV;
/* 2105:     */   long glGetVaryingLocationNV;
/* 2106:     */   long glGetActiveVaryingNV;
/* 2107:     */   long glActiveVaryingNV;
/* 2108:     */   long glGetTransformFeedbackVaryingNV;
/* 2109:     */   long glBindTransformFeedbackNV;
/* 2110:     */   long glDeleteTransformFeedbacksNV;
/* 2111:     */   long glGenTransformFeedbacksNV;
/* 2112:     */   long glIsTransformFeedbackNV;
/* 2113:     */   long glPauseTransformFeedbackNV;
/* 2114:     */   long glResumeTransformFeedbackNV;
/* 2115:     */   long glDrawTransformFeedbackNV;
/* 2116:     */   long glVertexArrayRangeNV;
/* 2117:     */   long glFlushVertexArrayRangeNV;
/* 2118:     */   long glAllocateMemoryNV;
/* 2119:     */   long glFreeMemoryNV;
/* 2120:     */   long glVertexAttribL1i64NV;
/* 2121:     */   long glVertexAttribL2i64NV;
/* 2122:     */   long glVertexAttribL3i64NV;
/* 2123:     */   long glVertexAttribL4i64NV;
/* 2124:     */   long glVertexAttribL1i64vNV;
/* 2125:     */   long glVertexAttribL2i64vNV;
/* 2126:     */   long glVertexAttribL3i64vNV;
/* 2127:     */   long glVertexAttribL4i64vNV;
/* 2128:     */   long glVertexAttribL1ui64NV;
/* 2129:     */   long glVertexAttribL2ui64NV;
/* 2130:     */   long glVertexAttribL3ui64NV;
/* 2131:     */   long glVertexAttribL4ui64NV;
/* 2132:     */   long glVertexAttribL1ui64vNV;
/* 2133:     */   long glVertexAttribL2ui64vNV;
/* 2134:     */   long glVertexAttribL3ui64vNV;
/* 2135:     */   long glVertexAttribL4ui64vNV;
/* 2136:     */   long glGetVertexAttribLi64vNV;
/* 2137:     */   long glGetVertexAttribLui64vNV;
/* 2138:     */   long glVertexAttribLFormatNV;
/* 2139:     */   long glBufferAddressRangeNV;
/* 2140:     */   long glVertexFormatNV;
/* 2141:     */   long glNormalFormatNV;
/* 2142:     */   long glColorFormatNV;
/* 2143:     */   long glIndexFormatNV;
/* 2144:     */   long glTexCoordFormatNV;
/* 2145:     */   long glEdgeFlagFormatNV;
/* 2146:     */   long glSecondaryColorFormatNV;
/* 2147:     */   long glFogCoordFormatNV;
/* 2148:     */   long glVertexAttribFormatNV;
/* 2149:     */   long glVertexAttribIFormatNV;
/* 2150:     */   long glGetIntegerui64i_vNV;
/* 2151:     */   long glExecuteProgramNV;
/* 2152:     */   long glGetProgramParameterfvNV;
/* 2153:     */   long glGetProgramParameterdvNV;
/* 2154:     */   long glGetTrackMatrixivNV;
/* 2155:     */   long glGetVertexAttribfvNV;
/* 2156:     */   long glGetVertexAttribdvNV;
/* 2157:     */   long glGetVertexAttribivNV;
/* 2158:     */   long glGetVertexAttribPointervNV;
/* 2159:     */   long glProgramParameter4fNV;
/* 2160:     */   long glProgramParameter4dNV;
/* 2161:     */   long glProgramParameters4fvNV;
/* 2162:     */   long glProgramParameters4dvNV;
/* 2163:     */   long glTrackMatrixNV;
/* 2164:     */   long glVertexAttribPointerNV;
/* 2165:     */   long glVertexAttrib1sNV;
/* 2166:     */   long glVertexAttrib1fNV;
/* 2167:     */   long glVertexAttrib1dNV;
/* 2168:     */   long glVertexAttrib2sNV;
/* 2169:     */   long glVertexAttrib2fNV;
/* 2170:     */   long glVertexAttrib2dNV;
/* 2171:     */   long glVertexAttrib3sNV;
/* 2172:     */   long glVertexAttrib3fNV;
/* 2173:     */   long glVertexAttrib3dNV;
/* 2174:     */   long glVertexAttrib4sNV;
/* 2175:     */   long glVertexAttrib4fNV;
/* 2176:     */   long glVertexAttrib4dNV;
/* 2177:     */   long glVertexAttrib4ubNV;
/* 2178:     */   long glVertexAttribs1svNV;
/* 2179:     */   long glVertexAttribs1fvNV;
/* 2180:     */   long glVertexAttribs1dvNV;
/* 2181:     */   long glVertexAttribs2svNV;
/* 2182:     */   long glVertexAttribs2fvNV;
/* 2183:     */   long glVertexAttribs2dvNV;
/* 2184:     */   long glVertexAttribs3svNV;
/* 2185:     */   long glVertexAttribs3fvNV;
/* 2186:     */   long glVertexAttribs3dvNV;
/* 2187:     */   long glVertexAttribs4svNV;
/* 2188:     */   long glVertexAttribs4fvNV;
/* 2189:     */   long glVertexAttribs4dvNV;
/* 2190:     */   long glBeginVideoCaptureNV;
/* 2191:     */   long glBindVideoCaptureStreamBufferNV;
/* 2192:     */   long glBindVideoCaptureStreamTextureNV;
/* 2193:     */   long glEndVideoCaptureNV;
/* 2194:     */   long glGetVideoCaptureivNV;
/* 2195:     */   long glGetVideoCaptureStreamivNV;
/* 2196:     */   long glGetVideoCaptureStreamfvNV;
/* 2197:     */   long glGetVideoCaptureStreamdvNV;
/* 2198:     */   long glVideoCaptureNV;
/* 2199:     */   long glVideoCaptureStreamParameterivNV;
/* 2200:     */   long glVideoCaptureStreamParameterfvNV;
/* 2201:     */   long glVideoCaptureStreamParameterdvNV;
/* 2202:     */   
/* 2203:     */   private boolean AMD_debug_output_initNativeFunctionAddresses()
/* 2204:     */   {
/* 2205:2353 */     return ((this.glDebugMessageEnableAMD = GLContext.getFunctionAddress(new String[] { "glDebugMessageEnableAMD", "glDebugMessageEnableAMDX" })) != 0L ? 1 : 0) & ((this.glDebugMessageInsertAMD = GLContext.getFunctionAddress(new String[] { "glDebugMessageInsertAMD", "glDebugMessageInsertAMDX" })) != 0L ? 1 : 0) & ((this.glDebugMessageCallbackAMD = GLContext.getFunctionAddress(new String[] { "glDebugMessageCallbackAMD", "glDebugMessageCallbackAMDX" })) != 0L ? 1 : 0) & ((this.glGetDebugMessageLogAMD = GLContext.getFunctionAddress(new String[] { "glGetDebugMessageLogAMD", "glGetDebugMessageLogAMDX" })) != 0L ? 1 : 0);
/* 2206:     */   }
/* 2207:     */   
/* 2208:     */   private boolean AMD_draw_buffers_blend_initNativeFunctionAddresses()
/* 2209:     */   {
/* 2210:2361 */     return ((this.glBlendFuncIndexedAMD = GLContext.getFunctionAddress("glBlendFuncIndexedAMD")) != 0L ? 1 : 0) & ((this.glBlendFuncSeparateIndexedAMD = GLContext.getFunctionAddress("glBlendFuncSeparateIndexedAMD")) != 0L ? 1 : 0) & ((this.glBlendEquationIndexedAMD = GLContext.getFunctionAddress("glBlendEquationIndexedAMD")) != 0L ? 1 : 0) & ((this.glBlendEquationSeparateIndexedAMD = GLContext.getFunctionAddress("glBlendEquationSeparateIndexedAMD")) != 0L ? 1 : 0);
/* 2211:     */   }
/* 2212:     */   
/* 2213:     */   private boolean AMD_multi_draw_indirect_initNativeFunctionAddresses()
/* 2214:     */   {
/* 2215:2369 */     return ((this.glMultiDrawArraysIndirectAMD = GLContext.getFunctionAddress("glMultiDrawArraysIndirectAMD")) != 0L ? 1 : 0) & ((this.glMultiDrawElementsIndirectAMD = GLContext.getFunctionAddress("glMultiDrawElementsIndirectAMD")) != 0L ? 1 : 0);
/* 2216:     */   }
/* 2217:     */   
/* 2218:     */   private boolean AMD_name_gen_delete_initNativeFunctionAddresses()
/* 2219:     */   {
/* 2220:2375 */     return ((this.glGenNamesAMD = GLContext.getFunctionAddress("glGenNamesAMD")) != 0L ? 1 : 0) & ((this.glDeleteNamesAMD = GLContext.getFunctionAddress("glDeleteNamesAMD")) != 0L ? 1 : 0) & ((this.glIsNameAMD = GLContext.getFunctionAddress("glIsNameAMD")) != 0L ? 1 : 0);
/* 2221:     */   }
/* 2222:     */   
/* 2223:     */   private boolean AMD_performance_monitor_initNativeFunctionAddresses()
/* 2224:     */   {
/* 2225:2382 */     return ((this.glGetPerfMonitorGroupsAMD = GLContext.getFunctionAddress("glGetPerfMonitorGroupsAMD")) != 0L ? 1 : 0) & ((this.glGetPerfMonitorCountersAMD = GLContext.getFunctionAddress("glGetPerfMonitorCountersAMD")) != 0L ? 1 : 0) & ((this.glGetPerfMonitorGroupStringAMD = GLContext.getFunctionAddress("glGetPerfMonitorGroupStringAMD")) != 0L ? 1 : 0) & ((this.glGetPerfMonitorCounterStringAMD = GLContext.getFunctionAddress("glGetPerfMonitorCounterStringAMD")) != 0L ? 1 : 0) & ((this.glGetPerfMonitorCounterInfoAMD = GLContext.getFunctionAddress("glGetPerfMonitorCounterInfoAMD")) != 0L ? 1 : 0) & ((this.glGenPerfMonitorsAMD = GLContext.getFunctionAddress("glGenPerfMonitorsAMD")) != 0L ? 1 : 0) & ((this.glDeletePerfMonitorsAMD = GLContext.getFunctionAddress("glDeletePerfMonitorsAMD")) != 0L ? 1 : 0) & ((this.glSelectPerfMonitorCountersAMD = GLContext.getFunctionAddress("glSelectPerfMonitorCountersAMD")) != 0L ? 1 : 0) & ((this.glBeginPerfMonitorAMD = GLContext.getFunctionAddress("glBeginPerfMonitorAMD")) != 0L ? 1 : 0) & ((this.glEndPerfMonitorAMD = GLContext.getFunctionAddress("glEndPerfMonitorAMD")) != 0L ? 1 : 0) & ((this.glGetPerfMonitorCounterDataAMD = GLContext.getFunctionAddress("glGetPerfMonitorCounterDataAMD")) != 0L ? 1 : 0);
/* 2226:     */   }
/* 2227:     */   
/* 2228:     */   private boolean AMD_sample_positions_initNativeFunctionAddresses()
/* 2229:     */   {
/* 2230:2397 */     return (this.glSetMultisamplefvAMD = GLContext.getFunctionAddress("glSetMultisamplefvAMD")) != 0L;
/* 2231:     */   }
/* 2232:     */   
/* 2233:     */   private boolean AMD_sparse_texture_initNativeFunctionAddresses()
/* 2234:     */   {
/* 2235:2402 */     return ((this.glTexStorageSparseAMD = GLContext.getFunctionAddress("glTexStorageSparseAMD")) != 0L ? 1 : 0) & ((this.glTextureStorageSparseAMD = GLContext.getFunctionAddress("glTextureStorageSparseAMD")) != 0L ? 1 : 0);
/* 2236:     */   }
/* 2237:     */   
/* 2238:     */   private boolean AMD_stencil_operation_extended_initNativeFunctionAddresses()
/* 2239:     */   {
/* 2240:2408 */     return (this.glStencilOpValueAMD = GLContext.getFunctionAddress("glStencilOpValueAMD")) != 0L;
/* 2241:     */   }
/* 2242:     */   
/* 2243:     */   private boolean AMD_vertex_shader_tessellator_initNativeFunctionAddresses()
/* 2244:     */   {
/* 2245:2413 */     return ((this.glTessellationFactorAMD = GLContext.getFunctionAddress("glTessellationFactorAMD")) != 0L ? 1 : 0) & ((this.glTessellationModeAMD = GLContext.getFunctionAddress("glTessellationModeAMD")) != 0L ? 1 : 0);
/* 2246:     */   }
/* 2247:     */   
/* 2248:     */   private boolean APPLE_element_array_initNativeFunctionAddresses()
/* 2249:     */   {
/* 2250:2419 */     return ((this.glElementPointerAPPLE = GLContext.getFunctionAddress("glElementPointerAPPLE")) != 0L ? 1 : 0) & ((this.glDrawElementArrayAPPLE = GLContext.getFunctionAddress("glDrawElementArrayAPPLE")) != 0L ? 1 : 0) & ((this.glDrawRangeElementArrayAPPLE = GLContext.getFunctionAddress("glDrawRangeElementArrayAPPLE")) != 0L ? 1 : 0) & ((this.glMultiDrawElementArrayAPPLE = GLContext.getFunctionAddress("glMultiDrawElementArrayAPPLE")) != 0L ? 1 : 0) & ((this.glMultiDrawRangeElementArrayAPPLE = GLContext.getFunctionAddress("glMultiDrawRangeElementArrayAPPLE")) != 0L ? 1 : 0);
/* 2251:     */   }
/* 2252:     */   
/* 2253:     */   private boolean APPLE_fence_initNativeFunctionAddresses()
/* 2254:     */   {
/* 2255:2428 */     return ((this.glGenFencesAPPLE = GLContext.getFunctionAddress("glGenFencesAPPLE")) != 0L ? 1 : 0) & ((this.glDeleteFencesAPPLE = GLContext.getFunctionAddress("glDeleteFencesAPPLE")) != 0L ? 1 : 0) & ((this.glSetFenceAPPLE = GLContext.getFunctionAddress("glSetFenceAPPLE")) != 0L ? 1 : 0) & ((this.glIsFenceAPPLE = GLContext.getFunctionAddress("glIsFenceAPPLE")) != 0L ? 1 : 0) & ((this.glTestFenceAPPLE = GLContext.getFunctionAddress("glTestFenceAPPLE")) != 0L ? 1 : 0) & ((this.glFinishFenceAPPLE = GLContext.getFunctionAddress("glFinishFenceAPPLE")) != 0L ? 1 : 0) & ((this.glTestObjectAPPLE = GLContext.getFunctionAddress("glTestObjectAPPLE")) != 0L ? 1 : 0) & ((this.glFinishObjectAPPLE = GLContext.getFunctionAddress("glFinishObjectAPPLE")) != 0L ? 1 : 0);
/* 2256:     */   }
/* 2257:     */   
/* 2258:     */   private boolean APPLE_flush_buffer_range_initNativeFunctionAddresses()
/* 2259:     */   {
/* 2260:2440 */     return ((this.glBufferParameteriAPPLE = GLContext.getFunctionAddress("glBufferParameteriAPPLE")) != 0L ? 1 : 0) & ((this.glFlushMappedBufferRangeAPPLE = GLContext.getFunctionAddress("glFlushMappedBufferRangeAPPLE")) != 0L ? 1 : 0);
/* 2261:     */   }
/* 2262:     */   
/* 2263:     */   private boolean APPLE_object_purgeable_initNativeFunctionAddresses()
/* 2264:     */   {
/* 2265:2446 */     return ((this.glObjectPurgeableAPPLE = GLContext.getFunctionAddress("glObjectPurgeableAPPLE")) != 0L ? 1 : 0) & ((this.glObjectUnpurgeableAPPLE = GLContext.getFunctionAddress("glObjectUnpurgeableAPPLE")) != 0L ? 1 : 0) & ((this.glGetObjectParameterivAPPLE = GLContext.getFunctionAddress("glGetObjectParameterivAPPLE")) != 0L ? 1 : 0);
/* 2266:     */   }
/* 2267:     */   
/* 2268:     */   private boolean APPLE_texture_range_initNativeFunctionAddresses()
/* 2269:     */   {
/* 2270:2453 */     return ((this.glTextureRangeAPPLE = GLContext.getFunctionAddress("glTextureRangeAPPLE")) != 0L ? 1 : 0) & ((this.glGetTexParameterPointervAPPLE = GLContext.getFunctionAddress("glGetTexParameterPointervAPPLE")) != 0L ? 1 : 0);
/* 2271:     */   }
/* 2272:     */   
/* 2273:     */   private boolean APPLE_vertex_array_object_initNativeFunctionAddresses()
/* 2274:     */   {
/* 2275:2459 */     return ((this.glBindVertexArrayAPPLE = GLContext.getFunctionAddress("glBindVertexArrayAPPLE")) != 0L ? 1 : 0) & ((this.glDeleteVertexArraysAPPLE = GLContext.getFunctionAddress("glDeleteVertexArraysAPPLE")) != 0L ? 1 : 0) & ((this.glGenVertexArraysAPPLE = GLContext.getFunctionAddress("glGenVertexArraysAPPLE")) != 0L ? 1 : 0) & ((this.glIsVertexArrayAPPLE = GLContext.getFunctionAddress("glIsVertexArrayAPPLE")) != 0L ? 1 : 0);
/* 2276:     */   }
/* 2277:     */   
/* 2278:     */   private boolean APPLE_vertex_array_range_initNativeFunctionAddresses()
/* 2279:     */   {
/* 2280:2467 */     return ((this.glVertexArrayRangeAPPLE = GLContext.getFunctionAddress("glVertexArrayRangeAPPLE")) != 0L ? 1 : 0) & ((this.glFlushVertexArrayRangeAPPLE = GLContext.getFunctionAddress("glFlushVertexArrayRangeAPPLE")) != 0L ? 1 : 0) & ((this.glVertexArrayParameteriAPPLE = GLContext.getFunctionAddress("glVertexArrayParameteriAPPLE")) != 0L ? 1 : 0);
/* 2281:     */   }
/* 2282:     */   
/* 2283:     */   private boolean APPLE_vertex_program_evaluators_initNativeFunctionAddresses()
/* 2284:     */   {
/* 2285:2474 */     return ((this.glEnableVertexAttribAPPLE = GLContext.getFunctionAddress("glEnableVertexAttribAPPLE")) != 0L ? 1 : 0) & ((this.glDisableVertexAttribAPPLE = GLContext.getFunctionAddress("glDisableVertexAttribAPPLE")) != 0L ? 1 : 0) & ((this.glIsVertexAttribEnabledAPPLE = GLContext.getFunctionAddress("glIsVertexAttribEnabledAPPLE")) != 0L ? 1 : 0) & ((this.glMapVertexAttrib1dAPPLE = GLContext.getFunctionAddress("glMapVertexAttrib1dAPPLE")) != 0L ? 1 : 0) & ((this.glMapVertexAttrib1fAPPLE = GLContext.getFunctionAddress("glMapVertexAttrib1fAPPLE")) != 0L ? 1 : 0) & ((this.glMapVertexAttrib2dAPPLE = GLContext.getFunctionAddress("glMapVertexAttrib2dAPPLE")) != 0L ? 1 : 0) & ((this.glMapVertexAttrib2fAPPLE = GLContext.getFunctionAddress("glMapVertexAttrib2fAPPLE")) != 0L ? 1 : 0);
/* 2286:     */   }
/* 2287:     */   
/* 2288:     */   private boolean ARB_ES2_compatibility_initNativeFunctionAddresses()
/* 2289:     */   {
/* 2290:2485 */     return ((this.glReleaseShaderCompiler = GLContext.getFunctionAddress("glReleaseShaderCompiler")) != 0L ? 1 : 0) & ((this.glShaderBinary = GLContext.getFunctionAddress("glShaderBinary")) != 0L ? 1 : 0) & ((this.glGetShaderPrecisionFormat = GLContext.getFunctionAddress("glGetShaderPrecisionFormat")) != 0L ? 1 : 0) & ((this.glDepthRangef = GLContext.getFunctionAddress("glDepthRangef")) != 0L ? 1 : 0) & ((this.glClearDepthf = GLContext.getFunctionAddress("glClearDepthf")) != 0L ? 1 : 0);
/* 2291:     */   }
/* 2292:     */   
/* 2293:     */   private boolean ARB_base_instance_initNativeFunctionAddresses()
/* 2294:     */   {
/* 2295:2494 */     return ((this.glDrawArraysInstancedBaseInstance = GLContext.getFunctionAddress("glDrawArraysInstancedBaseInstance")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseInstance = GLContext.getFunctionAddress("glDrawElementsInstancedBaseInstance")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseVertexBaseInstance = GLContext.getFunctionAddress("glDrawElementsInstancedBaseVertexBaseInstance")) != 0L ? 1 : 0);
/* 2296:     */   }
/* 2297:     */   
/* 2298:     */   private boolean ARB_blend_func_extended_initNativeFunctionAddresses()
/* 2299:     */   {
/* 2300:2501 */     return ((this.glBindFragDataLocationIndexed = GLContext.getFunctionAddress("glBindFragDataLocationIndexed")) != 0L ? 1 : 0) & ((this.glGetFragDataIndex = GLContext.getFunctionAddress("glGetFragDataIndex")) != 0L ? 1 : 0);
/* 2301:     */   }
/* 2302:     */   
/* 2303:     */   private boolean ARB_buffer_object_initNativeFunctionAddresses()
/* 2304:     */   {
/* 2305:2507 */     return ((this.glBindBufferARB = GLContext.getFunctionAddress("glBindBufferARB")) != 0L ? 1 : 0) & ((this.glDeleteBuffersARB = GLContext.getFunctionAddress("glDeleteBuffersARB")) != 0L ? 1 : 0) & ((this.glGenBuffersARB = GLContext.getFunctionAddress("glGenBuffersARB")) != 0L ? 1 : 0) & ((this.glIsBufferARB = GLContext.getFunctionAddress("glIsBufferARB")) != 0L ? 1 : 0) & ((this.glBufferDataARB = GLContext.getFunctionAddress("glBufferDataARB")) != 0L ? 1 : 0) & ((this.glBufferSubDataARB = GLContext.getFunctionAddress("glBufferSubDataARB")) != 0L ? 1 : 0) & ((this.glGetBufferSubDataARB = GLContext.getFunctionAddress("glGetBufferSubDataARB")) != 0L ? 1 : 0) & ((this.glMapBufferARB = GLContext.getFunctionAddress("glMapBufferARB")) != 0L ? 1 : 0) & ((this.glUnmapBufferARB = GLContext.getFunctionAddress("glUnmapBufferARB")) != 0L ? 1 : 0) & ((this.glGetBufferParameterivARB = GLContext.getFunctionAddress("glGetBufferParameterivARB")) != 0L ? 1 : 0) & ((this.glGetBufferPointervARB = GLContext.getFunctionAddress("glGetBufferPointervARB")) != 0L ? 1 : 0);
/* 2306:     */   }
/* 2307:     */   
/* 2308:     */   private boolean ARB_cl_event_initNativeFunctionAddresses()
/* 2309:     */   {
/* 2310:2522 */     return (this.glCreateSyncFromCLeventARB = GLContext.getFunctionAddress("glCreateSyncFromCLeventARB")) != 0L;
/* 2311:     */   }
/* 2312:     */   
/* 2313:     */   private boolean ARB_clear_buffer_object_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2314:     */   {
/* 2315:2527 */     return ((this.glClearBufferData = GLContext.getFunctionAddress("glClearBufferData")) != 0L ? 1 : 0) & ((this.glClearBufferSubData = GLContext.getFunctionAddress("glClearBufferSubData")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glClearNamedBufferDataEXT = GLContext.getFunctionAddress("glClearNamedBufferDataEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glClearNamedBufferSubDataEXT = GLContext.getFunctionAddress("glClearNamedBufferSubDataEXT")) != 0L) ? 1 : 0);
/* 2316:     */   }
/* 2317:     */   
/* 2318:     */   private boolean ARB_color_buffer_float_initNativeFunctionAddresses()
/* 2319:     */   {
/* 2320:2535 */     return (this.glClampColorARB = GLContext.getFunctionAddress("glClampColorARB")) != 0L;
/* 2321:     */   }
/* 2322:     */   
/* 2323:     */   private boolean ARB_compute_shader_initNativeFunctionAddresses()
/* 2324:     */   {
/* 2325:2540 */     return ((this.glDispatchCompute = GLContext.getFunctionAddress("glDispatchCompute")) != 0L ? 1 : 0) & ((this.glDispatchComputeIndirect = GLContext.getFunctionAddress("glDispatchComputeIndirect")) != 0L ? 1 : 0);
/* 2326:     */   }
/* 2327:     */   
/* 2328:     */   private boolean ARB_copy_buffer_initNativeFunctionAddresses()
/* 2329:     */   {
/* 2330:2546 */     return (this.glCopyBufferSubData = GLContext.getFunctionAddress("glCopyBufferSubData")) != 0L;
/* 2331:     */   }
/* 2332:     */   
/* 2333:     */   private boolean ARB_copy_image_initNativeFunctionAddresses()
/* 2334:     */   {
/* 2335:2551 */     return (this.glCopyImageSubData = GLContext.getFunctionAddress("glCopyImageSubData")) != 0L;
/* 2336:     */   }
/* 2337:     */   
/* 2338:     */   private boolean ARB_debug_output_initNativeFunctionAddresses()
/* 2339:     */   {
/* 2340:2556 */     return ((this.glDebugMessageControlARB = GLContext.getFunctionAddress("glDebugMessageControlARB")) != 0L ? 1 : 0) & ((this.glDebugMessageInsertARB = GLContext.getFunctionAddress("glDebugMessageInsertARB")) != 0L ? 1 : 0) & ((this.glDebugMessageCallbackARB = GLContext.getFunctionAddress("glDebugMessageCallbackARB")) != 0L ? 1 : 0) & ((this.glGetDebugMessageLogARB = GLContext.getFunctionAddress("glGetDebugMessageLogARB")) != 0L ? 1 : 0);
/* 2341:     */   }
/* 2342:     */   
/* 2343:     */   private boolean ARB_draw_buffers_initNativeFunctionAddresses()
/* 2344:     */   {
/* 2345:2564 */     return (this.glDrawBuffersARB = GLContext.getFunctionAddress("glDrawBuffersARB")) != 0L;
/* 2346:     */   }
/* 2347:     */   
/* 2348:     */   private boolean ARB_draw_buffers_blend_initNativeFunctionAddresses()
/* 2349:     */   {
/* 2350:2569 */     return ((this.glBlendEquationiARB = GLContext.getFunctionAddress("glBlendEquationiARB")) != 0L ? 1 : 0) & ((this.glBlendEquationSeparateiARB = GLContext.getFunctionAddress("glBlendEquationSeparateiARB")) != 0L ? 1 : 0) & ((this.glBlendFunciARB = GLContext.getFunctionAddress("glBlendFunciARB")) != 0L ? 1 : 0) & ((this.glBlendFuncSeparateiARB = GLContext.getFunctionAddress("glBlendFuncSeparateiARB")) != 0L ? 1 : 0);
/* 2351:     */   }
/* 2352:     */   
/* 2353:     */   private boolean ARB_draw_elements_base_vertex_initNativeFunctionAddresses()
/* 2354:     */   {
/* 2355:2577 */     return ((this.glDrawElementsBaseVertex = GLContext.getFunctionAddress("glDrawElementsBaseVertex")) != 0L ? 1 : 0) & ((this.glDrawRangeElementsBaseVertex = GLContext.getFunctionAddress("glDrawRangeElementsBaseVertex")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseVertex = GLContext.getFunctionAddress("glDrawElementsInstancedBaseVertex")) != 0L ? 1 : 0);
/* 2356:     */   }
/* 2357:     */   
/* 2358:     */   private boolean ARB_draw_indirect_initNativeFunctionAddresses()
/* 2359:     */   {
/* 2360:2584 */     return ((this.glDrawArraysIndirect = GLContext.getFunctionAddress("glDrawArraysIndirect")) != 0L ? 1 : 0) & ((this.glDrawElementsIndirect = GLContext.getFunctionAddress("glDrawElementsIndirect")) != 0L ? 1 : 0);
/* 2361:     */   }
/* 2362:     */   
/* 2363:     */   private boolean ARB_draw_instanced_initNativeFunctionAddresses()
/* 2364:     */   {
/* 2365:2590 */     return ((this.glDrawArraysInstancedARB = GLContext.getFunctionAddress("glDrawArraysInstancedARB")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedARB = GLContext.getFunctionAddress("glDrawElementsInstancedARB")) != 0L ? 1 : 0);
/* 2366:     */   }
/* 2367:     */   
/* 2368:     */   private boolean ARB_framebuffer_no_attachments_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2369:     */   {
/* 2370:2596 */     return ((this.glFramebufferParameteri = GLContext.getFunctionAddress("glFramebufferParameteri")) != 0L ? 1 : 0) & ((this.glGetFramebufferParameteriv = GLContext.getFunctionAddress("glGetFramebufferParameteriv")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glNamedFramebufferParameteriEXT = GLContext.getFunctionAddress("glNamedFramebufferParameteriEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glGetNamedFramebufferParameterivEXT = GLContext.getFunctionAddress("glGetNamedFramebufferParameterivEXT")) != 0L) ? 1 : 0);
/* 2371:     */   }
/* 2372:     */   
/* 2373:     */   private boolean ARB_framebuffer_object_initNativeFunctionAddresses()
/* 2374:     */   {
/* 2375:2604 */     return ((this.glIsRenderbuffer = GLContext.getFunctionAddress("glIsRenderbuffer")) != 0L ? 1 : 0) & ((this.glBindRenderbuffer = GLContext.getFunctionAddress("glBindRenderbuffer")) != 0L ? 1 : 0) & ((this.glDeleteRenderbuffers = GLContext.getFunctionAddress("glDeleteRenderbuffers")) != 0L ? 1 : 0) & ((this.glGenRenderbuffers = GLContext.getFunctionAddress("glGenRenderbuffers")) != 0L ? 1 : 0) & ((this.glRenderbufferStorage = GLContext.getFunctionAddress("glRenderbufferStorage")) != 0L ? 1 : 0) & ((this.glRenderbufferStorageMultisample = GLContext.getFunctionAddress("glRenderbufferStorageMultisample")) != 0L ? 1 : 0) & ((this.glGetRenderbufferParameteriv = GLContext.getFunctionAddress("glGetRenderbufferParameteriv")) != 0L ? 1 : 0) & ((this.glIsFramebuffer = GLContext.getFunctionAddress("glIsFramebuffer")) != 0L ? 1 : 0) & ((this.glBindFramebuffer = GLContext.getFunctionAddress("glBindFramebuffer")) != 0L ? 1 : 0) & ((this.glDeleteFramebuffers = GLContext.getFunctionAddress("glDeleteFramebuffers")) != 0L ? 1 : 0) & ((this.glGenFramebuffers = GLContext.getFunctionAddress("glGenFramebuffers")) != 0L ? 1 : 0) & ((this.glCheckFramebufferStatus = GLContext.getFunctionAddress("glCheckFramebufferStatus")) != 0L ? 1 : 0) & ((this.glFramebufferTexture1D = GLContext.getFunctionAddress("glFramebufferTexture1D")) != 0L ? 1 : 0) & ((this.glFramebufferTexture2D = GLContext.getFunctionAddress("glFramebufferTexture2D")) != 0L ? 1 : 0) & ((this.glFramebufferTexture3D = GLContext.getFunctionAddress("glFramebufferTexture3D")) != 0L ? 1 : 0) & ((this.glFramebufferTextureLayer = GLContext.getFunctionAddress("glFramebufferTextureLayer")) != 0L ? 1 : 0) & ((this.glFramebufferRenderbuffer = GLContext.getFunctionAddress("glFramebufferRenderbuffer")) != 0L ? 1 : 0) & ((this.glGetFramebufferAttachmentParameteriv = GLContext.getFunctionAddress("glGetFramebufferAttachmentParameteriv")) != 0L ? 1 : 0) & ((this.glBlitFramebuffer = GLContext.getFunctionAddress("glBlitFramebuffer")) != 0L ? 1 : 0) & ((this.glGenerateMipmap = GLContext.getFunctionAddress("glGenerateMipmap")) != 0L ? 1 : 0);
/* 2376:     */   }
/* 2377:     */   
/* 2378:     */   private boolean ARB_geometry_shader4_initNativeFunctionAddresses()
/* 2379:     */   {
/* 2380:2628 */     return ((this.glProgramParameteriARB = GLContext.getFunctionAddress("glProgramParameteriARB")) != 0L ? 1 : 0) & ((this.glFramebufferTextureARB = GLContext.getFunctionAddress("glFramebufferTextureARB")) != 0L ? 1 : 0) & ((this.glFramebufferTextureLayerARB = GLContext.getFunctionAddress("glFramebufferTextureLayerARB")) != 0L ? 1 : 0) & ((this.glFramebufferTextureFaceARB = GLContext.getFunctionAddress("glFramebufferTextureFaceARB")) != 0L ? 1 : 0);
/* 2381:     */   }
/* 2382:     */   
/* 2383:     */   private boolean ARB_get_program_binary_initNativeFunctionAddresses()
/* 2384:     */   {
/* 2385:2636 */     return ((this.glGetProgramBinary = GLContext.getFunctionAddress("glGetProgramBinary")) != 0L ? 1 : 0) & ((this.glProgramBinary = GLContext.getFunctionAddress("glProgramBinary")) != 0L ? 1 : 0) & ((this.glProgramParameteri = GLContext.getFunctionAddress("glProgramParameteri")) != 0L ? 1 : 0);
/* 2386:     */   }
/* 2387:     */   
/* 2388:     */   private boolean ARB_gpu_shader_fp64_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2389:     */   {
/* 2390:2643 */     return ((this.glUniform1d = GLContext.getFunctionAddress("glUniform1d")) != 0L ? 1 : 0) & ((this.glUniform2d = GLContext.getFunctionAddress("glUniform2d")) != 0L ? 1 : 0) & ((this.glUniform3d = GLContext.getFunctionAddress("glUniform3d")) != 0L ? 1 : 0) & ((this.glUniform4d = GLContext.getFunctionAddress("glUniform4d")) != 0L ? 1 : 0) & ((this.glUniform1dv = GLContext.getFunctionAddress("glUniform1dv")) != 0L ? 1 : 0) & ((this.glUniform2dv = GLContext.getFunctionAddress("glUniform2dv")) != 0L ? 1 : 0) & ((this.glUniform3dv = GLContext.getFunctionAddress("glUniform3dv")) != 0L ? 1 : 0) & ((this.glUniform4dv = GLContext.getFunctionAddress("glUniform4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2dv = GLContext.getFunctionAddress("glUniformMatrix2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3dv = GLContext.getFunctionAddress("glUniformMatrix3dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4dv = GLContext.getFunctionAddress("glUniformMatrix4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2x3dv = GLContext.getFunctionAddress("glUniformMatrix2x3dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2x4dv = GLContext.getFunctionAddress("glUniformMatrix2x4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x2dv = GLContext.getFunctionAddress("glUniformMatrix3x2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x4dv = GLContext.getFunctionAddress("glUniformMatrix3x4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x2dv = GLContext.getFunctionAddress("glUniformMatrix4x2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x3dv = GLContext.getFunctionAddress("glUniformMatrix4x3dv")) != 0L ? 1 : 0) & ((this.glGetUniformdv = GLContext.getFunctionAddress("glGetUniformdv")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1dEXT = GLContext.getFunctionAddress("glProgramUniform1dEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2dEXT = GLContext.getFunctionAddress("glProgramUniform2dEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3dEXT = GLContext.getFunctionAddress("glProgramUniform3dEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4dEXT = GLContext.getFunctionAddress("glProgramUniform4dEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1dvEXT = GLContext.getFunctionAddress("glProgramUniform1dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2dvEXT = GLContext.getFunctionAddress("glProgramUniform2dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3dvEXT = GLContext.getFunctionAddress("glProgramUniform3dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4dvEXT = GLContext.getFunctionAddress("glProgramUniform4dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix2dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix3dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix4dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix2x3dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2x3dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix2x4dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2x4dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix3x2dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3x2dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix3x4dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3x4dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix4x2dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4x2dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniformMatrix4x3dvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4x3dvEXT")) != 0L) ? 1 : 0);
/* 2391:     */   }
/* 2392:     */   
/* 2393:     */   private boolean ARB_imaging_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2394:     */   {
/* 2395:2682 */     return ((forwardCompatible) || ((this.glColorTable = GLContext.getFunctionAddress("glColorTable")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorSubTable = GLContext.getFunctionAddress("glColorSubTable")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorTableParameteriv = GLContext.getFunctionAddress("glColorTableParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorTableParameterfv = GLContext.getFunctionAddress("glColorTableParameterfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glCopyColorSubTable = GLContext.getFunctionAddress("glCopyColorSubTable")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glCopyColorTable = GLContext.getFunctionAddress("glCopyColorTable")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetColorTable = GLContext.getFunctionAddress("glGetColorTable")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetColorTableParameteriv = GLContext.getFunctionAddress("glGetColorTableParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetColorTableParameterfv = GLContext.getFunctionAddress("glGetColorTableParameterfv")) != 0L) ? 1 : 0) & ((this.glBlendEquation = GLContext.getFunctionAddress("glBlendEquation")) != 0L ? 1 : 0) & ((this.glBlendColor = GLContext.getFunctionAddress("glBlendColor")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glHistogram = GLContext.getFunctionAddress("glHistogram")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glResetHistogram = GLContext.getFunctionAddress("glResetHistogram")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetHistogram = GLContext.getFunctionAddress("glGetHistogram")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetHistogramParameterfv = GLContext.getFunctionAddress("glGetHistogramParameterfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetHistogramParameteriv = GLContext.getFunctionAddress("glGetHistogramParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMinmax = GLContext.getFunctionAddress("glMinmax")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glResetMinmax = GLContext.getFunctionAddress("glResetMinmax")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMinmax = GLContext.getFunctionAddress("glGetMinmax")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMinmaxParameterfv = GLContext.getFunctionAddress("glGetMinmaxParameterfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMinmaxParameteriv = GLContext.getFunctionAddress("glGetMinmaxParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionFilter1D = GLContext.getFunctionAddress("glConvolutionFilter1D")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionFilter2D = GLContext.getFunctionAddress("glConvolutionFilter2D")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionParameterf = GLContext.getFunctionAddress("glConvolutionParameterf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionParameterfv = GLContext.getFunctionAddress("glConvolutionParameterfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionParameteri = GLContext.getFunctionAddress("glConvolutionParameteri")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glConvolutionParameteriv = GLContext.getFunctionAddress("glConvolutionParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glCopyConvolutionFilter1D = GLContext.getFunctionAddress("glCopyConvolutionFilter1D")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glCopyConvolutionFilter2D = GLContext.getFunctionAddress("glCopyConvolutionFilter2D")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetConvolutionFilter = GLContext.getFunctionAddress("glGetConvolutionFilter")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetConvolutionParameterfv = GLContext.getFunctionAddress("glGetConvolutionParameterfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetConvolutionParameteriv = GLContext.getFunctionAddress("glGetConvolutionParameteriv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSeparableFilter2D = GLContext.getFunctionAddress("glSeparableFilter2D")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetSeparableFilter = GLContext.getFunctionAddress("glGetSeparableFilter")) != 0L) ? 1 : 0);
/* 2396:     */   }
/* 2397:     */   
/* 2398:     */   private boolean ARB_instanced_arrays_initNativeFunctionAddresses()
/* 2399:     */   {
/* 2400:2720 */     return (this.glVertexAttribDivisorARB = GLContext.getFunctionAddress("glVertexAttribDivisorARB")) != 0L;
/* 2401:     */   }
/* 2402:     */   
/* 2403:     */   private boolean ARB_internalformat_query_initNativeFunctionAddresses()
/* 2404:     */   {
/* 2405:2725 */     return (this.glGetInternalformativ = GLContext.getFunctionAddress("glGetInternalformativ")) != 0L;
/* 2406:     */   }
/* 2407:     */   
/* 2408:     */   private boolean ARB_internalformat_query2_initNativeFunctionAddresses()
/* 2409:     */   {
/* 2410:2730 */     return (this.glGetInternalformati64v = GLContext.getFunctionAddress("glGetInternalformati64v")) != 0L;
/* 2411:     */   }
/* 2412:     */   
/* 2413:     */   private boolean ARB_invalidate_subdata_initNativeFunctionAddresses()
/* 2414:     */   {
/* 2415:2735 */     return ((this.glInvalidateTexSubImage = GLContext.getFunctionAddress("glInvalidateTexSubImage")) != 0L ? 1 : 0) & ((this.glInvalidateTexImage = GLContext.getFunctionAddress("glInvalidateTexImage")) != 0L ? 1 : 0) & ((this.glInvalidateBufferSubData = GLContext.getFunctionAddress("glInvalidateBufferSubData")) != 0L ? 1 : 0) & ((this.glInvalidateBufferData = GLContext.getFunctionAddress("glInvalidateBufferData")) != 0L ? 1 : 0) & ((this.glInvalidateFramebuffer = GLContext.getFunctionAddress("glInvalidateFramebuffer")) != 0L ? 1 : 0) & ((this.glInvalidateSubFramebuffer = GLContext.getFunctionAddress("glInvalidateSubFramebuffer")) != 0L ? 1 : 0);
/* 2416:     */   }
/* 2417:     */   
/* 2418:     */   private boolean ARB_map_buffer_range_initNativeFunctionAddresses()
/* 2419:     */   {
/* 2420:2745 */     return ((this.glMapBufferRange = GLContext.getFunctionAddress("glMapBufferRange")) != 0L ? 1 : 0) & ((this.glFlushMappedBufferRange = GLContext.getFunctionAddress("glFlushMappedBufferRange")) != 0L ? 1 : 0);
/* 2421:     */   }
/* 2422:     */   
/* 2423:     */   private boolean ARB_matrix_palette_initNativeFunctionAddresses()
/* 2424:     */   {
/* 2425:2751 */     return ((this.glCurrentPaletteMatrixARB = GLContext.getFunctionAddress("glCurrentPaletteMatrixARB")) != 0L ? 1 : 0) & ((this.glMatrixIndexPointerARB = GLContext.getFunctionAddress("glMatrixIndexPointerARB")) != 0L ? 1 : 0) & ((this.glMatrixIndexubvARB = GLContext.getFunctionAddress("glMatrixIndexubvARB")) != 0L ? 1 : 0) & ((this.glMatrixIndexusvARB = GLContext.getFunctionAddress("glMatrixIndexusvARB")) != 0L ? 1 : 0) & ((this.glMatrixIndexuivARB = GLContext.getFunctionAddress("glMatrixIndexuivARB")) != 0L ? 1 : 0);
/* 2426:     */   }
/* 2427:     */   
/* 2428:     */   private boolean ARB_multi_draw_indirect_initNativeFunctionAddresses()
/* 2429:     */   {
/* 2430:2760 */     return ((this.glMultiDrawArraysIndirect = GLContext.getFunctionAddress("glMultiDrawArraysIndirect")) != 0L ? 1 : 0) & ((this.glMultiDrawElementsIndirect = GLContext.getFunctionAddress("glMultiDrawElementsIndirect")) != 0L ? 1 : 0);
/* 2431:     */   }
/* 2432:     */   
/* 2433:     */   private boolean ARB_multisample_initNativeFunctionAddresses()
/* 2434:     */   {
/* 2435:2766 */     return (this.glSampleCoverageARB = GLContext.getFunctionAddress("glSampleCoverageARB")) != 0L;
/* 2436:     */   }
/* 2437:     */   
/* 2438:     */   private boolean ARB_multitexture_initNativeFunctionAddresses()
/* 2439:     */   {
/* 2440:2771 */     return ((this.glClientActiveTextureARB = GLContext.getFunctionAddress("glClientActiveTextureARB")) != 0L ? 1 : 0) & ((this.glActiveTextureARB = GLContext.getFunctionAddress("glActiveTextureARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord1fARB = GLContext.getFunctionAddress("glMultiTexCoord1fARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord1dARB = GLContext.getFunctionAddress("glMultiTexCoord1dARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord1iARB = GLContext.getFunctionAddress("glMultiTexCoord1iARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord1sARB = GLContext.getFunctionAddress("glMultiTexCoord1sARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord2fARB = GLContext.getFunctionAddress("glMultiTexCoord2fARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord2dARB = GLContext.getFunctionAddress("glMultiTexCoord2dARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord2iARB = GLContext.getFunctionAddress("glMultiTexCoord2iARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord2sARB = GLContext.getFunctionAddress("glMultiTexCoord2sARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord3fARB = GLContext.getFunctionAddress("glMultiTexCoord3fARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord3dARB = GLContext.getFunctionAddress("glMultiTexCoord3dARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord3iARB = GLContext.getFunctionAddress("glMultiTexCoord3iARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord3sARB = GLContext.getFunctionAddress("glMultiTexCoord3sARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord4fARB = GLContext.getFunctionAddress("glMultiTexCoord4fARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord4dARB = GLContext.getFunctionAddress("glMultiTexCoord4dARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord4iARB = GLContext.getFunctionAddress("glMultiTexCoord4iARB")) != 0L ? 1 : 0) & ((this.glMultiTexCoord4sARB = GLContext.getFunctionAddress("glMultiTexCoord4sARB")) != 0L ? 1 : 0);
/* 2441:     */   }
/* 2442:     */   
/* 2443:     */   private boolean ARB_occlusion_query_initNativeFunctionAddresses()
/* 2444:     */   {
/* 2445:2793 */     return ((this.glGenQueriesARB = GLContext.getFunctionAddress("glGenQueriesARB")) != 0L ? 1 : 0) & ((this.glDeleteQueriesARB = GLContext.getFunctionAddress("glDeleteQueriesARB")) != 0L ? 1 : 0) & ((this.glIsQueryARB = GLContext.getFunctionAddress("glIsQueryARB")) != 0L ? 1 : 0) & ((this.glBeginQueryARB = GLContext.getFunctionAddress("glBeginQueryARB")) != 0L ? 1 : 0) & ((this.glEndQueryARB = GLContext.getFunctionAddress("glEndQueryARB")) != 0L ? 1 : 0) & ((this.glGetQueryivARB = GLContext.getFunctionAddress("glGetQueryivARB")) != 0L ? 1 : 0) & ((this.glGetQueryObjectivARB = GLContext.getFunctionAddress("glGetQueryObjectivARB")) != 0L ? 1 : 0) & ((this.glGetQueryObjectuivARB = GLContext.getFunctionAddress("glGetQueryObjectuivARB")) != 0L ? 1 : 0);
/* 2446:     */   }
/* 2447:     */   
/* 2448:     */   private boolean ARB_point_parameters_initNativeFunctionAddresses()
/* 2449:     */   {
/* 2450:2805 */     return ((this.glPointParameterfARB = GLContext.getFunctionAddress("glPointParameterfARB")) != 0L ? 1 : 0) & ((this.glPointParameterfvARB = GLContext.getFunctionAddress("glPointParameterfvARB")) != 0L ? 1 : 0);
/* 2451:     */   }
/* 2452:     */   
/* 2453:     */   private boolean ARB_program_initNativeFunctionAddresses()
/* 2454:     */   {
/* 2455:2811 */     return ((this.glProgramStringARB = GLContext.getFunctionAddress("glProgramStringARB")) != 0L ? 1 : 0) & ((this.glBindProgramARB = GLContext.getFunctionAddress("glBindProgramARB")) != 0L ? 1 : 0) & ((this.glDeleteProgramsARB = GLContext.getFunctionAddress("glDeleteProgramsARB")) != 0L ? 1 : 0) & ((this.glGenProgramsARB = GLContext.getFunctionAddress("glGenProgramsARB")) != 0L ? 1 : 0) & ((this.glProgramEnvParameter4fARB = GLContext.getFunctionAddress("glProgramEnvParameter4fARB")) != 0L ? 1 : 0) & ((this.glProgramEnvParameter4dARB = GLContext.getFunctionAddress("glProgramEnvParameter4dARB")) != 0L ? 1 : 0) & ((this.glProgramEnvParameter4fvARB = GLContext.getFunctionAddress("glProgramEnvParameter4fvARB")) != 0L ? 1 : 0) & ((this.glProgramEnvParameter4dvARB = GLContext.getFunctionAddress("glProgramEnvParameter4dvARB")) != 0L ? 1 : 0) & ((this.glProgramLocalParameter4fARB = GLContext.getFunctionAddress("glProgramLocalParameter4fARB")) != 0L ? 1 : 0) & ((this.glProgramLocalParameter4dARB = GLContext.getFunctionAddress("glProgramLocalParameter4dARB")) != 0L ? 1 : 0) & ((this.glProgramLocalParameter4fvARB = GLContext.getFunctionAddress("glProgramLocalParameter4fvARB")) != 0L ? 1 : 0) & ((this.glProgramLocalParameter4dvARB = GLContext.getFunctionAddress("glProgramLocalParameter4dvARB")) != 0L ? 1 : 0) & ((this.glGetProgramEnvParameterfvARB = GLContext.getFunctionAddress("glGetProgramEnvParameterfvARB")) != 0L ? 1 : 0) & ((this.glGetProgramEnvParameterdvARB = GLContext.getFunctionAddress("glGetProgramEnvParameterdvARB")) != 0L ? 1 : 0) & ((this.glGetProgramLocalParameterfvARB = GLContext.getFunctionAddress("glGetProgramLocalParameterfvARB")) != 0L ? 1 : 0) & ((this.glGetProgramLocalParameterdvARB = GLContext.getFunctionAddress("glGetProgramLocalParameterdvARB")) != 0L ? 1 : 0) & ((this.glGetProgramivARB = GLContext.getFunctionAddress("glGetProgramivARB")) != 0L ? 1 : 0) & ((this.glGetProgramStringARB = GLContext.getFunctionAddress("glGetProgramStringARB")) != 0L ? 1 : 0) & ((this.glIsProgramARB = GLContext.getFunctionAddress("glIsProgramARB")) != 0L ? 1 : 0);
/* 2456:     */   }
/* 2457:     */   
/* 2458:     */   private boolean ARB_program_interface_query_initNativeFunctionAddresses()
/* 2459:     */   {
/* 2460:2834 */     return ((this.glGetProgramInterfaceiv = GLContext.getFunctionAddress("glGetProgramInterfaceiv")) != 0L ? 1 : 0) & ((this.glGetProgramResourceIndex = GLContext.getFunctionAddress("glGetProgramResourceIndex")) != 0L ? 1 : 0) & ((this.glGetProgramResourceName = GLContext.getFunctionAddress("glGetProgramResourceName")) != 0L ? 1 : 0) & ((this.glGetProgramResourceiv = GLContext.getFunctionAddress("glGetProgramResourceiv")) != 0L ? 1 : 0) & ((this.glGetProgramResourceLocation = GLContext.getFunctionAddress("glGetProgramResourceLocation")) != 0L ? 1 : 0) & ((this.glGetProgramResourceLocationIndex = GLContext.getFunctionAddress("glGetProgramResourceLocationIndex")) != 0L ? 1 : 0);
/* 2461:     */   }
/* 2462:     */   
/* 2463:     */   private boolean ARB_provoking_vertex_initNativeFunctionAddresses()
/* 2464:     */   {
/* 2465:2844 */     return (this.glProvokingVertex = GLContext.getFunctionAddress("glProvokingVertex")) != 0L;
/* 2466:     */   }
/* 2467:     */   
/* 2468:     */   private boolean ARB_robustness_initNativeFunctionAddresses(boolean forwardCompatible, Set<String> supported_extensions)
/* 2469:     */   {
/* 2470:2849 */     return ((this.glGetGraphicsResetStatusARB = GLContext.getFunctionAddress("glGetGraphicsResetStatusARB")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glGetnMapdvARB = GLContext.getFunctionAddress("glGetnMapdvARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnMapfvARB = GLContext.getFunctionAddress("glGetnMapfvARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnMapivARB = GLContext.getFunctionAddress("glGetnMapivARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnPixelMapfvARB = GLContext.getFunctionAddress("glGetnPixelMapfvARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnPixelMapuivARB = GLContext.getFunctionAddress("glGetnPixelMapuivARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnPixelMapusvARB = GLContext.getFunctionAddress("glGetnPixelMapusvARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetnPolygonStippleARB = GLContext.getFunctionAddress("glGetnPolygonStippleARB")) != 0L) ? 1 : 0) & ((this.glGetnTexImageARB = GLContext.getFunctionAddress("glGetnTexImageARB")) != 0L ? 1 : 0) & ((this.glReadnPixelsARB = GLContext.getFunctionAddress("glReadnPixelsARB")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_imaging")) || ((this.glGetnColorTableARB = GLContext.getFunctionAddress("glGetnColorTableARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_imaging")) || ((this.glGetnConvolutionFilterARB = GLContext.getFunctionAddress("glGetnConvolutionFilterARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_imaging")) || ((this.glGetnSeparableFilterARB = GLContext.getFunctionAddress("glGetnSeparableFilterARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_imaging")) || ((this.glGetnHistogramARB = GLContext.getFunctionAddress("glGetnHistogramARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_imaging")) || ((this.glGetnMinmaxARB = GLContext.getFunctionAddress("glGetnMinmaxARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetnCompressedTexImageARB = GLContext.getFunctionAddress("glGetnCompressedTexImageARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glGetnUniformfvARB = GLContext.getFunctionAddress("glGetnUniformfvARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glGetnUniformivARB = GLContext.getFunctionAddress("glGetnUniformivARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glGetnUniformuivARB = GLContext.getFunctionAddress("glGetnUniformuivARB")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glGetnUniformdvARB = GLContext.getFunctionAddress("glGetnUniformdvARB")) != 0L) ? 1 : 0);
/* 2471:     */   }
/* 2472:     */   
/* 2473:     */   private boolean ARB_sample_shading_initNativeFunctionAddresses()
/* 2474:     */   {
/* 2475:2873 */     return (this.glMinSampleShadingARB = GLContext.getFunctionAddress("glMinSampleShadingARB")) != 0L;
/* 2476:     */   }
/* 2477:     */   
/* 2478:     */   private boolean ARB_sampler_objects_initNativeFunctionAddresses()
/* 2479:     */   {
/* 2480:2878 */     return ((this.glGenSamplers = GLContext.getFunctionAddress("glGenSamplers")) != 0L ? 1 : 0) & ((this.glDeleteSamplers = GLContext.getFunctionAddress("glDeleteSamplers")) != 0L ? 1 : 0) & ((this.glIsSampler = GLContext.getFunctionAddress("glIsSampler")) != 0L ? 1 : 0) & ((this.glBindSampler = GLContext.getFunctionAddress("glBindSampler")) != 0L ? 1 : 0) & ((this.glSamplerParameteri = GLContext.getFunctionAddress("glSamplerParameteri")) != 0L ? 1 : 0) & ((this.glSamplerParameterf = GLContext.getFunctionAddress("glSamplerParameterf")) != 0L ? 1 : 0) & ((this.glSamplerParameteriv = GLContext.getFunctionAddress("glSamplerParameteriv")) != 0L ? 1 : 0) & ((this.glSamplerParameterfv = GLContext.getFunctionAddress("glSamplerParameterfv")) != 0L ? 1 : 0) & ((this.glSamplerParameterIiv = GLContext.getFunctionAddress("glSamplerParameterIiv")) != 0L ? 1 : 0) & ((this.glSamplerParameterIuiv = GLContext.getFunctionAddress("glSamplerParameterIuiv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameteriv = GLContext.getFunctionAddress("glGetSamplerParameteriv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterfv = GLContext.getFunctionAddress("glGetSamplerParameterfv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterIiv = GLContext.getFunctionAddress("glGetSamplerParameterIiv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterIuiv = GLContext.getFunctionAddress("glGetSamplerParameterIuiv")) != 0L ? 1 : 0);
/* 2481:     */   }
/* 2482:     */   
/* 2483:     */   private boolean ARB_separate_shader_objects_initNativeFunctionAddresses()
/* 2484:     */   {
/* 2485:2896 */     return ((this.glUseProgramStages = GLContext.getFunctionAddress("glUseProgramStages")) != 0L ? 1 : 0) & ((this.glActiveShaderProgram = GLContext.getFunctionAddress("glActiveShaderProgram")) != 0L ? 1 : 0) & ((this.glCreateShaderProgramv = GLContext.getFunctionAddress("glCreateShaderProgramv")) != 0L ? 1 : 0) & ((this.glBindProgramPipeline = GLContext.getFunctionAddress("glBindProgramPipeline")) != 0L ? 1 : 0) & ((this.glDeleteProgramPipelines = GLContext.getFunctionAddress("glDeleteProgramPipelines")) != 0L ? 1 : 0) & ((this.glGenProgramPipelines = GLContext.getFunctionAddress("glGenProgramPipelines")) != 0L ? 1 : 0) & ((this.glIsProgramPipeline = GLContext.getFunctionAddress("glIsProgramPipeline")) != 0L ? 1 : 0) & ((this.glProgramParameteri = GLContext.getFunctionAddress("glProgramParameteri")) != 0L ? 1 : 0) & ((this.glGetProgramPipelineiv = GLContext.getFunctionAddress("glGetProgramPipelineiv")) != 0L ? 1 : 0) & ((this.glProgramUniform1i = GLContext.getFunctionAddress("glProgramUniform1i")) != 0L ? 1 : 0) & ((this.glProgramUniform2i = GLContext.getFunctionAddress("glProgramUniform2i")) != 0L ? 1 : 0) & ((this.glProgramUniform3i = GLContext.getFunctionAddress("glProgramUniform3i")) != 0L ? 1 : 0) & ((this.glProgramUniform4i = GLContext.getFunctionAddress("glProgramUniform4i")) != 0L ? 1 : 0) & ((this.glProgramUniform1f = GLContext.getFunctionAddress("glProgramUniform1f")) != 0L ? 1 : 0) & ((this.glProgramUniform2f = GLContext.getFunctionAddress("glProgramUniform2f")) != 0L ? 1 : 0) & ((this.glProgramUniform3f = GLContext.getFunctionAddress("glProgramUniform3f")) != 0L ? 1 : 0) & ((this.glProgramUniform4f = GLContext.getFunctionAddress("glProgramUniform4f")) != 0L ? 1 : 0) & ((this.glProgramUniform1d = GLContext.getFunctionAddress("glProgramUniform1d")) != 0L ? 1 : 0) & ((this.glProgramUniform2d = GLContext.getFunctionAddress("glProgramUniform2d")) != 0L ? 1 : 0) & ((this.glProgramUniform3d = GLContext.getFunctionAddress("glProgramUniform3d")) != 0L ? 1 : 0) & ((this.glProgramUniform4d = GLContext.getFunctionAddress("glProgramUniform4d")) != 0L ? 1 : 0) & ((this.glProgramUniform1iv = GLContext.getFunctionAddress("glProgramUniform1iv")) != 0L ? 1 : 0) & ((this.glProgramUniform2iv = GLContext.getFunctionAddress("glProgramUniform2iv")) != 0L ? 1 : 0) & ((this.glProgramUniform3iv = GLContext.getFunctionAddress("glProgramUniform3iv")) != 0L ? 1 : 0) & ((this.glProgramUniform4iv = GLContext.getFunctionAddress("glProgramUniform4iv")) != 0L ? 1 : 0) & ((this.glProgramUniform1fv = GLContext.getFunctionAddress("glProgramUniform1fv")) != 0L ? 1 : 0) & ((this.glProgramUniform2fv = GLContext.getFunctionAddress("glProgramUniform2fv")) != 0L ? 1 : 0) & ((this.glProgramUniform3fv = GLContext.getFunctionAddress("glProgramUniform3fv")) != 0L ? 1 : 0) & ((this.glProgramUniform4fv = GLContext.getFunctionAddress("glProgramUniform4fv")) != 0L ? 1 : 0) & ((this.glProgramUniform1dv = GLContext.getFunctionAddress("glProgramUniform1dv")) != 0L ? 1 : 0) & ((this.glProgramUniform2dv = GLContext.getFunctionAddress("glProgramUniform2dv")) != 0L ? 1 : 0) & ((this.glProgramUniform3dv = GLContext.getFunctionAddress("glProgramUniform3dv")) != 0L ? 1 : 0) & ((this.glProgramUniform4dv = GLContext.getFunctionAddress("glProgramUniform4dv")) != 0L ? 1 : 0) & ((this.glProgramUniform1ui = GLContext.getFunctionAddress("glProgramUniform1ui")) != 0L ? 1 : 0) & ((this.glProgramUniform2ui = GLContext.getFunctionAddress("glProgramUniform2ui")) != 0L ? 1 : 0) & ((this.glProgramUniform3ui = GLContext.getFunctionAddress("glProgramUniform3ui")) != 0L ? 1 : 0) & ((this.glProgramUniform4ui = GLContext.getFunctionAddress("glProgramUniform4ui")) != 0L ? 1 : 0) & ((this.glProgramUniform1uiv = GLContext.getFunctionAddress("glProgramUniform1uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform2uiv = GLContext.getFunctionAddress("glProgramUniform2uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform3uiv = GLContext.getFunctionAddress("glProgramUniform3uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform4uiv = GLContext.getFunctionAddress("glProgramUniform4uiv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2fv = GLContext.getFunctionAddress("glProgramUniformMatrix2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3fv = GLContext.getFunctionAddress("glProgramUniformMatrix3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4fv = GLContext.getFunctionAddress("glProgramUniformMatrix4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2dv = GLContext.getFunctionAddress("glProgramUniformMatrix2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3dv = GLContext.getFunctionAddress("glProgramUniformMatrix3dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4dv = GLContext.getFunctionAddress("glProgramUniformMatrix4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x3fv = GLContext.getFunctionAddress("glProgramUniformMatrix2x3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x2fv = GLContext.getFunctionAddress("glProgramUniformMatrix3x2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x4fv = GLContext.getFunctionAddress("glProgramUniformMatrix2x4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x2fv = GLContext.getFunctionAddress("glProgramUniformMatrix4x2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x4fv = GLContext.getFunctionAddress("glProgramUniformMatrix3x4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x3fv = GLContext.getFunctionAddress("glProgramUniformMatrix4x3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x3dv = GLContext.getFunctionAddress("glProgramUniformMatrix2x3dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x2dv = GLContext.getFunctionAddress("glProgramUniformMatrix3x2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x4dv = GLContext.getFunctionAddress("glProgramUniformMatrix2x4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x2dv = GLContext.getFunctionAddress("glProgramUniformMatrix4x2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x4dv = GLContext.getFunctionAddress("glProgramUniformMatrix3x4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x3dv = GLContext.getFunctionAddress("glProgramUniformMatrix4x3dv")) != 0L ? 1 : 0) & ((this.glValidateProgramPipeline = GLContext.getFunctionAddress("glValidateProgramPipeline")) != 0L ? 1 : 0) & ((this.glGetProgramPipelineInfoLog = GLContext.getFunctionAddress("glGetProgramPipelineInfoLog")) != 0L ? 1 : 0);
/* 2486:     */   }
/* 2487:     */   
/* 2488:     */   private boolean ARB_shader_atomic_counters_initNativeFunctionAddresses()
/* 2489:     */   {
/* 2490:2961 */     return (this.glGetActiveAtomicCounterBufferiv = GLContext.getFunctionAddress("glGetActiveAtomicCounterBufferiv")) != 0L;
/* 2491:     */   }
/* 2492:     */   
/* 2493:     */   private boolean ARB_shader_image_load_store_initNativeFunctionAddresses()
/* 2494:     */   {
/* 2495:2966 */     return ((this.glBindImageTexture = GLContext.getFunctionAddress("glBindImageTexture")) != 0L ? 1 : 0) & ((this.glMemoryBarrier = GLContext.getFunctionAddress("glMemoryBarrier")) != 0L ? 1 : 0);
/* 2496:     */   }
/* 2497:     */   
/* 2498:     */   private boolean ARB_shader_objects_initNativeFunctionAddresses()
/* 2499:     */   {
/* 2500:2972 */     return ((this.glDeleteObjectARB = GLContext.getFunctionAddress("glDeleteObjectARB")) != 0L ? 1 : 0) & ((this.glGetHandleARB = GLContext.getFunctionAddress("glGetHandleARB")) != 0L ? 1 : 0) & ((this.glDetachObjectARB = GLContext.getFunctionAddress("glDetachObjectARB")) != 0L ? 1 : 0) & ((this.glCreateShaderObjectARB = GLContext.getFunctionAddress("glCreateShaderObjectARB")) != 0L ? 1 : 0) & ((this.glShaderSourceARB = GLContext.getFunctionAddress("glShaderSourceARB")) != 0L ? 1 : 0) & ((this.glCompileShaderARB = GLContext.getFunctionAddress("glCompileShaderARB")) != 0L ? 1 : 0) & ((this.glCreateProgramObjectARB = GLContext.getFunctionAddress("glCreateProgramObjectARB")) != 0L ? 1 : 0) & ((this.glAttachObjectARB = GLContext.getFunctionAddress("glAttachObjectARB")) != 0L ? 1 : 0) & ((this.glLinkProgramARB = GLContext.getFunctionAddress("glLinkProgramARB")) != 0L ? 1 : 0) & ((this.glUseProgramObjectARB = GLContext.getFunctionAddress("glUseProgramObjectARB")) != 0L ? 1 : 0) & ((this.glValidateProgramARB = GLContext.getFunctionAddress("glValidateProgramARB")) != 0L ? 1 : 0) & ((this.glUniform1fARB = GLContext.getFunctionAddress("glUniform1fARB")) != 0L ? 1 : 0) & ((this.glUniform2fARB = GLContext.getFunctionAddress("glUniform2fARB")) != 0L ? 1 : 0) & ((this.glUniform3fARB = GLContext.getFunctionAddress("glUniform3fARB")) != 0L ? 1 : 0) & ((this.glUniform4fARB = GLContext.getFunctionAddress("glUniform4fARB")) != 0L ? 1 : 0) & ((this.glUniform1iARB = GLContext.getFunctionAddress("glUniform1iARB")) != 0L ? 1 : 0) & ((this.glUniform2iARB = GLContext.getFunctionAddress("glUniform2iARB")) != 0L ? 1 : 0) & ((this.glUniform3iARB = GLContext.getFunctionAddress("glUniform3iARB")) != 0L ? 1 : 0) & ((this.glUniform4iARB = GLContext.getFunctionAddress("glUniform4iARB")) != 0L ? 1 : 0) & ((this.glUniform1fvARB = GLContext.getFunctionAddress("glUniform1fvARB")) != 0L ? 1 : 0) & ((this.glUniform2fvARB = GLContext.getFunctionAddress("glUniform2fvARB")) != 0L ? 1 : 0) & ((this.glUniform3fvARB = GLContext.getFunctionAddress("glUniform3fvARB")) != 0L ? 1 : 0) & ((this.glUniform4fvARB = GLContext.getFunctionAddress("glUniform4fvARB")) != 0L ? 1 : 0) & ((this.glUniform1ivARB = GLContext.getFunctionAddress("glUniform1ivARB")) != 0L ? 1 : 0) & ((this.glUniform2ivARB = GLContext.getFunctionAddress("glUniform2ivARB")) != 0L ? 1 : 0) & ((this.glUniform3ivARB = GLContext.getFunctionAddress("glUniform3ivARB")) != 0L ? 1 : 0) & ((this.glUniform4ivARB = GLContext.getFunctionAddress("glUniform4ivARB")) != 0L ? 1 : 0) & ((this.glUniformMatrix2fvARB = GLContext.getFunctionAddress("glUniformMatrix2fvARB")) != 0L ? 1 : 0) & ((this.glUniformMatrix3fvARB = GLContext.getFunctionAddress("glUniformMatrix3fvARB")) != 0L ? 1 : 0) & ((this.glUniformMatrix4fvARB = GLContext.getFunctionAddress("glUniformMatrix4fvARB")) != 0L ? 1 : 0) & ((this.glGetObjectParameterfvARB = GLContext.getFunctionAddress("glGetObjectParameterfvARB")) != 0L ? 1 : 0) & ((this.glGetObjectParameterivARB = GLContext.getFunctionAddress("glGetObjectParameterivARB")) != 0L ? 1 : 0) & ((this.glGetInfoLogARB = GLContext.getFunctionAddress("glGetInfoLogARB")) != 0L ? 1 : 0) & ((this.glGetAttachedObjectsARB = GLContext.getFunctionAddress("glGetAttachedObjectsARB")) != 0L ? 1 : 0) & ((this.glGetUniformLocationARB = GLContext.getFunctionAddress("glGetUniformLocationARB")) != 0L ? 1 : 0) & ((this.glGetActiveUniformARB = GLContext.getFunctionAddress("glGetActiveUniformARB")) != 0L ? 1 : 0) & ((this.glGetUniformfvARB = GLContext.getFunctionAddress("glGetUniformfvARB")) != 0L ? 1 : 0) & ((this.glGetUniformivARB = GLContext.getFunctionAddress("glGetUniformivARB")) != 0L ? 1 : 0) & ((this.glGetShaderSourceARB = GLContext.getFunctionAddress("glGetShaderSourceARB")) != 0L ? 1 : 0);
/* 2501:     */   }
/* 2502:     */   
/* 2503:     */   private boolean ARB_shader_storage_buffer_object_initNativeFunctionAddresses()
/* 2504:     */   {
/* 2505:3015 */     return (this.glShaderStorageBlockBinding = GLContext.getFunctionAddress("glShaderStorageBlockBinding")) != 0L;
/* 2506:     */   }
/* 2507:     */   
/* 2508:     */   private boolean ARB_shader_subroutine_initNativeFunctionAddresses()
/* 2509:     */   {
/* 2510:3020 */     return ((this.glGetSubroutineUniformLocation = GLContext.getFunctionAddress("glGetSubroutineUniformLocation")) != 0L ? 1 : 0) & ((this.glGetSubroutineIndex = GLContext.getFunctionAddress("glGetSubroutineIndex")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineUniformiv = GLContext.getFunctionAddress("glGetActiveSubroutineUniformiv")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineUniformName = GLContext.getFunctionAddress("glGetActiveSubroutineUniformName")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineName = GLContext.getFunctionAddress("glGetActiveSubroutineName")) != 0L ? 1 : 0) & ((this.glUniformSubroutinesuiv = GLContext.getFunctionAddress("glUniformSubroutinesuiv")) != 0L ? 1 : 0) & ((this.glGetUniformSubroutineuiv = GLContext.getFunctionAddress("glGetUniformSubroutineuiv")) != 0L ? 1 : 0) & ((this.glGetProgramStageiv = GLContext.getFunctionAddress("glGetProgramStageiv")) != 0L ? 1 : 0);
/* 2511:     */   }
/* 2512:     */   
/* 2513:     */   private boolean ARB_shading_language_include_initNativeFunctionAddresses()
/* 2514:     */   {
/* 2515:3032 */     return ((this.glNamedStringARB = GLContext.getFunctionAddress("glNamedStringARB")) != 0L ? 1 : 0) & ((this.glDeleteNamedStringARB = GLContext.getFunctionAddress("glDeleteNamedStringARB")) != 0L ? 1 : 0) & ((this.glCompileShaderIncludeARB = GLContext.getFunctionAddress("glCompileShaderIncludeARB")) != 0L ? 1 : 0) & ((this.glIsNamedStringARB = GLContext.getFunctionAddress("glIsNamedStringARB")) != 0L ? 1 : 0) & ((this.glGetNamedStringARB = GLContext.getFunctionAddress("glGetNamedStringARB")) != 0L ? 1 : 0) & ((this.glGetNamedStringivARB = GLContext.getFunctionAddress("glGetNamedStringivARB")) != 0L ? 1 : 0);
/* 2516:     */   }
/* 2517:     */   
/* 2518:     */   private boolean ARB_sync_initNativeFunctionAddresses()
/* 2519:     */   {
/* 2520:3042 */     return ((this.glFenceSync = GLContext.getFunctionAddress("glFenceSync")) != 0L ? 1 : 0) & ((this.glIsSync = GLContext.getFunctionAddress("glIsSync")) != 0L ? 1 : 0) & ((this.glDeleteSync = GLContext.getFunctionAddress("glDeleteSync")) != 0L ? 1 : 0) & ((this.glClientWaitSync = GLContext.getFunctionAddress("glClientWaitSync")) != 0L ? 1 : 0) & ((this.glWaitSync = GLContext.getFunctionAddress("glWaitSync")) != 0L ? 1 : 0) & ((this.glGetInteger64v = GLContext.getFunctionAddress("glGetInteger64v")) != 0L ? 1 : 0) & ((this.glGetSynciv = GLContext.getFunctionAddress("glGetSynciv")) != 0L ? 1 : 0);
/* 2521:     */   }
/* 2522:     */   
/* 2523:     */   private boolean ARB_tessellation_shader_initNativeFunctionAddresses()
/* 2524:     */   {
/* 2525:3053 */     return ((this.glPatchParameteri = GLContext.getFunctionAddress("glPatchParameteri")) != 0L ? 1 : 0) & ((this.glPatchParameterfv = GLContext.getFunctionAddress("glPatchParameterfv")) != 0L ? 1 : 0);
/* 2526:     */   }
/* 2527:     */   
/* 2528:     */   private boolean ARB_texture_buffer_object_initNativeFunctionAddresses()
/* 2529:     */   {
/* 2530:3059 */     return (this.glTexBufferARB = GLContext.getFunctionAddress("glTexBufferARB")) != 0L;
/* 2531:     */   }
/* 2532:     */   
/* 2533:     */   private boolean ARB_texture_buffer_range_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2534:     */   {
/* 2535:3064 */     return ((this.glTexBufferRange = GLContext.getFunctionAddress("glTexBufferRange")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glTextureBufferRangeEXT = GLContext.getFunctionAddress("glTextureBufferRangeEXT")) != 0L) ? 1 : 0);
/* 2536:     */   }
/* 2537:     */   
/* 2538:     */   private boolean ARB_texture_compression_initNativeFunctionAddresses()
/* 2539:     */   {
/* 2540:3070 */     return ((this.glCompressedTexImage1DARB = GLContext.getFunctionAddress("glCompressedTexImage1DARB")) != 0L ? 1 : 0) & ((this.glCompressedTexImage2DARB = GLContext.getFunctionAddress("glCompressedTexImage2DARB")) != 0L ? 1 : 0) & ((this.glCompressedTexImage3DARB = GLContext.getFunctionAddress("glCompressedTexImage3DARB")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage1DARB = GLContext.getFunctionAddress("glCompressedTexSubImage1DARB")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage2DARB = GLContext.getFunctionAddress("glCompressedTexSubImage2DARB")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage3DARB = GLContext.getFunctionAddress("glCompressedTexSubImage3DARB")) != 0L ? 1 : 0) & ((this.glGetCompressedTexImageARB = GLContext.getFunctionAddress("glGetCompressedTexImageARB")) != 0L ? 1 : 0);
/* 2541:     */   }
/* 2542:     */   
/* 2543:     */   private boolean ARB_texture_multisample_initNativeFunctionAddresses()
/* 2544:     */   {
/* 2545:3081 */     return ((this.glTexImage2DMultisample = GLContext.getFunctionAddress("glTexImage2DMultisample")) != 0L ? 1 : 0) & ((this.glTexImage3DMultisample = GLContext.getFunctionAddress("glTexImage3DMultisample")) != 0L ? 1 : 0) & ((this.glGetMultisamplefv = GLContext.getFunctionAddress("glGetMultisamplefv")) != 0L ? 1 : 0) & ((this.glSampleMaski = GLContext.getFunctionAddress("glSampleMaski")) != 0L ? 1 : 0);
/* 2546:     */   }
/* 2547:     */   
/* 2548:     */   private boolean ARB_texture_storage_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2549:     */   {
/* 2550:3089 */     if (supported_extensions.contains("GL_EXT_direct_state_access")) {}
/* 2551:3089 */     if (supported_extensions.contains("GL_EXT_direct_state_access")) {}
/* 2552:3089 */     if (supported_extensions.contains("GL_EXT_direct_state_access")) {}
/* 2553:3089 */     return ((this.glTexStorage1D = GLContext.getFunctionAddress(new String[] { "glTexStorage1D", "glTexStorage1DEXT" })) != 0L ? 1 : 0) & ((this.glTexStorage2D = GLContext.getFunctionAddress(new String[] { "glTexStorage2D", "glTexStorage2DEXT" })) != 0L ? 1 : 0) & ((this.glTexStorage3D = GLContext.getFunctionAddress(new String[] { "glTexStorage3D", "glTexStorage3DEXT" })) != 0L ? 1 : 0) & ((this.glTextureStorage1DEXT = GLContext.getFunctionAddress(new String[] { "glTextureStorage1DEXT", "glTextureStorage1DEXTEXT" })) != 0L ? 1 : 0) & ((this.glTextureStorage2DEXT = GLContext.getFunctionAddress(new String[] { "glTextureStorage2DEXT", "glTextureStorage2DEXTEXT" })) != 0L ? 1 : 0) & ((this.glTextureStorage3DEXT = GLContext.getFunctionAddress(new String[] { "glTextureStorage3DEXT", "glTextureStorage3DEXTEXT" })) != 0L ? 1 : 0);
/* 2554:     */   }
/* 2555:     */   
/* 2556:     */   private boolean ARB_texture_storage_multisample_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2557:     */   {
/* 2558:3099 */     return ((this.glTexStorage2DMultisample = GLContext.getFunctionAddress("glTexStorage2DMultisample")) != 0L ? 1 : 0) & ((this.glTexStorage3DMultisample = GLContext.getFunctionAddress("glTexStorage3DMultisample")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glTextureStorage2DMultisampleEXT = GLContext.getFunctionAddress("glTextureStorage2DMultisampleEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glTextureStorage3DMultisampleEXT = GLContext.getFunctionAddress("glTextureStorage3DMultisampleEXT")) != 0L) ? 1 : 0);
/* 2559:     */   }
/* 2560:     */   
/* 2561:     */   private boolean ARB_texture_view_initNativeFunctionAddresses()
/* 2562:     */   {
/* 2563:3107 */     return (this.glTextureView = GLContext.getFunctionAddress("glTextureView")) != 0L;
/* 2564:     */   }
/* 2565:     */   
/* 2566:     */   private boolean ARB_timer_query_initNativeFunctionAddresses()
/* 2567:     */   {
/* 2568:3112 */     return ((this.glQueryCounter = GLContext.getFunctionAddress("glQueryCounter")) != 0L ? 1 : 0) & ((this.glGetQueryObjecti64v = GLContext.getFunctionAddress("glGetQueryObjecti64v")) != 0L ? 1 : 0) & ((this.glGetQueryObjectui64v = GLContext.getFunctionAddress("glGetQueryObjectui64v")) != 0L ? 1 : 0);
/* 2569:     */   }
/* 2570:     */   
/* 2571:     */   private boolean ARB_transform_feedback2_initNativeFunctionAddresses()
/* 2572:     */   {
/* 2573:3119 */     return ((this.glBindTransformFeedback = GLContext.getFunctionAddress("glBindTransformFeedback")) != 0L ? 1 : 0) & ((this.glDeleteTransformFeedbacks = GLContext.getFunctionAddress("glDeleteTransformFeedbacks")) != 0L ? 1 : 0) & ((this.glGenTransformFeedbacks = GLContext.getFunctionAddress("glGenTransformFeedbacks")) != 0L ? 1 : 0) & ((this.glIsTransformFeedback = GLContext.getFunctionAddress("glIsTransformFeedback")) != 0L ? 1 : 0) & ((this.glPauseTransformFeedback = GLContext.getFunctionAddress("glPauseTransformFeedback")) != 0L ? 1 : 0) & ((this.glResumeTransformFeedback = GLContext.getFunctionAddress("glResumeTransformFeedback")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedback = GLContext.getFunctionAddress("glDrawTransformFeedback")) != 0L ? 1 : 0);
/* 2574:     */   }
/* 2575:     */   
/* 2576:     */   private boolean ARB_transform_feedback3_initNativeFunctionAddresses()
/* 2577:     */   {
/* 2578:3130 */     return ((this.glDrawTransformFeedbackStream = GLContext.getFunctionAddress("glDrawTransformFeedbackStream")) != 0L ? 1 : 0) & ((this.glBeginQueryIndexed = GLContext.getFunctionAddress("glBeginQueryIndexed")) != 0L ? 1 : 0) & ((this.glEndQueryIndexed = GLContext.getFunctionAddress("glEndQueryIndexed")) != 0L ? 1 : 0) & ((this.glGetQueryIndexediv = GLContext.getFunctionAddress("glGetQueryIndexediv")) != 0L ? 1 : 0);
/* 2579:     */   }
/* 2580:     */   
/* 2581:     */   private boolean ARB_transform_feedback_instanced_initNativeFunctionAddresses()
/* 2582:     */   {
/* 2583:3138 */     return ((this.glDrawTransformFeedbackInstanced = GLContext.getFunctionAddress("glDrawTransformFeedbackInstanced")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedbackStreamInstanced = GLContext.getFunctionAddress("glDrawTransformFeedbackStreamInstanced")) != 0L ? 1 : 0);
/* 2584:     */   }
/* 2585:     */   
/* 2586:     */   private boolean ARB_transpose_matrix_initNativeFunctionAddresses()
/* 2587:     */   {
/* 2588:3144 */     return ((this.glLoadTransposeMatrixfARB = GLContext.getFunctionAddress("glLoadTransposeMatrixfARB")) != 0L ? 1 : 0) & ((this.glMultTransposeMatrixfARB = GLContext.getFunctionAddress("glMultTransposeMatrixfARB")) != 0L ? 1 : 0);
/* 2589:     */   }
/* 2590:     */   
/* 2591:     */   private boolean ARB_uniform_buffer_object_initNativeFunctionAddresses()
/* 2592:     */   {
/* 2593:3150 */     return ((this.glGetUniformIndices = GLContext.getFunctionAddress("glGetUniformIndices")) != 0L ? 1 : 0) & ((this.glGetActiveUniformsiv = GLContext.getFunctionAddress("glGetActiveUniformsiv")) != 0L ? 1 : 0) & ((this.glGetActiveUniformName = GLContext.getFunctionAddress("glGetActiveUniformName")) != 0L ? 1 : 0) & ((this.glGetUniformBlockIndex = GLContext.getFunctionAddress("glGetUniformBlockIndex")) != 0L ? 1 : 0) & ((this.glGetActiveUniformBlockiv = GLContext.getFunctionAddress("glGetActiveUniformBlockiv")) != 0L ? 1 : 0) & ((this.glGetActiveUniformBlockName = GLContext.getFunctionAddress("glGetActiveUniformBlockName")) != 0L ? 1 : 0) & ((this.glBindBufferRange = GLContext.getFunctionAddress("glBindBufferRange")) != 0L ? 1 : 0) & ((this.glBindBufferBase = GLContext.getFunctionAddress("glBindBufferBase")) != 0L ? 1 : 0) & ((this.glGetIntegeri_v = GLContext.getFunctionAddress("glGetIntegeri_v")) != 0L ? 1 : 0) & ((this.glUniformBlockBinding = GLContext.getFunctionAddress("glUniformBlockBinding")) != 0L ? 1 : 0);
/* 2594:     */   }
/* 2595:     */   
/* 2596:     */   private boolean ARB_vertex_array_object_initNativeFunctionAddresses()
/* 2597:     */   {
/* 2598:3164 */     return ((this.glBindVertexArray = GLContext.getFunctionAddress("glBindVertexArray")) != 0L ? 1 : 0) & ((this.glDeleteVertexArrays = GLContext.getFunctionAddress("glDeleteVertexArrays")) != 0L ? 1 : 0) & ((this.glGenVertexArrays = GLContext.getFunctionAddress("glGenVertexArrays")) != 0L ? 1 : 0) & ((this.glIsVertexArray = GLContext.getFunctionAddress("glIsVertexArray")) != 0L ? 1 : 0);
/* 2599:     */   }
/* 2600:     */   
/* 2601:     */   private boolean ARB_vertex_attrib_64bit_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2602:     */   {
/* 2603:3172 */     return ((this.glVertexAttribL1d = GLContext.getFunctionAddress("glVertexAttribL1d")) != 0L ? 1 : 0) & ((this.glVertexAttribL2d = GLContext.getFunctionAddress("glVertexAttribL2d")) != 0L ? 1 : 0) & ((this.glVertexAttribL3d = GLContext.getFunctionAddress("glVertexAttribL3d")) != 0L ? 1 : 0) & ((this.glVertexAttribL4d = GLContext.getFunctionAddress("glVertexAttribL4d")) != 0L ? 1 : 0) & ((this.glVertexAttribL1dv = GLContext.getFunctionAddress("glVertexAttribL1dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL2dv = GLContext.getFunctionAddress("glVertexAttribL2dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL3dv = GLContext.getFunctionAddress("glVertexAttribL3dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL4dv = GLContext.getFunctionAddress("glVertexAttribL4dv")) != 0L ? 1 : 0) & ((this.glVertexAttribLPointer = GLContext.getFunctionAddress("glVertexAttribLPointer")) != 0L ? 1 : 0) & ((this.glGetVertexAttribLdv = GLContext.getFunctionAddress("glGetVertexAttribLdv")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glVertexArrayVertexAttribLOffsetEXT = GLContext.getFunctionAddress("glVertexArrayVertexAttribLOffsetEXT")) != 0L) ? 1 : 0);
/* 2604:     */   }
/* 2605:     */   
/* 2606:     */   private boolean ARB_vertex_attrib_binding_initNativeFunctionAddresses()
/* 2607:     */   {
/* 2608:3187 */     return ((this.glBindVertexBuffer = GLContext.getFunctionAddress("glBindVertexBuffer")) != 0L ? 1 : 0) & ((this.glVertexAttribFormat = GLContext.getFunctionAddress("glVertexAttribFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribIFormat = GLContext.getFunctionAddress("glVertexAttribIFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribLFormat = GLContext.getFunctionAddress("glVertexAttribLFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribBinding = GLContext.getFunctionAddress("glVertexAttribBinding")) != 0L ? 1 : 0) & ((this.glVertexBindingDivisor = GLContext.getFunctionAddress("glVertexBindingDivisor")) != 0L ? 1 : 0);
/* 2609:     */   }
/* 2610:     */   
/* 2611:     */   private boolean ARB_vertex_blend_initNativeFunctionAddresses()
/* 2612:     */   {
/* 2613:3197 */     return ((this.glWeightbvARB = GLContext.getFunctionAddress("glWeightbvARB")) != 0L ? 1 : 0) & ((this.glWeightsvARB = GLContext.getFunctionAddress("glWeightsvARB")) != 0L ? 1 : 0) & ((this.glWeightivARB = GLContext.getFunctionAddress("glWeightivARB")) != 0L ? 1 : 0) & ((this.glWeightfvARB = GLContext.getFunctionAddress("glWeightfvARB")) != 0L ? 1 : 0) & ((this.glWeightdvARB = GLContext.getFunctionAddress("glWeightdvARB")) != 0L ? 1 : 0) & ((this.glWeightubvARB = GLContext.getFunctionAddress("glWeightubvARB")) != 0L ? 1 : 0) & ((this.glWeightusvARB = GLContext.getFunctionAddress("glWeightusvARB")) != 0L ? 1 : 0) & ((this.glWeightuivARB = GLContext.getFunctionAddress("glWeightuivARB")) != 0L ? 1 : 0) & ((this.glWeightPointerARB = GLContext.getFunctionAddress("glWeightPointerARB")) != 0L ? 1 : 0) & ((this.glVertexBlendARB = GLContext.getFunctionAddress("glVertexBlendARB")) != 0L ? 1 : 0);
/* 2614:     */   }
/* 2615:     */   
/* 2616:     */   private boolean ARB_vertex_program_initNativeFunctionAddresses()
/* 2617:     */   {
/* 2618:3211 */     return ((this.glVertexAttrib1sARB = GLContext.getFunctionAddress("glVertexAttrib1sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib1fARB = GLContext.getFunctionAddress("glVertexAttrib1fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib1dARB = GLContext.getFunctionAddress("glVertexAttrib1dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2sARB = GLContext.getFunctionAddress("glVertexAttrib2sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2fARB = GLContext.getFunctionAddress("glVertexAttrib2fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2dARB = GLContext.getFunctionAddress("glVertexAttrib2dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3sARB = GLContext.getFunctionAddress("glVertexAttrib3sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3fARB = GLContext.getFunctionAddress("glVertexAttrib3fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3dARB = GLContext.getFunctionAddress("glVertexAttrib3dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4sARB = GLContext.getFunctionAddress("glVertexAttrib4sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4fARB = GLContext.getFunctionAddress("glVertexAttrib4fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4dARB = GLContext.getFunctionAddress("glVertexAttrib4dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4NubARB = GLContext.getFunctionAddress("glVertexAttrib4NubARB")) != 0L ? 1 : 0) & ((this.glVertexAttribPointerARB = GLContext.getFunctionAddress("glVertexAttribPointerARB")) != 0L ? 1 : 0) & ((this.glEnableVertexAttribArrayARB = GLContext.getFunctionAddress("glEnableVertexAttribArrayARB")) != 0L ? 1 : 0) & ((this.glDisableVertexAttribArrayARB = GLContext.getFunctionAddress("glDisableVertexAttribArrayARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribfvARB = GLContext.getFunctionAddress("glGetVertexAttribfvARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribdvARB = GLContext.getFunctionAddress("glGetVertexAttribdvARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribivARB = GLContext.getFunctionAddress("glGetVertexAttribivARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribPointervARB = GLContext.getFunctionAddress("glGetVertexAttribPointervARB")) != 0L ? 1 : 0);
/* 2619:     */   }
/* 2620:     */   
/* 2621:     */   private boolean ARB_vertex_shader_initNativeFunctionAddresses()
/* 2622:     */   {
/* 2623:3235 */     return ((this.glVertexAttrib1sARB = GLContext.getFunctionAddress("glVertexAttrib1sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib1fARB = GLContext.getFunctionAddress("glVertexAttrib1fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib1dARB = GLContext.getFunctionAddress("glVertexAttrib1dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2sARB = GLContext.getFunctionAddress("glVertexAttrib2sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2fARB = GLContext.getFunctionAddress("glVertexAttrib2fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib2dARB = GLContext.getFunctionAddress("glVertexAttrib2dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3sARB = GLContext.getFunctionAddress("glVertexAttrib3sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3fARB = GLContext.getFunctionAddress("glVertexAttrib3fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib3dARB = GLContext.getFunctionAddress("glVertexAttrib3dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4sARB = GLContext.getFunctionAddress("glVertexAttrib4sARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4fARB = GLContext.getFunctionAddress("glVertexAttrib4fARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4dARB = GLContext.getFunctionAddress("glVertexAttrib4dARB")) != 0L ? 1 : 0) & ((this.glVertexAttrib4NubARB = GLContext.getFunctionAddress("glVertexAttrib4NubARB")) != 0L ? 1 : 0) & ((this.glVertexAttribPointerARB = GLContext.getFunctionAddress("glVertexAttribPointerARB")) != 0L ? 1 : 0) & ((this.glEnableVertexAttribArrayARB = GLContext.getFunctionAddress("glEnableVertexAttribArrayARB")) != 0L ? 1 : 0) & ((this.glDisableVertexAttribArrayARB = GLContext.getFunctionAddress("glDisableVertexAttribArrayARB")) != 0L ? 1 : 0) & ((this.glBindAttribLocationARB = GLContext.getFunctionAddress("glBindAttribLocationARB")) != 0L ? 1 : 0) & ((this.glGetActiveAttribARB = GLContext.getFunctionAddress("glGetActiveAttribARB")) != 0L ? 1 : 0) & ((this.glGetAttribLocationARB = GLContext.getFunctionAddress("glGetAttribLocationARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribfvARB = GLContext.getFunctionAddress("glGetVertexAttribfvARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribdvARB = GLContext.getFunctionAddress("glGetVertexAttribdvARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribivARB = GLContext.getFunctionAddress("glGetVertexAttribivARB")) != 0L ? 1 : 0) & ((this.glGetVertexAttribPointervARB = GLContext.getFunctionAddress("glGetVertexAttribPointervARB")) != 0L ? 1 : 0);
/* 2624:     */   }
/* 2625:     */   
/* 2626:     */   private boolean ARB_vertex_type_2_10_10_10_rev_initNativeFunctionAddresses()
/* 2627:     */   {
/* 2628:3262 */     return ((this.glVertexP2ui = GLContext.getFunctionAddress("glVertexP2ui")) != 0L ? 1 : 0) & ((this.glVertexP3ui = GLContext.getFunctionAddress("glVertexP3ui")) != 0L ? 1 : 0) & ((this.glVertexP4ui = GLContext.getFunctionAddress("glVertexP4ui")) != 0L ? 1 : 0) & ((this.glVertexP2uiv = GLContext.getFunctionAddress("glVertexP2uiv")) != 0L ? 1 : 0) & ((this.glVertexP3uiv = GLContext.getFunctionAddress("glVertexP3uiv")) != 0L ? 1 : 0) & ((this.glVertexP4uiv = GLContext.getFunctionAddress("glVertexP4uiv")) != 0L ? 1 : 0) & ((this.glTexCoordP1ui = GLContext.getFunctionAddress("glTexCoordP1ui")) != 0L ? 1 : 0) & ((this.glTexCoordP2ui = GLContext.getFunctionAddress("glTexCoordP2ui")) != 0L ? 1 : 0) & ((this.glTexCoordP3ui = GLContext.getFunctionAddress("glTexCoordP3ui")) != 0L ? 1 : 0) & ((this.glTexCoordP4ui = GLContext.getFunctionAddress("glTexCoordP4ui")) != 0L ? 1 : 0) & ((this.glTexCoordP1uiv = GLContext.getFunctionAddress("glTexCoordP1uiv")) != 0L ? 1 : 0) & ((this.glTexCoordP2uiv = GLContext.getFunctionAddress("glTexCoordP2uiv")) != 0L ? 1 : 0) & ((this.glTexCoordP3uiv = GLContext.getFunctionAddress("glTexCoordP3uiv")) != 0L ? 1 : 0) & ((this.glTexCoordP4uiv = GLContext.getFunctionAddress("glTexCoordP4uiv")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP1ui = GLContext.getFunctionAddress("glMultiTexCoordP1ui")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP2ui = GLContext.getFunctionAddress("glMultiTexCoordP2ui")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP3ui = GLContext.getFunctionAddress("glMultiTexCoordP3ui")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP4ui = GLContext.getFunctionAddress("glMultiTexCoordP4ui")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP1uiv = GLContext.getFunctionAddress("glMultiTexCoordP1uiv")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP2uiv = GLContext.getFunctionAddress("glMultiTexCoordP2uiv")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP3uiv = GLContext.getFunctionAddress("glMultiTexCoordP3uiv")) != 0L ? 1 : 0) & ((this.glMultiTexCoordP4uiv = GLContext.getFunctionAddress("glMultiTexCoordP4uiv")) != 0L ? 1 : 0) & ((this.glNormalP3ui = GLContext.getFunctionAddress("glNormalP3ui")) != 0L ? 1 : 0) & ((this.glNormalP3uiv = GLContext.getFunctionAddress("glNormalP3uiv")) != 0L ? 1 : 0) & ((this.glColorP3ui = GLContext.getFunctionAddress("glColorP3ui")) != 0L ? 1 : 0) & ((this.glColorP4ui = GLContext.getFunctionAddress("glColorP4ui")) != 0L ? 1 : 0) & ((this.glColorP3uiv = GLContext.getFunctionAddress("glColorP3uiv")) != 0L ? 1 : 0) & ((this.glColorP4uiv = GLContext.getFunctionAddress("glColorP4uiv")) != 0L ? 1 : 0) & ((this.glSecondaryColorP3ui = GLContext.getFunctionAddress("glSecondaryColorP3ui")) != 0L ? 1 : 0) & ((this.glSecondaryColorP3uiv = GLContext.getFunctionAddress("glSecondaryColorP3uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribP1ui = GLContext.getFunctionAddress("glVertexAttribP1ui")) != 0L ? 1 : 0) & ((this.glVertexAttribP2ui = GLContext.getFunctionAddress("glVertexAttribP2ui")) != 0L ? 1 : 0) & ((this.glVertexAttribP3ui = GLContext.getFunctionAddress("glVertexAttribP3ui")) != 0L ? 1 : 0) & ((this.glVertexAttribP4ui = GLContext.getFunctionAddress("glVertexAttribP4ui")) != 0L ? 1 : 0) & ((this.glVertexAttribP1uiv = GLContext.getFunctionAddress("glVertexAttribP1uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribP2uiv = GLContext.getFunctionAddress("glVertexAttribP2uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribP3uiv = GLContext.getFunctionAddress("glVertexAttribP3uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribP4uiv = GLContext.getFunctionAddress("glVertexAttribP4uiv")) != 0L ? 1 : 0);
/* 2629:     */   }
/* 2630:     */   
/* 2631:     */   private boolean ARB_viewport_array_initNativeFunctionAddresses()
/* 2632:     */   {
/* 2633:3304 */     return ((this.glViewportArrayv = GLContext.getFunctionAddress("glViewportArrayv")) != 0L ? 1 : 0) & ((this.glViewportIndexedf = GLContext.getFunctionAddress("glViewportIndexedf")) != 0L ? 1 : 0) & ((this.glViewportIndexedfv = GLContext.getFunctionAddress("glViewportIndexedfv")) != 0L ? 1 : 0) & ((this.glScissorArrayv = GLContext.getFunctionAddress("glScissorArrayv")) != 0L ? 1 : 0) & ((this.glScissorIndexed = GLContext.getFunctionAddress("glScissorIndexed")) != 0L ? 1 : 0) & ((this.glScissorIndexedv = GLContext.getFunctionAddress("glScissorIndexedv")) != 0L ? 1 : 0) & ((this.glDepthRangeArrayv = GLContext.getFunctionAddress("glDepthRangeArrayv")) != 0L ? 1 : 0) & ((this.glDepthRangeIndexed = GLContext.getFunctionAddress("glDepthRangeIndexed")) != 0L ? 1 : 0) & ((this.glGetFloati_v = GLContext.getFunctionAddress("glGetFloati_v")) != 0L ? 1 : 0) & ((this.glGetDoublei_v = GLContext.getFunctionAddress("glGetDoublei_v")) != 0L ? 1 : 0) & ((this.glGetIntegerIndexedvEXT = GLContext.getFunctionAddress("glGetIntegerIndexedvEXT")) != 0L ? 1 : 0) & ((this.glEnableIndexedEXT = GLContext.getFunctionAddress("glEnableIndexedEXT")) != 0L ? 1 : 0) & ((this.glDisableIndexedEXT = GLContext.getFunctionAddress("glDisableIndexedEXT")) != 0L ? 1 : 0) & ((this.glIsEnabledIndexedEXT = GLContext.getFunctionAddress("glIsEnabledIndexedEXT")) != 0L ? 1 : 0);
/* 2634:     */   }
/* 2635:     */   
/* 2636:     */   private boolean ARB_window_pos_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2637:     */   {
/* 2638:3322 */     return ((forwardCompatible) || ((this.glWindowPos2fARB = GLContext.getFunctionAddress("glWindowPos2fARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2dARB = GLContext.getFunctionAddress("glWindowPos2dARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2iARB = GLContext.getFunctionAddress("glWindowPos2iARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2sARB = GLContext.getFunctionAddress("glWindowPos2sARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3fARB = GLContext.getFunctionAddress("glWindowPos3fARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3dARB = GLContext.getFunctionAddress("glWindowPos3dARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3iARB = GLContext.getFunctionAddress("glWindowPos3iARB")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3sARB = GLContext.getFunctionAddress("glWindowPos3sARB")) != 0L) ? 1 : 0);
/* 2639:     */   }
/* 2640:     */   
/* 2641:     */   private boolean ATI_draw_buffers_initNativeFunctionAddresses()
/* 2642:     */   {
/* 2643:3334 */     return (this.glDrawBuffersATI = GLContext.getFunctionAddress("glDrawBuffersATI")) != 0L;
/* 2644:     */   }
/* 2645:     */   
/* 2646:     */   private boolean ATI_element_array_initNativeFunctionAddresses()
/* 2647:     */   {
/* 2648:3339 */     return ((this.glElementPointerATI = GLContext.getFunctionAddress("glElementPointerATI")) != 0L ? 1 : 0) & ((this.glDrawElementArrayATI = GLContext.getFunctionAddress("glDrawElementArrayATI")) != 0L ? 1 : 0) & ((this.glDrawRangeElementArrayATI = GLContext.getFunctionAddress("glDrawRangeElementArrayATI")) != 0L ? 1 : 0);
/* 2649:     */   }
/* 2650:     */   
/* 2651:     */   private boolean ATI_envmap_bumpmap_initNativeFunctionAddresses()
/* 2652:     */   {
/* 2653:3346 */     return ((this.glTexBumpParameterfvATI = GLContext.getFunctionAddress("glTexBumpParameterfvATI")) != 0L ? 1 : 0) & ((this.glTexBumpParameterivATI = GLContext.getFunctionAddress("glTexBumpParameterivATI")) != 0L ? 1 : 0) & ((this.glGetTexBumpParameterfvATI = GLContext.getFunctionAddress("glGetTexBumpParameterfvATI")) != 0L ? 1 : 0) & ((this.glGetTexBumpParameterivATI = GLContext.getFunctionAddress("glGetTexBumpParameterivATI")) != 0L ? 1 : 0);
/* 2654:     */   }
/* 2655:     */   
/* 2656:     */   private boolean ATI_fragment_shader_initNativeFunctionAddresses()
/* 2657:     */   {
/* 2658:3354 */     return ((this.glGenFragmentShadersATI = GLContext.getFunctionAddress("glGenFragmentShadersATI")) != 0L ? 1 : 0) & ((this.glBindFragmentShaderATI = GLContext.getFunctionAddress("glBindFragmentShaderATI")) != 0L ? 1 : 0) & ((this.glDeleteFragmentShaderATI = GLContext.getFunctionAddress("glDeleteFragmentShaderATI")) != 0L ? 1 : 0) & ((this.glBeginFragmentShaderATI = GLContext.getFunctionAddress("glBeginFragmentShaderATI")) != 0L ? 1 : 0) & ((this.glEndFragmentShaderATI = GLContext.getFunctionAddress("glEndFragmentShaderATI")) != 0L ? 1 : 0) & ((this.glPassTexCoordATI = GLContext.getFunctionAddress("glPassTexCoordATI")) != 0L ? 1 : 0) & ((this.glSampleMapATI = GLContext.getFunctionAddress("glSampleMapATI")) != 0L ? 1 : 0) & ((this.glColorFragmentOp1ATI = GLContext.getFunctionAddress("glColorFragmentOp1ATI")) != 0L ? 1 : 0) & ((this.glColorFragmentOp2ATI = GLContext.getFunctionAddress("glColorFragmentOp2ATI")) != 0L ? 1 : 0) & ((this.glColorFragmentOp3ATI = GLContext.getFunctionAddress("glColorFragmentOp3ATI")) != 0L ? 1 : 0) & ((this.glAlphaFragmentOp1ATI = GLContext.getFunctionAddress("glAlphaFragmentOp1ATI")) != 0L ? 1 : 0) & ((this.glAlphaFragmentOp2ATI = GLContext.getFunctionAddress("glAlphaFragmentOp2ATI")) != 0L ? 1 : 0) & ((this.glAlphaFragmentOp3ATI = GLContext.getFunctionAddress("glAlphaFragmentOp3ATI")) != 0L ? 1 : 0) & ((this.glSetFragmentShaderConstantATI = GLContext.getFunctionAddress("glSetFragmentShaderConstantATI")) != 0L ? 1 : 0);
/* 2659:     */   }
/* 2660:     */   
/* 2661:     */   private boolean ATI_map_object_buffer_initNativeFunctionAddresses()
/* 2662:     */   {
/* 2663:3372 */     return ((this.glMapObjectBufferATI = GLContext.getFunctionAddress("glMapObjectBufferATI")) != 0L ? 1 : 0) & ((this.glUnmapObjectBufferATI = GLContext.getFunctionAddress("glUnmapObjectBufferATI")) != 0L ? 1 : 0);
/* 2664:     */   }
/* 2665:     */   
/* 2666:     */   private boolean ATI_pn_triangles_initNativeFunctionAddresses()
/* 2667:     */   {
/* 2668:3378 */     return ((this.glPNTrianglesfATI = GLContext.getFunctionAddress("glPNTrianglesfATI")) != 0L ? 1 : 0) & ((this.glPNTrianglesiATI = GLContext.getFunctionAddress("glPNTrianglesiATI")) != 0L ? 1 : 0);
/* 2669:     */   }
/* 2670:     */   
/* 2671:     */   private boolean ATI_separate_stencil_initNativeFunctionAddresses()
/* 2672:     */   {
/* 2673:3384 */     return ((this.glStencilOpSeparateATI = GLContext.getFunctionAddress("glStencilOpSeparateATI")) != 0L ? 1 : 0) & ((this.glStencilFuncSeparateATI = GLContext.getFunctionAddress("glStencilFuncSeparateATI")) != 0L ? 1 : 0);
/* 2674:     */   }
/* 2675:     */   
/* 2676:     */   private boolean ATI_vertex_array_object_initNativeFunctionAddresses()
/* 2677:     */   {
/* 2678:3390 */     return ((this.glNewObjectBufferATI = GLContext.getFunctionAddress("glNewObjectBufferATI")) != 0L ? 1 : 0) & ((this.glIsObjectBufferATI = GLContext.getFunctionAddress("glIsObjectBufferATI")) != 0L ? 1 : 0) & ((this.glUpdateObjectBufferATI = GLContext.getFunctionAddress("glUpdateObjectBufferATI")) != 0L ? 1 : 0) & ((this.glGetObjectBufferfvATI = GLContext.getFunctionAddress("glGetObjectBufferfvATI")) != 0L ? 1 : 0) & ((this.glGetObjectBufferivATI = GLContext.getFunctionAddress("glGetObjectBufferivATI")) != 0L ? 1 : 0) & ((this.glFreeObjectBufferATI = GLContext.getFunctionAddress("glFreeObjectBufferATI")) != 0L ? 1 : 0) & ((this.glArrayObjectATI = GLContext.getFunctionAddress("glArrayObjectATI")) != 0L ? 1 : 0) & ((this.glGetArrayObjectfvATI = GLContext.getFunctionAddress("glGetArrayObjectfvATI")) != 0L ? 1 : 0) & ((this.glGetArrayObjectivATI = GLContext.getFunctionAddress("glGetArrayObjectivATI")) != 0L ? 1 : 0) & ((this.glVariantArrayObjectATI = GLContext.getFunctionAddress("glVariantArrayObjectATI")) != 0L ? 1 : 0) & ((this.glGetVariantArrayObjectfvATI = GLContext.getFunctionAddress("glGetVariantArrayObjectfvATI")) != 0L ? 1 : 0) & ((this.glGetVariantArrayObjectivATI = GLContext.getFunctionAddress("glGetVariantArrayObjectivATI")) != 0L ? 1 : 0);
/* 2679:     */   }
/* 2680:     */   
/* 2681:     */   private boolean ATI_vertex_attrib_array_object_initNativeFunctionAddresses()
/* 2682:     */   {
/* 2683:3406 */     return ((this.glVertexAttribArrayObjectATI = GLContext.getFunctionAddress("glVertexAttribArrayObjectATI")) != 0L ? 1 : 0) & ((this.glGetVertexAttribArrayObjectfvATI = GLContext.getFunctionAddress("glGetVertexAttribArrayObjectfvATI")) != 0L ? 1 : 0) & ((this.glGetVertexAttribArrayObjectivATI = GLContext.getFunctionAddress("glGetVertexAttribArrayObjectivATI")) != 0L ? 1 : 0);
/* 2684:     */   }
/* 2685:     */   
/* 2686:     */   private boolean ATI_vertex_streams_initNativeFunctionAddresses()
/* 2687:     */   {
/* 2688:3413 */     return ((this.glVertexStream2fATI = GLContext.getFunctionAddress("glVertexStream2fATI")) != 0L ? 1 : 0) & ((this.glVertexStream2dATI = GLContext.getFunctionAddress("glVertexStream2dATI")) != 0L ? 1 : 0) & ((this.glVertexStream2iATI = GLContext.getFunctionAddress("glVertexStream2iATI")) != 0L ? 1 : 0) & ((this.glVertexStream2sATI = GLContext.getFunctionAddress("glVertexStream2sATI")) != 0L ? 1 : 0) & ((this.glVertexStream3fATI = GLContext.getFunctionAddress("glVertexStream3fATI")) != 0L ? 1 : 0) & ((this.glVertexStream3dATI = GLContext.getFunctionAddress("glVertexStream3dATI")) != 0L ? 1 : 0) & ((this.glVertexStream3iATI = GLContext.getFunctionAddress("glVertexStream3iATI")) != 0L ? 1 : 0) & ((this.glVertexStream3sATI = GLContext.getFunctionAddress("glVertexStream3sATI")) != 0L ? 1 : 0) & ((this.glVertexStream4fATI = GLContext.getFunctionAddress("glVertexStream4fATI")) != 0L ? 1 : 0) & ((this.glVertexStream4dATI = GLContext.getFunctionAddress("glVertexStream4dATI")) != 0L ? 1 : 0) & ((this.glVertexStream4iATI = GLContext.getFunctionAddress("glVertexStream4iATI")) != 0L ? 1 : 0) & ((this.glVertexStream4sATI = GLContext.getFunctionAddress("glVertexStream4sATI")) != 0L ? 1 : 0) & ((this.glNormalStream3bATI = GLContext.getFunctionAddress("glNormalStream3bATI")) != 0L ? 1 : 0) & ((this.glNormalStream3fATI = GLContext.getFunctionAddress("glNormalStream3fATI")) != 0L ? 1 : 0) & ((this.glNormalStream3dATI = GLContext.getFunctionAddress("glNormalStream3dATI")) != 0L ? 1 : 0) & ((this.glNormalStream3iATI = GLContext.getFunctionAddress("glNormalStream3iATI")) != 0L ? 1 : 0) & ((this.glNormalStream3sATI = GLContext.getFunctionAddress("glNormalStream3sATI")) != 0L ? 1 : 0) & ((this.glClientActiveVertexStreamATI = GLContext.getFunctionAddress("glClientActiveVertexStreamATI")) != 0L ? 1 : 0) & ((this.glVertexBlendEnvfATI = GLContext.getFunctionAddress("glVertexBlendEnvfATI")) != 0L ? 1 : 0) & ((this.glVertexBlendEnviATI = GLContext.getFunctionAddress("glVertexBlendEnviATI")) != 0L ? 1 : 0);
/* 2689:     */   }
/* 2690:     */   
/* 2691:     */   private boolean EXT_bindable_uniform_initNativeFunctionAddresses()
/* 2692:     */   {
/* 2693:3437 */     return ((this.glUniformBufferEXT = GLContext.getFunctionAddress("glUniformBufferEXT")) != 0L ? 1 : 0) & ((this.glGetUniformBufferSizeEXT = GLContext.getFunctionAddress("glGetUniformBufferSizeEXT")) != 0L ? 1 : 0) & ((this.glGetUniformOffsetEXT = GLContext.getFunctionAddress("glGetUniformOffsetEXT")) != 0L ? 1 : 0);
/* 2694:     */   }
/* 2695:     */   
/* 2696:     */   private boolean EXT_blend_color_initNativeFunctionAddresses()
/* 2697:     */   {
/* 2698:3444 */     return (this.glBlendColorEXT = GLContext.getFunctionAddress("glBlendColorEXT")) != 0L;
/* 2699:     */   }
/* 2700:     */   
/* 2701:     */   private boolean EXT_blend_equation_separate_initNativeFunctionAddresses()
/* 2702:     */   {
/* 2703:3449 */     return (this.glBlendEquationSeparateEXT = GLContext.getFunctionAddress("glBlendEquationSeparateEXT")) != 0L;
/* 2704:     */   }
/* 2705:     */   
/* 2706:     */   private boolean EXT_blend_func_separate_initNativeFunctionAddresses()
/* 2707:     */   {
/* 2708:3454 */     return (this.glBlendFuncSeparateEXT = GLContext.getFunctionAddress("glBlendFuncSeparateEXT")) != 0L;
/* 2709:     */   }
/* 2710:     */   
/* 2711:     */   private boolean EXT_blend_minmax_initNativeFunctionAddresses()
/* 2712:     */   {
/* 2713:3459 */     return (this.glBlendEquationEXT = GLContext.getFunctionAddress("glBlendEquationEXT")) != 0L;
/* 2714:     */   }
/* 2715:     */   
/* 2716:     */   private boolean EXT_compiled_vertex_array_initNativeFunctionAddresses()
/* 2717:     */   {
/* 2718:3464 */     return ((this.glLockArraysEXT = GLContext.getFunctionAddress("glLockArraysEXT")) != 0L ? 1 : 0) & ((this.glUnlockArraysEXT = GLContext.getFunctionAddress("glUnlockArraysEXT")) != 0L ? 1 : 0);
/* 2719:     */   }
/* 2720:     */   
/* 2721:     */   private boolean EXT_depth_bounds_test_initNativeFunctionAddresses()
/* 2722:     */   {
/* 2723:3470 */     return (this.glDepthBoundsEXT = GLContext.getFunctionAddress("glDepthBoundsEXT")) != 0L;
/* 2724:     */   }
/* 2725:     */   
/* 2726:     */   private boolean EXT_direct_state_access_initNativeFunctionAddresses(boolean forwardCompatible, Set<String> supported_extensions)
/* 2727:     */   {
/* 2728:3475 */     return ((forwardCompatible) || ((this.glClientAttribDefaultEXT = GLContext.getFunctionAddress("glClientAttribDefaultEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPushClientAttribDefaultEXT = GLContext.getFunctionAddress("glPushClientAttribDefaultEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixLoadfEXT = GLContext.getFunctionAddress("glMatrixLoadfEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixLoaddEXT = GLContext.getFunctionAddress("glMatrixLoaddEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixMultfEXT = GLContext.getFunctionAddress("glMatrixMultfEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixMultdEXT = GLContext.getFunctionAddress("glMatrixMultdEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixLoadIdentityEXT = GLContext.getFunctionAddress("glMatrixLoadIdentityEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixRotatefEXT = GLContext.getFunctionAddress("glMatrixRotatefEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixRotatedEXT = GLContext.getFunctionAddress("glMatrixRotatedEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixScalefEXT = GLContext.getFunctionAddress("glMatrixScalefEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixScaledEXT = GLContext.getFunctionAddress("glMatrixScaledEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixTranslatefEXT = GLContext.getFunctionAddress("glMatrixTranslatefEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixTranslatedEXT = GLContext.getFunctionAddress("glMatrixTranslatedEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixOrthoEXT = GLContext.getFunctionAddress("glMatrixOrthoEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixFrustumEXT = GLContext.getFunctionAddress("glMatrixFrustumEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixPushEXT = GLContext.getFunctionAddress("glMatrixPushEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixPopEXT = GLContext.getFunctionAddress("glMatrixPopEXT")) != 0L) ? 1 : 0) & ((this.glTextureParameteriEXT = GLContext.getFunctionAddress("glTextureParameteriEXT")) != 0L ? 1 : 0) & ((this.glTextureParameterivEXT = GLContext.getFunctionAddress("glTextureParameterivEXT")) != 0L ? 1 : 0) & ((this.glTextureParameterfEXT = GLContext.getFunctionAddress("glTextureParameterfEXT")) != 0L ? 1 : 0) & ((this.glTextureParameterfvEXT = GLContext.getFunctionAddress("glTextureParameterfvEXT")) != 0L ? 1 : 0) & ((this.glTextureImage1DEXT = GLContext.getFunctionAddress("glTextureImage1DEXT")) != 0L ? 1 : 0) & ((this.glTextureImage2DEXT = GLContext.getFunctionAddress("glTextureImage2DEXT")) != 0L ? 1 : 0) & ((this.glTextureSubImage1DEXT = GLContext.getFunctionAddress("glTextureSubImage1DEXT")) != 0L ? 1 : 0) & ((this.glTextureSubImage2DEXT = GLContext.getFunctionAddress("glTextureSubImage2DEXT")) != 0L ? 1 : 0) & ((this.glCopyTextureImage1DEXT = GLContext.getFunctionAddress("glCopyTextureImage1DEXT")) != 0L ? 1 : 0) & ((this.glCopyTextureImage2DEXT = GLContext.getFunctionAddress("glCopyTextureImage2DEXT")) != 0L ? 1 : 0) & ((this.glCopyTextureSubImage1DEXT = GLContext.getFunctionAddress("glCopyTextureSubImage1DEXT")) != 0L ? 1 : 0) & ((this.glCopyTextureSubImage2DEXT = GLContext.getFunctionAddress("glCopyTextureSubImage2DEXT")) != 0L ? 1 : 0) & ((this.glGetTextureImageEXT = GLContext.getFunctionAddress("glGetTextureImageEXT")) != 0L ? 1 : 0) & ((this.glGetTextureParameterfvEXT = GLContext.getFunctionAddress("glGetTextureParameterfvEXT")) != 0L ? 1 : 0) & ((this.glGetTextureParameterivEXT = GLContext.getFunctionAddress("glGetTextureParameterivEXT")) != 0L ? 1 : 0) & ((this.glGetTextureLevelParameterfvEXT = GLContext.getFunctionAddress("glGetTextureLevelParameterfvEXT")) != 0L ? 1 : 0) & ((this.glGetTextureLevelParameterivEXT = GLContext.getFunctionAddress("glGetTextureLevelParameterivEXT")) != 0L ? 1 : 0) & ((!supported_extensions.contains("OpenGL12")) || ((this.glTextureImage3DEXT = GLContext.getFunctionAddress("glTextureImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL12")) || ((this.glTextureSubImage3DEXT = GLContext.getFunctionAddress("glTextureSubImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL12")) || ((this.glCopyTextureSubImage3DEXT = GLContext.getFunctionAddress("glCopyTextureSubImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glBindMultiTextureEXT = GLContext.getFunctionAddress("glBindMultiTextureEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexCoordPointerEXT = GLContext.getFunctionAddress("glMultiTexCoordPointerEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexEnvfEXT = GLContext.getFunctionAddress("glMultiTexEnvfEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexEnvfvEXT = GLContext.getFunctionAddress("glMultiTexEnvfvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexEnviEXT = GLContext.getFunctionAddress("glMultiTexEnviEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexEnvivEXT = GLContext.getFunctionAddress("glMultiTexEnvivEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGendEXT = GLContext.getFunctionAddress("glMultiTexGendEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGendvEXT = GLContext.getFunctionAddress("glMultiTexGendvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGenfEXT = GLContext.getFunctionAddress("glMultiTexGenfEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGenfvEXT = GLContext.getFunctionAddress("glMultiTexGenfvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGeniEXT = GLContext.getFunctionAddress("glMultiTexGeniEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexGenivEXT = GLContext.getFunctionAddress("glMultiTexGenivEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexEnvfvEXT = GLContext.getFunctionAddress("glGetMultiTexEnvfvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexEnvivEXT = GLContext.getFunctionAddress("glGetMultiTexEnvivEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexGendvEXT = GLContext.getFunctionAddress("glGetMultiTexGendvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexGenfvEXT = GLContext.getFunctionAddress("glGetMultiTexGenfvEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexGenivEXT = GLContext.getFunctionAddress("glGetMultiTexGenivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexParameteriEXT = GLContext.getFunctionAddress("glMultiTexParameteriEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexParameterivEXT = GLContext.getFunctionAddress("glMultiTexParameterivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexParameterfEXT = GLContext.getFunctionAddress("glMultiTexParameterfEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexParameterfvEXT = GLContext.getFunctionAddress("glMultiTexParameterfvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexImage1DEXT = GLContext.getFunctionAddress("glMultiTexImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexImage2DEXT = GLContext.getFunctionAddress("glMultiTexImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexSubImage1DEXT = GLContext.getFunctionAddress("glMultiTexSubImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexSubImage2DEXT = GLContext.getFunctionAddress("glMultiTexSubImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCopyMultiTexImage1DEXT = GLContext.getFunctionAddress("glCopyMultiTexImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCopyMultiTexImage2DEXT = GLContext.getFunctionAddress("glCopyMultiTexImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCopyMultiTexSubImage1DEXT = GLContext.getFunctionAddress("glCopyMultiTexSubImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCopyMultiTexSubImage2DEXT = GLContext.getFunctionAddress("glCopyMultiTexSubImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexImageEXT = GLContext.getFunctionAddress("glGetMultiTexImageEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexParameterfvEXT = GLContext.getFunctionAddress("glGetMultiTexParameterfvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexParameterivEXT = GLContext.getFunctionAddress("glGetMultiTexParameterivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexLevelParameterfvEXT = GLContext.getFunctionAddress("glGetMultiTexLevelParameterfvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetMultiTexLevelParameterivEXT = GLContext.getFunctionAddress("glGetMultiTexLevelParameterivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexImage3DEXT = GLContext.getFunctionAddress("glMultiTexImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glMultiTexSubImage3DEXT = GLContext.getFunctionAddress("glMultiTexSubImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCopyMultiTexSubImage3DEXT = GLContext.getFunctionAddress("glCopyMultiTexSubImage3DEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glEnableClientStateIndexedEXT = GLContext.getFunctionAddress("glEnableClientStateIndexedEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glDisableClientStateIndexedEXT = GLContext.getFunctionAddress("glDisableClientStateIndexedEXT")) != 0L) ? 1 : 0) & 0x1 & 0x1 & (((!supported_extensions.contains("OpenGL30")) || ((this.glEnableClientStateiEXT = GLContext.getFunctionAddress("glEnableClientStateiEXT")) != 0L)) || (((!supported_extensions.contains("OpenGL30")) || ((this.glDisableClientStateiEXT = GLContext.getFunctionAddress("glDisableClientStateiEXT")) != 0L)) || ((!supported_extensions.contains("OpenGL13")) || ((this.glGetFloatIndexedvEXT = GLContext.getFunctionAddress("glGetFloatIndexedvEXT")) != 0L))) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetDoubleIndexedvEXT = GLContext.getFunctionAddress("glGetDoubleIndexedvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetPointerIndexedvEXT = GLContext.getFunctionAddress("glGetPointerIndexedvEXT")) != 0L) ? 1 : 0) & 0x1 & 0x1 & 0x1 & (((!supported_extensions.contains("OpenGL30")) || ((this.glGetFloati_vEXT = GLContext.getFunctionAddress("glGetFloati_vEXT")) != 0L)) || (((!supported_extensions.contains("OpenGL30")) || ((this.glGetDoublei_vEXT = GLContext.getFunctionAddress("glGetDoublei_vEXT")) != 0L)) || (((!supported_extensions.contains("OpenGL30")) || ((this.glGetPointeri_vEXT = GLContext.getFunctionAddress("glGetPointeri_vEXT")) != 0L)) || ((!supported_extensions.contains("OpenGL13")) || ((this.glEnableIndexedEXT = GLContext.getFunctionAddress("glEnableIndexedEXT")) != 0L)))) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glDisableIndexedEXT = GLContext.getFunctionAddress("glDisableIndexedEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glIsEnabledIndexedEXT = GLContext.getFunctionAddress("glIsEnabledIndexedEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetIntegerIndexedvEXT = GLContext.getFunctionAddress("glGetIntegerIndexedvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetBooleanIndexedvEXT = GLContext.getFunctionAddress("glGetBooleanIndexedvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glNamedProgramStringEXT = GLContext.getFunctionAddress("glNamedProgramStringEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glNamedProgramLocalParameter4dEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameter4dEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glNamedProgramLocalParameter4dvEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameter4dvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glNamedProgramLocalParameter4fEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameter4fEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glNamedProgramLocalParameter4fvEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameter4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glGetNamedProgramLocalParameterdvEXT = GLContext.getFunctionAddress("glGetNamedProgramLocalParameterdvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glGetNamedProgramLocalParameterfvEXT = GLContext.getFunctionAddress("glGetNamedProgramLocalParameterfvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glGetNamedProgramivEXT = GLContext.getFunctionAddress("glGetNamedProgramivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_ARB_vertex_program")) || ((this.glGetNamedProgramStringEXT = GLContext.getFunctionAddress("glGetNamedProgramStringEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureImage3DEXT = GLContext.getFunctionAddress("glCompressedTextureImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureImage2DEXT = GLContext.getFunctionAddress("glCompressedTextureImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureImage1DEXT = GLContext.getFunctionAddress("glCompressedTextureImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureSubImage3DEXT = GLContext.getFunctionAddress("glCompressedTextureSubImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureSubImage2DEXT = GLContext.getFunctionAddress("glCompressedTextureSubImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedTextureSubImage1DEXT = GLContext.getFunctionAddress("glCompressedTextureSubImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetCompressedTextureImageEXT = GLContext.getFunctionAddress("glGetCompressedTextureImageEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexImage3DEXT = GLContext.getFunctionAddress("glCompressedMultiTexImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexImage2DEXT = GLContext.getFunctionAddress("glCompressedMultiTexImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexImage1DEXT = GLContext.getFunctionAddress("glCompressedMultiTexImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexSubImage3DEXT = GLContext.getFunctionAddress("glCompressedMultiTexSubImage3DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexSubImage2DEXT = GLContext.getFunctionAddress("glCompressedMultiTexSubImage2DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glCompressedMultiTexSubImage1DEXT = GLContext.getFunctionAddress("glCompressedMultiTexSubImage1DEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL13")) || ((this.glGetCompressedMultiTexImageEXT = GLContext.getFunctionAddress("glGetCompressedMultiTexImageEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMatrixLoadTransposefEXT = GLContext.getFunctionAddress("glMatrixLoadTransposefEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMatrixLoadTransposedEXT = GLContext.getFunctionAddress("glMatrixLoadTransposedEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMatrixMultTransposefEXT = GLContext.getFunctionAddress("glMatrixMultTransposefEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL13")) || ((this.glMatrixMultTransposedEXT = GLContext.getFunctionAddress("glMatrixMultTransposedEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glNamedBufferDataEXT = GLContext.getFunctionAddress("glNamedBufferDataEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glNamedBufferSubDataEXT = GLContext.getFunctionAddress("glNamedBufferSubDataEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glMapNamedBufferEXT = GLContext.getFunctionAddress("glMapNamedBufferEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glUnmapNamedBufferEXT = GLContext.getFunctionAddress("glUnmapNamedBufferEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glGetNamedBufferParameterivEXT = GLContext.getFunctionAddress("glGetNamedBufferParameterivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glGetNamedBufferPointervEXT = GLContext.getFunctionAddress("glGetNamedBufferPointervEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL15")) || ((this.glGetNamedBufferSubDataEXT = GLContext.getFunctionAddress("glGetNamedBufferSubDataEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform1fEXT = GLContext.getFunctionAddress("glProgramUniform1fEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform2fEXT = GLContext.getFunctionAddress("glProgramUniform2fEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform3fEXT = GLContext.getFunctionAddress("glProgramUniform3fEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform4fEXT = GLContext.getFunctionAddress("glProgramUniform4fEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform1iEXT = GLContext.getFunctionAddress("glProgramUniform1iEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform2iEXT = GLContext.getFunctionAddress("glProgramUniform2iEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform3iEXT = GLContext.getFunctionAddress("glProgramUniform3iEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform4iEXT = GLContext.getFunctionAddress("glProgramUniform4iEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform1fvEXT = GLContext.getFunctionAddress("glProgramUniform1fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform2fvEXT = GLContext.getFunctionAddress("glProgramUniform2fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform3fvEXT = GLContext.getFunctionAddress("glProgramUniform3fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform4fvEXT = GLContext.getFunctionAddress("glProgramUniform4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform1ivEXT = GLContext.getFunctionAddress("glProgramUniform1ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform2ivEXT = GLContext.getFunctionAddress("glProgramUniform2ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform3ivEXT = GLContext.getFunctionAddress("glProgramUniform3ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniform4ivEXT = GLContext.getFunctionAddress("glProgramUniform4ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniformMatrix2fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniformMatrix3fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL20")) || ((this.glProgramUniformMatrix4fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix2x3fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2x3fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix3x2fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3x2fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix2x4fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix2x4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix4x2fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4x2fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix3x4fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix3x4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL21")) || ((this.glProgramUniformMatrix4x3fvEXT = GLContext.getFunctionAddress("glProgramUniformMatrix4x3fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_buffer_object")) || ((this.glTextureBufferEXT = GLContext.getFunctionAddress("glTextureBufferEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_buffer_object")) || ((this.glMultiTexBufferEXT = GLContext.getFunctionAddress("glMultiTexBufferEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glTextureParameterIivEXT = GLContext.getFunctionAddress("glTextureParameterIivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glTextureParameterIuivEXT = GLContext.getFunctionAddress("glTextureParameterIuivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glGetTextureParameterIivEXT = GLContext.getFunctionAddress("glGetTextureParameterIivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glGetTextureParameterIuivEXT = GLContext.getFunctionAddress("glGetTextureParameterIuivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glMultiTexParameterIivEXT = GLContext.getFunctionAddress("glMultiTexParameterIivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glMultiTexParameterIuivEXT = GLContext.getFunctionAddress("glMultiTexParameterIuivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glGetMultiTexParameterIivEXT = GLContext.getFunctionAddress("glGetMultiTexParameterIivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_texture_integer")) || ((this.glGetMultiTexParameterIuivEXT = GLContext.getFunctionAddress("glGetMultiTexParameterIuivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform1uiEXT = GLContext.getFunctionAddress("glProgramUniform1uiEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform2uiEXT = GLContext.getFunctionAddress("glProgramUniform2uiEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform3uiEXT = GLContext.getFunctionAddress("glProgramUniform3uiEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform4uiEXT = GLContext.getFunctionAddress("glProgramUniform4uiEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform1uivEXT = GLContext.getFunctionAddress("glProgramUniform1uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform2uivEXT = GLContext.getFunctionAddress("glProgramUniform2uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform3uivEXT = GLContext.getFunctionAddress("glProgramUniform3uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_shader4")) || ((this.glProgramUniform4uivEXT = GLContext.getFunctionAddress("glProgramUniform4uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_gpu_program_parameters")) || ((this.glNamedProgramLocalParameters4fvEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameters4fvEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParameterI4iEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameterI4iEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParameterI4ivEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameterI4ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParametersI4ivEXT = GLContext.getFunctionAddress("glNamedProgramLocalParametersI4ivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParameterI4uiEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameterI4uiEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParameterI4uivEXT = GLContext.getFunctionAddress("glNamedProgramLocalParameterI4uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glNamedProgramLocalParametersI4uivEXT = GLContext.getFunctionAddress("glNamedProgramLocalParametersI4uivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glGetNamedProgramLocalParameterIivEXT = GLContext.getFunctionAddress("glGetNamedProgramLocalParameterIivEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_gpu_program4")) || ((this.glGetNamedProgramLocalParameterIuivEXT = GLContext.getFunctionAddress("glGetNamedProgramLocalParameterIuivEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glNamedRenderbufferStorageEXT = GLContext.getFunctionAddress("glNamedRenderbufferStorageEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glGetNamedRenderbufferParameterivEXT = GLContext.getFunctionAddress("glGetNamedRenderbufferParameterivEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_multisample"))) || ((this.glNamedRenderbufferStorageMultisampleEXT = GLContext.getFunctionAddress("glNamedRenderbufferStorageMultisampleEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_framebuffer_multisample_coverage")) || ((this.glNamedRenderbufferStorageMultisampleCoverageEXT = GLContext.getFunctionAddress("glNamedRenderbufferStorageMultisampleCoverageEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glCheckNamedFramebufferStatusEXT = GLContext.getFunctionAddress("glCheckNamedFramebufferStatusEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glNamedFramebufferTexture1DEXT = GLContext.getFunctionAddress("glNamedFramebufferTexture1DEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glNamedFramebufferTexture2DEXT = GLContext.getFunctionAddress("glNamedFramebufferTexture2DEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glNamedFramebufferTexture3DEXT = GLContext.getFunctionAddress("glNamedFramebufferTexture3DEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glNamedFramebufferRenderbufferEXT = GLContext.getFunctionAddress("glNamedFramebufferRenderbufferEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glGetNamedFramebufferAttachmentParameterivEXT = GLContext.getFunctionAddress("glGetNamedFramebufferAttachmentParameterivEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glGenerateTextureMipmapEXT = GLContext.getFunctionAddress("glGenerateTextureMipmapEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glGenerateMultiTexMipmapEXT = GLContext.getFunctionAddress("glGenerateMultiTexMipmapEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glFramebufferDrawBufferEXT = GLContext.getFunctionAddress("glFramebufferDrawBufferEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glFramebufferDrawBuffersEXT = GLContext.getFunctionAddress("glFramebufferDrawBuffersEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glFramebufferReadBufferEXT = GLContext.getFunctionAddress("glFramebufferReadBufferEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL30")) && (!supported_extensions.contains("GL_EXT_framebuffer_object"))) || ((this.glGetFramebufferParameterivEXT = GLContext.getFunctionAddress("glGetFramebufferParameterivEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("OpenGL31")) && (!supported_extensions.contains("GL_ARB_copy_buffer"))) || ((this.glNamedCopyBufferSubDataEXT = GLContext.getFunctionAddress("glNamedCopyBufferSubDataEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("GL_EXT_geometry_shader4")) && (!supported_extensions.contains("GL_NV_geometry_program4"))) || ((this.glNamedFramebufferTextureEXT = GLContext.getFunctionAddress("glNamedFramebufferTextureEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("GL_EXT_geometry_shader4")) && (!supported_extensions.contains("GL_NV_geometry_program4"))) || ((this.glNamedFramebufferTextureLayerEXT = GLContext.getFunctionAddress("glNamedFramebufferTextureLayerEXT")) != 0L) ? 1 : 0) & (((!supported_extensions.contains("GL_EXT_geometry_shader4")) && (!supported_extensions.contains("GL_NV_geometry_program4"))) || ((this.glNamedFramebufferTextureFaceEXT = GLContext.getFunctionAddress("glNamedFramebufferTextureFaceEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_explicit_multisample")) || ((this.glTextureRenderbufferEXT = GLContext.getFunctionAddress("glTextureRenderbufferEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_NV_explicit_multisample")) || ((this.glMultiTexRenderbufferEXT = GLContext.getFunctionAddress("glMultiTexRenderbufferEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayVertexOffsetEXT = GLContext.getFunctionAddress("glVertexArrayVertexOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayColorOffsetEXT = GLContext.getFunctionAddress("glVertexArrayColorOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayEdgeFlagOffsetEXT = GLContext.getFunctionAddress("glVertexArrayEdgeFlagOffsetEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayIndexOffsetEXT = GLContext.getFunctionAddress("glVertexArrayIndexOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayNormalOffsetEXT = GLContext.getFunctionAddress("glVertexArrayNormalOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayTexCoordOffsetEXT = GLContext.getFunctionAddress("glVertexArrayTexCoordOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayMultiTexCoordOffsetEXT = GLContext.getFunctionAddress("glVertexArrayMultiTexCoordOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayFogCoordOffsetEXT = GLContext.getFunctionAddress("glVertexArrayFogCoordOffsetEXT")) != 0L) ? 1 : 0) & ((forwardCompatible) || (!supported_extensions.contains("OpenGL30")) || ((this.glVertexArraySecondaryColorOffsetEXT = GLContext.getFunctionAddress("glVertexArraySecondaryColorOffsetEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayVertexAttribOffsetEXT = GLContext.getFunctionAddress("glVertexArrayVertexAttribOffsetEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glVertexArrayVertexAttribIOffsetEXT = GLContext.getFunctionAddress("glVertexArrayVertexAttribIOffsetEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glEnableVertexArrayEXT = GLContext.getFunctionAddress("glEnableVertexArrayEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glDisableVertexArrayEXT = GLContext.getFunctionAddress("glDisableVertexArrayEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glEnableVertexArrayAttribEXT = GLContext.getFunctionAddress("glEnableVertexArrayAttribEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glDisableVertexArrayAttribEXT = GLContext.getFunctionAddress("glDisableVertexArrayAttribEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glGetVertexArrayIntegervEXT = GLContext.getFunctionAddress("glGetVertexArrayIntegervEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glGetVertexArrayPointervEXT = GLContext.getFunctionAddress("glGetVertexArrayPointervEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glGetVertexArrayIntegeri_vEXT = GLContext.getFunctionAddress("glGetVertexArrayIntegeri_vEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glGetVertexArrayPointeri_vEXT = GLContext.getFunctionAddress("glGetVertexArrayPointeri_vEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glMapNamedBufferRangeEXT = GLContext.getFunctionAddress("glMapNamedBufferRangeEXT")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("OpenGL30")) || ((this.glFlushMappedNamedBufferRangeEXT = GLContext.getFunctionAddress("glFlushMappedNamedBufferRangeEXT")) != 0L) ? 1 : 0);
/* 2729:     */   }
/* 2730:     */   
/* 2731:     */   private boolean EXT_draw_buffers2_initNativeFunctionAddresses()
/* 2732:     */   {
/* 2733:3697 */     return ((this.glColorMaskIndexedEXT = GLContext.getFunctionAddress("glColorMaskIndexedEXT")) != 0L ? 1 : 0) & ((this.glGetBooleanIndexedvEXT = GLContext.getFunctionAddress("glGetBooleanIndexedvEXT")) != 0L ? 1 : 0) & ((this.glGetIntegerIndexedvEXT = GLContext.getFunctionAddress("glGetIntegerIndexedvEXT")) != 0L ? 1 : 0) & ((this.glEnableIndexedEXT = GLContext.getFunctionAddress("glEnableIndexedEXT")) != 0L ? 1 : 0) & ((this.glDisableIndexedEXT = GLContext.getFunctionAddress("glDisableIndexedEXT")) != 0L ? 1 : 0) & ((this.glIsEnabledIndexedEXT = GLContext.getFunctionAddress("glIsEnabledIndexedEXT")) != 0L ? 1 : 0);
/* 2734:     */   }
/* 2735:     */   
/* 2736:     */   private boolean EXT_draw_instanced_initNativeFunctionAddresses()
/* 2737:     */   {
/* 2738:3707 */     return ((this.glDrawArraysInstancedEXT = GLContext.getFunctionAddress("glDrawArraysInstancedEXT")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedEXT = GLContext.getFunctionAddress("glDrawElementsInstancedEXT")) != 0L ? 1 : 0);
/* 2739:     */   }
/* 2740:     */   
/* 2741:     */   private boolean EXT_draw_range_elements_initNativeFunctionAddresses()
/* 2742:     */   {
/* 2743:3713 */     return (this.glDrawRangeElementsEXT = GLContext.getFunctionAddress("glDrawRangeElementsEXT")) != 0L;
/* 2744:     */   }
/* 2745:     */   
/* 2746:     */   private boolean EXT_fog_coord_initNativeFunctionAddresses()
/* 2747:     */   {
/* 2748:3718 */     return ((this.glFogCoordfEXT = GLContext.getFunctionAddress("glFogCoordfEXT")) != 0L ? 1 : 0) & ((this.glFogCoorddEXT = GLContext.getFunctionAddress("glFogCoorddEXT")) != 0L ? 1 : 0) & ((this.glFogCoordPointerEXT = GLContext.getFunctionAddress("glFogCoordPointerEXT")) != 0L ? 1 : 0);
/* 2749:     */   }
/* 2750:     */   
/* 2751:     */   private boolean EXT_framebuffer_blit_initNativeFunctionAddresses()
/* 2752:     */   {
/* 2753:3725 */     return (this.glBlitFramebufferEXT = GLContext.getFunctionAddress("glBlitFramebufferEXT")) != 0L;
/* 2754:     */   }
/* 2755:     */   
/* 2756:     */   private boolean EXT_framebuffer_multisample_initNativeFunctionAddresses()
/* 2757:     */   {
/* 2758:3730 */     return (this.glRenderbufferStorageMultisampleEXT = GLContext.getFunctionAddress("glRenderbufferStorageMultisampleEXT")) != 0L;
/* 2759:     */   }
/* 2760:     */   
/* 2761:     */   private boolean EXT_framebuffer_object_initNativeFunctionAddresses()
/* 2762:     */   {
/* 2763:3735 */     return ((this.glIsRenderbufferEXT = GLContext.getFunctionAddress("glIsRenderbufferEXT")) != 0L ? 1 : 0) & ((this.glBindRenderbufferEXT = GLContext.getFunctionAddress("glBindRenderbufferEXT")) != 0L ? 1 : 0) & ((this.glDeleteRenderbuffersEXT = GLContext.getFunctionAddress("glDeleteRenderbuffersEXT")) != 0L ? 1 : 0) & ((this.glGenRenderbuffersEXT = GLContext.getFunctionAddress("glGenRenderbuffersEXT")) != 0L ? 1 : 0) & ((this.glRenderbufferStorageEXT = GLContext.getFunctionAddress("glRenderbufferStorageEXT")) != 0L ? 1 : 0) & ((this.glGetRenderbufferParameterivEXT = GLContext.getFunctionAddress("glGetRenderbufferParameterivEXT")) != 0L ? 1 : 0) & ((this.glIsFramebufferEXT = GLContext.getFunctionAddress("glIsFramebufferEXT")) != 0L ? 1 : 0) & ((this.glBindFramebufferEXT = GLContext.getFunctionAddress("glBindFramebufferEXT")) != 0L ? 1 : 0) & ((this.glDeleteFramebuffersEXT = GLContext.getFunctionAddress("glDeleteFramebuffersEXT")) != 0L ? 1 : 0) & ((this.glGenFramebuffersEXT = GLContext.getFunctionAddress("glGenFramebuffersEXT")) != 0L ? 1 : 0) & ((this.glCheckFramebufferStatusEXT = GLContext.getFunctionAddress("glCheckFramebufferStatusEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTexture1DEXT = GLContext.getFunctionAddress("glFramebufferTexture1DEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTexture2DEXT = GLContext.getFunctionAddress("glFramebufferTexture2DEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTexture3DEXT = GLContext.getFunctionAddress("glFramebufferTexture3DEXT")) != 0L ? 1 : 0) & ((this.glFramebufferRenderbufferEXT = GLContext.getFunctionAddress("glFramebufferRenderbufferEXT")) != 0L ? 1 : 0) & ((this.glGetFramebufferAttachmentParameterivEXT = GLContext.getFunctionAddress("glGetFramebufferAttachmentParameterivEXT")) != 0L ? 1 : 0) & ((this.glGenerateMipmapEXT = GLContext.getFunctionAddress("glGenerateMipmapEXT")) != 0L ? 1 : 0);
/* 2764:     */   }
/* 2765:     */   
/* 2766:     */   private boolean EXT_geometry_shader4_initNativeFunctionAddresses()
/* 2767:     */   {
/* 2768:3756 */     return ((this.glProgramParameteriEXT = GLContext.getFunctionAddress("glProgramParameteriEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTextureEXT = GLContext.getFunctionAddress("glFramebufferTextureEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTextureLayerEXT = GLContext.getFunctionAddress("glFramebufferTextureLayerEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTextureFaceEXT = GLContext.getFunctionAddress("glFramebufferTextureFaceEXT")) != 0L ? 1 : 0);
/* 2769:     */   }
/* 2770:     */   
/* 2771:     */   private boolean EXT_gpu_program_parameters_initNativeFunctionAddresses()
/* 2772:     */   {
/* 2773:3764 */     return ((this.glProgramEnvParameters4fvEXT = GLContext.getFunctionAddress("glProgramEnvParameters4fvEXT")) != 0L ? 1 : 0) & ((this.glProgramLocalParameters4fvEXT = GLContext.getFunctionAddress("glProgramLocalParameters4fvEXT")) != 0L ? 1 : 0);
/* 2774:     */   }
/* 2775:     */   
/* 2776:     */   private boolean EXT_gpu_shader4_initNativeFunctionAddresses()
/* 2777:     */   {
/* 2778:3770 */     return ((this.glVertexAttribI1iEXT = GLContext.getFunctionAddress("glVertexAttribI1iEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI2iEXT = GLContext.getFunctionAddress("glVertexAttribI2iEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI3iEXT = GLContext.getFunctionAddress("glVertexAttribI3iEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4iEXT = GLContext.getFunctionAddress("glVertexAttribI4iEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI1uiEXT = GLContext.getFunctionAddress("glVertexAttribI1uiEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI2uiEXT = GLContext.getFunctionAddress("glVertexAttribI2uiEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI3uiEXT = GLContext.getFunctionAddress("glVertexAttribI3uiEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4uiEXT = GLContext.getFunctionAddress("glVertexAttribI4uiEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI1ivEXT = GLContext.getFunctionAddress("glVertexAttribI1ivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI2ivEXT = GLContext.getFunctionAddress("glVertexAttribI2ivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI3ivEXT = GLContext.getFunctionAddress("glVertexAttribI3ivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4ivEXT = GLContext.getFunctionAddress("glVertexAttribI4ivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI1uivEXT = GLContext.getFunctionAddress("glVertexAttribI1uivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI2uivEXT = GLContext.getFunctionAddress("glVertexAttribI2uivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI3uivEXT = GLContext.getFunctionAddress("glVertexAttribI3uivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4uivEXT = GLContext.getFunctionAddress("glVertexAttribI4uivEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4bvEXT = GLContext.getFunctionAddress("glVertexAttribI4bvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4svEXT = GLContext.getFunctionAddress("glVertexAttribI4svEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4ubvEXT = GLContext.getFunctionAddress("glVertexAttribI4ubvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribI4usvEXT = GLContext.getFunctionAddress("glVertexAttribI4usvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribIPointerEXT = GLContext.getFunctionAddress("glVertexAttribIPointerEXT")) != 0L ? 1 : 0) & ((this.glGetVertexAttribIivEXT = GLContext.getFunctionAddress("glGetVertexAttribIivEXT")) != 0L ? 1 : 0) & ((this.glGetVertexAttribIuivEXT = GLContext.getFunctionAddress("glGetVertexAttribIuivEXT")) != 0L ? 1 : 0) & ((this.glUniform1uiEXT = GLContext.getFunctionAddress("glUniform1uiEXT")) != 0L ? 1 : 0) & ((this.glUniform2uiEXT = GLContext.getFunctionAddress("glUniform2uiEXT")) != 0L ? 1 : 0) & ((this.glUniform3uiEXT = GLContext.getFunctionAddress("glUniform3uiEXT")) != 0L ? 1 : 0) & ((this.glUniform4uiEXT = GLContext.getFunctionAddress("glUniform4uiEXT")) != 0L ? 1 : 0) & ((this.glUniform1uivEXT = GLContext.getFunctionAddress("glUniform1uivEXT")) != 0L ? 1 : 0) & ((this.glUniform2uivEXT = GLContext.getFunctionAddress("glUniform2uivEXT")) != 0L ? 1 : 0) & ((this.glUniform3uivEXT = GLContext.getFunctionAddress("glUniform3uivEXT")) != 0L ? 1 : 0) & ((this.glUniform4uivEXT = GLContext.getFunctionAddress("glUniform4uivEXT")) != 0L ? 1 : 0) & ((this.glGetUniformuivEXT = GLContext.getFunctionAddress("glGetUniformuivEXT")) != 0L ? 1 : 0) & ((this.glBindFragDataLocationEXT = GLContext.getFunctionAddress("glBindFragDataLocationEXT")) != 0L ? 1 : 0) & ((this.glGetFragDataLocationEXT = GLContext.getFunctionAddress("glGetFragDataLocationEXT")) != 0L ? 1 : 0);
/* 2779:     */   }
/* 2780:     */   
/* 2781:     */   private boolean EXT_multi_draw_arrays_initNativeFunctionAddresses()
/* 2782:     */   {
/* 2783:3808 */     return (this.glMultiDrawArraysEXT = GLContext.getFunctionAddress("glMultiDrawArraysEXT")) != 0L;
/* 2784:     */   }
/* 2785:     */   
/* 2786:     */   private boolean EXT_paletted_texture_initNativeFunctionAddresses()
/* 2787:     */   {
/* 2788:3813 */     return ((this.glColorTableEXT = GLContext.getFunctionAddress("glColorTableEXT")) != 0L ? 1 : 0) & ((this.glColorSubTableEXT = GLContext.getFunctionAddress("glColorSubTableEXT")) != 0L ? 1 : 0) & ((this.glGetColorTableEXT = GLContext.getFunctionAddress("glGetColorTableEXT")) != 0L ? 1 : 0) & ((this.glGetColorTableParameterivEXT = GLContext.getFunctionAddress("glGetColorTableParameterivEXT")) != 0L ? 1 : 0) & ((this.glGetColorTableParameterfvEXT = GLContext.getFunctionAddress("glGetColorTableParameterfvEXT")) != 0L ? 1 : 0);
/* 2789:     */   }
/* 2790:     */   
/* 2791:     */   private boolean EXT_point_parameters_initNativeFunctionAddresses()
/* 2792:     */   {
/* 2793:3822 */     return ((this.glPointParameterfEXT = GLContext.getFunctionAddress("glPointParameterfEXT")) != 0L ? 1 : 0) & ((this.glPointParameterfvEXT = GLContext.getFunctionAddress("glPointParameterfvEXT")) != 0L ? 1 : 0);
/* 2794:     */   }
/* 2795:     */   
/* 2796:     */   private boolean EXT_provoking_vertex_initNativeFunctionAddresses()
/* 2797:     */   {
/* 2798:3828 */     return (this.glProvokingVertexEXT = GLContext.getFunctionAddress("glProvokingVertexEXT")) != 0L;
/* 2799:     */   }
/* 2800:     */   
/* 2801:     */   private boolean EXT_secondary_color_initNativeFunctionAddresses()
/* 2802:     */   {
/* 2803:3833 */     return ((this.glSecondaryColor3bEXT = GLContext.getFunctionAddress("glSecondaryColor3bEXT")) != 0L ? 1 : 0) & ((this.glSecondaryColor3fEXT = GLContext.getFunctionAddress("glSecondaryColor3fEXT")) != 0L ? 1 : 0) & ((this.glSecondaryColor3dEXT = GLContext.getFunctionAddress("glSecondaryColor3dEXT")) != 0L ? 1 : 0) & ((this.glSecondaryColor3ubEXT = GLContext.getFunctionAddress("glSecondaryColor3ubEXT")) != 0L ? 1 : 0) & ((this.glSecondaryColorPointerEXT = GLContext.getFunctionAddress("glSecondaryColorPointerEXT")) != 0L ? 1 : 0);
/* 2804:     */   }
/* 2805:     */   
/* 2806:     */   private boolean EXT_separate_shader_objects_initNativeFunctionAddresses()
/* 2807:     */   {
/* 2808:3842 */     return ((this.glUseShaderProgramEXT = GLContext.getFunctionAddress("glUseShaderProgramEXT")) != 0L ? 1 : 0) & ((this.glActiveProgramEXT = GLContext.getFunctionAddress("glActiveProgramEXT")) != 0L ? 1 : 0) & ((this.glCreateShaderProgramEXT = GLContext.getFunctionAddress("glCreateShaderProgramEXT")) != 0L ? 1 : 0);
/* 2809:     */   }
/* 2810:     */   
/* 2811:     */   private boolean EXT_shader_image_load_store_initNativeFunctionAddresses()
/* 2812:     */   {
/* 2813:3849 */     return ((this.glBindImageTextureEXT = GLContext.getFunctionAddress("glBindImageTextureEXT")) != 0L ? 1 : 0) & ((this.glMemoryBarrierEXT = GLContext.getFunctionAddress("glMemoryBarrierEXT")) != 0L ? 1 : 0);
/* 2814:     */   }
/* 2815:     */   
/* 2816:     */   private boolean EXT_stencil_clear_tag_initNativeFunctionAddresses()
/* 2817:     */   {
/* 2818:3855 */     return (this.glStencilClearTagEXT = GLContext.getFunctionAddress("glStencilClearTagEXT")) != 0L;
/* 2819:     */   }
/* 2820:     */   
/* 2821:     */   private boolean EXT_stencil_two_side_initNativeFunctionAddresses()
/* 2822:     */   {
/* 2823:3860 */     return (this.glActiveStencilFaceEXT = GLContext.getFunctionAddress("glActiveStencilFaceEXT")) != 0L;
/* 2824:     */   }
/* 2825:     */   
/* 2826:     */   private boolean EXT_texture_array_initNativeFunctionAddresses()
/* 2827:     */   {
/* 2828:3865 */     return (this.glFramebufferTextureLayerEXT = GLContext.getFunctionAddress("glFramebufferTextureLayerEXT")) != 0L;
/* 2829:     */   }
/* 2830:     */   
/* 2831:     */   private boolean EXT_texture_buffer_object_initNativeFunctionAddresses()
/* 2832:     */   {
/* 2833:3870 */     return (this.glTexBufferEXT = GLContext.getFunctionAddress("glTexBufferEXT")) != 0L;
/* 2834:     */   }
/* 2835:     */   
/* 2836:     */   private boolean EXT_texture_integer_initNativeFunctionAddresses()
/* 2837:     */   {
/* 2838:3875 */     return ((this.glClearColorIiEXT = GLContext.getFunctionAddress("glClearColorIiEXT")) != 0L ? 1 : 0) & ((this.glClearColorIuiEXT = GLContext.getFunctionAddress("glClearColorIuiEXT")) != 0L ? 1 : 0) & ((this.glTexParameterIivEXT = GLContext.getFunctionAddress("glTexParameterIivEXT")) != 0L ? 1 : 0) & ((this.glTexParameterIuivEXT = GLContext.getFunctionAddress("glTexParameterIuivEXT")) != 0L ? 1 : 0) & ((this.glGetTexParameterIivEXT = GLContext.getFunctionAddress("glGetTexParameterIivEXT")) != 0L ? 1 : 0) & ((this.glGetTexParameterIuivEXT = GLContext.getFunctionAddress("glGetTexParameterIuivEXT")) != 0L ? 1 : 0);
/* 2839:     */   }
/* 2840:     */   
/* 2841:     */   private boolean EXT_timer_query_initNativeFunctionAddresses()
/* 2842:     */   {
/* 2843:3885 */     return ((this.glGetQueryObjecti64vEXT = GLContext.getFunctionAddress("glGetQueryObjecti64vEXT")) != 0L ? 1 : 0) & ((this.glGetQueryObjectui64vEXT = GLContext.getFunctionAddress("glGetQueryObjectui64vEXT")) != 0L ? 1 : 0);
/* 2844:     */   }
/* 2845:     */   
/* 2846:     */   private boolean EXT_transform_feedback_initNativeFunctionAddresses()
/* 2847:     */   {
/* 2848:3891 */     return ((this.glBindBufferRangeEXT = GLContext.getFunctionAddress("glBindBufferRangeEXT")) != 0L ? 1 : 0) & ((this.glBindBufferOffsetEXT = GLContext.getFunctionAddress("glBindBufferOffsetEXT")) != 0L ? 1 : 0) & ((this.glBindBufferBaseEXT = GLContext.getFunctionAddress("glBindBufferBaseEXT")) != 0L ? 1 : 0) & ((this.glBeginTransformFeedbackEXT = GLContext.getFunctionAddress("glBeginTransformFeedbackEXT")) != 0L ? 1 : 0) & ((this.glEndTransformFeedbackEXT = GLContext.getFunctionAddress("glEndTransformFeedbackEXT")) != 0L ? 1 : 0) & ((this.glTransformFeedbackVaryingsEXT = GLContext.getFunctionAddress("glTransformFeedbackVaryingsEXT")) != 0L ? 1 : 0) & ((this.glGetTransformFeedbackVaryingEXT = GLContext.getFunctionAddress("glGetTransformFeedbackVaryingEXT")) != 0L ? 1 : 0);
/* 2849:     */   }
/* 2850:     */   
/* 2851:     */   private boolean EXT_vertex_attrib_64bit_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 2852:     */   {
/* 2853:3902 */     return ((this.glVertexAttribL1dEXT = GLContext.getFunctionAddress("glVertexAttribL1dEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL2dEXT = GLContext.getFunctionAddress("glVertexAttribL2dEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL3dEXT = GLContext.getFunctionAddress("glVertexAttribL3dEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL4dEXT = GLContext.getFunctionAddress("glVertexAttribL4dEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL1dvEXT = GLContext.getFunctionAddress("glVertexAttribL1dvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL2dvEXT = GLContext.getFunctionAddress("glVertexAttribL2dvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL3dvEXT = GLContext.getFunctionAddress("glVertexAttribL3dvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribL4dvEXT = GLContext.getFunctionAddress("glVertexAttribL4dvEXT")) != 0L ? 1 : 0) & ((this.glVertexAttribLPointerEXT = GLContext.getFunctionAddress("glVertexAttribLPointerEXT")) != 0L ? 1 : 0) & ((this.glGetVertexAttribLdvEXT = GLContext.getFunctionAddress("glGetVertexAttribLdvEXT")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glVertexArrayVertexAttribLOffsetEXT = GLContext.getFunctionAddress("glVertexArrayVertexAttribLOffsetEXT")) != 0L) ? 1 : 0);
/* 2854:     */   }
/* 2855:     */   
/* 2856:     */   private boolean EXT_vertex_shader_initNativeFunctionAddresses()
/* 2857:     */   {
/* 2858:3917 */     return ((this.glBeginVertexShaderEXT = GLContext.getFunctionAddress("glBeginVertexShaderEXT")) != 0L ? 1 : 0) & ((this.glEndVertexShaderEXT = GLContext.getFunctionAddress("glEndVertexShaderEXT")) != 0L ? 1 : 0) & ((this.glBindVertexShaderEXT = GLContext.getFunctionAddress("glBindVertexShaderEXT")) != 0L ? 1 : 0) & ((this.glGenVertexShadersEXT = GLContext.getFunctionAddress("glGenVertexShadersEXT")) != 0L ? 1 : 0) & ((this.glDeleteVertexShaderEXT = GLContext.getFunctionAddress("glDeleteVertexShaderEXT")) != 0L ? 1 : 0) & ((this.glShaderOp1EXT = GLContext.getFunctionAddress("glShaderOp1EXT")) != 0L ? 1 : 0) & ((this.glShaderOp2EXT = GLContext.getFunctionAddress("glShaderOp2EXT")) != 0L ? 1 : 0) & ((this.glShaderOp3EXT = GLContext.getFunctionAddress("glShaderOp3EXT")) != 0L ? 1 : 0) & ((this.glSwizzleEXT = GLContext.getFunctionAddress("glSwizzleEXT")) != 0L ? 1 : 0) & ((this.glWriteMaskEXT = GLContext.getFunctionAddress("glWriteMaskEXT")) != 0L ? 1 : 0) & ((this.glInsertComponentEXT = GLContext.getFunctionAddress("glInsertComponentEXT")) != 0L ? 1 : 0) & ((this.glExtractComponentEXT = GLContext.getFunctionAddress("glExtractComponentEXT")) != 0L ? 1 : 0) & ((this.glGenSymbolsEXT = GLContext.getFunctionAddress("glGenSymbolsEXT")) != 0L ? 1 : 0) & ((this.glSetInvariantEXT = GLContext.getFunctionAddress("glSetInvariantEXT")) != 0L ? 1 : 0) & ((this.glSetLocalConstantEXT = GLContext.getFunctionAddress("glSetLocalConstantEXT")) != 0L ? 1 : 0) & ((this.glVariantbvEXT = GLContext.getFunctionAddress("glVariantbvEXT")) != 0L ? 1 : 0) & ((this.glVariantsvEXT = GLContext.getFunctionAddress("glVariantsvEXT")) != 0L ? 1 : 0) & ((this.glVariantivEXT = GLContext.getFunctionAddress("glVariantivEXT")) != 0L ? 1 : 0) & ((this.glVariantfvEXT = GLContext.getFunctionAddress("glVariantfvEXT")) != 0L ? 1 : 0) & ((this.glVariantdvEXT = GLContext.getFunctionAddress("glVariantdvEXT")) != 0L ? 1 : 0) & ((this.glVariantubvEXT = GLContext.getFunctionAddress("glVariantubvEXT")) != 0L ? 1 : 0) & ((this.glVariantusvEXT = GLContext.getFunctionAddress("glVariantusvEXT")) != 0L ? 1 : 0) & ((this.glVariantuivEXT = GLContext.getFunctionAddress("glVariantuivEXT")) != 0L ? 1 : 0) & ((this.glVariantPointerEXT = GLContext.getFunctionAddress("glVariantPointerEXT")) != 0L ? 1 : 0) & ((this.glEnableVariantClientStateEXT = GLContext.getFunctionAddress("glEnableVariantClientStateEXT")) != 0L ? 1 : 0) & ((this.glDisableVariantClientStateEXT = GLContext.getFunctionAddress("glDisableVariantClientStateEXT")) != 0L ? 1 : 0) & ((this.glBindLightParameterEXT = GLContext.getFunctionAddress("glBindLightParameterEXT")) != 0L ? 1 : 0) & ((this.glBindMaterialParameterEXT = GLContext.getFunctionAddress("glBindMaterialParameterEXT")) != 0L ? 1 : 0) & ((this.glBindTexGenParameterEXT = GLContext.getFunctionAddress("glBindTexGenParameterEXT")) != 0L ? 1 : 0) & ((this.glBindTextureUnitParameterEXT = GLContext.getFunctionAddress("glBindTextureUnitParameterEXT")) != 0L ? 1 : 0) & ((this.glBindParameterEXT = GLContext.getFunctionAddress("glBindParameterEXT")) != 0L ? 1 : 0) & ((this.glIsVariantEnabledEXT = GLContext.getFunctionAddress("glIsVariantEnabledEXT")) != 0L ? 1 : 0) & ((this.glGetVariantBooleanvEXT = GLContext.getFunctionAddress("glGetVariantBooleanvEXT")) != 0L ? 1 : 0) & ((this.glGetVariantIntegervEXT = GLContext.getFunctionAddress("glGetVariantIntegervEXT")) != 0L ? 1 : 0) & ((this.glGetVariantFloatvEXT = GLContext.getFunctionAddress("glGetVariantFloatvEXT")) != 0L ? 1 : 0) & ((this.glGetVariantPointervEXT = GLContext.getFunctionAddress("glGetVariantPointervEXT")) != 0L ? 1 : 0) & ((this.glGetInvariantBooleanvEXT = GLContext.getFunctionAddress("glGetInvariantBooleanvEXT")) != 0L ? 1 : 0) & ((this.glGetInvariantIntegervEXT = GLContext.getFunctionAddress("glGetInvariantIntegervEXT")) != 0L ? 1 : 0) & ((this.glGetInvariantFloatvEXT = GLContext.getFunctionAddress("glGetInvariantFloatvEXT")) != 0L ? 1 : 0) & ((this.glGetLocalConstantBooleanvEXT = GLContext.getFunctionAddress("glGetLocalConstantBooleanvEXT")) != 0L ? 1 : 0) & ((this.glGetLocalConstantIntegervEXT = GLContext.getFunctionAddress("glGetLocalConstantIntegervEXT")) != 0L ? 1 : 0) & ((this.glGetLocalConstantFloatvEXT = GLContext.getFunctionAddress("glGetLocalConstantFloatvEXT")) != 0L ? 1 : 0);
/* 2859:     */   }
/* 2860:     */   
/* 2861:     */   private boolean EXT_vertex_weighting_initNativeFunctionAddresses()
/* 2862:     */   {
/* 2863:3963 */     return ((this.glVertexWeightfEXT = GLContext.getFunctionAddress("glVertexWeightfEXT")) != 0L ? 1 : 0) & ((this.glVertexWeightPointerEXT = GLContext.getFunctionAddress("glVertexWeightPointerEXT")) != 0L ? 1 : 0);
/* 2864:     */   }
/* 2865:     */   
/* 2866:     */   private boolean GL11_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2867:     */   {
/* 2868:3969 */     return ((forwardCompatible) || ((this.glAccum = GLContext.getFunctionAddress("glAccum")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glAlphaFunc = GLContext.getFunctionAddress("glAlphaFunc")) != 0L) ? 1 : 0) & ((this.glClearColor = GLContext.getFunctionAddress("glClearColor")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glClearAccum = GLContext.getFunctionAddress("glClearAccum")) != 0L) ? 1 : 0) & ((this.glClear = GLContext.getFunctionAddress("glClear")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glCallLists = GLContext.getFunctionAddress("glCallLists")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glCallList = GLContext.getFunctionAddress("glCallList")) != 0L) ? 1 : 0) & ((this.glBlendFunc = GLContext.getFunctionAddress("glBlendFunc")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glBitmap = GLContext.getFunctionAddress("glBitmap")) != 0L) ? 1 : 0) & ((this.glBindTexture = GLContext.getFunctionAddress("glBindTexture")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glPrioritizeTextures = GLContext.getFunctionAddress("glPrioritizeTextures")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glAreTexturesResident = GLContext.getFunctionAddress("glAreTexturesResident")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glBegin = GLContext.getFunctionAddress("glBegin")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEnd = GLContext.getFunctionAddress("glEnd")) != 0L) ? 1 : 0) & ((this.glArrayElement = GLContext.getFunctionAddress("glArrayElement")) != 0L ? 1 : 0) & ((this.glClearDepth = GLContext.getFunctionAddress("glClearDepth")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glDeleteLists = GLContext.getFunctionAddress("glDeleteLists")) != 0L) ? 1 : 0) & ((this.glDeleteTextures = GLContext.getFunctionAddress("glDeleteTextures")) != 0L ? 1 : 0) & ((this.glCullFace = GLContext.getFunctionAddress("glCullFace")) != 0L ? 1 : 0) & ((this.glCopyTexSubImage2D = GLContext.getFunctionAddress("glCopyTexSubImage2D")) != 0L ? 1 : 0) & ((this.glCopyTexSubImage1D = GLContext.getFunctionAddress("glCopyTexSubImage1D")) != 0L ? 1 : 0) & ((this.glCopyTexImage2D = GLContext.getFunctionAddress("glCopyTexImage2D")) != 0L ? 1 : 0) & ((this.glCopyTexImage1D = GLContext.getFunctionAddress("glCopyTexImage1D")) != 0L ? 1 : 0) & ((this.glCopyPixels = GLContext.getFunctionAddress("glCopyPixels")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glColorPointer = GLContext.getFunctionAddress("glColorPointer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorMaterial = GLContext.getFunctionAddress("glColorMaterial")) != 0L) ? 1 : 0) & ((this.glColorMask = GLContext.getFunctionAddress("glColorMask")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glColor3b = GLContext.getFunctionAddress("glColor3b")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor3f = GLContext.getFunctionAddress("glColor3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor3d = GLContext.getFunctionAddress("glColor3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor3ub = GLContext.getFunctionAddress("glColor3ub")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor4b = GLContext.getFunctionAddress("glColor4b")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor4f = GLContext.getFunctionAddress("glColor4f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor4d = GLContext.getFunctionAddress("glColor4d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColor4ub = GLContext.getFunctionAddress("glColor4ub")) != 0L) ? 1 : 0) & ((this.glClipPlane = GLContext.getFunctionAddress("glClipPlane")) != 0L ? 1 : 0) & ((this.glClearStencil = GLContext.getFunctionAddress("glClearStencil")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glEvalPoint1 = GLContext.getFunctionAddress("glEvalPoint1")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalPoint2 = GLContext.getFunctionAddress("glEvalPoint2")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalMesh1 = GLContext.getFunctionAddress("glEvalMesh1")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalMesh2 = GLContext.getFunctionAddress("glEvalMesh2")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalCoord1f = GLContext.getFunctionAddress("glEvalCoord1f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalCoord1d = GLContext.getFunctionAddress("glEvalCoord1d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalCoord2f = GLContext.getFunctionAddress("glEvalCoord2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEvalCoord2d = GLContext.getFunctionAddress("glEvalCoord2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEnableClientState = GLContext.getFunctionAddress("glEnableClientState")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glDisableClientState = GLContext.getFunctionAddress("glDisableClientState")) != 0L) ? 1 : 0) & ((this.glEnable = GLContext.getFunctionAddress("glEnable")) != 0L ? 1 : 0) & ((this.glDisable = GLContext.getFunctionAddress("glDisable")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glEdgeFlagPointer = GLContext.getFunctionAddress("glEdgeFlagPointer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEdgeFlag = GLContext.getFunctionAddress("glEdgeFlag")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glDrawPixels = GLContext.getFunctionAddress("glDrawPixels")) != 0L) ? 1 : 0) & ((this.glDrawElements = GLContext.getFunctionAddress("glDrawElements")) != 0L ? 1 : 0) & ((this.glDrawBuffer = GLContext.getFunctionAddress("glDrawBuffer")) != 0L ? 1 : 0) & ((this.glDrawArrays = GLContext.getFunctionAddress("glDrawArrays")) != 0L ? 1 : 0) & ((this.glDepthRange = GLContext.getFunctionAddress("glDepthRange")) != 0L ? 1 : 0) & ((this.glDepthMask = GLContext.getFunctionAddress("glDepthMask")) != 0L ? 1 : 0) & ((this.glDepthFunc = GLContext.getFunctionAddress("glDepthFunc")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glFeedbackBuffer = GLContext.getFunctionAddress("glFeedbackBuffer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetPixelMapfv = GLContext.getFunctionAddress("glGetPixelMapfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetPixelMapuiv = GLContext.getFunctionAddress("glGetPixelMapuiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetPixelMapusv = GLContext.getFunctionAddress("glGetPixelMapusv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMaterialfv = GLContext.getFunctionAddress("glGetMaterialfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMaterialiv = GLContext.getFunctionAddress("glGetMaterialiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMapfv = GLContext.getFunctionAddress("glGetMapfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMapdv = GLContext.getFunctionAddress("glGetMapdv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetMapiv = GLContext.getFunctionAddress("glGetMapiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetLightfv = GLContext.getFunctionAddress("glGetLightfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetLightiv = GLContext.getFunctionAddress("glGetLightiv")) != 0L) ? 1 : 0) & ((this.glGetError = GLContext.getFunctionAddress("glGetError")) != 0L ? 1 : 0) & ((this.glGetClipPlane = GLContext.getFunctionAddress("glGetClipPlane")) != 0L ? 1 : 0) & ((this.glGetBooleanv = GLContext.getFunctionAddress("glGetBooleanv")) != 0L ? 1 : 0) & ((this.glGetDoublev = GLContext.getFunctionAddress("glGetDoublev")) != 0L ? 1 : 0) & ((this.glGetFloatv = GLContext.getFunctionAddress("glGetFloatv")) != 0L ? 1 : 0) & ((this.glGetIntegerv = GLContext.getFunctionAddress("glGetIntegerv")) != 0L ? 1 : 0) & ((this.glGenTextures = GLContext.getFunctionAddress("glGenTextures")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glGenLists = GLContext.getFunctionAddress("glGenLists")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFrustum = GLContext.getFunctionAddress("glFrustum")) != 0L) ? 1 : 0) & ((this.glFrontFace = GLContext.getFunctionAddress("glFrontFace")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glFogf = GLContext.getFunctionAddress("glFogf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFogi = GLContext.getFunctionAddress("glFogi")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFogfv = GLContext.getFunctionAddress("glFogfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFogiv = GLContext.getFunctionAddress("glFogiv")) != 0L) ? 1 : 0) & ((this.glFlush = GLContext.getFunctionAddress("glFlush")) != 0L ? 1 : 0) & ((this.glFinish = GLContext.getFunctionAddress("glFinish")) != 0L ? 1 : 0) & ((this.glGetPointerv = GLContext.getFunctionAddress("glGetPointerv")) != 0L ? 1 : 0) & ((this.glIsEnabled = GLContext.getFunctionAddress("glIsEnabled")) != 0L ? 1 : 0) & ((this.glInterleavedArrays = GLContext.getFunctionAddress("glInterleavedArrays")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glInitNames = GLContext.getFunctionAddress("glInitNames")) != 0L) ? 1 : 0) & ((this.glHint = GLContext.getFunctionAddress("glHint")) != 0L ? 1 : 0) & ((this.glGetTexParameterfv = GLContext.getFunctionAddress("glGetTexParameterfv")) != 0L ? 1 : 0) & ((this.glGetTexParameteriv = GLContext.getFunctionAddress("glGetTexParameteriv")) != 0L ? 1 : 0) & ((this.glGetTexLevelParameterfv = GLContext.getFunctionAddress("glGetTexLevelParameterfv")) != 0L ? 1 : 0) & ((this.glGetTexLevelParameteriv = GLContext.getFunctionAddress("glGetTexLevelParameteriv")) != 0L ? 1 : 0) & ((this.glGetTexImage = GLContext.getFunctionAddress("glGetTexImage")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glGetTexGeniv = GLContext.getFunctionAddress("glGetTexGeniv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetTexGenfv = GLContext.getFunctionAddress("glGetTexGenfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glGetTexGendv = GLContext.getFunctionAddress("glGetTexGendv")) != 0L) ? 1 : 0) & ((this.glGetTexEnviv = GLContext.getFunctionAddress("glGetTexEnviv")) != 0L ? 1 : 0) & ((this.glGetTexEnvfv = GLContext.getFunctionAddress("glGetTexEnvfv")) != 0L ? 1 : 0) & ((this.glGetString = GLContext.getFunctionAddress("glGetString")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glGetPolygonStipple = GLContext.getFunctionAddress("glGetPolygonStipple")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glIsList = GLContext.getFunctionAddress("glIsList")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMaterialf = GLContext.getFunctionAddress("glMaterialf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMateriali = GLContext.getFunctionAddress("glMateriali")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMaterialfv = GLContext.getFunctionAddress("glMaterialfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMaterialiv = GLContext.getFunctionAddress("glMaterialiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMapGrid1f = GLContext.getFunctionAddress("glMapGrid1f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMapGrid1d = GLContext.getFunctionAddress("glMapGrid1d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMapGrid2f = GLContext.getFunctionAddress("glMapGrid2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMapGrid2d = GLContext.getFunctionAddress("glMapGrid2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMap2f = GLContext.getFunctionAddress("glMap2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMap2d = GLContext.getFunctionAddress("glMap2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMap1f = GLContext.getFunctionAddress("glMap1f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMap1d = GLContext.getFunctionAddress("glMap1d")) != 0L) ? 1 : 0) & ((this.glLogicOp = GLContext.getFunctionAddress("glLogicOp")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glLoadName = GLContext.getFunctionAddress("glLoadName")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLoadMatrixf = GLContext.getFunctionAddress("glLoadMatrixf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLoadMatrixd = GLContext.getFunctionAddress("glLoadMatrixd")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLoadIdentity = GLContext.getFunctionAddress("glLoadIdentity")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glListBase = GLContext.getFunctionAddress("glListBase")) != 0L) ? 1 : 0) & ((this.glLineWidth = GLContext.getFunctionAddress("glLineWidth")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glLineStipple = GLContext.getFunctionAddress("glLineStipple")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightModelf = GLContext.getFunctionAddress("glLightModelf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightModeli = GLContext.getFunctionAddress("glLightModeli")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightModelfv = GLContext.getFunctionAddress("glLightModelfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightModeliv = GLContext.getFunctionAddress("glLightModeliv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightf = GLContext.getFunctionAddress("glLightf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLighti = GLContext.getFunctionAddress("glLighti")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightfv = GLContext.getFunctionAddress("glLightfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLightiv = GLContext.getFunctionAddress("glLightiv")) != 0L) ? 1 : 0) & ((this.glIsTexture = GLContext.getFunctionAddress("glIsTexture")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glMatrixMode = GLContext.getFunctionAddress("glMatrixMode")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPolygonStipple = GLContext.getFunctionAddress("glPolygonStipple")) != 0L) ? 1 : 0) & ((this.glPolygonOffset = GLContext.getFunctionAddress("glPolygonOffset")) != 0L ? 1 : 0) & ((this.glPolygonMode = GLContext.getFunctionAddress("glPolygonMode")) != 0L ? 1 : 0) & ((this.glPointSize = GLContext.getFunctionAddress("glPointSize")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glPixelZoom = GLContext.getFunctionAddress("glPixelZoom")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPixelTransferf = GLContext.getFunctionAddress("glPixelTransferf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPixelTransferi = GLContext.getFunctionAddress("glPixelTransferi")) != 0L) ? 1 : 0) & ((this.glPixelStoref = GLContext.getFunctionAddress("glPixelStoref")) != 0L ? 1 : 0) & ((this.glPixelStorei = GLContext.getFunctionAddress("glPixelStorei")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glPixelMapfv = GLContext.getFunctionAddress("glPixelMapfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPixelMapuiv = GLContext.getFunctionAddress("glPixelMapuiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPixelMapusv = GLContext.getFunctionAddress("glPixelMapusv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPassThrough = GLContext.getFunctionAddress("glPassThrough")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glOrtho = GLContext.getFunctionAddress("glOrtho")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormalPointer = GLContext.getFunctionAddress("glNormalPointer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormal3b = GLContext.getFunctionAddress("glNormal3b")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormal3f = GLContext.getFunctionAddress("glNormal3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormal3d = GLContext.getFunctionAddress("glNormal3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormal3i = GLContext.getFunctionAddress("glNormal3i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNewList = GLContext.getFunctionAddress("glNewList")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glEndList = GLContext.getFunctionAddress("glEndList")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultMatrixf = GLContext.getFunctionAddress("glMultMatrixf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultMatrixd = GLContext.getFunctionAddress("glMultMatrixd")) != 0L) ? 1 : 0) & ((this.glShadeModel = GLContext.getFunctionAddress("glShadeModel")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glSelectBuffer = GLContext.getFunctionAddress("glSelectBuffer")) != 0L) ? 1 : 0) & ((this.glScissor = GLContext.getFunctionAddress("glScissor")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glScalef = GLContext.getFunctionAddress("glScalef")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glScaled = GLContext.getFunctionAddress("glScaled")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRotatef = GLContext.getFunctionAddress("glRotatef")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRotated = GLContext.getFunctionAddress("glRotated")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRenderMode = GLContext.getFunctionAddress("glRenderMode")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRectf = GLContext.getFunctionAddress("glRectf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRectd = GLContext.getFunctionAddress("glRectd")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRecti = GLContext.getFunctionAddress("glRecti")) != 0L) ? 1 : 0) & ((this.glReadPixels = GLContext.getFunctionAddress("glReadPixels")) != 0L ? 1 : 0) & ((this.glReadBuffer = GLContext.getFunctionAddress("glReadBuffer")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos2f = GLContext.getFunctionAddress("glRasterPos2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos2d = GLContext.getFunctionAddress("glRasterPos2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos2i = GLContext.getFunctionAddress("glRasterPos2i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos3f = GLContext.getFunctionAddress("glRasterPos3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos3d = GLContext.getFunctionAddress("glRasterPos3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos3i = GLContext.getFunctionAddress("glRasterPos3i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos4f = GLContext.getFunctionAddress("glRasterPos4f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos4d = GLContext.getFunctionAddress("glRasterPos4d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glRasterPos4i = GLContext.getFunctionAddress("glRasterPos4i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPushName = GLContext.getFunctionAddress("glPushName")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPopName = GLContext.getFunctionAddress("glPopName")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPushMatrix = GLContext.getFunctionAddress("glPushMatrix")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPopMatrix = GLContext.getFunctionAddress("glPopMatrix")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPushClientAttrib = GLContext.getFunctionAddress("glPushClientAttrib")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPopClientAttrib = GLContext.getFunctionAddress("glPopClientAttrib")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPushAttrib = GLContext.getFunctionAddress("glPushAttrib")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glPopAttrib = GLContext.getFunctionAddress("glPopAttrib")) != 0L) ? 1 : 0) & ((this.glStencilFunc = GLContext.getFunctionAddress("glStencilFunc")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glVertexPointer = GLContext.getFunctionAddress("glVertexPointer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex2f = GLContext.getFunctionAddress("glVertex2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex2d = GLContext.getFunctionAddress("glVertex2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex2i = GLContext.getFunctionAddress("glVertex2i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex3f = GLContext.getFunctionAddress("glVertex3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex3d = GLContext.getFunctionAddress("glVertex3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex3i = GLContext.getFunctionAddress("glVertex3i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex4f = GLContext.getFunctionAddress("glVertex4f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex4d = GLContext.getFunctionAddress("glVertex4d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertex4i = GLContext.getFunctionAddress("glVertex4i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTranslatef = GLContext.getFunctionAddress("glTranslatef")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTranslated = GLContext.getFunctionAddress("glTranslated")) != 0L) ? 1 : 0) & ((this.glTexImage1D = GLContext.getFunctionAddress("glTexImage1D")) != 0L ? 1 : 0) & ((this.glTexImage2D = GLContext.getFunctionAddress("glTexImage2D")) != 0L ? 1 : 0) & ((this.glTexSubImage1D = GLContext.getFunctionAddress("glTexSubImage1D")) != 0L ? 1 : 0) & ((this.glTexSubImage2D = GLContext.getFunctionAddress("glTexSubImage2D")) != 0L ? 1 : 0) & ((this.glTexParameterf = GLContext.getFunctionAddress("glTexParameterf")) != 0L ? 1 : 0) & ((this.glTexParameteri = GLContext.getFunctionAddress("glTexParameteri")) != 0L ? 1 : 0) & ((this.glTexParameterfv = GLContext.getFunctionAddress("glTexParameterfv")) != 0L ? 1 : 0) & ((this.glTexParameteriv = GLContext.getFunctionAddress("glTexParameteriv")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glTexGenf = GLContext.getFunctionAddress("glTexGenf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexGend = GLContext.getFunctionAddress("glTexGend")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexGenfv = GLContext.getFunctionAddress("glTexGenfv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexGendv = GLContext.getFunctionAddress("glTexGendv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexGeni = GLContext.getFunctionAddress("glTexGeni")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexGeniv = GLContext.getFunctionAddress("glTexGeniv")) != 0L) ? 1 : 0) & ((this.glTexEnvf = GLContext.getFunctionAddress("glTexEnvf")) != 0L ? 1 : 0) & ((this.glTexEnvi = GLContext.getFunctionAddress("glTexEnvi")) != 0L ? 1 : 0) & ((this.glTexEnvfv = GLContext.getFunctionAddress("glTexEnvfv")) != 0L ? 1 : 0) & ((this.glTexEnviv = GLContext.getFunctionAddress("glTexEnviv")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordPointer = GLContext.getFunctionAddress("glTexCoordPointer")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord1f = GLContext.getFunctionAddress("glTexCoord1f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord1d = GLContext.getFunctionAddress("glTexCoord1d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord2f = GLContext.getFunctionAddress("glTexCoord2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord2d = GLContext.getFunctionAddress("glTexCoord2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord3f = GLContext.getFunctionAddress("glTexCoord3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord3d = GLContext.getFunctionAddress("glTexCoord3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord4f = GLContext.getFunctionAddress("glTexCoord4f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoord4d = GLContext.getFunctionAddress("glTexCoord4d")) != 0L) ? 1 : 0) & ((this.glStencilOp = GLContext.getFunctionAddress("glStencilOp")) != 0L ? 1 : 0) & ((this.glStencilMask = GLContext.getFunctionAddress("glStencilMask")) != 0L ? 1 : 0) & ((this.glViewport = GLContext.getFunctionAddress("glViewport")) != 0L ? 1 : 0);
/* 2869:     */   }
/* 2870:     */   
/* 2871:     */   private boolean GL12_initNativeFunctionAddresses()
/* 2872:     */   {
/* 2873:4202 */     return ((this.glDrawRangeElements = GLContext.getFunctionAddress("glDrawRangeElements")) != 0L ? 1 : 0) & ((this.glTexImage3D = GLContext.getFunctionAddress("glTexImage3D")) != 0L ? 1 : 0) & ((this.glTexSubImage3D = GLContext.getFunctionAddress("glTexSubImage3D")) != 0L ? 1 : 0) & ((this.glCopyTexSubImage3D = GLContext.getFunctionAddress("glCopyTexSubImage3D")) != 0L ? 1 : 0);
/* 2874:     */   }
/* 2875:     */   
/* 2876:     */   private boolean GL13_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2877:     */   {
/* 2878:4210 */     return ((this.glActiveTexture = GLContext.getFunctionAddress("glActiveTexture")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glClientActiveTexture = GLContext.getFunctionAddress("glClientActiveTexture")) != 0L) ? 1 : 0) & ((this.glCompressedTexImage1D = GLContext.getFunctionAddress("glCompressedTexImage1D")) != 0L ? 1 : 0) & ((this.glCompressedTexImage2D = GLContext.getFunctionAddress("glCompressedTexImage2D")) != 0L ? 1 : 0) & ((this.glCompressedTexImage3D = GLContext.getFunctionAddress("glCompressedTexImage3D")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage1D = GLContext.getFunctionAddress("glCompressedTexSubImage1D")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage2D = GLContext.getFunctionAddress("glCompressedTexSubImage2D")) != 0L ? 1 : 0) & ((this.glCompressedTexSubImage3D = GLContext.getFunctionAddress("glCompressedTexSubImage3D")) != 0L ? 1 : 0) & ((this.glGetCompressedTexImage = GLContext.getFunctionAddress("glGetCompressedTexImage")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord1f = GLContext.getFunctionAddress("glMultiTexCoord1f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord1d = GLContext.getFunctionAddress("glMultiTexCoord1d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord2f = GLContext.getFunctionAddress("glMultiTexCoord2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord2d = GLContext.getFunctionAddress("glMultiTexCoord2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord3f = GLContext.getFunctionAddress("glMultiTexCoord3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord3d = GLContext.getFunctionAddress("glMultiTexCoord3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord4f = GLContext.getFunctionAddress("glMultiTexCoord4f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoord4d = GLContext.getFunctionAddress("glMultiTexCoord4d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLoadTransposeMatrixf = GLContext.getFunctionAddress("glLoadTransposeMatrixf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glLoadTransposeMatrixd = GLContext.getFunctionAddress("glLoadTransposeMatrixd")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultTransposeMatrixf = GLContext.getFunctionAddress("glMultTransposeMatrixf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultTransposeMatrixd = GLContext.getFunctionAddress("glMultTransposeMatrixd")) != 0L) ? 1 : 0) & ((this.glSampleCoverage = GLContext.getFunctionAddress("glSampleCoverage")) != 0L ? 1 : 0);
/* 2879:     */   }
/* 2880:     */   
/* 2881:     */   private boolean GL14_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2882:     */   {
/* 2883:4236 */     return ((this.glBlendEquation = GLContext.getFunctionAddress("glBlendEquation")) != 0L ? 1 : 0) & ((this.glBlendColor = GLContext.getFunctionAddress("glBlendColor")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glFogCoordf = GLContext.getFunctionAddress("glFogCoordf")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFogCoordd = GLContext.getFunctionAddress("glFogCoordd")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glFogCoordPointer = GLContext.getFunctionAddress("glFogCoordPointer")) != 0L) ? 1 : 0) & ((this.glMultiDrawArrays = GLContext.getFunctionAddress("glMultiDrawArrays")) != 0L ? 1 : 0) & ((this.glPointParameteri = GLContext.getFunctionAddress("glPointParameteri")) != 0L ? 1 : 0) & ((this.glPointParameterf = GLContext.getFunctionAddress("glPointParameterf")) != 0L ? 1 : 0) & ((this.glPointParameteriv = GLContext.getFunctionAddress("glPointParameteriv")) != 0L ? 1 : 0) & ((this.glPointParameterfv = GLContext.getFunctionAddress("glPointParameterfv")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColor3b = GLContext.getFunctionAddress("glSecondaryColor3b")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColor3f = GLContext.getFunctionAddress("glSecondaryColor3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColor3d = GLContext.getFunctionAddress("glSecondaryColor3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColor3ub = GLContext.getFunctionAddress("glSecondaryColor3ub")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColorPointer = GLContext.getFunctionAddress("glSecondaryColorPointer")) != 0L) ? 1 : 0) & ((this.glBlendFuncSeparate = GLContext.getFunctionAddress("glBlendFuncSeparate")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2f = GLContext.getFunctionAddress("glWindowPos2f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2d = GLContext.getFunctionAddress("glWindowPos2d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos2i = GLContext.getFunctionAddress("glWindowPos2i")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3f = GLContext.getFunctionAddress("glWindowPos3f")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3d = GLContext.getFunctionAddress("glWindowPos3d")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glWindowPos3i = GLContext.getFunctionAddress("glWindowPos3i")) != 0L) ? 1 : 0);
/* 2884:     */   }
/* 2885:     */   
/* 2886:     */   private boolean GL15_initNativeFunctionAddresses()
/* 2887:     */   {
/* 2888:4262 */     return ((this.glBindBuffer = GLContext.getFunctionAddress("glBindBuffer")) != 0L ? 1 : 0) & ((this.glDeleteBuffers = GLContext.getFunctionAddress("glDeleteBuffers")) != 0L ? 1 : 0) & ((this.glGenBuffers = GLContext.getFunctionAddress("glGenBuffers")) != 0L ? 1 : 0) & ((this.glIsBuffer = GLContext.getFunctionAddress("glIsBuffer")) != 0L ? 1 : 0) & ((this.glBufferData = GLContext.getFunctionAddress("glBufferData")) != 0L ? 1 : 0) & ((this.glBufferSubData = GLContext.getFunctionAddress("glBufferSubData")) != 0L ? 1 : 0) & ((this.glGetBufferSubData = GLContext.getFunctionAddress("glGetBufferSubData")) != 0L ? 1 : 0) & ((this.glMapBuffer = GLContext.getFunctionAddress("glMapBuffer")) != 0L ? 1 : 0) & ((this.glUnmapBuffer = GLContext.getFunctionAddress("glUnmapBuffer")) != 0L ? 1 : 0) & ((this.glGetBufferParameteriv = GLContext.getFunctionAddress("glGetBufferParameteriv")) != 0L ? 1 : 0) & ((this.glGetBufferPointerv = GLContext.getFunctionAddress("glGetBufferPointerv")) != 0L ? 1 : 0) & ((this.glGenQueries = GLContext.getFunctionAddress("glGenQueries")) != 0L ? 1 : 0) & ((this.glDeleteQueries = GLContext.getFunctionAddress("glDeleteQueries")) != 0L ? 1 : 0) & ((this.glIsQuery = GLContext.getFunctionAddress("glIsQuery")) != 0L ? 1 : 0) & ((this.glBeginQuery = GLContext.getFunctionAddress("glBeginQuery")) != 0L ? 1 : 0) & ((this.glEndQuery = GLContext.getFunctionAddress("glEndQuery")) != 0L ? 1 : 0) & ((this.glGetQueryiv = GLContext.getFunctionAddress("glGetQueryiv")) != 0L ? 1 : 0) & ((this.glGetQueryObjectiv = GLContext.getFunctionAddress("glGetQueryObjectiv")) != 0L ? 1 : 0) & ((this.glGetQueryObjectuiv = GLContext.getFunctionAddress("glGetQueryObjectuiv")) != 0L ? 1 : 0);
/* 2889:     */   }
/* 2890:     */   
/* 2891:     */   private boolean GL20_initNativeFunctionAddresses()
/* 2892:     */   {
/* 2893:4285 */     return ((this.glShaderSource = GLContext.getFunctionAddress("glShaderSource")) != 0L ? 1 : 0) & ((this.glCreateShader = GLContext.getFunctionAddress("glCreateShader")) != 0L ? 1 : 0) & ((this.glIsShader = GLContext.getFunctionAddress("glIsShader")) != 0L ? 1 : 0) & ((this.glCompileShader = GLContext.getFunctionAddress("glCompileShader")) != 0L ? 1 : 0) & ((this.glDeleteShader = GLContext.getFunctionAddress("glDeleteShader")) != 0L ? 1 : 0) & ((this.glCreateProgram = GLContext.getFunctionAddress("glCreateProgram")) != 0L ? 1 : 0) & ((this.glIsProgram = GLContext.getFunctionAddress("glIsProgram")) != 0L ? 1 : 0) & ((this.glAttachShader = GLContext.getFunctionAddress("glAttachShader")) != 0L ? 1 : 0) & ((this.glDetachShader = GLContext.getFunctionAddress("glDetachShader")) != 0L ? 1 : 0) & ((this.glLinkProgram = GLContext.getFunctionAddress("glLinkProgram")) != 0L ? 1 : 0) & ((this.glUseProgram = GLContext.getFunctionAddress("glUseProgram")) != 0L ? 1 : 0) & ((this.glValidateProgram = GLContext.getFunctionAddress("glValidateProgram")) != 0L ? 1 : 0) & ((this.glDeleteProgram = GLContext.getFunctionAddress("glDeleteProgram")) != 0L ? 1 : 0) & ((this.glUniform1f = GLContext.getFunctionAddress("glUniform1f")) != 0L ? 1 : 0) & ((this.glUniform2f = GLContext.getFunctionAddress("glUniform2f")) != 0L ? 1 : 0) & ((this.glUniform3f = GLContext.getFunctionAddress("glUniform3f")) != 0L ? 1 : 0) & ((this.glUniform4f = GLContext.getFunctionAddress("glUniform4f")) != 0L ? 1 : 0) & ((this.glUniform1i = GLContext.getFunctionAddress("glUniform1i")) != 0L ? 1 : 0) & ((this.glUniform2i = GLContext.getFunctionAddress("glUniform2i")) != 0L ? 1 : 0) & ((this.glUniform3i = GLContext.getFunctionAddress("glUniform3i")) != 0L ? 1 : 0) & ((this.glUniform4i = GLContext.getFunctionAddress("glUniform4i")) != 0L ? 1 : 0) & ((this.glUniform1fv = GLContext.getFunctionAddress("glUniform1fv")) != 0L ? 1 : 0) & ((this.glUniform2fv = GLContext.getFunctionAddress("glUniform2fv")) != 0L ? 1 : 0) & ((this.glUniform3fv = GLContext.getFunctionAddress("glUniform3fv")) != 0L ? 1 : 0) & ((this.glUniform4fv = GLContext.getFunctionAddress("glUniform4fv")) != 0L ? 1 : 0) & ((this.glUniform1iv = GLContext.getFunctionAddress("glUniform1iv")) != 0L ? 1 : 0) & ((this.glUniform2iv = GLContext.getFunctionAddress("glUniform2iv")) != 0L ? 1 : 0) & ((this.glUniform3iv = GLContext.getFunctionAddress("glUniform3iv")) != 0L ? 1 : 0) & ((this.glUniform4iv = GLContext.getFunctionAddress("glUniform4iv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2fv = GLContext.getFunctionAddress("glUniformMatrix2fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3fv = GLContext.getFunctionAddress("glUniformMatrix3fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4fv = GLContext.getFunctionAddress("glUniformMatrix4fv")) != 0L ? 1 : 0) & ((this.glGetShaderiv = GLContext.getFunctionAddress("glGetShaderiv")) != 0L ? 1 : 0) & ((this.glGetProgramiv = GLContext.getFunctionAddress("glGetProgramiv")) != 0L ? 1 : 0) & ((this.glGetShaderInfoLog = GLContext.getFunctionAddress("glGetShaderInfoLog")) != 0L ? 1 : 0) & ((this.glGetProgramInfoLog = GLContext.getFunctionAddress("glGetProgramInfoLog")) != 0L ? 1 : 0) & ((this.glGetAttachedShaders = GLContext.getFunctionAddress("glGetAttachedShaders")) != 0L ? 1 : 0) & ((this.glGetUniformLocation = GLContext.getFunctionAddress("glGetUniformLocation")) != 0L ? 1 : 0) & ((this.glGetActiveUniform = GLContext.getFunctionAddress("glGetActiveUniform")) != 0L ? 1 : 0) & ((this.glGetUniformfv = GLContext.getFunctionAddress("glGetUniformfv")) != 0L ? 1 : 0) & ((this.glGetUniformiv = GLContext.getFunctionAddress("glGetUniformiv")) != 0L ? 1 : 0) & ((this.glGetShaderSource = GLContext.getFunctionAddress("glGetShaderSource")) != 0L ? 1 : 0) & ((this.glVertexAttrib1s = GLContext.getFunctionAddress("glVertexAttrib1s")) != 0L ? 1 : 0) & ((this.glVertexAttrib1f = GLContext.getFunctionAddress("glVertexAttrib1f")) != 0L ? 1 : 0) & ((this.glVertexAttrib1d = GLContext.getFunctionAddress("glVertexAttrib1d")) != 0L ? 1 : 0) & ((this.glVertexAttrib2s = GLContext.getFunctionAddress("glVertexAttrib2s")) != 0L ? 1 : 0) & ((this.glVertexAttrib2f = GLContext.getFunctionAddress("glVertexAttrib2f")) != 0L ? 1 : 0) & ((this.glVertexAttrib2d = GLContext.getFunctionAddress("glVertexAttrib2d")) != 0L ? 1 : 0) & ((this.glVertexAttrib3s = GLContext.getFunctionAddress("glVertexAttrib3s")) != 0L ? 1 : 0) & ((this.glVertexAttrib3f = GLContext.getFunctionAddress("glVertexAttrib3f")) != 0L ? 1 : 0) & ((this.glVertexAttrib3d = GLContext.getFunctionAddress("glVertexAttrib3d")) != 0L ? 1 : 0) & ((this.glVertexAttrib4s = GLContext.getFunctionAddress("glVertexAttrib4s")) != 0L ? 1 : 0) & ((this.glVertexAttrib4f = GLContext.getFunctionAddress("glVertexAttrib4f")) != 0L ? 1 : 0) & ((this.glVertexAttrib4d = GLContext.getFunctionAddress("glVertexAttrib4d")) != 0L ? 1 : 0) & ((this.glVertexAttrib4Nub = GLContext.getFunctionAddress("glVertexAttrib4Nub")) != 0L ? 1 : 0) & ((this.glVertexAttribPointer = GLContext.getFunctionAddress("glVertexAttribPointer")) != 0L ? 1 : 0) & ((this.glEnableVertexAttribArray = GLContext.getFunctionAddress("glEnableVertexAttribArray")) != 0L ? 1 : 0) & ((this.glDisableVertexAttribArray = GLContext.getFunctionAddress("glDisableVertexAttribArray")) != 0L ? 1 : 0) & ((this.glGetVertexAttribfv = GLContext.getFunctionAddress("glGetVertexAttribfv")) != 0L ? 1 : 0) & ((this.glGetVertexAttribdv = GLContext.getFunctionAddress("glGetVertexAttribdv")) != 0L ? 1 : 0) & ((this.glGetVertexAttribiv = GLContext.getFunctionAddress("glGetVertexAttribiv")) != 0L ? 1 : 0) & ((this.glGetVertexAttribPointerv = GLContext.getFunctionAddress("glGetVertexAttribPointerv")) != 0L ? 1 : 0) & ((this.glBindAttribLocation = GLContext.getFunctionAddress("glBindAttribLocation")) != 0L ? 1 : 0) & ((this.glGetActiveAttrib = GLContext.getFunctionAddress("glGetActiveAttrib")) != 0L ? 1 : 0) & ((this.glGetAttribLocation = GLContext.getFunctionAddress("glGetAttribLocation")) != 0L ? 1 : 0) & ((this.glDrawBuffers = GLContext.getFunctionAddress("glDrawBuffers")) != 0L ? 1 : 0) & ((this.glStencilOpSeparate = GLContext.getFunctionAddress("glStencilOpSeparate")) != 0L ? 1 : 0) & ((this.glStencilFuncSeparate = GLContext.getFunctionAddress("glStencilFuncSeparate")) != 0L ? 1 : 0) & ((this.glStencilMaskSeparate = GLContext.getFunctionAddress("glStencilMaskSeparate")) != 0L ? 1 : 0) & ((this.glBlendEquationSeparate = GLContext.getFunctionAddress("glBlendEquationSeparate")) != 0L ? 1 : 0);
/* 2894:     */   }
/* 2895:     */   
/* 2896:     */   private boolean GL21_initNativeFunctionAddresses()
/* 2897:     */   {
/* 2898:4359 */     return ((this.glUniformMatrix2x3fv = GLContext.getFunctionAddress("glUniformMatrix2x3fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x2fv = GLContext.getFunctionAddress("glUniformMatrix3x2fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2x4fv = GLContext.getFunctionAddress("glUniformMatrix2x4fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x2fv = GLContext.getFunctionAddress("glUniformMatrix4x2fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x4fv = GLContext.getFunctionAddress("glUniformMatrix3x4fv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x3fv = GLContext.getFunctionAddress("glUniformMatrix4x3fv")) != 0L ? 1 : 0);
/* 2899:     */   }
/* 2900:     */   
/* 2901:     */   private boolean GL30_initNativeFunctionAddresses()
/* 2902:     */   {
/* 2903:4369 */     return ((this.glGetStringi = GLContext.getFunctionAddress("glGetStringi")) != 0L ? 1 : 0) & ((this.glClearBufferfv = GLContext.getFunctionAddress("glClearBufferfv")) != 0L ? 1 : 0) & ((this.glClearBufferiv = GLContext.getFunctionAddress("glClearBufferiv")) != 0L ? 1 : 0) & ((this.glClearBufferuiv = GLContext.getFunctionAddress("glClearBufferuiv")) != 0L ? 1 : 0) & ((this.glClearBufferfi = GLContext.getFunctionAddress("glClearBufferfi")) != 0L ? 1 : 0) & ((this.glVertexAttribI1i = GLContext.getFunctionAddress("glVertexAttribI1i")) != 0L ? 1 : 0) & ((this.glVertexAttribI2i = GLContext.getFunctionAddress("glVertexAttribI2i")) != 0L ? 1 : 0) & ((this.glVertexAttribI3i = GLContext.getFunctionAddress("glVertexAttribI3i")) != 0L ? 1 : 0) & ((this.glVertexAttribI4i = GLContext.getFunctionAddress("glVertexAttribI4i")) != 0L ? 1 : 0) & ((this.glVertexAttribI1ui = GLContext.getFunctionAddress("glVertexAttribI1ui")) != 0L ? 1 : 0) & ((this.glVertexAttribI2ui = GLContext.getFunctionAddress("glVertexAttribI2ui")) != 0L ? 1 : 0) & ((this.glVertexAttribI3ui = GLContext.getFunctionAddress("glVertexAttribI3ui")) != 0L ? 1 : 0) & ((this.glVertexAttribI4ui = GLContext.getFunctionAddress("glVertexAttribI4ui")) != 0L ? 1 : 0) & ((this.glVertexAttribI1iv = GLContext.getFunctionAddress("glVertexAttribI1iv")) != 0L ? 1 : 0) & ((this.glVertexAttribI2iv = GLContext.getFunctionAddress("glVertexAttribI2iv")) != 0L ? 1 : 0) & ((this.glVertexAttribI3iv = GLContext.getFunctionAddress("glVertexAttribI3iv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4iv = GLContext.getFunctionAddress("glVertexAttribI4iv")) != 0L ? 1 : 0) & ((this.glVertexAttribI1uiv = GLContext.getFunctionAddress("glVertexAttribI1uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribI2uiv = GLContext.getFunctionAddress("glVertexAttribI2uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribI3uiv = GLContext.getFunctionAddress("glVertexAttribI3uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4uiv = GLContext.getFunctionAddress("glVertexAttribI4uiv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4bv = GLContext.getFunctionAddress("glVertexAttribI4bv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4sv = GLContext.getFunctionAddress("glVertexAttribI4sv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4ubv = GLContext.getFunctionAddress("glVertexAttribI4ubv")) != 0L ? 1 : 0) & ((this.glVertexAttribI4usv = GLContext.getFunctionAddress("glVertexAttribI4usv")) != 0L ? 1 : 0) & ((this.glVertexAttribIPointer = GLContext.getFunctionAddress("glVertexAttribIPointer")) != 0L ? 1 : 0) & ((this.glGetVertexAttribIiv = GLContext.getFunctionAddress("glGetVertexAttribIiv")) != 0L ? 1 : 0) & ((this.glGetVertexAttribIuiv = GLContext.getFunctionAddress("glGetVertexAttribIuiv")) != 0L ? 1 : 0) & ((this.glUniform1ui = GLContext.getFunctionAddress("glUniform1ui")) != 0L ? 1 : 0) & ((this.glUniform2ui = GLContext.getFunctionAddress("glUniform2ui")) != 0L ? 1 : 0) & ((this.glUniform3ui = GLContext.getFunctionAddress("glUniform3ui")) != 0L ? 1 : 0) & ((this.glUniform4ui = GLContext.getFunctionAddress("glUniform4ui")) != 0L ? 1 : 0) & ((this.glUniform1uiv = GLContext.getFunctionAddress("glUniform1uiv")) != 0L ? 1 : 0) & ((this.glUniform2uiv = GLContext.getFunctionAddress("glUniform2uiv")) != 0L ? 1 : 0) & ((this.glUniform3uiv = GLContext.getFunctionAddress("glUniform3uiv")) != 0L ? 1 : 0) & ((this.glUniform4uiv = GLContext.getFunctionAddress("glUniform4uiv")) != 0L ? 1 : 0) & ((this.glGetUniformuiv = GLContext.getFunctionAddress("glGetUniformuiv")) != 0L ? 1 : 0) & ((this.glBindFragDataLocation = GLContext.getFunctionAddress("glBindFragDataLocation")) != 0L ? 1 : 0) & ((this.glGetFragDataLocation = GLContext.getFunctionAddress("glGetFragDataLocation")) != 0L ? 1 : 0) & ((this.glBeginConditionalRender = GLContext.getFunctionAddress("glBeginConditionalRender")) != 0L ? 1 : 0) & ((this.glEndConditionalRender = GLContext.getFunctionAddress("glEndConditionalRender")) != 0L ? 1 : 0) & ((this.glMapBufferRange = GLContext.getFunctionAddress("glMapBufferRange")) != 0L ? 1 : 0) & ((this.glFlushMappedBufferRange = GLContext.getFunctionAddress("glFlushMappedBufferRange")) != 0L ? 1 : 0) & ((this.glClampColor = GLContext.getFunctionAddress("glClampColor")) != 0L ? 1 : 0) & ((this.glIsRenderbuffer = GLContext.getFunctionAddress("glIsRenderbuffer")) != 0L ? 1 : 0) & ((this.glBindRenderbuffer = GLContext.getFunctionAddress("glBindRenderbuffer")) != 0L ? 1 : 0) & ((this.glDeleteRenderbuffers = GLContext.getFunctionAddress("glDeleteRenderbuffers")) != 0L ? 1 : 0) & ((this.glGenRenderbuffers = GLContext.getFunctionAddress("glGenRenderbuffers")) != 0L ? 1 : 0) & ((this.glRenderbufferStorage = GLContext.getFunctionAddress("glRenderbufferStorage")) != 0L ? 1 : 0) & ((this.glGetRenderbufferParameteriv = GLContext.getFunctionAddress("glGetRenderbufferParameteriv")) != 0L ? 1 : 0) & ((this.glIsFramebuffer = GLContext.getFunctionAddress("glIsFramebuffer")) != 0L ? 1 : 0) & ((this.glBindFramebuffer = GLContext.getFunctionAddress("glBindFramebuffer")) != 0L ? 1 : 0) & ((this.glDeleteFramebuffers = GLContext.getFunctionAddress("glDeleteFramebuffers")) != 0L ? 1 : 0) & ((this.glGenFramebuffers = GLContext.getFunctionAddress("glGenFramebuffers")) != 0L ? 1 : 0) & ((this.glCheckFramebufferStatus = GLContext.getFunctionAddress("glCheckFramebufferStatus")) != 0L ? 1 : 0) & ((this.glFramebufferTexture1D = GLContext.getFunctionAddress("glFramebufferTexture1D")) != 0L ? 1 : 0) & ((this.glFramebufferTexture2D = GLContext.getFunctionAddress("glFramebufferTexture2D")) != 0L ? 1 : 0) & ((this.glFramebufferTexture3D = GLContext.getFunctionAddress("glFramebufferTexture3D")) != 0L ? 1 : 0) & ((this.glFramebufferRenderbuffer = GLContext.getFunctionAddress("glFramebufferRenderbuffer")) != 0L ? 1 : 0) & ((this.glGetFramebufferAttachmentParameteriv = GLContext.getFunctionAddress("glGetFramebufferAttachmentParameteriv")) != 0L ? 1 : 0) & ((this.glGenerateMipmap = GLContext.getFunctionAddress("glGenerateMipmap")) != 0L ? 1 : 0) & ((this.glRenderbufferStorageMultisample = GLContext.getFunctionAddress("glRenderbufferStorageMultisample")) != 0L ? 1 : 0) & ((this.glBlitFramebuffer = GLContext.getFunctionAddress("glBlitFramebuffer")) != 0L ? 1 : 0) & ((this.glTexParameterIiv = GLContext.getFunctionAddress("glTexParameterIiv")) != 0L ? 1 : 0) & ((this.glTexParameterIuiv = GLContext.getFunctionAddress("glTexParameterIuiv")) != 0L ? 1 : 0) & ((this.glGetTexParameterIiv = GLContext.getFunctionAddress("glGetTexParameterIiv")) != 0L ? 1 : 0) & ((this.glGetTexParameterIuiv = GLContext.getFunctionAddress("glGetTexParameterIuiv")) != 0L ? 1 : 0) & ((this.glFramebufferTextureLayer = GLContext.getFunctionAddress("glFramebufferTextureLayer")) != 0L ? 1 : 0) & ((this.glColorMaski = GLContext.getFunctionAddress("glColorMaski")) != 0L ? 1 : 0) & ((this.glGetBooleani_v = GLContext.getFunctionAddress("glGetBooleani_v")) != 0L ? 1 : 0) & ((this.glGetIntegeri_v = GLContext.getFunctionAddress("glGetIntegeri_v")) != 0L ? 1 : 0) & ((this.glEnablei = GLContext.getFunctionAddress("glEnablei")) != 0L ? 1 : 0) & ((this.glDisablei = GLContext.getFunctionAddress("glDisablei")) != 0L ? 1 : 0) & ((this.glIsEnabledi = GLContext.getFunctionAddress("glIsEnabledi")) != 0L ? 1 : 0) & ((this.glBindBufferRange = GLContext.getFunctionAddress("glBindBufferRange")) != 0L ? 1 : 0) & ((this.glBindBufferBase = GLContext.getFunctionAddress("glBindBufferBase")) != 0L ? 1 : 0) & ((this.glBeginTransformFeedback = GLContext.getFunctionAddress("glBeginTransformFeedback")) != 0L ? 1 : 0) & ((this.glEndTransformFeedback = GLContext.getFunctionAddress("glEndTransformFeedback")) != 0L ? 1 : 0) & ((this.glTransformFeedbackVaryings = GLContext.getFunctionAddress("glTransformFeedbackVaryings")) != 0L ? 1 : 0) & ((this.glGetTransformFeedbackVarying = GLContext.getFunctionAddress("glGetTransformFeedbackVarying")) != 0L ? 1 : 0) & ((this.glBindVertexArray = GLContext.getFunctionAddress("glBindVertexArray")) != 0L ? 1 : 0) & ((this.glDeleteVertexArrays = GLContext.getFunctionAddress("glDeleteVertexArrays")) != 0L ? 1 : 0) & ((this.glGenVertexArrays = GLContext.getFunctionAddress("glGenVertexArrays")) != 0L ? 1 : 0) & ((this.glIsVertexArray = GLContext.getFunctionAddress("glIsVertexArray")) != 0L ? 1 : 0);
/* 2904:     */   }
/* 2905:     */   
/* 2906:     */   private boolean GL31_initNativeFunctionAddresses()
/* 2907:     */   {
/* 2908:4457 */     return ((this.glDrawArraysInstanced = GLContext.getFunctionAddress("glDrawArraysInstanced")) != 0L ? 1 : 0) & ((this.glDrawElementsInstanced = GLContext.getFunctionAddress("glDrawElementsInstanced")) != 0L ? 1 : 0) & ((this.glCopyBufferSubData = GLContext.getFunctionAddress("glCopyBufferSubData")) != 0L ? 1 : 0) & ((this.glPrimitiveRestartIndex = GLContext.getFunctionAddress("glPrimitiveRestartIndex")) != 0L ? 1 : 0) & ((this.glTexBuffer = GLContext.getFunctionAddress("glTexBuffer")) != 0L ? 1 : 0) & ((this.glGetUniformIndices = GLContext.getFunctionAddress("glGetUniformIndices")) != 0L ? 1 : 0) & ((this.glGetActiveUniformsiv = GLContext.getFunctionAddress("glGetActiveUniformsiv")) != 0L ? 1 : 0) & ((this.glGetActiveUniformName = GLContext.getFunctionAddress("glGetActiveUniformName")) != 0L ? 1 : 0) & ((this.glGetUniformBlockIndex = GLContext.getFunctionAddress("glGetUniformBlockIndex")) != 0L ? 1 : 0) & ((this.glGetActiveUniformBlockiv = GLContext.getFunctionAddress("glGetActiveUniformBlockiv")) != 0L ? 1 : 0) & ((this.glGetActiveUniformBlockName = GLContext.getFunctionAddress("glGetActiveUniformBlockName")) != 0L ? 1 : 0) & ((this.glUniformBlockBinding = GLContext.getFunctionAddress("glUniformBlockBinding")) != 0L ? 1 : 0);
/* 2909:     */   }
/* 2910:     */   
/* 2911:     */   private boolean GL32_initNativeFunctionAddresses()
/* 2912:     */   {
/* 2913:4473 */     return ((this.glGetBufferParameteri64v = GLContext.getFunctionAddress("glGetBufferParameteri64v")) != 0L ? 1 : 0) & ((this.glDrawElementsBaseVertex = GLContext.getFunctionAddress("glDrawElementsBaseVertex")) != 0L ? 1 : 0) & ((this.glDrawRangeElementsBaseVertex = GLContext.getFunctionAddress("glDrawRangeElementsBaseVertex")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseVertex = GLContext.getFunctionAddress("glDrawElementsInstancedBaseVertex")) != 0L ? 1 : 0) & ((this.glProvokingVertex = GLContext.getFunctionAddress("glProvokingVertex")) != 0L ? 1 : 0) & ((this.glTexImage2DMultisample = GLContext.getFunctionAddress("glTexImage2DMultisample")) != 0L ? 1 : 0) & ((this.glTexImage3DMultisample = GLContext.getFunctionAddress("glTexImage3DMultisample")) != 0L ? 1 : 0) & ((this.glGetMultisamplefv = GLContext.getFunctionAddress("glGetMultisamplefv")) != 0L ? 1 : 0) & ((this.glSampleMaski = GLContext.getFunctionAddress("glSampleMaski")) != 0L ? 1 : 0) & ((this.glFramebufferTexture = GLContext.getFunctionAddress("glFramebufferTexture")) != 0L ? 1 : 0) & ((this.glFenceSync = GLContext.getFunctionAddress("glFenceSync")) != 0L ? 1 : 0) & ((this.glIsSync = GLContext.getFunctionAddress("glIsSync")) != 0L ? 1 : 0) & ((this.glDeleteSync = GLContext.getFunctionAddress("glDeleteSync")) != 0L ? 1 : 0) & ((this.glClientWaitSync = GLContext.getFunctionAddress("glClientWaitSync")) != 0L ? 1 : 0) & ((this.glWaitSync = GLContext.getFunctionAddress("glWaitSync")) != 0L ? 1 : 0) & ((this.glGetInteger64v = GLContext.getFunctionAddress("glGetInteger64v")) != 0L ? 1 : 0) & 0x1 & (((this.glGetInteger64i_v = GLContext.getFunctionAddress("glGetInteger64i_v")) != 0L) || ((this.glGetSynciv = GLContext.getFunctionAddress("glGetSynciv")) != 0L) ? 1 : 0);
/* 2914:     */   }
/* 2915:     */   
/* 2916:     */   private boolean GL33_initNativeFunctionAddresses(boolean forwardCompatible)
/* 2917:     */   {
/* 2918:4495 */     return ((this.glBindFragDataLocationIndexed = GLContext.getFunctionAddress("glBindFragDataLocationIndexed")) != 0L ? 1 : 0) & ((this.glGetFragDataIndex = GLContext.getFunctionAddress("glGetFragDataIndex")) != 0L ? 1 : 0) & ((this.glGenSamplers = GLContext.getFunctionAddress("glGenSamplers")) != 0L ? 1 : 0) & ((this.glDeleteSamplers = GLContext.getFunctionAddress("glDeleteSamplers")) != 0L ? 1 : 0) & ((this.glIsSampler = GLContext.getFunctionAddress("glIsSampler")) != 0L ? 1 : 0) & ((this.glBindSampler = GLContext.getFunctionAddress("glBindSampler")) != 0L ? 1 : 0) & ((this.glSamplerParameteri = GLContext.getFunctionAddress("glSamplerParameteri")) != 0L ? 1 : 0) & ((this.glSamplerParameterf = GLContext.getFunctionAddress("glSamplerParameterf")) != 0L ? 1 : 0) & ((this.glSamplerParameteriv = GLContext.getFunctionAddress("glSamplerParameteriv")) != 0L ? 1 : 0) & ((this.glSamplerParameterfv = GLContext.getFunctionAddress("glSamplerParameterfv")) != 0L ? 1 : 0) & ((this.glSamplerParameterIiv = GLContext.getFunctionAddress("glSamplerParameterIiv")) != 0L ? 1 : 0) & ((this.glSamplerParameterIuiv = GLContext.getFunctionAddress("glSamplerParameterIuiv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameteriv = GLContext.getFunctionAddress("glGetSamplerParameteriv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterfv = GLContext.getFunctionAddress("glGetSamplerParameterfv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterIiv = GLContext.getFunctionAddress("glGetSamplerParameterIiv")) != 0L ? 1 : 0) & ((this.glGetSamplerParameterIuiv = GLContext.getFunctionAddress("glGetSamplerParameterIuiv")) != 0L ? 1 : 0) & ((this.glQueryCounter = GLContext.getFunctionAddress("glQueryCounter")) != 0L ? 1 : 0) & ((this.glGetQueryObjecti64v = GLContext.getFunctionAddress("glGetQueryObjecti64v")) != 0L ? 1 : 0) & ((this.glGetQueryObjectui64v = GLContext.getFunctionAddress("glGetQueryObjectui64v")) != 0L ? 1 : 0) & ((this.glVertexAttribDivisor = GLContext.getFunctionAddress("glVertexAttribDivisor")) != 0L ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP2ui = GLContext.getFunctionAddress("glVertexP2ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP3ui = GLContext.getFunctionAddress("glVertexP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP4ui = GLContext.getFunctionAddress("glVertexP4ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP2uiv = GLContext.getFunctionAddress("glVertexP2uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP3uiv = GLContext.getFunctionAddress("glVertexP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexP4uiv = GLContext.getFunctionAddress("glVertexP4uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP1ui = GLContext.getFunctionAddress("glTexCoordP1ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP2ui = GLContext.getFunctionAddress("glTexCoordP2ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP3ui = GLContext.getFunctionAddress("glTexCoordP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP4ui = GLContext.getFunctionAddress("glTexCoordP4ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP1uiv = GLContext.getFunctionAddress("glTexCoordP1uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP2uiv = GLContext.getFunctionAddress("glTexCoordP2uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP3uiv = GLContext.getFunctionAddress("glTexCoordP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glTexCoordP4uiv = GLContext.getFunctionAddress("glTexCoordP4uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP1ui = GLContext.getFunctionAddress("glMultiTexCoordP1ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP2ui = GLContext.getFunctionAddress("glMultiTexCoordP2ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP3ui = GLContext.getFunctionAddress("glMultiTexCoordP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP4ui = GLContext.getFunctionAddress("glMultiTexCoordP4ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP1uiv = GLContext.getFunctionAddress("glMultiTexCoordP1uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP2uiv = GLContext.getFunctionAddress("glMultiTexCoordP2uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP3uiv = GLContext.getFunctionAddress("glMultiTexCoordP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glMultiTexCoordP4uiv = GLContext.getFunctionAddress("glMultiTexCoordP4uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormalP3ui = GLContext.getFunctionAddress("glNormalP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glNormalP3uiv = GLContext.getFunctionAddress("glNormalP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorP3ui = GLContext.getFunctionAddress("glColorP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorP4ui = GLContext.getFunctionAddress("glColorP4ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorP3uiv = GLContext.getFunctionAddress("glColorP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glColorP4uiv = GLContext.getFunctionAddress("glColorP4uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColorP3ui = GLContext.getFunctionAddress("glSecondaryColorP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glSecondaryColorP3uiv = GLContext.getFunctionAddress("glSecondaryColorP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP1ui = GLContext.getFunctionAddress("glVertexAttribP1ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP2ui = GLContext.getFunctionAddress("glVertexAttribP2ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP3ui = GLContext.getFunctionAddress("glVertexAttribP3ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP4ui = GLContext.getFunctionAddress("glVertexAttribP4ui")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP1uiv = GLContext.getFunctionAddress("glVertexAttribP1uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP2uiv = GLContext.getFunctionAddress("glVertexAttribP2uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP3uiv = GLContext.getFunctionAddress("glVertexAttribP3uiv")) != 0L) ? 1 : 0) & ((forwardCompatible) || ((this.glVertexAttribP4uiv = GLContext.getFunctionAddress("glVertexAttribP4uiv")) != 0L) ? 1 : 0);
/* 2919:     */   }
/* 2920:     */   
/* 2921:     */   private boolean GL40_initNativeFunctionAddresses()
/* 2922:     */   {
/* 2923:4557 */     return ((this.glBlendEquationi = GLContext.getFunctionAddress("glBlendEquationi")) != 0L ? 1 : 0) & ((this.glBlendEquationSeparatei = GLContext.getFunctionAddress("glBlendEquationSeparatei")) != 0L ? 1 : 0) & ((this.glBlendFunci = GLContext.getFunctionAddress("glBlendFunci")) != 0L ? 1 : 0) & ((this.glBlendFuncSeparatei = GLContext.getFunctionAddress("glBlendFuncSeparatei")) != 0L ? 1 : 0) & ((this.glDrawArraysIndirect = GLContext.getFunctionAddress("glDrawArraysIndirect")) != 0L ? 1 : 0) & ((this.glDrawElementsIndirect = GLContext.getFunctionAddress("glDrawElementsIndirect")) != 0L ? 1 : 0) & ((this.glUniform1d = GLContext.getFunctionAddress("glUniform1d")) != 0L ? 1 : 0) & ((this.glUniform2d = GLContext.getFunctionAddress("glUniform2d")) != 0L ? 1 : 0) & ((this.glUniform3d = GLContext.getFunctionAddress("glUniform3d")) != 0L ? 1 : 0) & ((this.glUniform4d = GLContext.getFunctionAddress("glUniform4d")) != 0L ? 1 : 0) & ((this.glUniform1dv = GLContext.getFunctionAddress("glUniform1dv")) != 0L ? 1 : 0) & ((this.glUniform2dv = GLContext.getFunctionAddress("glUniform2dv")) != 0L ? 1 : 0) & ((this.glUniform3dv = GLContext.getFunctionAddress("glUniform3dv")) != 0L ? 1 : 0) & ((this.glUniform4dv = GLContext.getFunctionAddress("glUniform4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2dv = GLContext.getFunctionAddress("glUniformMatrix2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3dv = GLContext.getFunctionAddress("glUniformMatrix3dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4dv = GLContext.getFunctionAddress("glUniformMatrix4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2x3dv = GLContext.getFunctionAddress("glUniformMatrix2x3dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix2x4dv = GLContext.getFunctionAddress("glUniformMatrix2x4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x2dv = GLContext.getFunctionAddress("glUniformMatrix3x2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix3x4dv = GLContext.getFunctionAddress("glUniformMatrix3x4dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x2dv = GLContext.getFunctionAddress("glUniformMatrix4x2dv")) != 0L ? 1 : 0) & ((this.glUniformMatrix4x3dv = GLContext.getFunctionAddress("glUniformMatrix4x3dv")) != 0L ? 1 : 0) & ((this.glGetUniformdv = GLContext.getFunctionAddress("glGetUniformdv")) != 0L ? 1 : 0) & ((this.glMinSampleShading = GLContext.getFunctionAddress("glMinSampleShading")) != 0L ? 1 : 0) & ((this.glGetSubroutineUniformLocation = GLContext.getFunctionAddress("glGetSubroutineUniformLocation")) != 0L ? 1 : 0) & ((this.glGetSubroutineIndex = GLContext.getFunctionAddress("glGetSubroutineIndex")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineUniformiv = GLContext.getFunctionAddress("glGetActiveSubroutineUniformiv")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineUniformName = GLContext.getFunctionAddress("glGetActiveSubroutineUniformName")) != 0L ? 1 : 0) & ((this.glGetActiveSubroutineName = GLContext.getFunctionAddress("glGetActiveSubroutineName")) != 0L ? 1 : 0) & ((this.glUniformSubroutinesuiv = GLContext.getFunctionAddress("glUniformSubroutinesuiv")) != 0L ? 1 : 0) & ((this.glGetUniformSubroutineuiv = GLContext.getFunctionAddress("glGetUniformSubroutineuiv")) != 0L ? 1 : 0) & ((this.glGetProgramStageiv = GLContext.getFunctionAddress("glGetProgramStageiv")) != 0L ? 1 : 0) & ((this.glPatchParameteri = GLContext.getFunctionAddress("glPatchParameteri")) != 0L ? 1 : 0) & ((this.glPatchParameterfv = GLContext.getFunctionAddress("glPatchParameterfv")) != 0L ? 1 : 0) & ((this.glBindTransformFeedback = GLContext.getFunctionAddress("glBindTransformFeedback")) != 0L ? 1 : 0) & ((this.glDeleteTransformFeedbacks = GLContext.getFunctionAddress("glDeleteTransformFeedbacks")) != 0L ? 1 : 0) & ((this.glGenTransformFeedbacks = GLContext.getFunctionAddress("glGenTransformFeedbacks")) != 0L ? 1 : 0) & ((this.glIsTransformFeedback = GLContext.getFunctionAddress("glIsTransformFeedback")) != 0L ? 1 : 0) & ((this.glPauseTransformFeedback = GLContext.getFunctionAddress("glPauseTransformFeedback")) != 0L ? 1 : 0) & ((this.glResumeTransformFeedback = GLContext.getFunctionAddress("glResumeTransformFeedback")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedback = GLContext.getFunctionAddress("glDrawTransformFeedback")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedbackStream = GLContext.getFunctionAddress("glDrawTransformFeedbackStream")) != 0L ? 1 : 0) & ((this.glBeginQueryIndexed = GLContext.getFunctionAddress("glBeginQueryIndexed")) != 0L ? 1 : 0) & ((this.glEndQueryIndexed = GLContext.getFunctionAddress("glEndQueryIndexed")) != 0L ? 1 : 0) & ((this.glGetQueryIndexediv = GLContext.getFunctionAddress("glGetQueryIndexediv")) != 0L ? 1 : 0);
/* 2924:     */   }
/* 2925:     */   
/* 2926:     */   private boolean GL41_initNativeFunctionAddresses()
/* 2927:     */   {
/* 2928:4607 */     return ((this.glReleaseShaderCompiler = GLContext.getFunctionAddress("glReleaseShaderCompiler")) != 0L ? 1 : 0) & ((this.glShaderBinary = GLContext.getFunctionAddress("glShaderBinary")) != 0L ? 1 : 0) & ((this.glGetShaderPrecisionFormat = GLContext.getFunctionAddress("glGetShaderPrecisionFormat")) != 0L ? 1 : 0) & ((this.glDepthRangef = GLContext.getFunctionAddress("glDepthRangef")) != 0L ? 1 : 0) & ((this.glClearDepthf = GLContext.getFunctionAddress("glClearDepthf")) != 0L ? 1 : 0) & ((this.glGetProgramBinary = GLContext.getFunctionAddress("glGetProgramBinary")) != 0L ? 1 : 0) & ((this.glProgramBinary = GLContext.getFunctionAddress("glProgramBinary")) != 0L ? 1 : 0) & ((this.glProgramParameteri = GLContext.getFunctionAddress("glProgramParameteri")) != 0L ? 1 : 0) & ((this.glUseProgramStages = GLContext.getFunctionAddress("glUseProgramStages")) != 0L ? 1 : 0) & ((this.glActiveShaderProgram = GLContext.getFunctionAddress("glActiveShaderProgram")) != 0L ? 1 : 0) & ((this.glCreateShaderProgramv = GLContext.getFunctionAddress("glCreateShaderProgramv")) != 0L ? 1 : 0) & ((this.glBindProgramPipeline = GLContext.getFunctionAddress("glBindProgramPipeline")) != 0L ? 1 : 0) & ((this.glDeleteProgramPipelines = GLContext.getFunctionAddress("glDeleteProgramPipelines")) != 0L ? 1 : 0) & ((this.glGenProgramPipelines = GLContext.getFunctionAddress("glGenProgramPipelines")) != 0L ? 1 : 0) & ((this.glIsProgramPipeline = GLContext.getFunctionAddress("glIsProgramPipeline")) != 0L ? 1 : 0) & ((this.glGetProgramPipelineiv = GLContext.getFunctionAddress("glGetProgramPipelineiv")) != 0L ? 1 : 0) & ((this.glProgramUniform1i = GLContext.getFunctionAddress("glProgramUniform1i")) != 0L ? 1 : 0) & ((this.glProgramUniform2i = GLContext.getFunctionAddress("glProgramUniform2i")) != 0L ? 1 : 0) & ((this.glProgramUniform3i = GLContext.getFunctionAddress("glProgramUniform3i")) != 0L ? 1 : 0) & ((this.glProgramUniform4i = GLContext.getFunctionAddress("glProgramUniform4i")) != 0L ? 1 : 0) & ((this.glProgramUniform1f = GLContext.getFunctionAddress("glProgramUniform1f")) != 0L ? 1 : 0) & ((this.glProgramUniform2f = GLContext.getFunctionAddress("glProgramUniform2f")) != 0L ? 1 : 0) & ((this.glProgramUniform3f = GLContext.getFunctionAddress("glProgramUniform3f")) != 0L ? 1 : 0) & ((this.glProgramUniform4f = GLContext.getFunctionAddress("glProgramUniform4f")) != 0L ? 1 : 0) & ((this.glProgramUniform1d = GLContext.getFunctionAddress("glProgramUniform1d")) != 0L ? 1 : 0) & ((this.glProgramUniform2d = GLContext.getFunctionAddress("glProgramUniform2d")) != 0L ? 1 : 0) & ((this.glProgramUniform3d = GLContext.getFunctionAddress("glProgramUniform3d")) != 0L ? 1 : 0) & ((this.glProgramUniform4d = GLContext.getFunctionAddress("glProgramUniform4d")) != 0L ? 1 : 0) & ((this.glProgramUniform1iv = GLContext.getFunctionAddress("glProgramUniform1iv")) != 0L ? 1 : 0) & ((this.glProgramUniform2iv = GLContext.getFunctionAddress("glProgramUniform2iv")) != 0L ? 1 : 0) & ((this.glProgramUniform3iv = GLContext.getFunctionAddress("glProgramUniform3iv")) != 0L ? 1 : 0) & ((this.glProgramUniform4iv = GLContext.getFunctionAddress("glProgramUniform4iv")) != 0L ? 1 : 0) & ((this.glProgramUniform1fv = GLContext.getFunctionAddress("glProgramUniform1fv")) != 0L ? 1 : 0) & ((this.glProgramUniform2fv = GLContext.getFunctionAddress("glProgramUniform2fv")) != 0L ? 1 : 0) & ((this.glProgramUniform3fv = GLContext.getFunctionAddress("glProgramUniform3fv")) != 0L ? 1 : 0) & ((this.glProgramUniform4fv = GLContext.getFunctionAddress("glProgramUniform4fv")) != 0L ? 1 : 0) & ((this.glProgramUniform1dv = GLContext.getFunctionAddress("glProgramUniform1dv")) != 0L ? 1 : 0) & ((this.glProgramUniform2dv = GLContext.getFunctionAddress("glProgramUniform2dv")) != 0L ? 1 : 0) & ((this.glProgramUniform3dv = GLContext.getFunctionAddress("glProgramUniform3dv")) != 0L ? 1 : 0) & ((this.glProgramUniform4dv = GLContext.getFunctionAddress("glProgramUniform4dv")) != 0L ? 1 : 0) & ((this.glProgramUniform1ui = GLContext.getFunctionAddress("glProgramUniform1ui")) != 0L ? 1 : 0) & ((this.glProgramUniform2ui = GLContext.getFunctionAddress("glProgramUniform2ui")) != 0L ? 1 : 0) & ((this.glProgramUniform3ui = GLContext.getFunctionAddress("glProgramUniform3ui")) != 0L ? 1 : 0) & ((this.glProgramUniform4ui = GLContext.getFunctionAddress("glProgramUniform4ui")) != 0L ? 1 : 0) & ((this.glProgramUniform1uiv = GLContext.getFunctionAddress("glProgramUniform1uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform2uiv = GLContext.getFunctionAddress("glProgramUniform2uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform3uiv = GLContext.getFunctionAddress("glProgramUniform3uiv")) != 0L ? 1 : 0) & ((this.glProgramUniform4uiv = GLContext.getFunctionAddress("glProgramUniform4uiv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2fv = GLContext.getFunctionAddress("glProgramUniformMatrix2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3fv = GLContext.getFunctionAddress("glProgramUniformMatrix3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4fv = GLContext.getFunctionAddress("glProgramUniformMatrix4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2dv = GLContext.getFunctionAddress("glProgramUniformMatrix2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3dv = GLContext.getFunctionAddress("glProgramUniformMatrix3dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4dv = GLContext.getFunctionAddress("glProgramUniformMatrix4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x3fv = GLContext.getFunctionAddress("glProgramUniformMatrix2x3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x2fv = GLContext.getFunctionAddress("glProgramUniformMatrix3x2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x4fv = GLContext.getFunctionAddress("glProgramUniformMatrix2x4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x2fv = GLContext.getFunctionAddress("glProgramUniformMatrix4x2fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x4fv = GLContext.getFunctionAddress("glProgramUniformMatrix3x4fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x3fv = GLContext.getFunctionAddress("glProgramUniformMatrix4x3fv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x3dv = GLContext.getFunctionAddress("glProgramUniformMatrix2x3dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x2dv = GLContext.getFunctionAddress("glProgramUniformMatrix3x2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix2x4dv = GLContext.getFunctionAddress("glProgramUniformMatrix2x4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x2dv = GLContext.getFunctionAddress("glProgramUniformMatrix4x2dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix3x4dv = GLContext.getFunctionAddress("glProgramUniformMatrix3x4dv")) != 0L ? 1 : 0) & ((this.glProgramUniformMatrix4x3dv = GLContext.getFunctionAddress("glProgramUniformMatrix4x3dv")) != 0L ? 1 : 0) & ((this.glValidateProgramPipeline = GLContext.getFunctionAddress("glValidateProgramPipeline")) != 0L ? 1 : 0) & ((this.glGetProgramPipelineInfoLog = GLContext.getFunctionAddress("glGetProgramPipelineInfoLog")) != 0L ? 1 : 0) & ((this.glVertexAttribL1d = GLContext.getFunctionAddress("glVertexAttribL1d")) != 0L ? 1 : 0) & ((this.glVertexAttribL2d = GLContext.getFunctionAddress("glVertexAttribL2d")) != 0L ? 1 : 0) & ((this.glVertexAttribL3d = GLContext.getFunctionAddress("glVertexAttribL3d")) != 0L ? 1 : 0) & ((this.glVertexAttribL4d = GLContext.getFunctionAddress("glVertexAttribL4d")) != 0L ? 1 : 0) & ((this.glVertexAttribL1dv = GLContext.getFunctionAddress("glVertexAttribL1dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL2dv = GLContext.getFunctionAddress("glVertexAttribL2dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL3dv = GLContext.getFunctionAddress("glVertexAttribL3dv")) != 0L ? 1 : 0) & ((this.glVertexAttribL4dv = GLContext.getFunctionAddress("glVertexAttribL4dv")) != 0L ? 1 : 0) & ((this.glVertexAttribLPointer = GLContext.getFunctionAddress("glVertexAttribLPointer")) != 0L ? 1 : 0) & ((this.glGetVertexAttribLdv = GLContext.getFunctionAddress("glGetVertexAttribLdv")) != 0L ? 1 : 0) & ((this.glViewportArrayv = GLContext.getFunctionAddress("glViewportArrayv")) != 0L ? 1 : 0) & ((this.glViewportIndexedf = GLContext.getFunctionAddress("glViewportIndexedf")) != 0L ? 1 : 0) & ((this.glViewportIndexedfv = GLContext.getFunctionAddress("glViewportIndexedfv")) != 0L ? 1 : 0) & ((this.glScissorArrayv = GLContext.getFunctionAddress("glScissorArrayv")) != 0L ? 1 : 0) & ((this.glScissorIndexed = GLContext.getFunctionAddress("glScissorIndexed")) != 0L ? 1 : 0) & ((this.glScissorIndexedv = GLContext.getFunctionAddress("glScissorIndexedv")) != 0L ? 1 : 0) & ((this.glDepthRangeArrayv = GLContext.getFunctionAddress("glDepthRangeArrayv")) != 0L ? 1 : 0) & ((this.glDepthRangeIndexed = GLContext.getFunctionAddress("glDepthRangeIndexed")) != 0L ? 1 : 0) & ((this.glGetFloati_v = GLContext.getFunctionAddress("glGetFloati_v")) != 0L ? 1 : 0) & ((this.glGetDoublei_v = GLContext.getFunctionAddress("glGetDoublei_v")) != 0L ? 1 : 0);
/* 2929:     */   }
/* 2930:     */   
/* 2931:     */   private boolean GL42_initNativeFunctionAddresses()
/* 2932:     */   {
/* 2933:4699 */     return 0x1 & (((this.glGetActiveAtomicCounterBufferiv = GLContext.getFunctionAddress("glGetActiveAtomicCounterBufferiv")) != 0L) || ((this.glTexStorage1D = GLContext.getFunctionAddress("glTexStorage1D")) != 0L) ? 1 : 0) & ((this.glTexStorage2D = GLContext.getFunctionAddress("glTexStorage2D")) != 0L ? 1 : 0) & ((this.glTexStorage3D = GLContext.getFunctionAddress("glTexStorage3D")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedbackInstanced = GLContext.getFunctionAddress("glDrawTransformFeedbackInstanced")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedbackStreamInstanced = GLContext.getFunctionAddress("glDrawTransformFeedbackStreamInstanced")) != 0L ? 1 : 0) & ((this.glDrawArraysInstancedBaseInstance = GLContext.getFunctionAddress("glDrawArraysInstancedBaseInstance")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseInstance = GLContext.getFunctionAddress("glDrawElementsInstancedBaseInstance")) != 0L ? 1 : 0) & ((this.glDrawElementsInstancedBaseVertexBaseInstance = GLContext.getFunctionAddress("glDrawElementsInstancedBaseVertexBaseInstance")) != 0L ? 1 : 0) & ((this.glBindImageTexture = GLContext.getFunctionAddress("glBindImageTexture")) != 0L ? 1 : 0) & ((this.glMemoryBarrier = GLContext.getFunctionAddress("glMemoryBarrier")) != 0L ? 1 : 0) & ((this.glGetInternalformativ = GLContext.getFunctionAddress("glGetInternalformativ")) != 0L ? 1 : 0);
/* 2934:     */   }
/* 2935:     */   
/* 2936:     */   private boolean GL43_initNativeFunctionAddresses()
/* 2937:     */   {
/* 2938:4715 */     return ((this.glClearBufferData = GLContext.getFunctionAddress("glClearBufferData")) != 0L ? 1 : 0) & ((this.glClearBufferSubData = GLContext.getFunctionAddress("glClearBufferSubData")) != 0L ? 1 : 0) & ((this.glDispatchCompute = GLContext.getFunctionAddress("glDispatchCompute")) != 0L ? 1 : 0) & ((this.glDispatchComputeIndirect = GLContext.getFunctionAddress("glDispatchComputeIndirect")) != 0L ? 1 : 0) & ((this.glCopyImageSubData = GLContext.getFunctionAddress("glCopyImageSubData")) != 0L ? 1 : 0) & ((this.glDebugMessageControl = GLContext.getFunctionAddress("glDebugMessageControl")) != 0L ? 1 : 0) & ((this.glDebugMessageInsert = GLContext.getFunctionAddress("glDebugMessageInsert")) != 0L ? 1 : 0) & ((this.glDebugMessageCallback = GLContext.getFunctionAddress("glDebugMessageCallback")) != 0L ? 1 : 0) & ((this.glGetDebugMessageLog = GLContext.getFunctionAddress("glGetDebugMessageLog")) != 0L ? 1 : 0) & ((this.glPushDebugGroup = GLContext.getFunctionAddress("glPushDebugGroup")) != 0L ? 1 : 0) & ((this.glPopDebugGroup = GLContext.getFunctionAddress("glPopDebugGroup")) != 0L ? 1 : 0) & ((this.glObjectLabel = GLContext.getFunctionAddress("glObjectLabel")) != 0L ? 1 : 0) & ((this.glGetObjectLabel = GLContext.getFunctionAddress("glGetObjectLabel")) != 0L ? 1 : 0) & ((this.glObjectPtrLabel = GLContext.getFunctionAddress("glObjectPtrLabel")) != 0L ? 1 : 0) & ((this.glGetObjectPtrLabel = GLContext.getFunctionAddress("glGetObjectPtrLabel")) != 0L ? 1 : 0) & ((this.glFramebufferParameteri = GLContext.getFunctionAddress("glFramebufferParameteri")) != 0L ? 1 : 0) & ((this.glGetFramebufferParameteriv = GLContext.getFunctionAddress("glGetFramebufferParameteriv")) != 0L ? 1 : 0) & ((this.glGetInternalformati64v = GLContext.getFunctionAddress("glGetInternalformati64v")) != 0L ? 1 : 0) & ((this.glInvalidateTexSubImage = GLContext.getFunctionAddress("glInvalidateTexSubImage")) != 0L ? 1 : 0) & ((this.glInvalidateTexImage = GLContext.getFunctionAddress("glInvalidateTexImage")) != 0L ? 1 : 0) & ((this.glInvalidateBufferSubData = GLContext.getFunctionAddress("glInvalidateBufferSubData")) != 0L ? 1 : 0) & ((this.glInvalidateBufferData = GLContext.getFunctionAddress("glInvalidateBufferData")) != 0L ? 1 : 0) & ((this.glInvalidateFramebuffer = GLContext.getFunctionAddress("glInvalidateFramebuffer")) != 0L ? 1 : 0) & ((this.glInvalidateSubFramebuffer = GLContext.getFunctionAddress("glInvalidateSubFramebuffer")) != 0L ? 1 : 0) & ((this.glMultiDrawArraysIndirect = GLContext.getFunctionAddress("glMultiDrawArraysIndirect")) != 0L ? 1 : 0) & ((this.glMultiDrawElementsIndirect = GLContext.getFunctionAddress("glMultiDrawElementsIndirect")) != 0L ? 1 : 0) & ((this.glGetProgramInterfaceiv = GLContext.getFunctionAddress("glGetProgramInterfaceiv")) != 0L ? 1 : 0) & ((this.glGetProgramResourceIndex = GLContext.getFunctionAddress("glGetProgramResourceIndex")) != 0L ? 1 : 0) & ((this.glGetProgramResourceName = GLContext.getFunctionAddress("glGetProgramResourceName")) != 0L ? 1 : 0) & ((this.glGetProgramResourceiv = GLContext.getFunctionAddress("glGetProgramResourceiv")) != 0L ? 1 : 0) & ((this.glGetProgramResourceLocation = GLContext.getFunctionAddress("glGetProgramResourceLocation")) != 0L ? 1 : 0) & ((this.glGetProgramResourceLocationIndex = GLContext.getFunctionAddress("glGetProgramResourceLocationIndex")) != 0L ? 1 : 0) & ((this.glShaderStorageBlockBinding = GLContext.getFunctionAddress("glShaderStorageBlockBinding")) != 0L ? 1 : 0) & ((this.glTexBufferRange = GLContext.getFunctionAddress("glTexBufferRange")) != 0L ? 1 : 0) & ((this.glTexStorage2DMultisample = GLContext.getFunctionAddress("glTexStorage2DMultisample")) != 0L ? 1 : 0) & ((this.glTexStorage3DMultisample = GLContext.getFunctionAddress("glTexStorage3DMultisample")) != 0L ? 1 : 0) & ((this.glTextureView = GLContext.getFunctionAddress("glTextureView")) != 0L ? 1 : 0) & ((this.glBindVertexBuffer = GLContext.getFunctionAddress("glBindVertexBuffer")) != 0L ? 1 : 0) & ((this.glVertexAttribFormat = GLContext.getFunctionAddress("glVertexAttribFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribIFormat = GLContext.getFunctionAddress("glVertexAttribIFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribLFormat = GLContext.getFunctionAddress("glVertexAttribLFormat")) != 0L ? 1 : 0) & ((this.glVertexAttribBinding = GLContext.getFunctionAddress("glVertexAttribBinding")) != 0L ? 1 : 0) & ((this.glVertexBindingDivisor = GLContext.getFunctionAddress("glVertexBindingDivisor")) != 0L ? 1 : 0);
/* 2939:     */   }
/* 2940:     */   
/* 2941:     */   private boolean GREMEDY_frame_terminator_initNativeFunctionAddresses()
/* 2942:     */   {
/* 2943:4762 */     return (this.glFrameTerminatorGREMEDY = GLContext.getFunctionAddress("glFrameTerminatorGREMEDY")) != 0L;
/* 2944:     */   }
/* 2945:     */   
/* 2946:     */   private boolean GREMEDY_string_marker_initNativeFunctionAddresses()
/* 2947:     */   {
/* 2948:4767 */     return (this.glStringMarkerGREMEDY = GLContext.getFunctionAddress("glStringMarkerGREMEDY")) != 0L;
/* 2949:     */   }
/* 2950:     */   
/* 2951:     */   private boolean INTEL_map_texture_initNativeFunctionAddresses()
/* 2952:     */   {
/* 2953:4772 */     return ((this.glMapTexture2DINTEL = GLContext.getFunctionAddress("glMapTexture2DINTEL")) != 0L ? 1 : 0) & ((this.glUnmapTexture2DINTEL = GLContext.getFunctionAddress("glUnmapTexture2DINTEL")) != 0L ? 1 : 0) & ((this.glSyncTextureINTEL = GLContext.getFunctionAddress("glSyncTextureINTEL")) != 0L ? 1 : 0);
/* 2954:     */   }
/* 2955:     */   
/* 2956:     */   private boolean KHR_debug_initNativeFunctionAddresses()
/* 2957:     */   {
/* 2958:4779 */     return ((this.glDebugMessageControl = GLContext.getFunctionAddress("glDebugMessageControl")) != 0L ? 1 : 0) & ((this.glDebugMessageInsert = GLContext.getFunctionAddress("glDebugMessageInsert")) != 0L ? 1 : 0) & ((this.glDebugMessageCallback = GLContext.getFunctionAddress("glDebugMessageCallback")) != 0L ? 1 : 0) & ((this.glGetDebugMessageLog = GLContext.getFunctionAddress("glGetDebugMessageLog")) != 0L ? 1 : 0) & ((this.glPushDebugGroup = GLContext.getFunctionAddress("glPushDebugGroup")) != 0L ? 1 : 0) & ((this.glPopDebugGroup = GLContext.getFunctionAddress("glPopDebugGroup")) != 0L ? 1 : 0) & ((this.glObjectLabel = GLContext.getFunctionAddress("glObjectLabel")) != 0L ? 1 : 0) & ((this.glGetObjectLabel = GLContext.getFunctionAddress("glGetObjectLabel")) != 0L ? 1 : 0) & ((this.glObjectPtrLabel = GLContext.getFunctionAddress("glObjectPtrLabel")) != 0L ? 1 : 0) & ((this.glGetObjectPtrLabel = GLContext.getFunctionAddress("glGetObjectPtrLabel")) != 0L ? 1 : 0);
/* 2959:     */   }
/* 2960:     */   
/* 2961:     */   private boolean NV_bindless_texture_initNativeFunctionAddresses()
/* 2962:     */   {
/* 2963:4793 */     return ((this.glGetTextureHandleNV = GLContext.getFunctionAddress("glGetTextureHandleNV")) != 0L ? 1 : 0) & ((this.glGetTextureSamplerHandleNV = GLContext.getFunctionAddress("glGetTextureSamplerHandleNV")) != 0L ? 1 : 0) & ((this.glMakeTextureHandleResidentNV = GLContext.getFunctionAddress("glMakeTextureHandleResidentNV")) != 0L ? 1 : 0) & ((this.glMakeTextureHandleNonResidentNV = GLContext.getFunctionAddress("glMakeTextureHandleNonResidentNV")) != 0L ? 1 : 0) & ((this.glGetImageHandleNV = GLContext.getFunctionAddress("glGetImageHandleNV")) != 0L ? 1 : 0) & ((this.glMakeImageHandleResidentNV = GLContext.getFunctionAddress("glMakeImageHandleResidentNV")) != 0L ? 1 : 0) & ((this.glMakeImageHandleNonResidentNV = GLContext.getFunctionAddress("glMakeImageHandleNonResidentNV")) != 0L ? 1 : 0) & ((this.glUniformHandleui64NV = GLContext.getFunctionAddress("glUniformHandleui64NV")) != 0L ? 1 : 0) & ((this.glUniformHandleui64vNV = GLContext.getFunctionAddress("glUniformHandleui64vNV")) != 0L ? 1 : 0) & ((this.glProgramUniformHandleui64NV = GLContext.getFunctionAddress("glProgramUniformHandleui64NV")) != 0L ? 1 : 0) & ((this.glProgramUniformHandleui64vNV = GLContext.getFunctionAddress("glProgramUniformHandleui64vNV")) != 0L ? 1 : 0) & ((this.glIsTextureHandleResidentNV = GLContext.getFunctionAddress("glIsTextureHandleResidentNV")) != 0L ? 1 : 0) & ((this.glIsImageHandleResidentNV = GLContext.getFunctionAddress("glIsImageHandleResidentNV")) != 0L ? 1 : 0);
/* 2964:     */   }
/* 2965:     */   
/* 2966:     */   private boolean NV_conditional_render_initNativeFunctionAddresses()
/* 2967:     */   {
/* 2968:4810 */     return ((this.glBeginConditionalRenderNV = GLContext.getFunctionAddress("glBeginConditionalRenderNV")) != 0L ? 1 : 0) & ((this.glEndConditionalRenderNV = GLContext.getFunctionAddress("glEndConditionalRenderNV")) != 0L ? 1 : 0);
/* 2969:     */   }
/* 2970:     */   
/* 2971:     */   private boolean NV_copy_image_initNativeFunctionAddresses()
/* 2972:     */   {
/* 2973:4816 */     return (this.glCopyImageSubDataNV = GLContext.getFunctionAddress("glCopyImageSubDataNV")) != 0L;
/* 2974:     */   }
/* 2975:     */   
/* 2976:     */   private boolean NV_depth_buffer_float_initNativeFunctionAddresses()
/* 2977:     */   {
/* 2978:4821 */     return ((this.glDepthRangedNV = GLContext.getFunctionAddress("glDepthRangedNV")) != 0L ? 1 : 0) & ((this.glClearDepthdNV = GLContext.getFunctionAddress("glClearDepthdNV")) != 0L ? 1 : 0) & ((this.glDepthBoundsdNV = GLContext.getFunctionAddress("glDepthBoundsdNV")) != 0L ? 1 : 0);
/* 2979:     */   }
/* 2980:     */   
/* 2981:     */   private boolean NV_draw_texture_initNativeFunctionAddresses()
/* 2982:     */   {
/* 2983:4828 */     return (this.glDrawTextureNV = GLContext.getFunctionAddress("glDrawTextureNV")) != 0L;
/* 2984:     */   }
/* 2985:     */   
/* 2986:     */   private boolean NV_evaluators_initNativeFunctionAddresses()
/* 2987:     */   {
/* 2988:4833 */     return ((this.glGetMapControlPointsNV = GLContext.getFunctionAddress("glGetMapControlPointsNV")) != 0L ? 1 : 0) & ((this.glMapControlPointsNV = GLContext.getFunctionAddress("glMapControlPointsNV")) != 0L ? 1 : 0) & ((this.glMapParameterfvNV = GLContext.getFunctionAddress("glMapParameterfvNV")) != 0L ? 1 : 0) & ((this.glMapParameterivNV = GLContext.getFunctionAddress("glMapParameterivNV")) != 0L ? 1 : 0) & ((this.glGetMapParameterfvNV = GLContext.getFunctionAddress("glGetMapParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetMapParameterivNV = GLContext.getFunctionAddress("glGetMapParameterivNV")) != 0L ? 1 : 0) & ((this.glGetMapAttribParameterfvNV = GLContext.getFunctionAddress("glGetMapAttribParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetMapAttribParameterivNV = GLContext.getFunctionAddress("glGetMapAttribParameterivNV")) != 0L ? 1 : 0) & ((this.glEvalMapsNV = GLContext.getFunctionAddress("glEvalMapsNV")) != 0L ? 1 : 0);
/* 2989:     */   }
/* 2990:     */   
/* 2991:     */   private boolean NV_explicit_multisample_initNativeFunctionAddresses()
/* 2992:     */   {
/* 2993:4846 */     return ((this.glGetBooleanIndexedvEXT = GLContext.getFunctionAddress("glGetBooleanIndexedvEXT")) != 0L ? 1 : 0) & ((this.glGetIntegerIndexedvEXT = GLContext.getFunctionAddress("glGetIntegerIndexedvEXT")) != 0L ? 1 : 0) & ((this.glGetMultisamplefvNV = GLContext.getFunctionAddress("glGetMultisamplefvNV")) != 0L ? 1 : 0) & ((this.glSampleMaskIndexedNV = GLContext.getFunctionAddress("glSampleMaskIndexedNV")) != 0L ? 1 : 0) & ((this.glTexRenderbufferNV = GLContext.getFunctionAddress("glTexRenderbufferNV")) != 0L ? 1 : 0);
/* 2994:     */   }
/* 2995:     */   
/* 2996:     */   private boolean NV_fence_initNativeFunctionAddresses()
/* 2997:     */   {
/* 2998:4855 */     return ((this.glGenFencesNV = GLContext.getFunctionAddress("glGenFencesNV")) != 0L ? 1 : 0) & ((this.glDeleteFencesNV = GLContext.getFunctionAddress("glDeleteFencesNV")) != 0L ? 1 : 0) & ((this.glSetFenceNV = GLContext.getFunctionAddress("glSetFenceNV")) != 0L ? 1 : 0) & ((this.glTestFenceNV = GLContext.getFunctionAddress("glTestFenceNV")) != 0L ? 1 : 0) & ((this.glFinishFenceNV = GLContext.getFunctionAddress("glFinishFenceNV")) != 0L ? 1 : 0) & ((this.glIsFenceNV = GLContext.getFunctionAddress("glIsFenceNV")) != 0L ? 1 : 0) & ((this.glGetFenceivNV = GLContext.getFunctionAddress("glGetFenceivNV")) != 0L ? 1 : 0);
/* 2999:     */   }
/* 3000:     */   
/* 3001:     */   private boolean NV_fragment_program_initNativeFunctionAddresses()
/* 3002:     */   {
/* 3003:4866 */     return ((this.glProgramNamedParameter4fNV = GLContext.getFunctionAddress("glProgramNamedParameter4fNV")) != 0L ? 1 : 0) & ((this.glProgramNamedParameter4dNV = GLContext.getFunctionAddress("glProgramNamedParameter4dNV")) != 0L ? 1 : 0) & ((this.glGetProgramNamedParameterfvNV = GLContext.getFunctionAddress("glGetProgramNamedParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetProgramNamedParameterdvNV = GLContext.getFunctionAddress("glGetProgramNamedParameterdvNV")) != 0L ? 1 : 0);
/* 3004:     */   }
/* 3005:     */   
/* 3006:     */   private boolean NV_framebuffer_multisample_coverage_initNativeFunctionAddresses()
/* 3007:     */   {
/* 3008:4874 */     return (this.glRenderbufferStorageMultisampleCoverageNV = GLContext.getFunctionAddress("glRenderbufferStorageMultisampleCoverageNV")) != 0L;
/* 3009:     */   }
/* 3010:     */   
/* 3011:     */   private boolean NV_geometry_program4_initNativeFunctionAddresses()
/* 3012:     */   {
/* 3013:4879 */     return ((this.glProgramVertexLimitNV = GLContext.getFunctionAddress("glProgramVertexLimitNV")) != 0L ? 1 : 0) & ((this.glFramebufferTextureEXT = GLContext.getFunctionAddress("glFramebufferTextureEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTextureLayerEXT = GLContext.getFunctionAddress("glFramebufferTextureLayerEXT")) != 0L ? 1 : 0) & ((this.glFramebufferTextureFaceEXT = GLContext.getFunctionAddress("glFramebufferTextureFaceEXT")) != 0L ? 1 : 0);
/* 3014:     */   }
/* 3015:     */   
/* 3016:     */   private boolean NV_gpu_program4_initNativeFunctionAddresses()
/* 3017:     */   {
/* 3018:4887 */     return ((this.glProgramLocalParameterI4iNV = GLContext.getFunctionAddress("glProgramLocalParameterI4iNV")) != 0L ? 1 : 0) & ((this.glProgramLocalParameterI4ivNV = GLContext.getFunctionAddress("glProgramLocalParameterI4ivNV")) != 0L ? 1 : 0) & ((this.glProgramLocalParametersI4ivNV = GLContext.getFunctionAddress("glProgramLocalParametersI4ivNV")) != 0L ? 1 : 0) & ((this.glProgramLocalParameterI4uiNV = GLContext.getFunctionAddress("glProgramLocalParameterI4uiNV")) != 0L ? 1 : 0) & ((this.glProgramLocalParameterI4uivNV = GLContext.getFunctionAddress("glProgramLocalParameterI4uivNV")) != 0L ? 1 : 0) & ((this.glProgramLocalParametersI4uivNV = GLContext.getFunctionAddress("glProgramLocalParametersI4uivNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParameterI4iNV = GLContext.getFunctionAddress("glProgramEnvParameterI4iNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParameterI4ivNV = GLContext.getFunctionAddress("glProgramEnvParameterI4ivNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParametersI4ivNV = GLContext.getFunctionAddress("glProgramEnvParametersI4ivNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParameterI4uiNV = GLContext.getFunctionAddress("glProgramEnvParameterI4uiNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParameterI4uivNV = GLContext.getFunctionAddress("glProgramEnvParameterI4uivNV")) != 0L ? 1 : 0) & ((this.glProgramEnvParametersI4uivNV = GLContext.getFunctionAddress("glProgramEnvParametersI4uivNV")) != 0L ? 1 : 0) & ((this.glGetProgramLocalParameterIivNV = GLContext.getFunctionAddress("glGetProgramLocalParameterIivNV")) != 0L ? 1 : 0) & ((this.glGetProgramLocalParameterIuivNV = GLContext.getFunctionAddress("glGetProgramLocalParameterIuivNV")) != 0L ? 1 : 0) & ((this.glGetProgramEnvParameterIivNV = GLContext.getFunctionAddress("glGetProgramEnvParameterIivNV")) != 0L ? 1 : 0) & ((this.glGetProgramEnvParameterIuivNV = GLContext.getFunctionAddress("glGetProgramEnvParameterIuivNV")) != 0L ? 1 : 0);
/* 3019:     */   }
/* 3020:     */   
/* 3021:     */   private boolean NV_gpu_shader5_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 3022:     */   {
/* 3023:4907 */     return ((this.glUniform1i64NV = GLContext.getFunctionAddress("glUniform1i64NV")) != 0L ? 1 : 0) & ((this.glUniform2i64NV = GLContext.getFunctionAddress("glUniform2i64NV")) != 0L ? 1 : 0) & ((this.glUniform3i64NV = GLContext.getFunctionAddress("glUniform3i64NV")) != 0L ? 1 : 0) & ((this.glUniform4i64NV = GLContext.getFunctionAddress("glUniform4i64NV")) != 0L ? 1 : 0) & ((this.glUniform1i64vNV = GLContext.getFunctionAddress("glUniform1i64vNV")) != 0L ? 1 : 0) & ((this.glUniform2i64vNV = GLContext.getFunctionAddress("glUniform2i64vNV")) != 0L ? 1 : 0) & ((this.glUniform3i64vNV = GLContext.getFunctionAddress("glUniform3i64vNV")) != 0L ? 1 : 0) & ((this.glUniform4i64vNV = GLContext.getFunctionAddress("glUniform4i64vNV")) != 0L ? 1 : 0) & ((this.glUniform1ui64NV = GLContext.getFunctionAddress("glUniform1ui64NV")) != 0L ? 1 : 0) & ((this.glUniform2ui64NV = GLContext.getFunctionAddress("glUniform2ui64NV")) != 0L ? 1 : 0) & ((this.glUniform3ui64NV = GLContext.getFunctionAddress("glUniform3ui64NV")) != 0L ? 1 : 0) & ((this.glUniform4ui64NV = GLContext.getFunctionAddress("glUniform4ui64NV")) != 0L ? 1 : 0) & ((this.glUniform1ui64vNV = GLContext.getFunctionAddress("glUniform1ui64vNV")) != 0L ? 1 : 0) & ((this.glUniform2ui64vNV = GLContext.getFunctionAddress("glUniform2ui64vNV")) != 0L ? 1 : 0) & ((this.glUniform3ui64vNV = GLContext.getFunctionAddress("glUniform3ui64vNV")) != 0L ? 1 : 0) & ((this.glUniform4ui64vNV = GLContext.getFunctionAddress("glUniform4ui64vNV")) != 0L ? 1 : 0) & ((this.glGetUniformi64vNV = GLContext.getFunctionAddress("glGetUniformi64vNV")) != 0L ? 1 : 0) & ((this.glGetUniformui64vNV = GLContext.getFunctionAddress("glGetUniformui64vNV")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1i64NV = GLContext.getFunctionAddress("glProgramUniform1i64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2i64NV = GLContext.getFunctionAddress("glProgramUniform2i64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3i64NV = GLContext.getFunctionAddress("glProgramUniform3i64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4i64NV = GLContext.getFunctionAddress("glProgramUniform4i64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1i64vNV = GLContext.getFunctionAddress("glProgramUniform1i64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2i64vNV = GLContext.getFunctionAddress("glProgramUniform2i64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3i64vNV = GLContext.getFunctionAddress("glProgramUniform3i64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4i64vNV = GLContext.getFunctionAddress("glProgramUniform4i64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1ui64NV = GLContext.getFunctionAddress("glProgramUniform1ui64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2ui64NV = GLContext.getFunctionAddress("glProgramUniform2ui64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3ui64NV = GLContext.getFunctionAddress("glProgramUniform3ui64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4ui64NV = GLContext.getFunctionAddress("glProgramUniform4ui64NV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform1ui64vNV = GLContext.getFunctionAddress("glProgramUniform1ui64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform2ui64vNV = GLContext.getFunctionAddress("glProgramUniform2ui64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform3ui64vNV = GLContext.getFunctionAddress("glProgramUniform3ui64vNV")) != 0L) ? 1 : 0) & ((!supported_extensions.contains("GL_EXT_direct_state_access")) || ((this.glProgramUniform4ui64vNV = GLContext.getFunctionAddress("glProgramUniform4ui64vNV")) != 0L) ? 1 : 0);
/* 3024:     */   }
/* 3025:     */   
/* 3026:     */   private boolean NV_half_float_initNativeFunctionAddresses()
/* 3027:     */   {
/* 3028:4945 */     if (((this.glVertexWeighthNV = GLContext.getFunctionAddress("glVertexWeighthNV")) != 0L) || (((this.glVertexAttrib1hNV = GLContext.getFunctionAddress("glVertexAttrib1hNV")) != 0L) || (((this.glVertexAttrib2hNV = GLContext.getFunctionAddress("glVertexAttrib2hNV")) != 0L) || (((this.glVertexAttrib3hNV = GLContext.getFunctionAddress("glVertexAttrib3hNV")) != 0L) || (((this.glVertexAttrib4hNV = GLContext.getFunctionAddress("glVertexAttrib4hNV")) != 0L) || (((this.glVertexAttribs1hvNV = GLContext.getFunctionAddress("glVertexAttribs1hvNV")) != 0L) || (((this.glVertexAttribs2hvNV = GLContext.getFunctionAddress("glVertexAttribs2hvNV")) != 0L) || (((this.glVertexAttribs3hvNV = GLContext.getFunctionAddress("glVertexAttribs3hvNV")) != 0L) || ((this.glVertexAttribs4hvNV = GLContext.getFunctionAddress("glVertexAttribs4hvNV")) == 0L))))))))) {}
/* 3029:4945 */     return ((this.glVertex2hNV = GLContext.getFunctionAddress("glVertex2hNV")) != 0L ? 1 : 0) & ((this.glVertex3hNV = GLContext.getFunctionAddress("glVertex3hNV")) != 0L ? 1 : 0) & ((this.glVertex4hNV = GLContext.getFunctionAddress("glVertex4hNV")) != 0L ? 1 : 0) & ((this.glNormal3hNV = GLContext.getFunctionAddress("glNormal3hNV")) != 0L ? 1 : 0) & ((this.glColor3hNV = GLContext.getFunctionAddress("glColor3hNV")) != 0L ? 1 : 0) & ((this.glColor4hNV = GLContext.getFunctionAddress("glColor4hNV")) != 0L ? 1 : 0) & ((this.glTexCoord1hNV = GLContext.getFunctionAddress("glTexCoord1hNV")) != 0L ? 1 : 0) & ((this.glTexCoord2hNV = GLContext.getFunctionAddress("glTexCoord2hNV")) != 0L ? 1 : 0) & ((this.glTexCoord3hNV = GLContext.getFunctionAddress("glTexCoord3hNV")) != 0L ? 1 : 0) & ((this.glTexCoord4hNV = GLContext.getFunctionAddress("glTexCoord4hNV")) != 0L ? 1 : 0) & ((this.glMultiTexCoord1hNV = GLContext.getFunctionAddress("glMultiTexCoord1hNV")) != 0L ? 1 : 0) & ((this.glMultiTexCoord2hNV = GLContext.getFunctionAddress("glMultiTexCoord2hNV")) != 0L ? 1 : 0) & ((this.glMultiTexCoord3hNV = GLContext.getFunctionAddress("glMultiTexCoord3hNV")) != 0L ? 1 : 0) & ((this.glMultiTexCoord4hNV = GLContext.getFunctionAddress("glMultiTexCoord4hNV")) != 0L ? 1 : 0) & ((this.glFogCoordhNV = GLContext.getFunctionAddress("glFogCoordhNV")) != 0L ? 1 : 0) & ((this.glSecondaryColor3hNV = GLContext.getFunctionAddress("glSecondaryColor3hNV")) != 0L ? 1 : 0) & 0x1 & 0x1 & 0x1 & 0x1 & 0x1 & 0x1 & 0x1 & 0x1 & 0x1;
/* 3030:     */   }
/* 3031:     */   
/* 3032:     */   private boolean NV_occlusion_query_initNativeFunctionAddresses()
/* 3033:     */   {
/* 3034:4974 */     return ((this.glGenOcclusionQueriesNV = GLContext.getFunctionAddress("glGenOcclusionQueriesNV")) != 0L ? 1 : 0) & ((this.glDeleteOcclusionQueriesNV = GLContext.getFunctionAddress("glDeleteOcclusionQueriesNV")) != 0L ? 1 : 0) & ((this.glIsOcclusionQueryNV = GLContext.getFunctionAddress("glIsOcclusionQueryNV")) != 0L ? 1 : 0) & ((this.glBeginOcclusionQueryNV = GLContext.getFunctionAddress("glBeginOcclusionQueryNV")) != 0L ? 1 : 0) & ((this.glEndOcclusionQueryNV = GLContext.getFunctionAddress("glEndOcclusionQueryNV")) != 0L ? 1 : 0) & ((this.glGetOcclusionQueryuivNV = GLContext.getFunctionAddress("glGetOcclusionQueryuivNV")) != 0L ? 1 : 0) & ((this.glGetOcclusionQueryivNV = GLContext.getFunctionAddress("glGetOcclusionQueryivNV")) != 0L ? 1 : 0);
/* 3035:     */   }
/* 3036:     */   
/* 3037:     */   private boolean NV_parameter_buffer_object_initNativeFunctionAddresses()
/* 3038:     */   {
/* 3039:4985 */     return ((this.glProgramBufferParametersfvNV = GLContext.getFunctionAddress("glProgramBufferParametersfvNV")) != 0L ? 1 : 0) & ((this.glProgramBufferParametersIivNV = GLContext.getFunctionAddress("glProgramBufferParametersIivNV")) != 0L ? 1 : 0) & ((this.glProgramBufferParametersIuivNV = GLContext.getFunctionAddress("glProgramBufferParametersIuivNV")) != 0L ? 1 : 0);
/* 3040:     */   }
/* 3041:     */   
/* 3042:     */   private boolean NV_path_rendering_initNativeFunctionAddresses()
/* 3043:     */   {
/* 3044:4992 */     return ((this.glPathCommandsNV = GLContext.getFunctionAddress("glPathCommandsNV")) != 0L ? 1 : 0) & ((this.glPathCoordsNV = GLContext.getFunctionAddress("glPathCoordsNV")) != 0L ? 1 : 0) & ((this.glPathSubCommandsNV = GLContext.getFunctionAddress("glPathSubCommandsNV")) != 0L ? 1 : 0) & ((this.glPathSubCoordsNV = GLContext.getFunctionAddress("glPathSubCoordsNV")) != 0L ? 1 : 0) & ((this.glPathStringNV = GLContext.getFunctionAddress("glPathStringNV")) != 0L ? 1 : 0) & ((this.glPathGlyphsNV = GLContext.getFunctionAddress("glPathGlyphsNV")) != 0L ? 1 : 0) & ((this.glPathGlyphRangeNV = GLContext.getFunctionAddress("glPathGlyphRangeNV")) != 0L ? 1 : 0) & ((this.glWeightPathsNV = GLContext.getFunctionAddress("glWeightPathsNV")) != 0L ? 1 : 0) & ((this.glCopyPathNV = GLContext.getFunctionAddress("glCopyPathNV")) != 0L ? 1 : 0) & ((this.glInterpolatePathsNV = GLContext.getFunctionAddress("glInterpolatePathsNV")) != 0L ? 1 : 0) & ((this.glTransformPathNV = GLContext.getFunctionAddress("glTransformPathNV")) != 0L ? 1 : 0) & ((this.glPathParameterivNV = GLContext.getFunctionAddress("glPathParameterivNV")) != 0L ? 1 : 0) & ((this.glPathParameteriNV = GLContext.getFunctionAddress("glPathParameteriNV")) != 0L ? 1 : 0) & ((this.glPathParameterfvNV = GLContext.getFunctionAddress("glPathParameterfvNV")) != 0L ? 1 : 0) & ((this.glPathParameterfNV = GLContext.getFunctionAddress("glPathParameterfNV")) != 0L ? 1 : 0) & ((this.glPathDashArrayNV = GLContext.getFunctionAddress("glPathDashArrayNV")) != 0L ? 1 : 0) & ((this.glGenPathsNV = GLContext.getFunctionAddress("glGenPathsNV")) != 0L ? 1 : 0) & ((this.glDeletePathsNV = GLContext.getFunctionAddress("glDeletePathsNV")) != 0L ? 1 : 0) & ((this.glIsPathNV = GLContext.getFunctionAddress("glIsPathNV")) != 0L ? 1 : 0) & ((this.glPathStencilFuncNV = GLContext.getFunctionAddress("glPathStencilFuncNV")) != 0L ? 1 : 0) & ((this.glPathStencilDepthOffsetNV = GLContext.getFunctionAddress("glPathStencilDepthOffsetNV")) != 0L ? 1 : 0) & ((this.glStencilFillPathNV = GLContext.getFunctionAddress("glStencilFillPathNV")) != 0L ? 1 : 0) & ((this.glStencilStrokePathNV = GLContext.getFunctionAddress("glStencilStrokePathNV")) != 0L ? 1 : 0) & ((this.glStencilFillPathInstancedNV = GLContext.getFunctionAddress("glStencilFillPathInstancedNV")) != 0L ? 1 : 0) & ((this.glStencilStrokePathInstancedNV = GLContext.getFunctionAddress("glStencilStrokePathInstancedNV")) != 0L ? 1 : 0) & ((this.glPathCoverDepthFuncNV = GLContext.getFunctionAddress("glPathCoverDepthFuncNV")) != 0L ? 1 : 0) & ((this.glPathColorGenNV = GLContext.getFunctionAddress("glPathColorGenNV")) != 0L ? 1 : 0) & ((this.glPathTexGenNV = GLContext.getFunctionAddress("glPathTexGenNV")) != 0L ? 1 : 0) & ((this.glPathFogGenNV = GLContext.getFunctionAddress("glPathFogGenNV")) != 0L ? 1 : 0) & ((this.glCoverFillPathNV = GLContext.getFunctionAddress("glCoverFillPathNV")) != 0L ? 1 : 0) & ((this.glCoverStrokePathNV = GLContext.getFunctionAddress("glCoverStrokePathNV")) != 0L ? 1 : 0) & ((this.glCoverFillPathInstancedNV = GLContext.getFunctionAddress("glCoverFillPathInstancedNV")) != 0L ? 1 : 0) & ((this.glCoverStrokePathInstancedNV = GLContext.getFunctionAddress("glCoverStrokePathInstancedNV")) != 0L ? 1 : 0) & ((this.glGetPathParameterivNV = GLContext.getFunctionAddress("glGetPathParameterivNV")) != 0L ? 1 : 0) & ((this.glGetPathParameterfvNV = GLContext.getFunctionAddress("glGetPathParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetPathCommandsNV = GLContext.getFunctionAddress("glGetPathCommandsNV")) != 0L ? 1 : 0) & ((this.glGetPathCoordsNV = GLContext.getFunctionAddress("glGetPathCoordsNV")) != 0L ? 1 : 0) & ((this.glGetPathDashArrayNV = GLContext.getFunctionAddress("glGetPathDashArrayNV")) != 0L ? 1 : 0) & ((this.glGetPathMetricsNV = GLContext.getFunctionAddress("glGetPathMetricsNV")) != 0L ? 1 : 0) & ((this.glGetPathMetricRangeNV = GLContext.getFunctionAddress("glGetPathMetricRangeNV")) != 0L ? 1 : 0) & ((this.glGetPathSpacingNV = GLContext.getFunctionAddress("glGetPathSpacingNV")) != 0L ? 1 : 0) & ((this.glGetPathColorGenivNV = GLContext.getFunctionAddress("glGetPathColorGenivNV")) != 0L ? 1 : 0) & ((this.glGetPathColorGenfvNV = GLContext.getFunctionAddress("glGetPathColorGenfvNV")) != 0L ? 1 : 0) & ((this.glGetPathTexGenivNV = GLContext.getFunctionAddress("glGetPathTexGenivNV")) != 0L ? 1 : 0) & ((this.glGetPathTexGenfvNV = GLContext.getFunctionAddress("glGetPathTexGenfvNV")) != 0L ? 1 : 0) & ((this.glIsPointInFillPathNV = GLContext.getFunctionAddress("glIsPointInFillPathNV")) != 0L ? 1 : 0) & ((this.glIsPointInStrokePathNV = GLContext.getFunctionAddress("glIsPointInStrokePathNV")) != 0L ? 1 : 0) & ((this.glGetPathLengthNV = GLContext.getFunctionAddress("glGetPathLengthNV")) != 0L ? 1 : 0) & ((this.glPointAlongPathNV = GLContext.getFunctionAddress("glPointAlongPathNV")) != 0L ? 1 : 0);
/* 3045:     */   }
/* 3046:     */   
/* 3047:     */   private boolean NV_pixel_data_range_initNativeFunctionAddresses()
/* 3048:     */   {
/* 3049:5045 */     return ((this.glPixelDataRangeNV = GLContext.getFunctionAddress("glPixelDataRangeNV")) != 0L ? 1 : 0) & ((this.glFlushPixelDataRangeNV = GLContext.getFunctionAddress("glFlushPixelDataRangeNV")) != 0L ? 1 : 0);
/* 3050:     */   }
/* 3051:     */   
/* 3052:     */   private boolean NV_point_sprite_initNativeFunctionAddresses()
/* 3053:     */   {
/* 3054:5051 */     return ((this.glPointParameteriNV = GLContext.getFunctionAddress("glPointParameteriNV")) != 0L ? 1 : 0) & ((this.glPointParameterivNV = GLContext.getFunctionAddress("glPointParameterivNV")) != 0L ? 1 : 0);
/* 3055:     */   }
/* 3056:     */   
/* 3057:     */   private boolean NV_present_video_initNativeFunctionAddresses()
/* 3058:     */   {
/* 3059:5057 */     return ((this.glPresentFrameKeyedNV = GLContext.getFunctionAddress("glPresentFrameKeyedNV")) != 0L ? 1 : 0) & ((this.glPresentFrameDualFillNV = GLContext.getFunctionAddress("glPresentFrameDualFillNV")) != 0L ? 1 : 0) & ((this.glGetVideoivNV = GLContext.getFunctionAddress("glGetVideoivNV")) != 0L ? 1 : 0) & ((this.glGetVideouivNV = GLContext.getFunctionAddress("glGetVideouivNV")) != 0L ? 1 : 0) & ((this.glGetVideoi64vNV = GLContext.getFunctionAddress("glGetVideoi64vNV")) != 0L ? 1 : 0) & ((this.glGetVideoui64vNV = GLContext.getFunctionAddress("glGetVideoui64vNV")) != 0L ? 1 : 0);
/* 3060:     */   }
/* 3061:     */   
/* 3062:     */   private boolean NV_primitive_restart_initNativeFunctionAddresses()
/* 3063:     */   {
/* 3064:5067 */     return ((this.glPrimitiveRestartNV = GLContext.getFunctionAddress("glPrimitiveRestartNV")) != 0L ? 1 : 0) & ((this.glPrimitiveRestartIndexNV = GLContext.getFunctionAddress("glPrimitiveRestartIndexNV")) != 0L ? 1 : 0);
/* 3065:     */   }
/* 3066:     */   
/* 3067:     */   private boolean NV_program_initNativeFunctionAddresses()
/* 3068:     */   {
/* 3069:5073 */     return ((this.glLoadProgramNV = GLContext.getFunctionAddress("glLoadProgramNV")) != 0L ? 1 : 0) & ((this.glBindProgramNV = GLContext.getFunctionAddress("glBindProgramNV")) != 0L ? 1 : 0) & ((this.glDeleteProgramsNV = GLContext.getFunctionAddress("glDeleteProgramsNV")) != 0L ? 1 : 0) & ((this.glGenProgramsNV = GLContext.getFunctionAddress("glGenProgramsNV")) != 0L ? 1 : 0) & ((this.glGetProgramivNV = GLContext.getFunctionAddress("glGetProgramivNV")) != 0L ? 1 : 0) & ((this.glGetProgramStringNV = GLContext.getFunctionAddress("glGetProgramStringNV")) != 0L ? 1 : 0) & ((this.glIsProgramNV = GLContext.getFunctionAddress("glIsProgramNV")) != 0L ? 1 : 0) & ((this.glAreProgramsResidentNV = GLContext.getFunctionAddress("glAreProgramsResidentNV")) != 0L ? 1 : 0) & ((this.glRequestResidentProgramsNV = GLContext.getFunctionAddress("glRequestResidentProgramsNV")) != 0L ? 1 : 0);
/* 3070:     */   }
/* 3071:     */   
/* 3072:     */   private boolean NV_register_combiners_initNativeFunctionAddresses()
/* 3073:     */   {
/* 3074:5086 */     return ((this.glCombinerParameterfNV = GLContext.getFunctionAddress("glCombinerParameterfNV")) != 0L ? 1 : 0) & ((this.glCombinerParameterfvNV = GLContext.getFunctionAddress("glCombinerParameterfvNV")) != 0L ? 1 : 0) & ((this.glCombinerParameteriNV = GLContext.getFunctionAddress("glCombinerParameteriNV")) != 0L ? 1 : 0) & ((this.glCombinerParameterivNV = GLContext.getFunctionAddress("glCombinerParameterivNV")) != 0L ? 1 : 0) & ((this.glCombinerInputNV = GLContext.getFunctionAddress("glCombinerInputNV")) != 0L ? 1 : 0) & ((this.glCombinerOutputNV = GLContext.getFunctionAddress("glCombinerOutputNV")) != 0L ? 1 : 0) & ((this.glFinalCombinerInputNV = GLContext.getFunctionAddress("glFinalCombinerInputNV")) != 0L ? 1 : 0) & ((this.glGetCombinerInputParameterfvNV = GLContext.getFunctionAddress("glGetCombinerInputParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetCombinerInputParameterivNV = GLContext.getFunctionAddress("glGetCombinerInputParameterivNV")) != 0L ? 1 : 0) & ((this.glGetCombinerOutputParameterfvNV = GLContext.getFunctionAddress("glGetCombinerOutputParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetCombinerOutputParameterivNV = GLContext.getFunctionAddress("glGetCombinerOutputParameterivNV")) != 0L ? 1 : 0) & ((this.glGetFinalCombinerInputParameterfvNV = GLContext.getFunctionAddress("glGetFinalCombinerInputParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetFinalCombinerInputParameterivNV = GLContext.getFunctionAddress("glGetFinalCombinerInputParameterivNV")) != 0L ? 1 : 0);
/* 3075:     */   }
/* 3076:     */   
/* 3077:     */   private boolean NV_register_combiners2_initNativeFunctionAddresses()
/* 3078:     */   {
/* 3079:5103 */     return ((this.glCombinerStageParameterfvNV = GLContext.getFunctionAddress("glCombinerStageParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetCombinerStageParameterfvNV = GLContext.getFunctionAddress("glGetCombinerStageParameterfvNV")) != 0L ? 1 : 0);
/* 3080:     */   }
/* 3081:     */   
/* 3082:     */   private boolean NV_shader_buffer_load_initNativeFunctionAddresses()
/* 3083:     */   {
/* 3084:5109 */     return ((this.glMakeBufferResidentNV = GLContext.getFunctionAddress("glMakeBufferResidentNV")) != 0L ? 1 : 0) & ((this.glMakeBufferNonResidentNV = GLContext.getFunctionAddress("glMakeBufferNonResidentNV")) != 0L ? 1 : 0) & ((this.glIsBufferResidentNV = GLContext.getFunctionAddress("glIsBufferResidentNV")) != 0L ? 1 : 0) & ((this.glMakeNamedBufferResidentNV = GLContext.getFunctionAddress("glMakeNamedBufferResidentNV")) != 0L ? 1 : 0) & ((this.glMakeNamedBufferNonResidentNV = GLContext.getFunctionAddress("glMakeNamedBufferNonResidentNV")) != 0L ? 1 : 0) & ((this.glIsNamedBufferResidentNV = GLContext.getFunctionAddress("glIsNamedBufferResidentNV")) != 0L ? 1 : 0) & ((this.glGetBufferParameterui64vNV = GLContext.getFunctionAddress("glGetBufferParameterui64vNV")) != 0L ? 1 : 0) & ((this.glGetNamedBufferParameterui64vNV = GLContext.getFunctionAddress("glGetNamedBufferParameterui64vNV")) != 0L ? 1 : 0) & ((this.glGetIntegerui64vNV = GLContext.getFunctionAddress("glGetIntegerui64vNV")) != 0L ? 1 : 0) & ((this.glUniformui64NV = GLContext.getFunctionAddress("glUniformui64NV")) != 0L ? 1 : 0) & ((this.glUniformui64vNV = GLContext.getFunctionAddress("glUniformui64vNV")) != 0L ? 1 : 0) & ((this.glGetUniformui64vNV = GLContext.getFunctionAddress("glGetUniformui64vNV")) != 0L ? 1 : 0) & ((this.glProgramUniformui64NV = GLContext.getFunctionAddress("glProgramUniformui64NV")) != 0L ? 1 : 0) & ((this.glProgramUniformui64vNV = GLContext.getFunctionAddress("glProgramUniformui64vNV")) != 0L ? 1 : 0);
/* 3085:     */   }
/* 3086:     */   
/* 3087:     */   private boolean NV_texture_barrier_initNativeFunctionAddresses()
/* 3088:     */   {
/* 3089:5127 */     return (this.glTextureBarrierNV = GLContext.getFunctionAddress("glTextureBarrierNV")) != 0L;
/* 3090:     */   }
/* 3091:     */   
/* 3092:     */   private boolean NV_texture_multisample_initNativeFunctionAddresses()
/* 3093:     */   {
/* 3094:5132 */     return ((this.glTexImage2DMultisampleCoverageNV = GLContext.getFunctionAddress("glTexImage2DMultisampleCoverageNV")) != 0L ? 1 : 0) & ((this.glTexImage3DMultisampleCoverageNV = GLContext.getFunctionAddress("glTexImage3DMultisampleCoverageNV")) != 0L ? 1 : 0) & ((this.glTextureImage2DMultisampleNV = GLContext.getFunctionAddress("glTextureImage2DMultisampleNV")) != 0L ? 1 : 0) & ((this.glTextureImage3DMultisampleNV = GLContext.getFunctionAddress("glTextureImage3DMultisampleNV")) != 0L ? 1 : 0) & ((this.glTextureImage2DMultisampleCoverageNV = GLContext.getFunctionAddress("glTextureImage2DMultisampleCoverageNV")) != 0L ? 1 : 0) & ((this.glTextureImage3DMultisampleCoverageNV = GLContext.getFunctionAddress("glTextureImage3DMultisampleCoverageNV")) != 0L ? 1 : 0);
/* 3095:     */   }
/* 3096:     */   
/* 3097:     */   private boolean NV_transform_feedback_initNativeFunctionAddresses()
/* 3098:     */   {
/* 3099:5142 */     return ((this.glBindBufferRangeNV = GLContext.getFunctionAddress("glBindBufferRangeNV")) != 0L ? 1 : 0) & ((this.glBindBufferOffsetNV = GLContext.getFunctionAddress("glBindBufferOffsetNV")) != 0L ? 1 : 0) & ((this.glBindBufferBaseNV = GLContext.getFunctionAddress("glBindBufferBaseNV")) != 0L ? 1 : 0) & ((this.glTransformFeedbackAttribsNV = GLContext.getFunctionAddress("glTransformFeedbackAttribsNV")) != 0L ? 1 : 0) & ((this.glTransformFeedbackVaryingsNV = GLContext.getFunctionAddress("glTransformFeedbackVaryingsNV")) != 0L ? 1 : 0) & ((this.glBeginTransformFeedbackNV = GLContext.getFunctionAddress("glBeginTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glEndTransformFeedbackNV = GLContext.getFunctionAddress("glEndTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glGetVaryingLocationNV = GLContext.getFunctionAddress("glGetVaryingLocationNV")) != 0L ? 1 : 0) & ((this.glGetActiveVaryingNV = GLContext.getFunctionAddress("glGetActiveVaryingNV")) != 0L ? 1 : 0) & ((this.glActiveVaryingNV = GLContext.getFunctionAddress("glActiveVaryingNV")) != 0L ? 1 : 0) & ((this.glGetTransformFeedbackVaryingNV = GLContext.getFunctionAddress("glGetTransformFeedbackVaryingNV")) != 0L ? 1 : 0);
/* 3100:     */   }
/* 3101:     */   
/* 3102:     */   private boolean NV_transform_feedback2_initNativeFunctionAddresses()
/* 3103:     */   {
/* 3104:5157 */     return ((this.glBindTransformFeedbackNV = GLContext.getFunctionAddress("glBindTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glDeleteTransformFeedbacksNV = GLContext.getFunctionAddress("glDeleteTransformFeedbacksNV")) != 0L ? 1 : 0) & ((this.glGenTransformFeedbacksNV = GLContext.getFunctionAddress("glGenTransformFeedbacksNV")) != 0L ? 1 : 0) & ((this.glIsTransformFeedbackNV = GLContext.getFunctionAddress("glIsTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glPauseTransformFeedbackNV = GLContext.getFunctionAddress("glPauseTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glResumeTransformFeedbackNV = GLContext.getFunctionAddress("glResumeTransformFeedbackNV")) != 0L ? 1 : 0) & ((this.glDrawTransformFeedbackNV = GLContext.getFunctionAddress("glDrawTransformFeedbackNV")) != 0L ? 1 : 0);
/* 3105:     */   }
/* 3106:     */   
/* 3107:     */   private boolean NV_vertex_array_range_initNativeFunctionAddresses()
/* 3108:     */   {
/* 3109:5168 */     return ((this.glVertexArrayRangeNV = GLContext.getFunctionAddress("glVertexArrayRangeNV")) != 0L ? 1 : 0) & ((this.glFlushVertexArrayRangeNV = GLContext.getFunctionAddress("glFlushVertexArrayRangeNV")) != 0L ? 1 : 0) & ((this.glAllocateMemoryNV = GLContext.getPlatformSpecificFunctionAddress("gl", new String[] { "Windows", "Linux" }, new String[] { "wgl", "glX" }, "glAllocateMemoryNV")) != 0L ? 1 : 0) & ((this.glFreeMemoryNV = GLContext.getPlatformSpecificFunctionAddress("gl", new String[] { "Windows", "Linux" }, new String[] { "wgl", "glX" }, "glFreeMemoryNV")) != 0L ? 1 : 0);
/* 3110:     */   }
/* 3111:     */   
/* 3112:     */   private boolean NV_vertex_attrib_integer_64bit_initNativeFunctionAddresses(Set<String> supported_extensions)
/* 3113:     */   {
/* 3114:5176 */     return ((this.glVertexAttribL1i64NV = GLContext.getFunctionAddress("glVertexAttribL1i64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL2i64NV = GLContext.getFunctionAddress("glVertexAttribL2i64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL3i64NV = GLContext.getFunctionAddress("glVertexAttribL3i64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL4i64NV = GLContext.getFunctionAddress("glVertexAttribL4i64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL1i64vNV = GLContext.getFunctionAddress("glVertexAttribL1i64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL2i64vNV = GLContext.getFunctionAddress("glVertexAttribL2i64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL3i64vNV = GLContext.getFunctionAddress("glVertexAttribL3i64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL4i64vNV = GLContext.getFunctionAddress("glVertexAttribL4i64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL1ui64NV = GLContext.getFunctionAddress("glVertexAttribL1ui64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL2ui64NV = GLContext.getFunctionAddress("glVertexAttribL2ui64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL3ui64NV = GLContext.getFunctionAddress("glVertexAttribL3ui64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL4ui64NV = GLContext.getFunctionAddress("glVertexAttribL4ui64NV")) != 0L ? 1 : 0) & ((this.glVertexAttribL1ui64vNV = GLContext.getFunctionAddress("glVertexAttribL1ui64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL2ui64vNV = GLContext.getFunctionAddress("glVertexAttribL2ui64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL3ui64vNV = GLContext.getFunctionAddress("glVertexAttribL3ui64vNV")) != 0L ? 1 : 0) & ((this.glVertexAttribL4ui64vNV = GLContext.getFunctionAddress("glVertexAttribL4ui64vNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribLi64vNV = GLContext.getFunctionAddress("glGetVertexAttribLi64vNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribLui64vNV = GLContext.getFunctionAddress("glGetVertexAttribLui64vNV")) != 0L ? 1 : 0) & ((!supported_extensions.contains("GL_NV_vertex_buffer_unified_memory")) || ((this.glVertexAttribLFormatNV = GLContext.getFunctionAddress("glVertexAttribLFormatNV")) != 0L) ? 1 : 0);
/* 3115:     */   }
/* 3116:     */   
/* 3117:     */   private boolean NV_vertex_buffer_unified_memory_initNativeFunctionAddresses()
/* 3118:     */   {
/* 3119:5199 */     return ((this.glBufferAddressRangeNV = GLContext.getFunctionAddress("glBufferAddressRangeNV")) != 0L ? 1 : 0) & ((this.glVertexFormatNV = GLContext.getFunctionAddress("glVertexFormatNV")) != 0L ? 1 : 0) & ((this.glNormalFormatNV = GLContext.getFunctionAddress("glNormalFormatNV")) != 0L ? 1 : 0) & ((this.glColorFormatNV = GLContext.getFunctionAddress("glColorFormatNV")) != 0L ? 1 : 0) & ((this.glIndexFormatNV = GLContext.getFunctionAddress("glIndexFormatNV")) != 0L ? 1 : 0) & ((this.glTexCoordFormatNV = GLContext.getFunctionAddress("glTexCoordFormatNV")) != 0L ? 1 : 0) & ((this.glEdgeFlagFormatNV = GLContext.getFunctionAddress("glEdgeFlagFormatNV")) != 0L ? 1 : 0) & ((this.glSecondaryColorFormatNV = GLContext.getFunctionAddress("glSecondaryColorFormatNV")) != 0L ? 1 : 0) & ((this.glFogCoordFormatNV = GLContext.getFunctionAddress("glFogCoordFormatNV")) != 0L ? 1 : 0) & ((this.glVertexAttribFormatNV = GLContext.getFunctionAddress("glVertexAttribFormatNV")) != 0L ? 1 : 0) & ((this.glVertexAttribIFormatNV = GLContext.getFunctionAddress("glVertexAttribIFormatNV")) != 0L ? 1 : 0) & ((this.glGetIntegerui64i_vNV = GLContext.getFunctionAddress("glGetIntegerui64i_vNV")) != 0L ? 1 : 0);
/* 3120:     */   }
/* 3121:     */   
/* 3122:     */   private boolean NV_vertex_program_initNativeFunctionAddresses()
/* 3123:     */   {
/* 3124:5215 */     return ((this.glExecuteProgramNV = GLContext.getFunctionAddress("glExecuteProgramNV")) != 0L ? 1 : 0) & ((this.glGetProgramParameterfvNV = GLContext.getFunctionAddress("glGetProgramParameterfvNV")) != 0L ? 1 : 0) & ((this.glGetProgramParameterdvNV = GLContext.getFunctionAddress("glGetProgramParameterdvNV")) != 0L ? 1 : 0) & ((this.glGetTrackMatrixivNV = GLContext.getFunctionAddress("glGetTrackMatrixivNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribfvNV = GLContext.getFunctionAddress("glGetVertexAttribfvNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribdvNV = GLContext.getFunctionAddress("glGetVertexAttribdvNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribivNV = GLContext.getFunctionAddress("glGetVertexAttribivNV")) != 0L ? 1 : 0) & ((this.glGetVertexAttribPointervNV = GLContext.getFunctionAddress("glGetVertexAttribPointervNV")) != 0L ? 1 : 0) & ((this.glProgramParameter4fNV = GLContext.getFunctionAddress("glProgramParameter4fNV")) != 0L ? 1 : 0) & ((this.glProgramParameter4dNV = GLContext.getFunctionAddress("glProgramParameter4dNV")) != 0L ? 1 : 0) & ((this.glProgramParameters4fvNV = GLContext.getFunctionAddress("glProgramParameters4fvNV")) != 0L ? 1 : 0) & ((this.glProgramParameters4dvNV = GLContext.getFunctionAddress("glProgramParameters4dvNV")) != 0L ? 1 : 0) & ((this.glTrackMatrixNV = GLContext.getFunctionAddress("glTrackMatrixNV")) != 0L ? 1 : 0) & ((this.glVertexAttribPointerNV = GLContext.getFunctionAddress("glVertexAttribPointerNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib1sNV = GLContext.getFunctionAddress("glVertexAttrib1sNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib1fNV = GLContext.getFunctionAddress("glVertexAttrib1fNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib1dNV = GLContext.getFunctionAddress("glVertexAttrib1dNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib2sNV = GLContext.getFunctionAddress("glVertexAttrib2sNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib2fNV = GLContext.getFunctionAddress("glVertexAttrib2fNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib2dNV = GLContext.getFunctionAddress("glVertexAttrib2dNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib3sNV = GLContext.getFunctionAddress("glVertexAttrib3sNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib3fNV = GLContext.getFunctionAddress("glVertexAttrib3fNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib3dNV = GLContext.getFunctionAddress("glVertexAttrib3dNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib4sNV = GLContext.getFunctionAddress("glVertexAttrib4sNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib4fNV = GLContext.getFunctionAddress("glVertexAttrib4fNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib4dNV = GLContext.getFunctionAddress("glVertexAttrib4dNV")) != 0L ? 1 : 0) & ((this.glVertexAttrib4ubNV = GLContext.getFunctionAddress("glVertexAttrib4ubNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs1svNV = GLContext.getFunctionAddress("glVertexAttribs1svNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs1fvNV = GLContext.getFunctionAddress("glVertexAttribs1fvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs1dvNV = GLContext.getFunctionAddress("glVertexAttribs1dvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs2svNV = GLContext.getFunctionAddress("glVertexAttribs2svNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs2fvNV = GLContext.getFunctionAddress("glVertexAttribs2fvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs2dvNV = GLContext.getFunctionAddress("glVertexAttribs2dvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs3svNV = GLContext.getFunctionAddress("glVertexAttribs3svNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs3fvNV = GLContext.getFunctionAddress("glVertexAttribs3fvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs3dvNV = GLContext.getFunctionAddress("glVertexAttribs3dvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs4svNV = GLContext.getFunctionAddress("glVertexAttribs4svNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs4fvNV = GLContext.getFunctionAddress("glVertexAttribs4fvNV")) != 0L ? 1 : 0) & ((this.glVertexAttribs4dvNV = GLContext.getFunctionAddress("glVertexAttribs4dvNV")) != 0L ? 1 : 0);
/* 3125:     */   }
/* 3126:     */   
/* 3127:     */   private boolean NV_video_capture_initNativeFunctionAddresses()
/* 3128:     */   {
/* 3129:5258 */     return ((this.glBeginVideoCaptureNV = GLContext.getFunctionAddress("glBeginVideoCaptureNV")) != 0L ? 1 : 0) & ((this.glBindVideoCaptureStreamBufferNV = GLContext.getFunctionAddress("glBindVideoCaptureStreamBufferNV")) != 0L ? 1 : 0) & ((this.glBindVideoCaptureStreamTextureNV = GLContext.getFunctionAddress("glBindVideoCaptureStreamTextureNV")) != 0L ? 1 : 0) & ((this.glEndVideoCaptureNV = GLContext.getFunctionAddress("glEndVideoCaptureNV")) != 0L ? 1 : 0) & ((this.glGetVideoCaptureivNV = GLContext.getFunctionAddress("glGetVideoCaptureivNV")) != 0L ? 1 : 0) & ((this.glGetVideoCaptureStreamivNV = GLContext.getFunctionAddress("glGetVideoCaptureStreamivNV")) != 0L ? 1 : 0) & ((this.glGetVideoCaptureStreamfvNV = GLContext.getFunctionAddress("glGetVideoCaptureStreamfvNV")) != 0L ? 1 : 0) & ((this.glGetVideoCaptureStreamdvNV = GLContext.getFunctionAddress("glGetVideoCaptureStreamdvNV")) != 0L ? 1 : 0) & ((this.glVideoCaptureNV = GLContext.getFunctionAddress("glVideoCaptureNV")) != 0L ? 1 : 0) & ((this.glVideoCaptureStreamParameterivNV = GLContext.getFunctionAddress("glVideoCaptureStreamParameterivNV")) != 0L ? 1 : 0) & ((this.glVideoCaptureStreamParameterfvNV = GLContext.getFunctionAddress("glVideoCaptureStreamParameterfvNV")) != 0L ? 1 : 0) & ((this.glVideoCaptureStreamParameterdvNV = GLContext.getFunctionAddress("glVideoCaptureStreamParameterdvNV")) != 0L ? 1 : 0);
/* 3130:     */   }
/* 3131:     */   
/* 3132:     */   private static void remove(Set supported_extensions, String extension)
/* 3133:     */   {
/* 3134:5275 */     LWJGLUtil.log(extension + " was reported as available but an entry point is missing");
/* 3135:5276 */     supported_extensions.remove(extension);
/* 3136:     */   }
/* 3137:     */   
/* 3138:     */   private Set<String> initAllStubs(boolean forwardCompatible)
/* 3139:     */     throws LWJGLException
/* 3140:     */   {
/* 3141:5280 */     this.glGetError = GLContext.getFunctionAddress("glGetError");
/* 3142:5281 */     this.glGetString = GLContext.getFunctionAddress("glGetString");
/* 3143:5282 */     this.glGetIntegerv = GLContext.getFunctionAddress("glGetIntegerv");
/* 3144:5283 */     this.glGetStringi = GLContext.getFunctionAddress("glGetStringi");
/* 3145:5284 */     GLContext.setCapabilities(this);
/* 3146:5285 */     Set<String> supported_extensions = new HashSet(256);
/* 3147:5286 */     int profileMask = GLContext.getSupportedExtensions(supported_extensions);
/* 3148:5287 */     if ((supported_extensions.contains("OpenGL31")) && (!supported_extensions.contains("GL_ARB_compatibility")) && ((profileMask & 0x2) == 0)) {
/* 3149:5288 */       forwardCompatible = true;
/* 3150:     */     }
/* 3151:5289 */     if (!GL11_initNativeFunctionAddresses(forwardCompatible)) {
/* 3152:5290 */       throw new LWJGLException("GL11 not supported");
/* 3153:     */     }
/* 3154:5291 */     if (supported_extensions.contains("GL_ARB_fragment_program")) {
/* 3155:5292 */       supported_extensions.add("GL_ARB_program");
/* 3156:     */     }
/* 3157:5293 */     if (supported_extensions.contains("GL_ARB_pixel_buffer_object")) {
/* 3158:5294 */       supported_extensions.add("GL_ARB_buffer_object");
/* 3159:     */     }
/* 3160:5295 */     if (supported_extensions.contains("GL_ARB_vertex_buffer_object")) {
/* 3161:5296 */       supported_extensions.add("GL_ARB_buffer_object");
/* 3162:     */     }
/* 3163:5297 */     if (supported_extensions.contains("GL_ARB_vertex_program")) {
/* 3164:5298 */       supported_extensions.add("GL_ARB_program");
/* 3165:     */     }
/* 3166:5299 */     if (supported_extensions.contains("GL_EXT_pixel_buffer_object")) {
/* 3167:5300 */       supported_extensions.add("GL_ARB_buffer_object");
/* 3168:     */     }
/* 3169:5301 */     if (supported_extensions.contains("GL_NV_fragment_program")) {
/* 3170:5302 */       supported_extensions.add("GL_NV_program");
/* 3171:     */     }
/* 3172:5303 */     if (supported_extensions.contains("GL_NV_vertex_program")) {
/* 3173:5304 */       supported_extensions.add("GL_NV_program");
/* 3174:     */     }
/* 3175:5305 */     if (((supported_extensions.contains("GL_AMD_debug_output")) || (supported_extensions.contains("GL_AMDX_debug_output"))) && (!AMD_debug_output_initNativeFunctionAddresses()))
/* 3176:     */     {
/* 3177:5306 */       remove(supported_extensions, "GL_AMDX_debug_output");
/* 3178:5307 */       remove(supported_extensions, "GL_AMD_debug_output");
/* 3179:     */     }
/* 3180:5309 */     if ((supported_extensions.contains("GL_AMD_draw_buffers_blend")) && (!AMD_draw_buffers_blend_initNativeFunctionAddresses())) {
/* 3181:5310 */       remove(supported_extensions, "GL_AMD_draw_buffers_blend");
/* 3182:     */     }
/* 3183:5311 */     if ((supported_extensions.contains("GL_AMD_multi_draw_indirect")) && (!AMD_multi_draw_indirect_initNativeFunctionAddresses())) {
/* 3184:5312 */       remove(supported_extensions, "GL_AMD_multi_draw_indirect");
/* 3185:     */     }
/* 3186:5313 */     if ((supported_extensions.contains("GL_AMD_name_gen_delete")) && (!AMD_name_gen_delete_initNativeFunctionAddresses())) {
/* 3187:5314 */       remove(supported_extensions, "GL_AMD_name_gen_delete");
/* 3188:     */     }
/* 3189:5315 */     if ((supported_extensions.contains("GL_AMD_performance_monitor")) && (!AMD_performance_monitor_initNativeFunctionAddresses())) {
/* 3190:5316 */       remove(supported_extensions, "GL_AMD_performance_monitor");
/* 3191:     */     }
/* 3192:5317 */     if ((supported_extensions.contains("GL_AMD_sample_positions")) && (!AMD_sample_positions_initNativeFunctionAddresses())) {
/* 3193:5318 */       remove(supported_extensions, "GL_AMD_sample_positions");
/* 3194:     */     }
/* 3195:5319 */     if ((supported_extensions.contains("GL_AMD_sparse_texture")) && (!AMD_sparse_texture_initNativeFunctionAddresses())) {
/* 3196:5320 */       remove(supported_extensions, "GL_AMD_sparse_texture");
/* 3197:     */     }
/* 3198:5321 */     if ((supported_extensions.contains("GL_AMD_stencil_operation_extended")) && (!AMD_stencil_operation_extended_initNativeFunctionAddresses())) {
/* 3199:5322 */       remove(supported_extensions, "GL_AMD_stencil_operation_extended");
/* 3200:     */     }
/* 3201:5323 */     if ((supported_extensions.contains("GL_AMD_vertex_shader_tessellator")) && (!AMD_vertex_shader_tessellator_initNativeFunctionAddresses())) {
/* 3202:5324 */       remove(supported_extensions, "GL_AMD_vertex_shader_tessellator");
/* 3203:     */     }
/* 3204:5325 */     if ((supported_extensions.contains("GL_APPLE_element_array")) && (!APPLE_element_array_initNativeFunctionAddresses())) {
/* 3205:5326 */       remove(supported_extensions, "GL_APPLE_element_array");
/* 3206:     */     }
/* 3207:5327 */     if ((supported_extensions.contains("GL_APPLE_fence")) && (!APPLE_fence_initNativeFunctionAddresses())) {
/* 3208:5328 */       remove(supported_extensions, "GL_APPLE_fence");
/* 3209:     */     }
/* 3210:5329 */     if ((supported_extensions.contains("GL_APPLE_flush_buffer_range")) && (!APPLE_flush_buffer_range_initNativeFunctionAddresses())) {
/* 3211:5330 */       remove(supported_extensions, "GL_APPLE_flush_buffer_range");
/* 3212:     */     }
/* 3213:5331 */     if ((supported_extensions.contains("GL_APPLE_object_purgeable")) && (!APPLE_object_purgeable_initNativeFunctionAddresses())) {
/* 3214:5332 */       remove(supported_extensions, "GL_APPLE_object_purgeable");
/* 3215:     */     }
/* 3216:5333 */     if ((supported_extensions.contains("GL_APPLE_texture_range")) && (!APPLE_texture_range_initNativeFunctionAddresses())) {
/* 3217:5334 */       remove(supported_extensions, "GL_APPLE_texture_range");
/* 3218:     */     }
/* 3219:5335 */     if ((supported_extensions.contains("GL_APPLE_vertex_array_object")) && (!APPLE_vertex_array_object_initNativeFunctionAddresses())) {
/* 3220:5336 */       remove(supported_extensions, "GL_APPLE_vertex_array_object");
/* 3221:     */     }
/* 3222:5337 */     if ((supported_extensions.contains("GL_APPLE_vertex_array_range")) && (!APPLE_vertex_array_range_initNativeFunctionAddresses())) {
/* 3223:5338 */       remove(supported_extensions, "GL_APPLE_vertex_array_range");
/* 3224:     */     }
/* 3225:5339 */     if ((supported_extensions.contains("GL_APPLE_vertex_program_evaluators")) && (!APPLE_vertex_program_evaluators_initNativeFunctionAddresses())) {
/* 3226:5340 */       remove(supported_extensions, "GL_APPLE_vertex_program_evaluators");
/* 3227:     */     }
/* 3228:5341 */     if ((supported_extensions.contains("GL_ARB_ES2_compatibility")) && (!ARB_ES2_compatibility_initNativeFunctionAddresses())) {
/* 3229:5342 */       remove(supported_extensions, "GL_ARB_ES2_compatibility");
/* 3230:     */     }
/* 3231:5343 */     if ((supported_extensions.contains("GL_ARB_base_instance")) && (!ARB_base_instance_initNativeFunctionAddresses())) {
/* 3232:5344 */       remove(supported_extensions, "GL_ARB_base_instance");
/* 3233:     */     }
/* 3234:5345 */     if ((supported_extensions.contains("GL_ARB_blend_func_extended")) && (!ARB_blend_func_extended_initNativeFunctionAddresses())) {
/* 3235:5346 */       remove(supported_extensions, "GL_ARB_blend_func_extended");
/* 3236:     */     }
/* 3237:5347 */     if ((supported_extensions.contains("GL_ARB_buffer_object")) && (!ARB_buffer_object_initNativeFunctionAddresses())) {
/* 3238:5348 */       remove(supported_extensions, "GL_ARB_buffer_object");
/* 3239:     */     }
/* 3240:5349 */     if ((supported_extensions.contains("GL_ARB_cl_event")) && (!ARB_cl_event_initNativeFunctionAddresses())) {
/* 3241:5350 */       remove(supported_extensions, "GL_ARB_cl_event");
/* 3242:     */     }
/* 3243:5351 */     if ((supported_extensions.contains("GL_ARB_clear_buffer_object")) && (!ARB_clear_buffer_object_initNativeFunctionAddresses(supported_extensions))) {
/* 3244:5352 */       remove(supported_extensions, "GL_ARB_clear_buffer_object");
/* 3245:     */     }
/* 3246:5353 */     if ((supported_extensions.contains("GL_ARB_color_buffer_float")) && (!ARB_color_buffer_float_initNativeFunctionAddresses())) {
/* 3247:5354 */       remove(supported_extensions, "GL_ARB_color_buffer_float");
/* 3248:     */     }
/* 3249:5355 */     if ((supported_extensions.contains("GL_ARB_compute_shader")) && (!ARB_compute_shader_initNativeFunctionAddresses())) {
/* 3250:5356 */       remove(supported_extensions, "GL_ARB_compute_shader");
/* 3251:     */     }
/* 3252:5357 */     if ((supported_extensions.contains("GL_ARB_copy_buffer")) && (!ARB_copy_buffer_initNativeFunctionAddresses())) {
/* 3253:5358 */       remove(supported_extensions, "GL_ARB_copy_buffer");
/* 3254:     */     }
/* 3255:5359 */     if ((supported_extensions.contains("GL_ARB_copy_image")) && (!ARB_copy_image_initNativeFunctionAddresses())) {
/* 3256:5360 */       remove(supported_extensions, "GL_ARB_copy_image");
/* 3257:     */     }
/* 3258:5361 */     if ((supported_extensions.contains("GL_ARB_debug_output")) && (!ARB_debug_output_initNativeFunctionAddresses())) {
/* 3259:5362 */       remove(supported_extensions, "GL_ARB_debug_output");
/* 3260:     */     }
/* 3261:5363 */     if ((supported_extensions.contains("GL_ARB_draw_buffers")) && (!ARB_draw_buffers_initNativeFunctionAddresses())) {
/* 3262:5364 */       remove(supported_extensions, "GL_ARB_draw_buffers");
/* 3263:     */     }
/* 3264:5365 */     if ((supported_extensions.contains("GL_ARB_draw_buffers_blend")) && (!ARB_draw_buffers_blend_initNativeFunctionAddresses())) {
/* 3265:5366 */       remove(supported_extensions, "GL_ARB_draw_buffers_blend");
/* 3266:     */     }
/* 3267:5367 */     if ((supported_extensions.contains("GL_ARB_draw_elements_base_vertex")) && (!ARB_draw_elements_base_vertex_initNativeFunctionAddresses())) {
/* 3268:5368 */       remove(supported_extensions, "GL_ARB_draw_elements_base_vertex");
/* 3269:     */     }
/* 3270:5369 */     if ((supported_extensions.contains("GL_ARB_draw_indirect")) && (!ARB_draw_indirect_initNativeFunctionAddresses())) {
/* 3271:5370 */       remove(supported_extensions, "GL_ARB_draw_indirect");
/* 3272:     */     }
/* 3273:5371 */     if ((supported_extensions.contains("GL_ARB_draw_instanced")) && (!ARB_draw_instanced_initNativeFunctionAddresses())) {
/* 3274:5372 */       remove(supported_extensions, "GL_ARB_draw_instanced");
/* 3275:     */     }
/* 3276:5373 */     if ((supported_extensions.contains("GL_ARB_framebuffer_no_attachments")) && (!ARB_framebuffer_no_attachments_initNativeFunctionAddresses(supported_extensions))) {
/* 3277:5374 */       remove(supported_extensions, "GL_ARB_framebuffer_no_attachments");
/* 3278:     */     }
/* 3279:5375 */     if ((supported_extensions.contains("GL_ARB_framebuffer_object")) && (!ARB_framebuffer_object_initNativeFunctionAddresses())) {
/* 3280:5376 */       remove(supported_extensions, "GL_ARB_framebuffer_object");
/* 3281:     */     }
/* 3282:5377 */     if ((supported_extensions.contains("GL_ARB_geometry_shader4")) && (!ARB_geometry_shader4_initNativeFunctionAddresses())) {
/* 3283:5378 */       remove(supported_extensions, "GL_ARB_geometry_shader4");
/* 3284:     */     }
/* 3285:5379 */     if ((supported_extensions.contains("GL_ARB_get_program_binary")) && (!ARB_get_program_binary_initNativeFunctionAddresses())) {
/* 3286:5380 */       remove(supported_extensions, "GL_ARB_get_program_binary");
/* 3287:     */     }
/* 3288:5381 */     if ((supported_extensions.contains("GL_ARB_gpu_shader_fp64")) && (!ARB_gpu_shader_fp64_initNativeFunctionAddresses(supported_extensions))) {
/* 3289:5382 */       remove(supported_extensions, "GL_ARB_gpu_shader_fp64");
/* 3290:     */     }
/* 3291:5383 */     if ((supported_extensions.contains("GL_ARB_imaging")) && (!ARB_imaging_initNativeFunctionAddresses(forwardCompatible))) {
/* 3292:5384 */       remove(supported_extensions, "GL_ARB_imaging");
/* 3293:     */     }
/* 3294:5385 */     if ((supported_extensions.contains("GL_ARB_instanced_arrays")) && (!ARB_instanced_arrays_initNativeFunctionAddresses())) {
/* 3295:5386 */       remove(supported_extensions, "GL_ARB_instanced_arrays");
/* 3296:     */     }
/* 3297:5387 */     if ((supported_extensions.contains("GL_ARB_internalformat_query")) && (!ARB_internalformat_query_initNativeFunctionAddresses())) {
/* 3298:5388 */       remove(supported_extensions, "GL_ARB_internalformat_query");
/* 3299:     */     }
/* 3300:5389 */     if ((supported_extensions.contains("GL_ARB_internalformat_query2")) && (!ARB_internalformat_query2_initNativeFunctionAddresses())) {
/* 3301:5390 */       remove(supported_extensions, "GL_ARB_internalformat_query2");
/* 3302:     */     }
/* 3303:5391 */     if ((supported_extensions.contains("GL_ARB_invalidate_subdata")) && (!ARB_invalidate_subdata_initNativeFunctionAddresses())) {
/* 3304:5392 */       remove(supported_extensions, "GL_ARB_invalidate_subdata");
/* 3305:     */     }
/* 3306:5393 */     if ((supported_extensions.contains("GL_ARB_map_buffer_range")) && (!ARB_map_buffer_range_initNativeFunctionAddresses())) {
/* 3307:5394 */       remove(supported_extensions, "GL_ARB_map_buffer_range");
/* 3308:     */     }
/* 3309:5395 */     if ((supported_extensions.contains("GL_ARB_matrix_palette")) && (!ARB_matrix_palette_initNativeFunctionAddresses())) {
/* 3310:5396 */       remove(supported_extensions, "GL_ARB_matrix_palette");
/* 3311:     */     }
/* 3312:5397 */     if ((supported_extensions.contains("GL_ARB_multi_draw_indirect")) && (!ARB_multi_draw_indirect_initNativeFunctionAddresses())) {
/* 3313:5398 */       remove(supported_extensions, "GL_ARB_multi_draw_indirect");
/* 3314:     */     }
/* 3315:5399 */     if ((supported_extensions.contains("GL_ARB_multisample")) && (!ARB_multisample_initNativeFunctionAddresses())) {
/* 3316:5400 */       remove(supported_extensions, "GL_ARB_multisample");
/* 3317:     */     }
/* 3318:5401 */     if ((supported_extensions.contains("GL_ARB_multitexture")) && (!ARB_multitexture_initNativeFunctionAddresses())) {
/* 3319:5402 */       remove(supported_extensions, "GL_ARB_multitexture");
/* 3320:     */     }
/* 3321:5403 */     if ((supported_extensions.contains("GL_ARB_occlusion_query")) && (!ARB_occlusion_query_initNativeFunctionAddresses())) {
/* 3322:5404 */       remove(supported_extensions, "GL_ARB_occlusion_query");
/* 3323:     */     }
/* 3324:5405 */     if ((supported_extensions.contains("GL_ARB_point_parameters")) && (!ARB_point_parameters_initNativeFunctionAddresses())) {
/* 3325:5406 */       remove(supported_extensions, "GL_ARB_point_parameters");
/* 3326:     */     }
/* 3327:5407 */     if ((supported_extensions.contains("GL_ARB_program")) && (!ARB_program_initNativeFunctionAddresses())) {
/* 3328:5408 */       remove(supported_extensions, "GL_ARB_program");
/* 3329:     */     }
/* 3330:5409 */     if ((supported_extensions.contains("GL_ARB_program_interface_query")) && (!ARB_program_interface_query_initNativeFunctionAddresses())) {
/* 3331:5410 */       remove(supported_extensions, "GL_ARB_program_interface_query");
/* 3332:     */     }
/* 3333:5411 */     if ((supported_extensions.contains("GL_ARB_provoking_vertex")) && (!ARB_provoking_vertex_initNativeFunctionAddresses())) {
/* 3334:5412 */       remove(supported_extensions, "GL_ARB_provoking_vertex");
/* 3335:     */     }
/* 3336:5413 */     if ((supported_extensions.contains("GL_ARB_robustness")) && (!ARB_robustness_initNativeFunctionAddresses(forwardCompatible, supported_extensions))) {
/* 3337:5414 */       remove(supported_extensions, "GL_ARB_robustness");
/* 3338:     */     }
/* 3339:5415 */     if ((supported_extensions.contains("GL_ARB_sample_shading")) && (!ARB_sample_shading_initNativeFunctionAddresses())) {
/* 3340:5416 */       remove(supported_extensions, "GL_ARB_sample_shading");
/* 3341:     */     }
/* 3342:5417 */     if ((supported_extensions.contains("GL_ARB_sampler_objects")) && (!ARB_sampler_objects_initNativeFunctionAddresses())) {
/* 3343:5418 */       remove(supported_extensions, "GL_ARB_sampler_objects");
/* 3344:     */     }
/* 3345:5419 */     if ((supported_extensions.contains("GL_ARB_separate_shader_objects")) && (!ARB_separate_shader_objects_initNativeFunctionAddresses())) {
/* 3346:5420 */       remove(supported_extensions, "GL_ARB_separate_shader_objects");
/* 3347:     */     }
/* 3348:5421 */     if ((supported_extensions.contains("GL_ARB_shader_atomic_counters")) && (!ARB_shader_atomic_counters_initNativeFunctionAddresses())) {
/* 3349:5422 */       remove(supported_extensions, "GL_ARB_shader_atomic_counters");
/* 3350:     */     }
/* 3351:5423 */     if ((supported_extensions.contains("GL_ARB_shader_image_load_store")) && (!ARB_shader_image_load_store_initNativeFunctionAddresses())) {
/* 3352:5424 */       remove(supported_extensions, "GL_ARB_shader_image_load_store");
/* 3353:     */     }
/* 3354:5425 */     if ((supported_extensions.contains("GL_ARB_shader_objects")) && (!ARB_shader_objects_initNativeFunctionAddresses())) {
/* 3355:5426 */       remove(supported_extensions, "GL_ARB_shader_objects");
/* 3356:     */     }
/* 3357:5427 */     if ((supported_extensions.contains("GL_ARB_shader_storage_buffer_object")) && (!ARB_shader_storage_buffer_object_initNativeFunctionAddresses())) {
/* 3358:5428 */       remove(supported_extensions, "GL_ARB_shader_storage_buffer_object");
/* 3359:     */     }
/* 3360:5429 */     if ((supported_extensions.contains("GL_ARB_shader_subroutine")) && (!ARB_shader_subroutine_initNativeFunctionAddresses())) {
/* 3361:5430 */       remove(supported_extensions, "GL_ARB_shader_subroutine");
/* 3362:     */     }
/* 3363:5431 */     if ((supported_extensions.contains("GL_ARB_shading_language_include")) && (!ARB_shading_language_include_initNativeFunctionAddresses())) {
/* 3364:5432 */       remove(supported_extensions, "GL_ARB_shading_language_include");
/* 3365:     */     }
/* 3366:5433 */     if ((supported_extensions.contains("GL_ARB_sync")) && (!ARB_sync_initNativeFunctionAddresses())) {
/* 3367:5434 */       remove(supported_extensions, "GL_ARB_sync");
/* 3368:     */     }
/* 3369:5435 */     if ((supported_extensions.contains("GL_ARB_tessellation_shader")) && (!ARB_tessellation_shader_initNativeFunctionAddresses())) {
/* 3370:5436 */       remove(supported_extensions, "GL_ARB_tessellation_shader");
/* 3371:     */     }
/* 3372:5437 */     if ((supported_extensions.contains("GL_ARB_texture_buffer_object")) && (!ARB_texture_buffer_object_initNativeFunctionAddresses())) {
/* 3373:5438 */       remove(supported_extensions, "GL_ARB_texture_buffer_object");
/* 3374:     */     }
/* 3375:5439 */     if ((supported_extensions.contains("GL_ARB_texture_buffer_range")) && (!ARB_texture_buffer_range_initNativeFunctionAddresses(supported_extensions))) {
/* 3376:5440 */       remove(supported_extensions, "GL_ARB_texture_buffer_range");
/* 3377:     */     }
/* 3378:5441 */     if ((supported_extensions.contains("GL_ARB_texture_compression")) && (!ARB_texture_compression_initNativeFunctionAddresses())) {
/* 3379:5442 */       remove(supported_extensions, "GL_ARB_texture_compression");
/* 3380:     */     }
/* 3381:5443 */     if ((supported_extensions.contains("GL_ARB_texture_multisample")) && (!ARB_texture_multisample_initNativeFunctionAddresses())) {
/* 3382:5444 */       remove(supported_extensions, "GL_ARB_texture_multisample");
/* 3383:     */     }
/* 3384:5445 */     if (((supported_extensions.contains("GL_ARB_texture_storage")) || (supported_extensions.contains("GL_EXT_texture_storage"))) && (!ARB_texture_storage_initNativeFunctionAddresses(supported_extensions)))
/* 3385:     */     {
/* 3386:5446 */       remove(supported_extensions, "GL_EXT_texture_storage");
/* 3387:5447 */       remove(supported_extensions, "GL_ARB_texture_storage");
/* 3388:     */     }
/* 3389:5449 */     if ((supported_extensions.contains("GL_ARB_texture_storage_multisample")) && (!ARB_texture_storage_multisample_initNativeFunctionAddresses(supported_extensions))) {
/* 3390:5450 */       remove(supported_extensions, "GL_ARB_texture_storage_multisample");
/* 3391:     */     }
/* 3392:5451 */     if ((supported_extensions.contains("GL_ARB_texture_view")) && (!ARB_texture_view_initNativeFunctionAddresses())) {
/* 3393:5452 */       remove(supported_extensions, "GL_ARB_texture_view");
/* 3394:     */     }
/* 3395:5453 */     if ((supported_extensions.contains("GL_ARB_timer_query")) && (!ARB_timer_query_initNativeFunctionAddresses())) {
/* 3396:5454 */       remove(supported_extensions, "GL_ARB_timer_query");
/* 3397:     */     }
/* 3398:5455 */     if ((supported_extensions.contains("GL_ARB_transform_feedback2")) && (!ARB_transform_feedback2_initNativeFunctionAddresses())) {
/* 3399:5456 */       remove(supported_extensions, "GL_ARB_transform_feedback2");
/* 3400:     */     }
/* 3401:5457 */     if ((supported_extensions.contains("GL_ARB_transform_feedback3")) && (!ARB_transform_feedback3_initNativeFunctionAddresses())) {
/* 3402:5458 */       remove(supported_extensions, "GL_ARB_transform_feedback3");
/* 3403:     */     }
/* 3404:5459 */     if ((supported_extensions.contains("GL_ARB_transform_feedback_instanced")) && (!ARB_transform_feedback_instanced_initNativeFunctionAddresses())) {
/* 3405:5460 */       remove(supported_extensions, "GL_ARB_transform_feedback_instanced");
/* 3406:     */     }
/* 3407:5461 */     if ((supported_extensions.contains("GL_ARB_transpose_matrix")) && (!ARB_transpose_matrix_initNativeFunctionAddresses())) {
/* 3408:5462 */       remove(supported_extensions, "GL_ARB_transpose_matrix");
/* 3409:     */     }
/* 3410:5463 */     if ((supported_extensions.contains("GL_ARB_uniform_buffer_object")) && (!ARB_uniform_buffer_object_initNativeFunctionAddresses())) {
/* 3411:5464 */       remove(supported_extensions, "GL_ARB_uniform_buffer_object");
/* 3412:     */     }
/* 3413:5465 */     if ((supported_extensions.contains("GL_ARB_vertex_array_object")) && (!ARB_vertex_array_object_initNativeFunctionAddresses())) {
/* 3414:5466 */       remove(supported_extensions, "GL_ARB_vertex_array_object");
/* 3415:     */     }
/* 3416:5467 */     if ((supported_extensions.contains("GL_ARB_vertex_attrib_64bit")) && (!ARB_vertex_attrib_64bit_initNativeFunctionAddresses(supported_extensions))) {
/* 3417:5468 */       remove(supported_extensions, "GL_ARB_vertex_attrib_64bit");
/* 3418:     */     }
/* 3419:5469 */     if ((supported_extensions.contains("GL_ARB_vertex_attrib_binding")) && (!ARB_vertex_attrib_binding_initNativeFunctionAddresses())) {
/* 3420:5470 */       remove(supported_extensions, "GL_ARB_vertex_attrib_binding");
/* 3421:     */     }
/* 3422:5471 */     if ((supported_extensions.contains("GL_ARB_vertex_blend")) && (!ARB_vertex_blend_initNativeFunctionAddresses())) {
/* 3423:5472 */       remove(supported_extensions, "GL_ARB_vertex_blend");
/* 3424:     */     }
/* 3425:5473 */     if ((supported_extensions.contains("GL_ARB_vertex_program")) && (!ARB_vertex_program_initNativeFunctionAddresses())) {
/* 3426:5474 */       remove(supported_extensions, "GL_ARB_vertex_program");
/* 3427:     */     }
/* 3428:5475 */     if ((supported_extensions.contains("GL_ARB_vertex_shader")) && (!ARB_vertex_shader_initNativeFunctionAddresses())) {
/* 3429:5476 */       remove(supported_extensions, "GL_ARB_vertex_shader");
/* 3430:     */     }
/* 3431:5477 */     if ((supported_extensions.contains("GL_ARB_vertex_type_2_10_10_10_rev")) && (!ARB_vertex_type_2_10_10_10_rev_initNativeFunctionAddresses())) {
/* 3432:5478 */       remove(supported_extensions, "GL_ARB_vertex_type_2_10_10_10_rev");
/* 3433:     */     }
/* 3434:5479 */     if ((supported_extensions.contains("GL_ARB_viewport_array")) && (!ARB_viewport_array_initNativeFunctionAddresses())) {
/* 3435:5480 */       remove(supported_extensions, "GL_ARB_viewport_array");
/* 3436:     */     }
/* 3437:5481 */     if ((supported_extensions.contains("GL_ARB_window_pos")) && (!ARB_window_pos_initNativeFunctionAddresses(forwardCompatible))) {
/* 3438:5482 */       remove(supported_extensions, "GL_ARB_window_pos");
/* 3439:     */     }
/* 3440:5483 */     if ((supported_extensions.contains("GL_ATI_draw_buffers")) && (!ATI_draw_buffers_initNativeFunctionAddresses())) {
/* 3441:5484 */       remove(supported_extensions, "GL_ATI_draw_buffers");
/* 3442:     */     }
/* 3443:5485 */     if ((supported_extensions.contains("GL_ATI_element_array")) && (!ATI_element_array_initNativeFunctionAddresses())) {
/* 3444:5486 */       remove(supported_extensions, "GL_ATI_element_array");
/* 3445:     */     }
/* 3446:5487 */     if ((supported_extensions.contains("GL_ATI_envmap_bumpmap")) && (!ATI_envmap_bumpmap_initNativeFunctionAddresses())) {
/* 3447:5488 */       remove(supported_extensions, "GL_ATI_envmap_bumpmap");
/* 3448:     */     }
/* 3449:5489 */     if ((supported_extensions.contains("GL_ATI_fragment_shader")) && (!ATI_fragment_shader_initNativeFunctionAddresses())) {
/* 3450:5490 */       remove(supported_extensions, "GL_ATI_fragment_shader");
/* 3451:     */     }
/* 3452:5491 */     if ((supported_extensions.contains("GL_ATI_map_object_buffer")) && (!ATI_map_object_buffer_initNativeFunctionAddresses())) {
/* 3453:5492 */       remove(supported_extensions, "GL_ATI_map_object_buffer");
/* 3454:     */     }
/* 3455:5493 */     if ((supported_extensions.contains("GL_ATI_pn_triangles")) && (!ATI_pn_triangles_initNativeFunctionAddresses())) {
/* 3456:5494 */       remove(supported_extensions, "GL_ATI_pn_triangles");
/* 3457:     */     }
/* 3458:5495 */     if ((supported_extensions.contains("GL_ATI_separate_stencil")) && (!ATI_separate_stencil_initNativeFunctionAddresses())) {
/* 3459:5496 */       remove(supported_extensions, "GL_ATI_separate_stencil");
/* 3460:     */     }
/* 3461:5497 */     if ((supported_extensions.contains("GL_ATI_vertex_array_object")) && (!ATI_vertex_array_object_initNativeFunctionAddresses())) {
/* 3462:5498 */       remove(supported_extensions, "GL_ATI_vertex_array_object");
/* 3463:     */     }
/* 3464:5499 */     if ((supported_extensions.contains("GL_ATI_vertex_attrib_array_object")) && (!ATI_vertex_attrib_array_object_initNativeFunctionAddresses())) {
/* 3465:5500 */       remove(supported_extensions, "GL_ATI_vertex_attrib_array_object");
/* 3466:     */     }
/* 3467:5501 */     if ((supported_extensions.contains("GL_ATI_vertex_streams")) && (!ATI_vertex_streams_initNativeFunctionAddresses())) {
/* 3468:5502 */       remove(supported_extensions, "GL_ATI_vertex_streams");
/* 3469:     */     }
/* 3470:5503 */     if ((supported_extensions.contains("GL_EXT_bindable_uniform")) && (!EXT_bindable_uniform_initNativeFunctionAddresses())) {
/* 3471:5504 */       remove(supported_extensions, "GL_EXT_bindable_uniform");
/* 3472:     */     }
/* 3473:5505 */     if ((supported_extensions.contains("GL_EXT_blend_color")) && (!EXT_blend_color_initNativeFunctionAddresses())) {
/* 3474:5506 */       remove(supported_extensions, "GL_EXT_blend_color");
/* 3475:     */     }
/* 3476:5507 */     if ((supported_extensions.contains("GL_EXT_blend_equation_separate")) && (!EXT_blend_equation_separate_initNativeFunctionAddresses())) {
/* 3477:5508 */       remove(supported_extensions, "GL_EXT_blend_equation_separate");
/* 3478:     */     }
/* 3479:5509 */     if ((supported_extensions.contains("GL_EXT_blend_func_separate")) && (!EXT_blend_func_separate_initNativeFunctionAddresses())) {
/* 3480:5510 */       remove(supported_extensions, "GL_EXT_blend_func_separate");
/* 3481:     */     }
/* 3482:5511 */     if ((supported_extensions.contains("GL_EXT_blend_minmax")) && (!EXT_blend_minmax_initNativeFunctionAddresses())) {
/* 3483:5512 */       remove(supported_extensions, "GL_EXT_blend_minmax");
/* 3484:     */     }
/* 3485:5513 */     if ((supported_extensions.contains("GL_EXT_compiled_vertex_array")) && (!EXT_compiled_vertex_array_initNativeFunctionAddresses())) {
/* 3486:5514 */       remove(supported_extensions, "GL_EXT_compiled_vertex_array");
/* 3487:     */     }
/* 3488:5515 */     if ((supported_extensions.contains("GL_EXT_depth_bounds_test")) && (!EXT_depth_bounds_test_initNativeFunctionAddresses())) {
/* 3489:5516 */       remove(supported_extensions, "GL_EXT_depth_bounds_test");
/* 3490:     */     }
/* 3491:5517 */     supported_extensions.add("GL_EXT_direct_state_access");
/* 3492:5518 */     if ((supported_extensions.contains("GL_EXT_direct_state_access")) && (!EXT_direct_state_access_initNativeFunctionAddresses(forwardCompatible, supported_extensions))) {
/* 3493:5519 */       remove(supported_extensions, "GL_EXT_direct_state_access");
/* 3494:     */     }
/* 3495:5520 */     if ((supported_extensions.contains("GL_EXT_draw_buffers2")) && (!EXT_draw_buffers2_initNativeFunctionAddresses())) {
/* 3496:5521 */       remove(supported_extensions, "GL_EXT_draw_buffers2");
/* 3497:     */     }
/* 3498:5522 */     if ((supported_extensions.contains("GL_EXT_draw_instanced")) && (!EXT_draw_instanced_initNativeFunctionAddresses())) {
/* 3499:5523 */       remove(supported_extensions, "GL_EXT_draw_instanced");
/* 3500:     */     }
/* 3501:5524 */     if ((supported_extensions.contains("GL_EXT_draw_range_elements")) && (!EXT_draw_range_elements_initNativeFunctionAddresses())) {
/* 3502:5525 */       remove(supported_extensions, "GL_EXT_draw_range_elements");
/* 3503:     */     }
/* 3504:5526 */     if ((supported_extensions.contains("GL_EXT_fog_coord")) && (!EXT_fog_coord_initNativeFunctionAddresses())) {
/* 3505:5527 */       remove(supported_extensions, "GL_EXT_fog_coord");
/* 3506:     */     }
/* 3507:5528 */     if ((supported_extensions.contains("GL_EXT_framebuffer_blit")) && (!EXT_framebuffer_blit_initNativeFunctionAddresses())) {
/* 3508:5529 */       remove(supported_extensions, "GL_EXT_framebuffer_blit");
/* 3509:     */     }
/* 3510:5530 */     if ((supported_extensions.contains("GL_EXT_framebuffer_multisample")) && (!EXT_framebuffer_multisample_initNativeFunctionAddresses())) {
/* 3511:5531 */       remove(supported_extensions, "GL_EXT_framebuffer_multisample");
/* 3512:     */     }
/* 3513:5532 */     if ((supported_extensions.contains("GL_EXT_framebuffer_object")) && (!EXT_framebuffer_object_initNativeFunctionAddresses())) {
/* 3514:5533 */       remove(supported_extensions, "GL_EXT_framebuffer_object");
/* 3515:     */     }
/* 3516:5534 */     if ((supported_extensions.contains("GL_EXT_geometry_shader4")) && (!EXT_geometry_shader4_initNativeFunctionAddresses())) {
/* 3517:5535 */       remove(supported_extensions, "GL_EXT_geometry_shader4");
/* 3518:     */     }
/* 3519:5536 */     if ((supported_extensions.contains("GL_EXT_gpu_program_parameters")) && (!EXT_gpu_program_parameters_initNativeFunctionAddresses())) {
/* 3520:5537 */       remove(supported_extensions, "GL_EXT_gpu_program_parameters");
/* 3521:     */     }
/* 3522:5538 */     if ((supported_extensions.contains("GL_EXT_gpu_shader4")) && (!EXT_gpu_shader4_initNativeFunctionAddresses())) {
/* 3523:5539 */       remove(supported_extensions, "GL_EXT_gpu_shader4");
/* 3524:     */     }
/* 3525:5540 */     if ((supported_extensions.contains("GL_EXT_multi_draw_arrays")) && (!EXT_multi_draw_arrays_initNativeFunctionAddresses())) {
/* 3526:5541 */       remove(supported_extensions, "GL_EXT_multi_draw_arrays");
/* 3527:     */     }
/* 3528:5542 */     if ((supported_extensions.contains("GL_EXT_paletted_texture")) && (!EXT_paletted_texture_initNativeFunctionAddresses())) {
/* 3529:5543 */       remove(supported_extensions, "GL_EXT_paletted_texture");
/* 3530:     */     }
/* 3531:5544 */     if ((supported_extensions.contains("GL_EXT_point_parameters")) && (!EXT_point_parameters_initNativeFunctionAddresses())) {
/* 3532:5545 */       remove(supported_extensions, "GL_EXT_point_parameters");
/* 3533:     */     }
/* 3534:5546 */     if ((supported_extensions.contains("GL_EXT_provoking_vertex")) && (!EXT_provoking_vertex_initNativeFunctionAddresses())) {
/* 3535:5547 */       remove(supported_extensions, "GL_EXT_provoking_vertex");
/* 3536:     */     }
/* 3537:5548 */     if ((supported_extensions.contains("GL_EXT_secondary_color")) && (!EXT_secondary_color_initNativeFunctionAddresses())) {
/* 3538:5549 */       remove(supported_extensions, "GL_EXT_secondary_color");
/* 3539:     */     }
/* 3540:5550 */     if ((supported_extensions.contains("GL_EXT_separate_shader_objects")) && (!EXT_separate_shader_objects_initNativeFunctionAddresses())) {
/* 3541:5551 */       remove(supported_extensions, "GL_EXT_separate_shader_objects");
/* 3542:     */     }
/* 3543:5552 */     if ((supported_extensions.contains("GL_EXT_shader_image_load_store")) && (!EXT_shader_image_load_store_initNativeFunctionAddresses())) {
/* 3544:5553 */       remove(supported_extensions, "GL_EXT_shader_image_load_store");
/* 3545:     */     }
/* 3546:5554 */     if ((supported_extensions.contains("GL_EXT_stencil_clear_tag")) && (!EXT_stencil_clear_tag_initNativeFunctionAddresses())) {
/* 3547:5555 */       remove(supported_extensions, "GL_EXT_stencil_clear_tag");
/* 3548:     */     }
/* 3549:5556 */     if ((supported_extensions.contains("GL_EXT_stencil_two_side")) && (!EXT_stencil_two_side_initNativeFunctionAddresses())) {
/* 3550:5557 */       remove(supported_extensions, "GL_EXT_stencil_two_side");
/* 3551:     */     }
/* 3552:5558 */     if ((supported_extensions.contains("GL_EXT_texture_array")) && (!EXT_texture_array_initNativeFunctionAddresses())) {
/* 3553:5559 */       remove(supported_extensions, "GL_EXT_texture_array");
/* 3554:     */     }
/* 3555:5560 */     if ((supported_extensions.contains("GL_EXT_texture_buffer_object")) && (!EXT_texture_buffer_object_initNativeFunctionAddresses())) {
/* 3556:5561 */       remove(supported_extensions, "GL_EXT_texture_buffer_object");
/* 3557:     */     }
/* 3558:5562 */     if ((supported_extensions.contains("GL_EXT_texture_integer")) && (!EXT_texture_integer_initNativeFunctionAddresses())) {
/* 3559:5563 */       remove(supported_extensions, "GL_EXT_texture_integer");
/* 3560:     */     }
/* 3561:5564 */     if ((supported_extensions.contains("GL_EXT_timer_query")) && (!EXT_timer_query_initNativeFunctionAddresses())) {
/* 3562:5565 */       remove(supported_extensions, "GL_EXT_timer_query");
/* 3563:     */     }
/* 3564:5566 */     if ((supported_extensions.contains("GL_EXT_transform_feedback")) && (!EXT_transform_feedback_initNativeFunctionAddresses())) {
/* 3565:5567 */       remove(supported_extensions, "GL_EXT_transform_feedback");
/* 3566:     */     }
/* 3567:5568 */     if ((supported_extensions.contains("GL_EXT_vertex_attrib_64bit")) && (!EXT_vertex_attrib_64bit_initNativeFunctionAddresses(supported_extensions))) {
/* 3568:5569 */       remove(supported_extensions, "GL_EXT_vertex_attrib_64bit");
/* 3569:     */     }
/* 3570:5570 */     if ((supported_extensions.contains("GL_EXT_vertex_shader")) && (!EXT_vertex_shader_initNativeFunctionAddresses())) {
/* 3571:5571 */       remove(supported_extensions, "GL_EXT_vertex_shader");
/* 3572:     */     }
/* 3573:5572 */     if ((supported_extensions.contains("GL_EXT_vertex_weighting")) && (!EXT_vertex_weighting_initNativeFunctionAddresses())) {
/* 3574:5573 */       remove(supported_extensions, "GL_EXT_vertex_weighting");
/* 3575:     */     }
/* 3576:5574 */     if ((supported_extensions.contains("OpenGL12")) && (!GL12_initNativeFunctionAddresses())) {
/* 3577:5575 */       remove(supported_extensions, "OpenGL12");
/* 3578:     */     }
/* 3579:5576 */     if ((supported_extensions.contains("OpenGL13")) && (!GL13_initNativeFunctionAddresses(forwardCompatible))) {
/* 3580:5577 */       remove(supported_extensions, "OpenGL13");
/* 3581:     */     }
/* 3582:5578 */     if ((supported_extensions.contains("OpenGL14")) && (!GL14_initNativeFunctionAddresses(forwardCompatible))) {
/* 3583:5579 */       remove(supported_extensions, "OpenGL14");
/* 3584:     */     }
/* 3585:5580 */     if ((supported_extensions.contains("OpenGL15")) && (!GL15_initNativeFunctionAddresses())) {
/* 3586:5581 */       remove(supported_extensions, "OpenGL15");
/* 3587:     */     }
/* 3588:5582 */     if ((supported_extensions.contains("OpenGL20")) && (!GL20_initNativeFunctionAddresses())) {
/* 3589:5583 */       remove(supported_extensions, "OpenGL20");
/* 3590:     */     }
/* 3591:5584 */     if ((supported_extensions.contains("OpenGL21")) && (!GL21_initNativeFunctionAddresses())) {
/* 3592:5585 */       remove(supported_extensions, "OpenGL21");
/* 3593:     */     }
/* 3594:5586 */     if ((supported_extensions.contains("OpenGL30")) && (!GL30_initNativeFunctionAddresses())) {
/* 3595:5587 */       remove(supported_extensions, "OpenGL30");
/* 3596:     */     }
/* 3597:5588 */     if ((supported_extensions.contains("OpenGL31")) && (!GL31_initNativeFunctionAddresses())) {
/* 3598:5589 */       remove(supported_extensions, "OpenGL31");
/* 3599:     */     }
/* 3600:5590 */     if ((supported_extensions.contains("OpenGL32")) && (!GL32_initNativeFunctionAddresses())) {
/* 3601:5591 */       remove(supported_extensions, "OpenGL32");
/* 3602:     */     }
/* 3603:5592 */     if ((supported_extensions.contains("OpenGL33")) && (!GL33_initNativeFunctionAddresses(forwardCompatible))) {
/* 3604:5593 */       remove(supported_extensions, "OpenGL33");
/* 3605:     */     }
/* 3606:5594 */     if ((supported_extensions.contains("OpenGL40")) && (!GL40_initNativeFunctionAddresses())) {
/* 3607:5595 */       remove(supported_extensions, "OpenGL40");
/* 3608:     */     }
/* 3609:5596 */     if ((supported_extensions.contains("OpenGL41")) && (!GL41_initNativeFunctionAddresses())) {
/* 3610:5597 */       remove(supported_extensions, "OpenGL41");
/* 3611:     */     }
/* 3612:5598 */     if ((supported_extensions.contains("OpenGL42")) && (!GL42_initNativeFunctionAddresses())) {
/* 3613:5599 */       remove(supported_extensions, "OpenGL42");
/* 3614:     */     }
/* 3615:5600 */     if ((supported_extensions.contains("OpenGL43")) && (!GL43_initNativeFunctionAddresses())) {
/* 3616:5601 */       remove(supported_extensions, "OpenGL43");
/* 3617:     */     }
/* 3618:5602 */     if ((supported_extensions.contains("GL_GREMEDY_frame_terminator")) && (!GREMEDY_frame_terminator_initNativeFunctionAddresses())) {
/* 3619:5603 */       remove(supported_extensions, "GL_GREMEDY_frame_terminator");
/* 3620:     */     }
/* 3621:5604 */     if ((supported_extensions.contains("GL_GREMEDY_string_marker")) && (!GREMEDY_string_marker_initNativeFunctionAddresses())) {
/* 3622:5605 */       remove(supported_extensions, "GL_GREMEDY_string_marker");
/* 3623:     */     }
/* 3624:5606 */     if ((supported_extensions.contains("GL_INTEL_map_texture")) && (!INTEL_map_texture_initNativeFunctionAddresses())) {
/* 3625:5607 */       remove(supported_extensions, "GL_INTEL_map_texture");
/* 3626:     */     }
/* 3627:5608 */     if ((supported_extensions.contains("GL_KHR_debug")) && (!KHR_debug_initNativeFunctionAddresses())) {
/* 3628:5609 */       remove(supported_extensions, "GL_KHR_debug");
/* 3629:     */     }
/* 3630:5610 */     if ((supported_extensions.contains("GL_NV_bindless_texture")) && (!NV_bindless_texture_initNativeFunctionAddresses())) {
/* 3631:5611 */       remove(supported_extensions, "GL_NV_bindless_texture");
/* 3632:     */     }
/* 3633:5612 */     if ((supported_extensions.contains("GL_NV_conditional_render")) && (!NV_conditional_render_initNativeFunctionAddresses())) {
/* 3634:5613 */       remove(supported_extensions, "GL_NV_conditional_render");
/* 3635:     */     }
/* 3636:5614 */     if ((supported_extensions.contains("GL_NV_copy_image")) && (!NV_copy_image_initNativeFunctionAddresses())) {
/* 3637:5615 */       remove(supported_extensions, "GL_NV_copy_image");
/* 3638:     */     }
/* 3639:5616 */     if ((supported_extensions.contains("GL_NV_depth_buffer_float")) && (!NV_depth_buffer_float_initNativeFunctionAddresses())) {
/* 3640:5617 */       remove(supported_extensions, "GL_NV_depth_buffer_float");
/* 3641:     */     }
/* 3642:5618 */     if ((supported_extensions.contains("GL_NV_draw_texture")) && (!NV_draw_texture_initNativeFunctionAddresses())) {
/* 3643:5619 */       remove(supported_extensions, "GL_NV_draw_texture");
/* 3644:     */     }
/* 3645:5620 */     if ((supported_extensions.contains("GL_NV_evaluators")) && (!NV_evaluators_initNativeFunctionAddresses())) {
/* 3646:5621 */       remove(supported_extensions, "GL_NV_evaluators");
/* 3647:     */     }
/* 3648:5622 */     if ((supported_extensions.contains("GL_NV_explicit_multisample")) && (!NV_explicit_multisample_initNativeFunctionAddresses())) {
/* 3649:5623 */       remove(supported_extensions, "GL_NV_explicit_multisample");
/* 3650:     */     }
/* 3651:5624 */     if ((supported_extensions.contains("GL_NV_fence")) && (!NV_fence_initNativeFunctionAddresses())) {
/* 3652:5625 */       remove(supported_extensions, "GL_NV_fence");
/* 3653:     */     }
/* 3654:5626 */     if ((supported_extensions.contains("GL_NV_fragment_program")) && (!NV_fragment_program_initNativeFunctionAddresses())) {
/* 3655:5627 */       remove(supported_extensions, "GL_NV_fragment_program");
/* 3656:     */     }
/* 3657:5628 */     if ((supported_extensions.contains("GL_NV_framebuffer_multisample_coverage")) && (!NV_framebuffer_multisample_coverage_initNativeFunctionAddresses())) {
/* 3658:5629 */       remove(supported_extensions, "GL_NV_framebuffer_multisample_coverage");
/* 3659:     */     }
/* 3660:5630 */     if ((supported_extensions.contains("GL_NV_geometry_program4")) && (!NV_geometry_program4_initNativeFunctionAddresses())) {
/* 3661:5631 */       remove(supported_extensions, "GL_NV_geometry_program4");
/* 3662:     */     }
/* 3663:5632 */     if ((supported_extensions.contains("GL_NV_gpu_program4")) && (!NV_gpu_program4_initNativeFunctionAddresses())) {
/* 3664:5633 */       remove(supported_extensions, "GL_NV_gpu_program4");
/* 3665:     */     }
/* 3666:5634 */     if ((supported_extensions.contains("GL_NV_gpu_shader5")) && (!NV_gpu_shader5_initNativeFunctionAddresses(supported_extensions))) {
/* 3667:5635 */       remove(supported_extensions, "GL_NV_gpu_shader5");
/* 3668:     */     }
/* 3669:5636 */     if ((supported_extensions.contains("GL_NV_half_float")) && (!NV_half_float_initNativeFunctionAddresses())) {
/* 3670:5637 */       remove(supported_extensions, "GL_NV_half_float");
/* 3671:     */     }
/* 3672:5638 */     if ((supported_extensions.contains("GL_NV_occlusion_query")) && (!NV_occlusion_query_initNativeFunctionAddresses())) {
/* 3673:5639 */       remove(supported_extensions, "GL_NV_occlusion_query");
/* 3674:     */     }
/* 3675:5640 */     if ((supported_extensions.contains("GL_NV_parameter_buffer_object")) && (!NV_parameter_buffer_object_initNativeFunctionAddresses())) {
/* 3676:5641 */       remove(supported_extensions, "GL_NV_parameter_buffer_object");
/* 3677:     */     }
/* 3678:5642 */     if ((supported_extensions.contains("GL_NV_path_rendering")) && (!NV_path_rendering_initNativeFunctionAddresses())) {
/* 3679:5643 */       remove(supported_extensions, "GL_NV_path_rendering");
/* 3680:     */     }
/* 3681:5644 */     if ((supported_extensions.contains("GL_NV_pixel_data_range")) && (!NV_pixel_data_range_initNativeFunctionAddresses())) {
/* 3682:5645 */       remove(supported_extensions, "GL_NV_pixel_data_range");
/* 3683:     */     }
/* 3684:5646 */     if ((supported_extensions.contains("GL_NV_point_sprite")) && (!NV_point_sprite_initNativeFunctionAddresses())) {
/* 3685:5647 */       remove(supported_extensions, "GL_NV_point_sprite");
/* 3686:     */     }
/* 3687:5648 */     if ((supported_extensions.contains("GL_NV_present_video")) && (!NV_present_video_initNativeFunctionAddresses())) {
/* 3688:5649 */       remove(supported_extensions, "GL_NV_present_video");
/* 3689:     */     }
/* 3690:5650 */     supported_extensions.add("GL_NV_primitive_restart");
/* 3691:5651 */     if ((supported_extensions.contains("GL_NV_primitive_restart")) && (!NV_primitive_restart_initNativeFunctionAddresses())) {
/* 3692:5652 */       remove(supported_extensions, "GL_NV_primitive_restart");
/* 3693:     */     }
/* 3694:5653 */     if ((supported_extensions.contains("GL_NV_program")) && (!NV_program_initNativeFunctionAddresses())) {
/* 3695:5654 */       remove(supported_extensions, "GL_NV_program");
/* 3696:     */     }
/* 3697:5655 */     if ((supported_extensions.contains("GL_NV_register_combiners")) && (!NV_register_combiners_initNativeFunctionAddresses())) {
/* 3698:5656 */       remove(supported_extensions, "GL_NV_register_combiners");
/* 3699:     */     }
/* 3700:5657 */     if ((supported_extensions.contains("GL_NV_register_combiners2")) && (!NV_register_combiners2_initNativeFunctionAddresses())) {
/* 3701:5658 */       remove(supported_extensions, "GL_NV_register_combiners2");
/* 3702:     */     }
/* 3703:5659 */     if ((supported_extensions.contains("GL_NV_shader_buffer_load")) && (!NV_shader_buffer_load_initNativeFunctionAddresses())) {
/* 3704:5660 */       remove(supported_extensions, "GL_NV_shader_buffer_load");
/* 3705:     */     }
/* 3706:5661 */     if ((supported_extensions.contains("GL_NV_texture_barrier")) && (!NV_texture_barrier_initNativeFunctionAddresses())) {
/* 3707:5662 */       remove(supported_extensions, "GL_NV_texture_barrier");
/* 3708:     */     }
/* 3709:5663 */     if ((supported_extensions.contains("GL_NV_texture_multisample")) && (!NV_texture_multisample_initNativeFunctionAddresses())) {
/* 3710:5664 */       remove(supported_extensions, "GL_NV_texture_multisample");
/* 3711:     */     }
/* 3712:5665 */     if ((supported_extensions.contains("GL_NV_transform_feedback")) && (!NV_transform_feedback_initNativeFunctionAddresses())) {
/* 3713:5666 */       remove(supported_extensions, "GL_NV_transform_feedback");
/* 3714:     */     }
/* 3715:5667 */     if ((supported_extensions.contains("GL_NV_transform_feedback2")) && (!NV_transform_feedback2_initNativeFunctionAddresses())) {
/* 3716:5668 */       remove(supported_extensions, "GL_NV_transform_feedback2");
/* 3717:     */     }
/* 3718:5669 */     if ((supported_extensions.contains("GL_NV_vertex_array_range")) && (!NV_vertex_array_range_initNativeFunctionAddresses())) {
/* 3719:5670 */       remove(supported_extensions, "GL_NV_vertex_array_range");
/* 3720:     */     }
/* 3721:5671 */     if ((supported_extensions.contains("GL_NV_vertex_attrib_integer_64bit")) && (!NV_vertex_attrib_integer_64bit_initNativeFunctionAddresses(supported_extensions))) {
/* 3722:5672 */       remove(supported_extensions, "GL_NV_vertex_attrib_integer_64bit");
/* 3723:     */     }
/* 3724:5673 */     if ((supported_extensions.contains("GL_NV_vertex_buffer_unified_memory")) && (!NV_vertex_buffer_unified_memory_initNativeFunctionAddresses())) {
/* 3725:5674 */       remove(supported_extensions, "GL_NV_vertex_buffer_unified_memory");
/* 3726:     */     }
/* 3727:5675 */     if ((supported_extensions.contains("GL_NV_vertex_program")) && (!NV_vertex_program_initNativeFunctionAddresses())) {
/* 3728:5676 */       remove(supported_extensions, "GL_NV_vertex_program");
/* 3729:     */     }
/* 3730:5677 */     if ((supported_extensions.contains("GL_NV_video_capture")) && (!NV_video_capture_initNativeFunctionAddresses())) {
/* 3731:5678 */       remove(supported_extensions, "GL_NV_video_capture");
/* 3732:     */     }
/* 3733:5679 */     return supported_extensions;
/* 3734:     */   }
/* 3735:     */   
/* 3736:     */   static void unloadAllStubs() {}
/* 3737:     */   
/* 3738:     */   ContextCapabilities(boolean forwardCompatible)
/* 3739:     */     throws LWJGLException
/* 3740:     */   {
/* 3741:5686 */     Set<String> supported_extensions = initAllStubs(forwardCompatible);
/* 3742:5687 */     this.GL_AMD_blend_minmax_factor = supported_extensions.contains("GL_AMD_blend_minmax_factor");
/* 3743:5688 */     this.GL_AMD_conservative_depth = supported_extensions.contains("GL_AMD_conservative_depth");
/* 3744:5689 */     this.GL_AMD_debug_output = ((supported_extensions.contains("GL_AMD_debug_output")) || (supported_extensions.contains("GL_AMDX_debug_output")));
/* 3745:     */     
/* 3746:5691 */     this.GL_AMD_depth_clamp_separate = supported_extensions.contains("GL_AMD_depth_clamp_separate");
/* 3747:5692 */     this.GL_AMD_draw_buffers_blend = supported_extensions.contains("GL_AMD_draw_buffers_blend");
/* 3748:5693 */     this.GL_AMD_multi_draw_indirect = supported_extensions.contains("GL_AMD_multi_draw_indirect");
/* 3749:5694 */     this.GL_AMD_name_gen_delete = supported_extensions.contains("GL_AMD_name_gen_delete");
/* 3750:5695 */     this.GL_AMD_performance_monitor = supported_extensions.contains("GL_AMD_performance_monitor");
/* 3751:5696 */     this.GL_AMD_pinned_memory = supported_extensions.contains("GL_AMD_pinned_memory");
/* 3752:5697 */     this.GL_AMD_query_buffer_object = supported_extensions.contains("GL_AMD_query_buffer_object");
/* 3753:5698 */     this.GL_AMD_sample_positions = supported_extensions.contains("GL_AMD_sample_positions");
/* 3754:5699 */     this.GL_AMD_seamless_cubemap_per_texture = supported_extensions.contains("GL_AMD_seamless_cubemap_per_texture");
/* 3755:5700 */     this.GL_AMD_shader_stencil_export = supported_extensions.contains("GL_AMD_shader_stencil_export");
/* 3756:5701 */     this.GL_AMD_shader_trinary_minmax = supported_extensions.contains("GL_AMD_shader_trinary_minmax");
/* 3757:5702 */     this.GL_AMD_sparse_texture = supported_extensions.contains("GL_AMD_sparse_texture");
/* 3758:5703 */     this.GL_AMD_stencil_operation_extended = supported_extensions.contains("GL_AMD_stencil_operation_extended");
/* 3759:5704 */     this.GL_AMD_texture_texture4 = supported_extensions.contains("GL_AMD_texture_texture4");
/* 3760:5705 */     this.GL_AMD_transform_feedback3_lines_triangles = supported_extensions.contains("GL_AMD_transform_feedback3_lines_triangles");
/* 3761:5706 */     this.GL_AMD_vertex_shader_layer = supported_extensions.contains("GL_AMD_vertex_shader_layer");
/* 3762:5707 */     this.GL_AMD_vertex_shader_tessellator = supported_extensions.contains("GL_AMD_vertex_shader_tessellator");
/* 3763:5708 */     this.GL_AMD_vertex_shader_viewport_index = supported_extensions.contains("GL_AMD_vertex_shader_viewport_index");
/* 3764:5709 */     this.GL_APPLE_aux_depth_stencil = supported_extensions.contains("GL_APPLE_aux_depth_stencil");
/* 3765:5710 */     this.GL_APPLE_client_storage = supported_extensions.contains("GL_APPLE_client_storage");
/* 3766:5711 */     this.GL_APPLE_element_array = supported_extensions.contains("GL_APPLE_element_array");
/* 3767:5712 */     this.GL_APPLE_fence = supported_extensions.contains("GL_APPLE_fence");
/* 3768:5713 */     this.GL_APPLE_float_pixels = supported_extensions.contains("GL_APPLE_float_pixels");
/* 3769:5714 */     this.GL_APPLE_flush_buffer_range = supported_extensions.contains("GL_APPLE_flush_buffer_range");
/* 3770:5715 */     this.GL_APPLE_object_purgeable = supported_extensions.contains("GL_APPLE_object_purgeable");
/* 3771:5716 */     this.GL_APPLE_packed_pixels = supported_extensions.contains("GL_APPLE_packed_pixels");
/* 3772:5717 */     this.GL_APPLE_rgb_422 = supported_extensions.contains("GL_APPLE_rgb_422");
/* 3773:5718 */     this.GL_APPLE_row_bytes = supported_extensions.contains("GL_APPLE_row_bytes");
/* 3774:5719 */     this.GL_APPLE_texture_range = supported_extensions.contains("GL_APPLE_texture_range");
/* 3775:5720 */     this.GL_APPLE_vertex_array_object = supported_extensions.contains("GL_APPLE_vertex_array_object");
/* 3776:5721 */     this.GL_APPLE_vertex_array_range = supported_extensions.contains("GL_APPLE_vertex_array_range");
/* 3777:5722 */     this.GL_APPLE_vertex_program_evaluators = supported_extensions.contains("GL_APPLE_vertex_program_evaluators");
/* 3778:5723 */     this.GL_APPLE_ycbcr_422 = supported_extensions.contains("GL_APPLE_ycbcr_422");
/* 3779:5724 */     this.GL_ARB_ES2_compatibility = supported_extensions.contains("GL_ARB_ES2_compatibility");
/* 3780:5725 */     this.GL_ARB_ES3_compatibility = supported_extensions.contains("GL_ARB_ES3_compatibility");
/* 3781:5726 */     this.GL_ARB_arrays_of_arrays = supported_extensions.contains("GL_ARB_arrays_of_arrays");
/* 3782:5727 */     this.GL_ARB_base_instance = supported_extensions.contains("GL_ARB_base_instance");
/* 3783:5728 */     this.GL_ARB_blend_func_extended = supported_extensions.contains("GL_ARB_blend_func_extended");
/* 3784:5729 */     this.GL_ARB_cl_event = supported_extensions.contains("GL_ARB_cl_event");
/* 3785:5730 */     this.GL_ARB_clear_buffer_object = supported_extensions.contains("GL_ARB_clear_buffer_object");
/* 3786:5731 */     this.GL_ARB_color_buffer_float = supported_extensions.contains("GL_ARB_color_buffer_float");
/* 3787:5732 */     this.GL_ARB_compatibility = supported_extensions.contains("GL_ARB_compatibility");
/* 3788:5733 */     this.GL_ARB_compressed_texture_pixel_storage = supported_extensions.contains("GL_ARB_compressed_texture_pixel_storage");
/* 3789:5734 */     this.GL_ARB_compute_shader = supported_extensions.contains("GL_ARB_compute_shader");
/* 3790:5735 */     this.GL_ARB_conservative_depth = supported_extensions.contains("GL_ARB_conservative_depth");
/* 3791:5736 */     this.GL_ARB_copy_buffer = supported_extensions.contains("GL_ARB_copy_buffer");
/* 3792:5737 */     this.GL_ARB_copy_image = supported_extensions.contains("GL_ARB_copy_image");
/* 3793:5738 */     this.GL_ARB_debug_output = supported_extensions.contains("GL_ARB_debug_output");
/* 3794:5739 */     this.GL_ARB_depth_buffer_float = supported_extensions.contains("GL_ARB_depth_buffer_float");
/* 3795:5740 */     this.GL_ARB_depth_clamp = supported_extensions.contains("GL_ARB_depth_clamp");
/* 3796:5741 */     this.GL_ARB_depth_texture = supported_extensions.contains("GL_ARB_depth_texture");
/* 3797:5742 */     this.GL_ARB_draw_buffers = supported_extensions.contains("GL_ARB_draw_buffers");
/* 3798:5743 */     this.GL_ARB_draw_buffers_blend = supported_extensions.contains("GL_ARB_draw_buffers_blend");
/* 3799:5744 */     this.GL_ARB_draw_elements_base_vertex = supported_extensions.contains("GL_ARB_draw_elements_base_vertex");
/* 3800:5745 */     this.GL_ARB_draw_indirect = supported_extensions.contains("GL_ARB_draw_indirect");
/* 3801:5746 */     this.GL_ARB_draw_instanced = supported_extensions.contains("GL_ARB_draw_instanced");
/* 3802:5747 */     this.GL_ARB_explicit_attrib_location = supported_extensions.contains("GL_ARB_explicit_attrib_location");
/* 3803:5748 */     this.GL_ARB_explicit_uniform_location = supported_extensions.contains("GL_ARB_explicit_uniform_location");
/* 3804:5749 */     this.GL_ARB_fragment_coord_conventions = supported_extensions.contains("GL_ARB_fragment_coord_conventions");
/* 3805:5750 */     this.GL_ARB_fragment_layer_viewport = supported_extensions.contains("GL_ARB_fragment_layer_viewport");
/* 3806:5751 */     this.GL_ARB_fragment_program = ((supported_extensions.contains("GL_ARB_fragment_program")) && (supported_extensions.contains("GL_ARB_program")));
/* 3807:     */     
/* 3808:5753 */     this.GL_ARB_fragment_program_shadow = supported_extensions.contains("GL_ARB_fragment_program_shadow");
/* 3809:5754 */     this.GL_ARB_fragment_shader = supported_extensions.contains("GL_ARB_fragment_shader");
/* 3810:5755 */     this.GL_ARB_framebuffer_no_attachments = supported_extensions.contains("GL_ARB_framebuffer_no_attachments");
/* 3811:5756 */     this.GL_ARB_framebuffer_object = supported_extensions.contains("GL_ARB_framebuffer_object");
/* 3812:5757 */     this.GL_ARB_framebuffer_sRGB = supported_extensions.contains("GL_ARB_framebuffer_sRGB");
/* 3813:5758 */     this.GL_ARB_geometry_shader4 = supported_extensions.contains("GL_ARB_geometry_shader4");
/* 3814:5759 */     this.GL_ARB_get_program_binary = supported_extensions.contains("GL_ARB_get_program_binary");
/* 3815:5760 */     this.GL_ARB_gpu_shader5 = supported_extensions.contains("GL_ARB_gpu_shader5");
/* 3816:5761 */     this.GL_ARB_gpu_shader_fp64 = supported_extensions.contains("GL_ARB_gpu_shader_fp64");
/* 3817:5762 */     this.GL_ARB_half_float_pixel = supported_extensions.contains("GL_ARB_half_float_pixel");
/* 3818:5763 */     this.GL_ARB_half_float_vertex = supported_extensions.contains("GL_ARB_half_float_vertex");
/* 3819:5764 */     this.GL_ARB_imaging = supported_extensions.contains("GL_ARB_imaging");
/* 3820:5765 */     this.GL_ARB_instanced_arrays = supported_extensions.contains("GL_ARB_instanced_arrays");
/* 3821:5766 */     this.GL_ARB_internalformat_query = supported_extensions.contains("GL_ARB_internalformat_query");
/* 3822:5767 */     this.GL_ARB_internalformat_query2 = supported_extensions.contains("GL_ARB_internalformat_query2");
/* 3823:5768 */     this.GL_ARB_invalidate_subdata = supported_extensions.contains("GL_ARB_invalidate_subdata");
/* 3824:5769 */     this.GL_ARB_map_buffer_alignment = supported_extensions.contains("GL_ARB_map_buffer_alignment");
/* 3825:5770 */     this.GL_ARB_map_buffer_range = supported_extensions.contains("GL_ARB_map_buffer_range");
/* 3826:5771 */     this.GL_ARB_matrix_palette = supported_extensions.contains("GL_ARB_matrix_palette");
/* 3827:5772 */     this.GL_ARB_multi_draw_indirect = supported_extensions.contains("GL_ARB_multi_draw_indirect");
/* 3828:5773 */     this.GL_ARB_multisample = supported_extensions.contains("GL_ARB_multisample");
/* 3829:5774 */     this.GL_ARB_multitexture = supported_extensions.contains("GL_ARB_multitexture");
/* 3830:5775 */     this.GL_ARB_occlusion_query = supported_extensions.contains("GL_ARB_occlusion_query");
/* 3831:5776 */     this.GL_ARB_occlusion_query2 = supported_extensions.contains("GL_ARB_occlusion_query2");
/* 3832:5777 */     this.GL_ARB_pixel_buffer_object = ((supported_extensions.contains("GL_ARB_pixel_buffer_object")) && (supported_extensions.contains("GL_ARB_buffer_object")));
/* 3833:     */     
/* 3834:5779 */     this.GL_ARB_point_parameters = supported_extensions.contains("GL_ARB_point_parameters");
/* 3835:5780 */     this.GL_ARB_point_sprite = supported_extensions.contains("GL_ARB_point_sprite");
/* 3836:5781 */     this.GL_ARB_program_interface_query = supported_extensions.contains("GL_ARB_program_interface_query");
/* 3837:5782 */     this.GL_ARB_provoking_vertex = supported_extensions.contains("GL_ARB_provoking_vertex");
/* 3838:5783 */     this.GL_ARB_robust_buffer_access_behavior = supported_extensions.contains("GL_ARB_robust_buffer_access_behavior");
/* 3839:5784 */     this.GL_ARB_robustness = supported_extensions.contains("GL_ARB_robustness");
/* 3840:5785 */     this.GL_ARB_robustness_isolation = supported_extensions.contains("GL_ARB_robustness_isolation");
/* 3841:5786 */     this.GL_ARB_sample_shading = supported_extensions.contains("GL_ARB_sample_shading");
/* 3842:5787 */     this.GL_ARB_sampler_objects = supported_extensions.contains("GL_ARB_sampler_objects");
/* 3843:5788 */     this.GL_ARB_seamless_cube_map = supported_extensions.contains("GL_ARB_seamless_cube_map");
/* 3844:5789 */     this.GL_ARB_separate_shader_objects = supported_extensions.contains("GL_ARB_separate_shader_objects");
/* 3845:5790 */     this.GL_ARB_shader_atomic_counters = supported_extensions.contains("GL_ARB_shader_atomic_counters");
/* 3846:5791 */     this.GL_ARB_shader_bit_encoding = supported_extensions.contains("GL_ARB_shader_bit_encoding");
/* 3847:5792 */     this.GL_ARB_shader_image_load_store = supported_extensions.contains("GL_ARB_shader_image_load_store");
/* 3848:5793 */     this.GL_ARB_shader_image_size = supported_extensions.contains("GL_ARB_shader_image_size");
/* 3849:5794 */     this.GL_ARB_shader_objects = supported_extensions.contains("GL_ARB_shader_objects");
/* 3850:5795 */     this.GL_ARB_shader_precision = supported_extensions.contains("GL_ARB_shader_precision");
/* 3851:5796 */     this.GL_ARB_shader_stencil_export = supported_extensions.contains("GL_ARB_shader_stencil_export");
/* 3852:5797 */     this.GL_ARB_shader_storage_buffer_object = supported_extensions.contains("GL_ARB_shader_storage_buffer_object");
/* 3853:5798 */     this.GL_ARB_shader_subroutine = supported_extensions.contains("GL_ARB_shader_subroutine");
/* 3854:5799 */     this.GL_ARB_shader_texture_lod = supported_extensions.contains("GL_ARB_shader_texture_lod");
/* 3855:5800 */     this.GL_ARB_shading_language_100 = supported_extensions.contains("GL_ARB_shading_language_100");
/* 3856:5801 */     this.GL_ARB_shading_language_420pack = supported_extensions.contains("GL_ARB_shading_language_420pack");
/* 3857:5802 */     this.GL_ARB_shading_language_include = supported_extensions.contains("GL_ARB_shading_language_include");
/* 3858:5803 */     this.GL_ARB_shading_language_packing = supported_extensions.contains("GL_ARB_shading_language_packing");
/* 3859:5804 */     this.GL_ARB_shadow = supported_extensions.contains("GL_ARB_shadow");
/* 3860:5805 */     this.GL_ARB_shadow_ambient = supported_extensions.contains("GL_ARB_shadow_ambient");
/* 3861:5806 */     this.GL_ARB_stencil_texturing = supported_extensions.contains("GL_ARB_stencil_texturing");
/* 3862:5807 */     this.GL_ARB_sync = supported_extensions.contains("GL_ARB_sync");
/* 3863:5808 */     this.GL_ARB_tessellation_shader = supported_extensions.contains("GL_ARB_tessellation_shader");
/* 3864:5809 */     this.GL_ARB_texture_border_clamp = supported_extensions.contains("GL_ARB_texture_border_clamp");
/* 3865:5810 */     this.GL_ARB_texture_buffer_object = supported_extensions.contains("GL_ARB_texture_buffer_object");
/* 3866:5811 */     this.GL_ARB_texture_buffer_object_rgb32 = ((supported_extensions.contains("GL_ARB_texture_buffer_object_rgb32")) || (supported_extensions.contains("GL_EXT_texture_buffer_object_rgb32")));
/* 3867:     */     
/* 3868:5813 */     this.GL_ARB_texture_buffer_range = supported_extensions.contains("GL_ARB_texture_buffer_range");
/* 3869:5814 */     this.GL_ARB_texture_compression = supported_extensions.contains("GL_ARB_texture_compression");
/* 3870:5815 */     this.GL_ARB_texture_compression_bptc = ((supported_extensions.contains("GL_ARB_texture_compression_bptc")) || (supported_extensions.contains("GL_EXT_texture_compression_bptc")));
/* 3871:     */     
/* 3872:5817 */     this.GL_ARB_texture_compression_rgtc = supported_extensions.contains("GL_ARB_texture_compression_rgtc");
/* 3873:5818 */     this.GL_ARB_texture_cube_map = supported_extensions.contains("GL_ARB_texture_cube_map");
/* 3874:5819 */     this.GL_ARB_texture_cube_map_array = supported_extensions.contains("GL_ARB_texture_cube_map_array");
/* 3875:5820 */     this.GL_ARB_texture_env_add = supported_extensions.contains("GL_ARB_texture_env_add");
/* 3876:5821 */     this.GL_ARB_texture_env_combine = supported_extensions.contains("GL_ARB_texture_env_combine");
/* 3877:5822 */     this.GL_ARB_texture_env_crossbar = supported_extensions.contains("GL_ARB_texture_env_crossbar");
/* 3878:5823 */     this.GL_ARB_texture_env_dot3 = supported_extensions.contains("GL_ARB_texture_env_dot3");
/* 3879:5824 */     this.GL_ARB_texture_float = supported_extensions.contains("GL_ARB_texture_float");
/* 3880:5825 */     this.GL_ARB_texture_gather = supported_extensions.contains("GL_ARB_texture_gather");
/* 3881:5826 */     this.GL_ARB_texture_mirrored_repeat = supported_extensions.contains("GL_ARB_texture_mirrored_repeat");
/* 3882:5827 */     this.GL_ARB_texture_multisample = supported_extensions.contains("GL_ARB_texture_multisample");
/* 3883:5828 */     this.GL_ARB_texture_non_power_of_two = supported_extensions.contains("GL_ARB_texture_non_power_of_two");
/* 3884:5829 */     this.GL_ARB_texture_query_levels = supported_extensions.contains("GL_ARB_texture_query_levels");
/* 3885:5830 */     this.GL_ARB_texture_query_lod = supported_extensions.contains("GL_ARB_texture_query_lod");
/* 3886:5831 */     this.GL_ARB_texture_rectangle = supported_extensions.contains("GL_ARB_texture_rectangle");
/* 3887:5832 */     this.GL_ARB_texture_rg = supported_extensions.contains("GL_ARB_texture_rg");
/* 3888:5833 */     this.GL_ARB_texture_rgb10_a2ui = supported_extensions.contains("GL_ARB_texture_rgb10_a2ui");
/* 3889:5834 */     this.GL_ARB_texture_storage = ((supported_extensions.contains("GL_ARB_texture_storage")) || (supported_extensions.contains("GL_EXT_texture_storage")));
/* 3890:     */     
/* 3891:5836 */     this.GL_ARB_texture_storage_multisample = supported_extensions.contains("GL_ARB_texture_storage_multisample");
/* 3892:5837 */     this.GL_ARB_texture_swizzle = supported_extensions.contains("GL_ARB_texture_swizzle");
/* 3893:5838 */     this.GL_ARB_texture_view = supported_extensions.contains("GL_ARB_texture_view");
/* 3894:5839 */     this.GL_ARB_timer_query = supported_extensions.contains("GL_ARB_timer_query");
/* 3895:5840 */     this.GL_ARB_transform_feedback2 = supported_extensions.contains("GL_ARB_transform_feedback2");
/* 3896:5841 */     this.GL_ARB_transform_feedback3 = supported_extensions.contains("GL_ARB_transform_feedback3");
/* 3897:5842 */     this.GL_ARB_transform_feedback_instanced = supported_extensions.contains("GL_ARB_transform_feedback_instanced");
/* 3898:5843 */     this.GL_ARB_transpose_matrix = supported_extensions.contains("GL_ARB_transpose_matrix");
/* 3899:5844 */     this.GL_ARB_uniform_buffer_object = supported_extensions.contains("GL_ARB_uniform_buffer_object");
/* 3900:5845 */     this.GL_ARB_vertex_array_bgra = supported_extensions.contains("GL_ARB_vertex_array_bgra");
/* 3901:5846 */     this.GL_ARB_vertex_array_object = supported_extensions.contains("GL_ARB_vertex_array_object");
/* 3902:5847 */     this.GL_ARB_vertex_attrib_64bit = supported_extensions.contains("GL_ARB_vertex_attrib_64bit");
/* 3903:5848 */     this.GL_ARB_vertex_attrib_binding = supported_extensions.contains("GL_ARB_vertex_attrib_binding");
/* 3904:5849 */     this.GL_ARB_vertex_blend = supported_extensions.contains("GL_ARB_vertex_blend");
/* 3905:5850 */     this.GL_ARB_vertex_buffer_object = ((supported_extensions.contains("GL_ARB_vertex_buffer_object")) && (supported_extensions.contains("GL_ARB_buffer_object")));
/* 3906:     */     
/* 3907:5852 */     this.GL_ARB_vertex_program = ((supported_extensions.contains("GL_ARB_vertex_program")) && (supported_extensions.contains("GL_ARB_program")));
/* 3908:     */     
/* 3909:5854 */     this.GL_ARB_vertex_shader = supported_extensions.contains("GL_ARB_vertex_shader");
/* 3910:5855 */     this.GL_ARB_vertex_type_2_10_10_10_rev = supported_extensions.contains("GL_ARB_vertex_type_2_10_10_10_rev");
/* 3911:5856 */     this.GL_ARB_viewport_array = supported_extensions.contains("GL_ARB_viewport_array");
/* 3912:5857 */     this.GL_ARB_window_pos = supported_extensions.contains("GL_ARB_window_pos");
/* 3913:5858 */     this.GL_ATI_draw_buffers = supported_extensions.contains("GL_ATI_draw_buffers");
/* 3914:5859 */     this.GL_ATI_element_array = supported_extensions.contains("GL_ATI_element_array");
/* 3915:5860 */     this.GL_ATI_envmap_bumpmap = supported_extensions.contains("GL_ATI_envmap_bumpmap");
/* 3916:5861 */     this.GL_ATI_fragment_shader = supported_extensions.contains("GL_ATI_fragment_shader");
/* 3917:5862 */     this.GL_ATI_map_object_buffer = supported_extensions.contains("GL_ATI_map_object_buffer");
/* 3918:5863 */     this.GL_ATI_meminfo = supported_extensions.contains("GL_ATI_meminfo");
/* 3919:5864 */     this.GL_ATI_pn_triangles = supported_extensions.contains("GL_ATI_pn_triangles");
/* 3920:5865 */     this.GL_ATI_separate_stencil = supported_extensions.contains("GL_ATI_separate_stencil");
/* 3921:5866 */     this.GL_ATI_shader_texture_lod = supported_extensions.contains("GL_ATI_shader_texture_lod");
/* 3922:5867 */     this.GL_ATI_text_fragment_shader = supported_extensions.contains("GL_ATI_text_fragment_shader");
/* 3923:5868 */     this.GL_ATI_texture_compression_3dc = supported_extensions.contains("GL_ATI_texture_compression_3dc");
/* 3924:5869 */     this.GL_ATI_texture_env_combine3 = supported_extensions.contains("GL_ATI_texture_env_combine3");
/* 3925:5870 */     this.GL_ATI_texture_float = supported_extensions.contains("GL_ATI_texture_float");
/* 3926:5871 */     this.GL_ATI_texture_mirror_once = supported_extensions.contains("GL_ATI_texture_mirror_once");
/* 3927:5872 */     this.GL_ATI_vertex_array_object = supported_extensions.contains("GL_ATI_vertex_array_object");
/* 3928:5873 */     this.GL_ATI_vertex_attrib_array_object = supported_extensions.contains("GL_ATI_vertex_attrib_array_object");
/* 3929:5874 */     this.GL_ATI_vertex_streams = supported_extensions.contains("GL_ATI_vertex_streams");
/* 3930:5875 */     this.GL_EXT_abgr = supported_extensions.contains("GL_EXT_abgr");
/* 3931:5876 */     this.GL_EXT_bgra = supported_extensions.contains("GL_EXT_bgra");
/* 3932:5877 */     this.GL_EXT_bindable_uniform = supported_extensions.contains("GL_EXT_bindable_uniform");
/* 3933:5878 */     this.GL_EXT_blend_color = supported_extensions.contains("GL_EXT_blend_color");
/* 3934:5879 */     this.GL_EXT_blend_equation_separate = supported_extensions.contains("GL_EXT_blend_equation_separate");
/* 3935:5880 */     this.GL_EXT_blend_func_separate = supported_extensions.contains("GL_EXT_blend_func_separate");
/* 3936:5881 */     this.GL_EXT_blend_minmax = supported_extensions.contains("GL_EXT_blend_minmax");
/* 3937:5882 */     this.GL_EXT_blend_subtract = supported_extensions.contains("GL_EXT_blend_subtract");
/* 3938:5883 */     this.GL_EXT_Cg_shader = supported_extensions.contains("GL_EXT_Cg_shader");
/* 3939:5884 */     this.GL_EXT_compiled_vertex_array = supported_extensions.contains("GL_EXT_compiled_vertex_array");
/* 3940:5885 */     this.GL_EXT_depth_bounds_test = supported_extensions.contains("GL_EXT_depth_bounds_test");
/* 3941:5886 */     this.GL_EXT_direct_state_access = supported_extensions.contains("GL_EXT_direct_state_access");
/* 3942:5887 */     this.GL_EXT_draw_buffers2 = supported_extensions.contains("GL_EXT_draw_buffers2");
/* 3943:5888 */     this.GL_EXT_draw_instanced = supported_extensions.contains("GL_EXT_draw_instanced");
/* 3944:5889 */     this.GL_EXT_draw_range_elements = supported_extensions.contains("GL_EXT_draw_range_elements");
/* 3945:5890 */     this.GL_EXT_fog_coord = supported_extensions.contains("GL_EXT_fog_coord");
/* 3946:5891 */     this.GL_EXT_framebuffer_blit = supported_extensions.contains("GL_EXT_framebuffer_blit");
/* 3947:5892 */     this.GL_EXT_framebuffer_multisample = supported_extensions.contains("GL_EXT_framebuffer_multisample");
/* 3948:5893 */     this.GL_EXT_framebuffer_multisample_blit_scaled = supported_extensions.contains("GL_EXT_framebuffer_multisample_blit_scaled");
/* 3949:5894 */     this.GL_EXT_framebuffer_object = supported_extensions.contains("GL_EXT_framebuffer_object");
/* 3950:5895 */     this.GL_EXT_framebuffer_sRGB = supported_extensions.contains("GL_EXT_framebuffer_sRGB");
/* 3951:5896 */     this.GL_EXT_geometry_shader4 = supported_extensions.contains("GL_EXT_geometry_shader4");
/* 3952:5897 */     this.GL_EXT_gpu_program_parameters = supported_extensions.contains("GL_EXT_gpu_program_parameters");
/* 3953:5898 */     this.GL_EXT_gpu_shader4 = supported_extensions.contains("GL_EXT_gpu_shader4");
/* 3954:5899 */     this.GL_EXT_multi_draw_arrays = supported_extensions.contains("GL_EXT_multi_draw_arrays");
/* 3955:5900 */     this.GL_EXT_packed_depth_stencil = supported_extensions.contains("GL_EXT_packed_depth_stencil");
/* 3956:5901 */     this.GL_EXT_packed_float = supported_extensions.contains("GL_EXT_packed_float");
/* 3957:5902 */     this.GL_EXT_packed_pixels = supported_extensions.contains("GL_EXT_packed_pixels");
/* 3958:5903 */     this.GL_EXT_paletted_texture = supported_extensions.contains("GL_EXT_paletted_texture");
/* 3959:5904 */     this.GL_EXT_pixel_buffer_object = ((supported_extensions.contains("GL_EXT_pixel_buffer_object")) && (supported_extensions.contains("GL_ARB_buffer_object")));
/* 3960:     */     
/* 3961:5906 */     this.GL_EXT_point_parameters = supported_extensions.contains("GL_EXT_point_parameters");
/* 3962:5907 */     this.GL_EXT_provoking_vertex = supported_extensions.contains("GL_EXT_provoking_vertex");
/* 3963:5908 */     this.GL_EXT_rescale_normal = supported_extensions.contains("GL_EXT_rescale_normal");
/* 3964:5909 */     this.GL_EXT_secondary_color = supported_extensions.contains("GL_EXT_secondary_color");
/* 3965:5910 */     this.GL_EXT_separate_shader_objects = supported_extensions.contains("GL_EXT_separate_shader_objects");
/* 3966:5911 */     this.GL_EXT_separate_specular_color = supported_extensions.contains("GL_EXT_separate_specular_color");
/* 3967:5912 */     this.GL_EXT_shader_image_load_store = supported_extensions.contains("GL_EXT_shader_image_load_store");
/* 3968:5913 */     this.GL_EXT_shadow_funcs = supported_extensions.contains("GL_EXT_shadow_funcs");
/* 3969:5914 */     this.GL_EXT_shared_texture_palette = supported_extensions.contains("GL_EXT_shared_texture_palette");
/* 3970:5915 */     this.GL_EXT_stencil_clear_tag = supported_extensions.contains("GL_EXT_stencil_clear_tag");
/* 3971:5916 */     this.GL_EXT_stencil_two_side = supported_extensions.contains("GL_EXT_stencil_two_side");
/* 3972:5917 */     this.GL_EXT_stencil_wrap = supported_extensions.contains("GL_EXT_stencil_wrap");
/* 3973:5918 */     this.GL_EXT_texture_3d = supported_extensions.contains("GL_EXT_texture_3d");
/* 3974:5919 */     this.GL_EXT_texture_array = supported_extensions.contains("GL_EXT_texture_array");
/* 3975:5920 */     this.GL_EXT_texture_buffer_object = supported_extensions.contains("GL_EXT_texture_buffer_object");
/* 3976:5921 */     this.GL_EXT_texture_compression_latc = supported_extensions.contains("GL_EXT_texture_compression_latc");
/* 3977:5922 */     this.GL_EXT_texture_compression_rgtc = supported_extensions.contains("GL_EXT_texture_compression_rgtc");
/* 3978:5923 */     this.GL_EXT_texture_compression_s3tc = supported_extensions.contains("GL_EXT_texture_compression_s3tc");
/* 3979:5924 */     this.GL_EXT_texture_env_combine = supported_extensions.contains("GL_EXT_texture_env_combine");
/* 3980:5925 */     this.GL_EXT_texture_env_dot3 = supported_extensions.contains("GL_EXT_texture_env_dot3");
/* 3981:5926 */     this.GL_EXT_texture_filter_anisotropic = supported_extensions.contains("GL_EXT_texture_filter_anisotropic");
/* 3982:5927 */     this.GL_EXT_texture_integer = supported_extensions.contains("GL_EXT_texture_integer");
/* 3983:5928 */     this.GL_EXT_texture_lod_bias = supported_extensions.contains("GL_EXT_texture_lod_bias");
/* 3984:5929 */     this.GL_EXT_texture_mirror_clamp = supported_extensions.contains("GL_EXT_texture_mirror_clamp");
/* 3985:5930 */     this.GL_EXT_texture_rectangle = supported_extensions.contains("GL_EXT_texture_rectangle");
/* 3986:5931 */     this.GL_EXT_texture_sRGB = supported_extensions.contains("GL_EXT_texture_sRGB");
/* 3987:5932 */     this.GL_EXT_texture_sRGB_decode = supported_extensions.contains("GL_EXT_texture_sRGB_decode");
/* 3988:5933 */     this.GL_EXT_texture_shared_exponent = supported_extensions.contains("GL_EXT_texture_shared_exponent");
/* 3989:5934 */     this.GL_EXT_texture_snorm = supported_extensions.contains("GL_EXT_texture_snorm");
/* 3990:5935 */     this.GL_EXT_texture_swizzle = supported_extensions.contains("GL_EXT_texture_swizzle");
/* 3991:5936 */     this.GL_EXT_timer_query = supported_extensions.contains("GL_EXT_timer_query");
/* 3992:5937 */     this.GL_EXT_transform_feedback = supported_extensions.contains("GL_EXT_transform_feedback");
/* 3993:5938 */     this.GL_EXT_vertex_array_bgra = supported_extensions.contains("GL_EXT_vertex_array_bgra");
/* 3994:5939 */     this.GL_EXT_vertex_attrib_64bit = supported_extensions.contains("GL_EXT_vertex_attrib_64bit");
/* 3995:5940 */     this.GL_EXT_vertex_shader = supported_extensions.contains("GL_EXT_vertex_shader");
/* 3996:5941 */     this.GL_EXT_vertex_weighting = supported_extensions.contains("GL_EXT_vertex_weighting");
/* 3997:5942 */     this.OpenGL11 = supported_extensions.contains("OpenGL11");
/* 3998:5943 */     this.OpenGL12 = supported_extensions.contains("OpenGL12");
/* 3999:5944 */     this.OpenGL13 = supported_extensions.contains("OpenGL13");
/* 4000:5945 */     this.OpenGL14 = supported_extensions.contains("OpenGL14");
/* 4001:5946 */     this.OpenGL15 = supported_extensions.contains("OpenGL15");
/* 4002:5947 */     this.OpenGL20 = supported_extensions.contains("OpenGL20");
/* 4003:5948 */     this.OpenGL21 = supported_extensions.contains("OpenGL21");
/* 4004:5949 */     this.OpenGL30 = supported_extensions.contains("OpenGL30");
/* 4005:5950 */     this.OpenGL31 = supported_extensions.contains("OpenGL31");
/* 4006:5951 */     this.OpenGL32 = supported_extensions.contains("OpenGL32");
/* 4007:5952 */     this.OpenGL33 = supported_extensions.contains("OpenGL33");
/* 4008:5953 */     this.OpenGL40 = supported_extensions.contains("OpenGL40");
/* 4009:5954 */     this.OpenGL41 = supported_extensions.contains("OpenGL41");
/* 4010:5955 */     this.OpenGL42 = supported_extensions.contains("OpenGL42");
/* 4011:5956 */     this.OpenGL43 = supported_extensions.contains("OpenGL43");
/* 4012:5957 */     this.GL_GREMEDY_frame_terminator = supported_extensions.contains("GL_GREMEDY_frame_terminator");
/* 4013:5958 */     this.GL_GREMEDY_string_marker = supported_extensions.contains("GL_GREMEDY_string_marker");
/* 4014:5959 */     this.GL_HP_occlusion_test = supported_extensions.contains("GL_HP_occlusion_test");
/* 4015:5960 */     this.GL_IBM_rasterpos_clip = supported_extensions.contains("GL_IBM_rasterpos_clip");
/* 4016:5961 */     this.GL_INTEL_map_texture = supported_extensions.contains("GL_INTEL_map_texture");
/* 4017:5962 */     this.GL_KHR_debug = supported_extensions.contains("GL_KHR_debug");
/* 4018:5963 */     this.GL_KHR_texture_compression_astc_ldr = supported_extensions.contains("GL_KHR_texture_compression_astc_ldr");
/* 4019:5964 */     this.GL_NVX_gpu_memory_info = supported_extensions.contains("GL_NVX_gpu_memory_info");
/* 4020:5965 */     this.GL_NV_bindless_texture = supported_extensions.contains("GL_NV_bindless_texture");
/* 4021:5966 */     this.GL_NV_blend_square = supported_extensions.contains("GL_NV_blend_square");
/* 4022:5967 */     this.GL_NV_compute_program5 = supported_extensions.contains("GL_NV_compute_program5");
/* 4023:5968 */     this.GL_NV_conditional_render = supported_extensions.contains("GL_NV_conditional_render");
/* 4024:5969 */     this.GL_NV_copy_depth_to_color = supported_extensions.contains("GL_NV_copy_depth_to_color");
/* 4025:5970 */     this.GL_NV_copy_image = supported_extensions.contains("GL_NV_copy_image");
/* 4026:5971 */     this.GL_NV_deep_texture3D = supported_extensions.contains("GL_NV_deep_texture3D");
/* 4027:5972 */     this.GL_NV_depth_buffer_float = supported_extensions.contains("GL_NV_depth_buffer_float");
/* 4028:5973 */     this.GL_NV_depth_clamp = supported_extensions.contains("GL_NV_depth_clamp");
/* 4029:5974 */     this.GL_NV_draw_texture = supported_extensions.contains("GL_NV_draw_texture");
/* 4030:5975 */     this.GL_NV_evaluators = supported_extensions.contains("GL_NV_evaluators");
/* 4031:5976 */     this.GL_NV_explicit_multisample = supported_extensions.contains("GL_NV_explicit_multisample");
/* 4032:5977 */     this.GL_NV_fence = supported_extensions.contains("GL_NV_fence");
/* 4033:5978 */     this.GL_NV_float_buffer = supported_extensions.contains("GL_NV_float_buffer");
/* 4034:5979 */     this.GL_NV_fog_distance = supported_extensions.contains("GL_NV_fog_distance");
/* 4035:5980 */     this.GL_NV_fragment_program = ((supported_extensions.contains("GL_NV_fragment_program")) && (supported_extensions.contains("GL_NV_program")));
/* 4036:     */     
/* 4037:5982 */     this.GL_NV_fragment_program2 = supported_extensions.contains("GL_NV_fragment_program2");
/* 4038:5983 */     this.GL_NV_fragment_program4 = supported_extensions.contains("GL_NV_fragment_program4");
/* 4039:5984 */     this.GL_NV_fragment_program_option = supported_extensions.contains("GL_NV_fragment_program_option");
/* 4040:5985 */     this.GL_NV_framebuffer_multisample_coverage = supported_extensions.contains("GL_NV_framebuffer_multisample_coverage");
/* 4041:5986 */     this.GL_NV_geometry_program4 = supported_extensions.contains("GL_NV_geometry_program4");
/* 4042:5987 */     this.GL_NV_geometry_shader4 = supported_extensions.contains("GL_NV_geometry_shader4");
/* 4043:5988 */     this.GL_NV_gpu_program4 = supported_extensions.contains("GL_NV_gpu_program4");
/* 4044:5989 */     this.GL_NV_gpu_program5 = supported_extensions.contains("GL_NV_gpu_program5");
/* 4045:5990 */     this.GL_NV_gpu_shader5 = supported_extensions.contains("GL_NV_gpu_shader5");
/* 4046:5991 */     this.GL_NV_half_float = supported_extensions.contains("GL_NV_half_float");
/* 4047:5992 */     this.GL_NV_light_max_exponent = supported_extensions.contains("GL_NV_light_max_exponent");
/* 4048:5993 */     this.GL_NV_multisample_coverage = supported_extensions.contains("GL_NV_multisample_coverage");
/* 4049:5994 */     this.GL_NV_multisample_filter_hint = supported_extensions.contains("GL_NV_multisample_filter_hint");
/* 4050:5995 */     this.GL_NV_occlusion_query = supported_extensions.contains("GL_NV_occlusion_query");
/* 4051:5996 */     this.GL_NV_packed_depth_stencil = supported_extensions.contains("GL_NV_packed_depth_stencil");
/* 4052:5997 */     this.GL_NV_parameter_buffer_object = supported_extensions.contains("GL_NV_parameter_buffer_object");
/* 4053:5998 */     this.GL_NV_parameter_buffer_object2 = supported_extensions.contains("GL_NV_parameter_buffer_object2");
/* 4054:5999 */     this.GL_NV_path_rendering = supported_extensions.contains("GL_NV_path_rendering");
/* 4055:6000 */     this.GL_NV_pixel_data_range = supported_extensions.contains("GL_NV_pixel_data_range");
/* 4056:6001 */     this.GL_NV_point_sprite = supported_extensions.contains("GL_NV_point_sprite");
/* 4057:6002 */     this.GL_NV_present_video = supported_extensions.contains("GL_NV_present_video");
/* 4058:6003 */     this.GL_NV_primitive_restart = supported_extensions.contains("GL_NV_primitive_restart");
/* 4059:6004 */     this.GL_NV_register_combiners = supported_extensions.contains("GL_NV_register_combiners");
/* 4060:6005 */     this.GL_NV_register_combiners2 = supported_extensions.contains("GL_NV_register_combiners2");
/* 4061:6006 */     this.GL_NV_shader_atomic_counters = supported_extensions.contains("GL_NV_shader_atomic_counters");
/* 4062:6007 */     this.GL_NV_shader_atomic_float = supported_extensions.contains("GL_NV_shader_atomic_float");
/* 4063:6008 */     this.GL_NV_shader_buffer_load = supported_extensions.contains("GL_NV_shader_buffer_load");
/* 4064:6009 */     this.GL_NV_shader_buffer_store = supported_extensions.contains("GL_NV_shader_buffer_store");
/* 4065:6010 */     this.GL_NV_shader_storage_buffer_object = supported_extensions.contains("GL_NV_shader_storage_buffer_object");
/* 4066:6011 */     this.GL_NV_tessellation_program5 = supported_extensions.contains("GL_NV_tessellation_program5");
/* 4067:6012 */     this.GL_NV_texgen_reflection = supported_extensions.contains("GL_NV_texgen_reflection");
/* 4068:6013 */     this.GL_NV_texture_barrier = supported_extensions.contains("GL_NV_texture_barrier");
/* 4069:6014 */     this.GL_NV_texture_compression_vtc = supported_extensions.contains("GL_NV_texture_compression_vtc");
/* 4070:6015 */     this.GL_NV_texture_env_combine4 = supported_extensions.contains("GL_NV_texture_env_combine4");
/* 4071:6016 */     this.GL_NV_texture_expand_normal = supported_extensions.contains("GL_NV_texture_expand_normal");
/* 4072:6017 */     this.GL_NV_texture_multisample = supported_extensions.contains("GL_NV_texture_multisample");
/* 4073:6018 */     this.GL_NV_texture_rectangle = supported_extensions.contains("GL_NV_texture_rectangle");
/* 4074:6019 */     this.GL_NV_texture_shader = supported_extensions.contains("GL_NV_texture_shader");
/* 4075:6020 */     this.GL_NV_texture_shader2 = supported_extensions.contains("GL_NV_texture_shader2");
/* 4076:6021 */     this.GL_NV_texture_shader3 = supported_extensions.contains("GL_NV_texture_shader3");
/* 4077:6022 */     this.GL_NV_transform_feedback = supported_extensions.contains("GL_NV_transform_feedback");
/* 4078:6023 */     this.GL_NV_transform_feedback2 = supported_extensions.contains("GL_NV_transform_feedback2");
/* 4079:6024 */     this.GL_NV_vertex_array_range = supported_extensions.contains("GL_NV_vertex_array_range");
/* 4080:6025 */     this.GL_NV_vertex_array_range2 = supported_extensions.contains("GL_NV_vertex_array_range2");
/* 4081:6026 */     this.GL_NV_vertex_attrib_integer_64bit = supported_extensions.contains("GL_NV_vertex_attrib_integer_64bit");
/* 4082:6027 */     this.GL_NV_vertex_buffer_unified_memory = supported_extensions.contains("GL_NV_vertex_buffer_unified_memory");
/* 4083:6028 */     this.GL_NV_vertex_program = ((supported_extensions.contains("GL_NV_vertex_program")) && (supported_extensions.contains("GL_NV_program")));
/* 4084:     */     
/* 4085:6030 */     this.GL_NV_vertex_program1_1 = supported_extensions.contains("GL_NV_vertex_program1_1");
/* 4086:6031 */     this.GL_NV_vertex_program2 = supported_extensions.contains("GL_NV_vertex_program2");
/* 4087:6032 */     this.GL_NV_vertex_program2_option = supported_extensions.contains("GL_NV_vertex_program2_option");
/* 4088:6033 */     this.GL_NV_vertex_program3 = supported_extensions.contains("GL_NV_vertex_program3");
/* 4089:6034 */     this.GL_NV_vertex_program4 = supported_extensions.contains("GL_NV_vertex_program4");
/* 4090:6035 */     this.GL_NV_video_capture = supported_extensions.contains("GL_NV_video_capture");
/* 4091:6036 */     this.GL_SGIS_generate_mipmap = supported_extensions.contains("GL_SGIS_generate_mipmap");
/* 4092:6037 */     this.GL_SGIS_texture_lod = supported_extensions.contains("GL_SGIS_texture_lod");
/* 4093:6038 */     this.GL_SUN_slice_accum = supported_extensions.contains("GL_SUN_slice_accum");
/* 4094:6039 */     this.tracker.init();
/* 4095:     */   }
/* 4096:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ContextCapabilities
 * JD-Core Version:    0.7.0.1
 */