package org.lwjgl.opencl;

public abstract class CLCompileProgramCallback
  extends CLProgramCallback
{}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLCompileProgramCallback
 * JD-Core Version:    0.7.0.1
 */