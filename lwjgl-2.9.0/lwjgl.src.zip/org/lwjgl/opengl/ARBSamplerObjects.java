/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ 
/*   6:    */ public final class ARBSamplerObjects
/*   7:    */ {
/*   8:    */   public static final int GL_SAMPLER_BINDING = 35097;
/*   9:    */   
/*  10:    */   public static void glGenSamplers(IntBuffer samplers)
/*  11:    */   {
/*  12: 19 */     GL33.glGenSamplers(samplers);
/*  13:    */   }
/*  14:    */   
/*  15:    */   public static int glGenSamplers()
/*  16:    */   {
/*  17: 24 */     return GL33.glGenSamplers();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static void glDeleteSamplers(IntBuffer samplers)
/*  21:    */   {
/*  22: 28 */     GL33.glDeleteSamplers(samplers);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static void glDeleteSamplers(int sampler)
/*  26:    */   {
/*  27: 33 */     GL33.glDeleteSamplers(sampler);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static boolean glIsSampler(int sampler)
/*  31:    */   {
/*  32: 37 */     return GL33.glIsSampler(sampler);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static void glBindSampler(int unit, int sampler)
/*  36:    */   {
/*  37: 41 */     GL33.glBindSampler(unit, sampler);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static void glSamplerParameteri(int sampler, int pname, int param)
/*  41:    */   {
/*  42: 45 */     GL33.glSamplerParameteri(sampler, pname, param);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static void glSamplerParameterf(int sampler, int pname, float param)
/*  46:    */   {
/*  47: 49 */     GL33.glSamplerParameterf(sampler, pname, param);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static void glSamplerParameter(int sampler, int pname, IntBuffer params)
/*  51:    */   {
/*  52: 53 */     GL33.glSamplerParameter(sampler, pname, params);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void glSamplerParameter(int sampler, int pname, FloatBuffer params)
/*  56:    */   {
/*  57: 57 */     GL33.glSamplerParameter(sampler, pname, params);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void glSamplerParameterI(int sampler, int pname, IntBuffer params)
/*  61:    */   {
/*  62: 61 */     GL33.glSamplerParameterI(sampler, pname, params);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glSamplerParameterIu(int sampler, int pname, IntBuffer params)
/*  66:    */   {
/*  67: 65 */     GL33.glSamplerParameterIu(sampler, pname, params);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static void glGetSamplerParameter(int sampler, int pname, IntBuffer params)
/*  71:    */   {
/*  72: 69 */     GL33.glGetSamplerParameter(sampler, pname, params);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int glGetSamplerParameteri(int sampler, int pname)
/*  76:    */   {
/*  77: 74 */     return GL33.glGetSamplerParameteri(sampler, pname);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static void glGetSamplerParameter(int sampler, int pname, FloatBuffer params)
/*  81:    */   {
/*  82: 78 */     GL33.glGetSamplerParameter(sampler, pname, params);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static float glGetSamplerParameterf(int sampler, int pname)
/*  86:    */   {
/*  87: 83 */     return GL33.glGetSamplerParameterf(sampler, pname);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static void glGetSamplerParameterI(int sampler, int pname, IntBuffer params)
/*  91:    */   {
/*  92: 87 */     GL33.glGetSamplerParameterI(sampler, pname, params);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static int glGetSamplerParameterIi(int sampler, int pname)
/*  96:    */   {
/*  97: 92 */     return GL33.glGetSamplerParameterIi(sampler, pname);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static void glGetSamplerParameterIu(int sampler, int pname, IntBuffer params)
/* 101:    */   {
/* 102: 96 */     GL33.glGetSamplerParameterIu(sampler, pname, params);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static int glGetSamplerParameterIui(int sampler, int pname)
/* 106:    */   {
/* 107:101 */     return GL33.glGetSamplerParameterIui(sampler, pname);
/* 108:    */   }
/* 109:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBSamplerObjects
 * JD-Core Version:    0.7.0.1
 */