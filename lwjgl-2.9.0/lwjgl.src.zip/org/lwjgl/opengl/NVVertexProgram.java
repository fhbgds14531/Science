/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ import org.lwjgl.MemoryUtil;
/*  12:    */ 
/*  13:    */ public final class NVVertexProgram
/*  14:    */   extends NVProgram
/*  15:    */ {
/*  16:    */   public static final int GL_VERTEX_PROGRAM_NV = 34336;
/*  17:    */   public static final int GL_VERTEX_PROGRAM_POINT_SIZE_NV = 34370;
/*  18:    */   public static final int GL_VERTEX_PROGRAM_TWO_SIDE_NV = 34371;
/*  19:    */   public static final int GL_VERTEX_STATE_PROGRAM_NV = 34337;
/*  20:    */   public static final int GL_ATTRIB_ARRAY_SIZE_NV = 34339;
/*  21:    */   public static final int GL_ATTRIB_ARRAY_STRIDE_NV = 34340;
/*  22:    */   public static final int GL_ATTRIB_ARRAY_TYPE_NV = 34341;
/*  23:    */   public static final int GL_CURRENT_ATTRIB_NV = 34342;
/*  24:    */   public static final int GL_PROGRAM_PARAMETER_NV = 34372;
/*  25:    */   public static final int GL_ATTRIB_ARRAY_POINTER_NV = 34373;
/*  26:    */   public static final int GL_TRACK_MATRIX_NV = 34376;
/*  27:    */   public static final int GL_TRACK_MATRIX_TRANSFORM_NV = 34377;
/*  28:    */   public static final int GL_MAX_TRACK_MATRIX_STACK_DEPTH_NV = 34350;
/*  29:    */   public static final int GL_MAX_TRACK_MATRICES_NV = 34351;
/*  30:    */   public static final int GL_CURRENT_MATRIX_STACK_DEPTH_NV = 34368;
/*  31:    */   public static final int GL_CURRENT_MATRIX_NV = 34369;
/*  32:    */   public static final int GL_VERTEX_PROGRAM_BINDING_NV = 34378;
/*  33:    */   public static final int GL_MODELVIEW_PROJECTION_NV = 34345;
/*  34:    */   public static final int GL_MATRIX0_NV = 34352;
/*  35:    */   public static final int GL_MATRIX1_NV = 34353;
/*  36:    */   public static final int GL_MATRIX2_NV = 34354;
/*  37:    */   public static final int GL_MATRIX3_NV = 34355;
/*  38:    */   public static final int GL_MATRIX4_NV = 34356;
/*  39:    */   public static final int GL_MATRIX5_NV = 34357;
/*  40:    */   public static final int GL_MATRIX6_NV = 34358;
/*  41:    */   public static final int GL_MATRIX7_NV = 34359;
/*  42:    */   public static final int GL_IDENTITY_NV = 34346;
/*  43:    */   public static final int GL_INVERSE_NV = 34347;
/*  44:    */   public static final int GL_TRANSPOSE_NV = 34348;
/*  45:    */   public static final int GL_INVERSE_TRANSPOSE_NV = 34349;
/*  46:    */   public static final int GL_VERTEX_ATTRIB_ARRAY0_NV = 34384;
/*  47:    */   public static final int GL_VERTEX_ATTRIB_ARRAY1_NV = 34385;
/*  48:    */   public static final int GL_VERTEX_ATTRIB_ARRAY2_NV = 34386;
/*  49:    */   public static final int GL_VERTEX_ATTRIB_ARRAY3_NV = 34387;
/*  50:    */   public static final int GL_VERTEX_ATTRIB_ARRAY4_NV = 34388;
/*  51:    */   public static final int GL_VERTEX_ATTRIB_ARRAY5_NV = 34389;
/*  52:    */   public static final int GL_VERTEX_ATTRIB_ARRAY6_NV = 34390;
/*  53:    */   public static final int GL_VERTEX_ATTRIB_ARRAY7_NV = 34391;
/*  54:    */   public static final int GL_VERTEX_ATTRIB_ARRAY8_NV = 34392;
/*  55:    */   public static final int GL_VERTEX_ATTRIB_ARRAY9_NV = 34393;
/*  56:    */   public static final int GL_VERTEX_ATTRIB_ARRAY10_NV = 34394;
/*  57:    */   public static final int GL_VERTEX_ATTRIB_ARRAY11_NV = 34395;
/*  58:    */   public static final int GL_VERTEX_ATTRIB_ARRAY12_NV = 34396;
/*  59:    */   public static final int GL_VERTEX_ATTRIB_ARRAY13_NV = 34397;
/*  60:    */   public static final int GL_VERTEX_ATTRIB_ARRAY14_NV = 34398;
/*  61:    */   public static final int GL_VERTEX_ATTRIB_ARRAY15_NV = 34399;
/*  62:    */   public static final int GL_MAP1_VERTEX_ATTRIB0_4_NV = 34400;
/*  63:    */   public static final int GL_MAP1_VERTEX_ATTRIB1_4_NV = 34401;
/*  64:    */   public static final int GL_MAP1_VERTEX_ATTRIB2_4_NV = 34402;
/*  65:    */   public static final int GL_MAP1_VERTEX_ATTRIB3_4_NV = 34403;
/*  66:    */   public static final int GL_MAP1_VERTEX_ATTRIB4_4_NV = 34404;
/*  67:    */   public static final int GL_MAP1_VERTEX_ATTRIB5_4_NV = 34405;
/*  68:    */   public static final int GL_MAP1_VERTEX_ATTRIB6_4_NV = 34406;
/*  69:    */   public static final int GL_MAP1_VERTEX_ATTRIB7_4_NV = 34407;
/*  70:    */   public static final int GL_MAP1_VERTEX_ATTRIB8_4_NV = 34408;
/*  71:    */   public static final int GL_MAP1_VERTEX_ATTRIB9_4_NV = 34409;
/*  72:    */   public static final int GL_MAP1_VERTEX_ATTRIB10_4_NV = 34410;
/*  73:    */   public static final int GL_MAP1_VERTEX_ATTRIB11_4_NV = 34411;
/*  74:    */   public static final int GL_MAP1_VERTEX_ATTRIB12_4_NV = 34412;
/*  75:    */   public static final int GL_MAP1_VERTEX_ATTRIB13_4_NV = 34413;
/*  76:    */   public static final int GL_MAP1_VERTEX_ATTRIB14_4_NV = 34414;
/*  77:    */   public static final int GL_MAP1_VERTEX_ATTRIB15_4_NV = 34415;
/*  78:    */   public static final int GL_MAP2_VERTEX_ATTRIB0_4_NV = 34416;
/*  79:    */   public static final int GL_MAP2_VERTEX_ATTRIB1_4_NV = 34417;
/*  80:    */   public static final int GL_MAP2_VERTEX_ATTRIB2_4_NV = 34418;
/*  81:    */   public static final int GL_MAP2_VERTEX_ATTRIB3_4_NV = 34419;
/*  82:    */   public static final int GL_MAP2_VERTEX_ATTRIB4_4_NV = 34420;
/*  83:    */   public static final int GL_MAP2_VERTEX_ATTRIB5_4_NV = 34421;
/*  84:    */   public static final int GL_MAP2_VERTEX_ATTRIB6_4_NV = 34422;
/*  85:    */   public static final int GL_MAP2_VERTEX_ATTRIB7_4_NV = 34423;
/*  86:    */   public static final int GL_MAP2_VERTEX_ATTRIB8_4_NV = 34424;
/*  87:    */   public static final int GL_MAP2_VERTEX_ATTRIB9_4_NV = 34425;
/*  88:    */   public static final int GL_MAP2_VERTEX_ATTRIB10_4_NV = 34426;
/*  89:    */   public static final int GL_MAP2_VERTEX_ATTRIB11_4_NV = 34427;
/*  90:    */   public static final int GL_MAP2_VERTEX_ATTRIB12_4_NV = 34428;
/*  91:    */   public static final int GL_MAP2_VERTEX_ATTRIB13_4_NV = 34429;
/*  92:    */   public static final int GL_MAP2_VERTEX_ATTRIB14_4_NV = 34430;
/*  93:    */   public static final int GL_MAP2_VERTEX_ATTRIB15_4_NV = 34431;
/*  94:    */   
/*  95:    */   public static void glExecuteProgramNV(int target, int id, FloatBuffer params)
/*  96:    */   {
/*  97:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98:167 */     long function_pointer = caps.glExecuteProgramNV;
/*  99:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100:169 */     BufferChecks.checkBuffer(params, 4);
/* 101:170 */     nglExecuteProgramNV(target, id, MemoryUtil.getAddress(params), function_pointer);
/* 102:    */   }
/* 103:    */   
/* 104:    */   static native void nglExecuteProgramNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 105:    */   
/* 106:    */   public static void glGetProgramParameterNV(int target, int index, int parameterName, FloatBuffer params)
/* 107:    */   {
/* 108:175 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 109:176 */     long function_pointer = caps.glGetProgramParameterfvNV;
/* 110:177 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 111:178 */     BufferChecks.checkBuffer(params, 4);
/* 112:179 */     nglGetProgramParameterfvNV(target, index, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 113:    */   }
/* 114:    */   
/* 115:    */   static native void nglGetProgramParameterfvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 116:    */   
/* 117:    */   public static void glGetProgramParameterNV(int target, int index, int parameterName, DoubleBuffer params)
/* 118:    */   {
/* 119:184 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 120:185 */     long function_pointer = caps.glGetProgramParameterdvNV;
/* 121:186 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 122:187 */     BufferChecks.checkBuffer(params, 4);
/* 123:188 */     nglGetProgramParameterdvNV(target, index, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglGetProgramParameterdvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 127:    */   
/* 128:    */   public static void glGetTrackMatrixNV(int target, int address, int parameterName, IntBuffer params)
/* 129:    */   {
/* 130:193 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:194 */     long function_pointer = caps.glGetTrackMatrixivNV;
/* 132:195 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:196 */     BufferChecks.checkBuffer(params, 4);
/* 134:197 */     nglGetTrackMatrixivNV(target, address, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 135:    */   }
/* 136:    */   
/* 137:    */   static native void nglGetTrackMatrixivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 138:    */   
/* 139:    */   public static void glGetVertexAttribNV(int index, int parameterName, FloatBuffer params)
/* 140:    */   {
/* 141:202 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 142:203 */     long function_pointer = caps.glGetVertexAttribfvNV;
/* 143:204 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 144:205 */     BufferChecks.checkBuffer(params, 4);
/* 145:206 */     nglGetVertexAttribfvNV(index, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   static native void nglGetVertexAttribfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 149:    */   
/* 150:    */   public static void glGetVertexAttribNV(int index, int parameterName, DoubleBuffer params)
/* 151:    */   {
/* 152:211 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 153:212 */     long function_pointer = caps.glGetVertexAttribdvNV;
/* 154:213 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 155:214 */     BufferChecks.checkBuffer(params, 4);
/* 156:215 */     nglGetVertexAttribdvNV(index, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static native void nglGetVertexAttribdvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 160:    */   
/* 161:    */   public static void glGetVertexAttribNV(int index, int parameterName, IntBuffer params)
/* 162:    */   {
/* 163:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 164:221 */     long function_pointer = caps.glGetVertexAttribivNV;
/* 165:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 166:223 */     BufferChecks.checkBuffer(params, 4);
/* 167:224 */     nglGetVertexAttribivNV(index, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 168:    */   }
/* 169:    */   
/* 170:    */   static native void nglGetVertexAttribivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 171:    */   
/* 172:    */   public static ByteBuffer glGetVertexAttribPointerNV(int index, int parameterName, long result_size)
/* 173:    */   {
/* 174:229 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 175:230 */     long function_pointer = caps.glGetVertexAttribPointervNV;
/* 176:231 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 177:232 */     ByteBuffer __result = nglGetVertexAttribPointervNV(index, parameterName, result_size, function_pointer);
/* 178:233 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 179:    */   }
/* 180:    */   
/* 181:    */   static native ByteBuffer nglGetVertexAttribPointervNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 182:    */   
/* 183:    */   public static void glProgramParameter4fNV(int target, int index, float x, float y, float z, float w)
/* 184:    */   {
/* 185:238 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 186:239 */     long function_pointer = caps.glProgramParameter4fNV;
/* 187:240 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 188:241 */     nglProgramParameter4fNV(target, index, x, y, z, w, function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglProgramParameter4fNV(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 192:    */   
/* 193:    */   public static void glProgramParameter4dNV(int target, int index, double x, double y, double z, double w)
/* 194:    */   {
/* 195:246 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 196:247 */     long function_pointer = caps.glProgramParameter4dNV;
/* 197:248 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 198:249 */     nglProgramParameter4dNV(target, index, x, y, z, w, function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   static native void nglProgramParameter4dNV(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 202:    */   
/* 203:    */   public static void glProgramParameters4NV(int target, int index, FloatBuffer params)
/* 204:    */   {
/* 205:254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 206:255 */     long function_pointer = caps.glProgramParameters4fvNV;
/* 207:256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 208:257 */     BufferChecks.checkDirect(params);
/* 209:258 */     nglProgramParameters4fvNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 210:    */   }
/* 211:    */   
/* 212:    */   static native void nglProgramParameters4fvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 213:    */   
/* 214:    */   public static void glProgramParameters4NV(int target, int index, DoubleBuffer params)
/* 215:    */   {
/* 216:263 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 217:264 */     long function_pointer = caps.glProgramParameters4dvNV;
/* 218:265 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 219:266 */     BufferChecks.checkDirect(params);
/* 220:267 */     nglProgramParameters4dvNV(target, index, params.remaining() >> 2, MemoryUtil.getAddress(params), function_pointer);
/* 221:    */   }
/* 222:    */   
/* 223:    */   static native void nglProgramParameters4dvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 224:    */   
/* 225:    */   public static void glTrackMatrixNV(int target, int address, int matrix, int transform)
/* 226:    */   {
/* 227:272 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 228:273 */     long function_pointer = caps.glTrackMatrixNV;
/* 229:274 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 230:275 */     nglTrackMatrixNV(target, address, matrix, transform, function_pointer);
/* 231:    */   }
/* 232:    */   
/* 233:    */   static native void nglTrackMatrixNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 234:    */   
/* 235:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, DoubleBuffer buffer)
/* 236:    */   {
/* 237:280 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 238:281 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 239:282 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 240:283 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 241:284 */     BufferChecks.checkDirect(buffer);
/* 242:285 */     if (LWJGLUtil.CHECKS) {
/* 243:285 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 244:    */     }
/* 245:286 */     nglVertexAttribPointerNV(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 246:    */   }
/* 247:    */   
/* 248:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, FloatBuffer buffer)
/* 249:    */   {
/* 250:289 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 251:290 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 252:291 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 253:292 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 254:293 */     BufferChecks.checkDirect(buffer);
/* 255:294 */     if (LWJGLUtil.CHECKS) {
/* 256:294 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 257:    */     }
/* 258:295 */     nglVertexAttribPointerNV(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 259:    */   }
/* 260:    */   
/* 261:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, ByteBuffer buffer)
/* 262:    */   {
/* 263:298 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 264:299 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 265:300 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 266:301 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 267:302 */     BufferChecks.checkDirect(buffer);
/* 268:303 */     if (LWJGLUtil.CHECKS) {
/* 269:303 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 270:    */     }
/* 271:304 */     nglVertexAttribPointerNV(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, IntBuffer buffer)
/* 275:    */   {
/* 276:307 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 277:308 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 278:309 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 279:310 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 280:311 */     BufferChecks.checkDirect(buffer);
/* 281:312 */     if (LWJGLUtil.CHECKS) {
/* 282:312 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 283:    */     }
/* 284:313 */     nglVertexAttribPointerNV(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 285:    */   }
/* 286:    */   
/* 287:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, ShortBuffer buffer)
/* 288:    */   {
/* 289:316 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 290:317 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 291:318 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 292:319 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 293:320 */     BufferChecks.checkDirect(buffer);
/* 294:321 */     if (LWJGLUtil.CHECKS) {
/* 295:321 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/* 296:    */     }
/* 297:322 */     nglVertexAttribPointerNV(index, size, type, stride, MemoryUtil.getAddress(buffer), function_pointer);
/* 298:    */   }
/* 299:    */   
/* 300:    */   static native void nglVertexAttribPointerNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 301:    */   
/* 302:    */   public static void glVertexAttribPointerNV(int index, int size, int type, int stride, long buffer_buffer_offset)
/* 303:    */   {
/* 304:326 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 305:327 */     long function_pointer = caps.glVertexAttribPointerNV;
/* 306:328 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 307:329 */     GLChecks.ensureArrayVBOenabled(caps);
/* 308:330 */     nglVertexAttribPointerNVBO(index, size, type, stride, buffer_buffer_offset, function_pointer);
/* 309:    */   }
/* 310:    */   
/* 311:    */   static native void nglVertexAttribPointerNVBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 312:    */   
/* 313:    */   public static void glVertexAttrib1sNV(int index, short x)
/* 314:    */   {
/* 315:335 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 316:336 */     long function_pointer = caps.glVertexAttrib1sNV;
/* 317:337 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 318:338 */     nglVertexAttrib1sNV(index, x, function_pointer);
/* 319:    */   }
/* 320:    */   
/* 321:    */   static native void nglVertexAttrib1sNV(int paramInt, short paramShort, long paramLong);
/* 322:    */   
/* 323:    */   public static void glVertexAttrib1fNV(int index, float x)
/* 324:    */   {
/* 325:343 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 326:344 */     long function_pointer = caps.glVertexAttrib1fNV;
/* 327:345 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 328:346 */     nglVertexAttrib1fNV(index, x, function_pointer);
/* 329:    */   }
/* 330:    */   
/* 331:    */   static native void nglVertexAttrib1fNV(int paramInt, float paramFloat, long paramLong);
/* 332:    */   
/* 333:    */   public static void glVertexAttrib1dNV(int index, double x)
/* 334:    */   {
/* 335:351 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 336:352 */     long function_pointer = caps.glVertexAttrib1dNV;
/* 337:353 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 338:354 */     nglVertexAttrib1dNV(index, x, function_pointer);
/* 339:    */   }
/* 340:    */   
/* 341:    */   static native void nglVertexAttrib1dNV(int paramInt, double paramDouble, long paramLong);
/* 342:    */   
/* 343:    */   public static void glVertexAttrib2sNV(int index, short x, short y)
/* 344:    */   {
/* 345:359 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 346:360 */     long function_pointer = caps.glVertexAttrib2sNV;
/* 347:361 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 348:362 */     nglVertexAttrib2sNV(index, x, y, function_pointer);
/* 349:    */   }
/* 350:    */   
/* 351:    */   static native void nglVertexAttrib2sNV(int paramInt, short paramShort1, short paramShort2, long paramLong);
/* 352:    */   
/* 353:    */   public static void glVertexAttrib2fNV(int index, float x, float y)
/* 354:    */   {
/* 355:367 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 356:368 */     long function_pointer = caps.glVertexAttrib2fNV;
/* 357:369 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 358:370 */     nglVertexAttrib2fNV(index, x, y, function_pointer);
/* 359:    */   }
/* 360:    */   
/* 361:    */   static native void nglVertexAttrib2fNV(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/* 362:    */   
/* 363:    */   public static void glVertexAttrib2dNV(int index, double x, double y)
/* 364:    */   {
/* 365:375 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 366:376 */     long function_pointer = caps.glVertexAttrib2dNV;
/* 367:377 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 368:378 */     nglVertexAttrib2dNV(index, x, y, function_pointer);
/* 369:    */   }
/* 370:    */   
/* 371:    */   static native void nglVertexAttrib2dNV(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 372:    */   
/* 373:    */   public static void glVertexAttrib3sNV(int index, short x, short y, short z)
/* 374:    */   {
/* 375:383 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 376:384 */     long function_pointer = caps.glVertexAttrib3sNV;
/* 377:385 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 378:386 */     nglVertexAttrib3sNV(index, x, y, z, function_pointer);
/* 379:    */   }
/* 380:    */   
/* 381:    */   static native void nglVertexAttrib3sNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 382:    */   
/* 383:    */   public static void glVertexAttrib3fNV(int index, float x, float y, float z)
/* 384:    */   {
/* 385:391 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 386:392 */     long function_pointer = caps.glVertexAttrib3fNV;
/* 387:393 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 388:394 */     nglVertexAttrib3fNV(index, x, y, z, function_pointer);
/* 389:    */   }
/* 390:    */   
/* 391:    */   static native void nglVertexAttrib3fNV(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 392:    */   
/* 393:    */   public static void glVertexAttrib3dNV(int index, double x, double y, double z)
/* 394:    */   {
/* 395:399 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 396:400 */     long function_pointer = caps.glVertexAttrib3dNV;
/* 397:401 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 398:402 */     nglVertexAttrib3dNV(index, x, y, z, function_pointer);
/* 399:    */   }
/* 400:    */   
/* 401:    */   static native void nglVertexAttrib3dNV(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 402:    */   
/* 403:    */   public static void glVertexAttrib4sNV(int index, short x, short y, short z, short w)
/* 404:    */   {
/* 405:407 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 406:408 */     long function_pointer = caps.glVertexAttrib4sNV;
/* 407:409 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 408:410 */     nglVertexAttrib4sNV(index, x, y, z, w, function_pointer);
/* 409:    */   }
/* 410:    */   
/* 411:    */   static native void nglVertexAttrib4sNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 412:    */   
/* 413:    */   public static void glVertexAttrib4fNV(int index, float x, float y, float z, float w)
/* 414:    */   {
/* 415:415 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 416:416 */     long function_pointer = caps.glVertexAttrib4fNV;
/* 417:417 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 418:418 */     nglVertexAttrib4fNV(index, x, y, z, w, function_pointer);
/* 419:    */   }
/* 420:    */   
/* 421:    */   static native void nglVertexAttrib4fNV(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 422:    */   
/* 423:    */   public static void glVertexAttrib4dNV(int index, double x, double y, double z, double w)
/* 424:    */   {
/* 425:423 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 426:424 */     long function_pointer = caps.glVertexAttrib4dNV;
/* 427:425 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 428:426 */     nglVertexAttrib4dNV(index, x, y, z, w, function_pointer);
/* 429:    */   }
/* 430:    */   
/* 431:    */   static native void nglVertexAttrib4dNV(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 432:    */   
/* 433:    */   public static void glVertexAttrib4ubNV(int index, byte x, byte y, byte z, byte w)
/* 434:    */   {
/* 435:431 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 436:432 */     long function_pointer = caps.glVertexAttrib4ubNV;
/* 437:433 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 438:434 */     nglVertexAttrib4ubNV(index, x, y, z, w, function_pointer);
/* 439:    */   }
/* 440:    */   
/* 441:    */   static native void nglVertexAttrib4ubNV(int paramInt, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, long paramLong);
/* 442:    */   
/* 443:    */   public static void glVertexAttribs1NV(int index, ShortBuffer v)
/* 444:    */   {
/* 445:439 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 446:440 */     long function_pointer = caps.glVertexAttribs1svNV;
/* 447:441 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 448:442 */     BufferChecks.checkDirect(v);
/* 449:443 */     nglVertexAttribs1svNV(index, v.remaining(), MemoryUtil.getAddress(v), function_pointer);
/* 450:    */   }
/* 451:    */   
/* 452:    */   static native void nglVertexAttribs1svNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 453:    */   
/* 454:    */   public static void glVertexAttribs1NV(int index, FloatBuffer v)
/* 455:    */   {
/* 456:448 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 457:449 */     long function_pointer = caps.glVertexAttribs1fvNV;
/* 458:450 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 459:451 */     BufferChecks.checkDirect(v);
/* 460:452 */     nglVertexAttribs1fvNV(index, v.remaining(), MemoryUtil.getAddress(v), function_pointer);
/* 461:    */   }
/* 462:    */   
/* 463:    */   static native void nglVertexAttribs1fvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 464:    */   
/* 465:    */   public static void glVertexAttribs1NV(int index, DoubleBuffer v)
/* 466:    */   {
/* 467:457 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 468:458 */     long function_pointer = caps.glVertexAttribs1dvNV;
/* 469:459 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 470:460 */     BufferChecks.checkDirect(v);
/* 471:461 */     nglVertexAttribs1dvNV(index, v.remaining(), MemoryUtil.getAddress(v), function_pointer);
/* 472:    */   }
/* 473:    */   
/* 474:    */   static native void nglVertexAttribs1dvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 475:    */   
/* 476:    */   public static void glVertexAttribs2NV(int index, ShortBuffer v)
/* 477:    */   {
/* 478:466 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 479:467 */     long function_pointer = caps.glVertexAttribs2svNV;
/* 480:468 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 481:469 */     BufferChecks.checkDirect(v);
/* 482:470 */     nglVertexAttribs2svNV(index, v.remaining() >> 1, MemoryUtil.getAddress(v), function_pointer);
/* 483:    */   }
/* 484:    */   
/* 485:    */   static native void nglVertexAttribs2svNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 486:    */   
/* 487:    */   public static void glVertexAttribs2NV(int index, FloatBuffer v)
/* 488:    */   {
/* 489:475 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 490:476 */     long function_pointer = caps.glVertexAttribs2fvNV;
/* 491:477 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 492:478 */     BufferChecks.checkDirect(v);
/* 493:479 */     nglVertexAttribs2fvNV(index, v.remaining() >> 1, MemoryUtil.getAddress(v), function_pointer);
/* 494:    */   }
/* 495:    */   
/* 496:    */   static native void nglVertexAttribs2fvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 497:    */   
/* 498:    */   public static void glVertexAttribs2NV(int index, DoubleBuffer v)
/* 499:    */   {
/* 500:484 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 501:485 */     long function_pointer = caps.glVertexAttribs2dvNV;
/* 502:486 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 503:487 */     BufferChecks.checkDirect(v);
/* 504:488 */     nglVertexAttribs2dvNV(index, v.remaining() >> 1, MemoryUtil.getAddress(v), function_pointer);
/* 505:    */   }
/* 506:    */   
/* 507:    */   static native void nglVertexAttribs2dvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 508:    */   
/* 509:    */   public static void glVertexAttribs3NV(int index, ShortBuffer v)
/* 510:    */   {
/* 511:493 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 512:494 */     long function_pointer = caps.glVertexAttribs3svNV;
/* 513:495 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 514:496 */     BufferChecks.checkDirect(v);
/* 515:497 */     nglVertexAttribs3svNV(index, v.remaining() / 3, MemoryUtil.getAddress(v), function_pointer);
/* 516:    */   }
/* 517:    */   
/* 518:    */   static native void nglVertexAttribs3svNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 519:    */   
/* 520:    */   public static void glVertexAttribs3NV(int index, FloatBuffer v)
/* 521:    */   {
/* 522:502 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 523:503 */     long function_pointer = caps.glVertexAttribs3fvNV;
/* 524:504 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 525:505 */     BufferChecks.checkDirect(v);
/* 526:506 */     nglVertexAttribs3fvNV(index, v.remaining() / 3, MemoryUtil.getAddress(v), function_pointer);
/* 527:    */   }
/* 528:    */   
/* 529:    */   static native void nglVertexAttribs3fvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 530:    */   
/* 531:    */   public static void glVertexAttribs3NV(int index, DoubleBuffer v)
/* 532:    */   {
/* 533:511 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 534:512 */     long function_pointer = caps.glVertexAttribs3dvNV;
/* 535:513 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 536:514 */     BufferChecks.checkDirect(v);
/* 537:515 */     nglVertexAttribs3dvNV(index, v.remaining() / 3, MemoryUtil.getAddress(v), function_pointer);
/* 538:    */   }
/* 539:    */   
/* 540:    */   static native void nglVertexAttribs3dvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 541:    */   
/* 542:    */   public static void glVertexAttribs4NV(int index, ShortBuffer v)
/* 543:    */   {
/* 544:520 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 545:521 */     long function_pointer = caps.glVertexAttribs4svNV;
/* 546:522 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 547:523 */     BufferChecks.checkDirect(v);
/* 548:524 */     nglVertexAttribs4svNV(index, v.remaining() >> 2, MemoryUtil.getAddress(v), function_pointer);
/* 549:    */   }
/* 550:    */   
/* 551:    */   static native void nglVertexAttribs4svNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 552:    */   
/* 553:    */   public static void glVertexAttribs4NV(int index, FloatBuffer v)
/* 554:    */   {
/* 555:529 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 556:530 */     long function_pointer = caps.glVertexAttribs4fvNV;
/* 557:531 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 558:532 */     BufferChecks.checkDirect(v);
/* 559:533 */     nglVertexAttribs4fvNV(index, v.remaining() >> 2, MemoryUtil.getAddress(v), function_pointer);
/* 560:    */   }
/* 561:    */   
/* 562:    */   static native void nglVertexAttribs4fvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 563:    */   
/* 564:    */   public static void glVertexAttribs4NV(int index, DoubleBuffer v)
/* 565:    */   {
/* 566:538 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 567:539 */     long function_pointer = caps.glVertexAttribs4dvNV;
/* 568:540 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 569:541 */     BufferChecks.checkDirect(v);
/* 570:542 */     nglVertexAttribs4dvNV(index, v.remaining() >> 2, MemoryUtil.getAddress(v), function_pointer);
/* 571:    */   }
/* 572:    */   
/* 573:    */   static native void nglVertexAttribs4dvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 574:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexProgram
 * JD-Core Version:    0.7.0.1
 */