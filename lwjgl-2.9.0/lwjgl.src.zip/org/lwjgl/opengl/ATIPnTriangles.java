/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ATIPnTriangles
/*  6:   */ {
/*  7:   */   public static final int GL_PN_TRIANGLES_ATI = 34800;
/*  8:   */   public static final int GL_MAX_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34801;
/*  9:   */   public static final int GL_PN_TRIANGLES_POINT_MODE_ATI = 34802;
/* 10:   */   public static final int GL_PN_TRIANGLES_NORMAL_MODE_ATI = 34803;
/* 11:   */   public static final int GL_PN_TRIANGLES_TESSELATION_LEVEL_ATI = 34804;
/* 12:   */   public static final int GL_PN_TRIANGLES_POINT_MODE_LINEAR_ATI = 34805;
/* 13:   */   public static final int GL_PN_TRIANGLES_POINT_MODE_CUBIC_ATI = 34806;
/* 14:   */   public static final int GL_PN_TRIANGLES_NORMAL_MODE_LINEAR_ATI = 34807;
/* 15:   */   public static final int GL_PN_TRIANGLES_NORMAL_MODE_QUADRATIC_ATI = 34808;
/* 16:   */   
/* 17:   */   public static void glPNTrianglesfATI(int pname, float param)
/* 18:   */   {
/* 19:23 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:24 */     long function_pointer = caps.glPNTrianglesfATI;
/* 21:25 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:26 */     nglPNTrianglesfATI(pname, param, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglPNTrianglesfATI(int paramInt, float paramFloat, long paramLong);
/* 26:   */   
/* 27:   */   public static void glPNTrianglesiATI(int pname, int param)
/* 28:   */   {
/* 29:31 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:32 */     long function_pointer = caps.glPNTrianglesiATI;
/* 31:33 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:34 */     nglPNTrianglesiATI(pname, param, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglPNTrianglesiATI(int paramInt1, int paramInt2, long paramLong);
/* 36:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIPnTriangles
 * JD-Core Version:    0.7.0.1
 */