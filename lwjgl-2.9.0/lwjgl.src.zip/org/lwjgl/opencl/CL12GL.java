/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class CL12GL
/*  8:   */ {
/*  9:   */   public static final int CL_GL_OBJECT_TEXTURE2D_ARRAY = 8206;
/* 10:   */   public static final int CL_GL_OBJECT_TEXTURE1D = 8207;
/* 11:   */   public static final int CL_GL_OBJECT_TEXTURE1D_ARRAY = 8208;
/* 12:   */   public static final int CL_GL_OBJECT_TEXTURE_BUFFER = 8209;
/* 13:   */   
/* 14:   */   public static CLMem clCreateFromGLTexture(CLContext context, long flags, int target, int miplevel, int texture, IntBuffer errcode_ret)
/* 15:   */   {
/* 16:21 */     long function_pointer = CLCapabilities.clCreateFromGLTexture;
/* 17:22 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 18:23 */     if (errcode_ret != null) {
/* 19:24 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 20:   */     }
/* 21:25 */     CLMem __result = new CLMem(nclCreateFromGLTexture(context.getPointer(), flags, target, miplevel, texture, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 22:26 */     return __result;
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native long nclCreateFromGLTexture(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, long paramLong3, long paramLong4);
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL12GL
 * JD-Core Version:    0.7.0.1
 */