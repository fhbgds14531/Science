/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class Util
/*  4:   */ {
/*  5:   */   public static void checkGLError()
/*  6:   */     throws OpenGLException
/*  7:   */   {
/*  8:57 */     int err = GL11.glGetError();
/*  9:58 */     if (err != 0) {
/* 10:59 */       throw new OpenGLException(err);
/* 11:   */     }
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static String translateGLErrorString(int error_code)
/* 15:   */   {
/* 16:67 */     switch (error_code)
/* 17:   */     {
/* 18:   */     case 0: 
/* 19:69 */       return "No error";
/* 20:   */     case 1280: 
/* 21:71 */       return "Invalid enum";
/* 22:   */     case 1281: 
/* 23:73 */       return "Invalid value";
/* 24:   */     case 1282: 
/* 25:75 */       return "Invalid operation";
/* 26:   */     case 1283: 
/* 27:77 */       return "Stack overflow";
/* 28:   */     case 1284: 
/* 29:79 */       return "Stack underflow";
/* 30:   */     case 1285: 
/* 31:81 */       return "Out of memory";
/* 32:   */     case 32817: 
/* 33:83 */       return "Table too large";
/* 34:   */     case 1286: 
/* 35:85 */       return "Invalid framebuffer operation";
/* 36:   */     }
/* 37:87 */     return null;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.Util
 * JD-Core Version:    0.7.0.1
 */