/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import java.nio.LongBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class NVPresentVideo
/*   9:    */ {
/*  10:    */   public static final int GL_FRAME_NV = 36390;
/*  11:    */   public static final int FIELDS_NV = 36391;
/*  12:    */   public static final int GL_CURRENT_TIME_NV = 36392;
/*  13:    */   public static final int GL_NUM_FILL_STREAMS_NV = 36393;
/*  14:    */   public static final int GL_PRESENT_TIME_NV = 36394;
/*  15:    */   public static final int GL_PRESENT_DURATION_NV = 36395;
/*  16:    */   public static final int GL_NUM_VIDEO_SLOTS_NV = 8432;
/*  17:    */   
/*  18:    */   public static void glPresentFrameKeyedNV(int video_slot, long minPresentTime, int beginPresentTimeId, int presentDurationId, int type, int target0, int fill0, int key0, int target1, int fill1, int key1)
/*  19:    */   {
/*  20: 38 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  21: 39 */     long function_pointer = caps.glPresentFrameKeyedNV;
/*  22: 40 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  23: 41 */     nglPresentFrameKeyedNV(video_slot, minPresentTime, beginPresentTimeId, presentDurationId, type, target0, fill0, key0, target1, fill1, key1, function_pointer);
/*  24:    */   }
/*  25:    */   
/*  26:    */   static native void nglPresentFrameKeyedNV(int paramInt1, long paramLong1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong2);
/*  27:    */   
/*  28:    */   public static void glPresentFrameDualFillNV(int video_slot, long minPresentTime, int beginPresentTimeId, int presentDurationId, int type, int target0, int fill0, int target1, int fill1, int target2, int fill2, int target3, int fill3)
/*  29:    */   {
/*  30: 46 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  31: 47 */     long function_pointer = caps.glPresentFrameDualFillNV;
/*  32: 48 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  33: 49 */     nglPresentFrameDualFillNV(video_slot, minPresentTime, beginPresentTimeId, presentDurationId, type, target0, fill0, target1, fill1, target2, fill2, target3, fill3, function_pointer);
/*  34:    */   }
/*  35:    */   
/*  36:    */   static native void nglPresentFrameDualFillNV(int paramInt1, long paramLong1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, long paramLong2);
/*  37:    */   
/*  38:    */   public static void glGetVideoNV(int video_slot, int pname, IntBuffer params)
/*  39:    */   {
/*  40: 54 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  41: 55 */     long function_pointer = caps.glGetVideoivNV;
/*  42: 56 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  43: 57 */     BufferChecks.checkBuffer(params, 1);
/*  44: 58 */     nglGetVideoivNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  45:    */   }
/*  46:    */   
/*  47:    */   static native void nglGetVideoivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  48:    */   
/*  49:    */   public static int glGetVideoiNV(int video_slot, int pname)
/*  50:    */   {
/*  51: 64 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  52: 65 */     long function_pointer = caps.glGetVideoivNV;
/*  53: 66 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  54: 67 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  55: 68 */     nglGetVideoivNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  56: 69 */     return params.get(0);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void glGetVideouNV(int video_slot, int pname, IntBuffer params)
/*  60:    */   {
/*  61: 73 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  62: 74 */     long function_pointer = caps.glGetVideouivNV;
/*  63: 75 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  64: 76 */     BufferChecks.checkBuffer(params, 1);
/*  65: 77 */     nglGetVideouivNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  66:    */   }
/*  67:    */   
/*  68:    */   static native void nglGetVideouivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  69:    */   
/*  70:    */   public static int glGetVideouiNV(int video_slot, int pname)
/*  71:    */   {
/*  72: 83 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  73: 84 */     long function_pointer = caps.glGetVideouivNV;
/*  74: 85 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  75: 86 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  76: 87 */     nglGetVideouivNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  77: 88 */     return params.get(0);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static void glGetVideoNV(int video_slot, int pname, LongBuffer params)
/*  81:    */   {
/*  82: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  83: 93 */     long function_pointer = caps.glGetVideoi64vNV;
/*  84: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  85: 95 */     BufferChecks.checkBuffer(params, 1);
/*  86: 96 */     nglGetVideoi64vNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglGetVideoi64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  90:    */   
/*  91:    */   public static long glGetVideoi64NV(int video_slot, int pname)
/*  92:    */   {
/*  93:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  94:103 */     long function_pointer = caps.glGetVideoi64vNV;
/*  95:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  96:105 */     LongBuffer params = APIUtil.getBufferLong(caps);
/*  97:106 */     nglGetVideoi64vNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  98:107 */     return params.get(0);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static void glGetVideouNV(int video_slot, int pname, LongBuffer params)
/* 102:    */   {
/* 103:111 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104:112 */     long function_pointer = caps.glGetVideoui64vNV;
/* 105:113 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106:114 */     BufferChecks.checkBuffer(params, 1);
/* 107:115 */     nglGetVideoui64vNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglGetVideoui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static long glGetVideoui64NV(int video_slot, int pname)
/* 113:    */   {
/* 114:121 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:122 */     long function_pointer = caps.glGetVideoui64vNV;
/* 116:123 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:124 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 118:125 */     nglGetVideoui64vNV(video_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/* 119:126 */     return params.get(0);
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPresentVideo
 * JD-Core Version:    0.7.0.1
 */