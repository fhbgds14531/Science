package org.lwjgl.opengl;

public final class ARBStencilTexturing
{
  public static final int GL_DEPTH_STENCIL_TEXTURE_MODE = 37098;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBStencilTexturing
 * JD-Core Version:    0.7.0.1
 */