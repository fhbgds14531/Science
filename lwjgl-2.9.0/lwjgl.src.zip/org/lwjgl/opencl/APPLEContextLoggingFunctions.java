/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ final class APPLEContextLoggingFunctions
/*  8:   */ {
/*  9:   */   static void clLogMessagesToSystemLogAPPLE(ByteBuffer errstr, ByteBuffer private_info, ByteBuffer user_data)
/* 10:   */   {
/* 11:13 */     long function_pointer = CLCapabilities.clLogMessagesToSystemLogAPPLE;
/* 12:14 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 13:15 */     BufferChecks.checkDirect(errstr);
/* 14:16 */     BufferChecks.checkDirect(private_info);
/* 15:17 */     BufferChecks.checkDirect(user_data);
/* 16:18 */     nclLogMessagesToSystemLogAPPLE(MemoryUtil.getAddress(errstr), MemoryUtil.getAddress(private_info), private_info.remaining(), MemoryUtil.getAddress(user_data), function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nclLogMessagesToSystemLogAPPLE(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 20:   */   
/* 21:   */   static void clLogMessagesToStdoutAPPLE(ByteBuffer errstr, ByteBuffer private_info, ByteBuffer user_data)
/* 22:   */   {
/* 23:23 */     long function_pointer = CLCapabilities.clLogMessagesToStdoutAPPLE;
/* 24:24 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:25 */     BufferChecks.checkDirect(errstr);
/* 26:26 */     BufferChecks.checkDirect(private_info);
/* 27:27 */     BufferChecks.checkDirect(user_data);
/* 28:28 */     nclLogMessagesToStdoutAPPLE(MemoryUtil.getAddress(errstr), MemoryUtil.getAddress(private_info), private_info.remaining(), MemoryUtil.getAddress(user_data), function_pointer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   static native void nclLogMessagesToStdoutAPPLE(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 32:   */   
/* 33:   */   static void clLogMessagesToStderrAPPLE(ByteBuffer errstr, ByteBuffer private_info, ByteBuffer user_data)
/* 34:   */   {
/* 35:33 */     long function_pointer = CLCapabilities.clLogMessagesToStderrAPPLE;
/* 36:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 37:35 */     BufferChecks.checkDirect(errstr);
/* 38:36 */     BufferChecks.checkDirect(private_info);
/* 39:37 */     BufferChecks.checkDirect(user_data);
/* 40:38 */     nclLogMessagesToStderrAPPLE(MemoryUtil.getAddress(errstr), MemoryUtil.getAddress(private_info), private_info.remaining(), MemoryUtil.getAddress(user_data), function_pointer);
/* 41:   */   }
/* 42:   */   
/* 43:   */   static native void nclLogMessagesToStderrAPPLE(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 44:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.APPLEContextLoggingFunctions
 * JD-Core Version:    0.7.0.1
 */