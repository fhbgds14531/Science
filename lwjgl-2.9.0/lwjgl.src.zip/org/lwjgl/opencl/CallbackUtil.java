/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ 
/*  6:   */ final class CallbackUtil
/*  7:   */ {
/*  8:44 */   private static final Map<CLContext, Long> contextUserData = new HashMap();
/*  9:   */   
/* 10:   */   static long createGlobalRef(Object obj)
/* 11:   */   {
/* 12:56 */     return obj == null ? 0L : ncreateGlobalRef(obj);
/* 13:   */   }
/* 14:   */   
/* 15:   */   private static native long ncreateGlobalRef(Object paramObject);
/* 16:   */   
/* 17:   */   static native void deleteGlobalRef(long paramLong);
/* 18:   */   
/* 19:   */   static void checkCallback(int errcode, long user_data)
/* 20:   */   {
/* 21:82 */     if ((errcode != 0) && (user_data != 0L)) {
/* 22:83 */       deleteGlobalRef(user_data);
/* 23:   */     }
/* 24:   */   }
/* 25:   */   
/* 26:   */   static native long getContextCallback();
/* 27:   */   
/* 28:   */   static native long getMemObjectDestructorCallback();
/* 29:   */   
/* 30:   */   static native long getProgramCallback();
/* 31:   */   
/* 32:   */   static native long getNativeKernelCallback();
/* 33:   */   
/* 34:   */   static native long getEventCallback();
/* 35:   */   
/* 36:   */   static native long getPrintfCallback();
/* 37:   */   
/* 38:   */   static native long getLogMessageToSystemLogAPPLE();
/* 39:   */   
/* 40:   */   static native long getLogMessageToStdoutAPPLE();
/* 41:   */   
/* 42:   */   static native long getLogMessageToStderrAPPLE();
/* 43:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CallbackUtil
 * JD-Core Version:    0.7.0.1
 */