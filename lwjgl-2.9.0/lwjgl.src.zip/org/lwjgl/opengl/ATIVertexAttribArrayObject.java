/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class ATIVertexAttribArrayObject
/*  9:   */ {
/* 10:   */   public static void glVertexAttribArrayObjectATI(int index, int size, int type, boolean normalized, int stride, int buffer, int offset)
/* 11:   */   {
/* 12:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:14 */     long function_pointer = caps.glVertexAttribArrayObjectATI;
/* 14:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:16 */     nglVertexAttribArrayObjectATI(index, size, type, normalized, stride, buffer, offset, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglVertexAttribArrayObjectATI(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 19:   */   
/* 20:   */   public static void glGetVertexAttribArrayObjectATI(int index, int pname, FloatBuffer params)
/* 21:   */   {
/* 22:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:22 */     long function_pointer = caps.glGetVertexAttribArrayObjectfvATI;
/* 24:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:24 */     BufferChecks.checkBuffer(params, 4);
/* 26:25 */     nglGetVertexAttribArrayObjectfvATI(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   static native void nglGetVertexAttribArrayObjectfvATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 30:   */   
/* 31:   */   public static void glGetVertexAttribArrayObjectATI(int index, int pname, IntBuffer params)
/* 32:   */   {
/* 33:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 34:31 */     long function_pointer = caps.glGetVertexAttribArrayObjectivATI;
/* 35:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:33 */     BufferChecks.checkBuffer(params, 4);
/* 37:34 */     nglGetVertexAttribArrayObjectivATI(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 38:   */   }
/* 39:   */   
/* 40:   */   static native void nglGetVertexAttribArrayObjectivATI(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 41:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIVertexAttribArrayObject
 * JD-Core Version:    0.7.0.1
 */