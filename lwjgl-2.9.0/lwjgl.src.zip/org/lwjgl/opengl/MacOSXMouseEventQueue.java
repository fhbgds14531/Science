/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Component;
/*   4:    */ import java.awt.Point;
/*   5:    */ import java.awt.Rectangle;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import org.lwjgl.BufferUtils;
/*   8:    */ 
/*   9:    */ final class MacOSXMouseEventQueue
/*  10:    */   extends MouseEventQueue
/*  11:    */ {
/*  12: 47 */   private final IntBuffer delta_buffer = BufferUtils.createIntBuffer(2);
/*  13:    */   private boolean skip_event;
/*  14:    */   private static boolean is_grabbed;
/*  15:    */   
/*  16:    */   MacOSXMouseEventQueue(Component component)
/*  17:    */   {
/*  18: 53 */     super(component);
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setGrabbed(boolean grab)
/*  22:    */   {
/*  23: 57 */     if (is_grabbed != grab)
/*  24:    */     {
/*  25: 58 */       super.setGrabbed(grab);
/*  26: 59 */       warpCursor();
/*  27: 60 */       grabMouse(grab);
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   private static synchronized void grabMouse(boolean grab)
/*  32:    */   {
/*  33: 65 */     is_grabbed = grab;
/*  34: 66 */     if (!grab) {
/*  35: 67 */       nGrabMouse(grab);
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected void resetCursorToCenter()
/*  40:    */   {
/*  41: 71 */     super.resetCursorToCenter();
/*  42:    */     
/*  43: 73 */     getMouseDeltas(this.delta_buffer);
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected void updateDeltas(long nanos)
/*  47:    */   {
/*  48: 77 */     super.updateDeltas(nanos);
/*  49: 78 */     synchronized (this)
/*  50:    */     {
/*  51: 79 */       getMouseDeltas(this.delta_buffer);
/*  52: 80 */       int dx = this.delta_buffer.get(0);
/*  53: 81 */       int dy = -this.delta_buffer.get(1);
/*  54: 82 */       if (this.skip_event)
/*  55:    */       {
/*  56: 83 */         this.skip_event = false;
/*  57: 84 */         nGrabMouse(isGrabbed());
/*  58: 85 */         return;
/*  59:    */       }
/*  60: 87 */       if ((dx != 0) || (dy != 0))
/*  61:    */       {
/*  62: 88 */         putMouseEventWithCoords((byte)-1, (byte)0, dx, dy, 0, nanos);
/*  63: 89 */         addDelta(dx, dy);
/*  64:    */       }
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   void warpCursor()
/*  69:    */   {
/*  70: 95 */     synchronized (this)
/*  71:    */     {
/*  72: 97 */       this.skip_event = isGrabbed();
/*  73:    */     }
/*  74: 99 */     if (isGrabbed())
/*  75:    */     {
/*  76:100 */       Rectangle bounds = getComponent().getBounds();
/*  77:101 */       Point location_on_screen = getComponent().getLocationOnScreen();
/*  78:102 */       int x = location_on_screen.x + bounds.width / 2;
/*  79:103 */       int y = location_on_screen.y + bounds.height / 2;
/*  80:104 */       nWarpCursor(x, y);
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   private static native void getMouseDeltas(IntBuffer paramIntBuffer);
/*  85:    */   
/*  86:    */   private static native void nWarpCursor(int paramInt1, int paramInt2);
/*  87:    */   
/*  88:    */   static native void nGrabMouse(boolean paramBoolean);
/*  89:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXMouseEventQueue
 * JD-Core Version:    0.7.0.1
 */