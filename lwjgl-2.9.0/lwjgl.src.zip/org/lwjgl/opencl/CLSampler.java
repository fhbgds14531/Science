/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ public final class CLSampler
/*  4:   */   extends CLObjectChild<CLContext>
/*  5:   */ {
/*  6:41 */   private static final InfoUtil<CLSampler> util = CLPlatform.getInfoUtilInstance(CLSampler.class, "CL_SAMPLER_UTIL");
/*  7:   */   
/*  8:   */   CLSampler(long pointer, CLContext context)
/*  9:   */   {
/* 10:44 */     super(pointer, context);
/* 11:45 */     if (isValid()) {
/* 12:46 */       context.getCLSamplerRegistry().registerObject(this);
/* 13:   */     }
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getInfoInt(int param_name)
/* 17:   */   {
/* 18:59 */     return util.getInfoInt(this, param_name);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public long getInfoLong(int param_name)
/* 22:   */   {
/* 23:71 */     return util.getInfoLong(this, param_name);
/* 24:   */   }
/* 25:   */   
/* 26:   */   int release()
/* 27:   */   {
/* 28:   */     try
/* 29:   */     {
/* 30:78 */       return super.release();
/* 31:   */     }
/* 32:   */     finally
/* 33:   */     {
/* 34:80 */       if (!isValid()) {
/* 35:81 */         ((CLContext)getParent()).getCLSamplerRegistry().unregisterObject(this);
/* 36:   */       }
/* 37:   */     }
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLSampler
 * JD-Core Version:    0.7.0.1
 */