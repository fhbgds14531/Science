package org.lwjgl.opencl;

public final class KHRInitializeMemory
{
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_KHR = 8206;
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_LOCAL_KHR = 1;
  public static final int CL_CONTEXT_MEMORY_INITIALIZE_PRIVATE_KHR = 2;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRInitializeMemory
 * JD-Core Version:    0.7.0.1
 */