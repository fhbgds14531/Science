package org.lwjgl.opencl;

public final class KHRFp64
{
  public static final int CL_DEVICE_DOUBLE_FP_CONFIG = 4146;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRFp64
 * JD-Core Version:    0.7.0.1
 */