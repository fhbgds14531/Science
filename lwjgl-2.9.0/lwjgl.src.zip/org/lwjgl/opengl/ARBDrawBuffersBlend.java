/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBDrawBuffersBlend
/*  6:   */ {
/*  7:   */   public static void glBlendEquationiARB(int buf, int mode)
/*  8:   */   {
/*  9:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 10:14 */     long function_pointer = caps.glBlendEquationiARB;
/* 11:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 12:16 */     nglBlendEquationiARB(buf, mode, function_pointer);
/* 13:   */   }
/* 14:   */   
/* 15:   */   static native void nglBlendEquationiARB(int paramInt1, int paramInt2, long paramLong);
/* 16:   */   
/* 17:   */   public static void glBlendEquationSeparateiARB(int buf, int modeRGB, int modeAlpha)
/* 18:   */   {
/* 19:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:22 */     long function_pointer = caps.glBlendEquationSeparateiARB;
/* 21:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:24 */     nglBlendEquationSeparateiARB(buf, modeRGB, modeAlpha, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglBlendEquationSeparateiARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 26:   */   
/* 27:   */   public static void glBlendFunciARB(int buf, int src, int dst)
/* 28:   */   {
/* 29:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:30 */     long function_pointer = caps.glBlendFunciARB;
/* 31:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:32 */     nglBlendFunciARB(buf, src, dst, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglBlendFunciARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 36:   */   
/* 37:   */   public static void glBlendFuncSeparateiARB(int buf, int srcRGB, int dstRGB, int srcAlpha, int dstAlpha)
/* 38:   */   {
/* 39:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 40:38 */     long function_pointer = caps.glBlendFuncSeparateiARB;
/* 41:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 42:40 */     nglBlendFuncSeparateiARB(buf, srcRGB, dstRGB, srcAlpha, dstAlpha, function_pointer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   static native void nglBlendFuncSeparateiARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 46:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDrawBuffersBlend
 * JD-Core Version:    0.7.0.1
 */