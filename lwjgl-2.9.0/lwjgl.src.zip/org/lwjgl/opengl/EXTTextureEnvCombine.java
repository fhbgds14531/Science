package org.lwjgl.opengl;

public final class EXTTextureEnvCombine
{
  public static final int GL_COMBINE_EXT = 34160;
  public static final int GL_COMBINE_RGB_EXT = 34161;
  public static final int GL_COMBINE_ALPHA_EXT = 34162;
  public static final int GL_SOURCE0_RGB_EXT = 34176;
  public static final int GL_SOURCE1_RGB_EXT = 34177;
  public static final int GL_SOURCE2_RGB_EXT = 34178;
  public static final int GL_SOURCE0_ALPHA_EXT = 34184;
  public static final int GL_SOURCE1_ALPHA_EXT = 34185;
  public static final int GL_SOURCE2_ALPHA_EXT = 34186;
  public static final int GL_OPERAND0_RGB_EXT = 34192;
  public static final int GL_OPERAND1_RGB_EXT = 34193;
  public static final int GL_OPERAND2_RGB_EXT = 34194;
  public static final int GL_OPERAND0_ALPHA_EXT = 34200;
  public static final int GL_OPERAND1_ALPHA_EXT = 34201;
  public static final int GL_OPERAND2_ALPHA_EXT = 34202;
  public static final int GL_RGB_SCALE_EXT = 34163;
  public static final int GL_ADD_SIGNED_EXT = 34164;
  public static final int GL_INTERPOLATE_EXT = 34165;
  public static final int GL_CONSTANT_EXT = 34166;
  public static final int GL_PRIMARY_COLOR_EXT = 34167;
  public static final int GL_PREVIOUS_EXT = 34168;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureEnvCombine
 * JD-Core Version:    0.7.0.1
 */