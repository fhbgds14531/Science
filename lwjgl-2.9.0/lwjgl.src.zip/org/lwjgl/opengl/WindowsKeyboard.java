/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.CharBuffer;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ 
/*   7:    */ final class WindowsKeyboard
/*   8:    */ {
/*   9:    */   private static final int MAPVK_VK_TO_VSC = 0;
/*  10:    */   private static final int BUFFER_SIZE = 50;
/*  11:    */   private final long hwnd;
/*  12: 51 */   private final byte[] key_down_buffer = new byte[256];
/*  13: 52 */   private final byte[] virt_key_down_buffer = new byte[256];
/*  14: 53 */   private final EventQueue event_queue = new EventQueue(18);
/*  15: 54 */   private final ByteBuffer tmp_event = ByteBuffer.allocate(18);
/*  16:    */   private boolean grabbed;
/*  17:    */   private boolean has_retained_event;
/*  18:    */   private int retained_key_code;
/*  19:    */   private byte retained_state;
/*  20:    */   private int retained_char;
/*  21:    */   private long retained_millis;
/*  22:    */   private boolean retained_repeat;
/*  23:    */   
/*  24:    */   WindowsKeyboard(long hwnd)
/*  25:    */     throws LWJGLException
/*  26:    */   {
/*  27: 66 */     this.hwnd = hwnd;
/*  28:    */   }
/*  29:    */   
/*  30:    */   private static native boolean isWindowsNT();
/*  31:    */   
/*  32:    */   public void destroy() {}
/*  33:    */   
/*  34:    */   boolean isKeyDown(int lwjgl_keycode)
/*  35:    */   {
/*  36: 74 */     return this.key_down_buffer[lwjgl_keycode] == 1;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void grab(boolean grab)
/*  40:    */   {
/*  41: 78 */     if (grab)
/*  42:    */     {
/*  43: 79 */       if (!this.grabbed) {
/*  44: 80 */         this.grabbed = true;
/*  45:    */       }
/*  46:    */     }
/*  47: 83 */     else if (this.grabbed) {
/*  48: 84 */       this.grabbed = false;
/*  49:    */     }
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void poll(ByteBuffer keyDownBuffer)
/*  53:    */   {
/*  54: 90 */     int old_position = keyDownBuffer.position();
/*  55: 91 */     keyDownBuffer.put(this.key_down_buffer);
/*  56: 92 */     keyDownBuffer.position(old_position);
/*  57:    */   }
/*  58:    */   
/*  59:    */   private static native int MapVirtualKey(int paramInt1, int paramInt2);
/*  60:    */   
/*  61:    */   private static native int ToUnicode(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, CharBuffer paramCharBuffer, int paramInt3, int paramInt4);
/*  62:    */   
/*  63:    */   private static native int ToAscii(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, int paramInt3);
/*  64:    */   
/*  65:    */   private static native int GetKeyboardState(ByteBuffer paramByteBuffer);
/*  66:    */   
/*  67:    */   private static native short GetKeyState(int paramInt);
/*  68:    */   
/*  69:    */   private static native short GetAsyncKeyState(int paramInt);
/*  70:    */   
/*  71:    */   private void putEvent(int keycode, byte state, int ch, long millis, boolean repeat)
/*  72:    */   {
/*  73:103 */     this.tmp_event.clear();
/*  74:104 */     this.tmp_event.putInt(keycode).put(state).putInt(ch).putLong(millis * 1000000L).put((byte)(repeat ? 1 : 0));
/*  75:105 */     this.tmp_event.flip();
/*  76:106 */     this.event_queue.putEvent(this.tmp_event);
/*  77:    */   }
/*  78:    */   
/*  79:    */   private boolean checkShiftKey(int virt_key, byte state)
/*  80:    */   {
/*  81:110 */     int key_state = GetKeyState(virt_key) >>> 15 & 0x1;
/*  82:111 */     int lwjgl_code = WindowsKeycodes.mapVirtualKeyToLWJGLCode(virt_key);
/*  83:112 */     return (this.key_down_buffer[lwjgl_code] == 1 - state) && (key_state == state);
/*  84:    */   }
/*  85:    */   
/*  86:    */   private int translateShift(int scan_code, byte state)
/*  87:    */   {
/*  88:116 */     if (checkShiftKey(160, state)) {
/*  89:117 */       return 160;
/*  90:    */     }
/*  91:118 */     if (checkShiftKey(161, state)) {
/*  92:119 */       return 161;
/*  93:    */     }
/*  94:121 */     if (scan_code == 42) {
/*  95:122 */       return 160;
/*  96:    */     }
/*  97:124 */     if (scan_code == 54) {
/*  98:125 */       return 161;
/*  99:    */     }
/* 100:127 */     return 160;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private int translateExtended(int virt_key, int scan_code, byte state, boolean extended)
/* 104:    */   {
/* 105:133 */     switch (virt_key)
/* 106:    */     {
/* 107:    */     case 16: 
/* 108:135 */       return translateShift(scan_code, state);
/* 109:    */     case 17: 
/* 110:137 */       return extended ? 163 : 162;
/* 111:    */     case 18: 
/* 112:139 */       return extended ? 165 : 164;
/* 113:    */     }
/* 114:141 */     return virt_key;
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void flushRetained()
/* 118:    */   {
/* 119:146 */     if (this.has_retained_event)
/* 120:    */     {
/* 121:147 */       this.has_retained_event = false;
/* 122:148 */       putEvent(this.retained_key_code, this.retained_state, this.retained_char, this.retained_millis, this.retained_repeat);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static boolean isKeyPressed(int state)
/* 127:    */   {
/* 128:153 */     return (state & 0x1) == 1;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void handleKey(int virt_key, int scan_code, boolean extended, byte event_state, long millis, boolean repeat)
/* 132:    */   {
/* 133:157 */     virt_key = translateExtended(virt_key, scan_code, event_state, extended);
/* 134:158 */     if ((!repeat) && (isKeyPressed(event_state) == isKeyPressed(this.virt_key_down_buffer[virt_key]))) {
/* 135:159 */       return;
/* 136:    */     }
/* 137:161 */     flushRetained();
/* 138:162 */     this.has_retained_event = true;
/* 139:163 */     int keycode = WindowsKeycodes.mapVirtualKeyToLWJGLCode(virt_key);
/* 140:164 */     if (keycode < this.key_down_buffer.length)
/* 141:    */     {
/* 142:165 */       this.key_down_buffer[keycode] = event_state;
/* 143:166 */       this.virt_key_down_buffer[virt_key] = event_state;
/* 144:    */     }
/* 145:168 */     this.retained_key_code = keycode;
/* 146:169 */     this.retained_state = event_state;
/* 147:170 */     this.retained_millis = millis;
/* 148:171 */     this.retained_char = 0;
/* 149:172 */     this.retained_repeat = repeat;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void fireLostKeyEvents()
/* 153:    */   {
/* 154:177 */     for (int i = 0; i < this.virt_key_down_buffer.length; i++) {
/* 155:178 */       if ((isKeyPressed(this.virt_key_down_buffer[i])) && ((GetAsyncKeyState(i) & 0x8000) == 0)) {
/* 156:179 */         handleKey(i, 0, false, (byte)0, System.currentTimeMillis(), false);
/* 157:    */       }
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void handleChar(int event_char, long millis, boolean repeat)
/* 162:    */   {
/* 163:184 */     if ((this.has_retained_event) && (this.retained_char != 0)) {
/* 164:185 */       flushRetained();
/* 165:    */     }
/* 166:186 */     if (!this.has_retained_event) {
/* 167:187 */       putEvent(0, (byte)0, event_char, millis, repeat);
/* 168:    */     } else {
/* 169:189 */       this.retained_char = event_char;
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void read(ByteBuffer buffer)
/* 174:    */   {
/* 175:193 */     flushRetained();
/* 176:194 */     this.event_queue.copyEvents(buffer);
/* 177:    */   }
/* 178:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsKeyboard
 * JD-Core Version:    0.7.0.1
 */