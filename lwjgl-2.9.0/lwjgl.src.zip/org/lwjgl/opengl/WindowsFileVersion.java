/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ final class WindowsFileVersion
/*  4:   */ {
/*  5:   */   private final int product_version_ms;
/*  6:   */   private final int product_version_ls;
/*  7:   */   
/*  8:   */   WindowsFileVersion(int product_version_ms, int product_version_ls)
/*  9:   */   {
/* 10:43 */     this.product_version_ms = product_version_ms;
/* 11:44 */     this.product_version_ls = product_version_ls;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public String toString()
/* 15:   */   {
/* 16:48 */     int f1 = this.product_version_ms >> 16 & 0xFFFF;
/* 17:49 */     int f2 = this.product_version_ms & 0xFFFF;
/* 18:50 */     int f3 = this.product_version_ls >> 16 & 0xFFFF;
/* 19:51 */     int f4 = this.product_version_ls & 0xFFFF;
/* 20:52 */     return f1 + "." + f2 + "." + f3 + "." + f4;
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsFileVersion
 * JD-Core Version:    0.7.0.1
 */