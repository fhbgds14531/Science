/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBCopyBuffer
/*  4:   */ {
/*  5:   */   public static final int GL_COPY_READ_BUFFER = 36662;
/*  6:   */   public static final int GL_COPY_WRITE_BUFFER = 36663;
/*  7:   */   
/*  8:   */   public static void glCopyBufferSubData(int readTarget, int writeTarget, long readOffset, long writeOffset, long size)
/*  9:   */   {
/* 10:23 */     GL31.glCopyBufferSubData(readTarget, writeTarget, readOffset, writeOffset, size);
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBCopyBuffer
 * JD-Core Version:    0.7.0.1
 */