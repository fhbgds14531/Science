package org.lwjgl.opengl;

public final class EXTRescaleNormal
{
  public static final int GL_RESCALE_NORMAL_EXT = 32826;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTRescaleNormal
 * JD-Core Version:    0.7.0.1
 */