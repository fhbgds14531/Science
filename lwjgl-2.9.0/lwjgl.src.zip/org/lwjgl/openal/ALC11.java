/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import org.lwjgl.BufferUtils;
/*   7:    */ import org.lwjgl.LWJGLException;
/*   8:    */ import org.lwjgl.LWJGLUtil;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class ALC11
/*  12:    */ {
/*  13:    */   public static final int ALC_DEFAULT_ALL_DEVICES_SPECIFIER = 4114;
/*  14:    */   public static final int ALC_ALL_DEVICES_SPECIFIER = 4115;
/*  15:    */   public static final int ALC_CAPTURE_DEVICE_SPECIFIER = 784;
/*  16:    */   public static final int ALC_CAPTURE_DEFAULT_DEVICE_SPECIFIER = 785;
/*  17:    */   public static final int ALC_CAPTURE_SAMPLES = 786;
/*  18:    */   public static final int ALC_MONO_SOURCES = 4112;
/*  19:    */   public static final int ALC_STEREO_SOURCES = 4113;
/*  20:    */   
/*  21:    */   public static ALCdevice alcCaptureOpenDevice(String devicename, int frequency, int format, int buffersize)
/*  22:    */   {
/*  23: 95 */     ByteBuffer buffer = MemoryUtil.encodeASCII(devicename);
/*  24: 96 */     long device_address = nalcCaptureOpenDevice(MemoryUtil.getAddressSafe(buffer), frequency, format, buffersize);
/*  25: 97 */     if (device_address != 0L)
/*  26:    */     {
/*  27: 98 */       ALCdevice device = new ALCdevice(device_address);
/*  28: 99 */       synchronized (ALC10.devices)
/*  29:    */       {
/*  30:100 */         ALC10.devices.put(Long.valueOf(device_address), device);
/*  31:    */       }
/*  32:102 */       return device;
/*  33:    */     }
/*  34:104 */     return null;
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static native long nalcCaptureOpenDevice(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*  38:    */   
/*  39:    */   public static boolean alcCaptureCloseDevice(ALCdevice device)
/*  40:    */   {
/*  41:118 */     boolean result = nalcCaptureCloseDevice(ALC10.getDevice(device));
/*  42:119 */     synchronized (ALC10.devices)
/*  43:    */     {
/*  44:120 */       device.setInvalid();
/*  45:121 */       ALC10.devices.remove(new Long(device.device));
/*  46:    */     }
/*  47:123 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   static native boolean nalcCaptureCloseDevice(long paramLong);
/*  51:    */   
/*  52:    */   public static void alcCaptureStart(ALCdevice device)
/*  53:    */   {
/*  54:138 */     nalcCaptureStart(ALC10.getDevice(device));
/*  55:    */   }
/*  56:    */   
/*  57:    */   static native void nalcCaptureStart(long paramLong);
/*  58:    */   
/*  59:    */   public static void alcCaptureStop(ALCdevice device)
/*  60:    */   {
/*  61:150 */     nalcCaptureStop(ALC10.getDevice(device));
/*  62:    */   }
/*  63:    */   
/*  64:    */   static native void nalcCaptureStop(long paramLong);
/*  65:    */   
/*  66:    */   public static void alcCaptureSamples(ALCdevice device, ByteBuffer buffer, int samples)
/*  67:    */   {
/*  68:166 */     nalcCaptureSamples(ALC10.getDevice(device), MemoryUtil.getAddress(buffer), samples);
/*  69:    */   }
/*  70:    */   
/*  71:    */   static native void nalcCaptureSamples(long paramLong1, long paramLong2, int paramInt);
/*  72:    */   
/*  73:    */   static native void initNativeStubs()
/*  74:    */     throws LWJGLException;
/*  75:    */   
/*  76:    */   static boolean initialize()
/*  77:    */   {
/*  78:    */     try
/*  79:    */     {
/*  80:178 */       IntBuffer ib = BufferUtils.createIntBuffer(2);
/*  81:179 */       ALC10.alcGetInteger(AL.getDevice(), 4096, ib);
/*  82:180 */       ib.position(1);
/*  83:181 */       ALC10.alcGetInteger(AL.getDevice(), 4097, ib);
/*  84:    */       
/*  85:183 */       int major = ib.get(0);
/*  86:184 */       int minor = ib.get(1);
/*  87:187 */       if (major >= 1) {
/*  88:190 */         if ((major > 1) || (minor >= 1))
/*  89:    */         {
/*  90:191 */           initNativeStubs();
/*  91:192 */           AL11.initNativeStubs();
/*  92:    */         }
/*  93:    */       }
/*  94:    */     }
/*  95:    */     catch (LWJGLException le)
/*  96:    */     {
/*  97:196 */       LWJGLUtil.log("failed to initialize ALC11: " + le);
/*  98:197 */       return false;
/*  99:    */     }
/* 100:199 */     return true;
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.ALC11
 * JD-Core Version:    0.7.0.1
 */