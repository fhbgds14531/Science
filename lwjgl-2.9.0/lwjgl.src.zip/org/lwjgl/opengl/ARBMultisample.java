/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBMultisample
/*  6:   */ {
/*  7:   */   public static final int GL_MULTISAMPLE_ARB = 32925;
/*  8:   */   public static final int GL_SAMPLE_ALPHA_TO_COVERAGE_ARB = 32926;
/*  9:   */   public static final int GL_SAMPLE_ALPHA_TO_ONE_ARB = 32927;
/* 10:   */   public static final int GL_SAMPLE_COVERAGE_ARB = 32928;
/* 11:   */   public static final int GL_SAMPLE_BUFFERS_ARB = 32936;
/* 12:   */   public static final int GL_SAMPLES_ARB = 32937;
/* 13:   */   public static final int GL_SAMPLE_COVERAGE_VALUE_ARB = 32938;
/* 14:   */   public static final int GL_SAMPLE_COVERAGE_INVERT_ARB = 32939;
/* 15:   */   public static final int GL_MULTISAMPLE_BIT_ARB = 536870912;
/* 16:   */   
/* 17:   */   public static void glSampleCoverageARB(float value, boolean invert)
/* 18:   */   {
/* 19:23 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:24 */     long function_pointer = caps.glSampleCoverageARB;
/* 21:25 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:26 */     nglSampleCoverageARB(value, invert, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglSampleCoverageARB(float paramFloat, boolean paramBoolean, long paramLong);
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBMultisample
 * JD-Core Version:    0.7.0.1
 */