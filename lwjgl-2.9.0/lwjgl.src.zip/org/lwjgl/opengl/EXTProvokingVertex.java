/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTProvokingVertex
/*  6:   */ {
/*  7:   */   public static final int GL_FIRST_VERTEX_CONVENTION_EXT = 36429;
/*  8:   */   public static final int GL_LAST_VERTEX_CONVENTION_EXT = 36430;
/*  9:   */   public static final int GL_PROVOKING_VERTEX_EXT = 36431;
/* 10:   */   public static final int GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION_EXT = 36428;
/* 11:   */   
/* 12:   */   public static void glProvokingVertexEXT(int mode)
/* 13:   */   {
/* 14:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:27 */     long function_pointer = caps.glProvokingVertexEXT;
/* 16:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:29 */     nglProvokingVertexEXT(mode, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglProvokingVertexEXT(int paramInt, long paramLong);
/* 21:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTProvokingVertex
 * JD-Core Version:    0.7.0.1
 */