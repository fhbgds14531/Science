package org.lwjgl.opencl;

public final class KHRImage2DFromBuffer
{
  public static final int CL_DEVICE_IMAGE_PITCH_ALIGNMENT = 4170;
  public static final int CL_DEVICE_IMAGE_BASE_ADDRESS_ALIGNMENT = 4171;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRImage2DFromBuffer
 * JD-Core Version:    0.7.0.1
 */