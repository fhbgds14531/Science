/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.lang.reflect.Modifier;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import org.lwjgl.BufferUtils;
/*   9:    */ import org.lwjgl.LWJGLException;
/*  10:    */ import org.lwjgl.Sys;
/*  11:    */ import org.lwjgl.opengl.Display;
/*  12:    */ import org.lwjgl.opengl.InputImplementation;
/*  13:    */ 
/*  14:    */ public class Keyboard
/*  15:    */ {
/*  16:    */   public static final int EVENT_SIZE = 18;
/*  17:    */   public static final int CHAR_NONE = 0;
/*  18:    */   public static final int KEY_NONE = 0;
/*  19:    */   public static final int KEY_ESCAPE = 1;
/*  20:    */   public static final int KEY_1 = 2;
/*  21:    */   public static final int KEY_2 = 3;
/*  22:    */   public static final int KEY_3 = 4;
/*  23:    */   public static final int KEY_4 = 5;
/*  24:    */   public static final int KEY_5 = 6;
/*  25:    */   public static final int KEY_6 = 7;
/*  26:    */   public static final int KEY_7 = 8;
/*  27:    */   public static final int KEY_8 = 9;
/*  28:    */   public static final int KEY_9 = 10;
/*  29:    */   public static final int KEY_0 = 11;
/*  30:    */   public static final int KEY_MINUS = 12;
/*  31:    */   public static final int KEY_EQUALS = 13;
/*  32:    */   public static final int KEY_BACK = 14;
/*  33:    */   public static final int KEY_TAB = 15;
/*  34:    */   public static final int KEY_Q = 16;
/*  35:    */   public static final int KEY_W = 17;
/*  36:    */   public static final int KEY_E = 18;
/*  37:    */   public static final int KEY_R = 19;
/*  38:    */   public static final int KEY_T = 20;
/*  39:    */   public static final int KEY_Y = 21;
/*  40:    */   public static final int KEY_U = 22;
/*  41:    */   public static final int KEY_I = 23;
/*  42:    */   public static final int KEY_O = 24;
/*  43:    */   public static final int KEY_P = 25;
/*  44:    */   public static final int KEY_LBRACKET = 26;
/*  45:    */   public static final int KEY_RBRACKET = 27;
/*  46:    */   public static final int KEY_RETURN = 28;
/*  47:    */   public static final int KEY_LCONTROL = 29;
/*  48:    */   public static final int KEY_A = 30;
/*  49:    */   public static final int KEY_S = 31;
/*  50:    */   public static final int KEY_D = 32;
/*  51:    */   public static final int KEY_F = 33;
/*  52:    */   public static final int KEY_G = 34;
/*  53:    */   public static final int KEY_H = 35;
/*  54:    */   public static final int KEY_J = 36;
/*  55:    */   public static final int KEY_K = 37;
/*  56:    */   public static final int KEY_L = 38;
/*  57:    */   public static final int KEY_SEMICOLON = 39;
/*  58:    */   public static final int KEY_APOSTROPHE = 40;
/*  59:    */   public static final int KEY_GRAVE = 41;
/*  60:    */   public static final int KEY_LSHIFT = 42;
/*  61:    */   public static final int KEY_BACKSLASH = 43;
/*  62:    */   public static final int KEY_Z = 44;
/*  63:    */   public static final int KEY_X = 45;
/*  64:    */   public static final int KEY_C = 46;
/*  65:    */   public static final int KEY_V = 47;
/*  66:    */   public static final int KEY_B = 48;
/*  67:    */   public static final int KEY_N = 49;
/*  68:    */   public static final int KEY_M = 50;
/*  69:    */   public static final int KEY_COMMA = 51;
/*  70:    */   public static final int KEY_PERIOD = 52;
/*  71:    */   public static final int KEY_SLASH = 53;
/*  72:    */   public static final int KEY_RSHIFT = 54;
/*  73:    */   public static final int KEY_MULTIPLY = 55;
/*  74:    */   public static final int KEY_LMENU = 56;
/*  75:    */   public static final int KEY_SPACE = 57;
/*  76:    */   public static final int KEY_CAPITAL = 58;
/*  77:    */   public static final int KEY_F1 = 59;
/*  78:    */   public static final int KEY_F2 = 60;
/*  79:    */   public static final int KEY_F3 = 61;
/*  80:    */   public static final int KEY_F4 = 62;
/*  81:    */   public static final int KEY_F5 = 63;
/*  82:    */   public static final int KEY_F6 = 64;
/*  83:    */   public static final int KEY_F7 = 65;
/*  84:    */   public static final int KEY_F8 = 66;
/*  85:    */   public static final int KEY_F9 = 67;
/*  86:    */   public static final int KEY_F10 = 68;
/*  87:    */   public static final int KEY_NUMLOCK = 69;
/*  88:    */   public static final int KEY_SCROLL = 70;
/*  89:    */   public static final int KEY_NUMPAD7 = 71;
/*  90:    */   public static final int KEY_NUMPAD8 = 72;
/*  91:    */   public static final int KEY_NUMPAD9 = 73;
/*  92:    */   public static final int KEY_SUBTRACT = 74;
/*  93:    */   public static final int KEY_NUMPAD4 = 75;
/*  94:    */   public static final int KEY_NUMPAD5 = 76;
/*  95:    */   public static final int KEY_NUMPAD6 = 77;
/*  96:    */   public static final int KEY_ADD = 78;
/*  97:    */   public static final int KEY_NUMPAD1 = 79;
/*  98:    */   public static final int KEY_NUMPAD2 = 80;
/*  99:    */   public static final int KEY_NUMPAD3 = 81;
/* 100:    */   public static final int KEY_NUMPAD0 = 82;
/* 101:    */   public static final int KEY_DECIMAL = 83;
/* 102:    */   public static final int KEY_F11 = 87;
/* 103:    */   public static final int KEY_F12 = 88;
/* 104:    */   public static final int KEY_F13 = 100;
/* 105:    */   public static final int KEY_F14 = 101;
/* 106:    */   public static final int KEY_F15 = 102;
/* 107:    */   public static final int KEY_F16 = 103;
/* 108:    */   public static final int KEY_F17 = 104;
/* 109:    */   public static final int KEY_F18 = 105;
/* 110:    */   public static final int KEY_KANA = 112;
/* 111:    */   public static final int KEY_F19 = 113;
/* 112:    */   public static final int KEY_CONVERT = 121;
/* 113:    */   public static final int KEY_NOCONVERT = 123;
/* 114:    */   public static final int KEY_YEN = 125;
/* 115:    */   public static final int KEY_NUMPADEQUALS = 141;
/* 116:    */   public static final int KEY_CIRCUMFLEX = 144;
/* 117:    */   public static final int KEY_AT = 145;
/* 118:    */   public static final int KEY_COLON = 146;
/* 119:    */   public static final int KEY_UNDERLINE = 147;
/* 120:    */   public static final int KEY_KANJI = 148;
/* 121:    */   public static final int KEY_STOP = 149;
/* 122:    */   public static final int KEY_AX = 150;
/* 123:    */   public static final int KEY_UNLABELED = 151;
/* 124:    */   public static final int KEY_NUMPADENTER = 156;
/* 125:    */   public static final int KEY_RCONTROL = 157;
/* 126:    */   public static final int KEY_SECTION = 167;
/* 127:    */   public static final int KEY_NUMPADCOMMA = 179;
/* 128:    */   public static final int KEY_DIVIDE = 181;
/* 129:    */   public static final int KEY_SYSRQ = 183;
/* 130:    */   public static final int KEY_RMENU = 184;
/* 131:    */   public static final int KEY_FUNCTION = 196;
/* 132:    */   public static final int KEY_PAUSE = 197;
/* 133:    */   public static final int KEY_HOME = 199;
/* 134:    */   public static final int KEY_UP = 200;
/* 135:    */   public static final int KEY_PRIOR = 201;
/* 136:    */   public static final int KEY_LEFT = 203;
/* 137:    */   public static final int KEY_RIGHT = 205;
/* 138:    */   public static final int KEY_END = 207;
/* 139:    */   public static final int KEY_DOWN = 208;
/* 140:    */   public static final int KEY_NEXT = 209;
/* 141:    */   public static final int KEY_INSERT = 210;
/* 142:    */   public static final int KEY_DELETE = 211;
/* 143:    */   public static final int KEY_CLEAR = 218;
/* 144:    */   public static final int KEY_LMETA = 219;
/* 145:    */   /**
/* 146:    */    * @deprecated
/* 147:    */    */
/* 148:    */   public static final int KEY_LWIN = 219;
/* 149:    */   public static final int KEY_RMETA = 220;
/* 150:    */   /**
/* 151:    */    * @deprecated
/* 152:    */    */
/* 153:    */   public static final int KEY_RWIN = 220;
/* 154:    */   public static final int KEY_APPS = 221;
/* 155:    */   public static final int KEY_POWER = 222;
/* 156:    */   public static final int KEY_SLEEP = 223;
/* 157:    */   public static final int KEYBOARD_SIZE = 256;
/* 158:    */   private static final int BUFFER_SIZE = 50;
/* 159:226 */   private static final String[] keyName = new String[256];
/* 160:227 */   private static final Map<String, Integer> keyMap = new HashMap(253);
/* 161:    */   private static int counter;
/* 162:    */   
/* 163:    */   static
/* 164:    */   {
/* 165:232 */     Field[] fields = Keyboard.class.getFields();
/* 166:    */     try
/* 167:    */     {
/* 168:234 */       for (Field field : fields) {
/* 169:235 */         if ((Modifier.isStatic(field.getModifiers())) && (Modifier.isPublic(field.getModifiers())) && (Modifier.isFinal(field.getModifiers())) && (field.getType().equals(Integer.TYPE)) && (field.getName().startsWith("KEY_")) && (!field.getName().endsWith("WIN")))
/* 170:    */         {
/* 171:242 */           int key = field.getInt(null);
/* 172:243 */           String name = field.getName().substring(4);
/* 173:244 */           keyName[key] = name;
/* 174:245 */           keyMap.put(name, Integer.valueOf(key));
/* 175:246 */           counter += 1;
/* 176:    */         }
/* 177:    */       }
/* 178:    */     }
/* 179:    */     catch (Exception e) {}
/* 180:    */   }
/* 181:    */   
/* 182:256 */   private static final int keyCount = counter;
/* 183:    */   private static boolean created;
/* 184:    */   private static boolean repeat_enabled;
/* 185:265 */   private static final ByteBuffer keyDownBuffer = BufferUtils.createByteBuffer(256);
/* 186:    */   private static ByteBuffer readBuffer;
/* 187:275 */   private static KeyEvent current_event = new KeyEvent(null);
/* 188:278 */   private static KeyEvent tmp_event = new KeyEvent(null);
/* 189:    */   private static boolean initialized;
/* 190:    */   private static InputImplementation implementation;
/* 191:    */   
/* 192:    */   private static void initialize()
/* 193:    */   {
/* 194:295 */     if (initialized) {
/* 195:296 */       return;
/* 196:    */     }
/* 197:297 */     Sys.initialize();
/* 198:298 */     initialized = true;
/* 199:    */   }
/* 200:    */   
/* 201:    */   private static void create(InputImplementation impl)
/* 202:    */     throws LWJGLException
/* 203:    */   {
/* 204:308 */     if (created) {
/* 205:309 */       return;
/* 206:    */     }
/* 207:310 */     if (!initialized) {
/* 208:311 */       initialize();
/* 209:    */     }
/* 210:312 */     implementation = impl;
/* 211:313 */     implementation.createKeyboard();
/* 212:314 */     created = true;
/* 213:315 */     readBuffer = ByteBuffer.allocate(900);
/* 214:316 */     reset();
/* 215:    */   }
/* 216:    */   
/* 217:    */   public static void create()
/* 218:    */     throws LWJGLException
/* 219:    */   {
/* 220:326 */     synchronized (OpenGLPackageAccess.global_lock)
/* 221:    */     {
/* 222:327 */       if (!Display.isCreated()) {
/* 223:327 */         throw new IllegalStateException("Display must be created.");
/* 224:    */       }
/* 225:329 */       create(OpenGLPackageAccess.createImplementation());
/* 226:    */     }
/* 227:    */   }
/* 228:    */   
/* 229:    */   private static void reset()
/* 230:    */   {
/* 231:334 */     readBuffer.limit(0);
/* 232:335 */     for (int i = 0; i < keyDownBuffer.remaining(); i++) {
/* 233:336 */       keyDownBuffer.put(i, (byte)0);
/* 234:    */     }
/* 235:337 */     current_event.reset();
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static boolean isCreated()
/* 239:    */   {
/* 240:344 */     synchronized (OpenGLPackageAccess.global_lock)
/* 241:    */     {
/* 242:345 */       return created;
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   public static void destroy()
/* 247:    */   {
/* 248:353 */     synchronized (OpenGLPackageAccess.global_lock)
/* 249:    */     {
/* 250:354 */       if (!created) {
/* 251:355 */         return;
/* 252:    */       }
/* 253:356 */       created = false;
/* 254:357 */       implementation.destroyKeyboard();
/* 255:358 */       reset();
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   public static void poll()
/* 260:    */   {
/* 261:384 */     synchronized (OpenGLPackageAccess.global_lock)
/* 262:    */     {
/* 263:385 */       if (!created) {
/* 264:386 */         throw new IllegalStateException("Keyboard must be created before you can poll the device");
/* 265:    */       }
/* 266:387 */       implementation.pollKeyboard(keyDownBuffer);
/* 267:388 */       read();
/* 268:    */     }
/* 269:    */   }
/* 270:    */   
/* 271:    */   private static void read()
/* 272:    */   {
/* 273:393 */     readBuffer.compact();
/* 274:394 */     implementation.readKeyboard(readBuffer);
/* 275:395 */     readBuffer.flip();
/* 276:    */   }
/* 277:    */   
/* 278:    */   public static boolean isKeyDown(int key)
/* 279:    */   {
/* 280:404 */     synchronized (OpenGLPackageAccess.global_lock)
/* 281:    */     {
/* 282:405 */       if (!created) {
/* 283:406 */         throw new IllegalStateException("Keyboard must be created before you can query key state");
/* 284:    */       }
/* 285:407 */       return keyDownBuffer.get(key) != 0;
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   public static synchronized String getKeyName(int key)
/* 290:    */   {
/* 291:429 */     return keyName[key];
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static synchronized int getKeyIndex(String keyName)
/* 295:    */   {
/* 296:437 */     Integer ret = (Integer)keyMap.get(keyName);
/* 297:438 */     if (ret == null) {
/* 298:439 */       return 0;
/* 299:    */     }
/* 300:441 */     return ret.intValue();
/* 301:    */   }
/* 302:    */   
/* 303:    */   public static int getNumKeyboardEvents()
/* 304:    */   {
/* 305:449 */     synchronized (OpenGLPackageAccess.global_lock)
/* 306:    */     {
/* 307:450 */       if (!created) {
/* 308:451 */         throw new IllegalStateException("Keyboard must be created before you can read events");
/* 309:    */       }
/* 310:452 */       int old_position = readBuffer.position();
/* 311:453 */       int num_events = 0;
/* 312:454 */       while ((readNext(tmp_event)) && ((!tmp_event.repeat) || (repeat_enabled))) {
/* 313:455 */         num_events++;
/* 314:    */       }
/* 315:456 */       readBuffer.position(old_position);
/* 316:457 */       return num_events;
/* 317:    */     }
/* 318:    */   }
/* 319:    */   
/* 320:    */   public static boolean next()
/* 321:    */   {
/* 322:473 */     synchronized (OpenGLPackageAccess.global_lock)
/* 323:    */     {
/* 324:474 */       if (!created) {
/* 325:475 */         throw new IllegalStateException("Keyboard must be created before you can read events");
/* 326:    */       }
/* 327:    */       boolean result;
/* 328:478 */       while (((result = readNext(current_event))) && (current_event.repeat) && (!repeat_enabled)) {}
/* 329:480 */       return result;
/* 330:    */     }
/* 331:    */   }
/* 332:    */   
/* 333:    */   public static void enableRepeatEvents(boolean enable)
/* 334:    */   {
/* 335:493 */     synchronized (OpenGLPackageAccess.global_lock)
/* 336:    */     {
/* 337:494 */       repeat_enabled = enable;
/* 338:    */     }
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static boolean areRepeatEventsEnabled()
/* 342:    */   {
/* 343:505 */     synchronized (OpenGLPackageAccess.global_lock)
/* 344:    */     {
/* 345:506 */       return repeat_enabled;
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:    */   private static boolean readNext(KeyEvent event)
/* 350:    */   {
/* 351:511 */     if (readBuffer.hasRemaining())
/* 352:    */     {
/* 353:512 */       event.key = (readBuffer.getInt() & 0xFF);
/* 354:513 */       event.state = (readBuffer.get() != 0);
/* 355:514 */       event.character = readBuffer.getInt();
/* 356:515 */       event.nanos = readBuffer.getLong();
/* 357:516 */       event.repeat = (readBuffer.get() == 1);
/* 358:517 */       return true;
/* 359:    */     }
/* 360:519 */     return false;
/* 361:    */   }
/* 362:    */   
/* 363:    */   public static int getKeyCount()
/* 364:    */   {
/* 365:526 */     return keyCount;
/* 366:    */   }
/* 367:    */   
/* 368:    */   public static char getEventCharacter()
/* 369:    */   {
/* 370:533 */     synchronized (OpenGLPackageAccess.global_lock)
/* 371:    */     {
/* 372:534 */       return (char)current_event.character;
/* 373:    */     }
/* 374:    */   }
/* 375:    */   
/* 376:    */   public static int getEventKey()
/* 377:    */   {
/* 378:546 */     synchronized (OpenGLPackageAccess.global_lock)
/* 379:    */     {
/* 380:547 */       return current_event.key;
/* 381:    */     }
/* 382:    */   }
/* 383:    */   
/* 384:    */   public static boolean getEventKeyState()
/* 385:    */   {
/* 386:558 */     synchronized (OpenGLPackageAccess.global_lock)
/* 387:    */     {
/* 388:559 */       return current_event.state;
/* 389:    */     }
/* 390:    */   }
/* 391:    */   
/* 392:    */   public static long getEventNanoseconds()
/* 393:    */   {
/* 394:571 */     synchronized (OpenGLPackageAccess.global_lock)
/* 395:    */     {
/* 396:572 */       return current_event.nanos;
/* 397:    */     }
/* 398:    */   }
/* 399:    */   
/* 400:    */   public static boolean isRepeatEvent()
/* 401:    */   {
/* 402:582 */     synchronized (OpenGLPackageAccess.global_lock)
/* 403:    */     {
/* 404:583 */       return current_event.repeat;
/* 405:    */     }
/* 406:    */   }
/* 407:    */   
/* 408:    */   private static final class KeyEvent
/* 409:    */   {
/* 410:    */     private int character;
/* 411:    */     private int key;
/* 412:    */     private boolean state;
/* 413:    */     private long nanos;
/* 414:    */     private boolean repeat;
/* 415:    */     
/* 416:    */     private void reset()
/* 417:    */     {
/* 418:604 */       this.character = 0;
/* 419:605 */       this.key = 0;
/* 420:606 */       this.state = false;
/* 421:607 */       this.repeat = false;
/* 422:    */     }
/* 423:    */   }
/* 424:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.Keyboard
 * JD-Core Version:    0.7.0.1
 */