/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ public final class DisplayMode
/*   4:    */ {
/*   5:    */   private final int width;
/*   6:    */   private final int height;
/*   7:    */   private final int bpp;
/*   8:    */   private final int freq;
/*   9:    */   private final boolean fullscreen;
/*  10:    */   
/*  11:    */   public DisplayMode(int width, int height)
/*  12:    */   {
/*  13: 63 */     this(width, height, 0, 0, false);
/*  14:    */   }
/*  15:    */   
/*  16:    */   DisplayMode(int width, int height, int bpp, int freq)
/*  17:    */   {
/*  18: 67 */     this(width, height, bpp, freq, true);
/*  19:    */   }
/*  20:    */   
/*  21:    */   private DisplayMode(int width, int height, int bpp, int freq, boolean fullscreen)
/*  22:    */   {
/*  23: 71 */     this.width = width;
/*  24: 72 */     this.height = height;
/*  25: 73 */     this.bpp = bpp;
/*  26: 74 */     this.freq = freq;
/*  27: 75 */     this.fullscreen = fullscreen;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean isFullscreenCapable()
/*  31:    */   {
/*  32: 80 */     return this.fullscreen;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public int getWidth()
/*  36:    */   {
/*  37: 84 */     return this.width;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public int getHeight()
/*  41:    */   {
/*  42: 88 */     return this.height;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public int getBitsPerPixel()
/*  46:    */   {
/*  47: 92 */     return this.bpp;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public int getFrequency()
/*  51:    */   {
/*  52: 96 */     return this.freq;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean equals(Object obj)
/*  56:    */   {
/*  57:105 */     if ((obj == null) || (!(obj instanceof DisplayMode))) {
/*  58:106 */       return false;
/*  59:    */     }
/*  60:109 */     DisplayMode dm = (DisplayMode)obj;
/*  61:110 */     return (dm.width == this.width) && (dm.height == this.height) && (dm.bpp == this.bpp) && (dm.freq == this.freq);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public int hashCode()
/*  65:    */   {
/*  66:122 */     return this.width ^ this.height ^ this.freq ^ this.bpp;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public String toString()
/*  70:    */   {
/*  71:131 */     StringBuilder sb = new StringBuilder(32);
/*  72:132 */     sb.append(this.width);
/*  73:133 */     sb.append(" x ");
/*  74:134 */     sb.append(this.height);
/*  75:135 */     sb.append(" x ");
/*  76:136 */     sb.append(this.bpp);
/*  77:137 */     sb.append(" @");
/*  78:138 */     sb.append(this.freq);
/*  79:139 */     sb.append("Hz");
/*  80:140 */     return sb.toString();
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.DisplayMode
 * JD-Core Version:    0.7.0.1
 */