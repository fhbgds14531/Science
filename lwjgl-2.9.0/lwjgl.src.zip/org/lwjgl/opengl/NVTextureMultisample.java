/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVTextureMultisample
/*  6:   */ {
/*  7:   */   public static final int GL_TEXTURE_COVERAGE_SAMPLES_NV = 36933;
/*  8:   */   public static final int GL_TEXTURE_COLOR_SAMPLES_NV = 36934;
/*  9:   */   
/* 10:   */   public static void glTexImage2DMultisampleCoverageNV(int target, int coverageSamples, int colorSamples, int internalFormat, int width, int height, boolean fixedSampleLocations)
/* 11:   */   {
/* 12:19 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:20 */     long function_pointer = caps.glTexImage2DMultisampleCoverageNV;
/* 14:21 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:22 */     nglTexImage2DMultisampleCoverageNV(target, coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglTexImage2DMultisampleCoverageNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, long paramLong);
/* 19:   */   
/* 20:   */   public static void glTexImage3DMultisampleCoverageNV(int target, int coverageSamples, int colorSamples, int internalFormat, int width, int height, int depth, boolean fixedSampleLocations)
/* 21:   */   {
/* 22:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:28 */     long function_pointer = caps.glTexImage3DMultisampleCoverageNV;
/* 24:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:30 */     nglTexImage3DMultisampleCoverageNV(target, coverageSamples, colorSamples, internalFormat, width, height, depth, fixedSampleLocations, function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglTexImage3DMultisampleCoverageNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, long paramLong);
/* 29:   */   
/* 30:   */   public static void glTextureImage2DMultisampleNV(int texture, int target, int samples, int internalFormat, int width, int height, boolean fixedSampleLocations)
/* 31:   */   {
/* 32:35 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:36 */     long function_pointer = caps.glTextureImage2DMultisampleNV;
/* 34:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:38 */     nglTextureImage2DMultisampleNV(texture, target, samples, internalFormat, width, height, fixedSampleLocations, function_pointer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   static native void nglTextureImage2DMultisampleNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, long paramLong);
/* 39:   */   
/* 40:   */   public static void glTextureImage3DMultisampleNV(int texture, int target, int samples, int internalFormat, int width, int height, int depth, boolean fixedSampleLocations)
/* 41:   */   {
/* 42:43 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:44 */     long function_pointer = caps.glTextureImage3DMultisampleNV;
/* 44:45 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 45:46 */     nglTextureImage3DMultisampleNV(texture, target, samples, internalFormat, width, height, depth, fixedSampleLocations, function_pointer);
/* 46:   */   }
/* 47:   */   
/* 48:   */   static native void nglTextureImage3DMultisampleNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, long paramLong);
/* 49:   */   
/* 50:   */   public static void glTextureImage2DMultisampleCoverageNV(int texture, int target, int coverageSamples, int colorSamples, int internalFormat, int width, int height, boolean fixedSampleLocations)
/* 51:   */   {
/* 52:51 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 53:52 */     long function_pointer = caps.glTextureImage2DMultisampleCoverageNV;
/* 54:53 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 55:54 */     nglTextureImage2DMultisampleCoverageNV(texture, target, coverageSamples, colorSamples, internalFormat, width, height, fixedSampleLocations, function_pointer);
/* 56:   */   }
/* 57:   */   
/* 58:   */   static native void nglTextureImage2DMultisampleCoverageNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, long paramLong);
/* 59:   */   
/* 60:   */   public static void glTextureImage3DMultisampleCoverageNV(int texture, int target, int coverageSamples, int colorSamples, int internalFormat, int width, int height, int depth, boolean fixedSampleLocations)
/* 61:   */   {
/* 62:59 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 63:60 */     long function_pointer = caps.glTextureImage3DMultisampleCoverageNV;
/* 64:61 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 65:62 */     nglTextureImage3DMultisampleCoverageNV(texture, target, coverageSamples, colorSamples, internalFormat, width, height, depth, fixedSampleLocations, function_pointer);
/* 66:   */   }
/* 67:   */   
/* 68:   */   static native void nglTextureImage3DMultisampleCoverageNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, long paramLong);
/* 69:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTextureMultisample
 * JD-Core Version:    0.7.0.1
 */