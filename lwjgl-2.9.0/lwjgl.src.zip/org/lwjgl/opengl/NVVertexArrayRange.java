/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.ByteOrder;
/*  5:   */ import java.nio.DoubleBuffer;
/*  6:   */ import java.nio.FloatBuffer;
/*  7:   */ import java.nio.IntBuffer;
/*  8:   */ import java.nio.ShortBuffer;
/*  9:   */ import org.lwjgl.BufferChecks;
/* 10:   */ import org.lwjgl.LWJGLUtil;
/* 11:   */ import org.lwjgl.MemoryUtil;
/* 12:   */ 
/* 13:   */ public final class NVVertexArrayRange
/* 14:   */ {
/* 15:   */   public static final int GL_VERTEX_ARRAY_RANGE_NV = 34077;
/* 16:   */   public static final int GL_VERTEX_ARRAY_RANGE_LENGTH_NV = 34078;
/* 17:   */   public static final int GL_VERTEX_ARRAY_RANGE_VALID_NV = 34079;
/* 18:   */   public static final int GL_MAX_VERTEX_ARRAY_RANGE_ELEMENT_NV = 34080;
/* 19:   */   public static final int GL_VERTEX_ARRAY_RANGE_POINTER_NV = 34081;
/* 20:   */   
/* 21:   */   public static void glVertexArrayRangeNV(ByteBuffer pPointer)
/* 22:   */   {
/* 23:19 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 24:20 */     long function_pointer = caps.glVertexArrayRangeNV;
/* 25:21 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 26:22 */     BufferChecks.checkDirect(pPointer);
/* 27:23 */     nglVertexArrayRangeNV(pPointer.remaining(), MemoryUtil.getAddress(pPointer), function_pointer);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static void glVertexArrayRangeNV(DoubleBuffer pPointer)
/* 31:   */   {
/* 32:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:27 */     long function_pointer = caps.glVertexArrayRangeNV;
/* 34:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:29 */     BufferChecks.checkDirect(pPointer);
/* 36:30 */     nglVertexArrayRangeNV(pPointer.remaining() << 3, MemoryUtil.getAddress(pPointer), function_pointer);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static void glVertexArrayRangeNV(FloatBuffer pPointer)
/* 40:   */   {
/* 41:33 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 42:34 */     long function_pointer = caps.glVertexArrayRangeNV;
/* 43:35 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 44:36 */     BufferChecks.checkDirect(pPointer);
/* 45:37 */     nglVertexArrayRangeNV(pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), function_pointer);
/* 46:   */   }
/* 47:   */   
/* 48:   */   public static void glVertexArrayRangeNV(IntBuffer pPointer)
/* 49:   */   {
/* 50:40 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 51:41 */     long function_pointer = caps.glVertexArrayRangeNV;
/* 52:42 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 53:43 */     BufferChecks.checkDirect(pPointer);
/* 54:44 */     nglVertexArrayRangeNV(pPointer.remaining() << 2, MemoryUtil.getAddress(pPointer), function_pointer);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public static void glVertexArrayRangeNV(ShortBuffer pPointer)
/* 58:   */   {
/* 59:47 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 60:48 */     long function_pointer = caps.glVertexArrayRangeNV;
/* 61:49 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 62:50 */     BufferChecks.checkDirect(pPointer);
/* 63:51 */     nglVertexArrayRangeNV(pPointer.remaining() << 1, MemoryUtil.getAddress(pPointer), function_pointer);
/* 64:   */   }
/* 65:   */   
/* 66:   */   static native void nglVertexArrayRangeNV(int paramInt, long paramLong1, long paramLong2);
/* 67:   */   
/* 68:   */   public static void glFlushVertexArrayRangeNV()
/* 69:   */   {
/* 70:56 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 71:57 */     long function_pointer = caps.glFlushVertexArrayRangeNV;
/* 72:58 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 73:59 */     nglFlushVertexArrayRangeNV(function_pointer);
/* 74:   */   }
/* 75:   */   
/* 76:   */   static native void nglFlushVertexArrayRangeNV(long paramLong);
/* 77:   */   
/* 78:   */   public static ByteBuffer glAllocateMemoryNV(int size, float readFrequency, float writeFrequency, float priority)
/* 79:   */   {
/* 80:64 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 81:65 */     long function_pointer = caps.glAllocateMemoryNV;
/* 82:66 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 83:67 */     ByteBuffer __result = nglAllocateMemoryNV(size, readFrequency, writeFrequency, priority, size, function_pointer);
/* 84:68 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 85:   */   }
/* 86:   */   
/* 87:   */   static native ByteBuffer nglAllocateMemoryNV(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong1, long paramLong2);
/* 88:   */   
/* 89:   */   public static void glFreeMemoryNV(ByteBuffer pointer)
/* 90:   */   {
/* 91:73 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 92:74 */     long function_pointer = caps.glFreeMemoryNV;
/* 93:75 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 94:76 */     BufferChecks.checkDirect(pointer);
/* 95:77 */     nglFreeMemoryNV(MemoryUtil.getAddress(pointer), function_pointer);
/* 96:   */   }
/* 97:   */   
/* 98:   */   static native void nglFreeMemoryNV(long paramLong1, long paramLong2);
/* 99:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexArrayRange
 * JD-Core Version:    0.7.0.1
 */