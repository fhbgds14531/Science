package org.lwjgl.opengl;

public final class SGISTextureLOD
{
  public static final int GL_TEXTURE_MIN_LOD_SGIS = 33082;
  public static final int GL_TEXTURE_MAX_LOD_SGIS = 33083;
  public static final int GL_TEXTURE_BASE_LEVEL_SGIS = 33084;
  public static final int GL_TEXTURE_MAX_LEVEL_SGIS = 33085;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.SGISTextureLOD
 * JD-Core Version:    0.7.0.1
 */