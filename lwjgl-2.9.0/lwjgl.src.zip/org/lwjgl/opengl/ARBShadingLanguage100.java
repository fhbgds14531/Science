package org.lwjgl.opengl;

public final class ARBShadingLanguage100
{
  public static final int GL_SHADING_LANGUAGE_VERSION_ARB = 35724;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShadingLanguage100
 * JD-Core Version:    0.7.0.1
 */