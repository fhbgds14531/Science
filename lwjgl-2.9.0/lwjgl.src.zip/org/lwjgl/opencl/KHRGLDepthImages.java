package org.lwjgl.opencl;

public final class KHRGLDepthImages
{
  public static final int CL_DEPTH_STENCIL = 4286;
  public static final int CL_UNORM_INT24 = 4319;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRGLDepthImages
 * JD-Core Version:    0.7.0.1
 */