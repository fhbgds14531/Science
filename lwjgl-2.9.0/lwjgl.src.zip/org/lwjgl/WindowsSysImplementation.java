/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.security.AccessController;
/*   6:    */ import java.security.PrivilegedActionException;
/*   7:    */ import java.security.PrivilegedExceptionAction;
/*   8:    */ import org.lwjgl.opengl.Display;
/*   9:    */ 
/*  10:    */ final class WindowsSysImplementation
/*  11:    */   extends DefaultSysImplementation
/*  12:    */ {
/*  13:    */   private static final int JNI_VERSION = 24;
/*  14:    */   
/*  15:    */   public int getRequiredJNIVersion()
/*  16:    */   {
/*  17: 56 */     return 24;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public long getTimerResolution()
/*  21:    */   {
/*  22: 60 */     return 1000L;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public long getTime()
/*  26:    */   {
/*  27: 64 */     return nGetTime();
/*  28:    */   }
/*  29:    */   
/*  30:    */   private static native long nGetTime();
/*  31:    */   
/*  32:    */   public boolean has64Bit()
/*  33:    */   {
/*  34: 69 */     return true;
/*  35:    */   }
/*  36:    */   
/*  37:    */   private static long getHwnd()
/*  38:    */   {
/*  39: 73 */     if (!Display.isCreated()) {
/*  40: 74 */       return 0L;
/*  41:    */     }
/*  42:    */     try
/*  43:    */     {
/*  44: 79 */       ((Long)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  45:    */       {
/*  46:    */         public Long run()
/*  47:    */           throws Exception
/*  48:    */         {
/*  49: 81 */           Method getImplementation_method = Display.class.getDeclaredMethod("getImplementation", new Class[0]);
/*  50: 82 */           getImplementation_method.setAccessible(true);
/*  51: 83 */           Object display_impl = getImplementation_method.invoke(null, new Object[0]);
/*  52: 84 */           Class<?> WindowsDisplay_class = Class.forName("org.lwjgl.opengl.WindowsDisplay");
/*  53: 85 */           Method getHwnd_method = WindowsDisplay_class.getDeclaredMethod("getHwnd", new Class[0]);
/*  54: 86 */           getHwnd_method.setAccessible(true);
/*  55: 87 */           return (Long)getHwnd_method.invoke(display_impl, new Object[0]);
/*  56:    */         }
/*  57:    */       })).longValue();
/*  58:    */     }
/*  59:    */     catch (PrivilegedActionException e)
/*  60:    */     {
/*  61: 91 */       throw new Error(e);
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void alert(String title, String message)
/*  66:    */   {
/*  67: 96 */     if (!Display.isCreated()) {
/*  68: 97 */       initCommonControls();
/*  69:    */     }
/*  70:100 */     LWJGLUtil.log(String.format("*** Alert *** %s\n%s\n", new Object[] { title, message }));
/*  71:    */     
/*  72:102 */     ByteBuffer titleText = MemoryUtil.encodeUTF16(title);
/*  73:103 */     ByteBuffer messageText = MemoryUtil.encodeUTF16(message);
/*  74:104 */     nAlert(getHwnd(), MemoryUtil.getAddress(titleText), MemoryUtil.getAddress(messageText));
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static native void nAlert(long paramLong1, long paramLong2, long paramLong3);
/*  78:    */   
/*  79:    */   private static native void initCommonControls();
/*  80:    */   
/*  81:    */   public boolean openURL(String url)
/*  82:    */   {
/*  83:    */     try
/*  84:    */     {
/*  85:111 */       LWJGLUtil.execPrivileged(new String[] { "rundll32", "url.dll,FileProtocolHandler", url });
/*  86:112 */       return true;
/*  87:    */     }
/*  88:    */     catch (Exception e)
/*  89:    */     {
/*  90:114 */       LWJGLUtil.log("Failed to open url (" + url + "): " + e.getMessage());
/*  91:    */     }
/*  92:115 */     return false;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public String getClipboard()
/*  96:    */   {
/*  97:120 */     return nGetClipboard();
/*  98:    */   }
/*  99:    */   
/* 100:    */   private static native String nGetClipboard();
/* 101:    */   
/* 102:    */   static {}
/* 103:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.WindowsSysImplementation
 * JD-Core Version:    0.7.0.1
 */