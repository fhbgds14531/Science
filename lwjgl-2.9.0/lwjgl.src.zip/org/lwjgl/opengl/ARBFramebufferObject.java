/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ 
/*   5:    */ public final class ARBFramebufferObject
/*   6:    */ {
/*   7:    */   public static final int GL_FRAMEBUFFER = 36160;
/*   8:    */   public static final int GL_READ_FRAMEBUFFER = 36008;
/*   9:    */   public static final int GL_DRAW_FRAMEBUFFER = 36009;
/*  10:    */   public static final int GL_RENDERBUFFER = 36161;
/*  11:    */   public static final int GL_STENCIL_INDEX1 = 36166;
/*  12:    */   public static final int GL_STENCIL_INDEX4 = 36167;
/*  13:    */   public static final int GL_STENCIL_INDEX8 = 36168;
/*  14:    */   public static final int GL_STENCIL_INDEX16 = 36169;
/*  15:    */   public static final int GL_RENDERBUFFER_WIDTH = 36162;
/*  16:    */   public static final int GL_RENDERBUFFER_HEIGHT = 36163;
/*  17:    */   public static final int GL_RENDERBUFFER_INTERNAL_FORMAT = 36164;
/*  18:    */   public static final int GL_RENDERBUFFER_RED_SIZE = 36176;
/*  19:    */   public static final int GL_RENDERBUFFER_GREEN_SIZE = 36177;
/*  20:    */   public static final int GL_RENDERBUFFER_BLUE_SIZE = 36178;
/*  21:    */   public static final int GL_RENDERBUFFER_ALPHA_SIZE = 36179;
/*  22:    */   public static final int GL_RENDERBUFFER_DEPTH_SIZE = 36180;
/*  23:    */   public static final int GL_RENDERBUFFER_STENCIL_SIZE = 36181;
/*  24:    */   public static final int GL_RENDERBUFFER_SAMPLES = 36011;
/*  25:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = 36048;
/*  26:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = 36049;
/*  27:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = 36050;
/*  28:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = 36051;
/*  29:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = 36052;
/*  30:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = 33296;
/*  31:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = 33297;
/*  32:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE = 33298;
/*  33:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE = 33299;
/*  34:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE = 33300;
/*  35:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE = 33301;
/*  36:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = 33302;
/*  37:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE = 33303;
/*  38:    */   public static final int GL_SRGB = 35904;
/*  39:    */   public static final int GL_UNSIGNED_NORMALIZED = 35863;
/*  40:    */   public static final int GL_FRAMEBUFFER_DEFAULT = 33304;
/*  41:    */   public static final int GL_INDEX = 33314;
/*  42:    */   public static final int GL_COLOR_ATTACHMENT0 = 36064;
/*  43:    */   public static final int GL_COLOR_ATTACHMENT1 = 36065;
/*  44:    */   public static final int GL_COLOR_ATTACHMENT2 = 36066;
/*  45:    */   public static final int GL_COLOR_ATTACHMENT3 = 36067;
/*  46:    */   public static final int GL_COLOR_ATTACHMENT4 = 36068;
/*  47:    */   public static final int GL_COLOR_ATTACHMENT5 = 36069;
/*  48:    */   public static final int GL_COLOR_ATTACHMENT6 = 36070;
/*  49:    */   public static final int GL_COLOR_ATTACHMENT7 = 36071;
/*  50:    */   public static final int GL_COLOR_ATTACHMENT8 = 36072;
/*  51:    */   public static final int GL_COLOR_ATTACHMENT9 = 36073;
/*  52:    */   public static final int GL_COLOR_ATTACHMENT10 = 36074;
/*  53:    */   public static final int GL_COLOR_ATTACHMENT11 = 36075;
/*  54:    */   public static final int GL_COLOR_ATTACHMENT12 = 36076;
/*  55:    */   public static final int GL_COLOR_ATTACHMENT13 = 36077;
/*  56:    */   public static final int GL_COLOR_ATTACHMENT14 = 36078;
/*  57:    */   public static final int GL_COLOR_ATTACHMENT15 = 36079;
/*  58:    */   public static final int GL_DEPTH_ATTACHMENT = 36096;
/*  59:    */   public static final int GL_STENCIL_ATTACHMENT = 36128;
/*  60:    */   public static final int GL_DEPTH_STENCIL_ATTACHMENT = 33306;
/*  61:    */   public static final int GL_MAX_SAMPLES = 36183;
/*  62:    */   public static final int GL_FRAMEBUFFER_COMPLETE = 36053;
/*  63:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT = 36054;
/*  64:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = 36055;
/*  65:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER = 36059;
/*  66:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER = 36060;
/*  67:    */   public static final int GL_FRAMEBUFFER_UNSUPPORTED = 36061;
/*  68:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE = 36182;
/*  69:    */   public static final int GL_FRAMEBUFFER_UNDEFINED = 33305;
/*  70:    */   public static final int GL_FRAMEBUFFER_BINDING = 36006;
/*  71:    */   public static final int GL_DRAW_FRAMEBUFFER_BINDING = 36006;
/*  72:    */   public static final int GL_READ_FRAMEBUFFER_BINDING = 36010;
/*  73:    */   public static final int GL_RENDERBUFFER_BINDING = 36007;
/*  74:    */   public static final int GL_MAX_COLOR_ATTACHMENTS = 36063;
/*  75:    */   public static final int GL_MAX_RENDERBUFFER_SIZE = 34024;
/*  76:    */   public static final int GL_INVALID_FRAMEBUFFER_OPERATION = 1286;
/*  77:    */   public static final int GL_DEPTH_STENCIL = 34041;
/*  78:    */   public static final int GL_UNSIGNED_INT_24_8 = 34042;
/*  79:    */   public static final int GL_DEPTH24_STENCIL8 = 35056;
/*  80:    */   public static final int GL_TEXTURE_STENCIL_SIZE = 35057;
/*  81:    */   
/*  82:    */   public static boolean glIsRenderbuffer(int renderbuffer)
/*  83:    */   {
/*  84:169 */     return GL30.glIsRenderbuffer(renderbuffer);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static void glBindRenderbuffer(int target, int renderbuffer)
/*  88:    */   {
/*  89:173 */     GL30.glBindRenderbuffer(target, renderbuffer);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static void glDeleteRenderbuffers(IntBuffer renderbuffers)
/*  93:    */   {
/*  94:177 */     GL30.glDeleteRenderbuffers(renderbuffers);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void glDeleteRenderbuffers(int renderbuffer)
/*  98:    */   {
/*  99:182 */     GL30.glDeleteRenderbuffers(renderbuffer);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static void glGenRenderbuffers(IntBuffer renderbuffers)
/* 103:    */   {
/* 104:186 */     GL30.glGenRenderbuffers(renderbuffers);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static int glGenRenderbuffers()
/* 108:    */   {
/* 109:191 */     return GL30.glGenRenderbuffers();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void glRenderbufferStorage(int target, int internalformat, int width, int height)
/* 113:    */   {
/* 114:195 */     GL30.glRenderbufferStorage(target, internalformat, width, height);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static void glRenderbufferStorageMultisample(int target, int samples, int internalformat, int width, int height)
/* 118:    */   {
/* 119:199 */     GL30.glRenderbufferStorageMultisample(target, samples, internalformat, width, height);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static void glGetRenderbufferParameter(int target, int pname, IntBuffer params)
/* 123:    */   {
/* 124:203 */     GL30.glGetRenderbufferParameter(target, pname, params);
/* 125:    */   }
/* 126:    */   
/* 127:    */   @Deprecated
/* 128:    */   public static int glGetRenderbufferParameter(int target, int pname)
/* 129:    */   {
/* 130:213 */     return glGetRenderbufferParameteri(target, pname);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static int glGetRenderbufferParameteri(int target, int pname)
/* 134:    */   {
/* 135:218 */     return GL30.glGetRenderbufferParameteri(target, pname);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static boolean glIsFramebuffer(int framebuffer)
/* 139:    */   {
/* 140:222 */     return GL30.glIsFramebuffer(framebuffer);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public static void glBindFramebuffer(int target, int framebuffer)
/* 144:    */   {
/* 145:226 */     GL30.glBindFramebuffer(target, framebuffer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static void glDeleteFramebuffers(IntBuffer framebuffers)
/* 149:    */   {
/* 150:230 */     GL30.glDeleteFramebuffers(framebuffers);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public static void glDeleteFramebuffers(int framebuffer)
/* 154:    */   {
/* 155:235 */     GL30.glDeleteFramebuffers(framebuffer);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static void glGenFramebuffers(IntBuffer framebuffers)
/* 159:    */   {
/* 160:239 */     GL30.glGenFramebuffers(framebuffers);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static int glGenFramebuffers()
/* 164:    */   {
/* 165:244 */     return GL30.glGenFramebuffers();
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static int glCheckFramebufferStatus(int target)
/* 169:    */   {
/* 170:248 */     return GL30.glCheckFramebufferStatus(target);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static void glFramebufferTexture1D(int target, int attachment, int textarget, int texture, int level)
/* 174:    */   {
/* 175:252 */     GL30.glFramebufferTexture1D(target, attachment, textarget, texture, level);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static void glFramebufferTexture2D(int target, int attachment, int textarget, int texture, int level)
/* 179:    */   {
/* 180:256 */     GL30.glFramebufferTexture2D(target, attachment, textarget, texture, level);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public static void glFramebufferTexture3D(int target, int attachment, int textarget, int texture, int level, int layer)
/* 184:    */   {
/* 185:260 */     GL30.glFramebufferTexture3D(target, attachment, textarget, texture, level, layer);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public static void glFramebufferTextureLayer(int target, int attachment, int texture, int level, int layer)
/* 189:    */   {
/* 190:264 */     GL30.glFramebufferTextureLayer(target, attachment, texture, level, layer);
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static void glFramebufferRenderbuffer(int target, int attachment, int renderbuffertarget, int renderbuffer)
/* 194:    */   {
/* 195:268 */     GL30.glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public static void glGetFramebufferAttachmentParameter(int target, int attachment, int pname, IntBuffer params)
/* 199:    */   {
/* 200:272 */     GL30.glGetFramebufferAttachmentParameter(target, attachment, pname, params);
/* 201:    */   }
/* 202:    */   
/* 203:    */   @Deprecated
/* 204:    */   public static int glGetFramebufferAttachmentParameter(int target, int attachment, int pname)
/* 205:    */   {
/* 206:282 */     return GL30.glGetFramebufferAttachmentParameteri(target, attachment, pname);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static int glGetFramebufferAttachmentParameteri(int target, int attachment, int pname)
/* 210:    */   {
/* 211:287 */     return GL30.glGetFramebufferAttachmentParameteri(target, attachment, pname);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public static void glBlitFramebuffer(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter)
/* 215:    */   {
/* 216:291 */     GL30.glBlitFramebuffer(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static void glGenerateMipmap(int target)
/* 220:    */   {
/* 221:295 */     GL30.glGenerateMipmap(target);
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBFramebufferObject
 * JD-Core Version:    0.7.0.1
 */