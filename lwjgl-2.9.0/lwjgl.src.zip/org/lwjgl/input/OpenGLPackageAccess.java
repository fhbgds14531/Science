/*  1:   */ package org.lwjgl.input;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Field;
/*  4:   */ import java.lang.reflect.Method;
/*  5:   */ import java.security.AccessController;
/*  6:   */ import java.security.PrivilegedActionException;
/*  7:   */ import java.security.PrivilegedExceptionAction;
/*  8:   */ import org.lwjgl.opengl.Display;
/*  9:   */ import org.lwjgl.opengl.InputImplementation;
/* 10:   */ 
/* 11:   */ final class OpenGLPackageAccess
/* 12:   */ {
/* 13:   */   static final Object global_lock;
/* 14:   */   
/* 15:   */   static
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:52 */       global_lock = AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 20:   */       {
/* 21:   */         public Object run()
/* 22:   */           throws Exception
/* 23:   */         {
/* 24:54 */           Field lock_field = Class.forName("org.lwjgl.opengl.GlobalLock").getDeclaredField("lock");
/* 25:55 */           lock_field.setAccessible(true);
/* 26:56 */           return lock_field.get(null);
/* 27:   */         }
/* 28:   */       });
/* 29:   */     }
/* 30:   */     catch (PrivilegedActionException e)
/* 31:   */     {
/* 32:60 */       throw new Error(e);
/* 33:   */     }
/* 34:   */   }
/* 35:   */   
/* 36:   */   static InputImplementation createImplementation()
/* 37:   */   {
/* 38:   */     try
/* 39:   */     {
/* 40:69 */       (InputImplementation)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 41:   */       {
/* 42:   */         public InputImplementation run()
/* 43:   */           throws Exception
/* 44:   */         {
/* 45:71 */           Method getImplementation_method = Display.class.getDeclaredMethod("getImplementation", new Class[0]);
/* 46:72 */           getImplementation_method.setAccessible(true);
/* 47:73 */           return (InputImplementation)getImplementation_method.invoke(null, new Object[0]);
/* 48:   */         }
/* 49:   */       });
/* 50:   */     }
/* 51:   */     catch (PrivilegedActionException e)
/* 52:   */     {
/* 53:77 */       throw new Error(e);
/* 54:   */     }
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.OpenGLPackageAccess
 * JD-Core Version:    0.7.0.1
 */