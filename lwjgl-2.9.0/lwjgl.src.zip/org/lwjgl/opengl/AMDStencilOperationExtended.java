/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class AMDStencilOperationExtended
/*  6:   */ {
/*  7:   */   public static final int GL_SET_AMD = 34634;
/*  8:   */   public static final int GL_AND = 5377;
/*  9:   */   public static final int GL_XOR = 5382;
/* 10:   */   public static final int GL_OR = 5383;
/* 11:   */   public static final int GL_NOR = 5384;
/* 12:   */   public static final int GL_EQUIV = 5385;
/* 13:   */   public static final int GL_NAND = 5390;
/* 14:   */   public static final int GL_REPLACE_VALUE_AMD = 34635;
/* 15:   */   public static final int GL_STENCIL_OP_VALUE_AMD = 34636;
/* 16:   */   public static final int GL_STENCIL_BACK_OP_VALUE_AMD = 34637;
/* 17:   */   
/* 18:   */   public static void glStencilOpValueAMD(int face, int value)
/* 19:   */   {
/* 20:33 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 21:34 */     long function_pointer = caps.glStencilOpValueAMD;
/* 22:35 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 23:36 */     nglStencilOpValueAMD(face, value, function_pointer);
/* 24:   */   }
/* 25:   */   
/* 26:   */   static native void nglStencilOpValueAMD(int paramInt1, int paramInt2, long paramLong);
/* 27:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDStencilOperationExtended
 * JD-Core Version:    0.7.0.1
 */