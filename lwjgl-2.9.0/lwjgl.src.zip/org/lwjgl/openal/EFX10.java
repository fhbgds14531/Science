/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ import org.lwjgl.MemoryUtil;
/*   8:    */ 
/*   9:    */ public final class EFX10
/*  10:    */ {
/*  11:    */   public static final String ALC_EXT_EFX_NAME = "ALC_EXT_EFX";
/*  12:    */   public static final int ALC_EFX_MAJOR_VERSION = 131073;
/*  13:    */   public static final int ALC_EFX_MINOR_VERSION = 131074;
/*  14:    */   public static final int ALC_MAX_AUXILIARY_SENDS = 131075;
/*  15:    */   public static final int AL_METERS_PER_UNIT = 131076;
/*  16:    */   public static final int AL_DIRECT_FILTER = 131077;
/*  17:    */   public static final int AL_AUXILIARY_SEND_FILTER = 131078;
/*  18:    */   public static final int AL_AIR_ABSORPTION_FACTOR = 131079;
/*  19:    */   public static final int AL_ROOM_ROLLOFF_FACTOR = 131080;
/*  20:    */   public static final int AL_CONE_OUTER_GAINHF = 131081;
/*  21:    */   public static final int AL_DIRECT_FILTER_GAINHF_AUTO = 131082;
/*  22:    */   public static final int AL_AUXILIARY_SEND_FILTER_GAIN_AUTO = 131083;
/*  23:    */   public static final int AL_AUXILIARY_SEND_FILTER_GAINHF_AUTO = 131084;
/*  24:    */   public static final int AL_EFFECTSLOT_EFFECT = 1;
/*  25:    */   public static final int AL_EFFECTSLOT_GAIN = 2;
/*  26:    */   public static final int AL_EFFECTSLOT_AUXILIARY_SEND_AUTO = 3;
/*  27:    */   public static final int AL_EFFECTSLOT_NULL = 0;
/*  28:    */   public static final int AL_REVERB_DENSITY = 1;
/*  29:    */   public static final int AL_REVERB_DIFFUSION = 2;
/*  30:    */   public static final int AL_REVERB_GAIN = 3;
/*  31:    */   public static final int AL_REVERB_GAINHF = 4;
/*  32:    */   public static final int AL_REVERB_DECAY_TIME = 5;
/*  33:    */   public static final int AL_REVERB_DECAY_HFRATIO = 6;
/*  34:    */   public static final int AL_REVERB_REFLECTIONS_GAIN = 7;
/*  35:    */   public static final int AL_REVERB_REFLECTIONS_DELAY = 8;
/*  36:    */   public static final int AL_REVERB_LATE_REVERB_GAIN = 9;
/*  37:    */   public static final int AL_REVERB_LATE_REVERB_DELAY = 10;
/*  38:    */   public static final int AL_REVERB_AIR_ABSORPTION_GAINHF = 11;
/*  39:    */   public static final int AL_REVERB_ROOM_ROLLOFF_FACTOR = 12;
/*  40:    */   public static final int AL_REVERB_DECAY_HFLIMIT = 13;
/*  41:    */   public static final int AL_EAXREVERB_DENSITY = 1;
/*  42:    */   public static final int AL_EAXREVERB_DIFFUSION = 2;
/*  43:    */   public static final int AL_EAXREVERB_GAIN = 3;
/*  44:    */   public static final int AL_EAXREVERB_GAINHF = 4;
/*  45:    */   public static final int AL_EAXREVERB_GAINLF = 5;
/*  46:    */   public static final int AL_EAXREVERB_DECAY_TIME = 6;
/*  47:    */   public static final int AL_EAXREVERB_DECAY_HFRATIO = 7;
/*  48:    */   public static final int AL_EAXREVERB_DECAY_LFRATIO = 8;
/*  49:    */   public static final int AL_EAXREVERB_REFLECTIONS_GAIN = 9;
/*  50:    */   public static final int AL_EAXREVERB_REFLECTIONS_DELAY = 10;
/*  51:    */   public static final int AL_EAXREVERB_REFLECTIONS_PAN = 11;
/*  52:    */   public static final int AL_EAXREVERB_LATE_REVERB_GAIN = 12;
/*  53:    */   public static final int AL_EAXREVERB_LATE_REVERB_DELAY = 13;
/*  54:    */   public static final int AL_EAXREVERB_LATE_REVERB_PAN = 14;
/*  55:    */   public static final int AL_EAXREVERB_ECHO_TIME = 15;
/*  56:    */   public static final int AL_EAXREVERB_ECHO_DEPTH = 16;
/*  57:    */   public static final int AL_EAXREVERB_MODULATION_TIME = 17;
/*  58:    */   public static final int AL_EAXREVERB_MODULATION_DEPTH = 18;
/*  59:    */   public static final int AL_EAXREVERB_AIR_ABSORPTION_GAINHF = 19;
/*  60:    */   public static final int AL_EAXREVERB_HFREFERENCE = 20;
/*  61:    */   public static final int AL_EAXREVERB_LFREFERENCE = 21;
/*  62:    */   public static final int AL_EAXREVERB_ROOM_ROLLOFF_FACTOR = 22;
/*  63:    */   public static final int AL_EAXREVERB_DECAY_HFLIMIT = 23;
/*  64:    */   public static final int AL_CHORUS_WAVEFORM = 1;
/*  65:    */   public static final int AL_CHORUS_PHASE = 2;
/*  66:    */   public static final int AL_CHORUS_RATE = 3;
/*  67:    */   public static final int AL_CHORUS_DEPTH = 4;
/*  68:    */   public static final int AL_CHORUS_FEEDBACK = 5;
/*  69:    */   public static final int AL_CHORUS_DELAY = 6;
/*  70:    */   public static final int AL_DISTORTION_EDGE = 1;
/*  71:    */   public static final int AL_DISTORTION_GAIN = 2;
/*  72:    */   public static final int AL_DISTORTION_LOWPASS_CUTOFF = 3;
/*  73:    */   public static final int AL_DISTORTION_EQCENTER = 4;
/*  74:    */   public static final int AL_DISTORTION_EQBANDWIDTH = 5;
/*  75:    */   public static final int AL_ECHO_DELAY = 1;
/*  76:    */   public static final int AL_ECHO_LRDELAY = 2;
/*  77:    */   public static final int AL_ECHO_DAMPING = 3;
/*  78:    */   public static final int AL_ECHO_FEEDBACK = 4;
/*  79:    */   public static final int AL_ECHO_SPREAD = 5;
/*  80:    */   public static final int AL_FLANGER_WAVEFORM = 1;
/*  81:    */   public static final int AL_FLANGER_PHASE = 2;
/*  82:    */   public static final int AL_FLANGER_RATE = 3;
/*  83:    */   public static final int AL_FLANGER_DEPTH = 4;
/*  84:    */   public static final int AL_FLANGER_FEEDBACK = 5;
/*  85:    */   public static final int AL_FLANGER_DELAY = 6;
/*  86:    */   public static final int AL_FREQUENCY_SHIFTER_FREQUENCY = 1;
/*  87:    */   public static final int AL_FREQUENCY_SHIFTER_LEFT_DIRECTION = 2;
/*  88:    */   public static final int AL_FREQUENCY_SHIFTER_RIGHT_DIRECTION = 3;
/*  89:    */   public static final int AL_VOCAL_MORPHER_PHONEMEA = 1;
/*  90:    */   public static final int AL_VOCAL_MORPHER_PHONEMEA_COARSE_TUNING = 2;
/*  91:    */   public static final int AL_VOCAL_MORPHER_PHONEMEB = 3;
/*  92:    */   public static final int AL_VOCAL_MORPHER_PHONEMEB_COARSE_TUNING = 4;
/*  93:    */   public static final int AL_VOCAL_MORPHER_WAVEFORM = 5;
/*  94:    */   public static final int AL_VOCAL_MORPHER_RATE = 6;
/*  95:    */   public static final int AL_PITCH_SHIFTER_COARSE_TUNE = 1;
/*  96:    */   public static final int AL_PITCH_SHIFTER_FINE_TUNE = 2;
/*  97:    */   public static final int AL_RING_MODULATOR_FREQUENCY = 1;
/*  98:    */   public static final int AL_RING_MODULATOR_HIGHPASS_CUTOFF = 2;
/*  99:    */   public static final int AL_RING_MODULATOR_WAVEFORM = 3;
/* 100:    */   public static final int AL_AUTOWAH_ATTACK_TIME = 1;
/* 101:    */   public static final int AL_AUTOWAH_RELEASE_TIME = 2;
/* 102:    */   public static final int AL_AUTOWAH_RESONANCE = 3;
/* 103:    */   public static final int AL_AUTOWAH_PEAK_GAIN = 4;
/* 104:    */   public static final int AL_COMPRESSOR_ONOFF = 1;
/* 105:    */   public static final int AL_EQUALIZER_LOW_GAIN = 1;
/* 106:    */   public static final int AL_EQUALIZER_LOW_CUTOFF = 2;
/* 107:    */   public static final int AL_EQUALIZER_MID1_GAIN = 3;
/* 108:    */   public static final int AL_EQUALIZER_MID1_CENTER = 4;
/* 109:    */   public static final int AL_EQUALIZER_MID1_WIDTH = 5;
/* 110:    */   public static final int AL_EQUALIZER_MID2_GAIN = 6;
/* 111:    */   public static final int AL_EQUALIZER_MID2_CENTER = 7;
/* 112:    */   public static final int AL_EQUALIZER_MID2_WIDTH = 8;
/* 113:    */   public static final int AL_EQUALIZER_HIGH_GAIN = 9;
/* 114:    */   public static final int AL_EQUALIZER_HIGH_CUTOFF = 10;
/* 115:    */   public static final int AL_EFFECT_FIRST_PARAMETER = 0;
/* 116:    */   public static final int AL_EFFECT_LAST_PARAMETER = 32768;
/* 117:    */   public static final int AL_EFFECT_TYPE = 32769;
/* 118:    */   public static final int AL_EFFECT_NULL = 0;
/* 119:    */   public static final int AL_EFFECT_REVERB = 1;
/* 120:    */   public static final int AL_EFFECT_CHORUS = 2;
/* 121:    */   public static final int AL_EFFECT_DISTORTION = 3;
/* 122:    */   public static final int AL_EFFECT_ECHO = 4;
/* 123:    */   public static final int AL_EFFECT_FLANGER = 5;
/* 124:    */   public static final int AL_EFFECT_FREQUENCY_SHIFTER = 6;
/* 125:    */   public static final int AL_EFFECT_VOCAL_MORPHER = 7;
/* 126:    */   public static final int AL_EFFECT_PITCH_SHIFTER = 8;
/* 127:    */   public static final int AL_EFFECT_RING_MODULATOR = 9;
/* 128:    */   public static final int AL_EFFECT_AUTOWAH = 10;
/* 129:    */   public static final int AL_EFFECT_COMPRESSOR = 11;
/* 130:    */   public static final int AL_EFFECT_EQUALIZER = 12;
/* 131:    */   public static final int AL_EFFECT_EAXREVERB = 32768;
/* 132:    */   public static final int AL_LOWPASS_GAIN = 1;
/* 133:    */   public static final int AL_LOWPASS_GAINHF = 2;
/* 134:    */   public static final int AL_HIGHPASS_GAIN = 1;
/* 135:    */   public static final int AL_HIGHPASS_GAINLF = 2;
/* 136:    */   public static final int AL_BANDPASS_GAIN = 1;
/* 137:    */   public static final int AL_BANDPASS_GAINLF = 2;
/* 138:    */   public static final int AL_BANDPASS_GAINHF = 3;
/* 139:    */   public static final int AL_FILTER_FIRST_PARAMETER = 0;
/* 140:    */   public static final int AL_FILTER_LAST_PARAMETER = 32768;
/* 141:    */   public static final int AL_FILTER_TYPE = 32769;
/* 142:    */   public static final int AL_FILTER_NULL = 0;
/* 143:    */   public static final int AL_FILTER_LOWPASS = 1;
/* 144:    */   public static final int AL_FILTER_HIGHPASS = 2;
/* 145:    */   public static final int AL_FILTER_BANDPASS = 3;
/* 146:    */   public static final float AL_MIN_AIR_ABSORPTION_FACTOR = 0.0F;
/* 147:    */   public static final float AL_MAX_AIR_ABSORPTION_FACTOR = 10.0F;
/* 148:    */   public static final float AL_DEFAULT_AIR_ABSORPTION_FACTOR = 0.0F;
/* 149:    */   public static final float AL_MIN_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 150:    */   public static final float AL_MAX_ROOM_ROLLOFF_FACTOR = 10.0F;
/* 151:    */   public static final float AL_DEFAULT_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 152:    */   public static final float AL_MIN_CONE_OUTER_GAINHF = 0.0F;
/* 153:    */   public static final float AL_MAX_CONE_OUTER_GAINHF = 1.0F;
/* 154:    */   public static final float AL_DEFAULT_CONE_OUTER_GAINHF = 1.0F;
/* 155:    */   public static final int AL_MIN_DIRECT_FILTER_GAINHF_AUTO = 0;
/* 156:    */   public static final int AL_MAX_DIRECT_FILTER_GAINHF_AUTO = 1;
/* 157:    */   public static final int AL_DEFAULT_DIRECT_FILTER_GAINHF_AUTO = 1;
/* 158:    */   public static final int AL_MIN_AUXILIARY_SEND_FILTER_GAIN_AUTO = 0;
/* 159:    */   public static final int AL_MAX_AUXILIARY_SEND_FILTER_GAIN_AUTO = 1;
/* 160:    */   public static final int AL_DEFAULT_AUXILIARY_SEND_FILTER_GAIN_AUTO = 1;
/* 161:    */   public static final int AL_MIN_AUXILIARY_SEND_FILTER_GAINHF_AUTO = 0;
/* 162:    */   public static final int AL_MAX_AUXILIARY_SEND_FILTER_GAINHF_AUTO = 1;
/* 163:    */   public static final int AL_DEFAULT_AUXILIARY_SEND_FILTER_GAINHF_AUTO = 1;
/* 164:    */   public static final float AL_MIN_METERS_PER_UNIT = 1.4E-45F;
/* 165:    */   public static final float AL_MAX_METERS_PER_UNIT = 3.4028235E+38F;
/* 166:    */   public static final float AL_DEFAULT_METERS_PER_UNIT = 1.0F;
/* 167:    */   public static final float AL_REVERB_MIN_DENSITY = 0.0F;
/* 168:    */   public static final float AL_REVERB_MAX_DENSITY = 1.0F;
/* 169:    */   public static final float AL_REVERB_DEFAULT_DENSITY = 1.0F;
/* 170:    */   public static final float AL_REVERB_MIN_DIFFUSION = 0.0F;
/* 171:    */   public static final float AL_REVERB_MAX_DIFFUSION = 1.0F;
/* 172:    */   public static final float AL_REVERB_DEFAULT_DIFFUSION = 1.0F;
/* 173:    */   public static final float AL_REVERB_MIN_GAIN = 0.0F;
/* 174:    */   public static final float AL_REVERB_MAX_GAIN = 1.0F;
/* 175:    */   public static final float AL_REVERB_DEFAULT_GAIN = 0.32F;
/* 176:    */   public static final float AL_REVERB_MIN_GAINHF = 0.0F;
/* 177:    */   public static final float AL_REVERB_MAX_GAINHF = 1.0F;
/* 178:    */   public static final float AL_REVERB_DEFAULT_GAINHF = 0.89F;
/* 179:    */   public static final float AL_REVERB_MIN_DECAY_TIME = 0.1F;
/* 180:    */   public static final float AL_REVERB_MAX_DECAY_TIME = 20.0F;
/* 181:    */   public static final float AL_REVERB_DEFAULT_DECAY_TIME = 1.49F;
/* 182:    */   public static final float AL_REVERB_MIN_DECAY_HFRATIO = 0.1F;
/* 183:    */   public static final float AL_REVERB_MAX_DECAY_HFRATIO = 2.0F;
/* 184:    */   public static final float AL_REVERB_DEFAULT_DECAY_HFRATIO = 0.83F;
/* 185:    */   public static final float AL_REVERB_MIN_REFLECTIONS_GAIN = 0.0F;
/* 186:    */   public static final float AL_REVERB_MAX_REFLECTIONS_GAIN = 3.16F;
/* 187:    */   public static final float AL_REVERB_DEFAULT_REFLECTIONS_GAIN = 0.05F;
/* 188:    */   public static final float AL_REVERB_MIN_REFLECTIONS_DELAY = 0.0F;
/* 189:    */   public static final float AL_REVERB_MAX_REFLECTIONS_DELAY = 0.3F;
/* 190:    */   public static final float AL_REVERB_DEFAULT_REFLECTIONS_DELAY = 0.007F;
/* 191:    */   public static final float AL_REVERB_MIN_LATE_REVERB_GAIN = 0.0F;
/* 192:    */   public static final float AL_REVERB_MAX_LATE_REVERB_GAIN = 10.0F;
/* 193:    */   public static final float AL_REVERB_DEFAULT_LATE_REVERB_GAIN = 1.26F;
/* 194:    */   public static final float AL_REVERB_MIN_LATE_REVERB_DELAY = 0.0F;
/* 195:    */   public static final float AL_REVERB_MAX_LATE_REVERB_DELAY = 0.1F;
/* 196:    */   public static final float AL_REVERB_DEFAULT_LATE_REVERB_DELAY = 0.011F;
/* 197:    */   public static final float AL_REVERB_MIN_AIR_ABSORPTION_GAINHF = 0.892F;
/* 198:    */   public static final float AL_REVERB_MAX_AIR_ABSORPTION_GAINHF = 1.0F;
/* 199:    */   public static final float AL_REVERB_DEFAULT_AIR_ABSORPTION_GAINHF = 0.994F;
/* 200:    */   public static final float AL_REVERB_MIN_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 201:    */   public static final float AL_REVERB_MAX_ROOM_ROLLOFF_FACTOR = 10.0F;
/* 202:    */   public static final float AL_REVERB_DEFAULT_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 203:    */   public static final int AL_REVERB_MIN_DECAY_HFLIMIT = 0;
/* 204:    */   public static final int AL_REVERB_MAX_DECAY_HFLIMIT = 1;
/* 205:    */   public static final int AL_REVERB_DEFAULT_DECAY_HFLIMIT = 1;
/* 206:    */   public static final float AL_EAXREVERB_MIN_DENSITY = 0.0F;
/* 207:    */   public static final float AL_EAXREVERB_MAX_DENSITY = 1.0F;
/* 208:    */   public static final float AL_EAXREVERB_DEFAULT_DENSITY = 1.0F;
/* 209:    */   public static final float AL_EAXREVERB_MIN_DIFFUSION = 0.0F;
/* 210:    */   public static final float AL_EAXREVERB_MAX_DIFFUSION = 1.0F;
/* 211:    */   public static final float AL_EAXREVERB_DEFAULT_DIFFUSION = 1.0F;
/* 212:    */   public static final float AL_EAXREVERB_MIN_GAIN = 0.0F;
/* 213:    */   public static final float AL_EAXREVERB_MAX_GAIN = 1.0F;
/* 214:    */   public static final float AL_EAXREVERB_DEFAULT_GAIN = 0.32F;
/* 215:    */   public static final float AL_EAXREVERB_MIN_GAINHF = 0.0F;
/* 216:    */   public static final float AL_EAXREVERB_MAX_GAINHF = 1.0F;
/* 217:    */   public static final float AL_EAXREVERB_DEFAULT_GAINHF = 0.89F;
/* 218:    */   public static final float AL_EAXREVERB_MIN_GAINLF = 0.0F;
/* 219:    */   public static final float AL_EAXREVERB_MAX_GAINLF = 1.0F;
/* 220:    */   public static final float AL_EAXREVERB_DEFAULT_GAINLF = 1.0F;
/* 221:    */   public static final float AL_EAXREVERB_MIN_DECAY_TIME = 0.1F;
/* 222:    */   public static final float AL_EAXREVERB_MAX_DECAY_TIME = 20.0F;
/* 223:    */   public static final float AL_EAXREVERB_DEFAULT_DECAY_TIME = 1.49F;
/* 224:    */   public static final float AL_EAXREVERB_MIN_DECAY_HFRATIO = 0.1F;
/* 225:    */   public static final float AL_EAXREVERB_MAX_DECAY_HFRATIO = 2.0F;
/* 226:    */   public static final float AL_EAXREVERB_DEFAULT_DECAY_HFRATIO = 0.83F;
/* 227:    */   public static final float AL_EAXREVERB_MIN_DECAY_LFRATIO = 0.1F;
/* 228:    */   public static final float AL_EAXREVERB_MAX_DECAY_LFRATIO = 2.0F;
/* 229:    */   public static final float AL_EAXREVERB_DEFAULT_DECAY_LFRATIO = 1.0F;
/* 230:    */   public static final float AL_EAXREVERB_MIN_REFLECTIONS_GAIN = 0.0F;
/* 231:    */   public static final float AL_EAXREVERB_MAX_REFLECTIONS_GAIN = 3.16F;
/* 232:    */   public static final float AL_EAXREVERB_DEFAULT_REFLECTIONS_GAIN = 0.05F;
/* 233:    */   public static final float AL_EAXREVERB_MIN_REFLECTIONS_DELAY = 0.0F;
/* 234:    */   public static final float AL_EAXREVERB_MAX_REFLECTIONS_DELAY = 0.3F;
/* 235:    */   public static final float AL_EAXREVERB_DEFAULT_REFLECTIONS_DELAY = 0.007F;
/* 236:    */   public static final float AL_EAXREVERB_DEFAULT_REFLECTIONS_PAN_XYZ = 0.0F;
/* 237:    */   public static final float AL_EAXREVERB_MIN_LATE_REVERB_GAIN = 0.0F;
/* 238:    */   public static final float AL_EAXREVERB_MAX_LATE_REVERB_GAIN = 10.0F;
/* 239:    */   public static final float AL_EAXREVERB_DEFAULT_LATE_REVERB_GAIN = 1.26F;
/* 240:    */   public static final float AL_EAXREVERB_MIN_LATE_REVERB_DELAY = 0.0F;
/* 241:    */   public static final float AL_EAXREVERB_MAX_LATE_REVERB_DELAY = 0.1F;
/* 242:    */   public static final float AL_EAXREVERB_DEFAULT_LATE_REVERB_DELAY = 0.011F;
/* 243:    */   public static final float AL_EAXREVERB_DEFAULT_LATE_REVERB_PAN_XYZ = 0.0F;
/* 244:    */   public static final float AL_EAXREVERB_MIN_ECHO_TIME = 0.075F;
/* 245:    */   public static final float AL_EAXREVERB_MAX_ECHO_TIME = 0.25F;
/* 246:    */   public static final float AL_EAXREVERB_DEFAULT_ECHO_TIME = 0.25F;
/* 247:    */   public static final float AL_EAXREVERB_MIN_ECHO_DEPTH = 0.0F;
/* 248:    */   public static final float AL_EAXREVERB_MAX_ECHO_DEPTH = 1.0F;
/* 249:    */   public static final float AL_EAXREVERB_DEFAULT_ECHO_DEPTH = 0.0F;
/* 250:    */   public static final float AL_EAXREVERB_MIN_MODULATION_TIME = 0.04F;
/* 251:    */   public static final float AL_EAXREVERB_MAX_MODULATION_TIME = 4.0F;
/* 252:    */   public static final float AL_EAXREVERB_DEFAULT_MODULATION_TIME = 0.25F;
/* 253:    */   public static final float AL_EAXREVERB_MIN_MODULATION_DEPTH = 0.0F;
/* 254:    */   public static final float AL_EAXREVERB_MAX_MODULATION_DEPTH = 1.0F;
/* 255:    */   public static final float AL_EAXREVERB_DEFAULT_MODULATION_DEPTH = 0.0F;
/* 256:    */   public static final float AL_EAXREVERB_MIN_AIR_ABSORPTION_GAINHF = 0.892F;
/* 257:    */   public static final float AL_EAXREVERB_MAX_AIR_ABSORPTION_GAINHF = 1.0F;
/* 258:    */   public static final float AL_EAXREVERB_DEFAULT_AIR_ABSORPTION_GAINHF = 0.994F;
/* 259:    */   public static final float AL_EAXREVERB_MIN_HFREFERENCE = 1000.0F;
/* 260:    */   public static final float AL_EAXREVERB_MAX_HFREFERENCE = 20000.0F;
/* 261:    */   public static final float AL_EAXREVERB_DEFAULT_HFREFERENCE = 5000.0F;
/* 262:    */   public static final float AL_EAXREVERB_MIN_LFREFERENCE = 20.0F;
/* 263:    */   public static final float AL_EAXREVERB_MAX_LFREFERENCE = 1000.0F;
/* 264:    */   public static final float AL_EAXREVERB_DEFAULT_LFREFERENCE = 250.0F;
/* 265:    */   public static final float AL_EAXREVERB_MIN_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 266:    */   public static final float AL_EAXREVERB_MAX_ROOM_ROLLOFF_FACTOR = 10.0F;
/* 267:    */   public static final float AL_EAXREVERB_DEFAULT_ROOM_ROLLOFF_FACTOR = 0.0F;
/* 268:    */   public static final int AL_EAXREVERB_MIN_DECAY_HFLIMIT = 0;
/* 269:    */   public static final int AL_EAXREVERB_MAX_DECAY_HFLIMIT = 1;
/* 270:    */   public static final int AL_EAXREVERB_DEFAULT_DECAY_HFLIMIT = 1;
/* 271:    */   public static final int AL_CHORUS_WAVEFORM_SINUSOID = 0;
/* 272:    */   public static final int AL_CHORUS_WAVEFORM_TRIANGLE = 1;
/* 273:    */   public static final int AL_CHORUS_MIN_WAVEFORM = 0;
/* 274:    */   public static final int AL_CHORUS_MAX_WAVEFORM = 1;
/* 275:    */   public static final int AL_CHORUS_DEFAULT_WAVEFORM = 1;
/* 276:    */   public static final int AL_CHORUS_MIN_PHASE = -180;
/* 277:    */   public static final int AL_CHORUS_MAX_PHASE = 180;
/* 278:    */   public static final int AL_CHORUS_DEFAULT_PHASE = 90;
/* 279:    */   public static final float AL_CHORUS_MIN_RATE = 0.0F;
/* 280:    */   public static final float AL_CHORUS_MAX_RATE = 10.0F;
/* 281:    */   public static final float AL_CHORUS_DEFAULT_RATE = 1.1F;
/* 282:    */   public static final float AL_CHORUS_MIN_DEPTH = 0.0F;
/* 283:    */   public static final float AL_CHORUS_MAX_DEPTH = 1.0F;
/* 284:    */   public static final float AL_CHORUS_DEFAULT_DEPTH = 0.1F;
/* 285:    */   public static final float AL_CHORUS_MIN_FEEDBACK = -1.0F;
/* 286:    */   public static final float AL_CHORUS_MAX_FEEDBACK = 1.0F;
/* 287:    */   public static final float AL_CHORUS_DEFAULT_FEEDBACK = 0.25F;
/* 288:    */   public static final float AL_CHORUS_MIN_DELAY = 0.0F;
/* 289:    */   public static final float AL_CHORUS_MAX_DELAY = 0.016F;
/* 290:    */   public static final float AL_CHORUS_DEFAULT_DELAY = 0.016F;
/* 291:    */   public static final float AL_DISTORTION_MIN_EDGE = 0.0F;
/* 292:    */   public static final float AL_DISTORTION_MAX_EDGE = 1.0F;
/* 293:    */   public static final float AL_DISTORTION_DEFAULT_EDGE = 0.2F;
/* 294:    */   public static final float AL_DISTORTION_MIN_GAIN = 0.01F;
/* 295:    */   public static final float AL_DISTORTION_MAX_GAIN = 1.0F;
/* 296:    */   public static final float AL_DISTORTION_DEFAULT_GAIN = 0.05F;
/* 297:    */   public static final float AL_DISTORTION_MIN_LOWPASS_CUTOFF = 80.0F;
/* 298:    */   public static final float AL_DISTORTION_MAX_LOWPASS_CUTOFF = 24000.0F;
/* 299:    */   public static final float AL_DISTORTION_DEFAULT_LOWPASS_CUTOFF = 8000.0F;
/* 300:    */   public static final float AL_DISTORTION_MIN_EQCENTER = 80.0F;
/* 301:    */   public static final float AL_DISTORTION_MAX_EQCENTER = 24000.0F;
/* 302:    */   public static final float AL_DISTORTION_DEFAULT_EQCENTER = 3600.0F;
/* 303:    */   public static final float AL_DISTORTION_MIN_EQBANDWIDTH = 80.0F;
/* 304:    */   public static final float AL_DISTORTION_MAX_EQBANDWIDTH = 24000.0F;
/* 305:    */   public static final float AL_DISTORTION_DEFAULT_EQBANDWIDTH = 3600.0F;
/* 306:    */   public static final float AL_ECHO_MIN_DELAY = 0.0F;
/* 307:    */   public static final float AL_ECHO_MAX_DELAY = 0.207F;
/* 308:    */   public static final float AL_ECHO_DEFAULT_DELAY = 0.1F;
/* 309:    */   public static final float AL_ECHO_MIN_LRDELAY = 0.0F;
/* 310:    */   public static final float AL_ECHO_MAX_LRDELAY = 0.404F;
/* 311:    */   public static final float AL_ECHO_DEFAULT_LRDELAY = 0.1F;
/* 312:    */   public static final float AL_ECHO_MIN_DAMPING = 0.0F;
/* 313:    */   public static final float AL_ECHO_MAX_DAMPING = 0.99F;
/* 314:    */   public static final float AL_ECHO_DEFAULT_DAMPING = 0.5F;
/* 315:    */   public static final float AL_ECHO_MIN_FEEDBACK = 0.0F;
/* 316:    */   public static final float AL_ECHO_MAX_FEEDBACK = 1.0F;
/* 317:    */   public static final float AL_ECHO_DEFAULT_FEEDBACK = 0.5F;
/* 318:    */   public static final float AL_ECHO_MIN_SPREAD = -1.0F;
/* 319:    */   public static final float AL_ECHO_MAX_SPREAD = 1.0F;
/* 320:    */   public static final float AL_ECHO_DEFAULT_SPREAD = -1.0F;
/* 321:    */   public static final int AL_FLANGER_WAVEFORM_SINUSOID = 0;
/* 322:    */   public static final int AL_FLANGER_WAVEFORM_TRIANGLE = 1;
/* 323:    */   public static final int AL_FLANGER_MIN_WAVEFORM = 0;
/* 324:    */   public static final int AL_FLANGER_MAX_WAVEFORM = 1;
/* 325:    */   public static final int AL_FLANGER_DEFAULT_WAVEFORM = 1;
/* 326:    */   public static final int AL_FLANGER_MIN_PHASE = -180;
/* 327:    */   public static final int AL_FLANGER_MAX_PHASE = 180;
/* 328:    */   public static final int AL_FLANGER_DEFAULT_PHASE = 0;
/* 329:    */   public static final float AL_FLANGER_MIN_RATE = 0.0F;
/* 330:    */   public static final float AL_FLANGER_MAX_RATE = 10.0F;
/* 331:    */   public static final float AL_FLANGER_DEFAULT_RATE = 0.27F;
/* 332:    */   public static final float AL_FLANGER_MIN_DEPTH = 0.0F;
/* 333:    */   public static final float AL_FLANGER_MAX_DEPTH = 1.0F;
/* 334:    */   public static final float AL_FLANGER_DEFAULT_DEPTH = 1.0F;
/* 335:    */   public static final float AL_FLANGER_MIN_FEEDBACK = -1.0F;
/* 336:    */   public static final float AL_FLANGER_MAX_FEEDBACK = 1.0F;
/* 337:    */   public static final float AL_FLANGER_DEFAULT_FEEDBACK = -0.5F;
/* 338:    */   public static final float AL_FLANGER_MIN_DELAY = 0.0F;
/* 339:    */   public static final float AL_FLANGER_MAX_DELAY = 0.004F;
/* 340:    */   public static final float AL_FLANGER_DEFAULT_DELAY = 0.002F;
/* 341:    */   public static final float AL_FREQUENCY_SHIFTER_MIN_FREQUENCY = 0.0F;
/* 342:    */   public static final float AL_FREQUENCY_SHIFTER_MAX_FREQUENCY = 24000.0F;
/* 343:    */   public static final float AL_FREQUENCY_SHIFTER_DEFAULT_FREQUENCY = 0.0F;
/* 344:    */   public static final int AL_FREQUENCY_SHIFTER_MIN_LEFT_DIRECTION = 0;
/* 345:    */   public static final int AL_FREQUENCY_SHIFTER_MAX_LEFT_DIRECTION = 2;
/* 346:    */   public static final int AL_FREQUENCY_SHIFTER_DEFAULT_LEFT_DIRECTION = 0;
/* 347:    */   public static final int AL_FREQUENCY_SHIFTER_DIRECTION_DOWN = 0;
/* 348:    */   public static final int AL_FREQUENCY_SHIFTER_DIRECTION_UP = 1;
/* 349:    */   public static final int AL_FREQUENCY_SHIFTER_DIRECTION_OFF = 2;
/* 350:    */   public static final int AL_FREQUENCY_SHIFTER_MIN_RIGHT_DIRECTION = 0;
/* 351:    */   public static final int AL_FREQUENCY_SHIFTER_MAX_RIGHT_DIRECTION = 2;
/* 352:    */   public static final int AL_FREQUENCY_SHIFTER_DEFAULT_RIGHT_DIRECTION = 0;
/* 353:    */   public static final int AL_VOCAL_MORPHER_MIN_PHONEMEA = 0;
/* 354:    */   public static final int AL_VOCAL_MORPHER_MAX_PHONEMEA = 29;
/* 355:    */   public static final int AL_VOCAL_MORPHER_DEFAULT_PHONEMEA = 0;
/* 356:    */   public static final int AL_VOCAL_MORPHER_MIN_PHONEMEA_COARSE_TUNING = -24;
/* 357:    */   public static final int AL_VOCAL_MORPHER_MAX_PHONEMEA_COARSE_TUNING = 24;
/* 358:    */   public static final int AL_VOCAL_MORPHER_DEFAULT_PHONEMEA_COARSE_TUNING = 0;
/* 359:    */   public static final int AL_VOCAL_MORPHER_MIN_PHONEMEB = 0;
/* 360:    */   public static final int AL_VOCAL_MORPHER_MAX_PHONEMEB = 29;
/* 361:    */   public static final int AL_VOCAL_MORPHER_DEFAULT_PHONEMEB = 10;
/* 362:    */   public static final int AL_VOCAL_MORPHER_MIN_PHONEMEB_COARSE_TUNING = -24;
/* 363:    */   public static final int AL_VOCAL_MORPHER_MAX_PHONEMEB_COARSE_TUNING = 24;
/* 364:    */   public static final int AL_VOCAL_MORPHER_DEFAULT_PHONEMEB_COARSE_TUNING = 0;
/* 365:    */   public static final int AL_VOCAL_MORPHER_PHONEME_A = 0;
/* 366:    */   public static final int AL_VOCAL_MORPHER_PHONEME_E = 1;
/* 367:    */   public static final int AL_VOCAL_MORPHER_PHONEME_I = 2;
/* 368:    */   public static final int AL_VOCAL_MORPHER_PHONEME_O = 3;
/* 369:    */   public static final int AL_VOCAL_MORPHER_PHONEME_U = 4;
/* 370:    */   public static final int AL_VOCAL_MORPHER_PHONEME_AA = 5;
/* 371:    */   public static final int AL_VOCAL_MORPHER_PHONEME_AE = 6;
/* 372:    */   public static final int AL_VOCAL_MORPHER_PHONEME_AH = 7;
/* 373:    */   public static final int AL_VOCAL_MORPHER_PHONEME_AO = 8;
/* 374:    */   public static final int AL_VOCAL_MORPHER_PHONEME_EH = 9;
/* 375:    */   public static final int AL_VOCAL_MORPHER_PHONEME_ER = 10;
/* 376:    */   public static final int AL_VOCAL_MORPHER_PHONEME_IH = 11;
/* 377:    */   public static final int AL_VOCAL_MORPHER_PHONEME_IY = 12;
/* 378:    */   public static final int AL_VOCAL_MORPHER_PHONEME_UH = 13;
/* 379:    */   public static final int AL_VOCAL_MORPHER_PHONEME_UW = 14;
/* 380:    */   public static final int AL_VOCAL_MORPHER_PHONEME_B = 15;
/* 381:    */   public static final int AL_VOCAL_MORPHER_PHONEME_D = 16;
/* 382:    */   public static final int AL_VOCAL_MORPHER_PHONEME_F = 17;
/* 383:    */   public static final int AL_VOCAL_MORPHER_PHONEME_G = 18;
/* 384:    */   public static final int AL_VOCAL_MORPHER_PHONEME_J = 19;
/* 385:    */   public static final int AL_VOCAL_MORPHER_PHONEME_K = 20;
/* 386:    */   public static final int AL_VOCAL_MORPHER_PHONEME_L = 21;
/* 387:    */   public static final int AL_VOCAL_MORPHER_PHONEME_M = 22;
/* 388:    */   public static final int AL_VOCAL_MORPHER_PHONEME_N = 23;
/* 389:    */   public static final int AL_VOCAL_MORPHER_PHONEME_P = 24;
/* 390:    */   public static final int AL_VOCAL_MORPHER_PHONEME_R = 25;
/* 391:    */   public static final int AL_VOCAL_MORPHER_PHONEME_S = 26;
/* 392:    */   public static final int AL_VOCAL_MORPHER_PHONEME_T = 27;
/* 393:    */   public static final int AL_VOCAL_MORPHER_PHONEME_V = 28;
/* 394:    */   public static final int AL_VOCAL_MORPHER_PHONEME_Z = 29;
/* 395:    */   public static final int AL_VOCAL_MORPHER_WAVEFORM_SINUSOID = 0;
/* 396:    */   public static final int AL_VOCAL_MORPHER_WAVEFORM_TRIANGLE = 1;
/* 397:    */   public static final int AL_VOCAL_MORPHER_WAVEFORM_SAWTOOTH = 2;
/* 398:    */   public static final int AL_VOCAL_MORPHER_MIN_WAVEFORM = 0;
/* 399:    */   public static final int AL_VOCAL_MORPHER_MAX_WAVEFORM = 2;
/* 400:    */   public static final int AL_VOCAL_MORPHER_DEFAULT_WAVEFORM = 0;
/* 401:    */   public static final float AL_VOCAL_MORPHER_MIN_RATE = 0.0F;
/* 402:    */   public static final float AL_VOCAL_MORPHER_MAX_RATE = 10.0F;
/* 403:    */   public static final float AL_VOCAL_MORPHER_DEFAULT_RATE = 1.41F;
/* 404:    */   public static final int AL_PITCH_SHIFTER_MIN_COARSE_TUNE = -12;
/* 405:    */   public static final int AL_PITCH_SHIFTER_MAX_COARSE_TUNE = 12;
/* 406:    */   public static final int AL_PITCH_SHIFTER_DEFAULT_COARSE_TUNE = 12;
/* 407:    */   public static final int AL_PITCH_SHIFTER_MIN_FINE_TUNE = -50;
/* 408:    */   public static final int AL_PITCH_SHIFTER_MAX_FINE_TUNE = 50;
/* 409:    */   public static final int AL_PITCH_SHIFTER_DEFAULT_FINE_TUNE = 0;
/* 410:    */   public static final float AL_RING_MODULATOR_MIN_FREQUENCY = 0.0F;
/* 411:    */   public static final float AL_RING_MODULATOR_MAX_FREQUENCY = 8000.0F;
/* 412:    */   public static final float AL_RING_MODULATOR_DEFAULT_FREQUENCY = 440.0F;
/* 413:    */   public static final float AL_RING_MODULATOR_MIN_HIGHPASS_CUTOFF = 0.0F;
/* 414:    */   public static final float AL_RING_MODULATOR_MAX_HIGHPASS_CUTOFF = 24000.0F;
/* 415:    */   public static final float AL_RING_MODULATOR_DEFAULT_HIGHPASS_CUTOFF = 800.0F;
/* 416:    */   public static final int AL_RING_MODULATOR_SINUSOID = 0;
/* 417:    */   public static final int AL_RING_MODULATOR_SAWTOOTH = 1;
/* 418:    */   public static final int AL_RING_MODULATOR_SQUARE = 2;
/* 419:    */   public static final int AL_RING_MODULATOR_MIN_WAVEFORM = 0;
/* 420:    */   public static final int AL_RING_MODULATOR_MAX_WAVEFORM = 2;
/* 421:    */   public static final int AL_RING_MODULATOR_DEFAULT_WAVEFORM = 0;
/* 422:    */   public static final float AL_AUTOWAH_MIN_ATTACK_TIME = 1.0E-004F;
/* 423:    */   public static final float AL_AUTOWAH_MAX_ATTACK_TIME = 1.0F;
/* 424:    */   public static final float AL_AUTOWAH_DEFAULT_ATTACK_TIME = 0.06F;
/* 425:    */   public static final float AL_AUTOWAH_MIN_RELEASE_TIME = 1.0E-004F;
/* 426:    */   public static final float AL_AUTOWAH_MAX_RELEASE_TIME = 1.0F;
/* 427:    */   public static final float AL_AUTOWAH_DEFAULT_RELEASE_TIME = 0.06F;
/* 428:    */   public static final float AL_AUTOWAH_MIN_RESONANCE = 2.0F;
/* 429:    */   public static final float AL_AUTOWAH_MAX_RESONANCE = 1000.0F;
/* 430:    */   public static final float AL_AUTOWAH_DEFAULT_RESONANCE = 1000.0F;
/* 431:    */   public static final float AL_AUTOWAH_MIN_PEAK_GAIN = 3.0E-005F;
/* 432:    */   public static final float AL_AUTOWAH_MAX_PEAK_GAIN = 31621.0F;
/* 433:    */   public static final float AL_AUTOWAH_DEFAULT_PEAK_GAIN = 11.22F;
/* 434:    */   public static final int AL_COMPRESSOR_MIN_ONOFF = 0;
/* 435:    */   public static final int AL_COMPRESSOR_MAX_ONOFF = 1;
/* 436:    */   public static final int AL_COMPRESSOR_DEFAULT_ONOFF = 1;
/* 437:    */   public static final float AL_EQUALIZER_MIN_LOW_GAIN = 0.126F;
/* 438:    */   public static final float AL_EQUALIZER_MAX_LOW_GAIN = 7.943F;
/* 439:    */   public static final float AL_EQUALIZER_DEFAULT_LOW_GAIN = 1.0F;
/* 440:    */   public static final float AL_EQUALIZER_MIN_LOW_CUTOFF = 50.0F;
/* 441:    */   public static final float AL_EQUALIZER_MAX_LOW_CUTOFF = 800.0F;
/* 442:    */   public static final float AL_EQUALIZER_DEFAULT_LOW_CUTOFF = 200.0F;
/* 443:    */   public static final float AL_EQUALIZER_MIN_MID1_GAIN = 0.126F;
/* 444:    */   public static final float AL_EQUALIZER_MAX_MID1_GAIN = 7.943F;
/* 445:    */   public static final float AL_EQUALIZER_DEFAULT_MID1_GAIN = 1.0F;
/* 446:    */   public static final float AL_EQUALIZER_MIN_MID1_CENTER = 200.0F;
/* 447:    */   public static final float AL_EQUALIZER_MAX_MID1_CENTER = 3000.0F;
/* 448:    */   public static final float AL_EQUALIZER_DEFAULT_MID1_CENTER = 500.0F;
/* 449:    */   public static final float AL_EQUALIZER_MIN_MID1_WIDTH = 0.01F;
/* 450:    */   public static final float AL_EQUALIZER_MAX_MID1_WIDTH = 1.0F;
/* 451:    */   public static final float AL_EQUALIZER_DEFAULT_MID1_WIDTH = 1.0F;
/* 452:    */   public static final float AL_EQUALIZER_MIN_MID2_GAIN = 0.126F;
/* 453:    */   public static final float AL_EQUALIZER_MAX_MID2_GAIN = 7.943F;
/* 454:    */   public static final float AL_EQUALIZER_DEFAULT_MID2_GAIN = 1.0F;
/* 455:    */   public static final float AL_EQUALIZER_MIN_MID2_CENTER = 1000.0F;
/* 456:    */   public static final float AL_EQUALIZER_MAX_MID2_CENTER = 8000.0F;
/* 457:    */   public static final float AL_EQUALIZER_DEFAULT_MID2_CENTER = 3000.0F;
/* 458:    */   public static final float AL_EQUALIZER_MIN_MID2_WIDTH = 0.01F;
/* 459:    */   public static final float AL_EQUALIZER_MAX_MID2_WIDTH = 1.0F;
/* 460:    */   public static final float AL_EQUALIZER_DEFAULT_MID2_WIDTH = 1.0F;
/* 461:    */   public static final float AL_EQUALIZER_MIN_HIGH_GAIN = 0.126F;
/* 462:    */   public static final float AL_EQUALIZER_MAX_HIGH_GAIN = 7.943F;
/* 463:    */   public static final float AL_EQUALIZER_DEFAULT_HIGH_GAIN = 1.0F;
/* 464:    */   public static final float AL_EQUALIZER_MIN_HIGH_CUTOFF = 4000.0F;
/* 465:    */   public static final float AL_EQUALIZER_MAX_HIGH_CUTOFF = 16000.0F;
/* 466:    */   public static final float AL_EQUALIZER_DEFAULT_HIGH_CUTOFF = 6000.0F;
/* 467:    */   public static final float LOWPASS_MIN_GAIN = 0.0F;
/* 468:    */   public static final float LOWPASS_MAX_GAIN = 1.0F;
/* 469:    */   public static final float LOWPASS_DEFAULT_GAIN = 1.0F;
/* 470:    */   public static final float LOWPASS_MIN_GAINHF = 0.0F;
/* 471:    */   public static final float LOWPASS_MAX_GAINHF = 1.0F;
/* 472:    */   public static final float LOWPASS_DEFAULT_GAINHF = 1.0F;
/* 473:    */   public static final float HIGHPASS_MIN_GAIN = 0.0F;
/* 474:    */   public static final float HIGHPASS_MAX_GAIN = 1.0F;
/* 475:    */   public static final float HIGHPASS_DEFAULT_GAIN = 1.0F;
/* 476:    */   public static final float HIGHPASS_MIN_GAINLF = 0.0F;
/* 477:    */   public static final float HIGHPASS_MAX_GAINLF = 1.0F;
/* 478:    */   public static final float HIGHPASS_DEFAULT_GAINLF = 1.0F;
/* 479:    */   public static final float BANDPASS_MIN_GAIN = 0.0F;
/* 480:    */   public static final float BANDPASS_MAX_GAIN = 1.0F;
/* 481:    */   public static final float BANDPASS_DEFAULT_GAIN = 1.0F;
/* 482:    */   public static final float BANDPASS_MIN_GAINHF = 0.0F;
/* 483:    */   public static final float BANDPASS_MAX_GAINHF = 1.0F;
/* 484:    */   public static final float BANDPASS_DEFAULT_GAINHF = 1.0F;
/* 485:    */   public static final float BANDPASS_MIN_GAINLF = 0.0F;
/* 486:    */   public static final float BANDPASS_MAX_GAINLF = 1.0F;
/* 487:    */   public static final float BANDPASS_DEFAULT_GAINLF = 1.0F;
/* 488:    */   
/* 489:    */   static native void initNativeStubs()
/* 490:    */     throws LWJGLException;
/* 491:    */   
/* 492:    */   public static void alGenAuxiliaryEffectSlots(IntBuffer auxiliaryeffectslots)
/* 493:    */   {
/* 494:528 */     BufferChecks.checkDirect(auxiliaryeffectslots);
/* 495:529 */     nalGenAuxiliaryEffectSlots(auxiliaryeffectslots.remaining(), MemoryUtil.getAddress(auxiliaryeffectslots));
/* 496:    */   }
/* 497:    */   
/* 498:    */   static native void nalGenAuxiliaryEffectSlots(int paramInt, long paramLong);
/* 499:    */   
/* 500:    */   public static int alGenAuxiliaryEffectSlots()
/* 501:    */   {
/* 502:535 */     int __result = nalGenAuxiliaryEffectSlots2(1);
/* 503:536 */     return __result;
/* 504:    */   }
/* 505:    */   
/* 506:    */   static native int nalGenAuxiliaryEffectSlots2(int paramInt);
/* 507:    */   
/* 508:    */   public static void alDeleteAuxiliaryEffectSlots(IntBuffer auxiliaryeffectslots)
/* 509:    */   {
/* 510:541 */     BufferChecks.checkDirect(auxiliaryeffectslots);
/* 511:542 */     nalDeleteAuxiliaryEffectSlots(auxiliaryeffectslots.remaining(), MemoryUtil.getAddress(auxiliaryeffectslots));
/* 512:    */   }
/* 513:    */   
/* 514:    */   static native void nalDeleteAuxiliaryEffectSlots(int paramInt, long paramLong);
/* 515:    */   
/* 516:    */   public static void alDeleteAuxiliaryEffectSlots(int auxiliaryeffectslot)
/* 517:    */   {
/* 518:548 */     nalDeleteAuxiliaryEffectSlots2(1, auxiliaryeffectslot);
/* 519:    */   }
/* 520:    */   
/* 521:    */   static native void nalDeleteAuxiliaryEffectSlots2(int paramInt1, int paramInt2);
/* 522:    */   
/* 523:    */   public static boolean alIsAuxiliaryEffectSlot(int auxiliaryeffectslot)
/* 524:    */   {
/* 525:553 */     boolean __result = nalIsAuxiliaryEffectSlot(auxiliaryeffectslot);
/* 526:554 */     return __result;
/* 527:    */   }
/* 528:    */   
/* 529:    */   static native boolean nalIsAuxiliaryEffectSlot(int paramInt);
/* 530:    */   
/* 531:    */   public static void alAuxiliaryEffectSloti(int auxiliaryeffectslot, int param, int value)
/* 532:    */   {
/* 533:559 */     nalAuxiliaryEffectSloti(auxiliaryeffectslot, param, value);
/* 534:    */   }
/* 535:    */   
/* 536:    */   static native void nalAuxiliaryEffectSloti(int paramInt1, int paramInt2, int paramInt3);
/* 537:    */   
/* 538:    */   public static void alAuxiliaryEffectSlot(int auxiliaryeffectslot, int param, IntBuffer values)
/* 539:    */   {
/* 540:564 */     BufferChecks.checkBuffer(values, 1);
/* 541:565 */     nalAuxiliaryEffectSlotiv(auxiliaryeffectslot, param, MemoryUtil.getAddress(values));
/* 542:    */   }
/* 543:    */   
/* 544:    */   static native void nalAuxiliaryEffectSlotiv(int paramInt1, int paramInt2, long paramLong);
/* 545:    */   
/* 546:    */   public static void alAuxiliaryEffectSlotf(int auxiliaryeffectslot, int param, float value)
/* 547:    */   {
/* 548:570 */     nalAuxiliaryEffectSlotf(auxiliaryeffectslot, param, value);
/* 549:    */   }
/* 550:    */   
/* 551:    */   static native void nalAuxiliaryEffectSlotf(int paramInt1, int paramInt2, float paramFloat);
/* 552:    */   
/* 553:    */   public static void alAuxiliaryEffectSlot(int auxiliaryeffectslot, int param, FloatBuffer values)
/* 554:    */   {
/* 555:575 */     BufferChecks.checkBuffer(values, 1);
/* 556:576 */     nalAuxiliaryEffectSlotfv(auxiliaryeffectslot, param, MemoryUtil.getAddress(values));
/* 557:    */   }
/* 558:    */   
/* 559:    */   static native void nalAuxiliaryEffectSlotfv(int paramInt1, int paramInt2, long paramLong);
/* 560:    */   
/* 561:    */   public static int alGetAuxiliaryEffectSloti(int auxiliaryeffectslot, int param)
/* 562:    */   {
/* 563:581 */     int __result = nalGetAuxiliaryEffectSloti(auxiliaryeffectslot, param);
/* 564:582 */     return __result;
/* 565:    */   }
/* 566:    */   
/* 567:    */   static native int nalGetAuxiliaryEffectSloti(int paramInt1, int paramInt2);
/* 568:    */   
/* 569:    */   public static void alGetAuxiliaryEffectSlot(int auxiliaryeffectslot, int param, IntBuffer intdata)
/* 570:    */   {
/* 571:587 */     BufferChecks.checkBuffer(intdata, 1);
/* 572:588 */     nalGetAuxiliaryEffectSlotiv(auxiliaryeffectslot, param, MemoryUtil.getAddress(intdata));
/* 573:    */   }
/* 574:    */   
/* 575:    */   static native void nalGetAuxiliaryEffectSlotiv(int paramInt1, int paramInt2, long paramLong);
/* 576:    */   
/* 577:    */   public static float alGetAuxiliaryEffectSlotf(int auxiliaryeffectslot, int param)
/* 578:    */   {
/* 579:593 */     float __result = nalGetAuxiliaryEffectSlotf(auxiliaryeffectslot, param);
/* 580:594 */     return __result;
/* 581:    */   }
/* 582:    */   
/* 583:    */   static native float nalGetAuxiliaryEffectSlotf(int paramInt1, int paramInt2);
/* 584:    */   
/* 585:    */   public static void alGetAuxiliaryEffectSlot(int auxiliaryeffectslot, int param, FloatBuffer floatdata)
/* 586:    */   {
/* 587:599 */     BufferChecks.checkBuffer(floatdata, 1);
/* 588:600 */     nalGetAuxiliaryEffectSlotfv(auxiliaryeffectslot, param, MemoryUtil.getAddress(floatdata));
/* 589:    */   }
/* 590:    */   
/* 591:    */   static native void nalGetAuxiliaryEffectSlotfv(int paramInt1, int paramInt2, long paramLong);
/* 592:    */   
/* 593:    */   public static void alGenEffects(IntBuffer effects)
/* 594:    */   {
/* 595:605 */     BufferChecks.checkDirect(effects);
/* 596:606 */     nalGenEffects(effects.remaining(), MemoryUtil.getAddress(effects));
/* 597:    */   }
/* 598:    */   
/* 599:    */   static native void nalGenEffects(int paramInt, long paramLong);
/* 600:    */   
/* 601:    */   public static int alGenEffects()
/* 602:    */   {
/* 603:612 */     int __result = nalGenEffects2(1);
/* 604:613 */     return __result;
/* 605:    */   }
/* 606:    */   
/* 607:    */   static native int nalGenEffects2(int paramInt);
/* 608:    */   
/* 609:    */   public static void alDeleteEffects(IntBuffer effects)
/* 610:    */   {
/* 611:618 */     BufferChecks.checkDirect(effects);
/* 612:619 */     nalDeleteEffects(effects.remaining(), MemoryUtil.getAddress(effects));
/* 613:    */   }
/* 614:    */   
/* 615:    */   static native void nalDeleteEffects(int paramInt, long paramLong);
/* 616:    */   
/* 617:    */   public static void alDeleteEffects(int effect)
/* 618:    */   {
/* 619:625 */     nalDeleteEffects2(1, effect);
/* 620:    */   }
/* 621:    */   
/* 622:    */   static native void nalDeleteEffects2(int paramInt1, int paramInt2);
/* 623:    */   
/* 624:    */   public static boolean alIsEffect(int effect)
/* 625:    */   {
/* 626:630 */     boolean __result = nalIsEffect(effect);
/* 627:631 */     return __result;
/* 628:    */   }
/* 629:    */   
/* 630:    */   static native boolean nalIsEffect(int paramInt);
/* 631:    */   
/* 632:    */   public static void alEffecti(int effect, int param, int value)
/* 633:    */   {
/* 634:636 */     nalEffecti(effect, param, value);
/* 635:    */   }
/* 636:    */   
/* 637:    */   static native void nalEffecti(int paramInt1, int paramInt2, int paramInt3);
/* 638:    */   
/* 639:    */   public static void alEffect(int effect, int param, IntBuffer values)
/* 640:    */   {
/* 641:641 */     BufferChecks.checkBuffer(values, 1);
/* 642:642 */     nalEffectiv(effect, param, MemoryUtil.getAddress(values));
/* 643:    */   }
/* 644:    */   
/* 645:    */   static native void nalEffectiv(int paramInt1, int paramInt2, long paramLong);
/* 646:    */   
/* 647:    */   public static void alEffectf(int effect, int param, float value)
/* 648:    */   {
/* 649:647 */     nalEffectf(effect, param, value);
/* 650:    */   }
/* 651:    */   
/* 652:    */   static native void nalEffectf(int paramInt1, int paramInt2, float paramFloat);
/* 653:    */   
/* 654:    */   public static void alEffect(int effect, int param, FloatBuffer values)
/* 655:    */   {
/* 656:652 */     BufferChecks.checkBuffer(values, 1);
/* 657:653 */     nalEffectfv(effect, param, MemoryUtil.getAddress(values));
/* 658:    */   }
/* 659:    */   
/* 660:    */   static native void nalEffectfv(int paramInt1, int paramInt2, long paramLong);
/* 661:    */   
/* 662:    */   public static int alGetEffecti(int effect, int param)
/* 663:    */   {
/* 664:658 */     int __result = nalGetEffecti(effect, param);
/* 665:659 */     return __result;
/* 666:    */   }
/* 667:    */   
/* 668:    */   static native int nalGetEffecti(int paramInt1, int paramInt2);
/* 669:    */   
/* 670:    */   public static void alGetEffect(int effect, int param, IntBuffer intdata)
/* 671:    */   {
/* 672:664 */     BufferChecks.checkBuffer(intdata, 1);
/* 673:665 */     nalGetEffectiv(effect, param, MemoryUtil.getAddress(intdata));
/* 674:    */   }
/* 675:    */   
/* 676:    */   static native void nalGetEffectiv(int paramInt1, int paramInt2, long paramLong);
/* 677:    */   
/* 678:    */   public static float alGetEffectf(int effect, int param)
/* 679:    */   {
/* 680:670 */     float __result = nalGetEffectf(effect, param);
/* 681:671 */     return __result;
/* 682:    */   }
/* 683:    */   
/* 684:    */   static native float nalGetEffectf(int paramInt1, int paramInt2);
/* 685:    */   
/* 686:    */   public static void alGetEffect(int effect, int param, FloatBuffer floatdata)
/* 687:    */   {
/* 688:676 */     BufferChecks.checkBuffer(floatdata, 1);
/* 689:677 */     nalGetEffectfv(effect, param, MemoryUtil.getAddress(floatdata));
/* 690:    */   }
/* 691:    */   
/* 692:    */   static native void nalGetEffectfv(int paramInt1, int paramInt2, long paramLong);
/* 693:    */   
/* 694:    */   public static void alGenFilters(IntBuffer filters)
/* 695:    */   {
/* 696:682 */     BufferChecks.checkDirect(filters);
/* 697:683 */     nalGenFilters(filters.remaining(), MemoryUtil.getAddress(filters));
/* 698:    */   }
/* 699:    */   
/* 700:    */   static native void nalGenFilters(int paramInt, long paramLong);
/* 701:    */   
/* 702:    */   public static int alGenFilters()
/* 703:    */   {
/* 704:689 */     int __result = nalGenFilters2(1);
/* 705:690 */     return __result;
/* 706:    */   }
/* 707:    */   
/* 708:    */   static native int nalGenFilters2(int paramInt);
/* 709:    */   
/* 710:    */   public static void alDeleteFilters(IntBuffer filters)
/* 711:    */   {
/* 712:695 */     BufferChecks.checkDirect(filters);
/* 713:696 */     nalDeleteFilters(filters.remaining(), MemoryUtil.getAddress(filters));
/* 714:    */   }
/* 715:    */   
/* 716:    */   static native void nalDeleteFilters(int paramInt, long paramLong);
/* 717:    */   
/* 718:    */   public static void alDeleteFilters(int filter)
/* 719:    */   {
/* 720:702 */     nalDeleteFilters2(1, filter);
/* 721:    */   }
/* 722:    */   
/* 723:    */   static native void nalDeleteFilters2(int paramInt1, int paramInt2);
/* 724:    */   
/* 725:    */   public static boolean alIsFilter(int filter)
/* 726:    */   {
/* 727:707 */     boolean __result = nalIsFilter(filter);
/* 728:708 */     return __result;
/* 729:    */   }
/* 730:    */   
/* 731:    */   static native boolean nalIsFilter(int paramInt);
/* 732:    */   
/* 733:    */   public static void alFilteri(int filter, int param, int value)
/* 734:    */   {
/* 735:713 */     nalFilteri(filter, param, value);
/* 736:    */   }
/* 737:    */   
/* 738:    */   static native void nalFilteri(int paramInt1, int paramInt2, int paramInt3);
/* 739:    */   
/* 740:    */   public static void alFilter(int filter, int param, IntBuffer values)
/* 741:    */   {
/* 742:718 */     BufferChecks.checkBuffer(values, 1);
/* 743:719 */     nalFilteriv(filter, param, MemoryUtil.getAddress(values));
/* 744:    */   }
/* 745:    */   
/* 746:    */   static native void nalFilteriv(int paramInt1, int paramInt2, long paramLong);
/* 747:    */   
/* 748:    */   public static void alFilterf(int filter, int param, float value)
/* 749:    */   {
/* 750:724 */     nalFilterf(filter, param, value);
/* 751:    */   }
/* 752:    */   
/* 753:    */   static native void nalFilterf(int paramInt1, int paramInt2, float paramFloat);
/* 754:    */   
/* 755:    */   public static void alFilter(int filter, int param, FloatBuffer values)
/* 756:    */   {
/* 757:729 */     BufferChecks.checkBuffer(values, 1);
/* 758:730 */     nalFilterfv(filter, param, MemoryUtil.getAddress(values));
/* 759:    */   }
/* 760:    */   
/* 761:    */   static native void nalFilterfv(int paramInt1, int paramInt2, long paramLong);
/* 762:    */   
/* 763:    */   public static int alGetFilteri(int filter, int param)
/* 764:    */   {
/* 765:735 */     int __result = nalGetFilteri(filter, param);
/* 766:736 */     return __result;
/* 767:    */   }
/* 768:    */   
/* 769:    */   static native int nalGetFilteri(int paramInt1, int paramInt2);
/* 770:    */   
/* 771:    */   public static void alGetFilter(int filter, int param, IntBuffer intdata)
/* 772:    */   {
/* 773:741 */     BufferChecks.checkBuffer(intdata, 1);
/* 774:742 */     nalGetFilteriv(filter, param, MemoryUtil.getAddress(intdata));
/* 775:    */   }
/* 776:    */   
/* 777:    */   static native void nalGetFilteriv(int paramInt1, int paramInt2, long paramLong);
/* 778:    */   
/* 779:    */   public static float alGetFilterf(int filter, int param)
/* 780:    */   {
/* 781:747 */     float __result = nalGetFilterf(filter, param);
/* 782:748 */     return __result;
/* 783:    */   }
/* 784:    */   
/* 785:    */   static native float nalGetFilterf(int paramInt1, int paramInt2);
/* 786:    */   
/* 787:    */   public static void alGetFilter(int filter, int param, FloatBuffer floatdata)
/* 788:    */   {
/* 789:753 */     BufferChecks.checkBuffer(floatdata, 1);
/* 790:754 */     nalGetFilterfv(filter, param, MemoryUtil.getAddress(floatdata));
/* 791:    */   }
/* 792:    */   
/* 793:    */   static native void nalGetFilterfv(int paramInt1, int paramInt2, long paramLong);
/* 794:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.EFX10
 * JD-Core Version:    0.7.0.1
 */