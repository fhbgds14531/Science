/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.DoubleBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class ARBGpuShaderFp64
/*   8:    */ {
/*   9:    */   public static final int GL_DOUBLE = 5130;
/*  10:    */   public static final int GL_DOUBLE_VEC2 = 36860;
/*  11:    */   public static final int GL_DOUBLE_VEC3 = 36861;
/*  12:    */   public static final int GL_DOUBLE_VEC4 = 36862;
/*  13:    */   public static final int GL_DOUBLE_MAT2 = 36678;
/*  14:    */   public static final int GL_DOUBLE_MAT3 = 36679;
/*  15:    */   public static final int GL_DOUBLE_MAT4 = 36680;
/*  16:    */   public static final int GL_DOUBLE_MAT2x3 = 36681;
/*  17:    */   public static final int GL_DOUBLE_MAT2x4 = 36682;
/*  18:    */   public static final int GL_DOUBLE_MAT3x2 = 36683;
/*  19:    */   public static final int GL_DOUBLE_MAT3x4 = 36684;
/*  20:    */   public static final int GL_DOUBLE_MAT4x2 = 36685;
/*  21:    */   public static final int GL_DOUBLE_MAT4x3 = 36686;
/*  22:    */   
/*  23:    */   public static void glUniform1d(int location, double x)
/*  24:    */   {
/*  25: 31 */     GL40.glUniform1d(location, x);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static void glUniform2d(int location, double x, double y)
/*  29:    */   {
/*  30: 35 */     GL40.glUniform2d(location, x, y);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static void glUniform3d(int location, double x, double y, double z)
/*  34:    */   {
/*  35: 39 */     GL40.glUniform3d(location, x, y, z);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static void glUniform4d(int location, double x, double y, double z, double w)
/*  39:    */   {
/*  40: 43 */     GL40.glUniform4d(location, x, y, z, w);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void glUniform1(int location, DoubleBuffer value)
/*  44:    */   {
/*  45: 47 */     GL40.glUniform1(location, value);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static void glUniform2(int location, DoubleBuffer value)
/*  49:    */   {
/*  50: 51 */     GL40.glUniform2(location, value);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static void glUniform3(int location, DoubleBuffer value)
/*  54:    */   {
/*  55: 55 */     GL40.glUniform3(location, value);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static void glUniform4(int location, DoubleBuffer value)
/*  59:    */   {
/*  60: 59 */     GL40.glUniform4(location, value);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void glUniformMatrix2(int location, boolean transpose, DoubleBuffer value)
/*  64:    */   {
/*  65: 63 */     GL40.glUniformMatrix2(location, transpose, value);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static void glUniformMatrix3(int location, boolean transpose, DoubleBuffer value)
/*  69:    */   {
/*  70: 67 */     GL40.glUniformMatrix3(location, transpose, value);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static void glUniformMatrix4(int location, boolean transpose, DoubleBuffer value)
/*  74:    */   {
/*  75: 71 */     GL40.glUniformMatrix4(location, transpose, value);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static void glUniformMatrix2x3(int location, boolean transpose, DoubleBuffer value)
/*  79:    */   {
/*  80: 75 */     GL40.glUniformMatrix2x3(location, transpose, value);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void glUniformMatrix2x4(int location, boolean transpose, DoubleBuffer value)
/*  84:    */   {
/*  85: 79 */     GL40.glUniformMatrix2x4(location, transpose, value);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static void glUniformMatrix3x2(int location, boolean transpose, DoubleBuffer value)
/*  89:    */   {
/*  90: 83 */     GL40.glUniformMatrix3x2(location, transpose, value);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static void glUniformMatrix3x4(int location, boolean transpose, DoubleBuffer value)
/*  94:    */   {
/*  95: 87 */     GL40.glUniformMatrix3x4(location, transpose, value);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void glUniformMatrix4x2(int location, boolean transpose, DoubleBuffer value)
/*  99:    */   {
/* 100: 91 */     GL40.glUniformMatrix4x2(location, transpose, value);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void glUniformMatrix4x3(int location, boolean transpose, DoubleBuffer value)
/* 104:    */   {
/* 105: 95 */     GL40.glUniformMatrix4x3(location, transpose, value);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static void glGetUniform(int program, int location, DoubleBuffer params)
/* 109:    */   {
/* 110: 99 */     GL40.glGetUniform(program, location, params);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void glProgramUniform1dEXT(int program, int location, double x)
/* 114:    */   {
/* 115:103 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116:104 */     long function_pointer = caps.glProgramUniform1dEXT;
/* 117:105 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:106 */     nglProgramUniform1dEXT(program, location, x, function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native void nglProgramUniform1dEXT(int paramInt1, int paramInt2, double paramDouble, long paramLong);
/* 122:    */   
/* 123:    */   public static void glProgramUniform2dEXT(int program, int location, double x, double y)
/* 124:    */   {
/* 125:111 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:112 */     long function_pointer = caps.glProgramUniform2dEXT;
/* 127:113 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:114 */     nglProgramUniform2dEXT(program, location, x, y, function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglProgramUniform2dEXT(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, long paramLong);
/* 132:    */   
/* 133:    */   public static void glProgramUniform3dEXT(int program, int location, double x, double y, double z)
/* 134:    */   {
/* 135:119 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 136:120 */     long function_pointer = caps.glProgramUniform3dEXT;
/* 137:121 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 138:122 */     nglProgramUniform3dEXT(program, location, x, y, z, function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglProgramUniform3dEXT(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 142:    */   
/* 143:    */   public static void glProgramUniform4dEXT(int program, int location, double x, double y, double z, double w)
/* 144:    */   {
/* 145:127 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 146:128 */     long function_pointer = caps.glProgramUniform4dEXT;
/* 147:129 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 148:130 */     nglProgramUniform4dEXT(program, location, x, y, z, w, function_pointer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   static native void nglProgramUniform4dEXT(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 152:    */   
/* 153:    */   public static void glProgramUniform1EXT(int program, int location, DoubleBuffer value)
/* 154:    */   {
/* 155:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 156:136 */     long function_pointer = caps.glProgramUniform1dvEXT;
/* 157:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 158:138 */     BufferChecks.checkDirect(value);
/* 159:139 */     nglProgramUniform1dvEXT(program, location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 160:    */   }
/* 161:    */   
/* 162:    */   static native void nglProgramUniform1dvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 163:    */   
/* 164:    */   public static void glProgramUniform2EXT(int program, int location, DoubleBuffer value)
/* 165:    */   {
/* 166:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 167:145 */     long function_pointer = caps.glProgramUniform2dvEXT;
/* 168:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 169:147 */     BufferChecks.checkDirect(value);
/* 170:148 */     nglProgramUniform2dvEXT(program, location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 171:    */   }
/* 172:    */   
/* 173:    */   static native void nglProgramUniform2dvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 174:    */   
/* 175:    */   public static void glProgramUniform3EXT(int program, int location, DoubleBuffer value)
/* 176:    */   {
/* 177:153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 178:154 */     long function_pointer = caps.glProgramUniform3dvEXT;
/* 179:155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 180:156 */     BufferChecks.checkDirect(value);
/* 181:157 */     nglProgramUniform3dvEXT(program, location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 182:    */   }
/* 183:    */   
/* 184:    */   static native void nglProgramUniform3dvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 185:    */   
/* 186:    */   public static void glProgramUniform4EXT(int program, int location, DoubleBuffer value)
/* 187:    */   {
/* 188:162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 189:163 */     long function_pointer = caps.glProgramUniform4dvEXT;
/* 190:164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 191:165 */     BufferChecks.checkDirect(value);
/* 192:166 */     nglProgramUniform4dvEXT(program, location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   static native void nglProgramUniform4dvEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 196:    */   
/* 197:    */   public static void glProgramUniformMatrix2EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 198:    */   {
/* 199:171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:172 */     long function_pointer = caps.glProgramUniformMatrix2dvEXT;
/* 201:173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:174 */     BufferChecks.checkDirect(value);
/* 203:175 */     nglProgramUniformMatrix2dvEXT(program, location, value.remaining() >> 2, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   static native void nglProgramUniformMatrix2dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 207:    */   
/* 208:    */   public static void glProgramUniformMatrix3EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 209:    */   {
/* 210:180 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 211:181 */     long function_pointer = caps.glProgramUniformMatrix3dvEXT;
/* 212:182 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 213:183 */     BufferChecks.checkDirect(value);
/* 214:184 */     nglProgramUniformMatrix3dvEXT(program, location, value.remaining() / 9, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 215:    */   }
/* 216:    */   
/* 217:    */   static native void nglProgramUniformMatrix3dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 218:    */   
/* 219:    */   public static void glProgramUniformMatrix4EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 220:    */   {
/* 221:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 222:190 */     long function_pointer = caps.glProgramUniformMatrix4dvEXT;
/* 223:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 224:192 */     BufferChecks.checkDirect(value);
/* 225:193 */     nglProgramUniformMatrix4dvEXT(program, location, value.remaining() >> 4, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 226:    */   }
/* 227:    */   
/* 228:    */   static native void nglProgramUniformMatrix4dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 229:    */   
/* 230:    */   public static void glProgramUniformMatrix2x3EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 231:    */   {
/* 232:198 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 233:199 */     long function_pointer = caps.glProgramUniformMatrix2x3dvEXT;
/* 234:200 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 235:201 */     BufferChecks.checkDirect(value);
/* 236:202 */     nglProgramUniformMatrix2x3dvEXT(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 237:    */   }
/* 238:    */   
/* 239:    */   static native void nglProgramUniformMatrix2x3dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 240:    */   
/* 241:    */   public static void glProgramUniformMatrix2x4EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 242:    */   {
/* 243:207 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 244:208 */     long function_pointer = caps.glProgramUniformMatrix2x4dvEXT;
/* 245:209 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 246:210 */     BufferChecks.checkDirect(value);
/* 247:211 */     nglProgramUniformMatrix2x4dvEXT(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 248:    */   }
/* 249:    */   
/* 250:    */   static native void nglProgramUniformMatrix2x4dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 251:    */   
/* 252:    */   public static void glProgramUniformMatrix3x2EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 253:    */   {
/* 254:216 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 255:217 */     long function_pointer = caps.glProgramUniformMatrix3x2dvEXT;
/* 256:218 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 257:219 */     BufferChecks.checkDirect(value);
/* 258:220 */     nglProgramUniformMatrix3x2dvEXT(program, location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 259:    */   }
/* 260:    */   
/* 261:    */   static native void nglProgramUniformMatrix3x2dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 262:    */   
/* 263:    */   public static void glProgramUniformMatrix3x4EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 264:    */   {
/* 265:225 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 266:226 */     long function_pointer = caps.glProgramUniformMatrix3x4dvEXT;
/* 267:227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 268:228 */     BufferChecks.checkDirect(value);
/* 269:229 */     nglProgramUniformMatrix3x4dvEXT(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 270:    */   }
/* 271:    */   
/* 272:    */   static native void nglProgramUniformMatrix3x4dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 273:    */   
/* 274:    */   public static void glProgramUniformMatrix4x2EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 275:    */   {
/* 276:234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 277:235 */     long function_pointer = caps.glProgramUniformMatrix4x2dvEXT;
/* 278:236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 279:237 */     BufferChecks.checkDirect(value);
/* 280:238 */     nglProgramUniformMatrix4x2dvEXT(program, location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 281:    */   }
/* 282:    */   
/* 283:    */   static native void nglProgramUniformMatrix4x2dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 284:    */   
/* 285:    */   public static void glProgramUniformMatrix4x3EXT(int program, int location, boolean transpose, DoubleBuffer value)
/* 286:    */   {
/* 287:243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 288:244 */     long function_pointer = caps.glProgramUniformMatrix4x3dvEXT;
/* 289:245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 290:246 */     BufferChecks.checkDirect(value);
/* 291:247 */     nglProgramUniformMatrix4x3dvEXT(program, location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 292:    */   }
/* 293:    */   
/* 294:    */   static native void nglProgramUniformMatrix4x3dvEXT(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong1, long paramLong2);
/* 295:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBGpuShaderFp64
 * JD-Core Version:    0.7.0.1
 */