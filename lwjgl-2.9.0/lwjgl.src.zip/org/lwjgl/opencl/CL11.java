/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.LongBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.MemoryUtil;
/*  11:    */ import org.lwjgl.PointerBuffer;
/*  12:    */ 
/*  13:    */ public final class CL11
/*  14:    */ {
/*  15:    */   public static final int CL_MISALIGNED_SUB_BUFFER_OFFSET = -13;
/*  16:    */   public static final int CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST = -14;
/*  17:    */   public static final int CL_INVALID_PROPERTY = -64;
/*  18:    */   public static final int CL_VERSION_1_1 = 1;
/*  19:    */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_HALF = 4148;
/*  20:    */   public static final int CL_DEVICE_HOST_UNIFIED_MEMORY = 4149;
/*  21:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_CHAR = 4150;
/*  22:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_SHORT = 4151;
/*  23:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_INT = 4152;
/*  24:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_LONG = 4153;
/*  25:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_FLOAT = 4154;
/*  26:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_DOUBLE = 4155;
/*  27:    */   public static final int CL_DEVICE_NATIVE_VECTOR_WIDTH_HALF = 4156;
/*  28:    */   public static final int CL_DEVICE_OPENCL_C_VERSION = 4157;
/*  29:    */   public static final int CL_FP_SOFT_FLOAT = 64;
/*  30:    */   public static final int CL_CONTEXT_NUM_DEVICES = 4227;
/*  31:    */   public static final int CL_Rx = 4282;
/*  32:    */   public static final int CL_RGx = 4283;
/*  33:    */   public static final int CL_RGBx = 4284;
/*  34:    */   public static final int CL_MEM_ASSOCIATED_MEMOBJECT = 4359;
/*  35:    */   public static final int CL_MEM_OFFSET = 4360;
/*  36:    */   public static final int CL_ADDRESS_MIRRORED_REPEAT = 4404;
/*  37:    */   public static final int CL_KERNEL_PREFERRED_WORK_GROUP_SIZE_MULTIPLE = 4531;
/*  38:    */   public static final int CL_KERNEL_PRIVATE_MEM_SIZE = 4532;
/*  39:    */   public static final int CL_EVENT_CONTEXT = 4564;
/*  40:    */   public static final int CL_COMMAND_READ_BUFFER_RECT = 4609;
/*  41:    */   public static final int CL_COMMAND_WRITE_BUFFER_RECT = 4610;
/*  42:    */   public static final int CL_COMMAND_COPY_BUFFER_RECT = 4611;
/*  43:    */   public static final int CL_COMMAND_USER = 4612;
/*  44:    */   public static final int CL_BUFFER_CREATE_TYPE_REGION = 4640;
/*  45:    */   
/*  46:    */   public static CLMem clCreateSubBuffer(CLMem buffer, long flags, int buffer_create_type, ByteBuffer buffer_create_info, IntBuffer errcode_ret)
/*  47:    */   {
/*  48: 94 */     long function_pointer = CLCapabilities.clCreateSubBuffer;
/*  49: 95 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  50: 96 */     BufferChecks.checkBuffer(buffer_create_info, 2 * PointerBuffer.getPointerSize());
/*  51: 97 */     if (errcode_ret != null) {
/*  52: 98 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  53:    */     }
/*  54: 99 */     CLMem __result = CLMem.create(nclCreateSubBuffer(buffer.getPointer(), flags, buffer_create_type, MemoryUtil.getAddress(buffer_create_info), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), (CLContext)buffer.getParent());
/*  55:100 */     return __result;
/*  56:    */   }
/*  57:    */   
/*  58:    */   static native long nclCreateSubBuffer(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/*  59:    */   
/*  60:    */   public static int clSetMemObjectDestructorCallback(CLMem memobj, CLMemObjectDestructorCallback pfn_notify)
/*  61:    */   {
/*  62:105 */     long function_pointer = CLCapabilities.clSetMemObjectDestructorCallback;
/*  63:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  64:107 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/*  65:108 */     int __result = 0;
/*  66:    */     try
/*  67:    */     {
/*  68:110 */       __result = nclSetMemObjectDestructorCallback(memobj.getPointer(), pfn_notify.getPointer(), user_data, function_pointer);
/*  69:111 */       return __result;
/*  70:    */     }
/*  71:    */     finally
/*  72:    */     {
/*  73:113 */       CallbackUtil.checkCallback(__result, user_data);
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native int nclSetMemObjectDestructorCallback(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*  78:    */   
/*  79:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  80:    */   {
/*  81:119 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/*  82:120 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  83:121 */     BufferChecks.checkBuffer(buffer_offset, 3);
/*  84:122 */     BufferChecks.checkBuffer(host_offset, 3);
/*  85:123 */     BufferChecks.checkBuffer(region, 3);
/*  86:124 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/*  87:125 */     if (event_wait_list != null) {
/*  88:126 */       BufferChecks.checkDirect(event_wait_list);
/*  89:    */     }
/*  90:127 */     if (event != null) {
/*  91:128 */       BufferChecks.checkBuffer(event, 1);
/*  92:    */     }
/*  93:129 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  94:130 */     if (__result == 0) {
/*  95:130 */       command_queue.registerCLEvent(event);
/*  96:    */     }
/*  97:131 */     return __result;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, DoubleBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 101:    */   {
/* 102:134 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/* 103:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 104:136 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 105:137 */     BufferChecks.checkBuffer(host_offset, 3);
/* 106:138 */     BufferChecks.checkBuffer(region, 3);
/* 107:139 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 108:140 */     if (event_wait_list != null) {
/* 109:141 */       BufferChecks.checkDirect(event_wait_list);
/* 110:    */     }
/* 111:142 */     if (event != null) {
/* 112:143 */       BufferChecks.checkBuffer(event, 1);
/* 113:    */     }
/* 114:144 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 115:145 */     if (__result == 0) {
/* 116:145 */       command_queue.registerCLEvent(event);
/* 117:    */     }
/* 118:146 */     return __result;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 122:    */   {
/* 123:149 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/* 124:150 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 125:151 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 126:152 */     BufferChecks.checkBuffer(host_offset, 3);
/* 127:153 */     BufferChecks.checkBuffer(region, 3);
/* 128:154 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 129:155 */     if (event_wait_list != null) {
/* 130:156 */       BufferChecks.checkDirect(event_wait_list);
/* 131:    */     }
/* 132:157 */     if (event != null) {
/* 133:158 */       BufferChecks.checkBuffer(event, 1);
/* 134:    */     }
/* 135:159 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 136:160 */     if (__result == 0) {
/* 137:160 */       command_queue.registerCLEvent(event);
/* 138:    */     }
/* 139:161 */     return __result;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 143:    */   {
/* 144:164 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/* 145:165 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 146:166 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 147:167 */     BufferChecks.checkBuffer(host_offset, 3);
/* 148:168 */     BufferChecks.checkBuffer(region, 3);
/* 149:169 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 150:170 */     if (event_wait_list != null) {
/* 151:171 */       BufferChecks.checkDirect(event_wait_list);
/* 152:    */     }
/* 153:172 */     if (event != null) {
/* 154:173 */       BufferChecks.checkBuffer(event, 1);
/* 155:    */     }
/* 156:174 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 157:175 */     if (__result == 0) {
/* 158:175 */       command_queue.registerCLEvent(event);
/* 159:    */     }
/* 160:176 */     return __result;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, LongBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 164:    */   {
/* 165:179 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/* 166:180 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 167:181 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 168:182 */     BufferChecks.checkBuffer(host_offset, 3);
/* 169:183 */     BufferChecks.checkBuffer(region, 3);
/* 170:184 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 171:185 */     if (event_wait_list != null) {
/* 172:186 */       BufferChecks.checkDirect(event_wait_list);
/* 173:    */     }
/* 174:187 */     if (event != null) {
/* 175:188 */       BufferChecks.checkBuffer(event, 1);
/* 176:    */     }
/* 177:189 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 178:190 */     if (__result == 0) {
/* 179:190 */       command_queue.registerCLEvent(event);
/* 180:    */     }
/* 181:191 */     return __result;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static int clEnqueueReadBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_read, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 185:    */   {
/* 186:194 */     long function_pointer = CLCapabilities.clEnqueueReadBufferRect;
/* 187:195 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 188:196 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 189:197 */     BufferChecks.checkBuffer(host_offset, 3);
/* 190:198 */     BufferChecks.checkBuffer(region, 3);
/* 191:199 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 192:200 */     if (event_wait_list != null) {
/* 193:201 */       BufferChecks.checkDirect(event_wait_list);
/* 194:    */     }
/* 195:202 */     if (event != null) {
/* 196:203 */       BufferChecks.checkBuffer(event, 1);
/* 197:    */     }
/* 198:204 */     int __result = nclEnqueueReadBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_read, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 199:205 */     if (__result == 0) {
/* 200:205 */       command_queue.registerCLEvent(event);
/* 201:    */     }
/* 202:206 */     return __result;
/* 203:    */   }
/* 204:    */   
/* 205:    */   static native int nclEnqueueReadBufferRect(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10, int paramInt2, long paramLong11, long paramLong12, long paramLong13);
/* 206:    */   
/* 207:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 208:    */   {
/* 209:211 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 210:212 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 211:213 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 212:214 */     BufferChecks.checkBuffer(host_offset, 3);
/* 213:215 */     BufferChecks.checkBuffer(region, 3);
/* 214:216 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 215:217 */     if (event_wait_list != null) {
/* 216:218 */       BufferChecks.checkDirect(event_wait_list);
/* 217:    */     }
/* 218:219 */     if (event != null) {
/* 219:220 */       BufferChecks.checkBuffer(event, 1);
/* 220:    */     }
/* 221:221 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 222:222 */     if (__result == 0) {
/* 223:222 */       command_queue.registerCLEvent(event);
/* 224:    */     }
/* 225:223 */     return __result;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, DoubleBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 229:    */   {
/* 230:226 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 231:227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 232:228 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 233:229 */     BufferChecks.checkBuffer(host_offset, 3);
/* 234:230 */     BufferChecks.checkBuffer(region, 3);
/* 235:231 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 236:232 */     if (event_wait_list != null) {
/* 237:233 */       BufferChecks.checkDirect(event_wait_list);
/* 238:    */     }
/* 239:234 */     if (event != null) {
/* 240:235 */       BufferChecks.checkBuffer(event, 1);
/* 241:    */     }
/* 242:236 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 243:237 */     if (__result == 0) {
/* 244:237 */       command_queue.registerCLEvent(event);
/* 245:    */     }
/* 246:238 */     return __result;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 250:    */   {
/* 251:241 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 252:242 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 253:243 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 254:244 */     BufferChecks.checkBuffer(host_offset, 3);
/* 255:245 */     BufferChecks.checkBuffer(region, 3);
/* 256:246 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 257:247 */     if (event_wait_list != null) {
/* 258:248 */       BufferChecks.checkDirect(event_wait_list);
/* 259:    */     }
/* 260:249 */     if (event != null) {
/* 261:250 */       BufferChecks.checkBuffer(event, 1);
/* 262:    */     }
/* 263:251 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 264:252 */     if (__result == 0) {
/* 265:252 */       command_queue.registerCLEvent(event);
/* 266:    */     }
/* 267:253 */     return __result;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 271:    */   {
/* 272:256 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 273:257 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 274:258 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 275:259 */     BufferChecks.checkBuffer(host_offset, 3);
/* 276:260 */     BufferChecks.checkBuffer(region, 3);
/* 277:261 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 278:262 */     if (event_wait_list != null) {
/* 279:263 */       BufferChecks.checkDirect(event_wait_list);
/* 280:    */     }
/* 281:264 */     if (event != null) {
/* 282:265 */       BufferChecks.checkBuffer(event, 1);
/* 283:    */     }
/* 284:266 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 285:267 */     if (__result == 0) {
/* 286:267 */       command_queue.registerCLEvent(event);
/* 287:    */     }
/* 288:268 */     return __result;
/* 289:    */   }
/* 290:    */   
/* 291:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, LongBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 292:    */   {
/* 293:271 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 294:272 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 295:273 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 296:274 */     BufferChecks.checkBuffer(host_offset, 3);
/* 297:275 */     BufferChecks.checkBuffer(region, 3);
/* 298:276 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 299:277 */     if (event_wait_list != null) {
/* 300:278 */       BufferChecks.checkDirect(event_wait_list);
/* 301:    */     }
/* 302:279 */     if (event != null) {
/* 303:280 */       BufferChecks.checkBuffer(event, 1);
/* 304:    */     }
/* 305:281 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 306:282 */     if (__result == 0) {
/* 307:282 */       command_queue.registerCLEvent(event);
/* 308:    */     }
/* 309:283 */     return __result;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public static int clEnqueueWriteBufferRect(CLCommandQueue command_queue, CLMem buffer, int blocking_write, PointerBuffer buffer_offset, PointerBuffer host_offset, PointerBuffer region, long buffer_row_pitch, long buffer_slice_pitch, long host_row_pitch, long host_slice_pitch, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 313:    */   {
/* 314:286 */     long function_pointer = CLCapabilities.clEnqueueWriteBufferRect;
/* 315:287 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 316:288 */     BufferChecks.checkBuffer(buffer_offset, 3);
/* 317:289 */     BufferChecks.checkBuffer(host_offset, 3);
/* 318:290 */     BufferChecks.checkBuffer(region, 3);
/* 319:291 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateBufferRectSize(host_offset, region, host_row_pitch, host_slice_pitch));
/* 320:292 */     if (event_wait_list != null) {
/* 321:293 */       BufferChecks.checkDirect(event_wait_list);
/* 322:    */     }
/* 323:294 */     if (event != null) {
/* 324:295 */       BufferChecks.checkBuffer(event, 1);
/* 325:    */     }
/* 326:296 */     int __result = nclEnqueueWriteBufferRect(command_queue.getPointer(), buffer.getPointer(), blocking_write, MemoryUtil.getAddress(buffer_offset), MemoryUtil.getAddress(host_offset), MemoryUtil.getAddress(region), buffer_row_pitch, buffer_slice_pitch, host_row_pitch, host_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 327:297 */     if (__result == 0) {
/* 328:297 */       command_queue.registerCLEvent(event);
/* 329:    */     }
/* 330:298 */     return __result;
/* 331:    */   }
/* 332:    */   
/* 333:    */   static native int nclEnqueueWriteBufferRect(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10, int paramInt2, long paramLong11, long paramLong12, long paramLong13);
/* 334:    */   
/* 335:    */   public static int clEnqueueCopyBufferRect(CLCommandQueue command_queue, CLMem src_buffer, CLMem dst_buffer, PointerBuffer src_origin, PointerBuffer dst_origin, PointerBuffer region, long src_row_pitch, long src_slice_pitch, long dst_row_pitch, long dst_slice_pitch, PointerBuffer event_wait_list, PointerBuffer event)
/* 336:    */   {
/* 337:303 */     long function_pointer = CLCapabilities.clEnqueueCopyBufferRect;
/* 338:304 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 339:305 */     BufferChecks.checkBuffer(src_origin, 3);
/* 340:306 */     BufferChecks.checkBuffer(dst_origin, 3);
/* 341:307 */     BufferChecks.checkBuffer(region, 3);
/* 342:308 */     if (event_wait_list != null) {
/* 343:309 */       BufferChecks.checkDirect(event_wait_list);
/* 344:    */     }
/* 345:310 */     if (event != null) {
/* 346:311 */       BufferChecks.checkBuffer(event, 1);
/* 347:    */     }
/* 348:312 */     int __result = nclEnqueueCopyBufferRect(command_queue.getPointer(), src_buffer.getPointer(), dst_buffer.getPointer(), MemoryUtil.getAddress(src_origin), MemoryUtil.getAddress(dst_origin), MemoryUtil.getAddress(region), src_row_pitch, src_slice_pitch, dst_row_pitch, dst_slice_pitch, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 349:313 */     if (__result == 0) {
/* 350:313 */       command_queue.registerCLEvent(event);
/* 351:    */     }
/* 352:314 */     return __result;
/* 353:    */   }
/* 354:    */   
/* 355:    */   static native int nclEnqueueCopyBufferRect(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10, int paramInt, long paramLong11, long paramLong12, long paramLong13);
/* 356:    */   
/* 357:    */   public static CLEvent clCreateUserEvent(CLContext context, IntBuffer errcode_ret)
/* 358:    */   {
/* 359:319 */     long function_pointer = CLCapabilities.clCreateUserEvent;
/* 360:320 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 361:321 */     if (errcode_ret != null) {
/* 362:322 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 363:    */     }
/* 364:323 */     CLEvent __result = new CLEvent(nclCreateUserEvent(context.getPointer(), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 365:324 */     return __result;
/* 366:    */   }
/* 367:    */   
/* 368:    */   static native long nclCreateUserEvent(long paramLong1, long paramLong2, long paramLong3);
/* 369:    */   
/* 370:    */   public static int clSetUserEventStatus(CLEvent event, int execution_status)
/* 371:    */   {
/* 372:329 */     long function_pointer = CLCapabilities.clSetUserEventStatus;
/* 373:330 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 374:331 */     int __result = nclSetUserEventStatus(event.getPointer(), execution_status, function_pointer);
/* 375:332 */     return __result;
/* 376:    */   }
/* 377:    */   
/* 378:    */   static native int nclSetUserEventStatus(long paramLong1, int paramInt, long paramLong2);
/* 379:    */   
/* 380:    */   public static int clSetEventCallback(CLEvent event, int command_exec_callback_type, CLEventCallback pfn_notify)
/* 381:    */   {
/* 382:337 */     long function_pointer = CLCapabilities.clSetEventCallback;
/* 383:338 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 384:339 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 385:340 */     pfn_notify.setRegistry(event.getParentRegistry());
/* 386:341 */     int __result = 0;
/* 387:    */     try
/* 388:    */     {
/* 389:343 */       __result = nclSetEventCallback(event.getPointer(), command_exec_callback_type, pfn_notify.getPointer(), user_data, function_pointer);
/* 390:344 */       return __result;
/* 391:    */     }
/* 392:    */     finally
/* 393:    */     {
/* 394:346 */       CallbackUtil.checkCallback(__result, user_data);
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   static native int nclSetEventCallback(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/* 399:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL11
 * JD-Core Version:    0.7.0.1
 */