/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class AMDSparseTexture
/*  6:   */ {
/*  7:   */   public static final int GL_TEXTURE_STORAGE_SPARSE_BIT_AMD = 1;
/*  8:   */   public static final int GL_VIRTUAL_PAGE_SIZE_X_AMD = 37269;
/*  9:   */   public static final int GL_VIRTUAL_PAGE_SIZE_Y_AMD = 37270;
/* 10:   */   public static final int GL_VIRTUAL_PAGE_SIZE_Z_AMD = 37271;
/* 11:   */   public static final int GL_MAX_SPARSE_TEXTURE_SIZE_AMD = 37272;
/* 12:   */   public static final int GL_MAX_SPARSE_3D_TEXTURE_SIZE_AMD = 37273;
/* 13:   */   public static final int GL_MAX_SPARSE_ARRAY_TEXTURE_LAYERS = 37274;
/* 14:   */   public static final int GL_MIN_SPARSE_LEVEL_AMD = 37275;
/* 15:   */   public static final int GL_MIN_LOD_WARNING_AMD = 37276;
/* 16:   */   
/* 17:   */   public static void glTexStorageSparseAMD(int target, int internalFormat, int width, int height, int depth, int layers, int flags)
/* 18:   */   {
/* 19:44 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:45 */     long function_pointer = caps.glTexStorageSparseAMD;
/* 21:46 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:47 */     nglTexStorageSparseAMD(target, internalFormat, width, height, depth, layers, flags, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglTexStorageSparseAMD(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/* 26:   */   
/* 27:   */   public static void glTextureStorageSparseAMD(int texture, int target, int internalFormat, int width, int height, int depth, int layers, int flags)
/* 28:   */   {
/* 29:52 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:53 */     long function_pointer = caps.glTextureStorageSparseAMD;
/* 31:54 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:55 */     nglTextureStorageSparseAMD(texture, target, internalFormat, width, height, depth, layers, flags, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglTextureStorageSparseAMD(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/* 36:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDSparseTexture
 * JD-Core Version:    0.7.0.1
 */