/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class EXTSeparateShaderObjects
/*  8:   */ {
/*  9:   */   public static final int GL_ACTIVE_PROGRAM_EXT = 35725;
/* 10:   */   
/* 11:   */   public static void glUseShaderProgramEXT(int type, int program)
/* 12:   */   {
/* 13:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:19 */     long function_pointer = caps.glUseShaderProgramEXT;
/* 15:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:21 */     nglUseShaderProgramEXT(type, program, function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nglUseShaderProgramEXT(int paramInt1, int paramInt2, long paramLong);
/* 20:   */   
/* 21:   */   public static void glActiveProgramEXT(int program)
/* 22:   */   {
/* 23:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 24:27 */     long function_pointer = caps.glActiveProgramEXT;
/* 25:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 26:29 */     nglActiveProgramEXT(program, function_pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   static native void nglActiveProgramEXT(int paramInt, long paramLong);
/* 30:   */   
/* 31:   */   public static int glCreateShaderProgramEXT(int type, ByteBuffer string)
/* 32:   */   {
/* 33:34 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 34:35 */     long function_pointer = caps.glCreateShaderProgramEXT;
/* 35:36 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:37 */     BufferChecks.checkDirect(string);
/* 37:38 */     BufferChecks.checkNullTerminated(string);
/* 38:39 */     int __result = nglCreateShaderProgramEXT(type, MemoryUtil.getAddress(string), function_pointer);
/* 39:40 */     return __result;
/* 40:   */   }
/* 41:   */   
/* 42:   */   static native int nglCreateShaderProgramEXT(int paramInt, long paramLong1, long paramLong2);
/* 43:   */   
/* 44:   */   public static int glCreateShaderProgramEXT(int type, CharSequence string)
/* 45:   */   {
/* 46:46 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 47:47 */     long function_pointer = caps.glCreateShaderProgramEXT;
/* 48:48 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 49:49 */     int __result = nglCreateShaderProgramEXT(type, APIUtil.getBufferNT(caps, string), function_pointer);
/* 50:50 */     return __result;
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTSeparateShaderObjects
 * JD-Core Version:    0.7.0.1
 */