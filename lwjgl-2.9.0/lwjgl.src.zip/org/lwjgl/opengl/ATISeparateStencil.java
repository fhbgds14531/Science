/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ATISeparateStencil
/*  6:   */ {
/*  7:   */   public static final int GL_STENCIL_BACK_FUNC_ATI = 34816;
/*  8:   */   public static final int GL_STENCIL_BACK_FAIL_ATI = 34817;
/*  9:   */   public static final int GL_STENCIL_BACK_PASS_DEPTH_FAIL_ATI = 34818;
/* 10:   */   public static final int GL_STENCIL_BACK_PASS_DEPTH_PASS_ATI = 34819;
/* 11:   */   
/* 12:   */   public static void glStencilOpSeparateATI(int face, int sfail, int dpfail, int dppass)
/* 13:   */   {
/* 14:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:19 */     long function_pointer = caps.glStencilOpSeparateATI;
/* 16:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:21 */     nglStencilOpSeparateATI(face, sfail, dpfail, dppass, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglStencilOpSeparateATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 21:   */   
/* 22:   */   public static void glStencilFuncSeparateATI(int frontfunc, int backfunc, int ref, int mask)
/* 23:   */   {
/* 24:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:27 */     long function_pointer = caps.glStencilFuncSeparateATI;
/* 26:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:29 */     nglStencilFuncSeparateATI(frontfunc, backfunc, ref, mask, function_pointer);
/* 28:   */   }
/* 29:   */   
/* 30:   */   static native void nglStencilFuncSeparateATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 31:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATISeparateStencil
 * JD-Core Version:    0.7.0.1
 */