package org.lwjgl.opencl;

public final class AMDOfflineDevices
{
  public static final int CL_CONTEXT_OFFLINE_DEVICES_AMD = 16447;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.AMDOfflineDevices
 * JD-Core Version:    0.7.0.1
 */