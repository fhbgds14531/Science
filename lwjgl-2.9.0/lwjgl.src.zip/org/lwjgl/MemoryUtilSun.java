/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.lang.reflect.Modifier;
/*   6:    */ import java.nio.Buffer;
/*   7:    */ import sun.misc.Unsafe;
/*   8:    */ import sun.reflect.FieldAccessor;
/*   9:    */ 
/*  10:    */ final class MemoryUtilSun
/*  11:    */ {
/*  12:    */   private static class AccessorUnsafe
/*  13:    */     implements MemoryUtil.Accessor
/*  14:    */   {
/*  15:    */     private final Unsafe unsafe;
/*  16:    */     private final long address;
/*  17:    */     
/*  18:    */     AccessorUnsafe()
/*  19:    */     {
/*  20:    */       try
/*  21:    */       {
/*  22: 62 */         this.unsafe = getUnsafeInstance();
/*  23: 63 */         this.address = this.unsafe.objectFieldOffset(MemoryUtil.getAddressField());
/*  24:    */       }
/*  25:    */       catch (Exception e)
/*  26:    */       {
/*  27: 65 */         throw new UnsupportedOperationException(e);
/*  28:    */       }
/*  29:    */     }
/*  30:    */     
/*  31:    */     public long getAddress(Buffer buffer)
/*  32:    */     {
/*  33: 70 */       return this.unsafe.getLong(buffer, this.address);
/*  34:    */     }
/*  35:    */     
/*  36:    */     private static Unsafe getUnsafeInstance()
/*  37:    */     {
/*  38: 74 */       Field[] fields = Unsafe.class.getDeclaredFields();
/*  39: 84 */       for (Field field : fields) {
/*  40: 85 */         if (field.getType().equals(Unsafe.class))
/*  41:    */         {
/*  42: 88 */           int modifiers = field.getModifiers();
/*  43: 89 */           if ((Modifier.isStatic(modifiers)) && (Modifier.isFinal(modifiers)))
/*  44:    */           {
/*  45: 92 */             field.setAccessible(true);
/*  46:    */             try
/*  47:    */             {
/*  48: 94 */               return (Unsafe)field.get(null);
/*  49:    */             }
/*  50:    */             catch (IllegalAccessException e) {}
/*  51:    */           }
/*  52:    */         }
/*  53:    */       }
/*  54:101 */       throw new UnsupportedOperationException();
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static class AccessorReflectFast
/*  59:    */     implements MemoryUtil.Accessor
/*  60:    */   {
/*  61:    */     private final FieldAccessor addressAccessor;
/*  62:    */     
/*  63:    */     AccessorReflectFast()
/*  64:    */     {
/*  65:    */       Field address;
/*  66:    */       try
/*  67:    */       {
/*  68:114 */         address = MemoryUtil.getAddressField();
/*  69:    */       }
/*  70:    */       catch (NoSuchFieldException e)
/*  71:    */       {
/*  72:116 */         throw new UnsupportedOperationException(e);
/*  73:    */       }
/*  74:118 */       address.setAccessible(true);
/*  75:    */       try
/*  76:    */       {
/*  77:121 */         Method m = Field.class.getDeclaredMethod("acquireFieldAccessor", new Class[] { Boolean.TYPE });
/*  78:122 */         m.setAccessible(true);
/*  79:123 */         this.addressAccessor = ((FieldAccessor)m.invoke(address, new Object[] { Boolean.valueOf(true) }));
/*  80:    */       }
/*  81:    */       catch (Exception e)
/*  82:    */       {
/*  83:125 */         throw new UnsupportedOperationException(e);
/*  84:    */       }
/*  85:    */     }
/*  86:    */     
/*  87:    */     public long getAddress(Buffer buffer)
/*  88:    */     {
/*  89:130 */       return this.addressAccessor.getLong(buffer);
/*  90:    */     }
/*  91:    */   }
/*  92:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.MemoryUtilSun
 * JD-Core Version:    0.7.0.1
 */