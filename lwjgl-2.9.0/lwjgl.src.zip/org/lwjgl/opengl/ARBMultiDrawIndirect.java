/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ 
/*  6:   */ public final class ARBMultiDrawIndirect
/*  7:   */ {
/*  8:   */   public static void glMultiDrawArraysIndirect(int mode, ByteBuffer indirect, int primcount, int stride)
/*  9:   */   {
/* 10:13 */     GL43.glMultiDrawArraysIndirect(mode, indirect, primcount, stride);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static void glMultiDrawArraysIndirect(int mode, long indirect_buffer_offset, int primcount, int stride)
/* 14:   */   {
/* 15:16 */     GL43.glMultiDrawArraysIndirect(mode, indirect_buffer_offset, primcount, stride);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static void glMultiDrawArraysIndirect(int mode, IntBuffer indirect, int primcount, int stride)
/* 19:   */   {
/* 20:21 */     GL43.glMultiDrawArraysIndirect(mode, indirect, primcount, stride);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static void glMultiDrawElementsIndirect(int mode, int type, ByteBuffer indirect, int primcount, int stride)
/* 24:   */   {
/* 25:25 */     GL43.glMultiDrawElementsIndirect(mode, type, indirect, primcount, stride);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static void glMultiDrawElementsIndirect(int mode, int type, long indirect_buffer_offset, int primcount, int stride)
/* 29:   */   {
/* 30:28 */     GL43.glMultiDrawElementsIndirect(mode, type, indirect_buffer_offset, primcount, stride);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static void glMultiDrawElementsIndirect(int mode, int type, IntBuffer indirect, int primcount, int stride)
/* 34:   */   {
/* 35:33 */     GL43.glMultiDrawElementsIndirect(mode, type, indirect, primcount, stride);
/* 36:   */   }
/* 37:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBMultiDrawIndirect
 * JD-Core Version:    0.7.0.1
 */