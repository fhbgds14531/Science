package org.lwjgl.opengl;

public final class KHRTextureCompressionAstcLdr
{
  public static final int GL_COMPRESSED_RGBA_ASTC_4x4_KHR = 37808;
  public static final int GL_COMPRESSED_RGBA_ASTC_5x4_KHR = 37809;
  public static final int GL_COMPRESSED_RGBA_ASTC_5x5_KHR = 37810;
  public static final int GL_COMPRESSED_RGBA_ASTC_6x5_KHR = 37811;
  public static final int GL_COMPRESSED_RGBA_ASTC_6x6_KHR = 37812;
  public static final int GL_COMPRESSED_RGBA_ASTC_8x5_KHR = 37813;
  public static final int GL_COMPRESSED_RGBA_ASTC_8x6_KHR = 37814;
  public static final int GL_COMPRESSED_RGBA_ASTC_8x8_KHR = 37815;
  public static final int GL_COMPRESSED_RGBA_ASTC_10x5_KHR = 37816;
  public static final int GL_COMPRESSED_RGBA_ASTC_10x6_KHR = 37817;
  public static final int GL_COMPRESSED_RGBA_ASTC_10x8_KHR = 37818;
  public static final int GL_COMPRESSED_RGBA_ASTC_10x10_KHR = 37819;
  public static final int GL_COMPRESSED_RGBA_ASTC_12x10_KHR = 37820;
  public static final int GL_COMPRESSED_RGBA_ASTC_12x12_KHR = 37821;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR = 37840;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR = 37841;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR = 37842;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR = 37843;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR = 37844;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR = 37845;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR = 37846;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR = 37847;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR = 37848;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR = 37849;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR = 37850;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR = 37851;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR = 37852;
  public static final int GL_COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR = 37853;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.KHRTextureCompressionAstcLdr
 * JD-Core Version:    0.7.0.1
 */