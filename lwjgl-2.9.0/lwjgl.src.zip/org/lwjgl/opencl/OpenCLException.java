/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ public class OpenCLException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public OpenCLException() {}
/*  9:   */   
/* 10:   */   public OpenCLException(String message)
/* 11:   */   {
/* 12:43 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public OpenCLException(String message, Throwable cause)
/* 16:   */   {
/* 17:47 */     super(message, cause);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public OpenCLException(Throwable cause)
/* 21:   */   {
/* 22:51 */     super(cause);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.OpenCLException
 * JD-Core Version:    0.7.0.1
 */