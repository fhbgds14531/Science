/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferUtils;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ import org.lwjgl.LWJGLUtil;
/*   8:    */ 
/*   9:    */ final class WindowsMouse
/*  10:    */ {
/*  11:    */   private final long hwnd;
/*  12:    */   private final int mouse_button_count;
/*  13:    */   private final boolean has_wheel;
/*  14: 53 */   private final EventQueue event_queue = new EventQueue(22);
/*  15: 55 */   private final ByteBuffer mouse_event = ByteBuffer.allocate(22);
/*  16:    */   private final Object blank_cursor;
/*  17:    */   private boolean mouse_grabbed;
/*  18:    */   private byte[] button_states;
/*  19:    */   private int accum_dx;
/*  20:    */   private int accum_dy;
/*  21:    */   private int accum_dwheel;
/*  22:    */   private int last_x;
/*  23:    */   private int last_y;
/*  24:    */   
/*  25:    */   WindowsMouse(long hwnd)
/*  26:    */     throws LWJGLException
/*  27:    */   {
/*  28: 67 */     this.hwnd = hwnd;
/*  29: 68 */     this.mouse_button_count = Math.min(5, WindowsDisplay.getSystemMetrics(43));
/*  30: 69 */     this.has_wheel = (WindowsDisplay.getSystemMetrics(75) != 0);
/*  31: 70 */     this.blank_cursor = createBlankCursor();
/*  32: 71 */     this.button_states = new byte[this.mouse_button_count];
/*  33:    */   }
/*  34:    */   
/*  35:    */   private Object createBlankCursor()
/*  36:    */     throws LWJGLException
/*  37:    */   {
/*  38: 75 */     int width = WindowsDisplay.getSystemMetrics(13);
/*  39: 76 */     int height = WindowsDisplay.getSystemMetrics(14);
/*  40: 77 */     IntBuffer pixels = BufferUtils.createIntBuffer(width * height);
/*  41: 78 */     return WindowsDisplay.doCreateCursor(width, height, 0, 0, 1, pixels, null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean isGrabbed()
/*  45:    */   {
/*  46: 82 */     return this.mouse_grabbed;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean hasWheel()
/*  50:    */   {
/*  51: 86 */     return this.has_wheel;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public int getButtonCount()
/*  55:    */   {
/*  56: 90 */     return this.mouse_button_count;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void poll(IntBuffer coord_buffer, ByteBuffer buttons)
/*  60:    */   {
/*  61: 94 */     for (int i = 0; i < coord_buffer.remaining(); i++) {
/*  62: 95 */       coord_buffer.put(coord_buffer.position() + i, 0);
/*  63:    */     }
/*  64: 96 */     int num_buttons = this.mouse_button_count;
/*  65: 97 */     coord_buffer.put(coord_buffer.position() + 2, this.accum_dwheel);
/*  66: 98 */     if (num_buttons > this.button_states.length) {
/*  67: 99 */       num_buttons = this.button_states.length;
/*  68:    */     }
/*  69:100 */     for (int j = 0; j < num_buttons; j++) {
/*  70:101 */       buttons.put(buttons.position() + j, this.button_states[j]);
/*  71:    */     }
/*  72:103 */     if (isGrabbed())
/*  73:    */     {
/*  74:104 */       coord_buffer.put(coord_buffer.position() + 0, this.accum_dx);
/*  75:105 */       coord_buffer.put(coord_buffer.position() + 1, this.accum_dy);
/*  76:    */     }
/*  77:    */     else
/*  78:    */     {
/*  79:107 */       coord_buffer.put(coord_buffer.position() + 0, this.last_x);
/*  80:108 */       coord_buffer.put(coord_buffer.position() + 1, this.last_y);
/*  81:    */     }
/*  82:110 */     this.accum_dx = (this.accum_dy = this.accum_dwheel = 0);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private void putMouseEventWithCoords(byte button, byte state, int coord1, int coord2, int dz, long nanos)
/*  86:    */   {
/*  87:114 */     this.mouse_event.clear();
/*  88:115 */     this.mouse_event.put(button).put(state).putInt(coord1).putInt(coord2).putInt(dz).putLong(nanos);
/*  89:116 */     this.mouse_event.flip();
/*  90:117 */     this.event_queue.putEvent(this.mouse_event);
/*  91:    */   }
/*  92:    */   
/*  93:    */   private void putMouseEvent(byte button, byte state, int dz, long nanos)
/*  94:    */   {
/*  95:121 */     if (this.mouse_grabbed) {
/*  96:122 */       putMouseEventWithCoords(button, state, 0, 0, dz, nanos);
/*  97:    */     } else {
/*  98:124 */       putMouseEventWithCoords(button, state, this.last_x, this.last_y, dz, nanos);
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void read(ByteBuffer buffer)
/* 103:    */   {
/* 104:128 */     this.event_queue.copyEvents(buffer);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public Object getBlankCursor()
/* 108:    */   {
/* 109:132 */     return this.blank_cursor;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void grab(boolean grab, boolean should_center)
/* 113:    */   {
/* 114:136 */     if (grab)
/* 115:    */     {
/* 116:137 */       if (!this.mouse_grabbed)
/* 117:    */       {
/* 118:138 */         this.mouse_grabbed = true;
/* 119:139 */         if (should_center)
/* 120:    */         {
/* 121:    */           try
/* 122:    */           {
/* 123:141 */             WindowsDisplay.setupCursorClipping(this.hwnd);
/* 124:    */           }
/* 125:    */           catch (LWJGLException e)
/* 126:    */           {
/* 127:143 */             LWJGLUtil.log("Failed to setup cursor clipping: " + e);
/* 128:    */           }
/* 129:145 */           centerCursor();
/* 130:    */         }
/* 131:    */       }
/* 132:    */     }
/* 133:149 */     else if (this.mouse_grabbed)
/* 134:    */     {
/* 135:150 */       this.mouse_grabbed = false;
/* 136:151 */       WindowsDisplay.resetCursorClipping();
/* 137:    */     }
/* 138:154 */     this.event_queue.clearEvents();
/* 139:    */   }
/* 140:    */   
/* 141:    */   public void handleMouseScrolled(int event_dwheel, long millis)
/* 142:    */   {
/* 143:158 */     this.accum_dwheel += event_dwheel;
/* 144:159 */     putMouseEvent((byte)-1, (byte)0, event_dwheel, millis * 1000000L);
/* 145:    */   }
/* 146:    */   
/* 147:    */   private void centerCursor()
/* 148:    */   {
/* 149:163 */     WindowsDisplay.centerCursor(this.hwnd);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setPosition(int x, int y)
/* 153:    */   {
/* 154:167 */     this.last_x = x;
/* 155:168 */     this.last_y = y;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void destroy()
/* 159:    */   {
/* 160:172 */     WindowsDisplay.doDestroyCursor(this.blank_cursor);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void handleMouseMoved(int x, int y, long millis, boolean should_center)
/* 164:    */   {
/* 165:176 */     int dx = x - this.last_x;
/* 166:177 */     int dy = y - this.last_y;
/* 167:178 */     if ((dx != 0) || (dy != 0))
/* 168:    */     {
/* 169:179 */       this.accum_dx += dx;
/* 170:180 */       this.accum_dy += dy;
/* 171:181 */       this.last_x = x;
/* 172:182 */       this.last_y = y;
/* 173:183 */       long nanos = millis * 1000000L;
/* 174:184 */       if (this.mouse_grabbed)
/* 175:    */       {
/* 176:185 */         putMouseEventWithCoords((byte)-1, (byte)0, dx, dy, 0, nanos);
/* 177:186 */         if (should_center) {
/* 178:187 */           centerCursor();
/* 179:    */         }
/* 180:    */       }
/* 181:    */       else
/* 182:    */       {
/* 183:189 */         putMouseEventWithCoords((byte)-1, (byte)0, x, y, 0, nanos);
/* 184:    */       }
/* 185:    */     }
/* 186:    */   }
/* 187:    */   
/* 188:    */   public void handleMouseButton(byte button, byte state, long millis)
/* 189:    */   {
/* 190:195 */     putMouseEvent(button, state, 0, millis * 1000000L);
/* 191:196 */     if (button < this.button_states.length) {
/* 192:197 */       this.button_states[button] = (state != 0 ? 1 : 0);
/* 193:    */     }
/* 194:    */   }
/* 195:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsMouse
 * JD-Core Version:    0.7.0.1
 */