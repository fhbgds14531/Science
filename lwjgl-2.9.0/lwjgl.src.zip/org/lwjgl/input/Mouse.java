/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.security.AccessController;
/*   6:    */ import java.security.PrivilegedAction;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.Map;
/*   9:    */ import org.lwjgl.BufferUtils;
/*  10:    */ import org.lwjgl.LWJGLException;
/*  11:    */ import org.lwjgl.LWJGLUtil;
/*  12:    */ import org.lwjgl.Sys;
/*  13:    */ import org.lwjgl.opengl.Display;
/*  14:    */ import org.lwjgl.opengl.InputImplementation;
/*  15:    */ 
/*  16:    */ public class Mouse
/*  17:    */ {
/*  18:    */   public static final int EVENT_SIZE = 22;
/*  19:    */   private static boolean created;
/*  20:    */   private static ByteBuffer buttons;
/*  21:    */   private static int x;
/*  22:    */   private static int y;
/*  23:    */   private static int absolute_x;
/*  24:    */   private static int absolute_y;
/*  25:    */   private static IntBuffer coord_buffer;
/*  26:    */   private static int dx;
/*  27:    */   private static int dy;
/*  28:    */   private static int dwheel;
/*  29:100 */   private static int buttonCount = -1;
/*  30:    */   private static boolean hasWheel;
/*  31:    */   private static Cursor currentCursor;
/*  32:    */   private static String[] buttonName;
/*  33:112 */   private static final Map<String, Integer> buttonMap = new HashMap(16);
/*  34:    */   private static boolean initialized;
/*  35:    */   private static ByteBuffer readBuffer;
/*  36:    */   private static int eventButton;
/*  37:    */   private static boolean eventState;
/*  38:    */   private static int event_dx;
/*  39:    */   private static int event_dy;
/*  40:    */   private static int event_dwheel;
/*  41:    */   private static int event_x;
/*  42:    */   private static int event_y;
/*  43:    */   private static long event_nanos;
/*  44:    */   private static int grab_x;
/*  45:    */   private static int grab_y;
/*  46:    */   private static int last_event_raw_x;
/*  47:    */   private static int last_event_raw_y;
/*  48:    */   private static final int BUFFER_SIZE = 50;
/*  49:    */   private static boolean isGrabbed;
/*  50:    */   private static InputImplementation implementation;
/*  51:149 */   private static final boolean emulateCursorAnimation = (LWJGLUtil.getPlatform() == 3) || (LWJGLUtil.getPlatform() == 2);
/*  52:152 */   private static boolean clipMouseCoordinatesToWindow = !getPrivilegedBoolean("org.lwjgl.input.Mouse.allowNegativeMouseCoords");
/*  53:    */   
/*  54:    */   public static Cursor getNativeCursor()
/*  55:    */   {
/*  56:166 */     synchronized (OpenGLPackageAccess.global_lock)
/*  57:    */     {
/*  58:167 */       return currentCursor;
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static Cursor setNativeCursor(Cursor cursor)
/*  63:    */     throws LWJGLException
/*  64:    */   {
/*  65:184 */     synchronized (OpenGLPackageAccess.global_lock)
/*  66:    */     {
/*  67:185 */       if ((Cursor.getCapabilities() & 0x1) == 0) {
/*  68:186 */         throw new IllegalStateException("Mouse doesn't support native cursors");
/*  69:    */       }
/*  70:187 */       Cursor oldCursor = currentCursor;
/*  71:188 */       currentCursor = cursor;
/*  72:189 */       if (isCreated()) {
/*  73:190 */         if (currentCursor != null)
/*  74:    */         {
/*  75:191 */           implementation.setNativeCursor(currentCursor.getHandle());
/*  76:192 */           currentCursor.setTimeout();
/*  77:    */         }
/*  78:    */         else
/*  79:    */         {
/*  80:194 */           implementation.setNativeCursor(null);
/*  81:    */         }
/*  82:    */       }
/*  83:197 */       return oldCursor;
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static boolean isClipMouseCoordinatesToWindow()
/*  88:    */   {
/*  89:202 */     return clipMouseCoordinatesToWindow;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static void setClipMouseCoordinatesToWindow(boolean clip)
/*  93:    */   {
/*  94:206 */     clipMouseCoordinatesToWindow = clip;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void setCursorPosition(int new_x, int new_y)
/*  98:    */   {
/*  99:219 */     synchronized (OpenGLPackageAccess.global_lock)
/* 100:    */     {
/* 101:220 */       if (!isCreated()) {
/* 102:221 */         throw new IllegalStateException("Mouse is not created");
/* 103:    */       }
/* 104:222 */       x = Mouse.event_x = new_x;
/* 105:223 */       y = Mouse.event_y = new_y;
/* 106:224 */       if ((!isGrabbed()) && ((Cursor.getCapabilities() & 0x1) != 0))
/* 107:    */       {
/* 108:225 */         implementation.setCursorPosition(x, y);
/* 109:    */       }
/* 110:    */       else
/* 111:    */       {
/* 112:228 */         grab_x = new_x;
/* 113:229 */         grab_y = new_y;
/* 114:    */       }
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static void initialize()
/* 119:    */   {
/* 120:238 */     Sys.initialize();
/* 121:    */     
/* 122:    */ 
/* 123:241 */     buttonName = new String[16];
/* 124:242 */     for (int i = 0; i < 16; i++)
/* 125:    */     {
/* 126:243 */       buttonName[i] = ("BUTTON" + i);
/* 127:244 */       buttonMap.put(buttonName[i], Integer.valueOf(i));
/* 128:    */     }
/* 129:247 */     initialized = true;
/* 130:    */   }
/* 131:    */   
/* 132:    */   private static void resetMouse()
/* 133:    */   {
/* 134:251 */     dx = Mouse.dy = Mouse.dwheel = 0;
/* 135:252 */     readBuffer.position(readBuffer.limit());
/* 136:    */   }
/* 137:    */   
/* 138:    */   static InputImplementation getImplementation()
/* 139:    */   {
/* 140:256 */     return implementation;
/* 141:    */   }
/* 142:    */   
/* 143:    */   private static void create(InputImplementation impl)
/* 144:    */     throws LWJGLException
/* 145:    */   {
/* 146:266 */     if (created) {
/* 147:267 */       return;
/* 148:    */     }
/* 149:268 */     if (!initialized) {
/* 150:269 */       initialize();
/* 151:    */     }
/* 152:270 */     implementation = impl;
/* 153:271 */     implementation.createMouse();
/* 154:272 */     hasWheel = implementation.hasWheel();
/* 155:273 */     created = true;
/* 156:    */     
/* 157:    */ 
/* 158:276 */     buttonCount = implementation.getButtonCount();
/* 159:277 */     buttons = BufferUtils.createByteBuffer(buttonCount);
/* 160:278 */     coord_buffer = BufferUtils.createIntBuffer(3);
/* 161:279 */     if ((currentCursor != null) && (implementation.getNativeCursorCapabilities() != 0)) {
/* 162:280 */       setNativeCursor(currentCursor);
/* 163:    */     }
/* 164:281 */     readBuffer = ByteBuffer.allocate(1100);
/* 165:282 */     readBuffer.limit(0);
/* 166:283 */     setGrabbed(isGrabbed);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static void create()
/* 170:    */     throws LWJGLException
/* 171:    */   {
/* 172:294 */     synchronized (OpenGLPackageAccess.global_lock)
/* 173:    */     {
/* 174:295 */       if (!Display.isCreated()) {
/* 175:295 */         throw new IllegalStateException("Display must be created.");
/* 176:    */       }
/* 177:297 */       create(OpenGLPackageAccess.createImplementation());
/* 178:    */     }
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static boolean isCreated()
/* 182:    */   {
/* 183:305 */     synchronized (OpenGLPackageAccess.global_lock)
/* 184:    */     {
/* 185:306 */       return created;
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   public static void destroy()
/* 190:    */   {
/* 191:314 */     synchronized (OpenGLPackageAccess.global_lock)
/* 192:    */     {
/* 193:315 */       if (!created) {
/* 194:315 */         return;
/* 195:    */       }
/* 196:316 */       created = false;
/* 197:317 */       buttons = null;
/* 198:318 */       coord_buffer = null;
/* 199:    */       
/* 200:320 */       implementation.destroyMouse();
/* 201:    */     }
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static void poll()
/* 205:    */   {
/* 206:349 */     synchronized (OpenGLPackageAccess.global_lock)
/* 207:    */     {
/* 208:350 */       if (!created) {
/* 209:350 */         throw new IllegalStateException("Mouse must be created before you can poll it");
/* 210:    */       }
/* 211:351 */       implementation.pollMouse(coord_buffer, buttons);
/* 212:    */       
/* 213:    */ 
/* 214:354 */       int poll_coord1 = coord_buffer.get(0);
/* 215:355 */       int poll_coord2 = coord_buffer.get(1);
/* 216:    */       
/* 217:357 */       int poll_dwheel = coord_buffer.get(2);
/* 218:359 */       if (isGrabbed())
/* 219:    */       {
/* 220:360 */         dx += poll_coord1;
/* 221:361 */         dy += poll_coord2;
/* 222:362 */         x += poll_coord1;
/* 223:363 */         y += poll_coord2;
/* 224:364 */         absolute_x += poll_coord1;
/* 225:365 */         absolute_y += poll_coord2;
/* 226:    */       }
/* 227:    */       else
/* 228:    */       {
/* 229:367 */         dx = poll_coord1 - absolute_x;
/* 230:368 */         dy = poll_coord2 - absolute_y;
/* 231:369 */         absolute_x = Mouse.x = poll_coord1;
/* 232:370 */         absolute_y = Mouse.y = poll_coord2;
/* 233:    */       }
/* 234:373 */       if (clipMouseCoordinatesToWindow)
/* 235:    */       {
/* 236:374 */         x = Math.min(Display.getWidth() - 1, Math.max(0, x));
/* 237:375 */         y = Math.min(Display.getHeight() - 1, Math.max(0, y));
/* 238:    */       }
/* 239:378 */       dwheel += poll_dwheel;
/* 240:379 */       read();
/* 241:    */     }
/* 242:    */   }
/* 243:    */   
/* 244:    */   private static void read()
/* 245:    */   {
/* 246:384 */     readBuffer.compact();
/* 247:385 */     implementation.readMouse(readBuffer);
/* 248:386 */     readBuffer.flip();
/* 249:    */   }
/* 250:    */   
/* 251:    */   public static boolean isButtonDown(int button)
/* 252:    */   {
/* 253:396 */     synchronized (OpenGLPackageAccess.global_lock)
/* 254:    */     {
/* 255:397 */       if (!created) {
/* 256:397 */         throw new IllegalStateException("Mouse must be created before you can poll the button state");
/* 257:    */       }
/* 258:398 */       if ((button >= buttonCount) || (button < 0)) {
/* 259:399 */         return false;
/* 260:    */       }
/* 261:401 */       return buttons.get(button) == 1;
/* 262:    */     }
/* 263:    */   }
/* 264:    */   
/* 265:    */   public static String getButtonName(int button)
/* 266:    */   {
/* 267:411 */     synchronized (OpenGLPackageAccess.global_lock)
/* 268:    */     {
/* 269:412 */       if ((button >= buttonName.length) || (button < 0)) {
/* 270:413 */         return null;
/* 271:    */       }
/* 272:415 */       return buttonName[button];
/* 273:    */     }
/* 274:    */   }
/* 275:    */   
/* 276:    */   public static int getButtonIndex(String buttonName)
/* 277:    */   {
/* 278:424 */     synchronized (OpenGLPackageAccess.global_lock)
/* 279:    */     {
/* 280:425 */       Integer ret = (Integer)buttonMap.get(buttonName);
/* 281:426 */       if (ret == null) {
/* 282:427 */         return -1;
/* 283:    */       }
/* 284:429 */       return ret.intValue();
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:    */   public static boolean next()
/* 289:    */   {
/* 290:443 */     synchronized (OpenGLPackageAccess.global_lock)
/* 291:    */     {
/* 292:444 */       if (!created) {
/* 293:444 */         throw new IllegalStateException("Mouse must be created before you can read events");
/* 294:    */       }
/* 295:445 */       if (readBuffer.hasRemaining())
/* 296:    */       {
/* 297:446 */         eventButton = readBuffer.get();
/* 298:447 */         eventState = readBuffer.get() != 0;
/* 299:448 */         if (isGrabbed())
/* 300:    */         {
/* 301:449 */           event_dx = readBuffer.getInt();
/* 302:450 */           event_dy = readBuffer.getInt();
/* 303:451 */           event_x += event_dx;
/* 304:452 */           event_y += event_dy;
/* 305:453 */           last_event_raw_x = event_x;
/* 306:454 */           last_event_raw_y = event_y;
/* 307:    */         }
/* 308:    */         else
/* 309:    */         {
/* 310:456 */           int new_event_x = readBuffer.getInt();
/* 311:457 */           int new_event_y = readBuffer.getInt();
/* 312:458 */           event_dx = new_event_x - last_event_raw_x;
/* 313:459 */           event_dy = new_event_y - last_event_raw_y;
/* 314:460 */           event_x = new_event_x;
/* 315:461 */           event_y = new_event_y;
/* 316:462 */           last_event_raw_x = new_event_x;
/* 317:463 */           last_event_raw_y = new_event_y;
/* 318:    */         }
/* 319:465 */         if (clipMouseCoordinatesToWindow)
/* 320:    */         {
/* 321:466 */           event_x = Math.min(Display.getWidth() - 1, Math.max(0, event_x));
/* 322:467 */           event_y = Math.min(Display.getHeight() - 1, Math.max(0, event_y));
/* 323:    */         }
/* 324:469 */         event_dwheel = readBuffer.getInt();
/* 325:470 */         event_nanos = readBuffer.getLong();
/* 326:471 */         return true;
/* 327:    */       }
/* 328:473 */       return false;
/* 329:    */     }
/* 330:    */   }
/* 331:    */   
/* 332:    */   public static int getEventButton()
/* 333:    */   {
/* 334:481 */     synchronized (OpenGLPackageAccess.global_lock)
/* 335:    */     {
/* 336:482 */       return eventButton;
/* 337:    */     }
/* 338:    */   }
/* 339:    */   
/* 340:    */   public static boolean getEventButtonState()
/* 341:    */   {
/* 342:491 */     synchronized (OpenGLPackageAccess.global_lock)
/* 343:    */     {
/* 344:492 */       return eventState;
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static int getEventDX()
/* 349:    */   {
/* 350:500 */     synchronized (OpenGLPackageAccess.global_lock)
/* 351:    */     {
/* 352:501 */       return event_dx;
/* 353:    */     }
/* 354:    */   }
/* 355:    */   
/* 356:    */   public static int getEventDY()
/* 357:    */   {
/* 358:509 */     synchronized (OpenGLPackageAccess.global_lock)
/* 359:    */     {
/* 360:510 */       return event_dy;
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   public static int getEventX()
/* 365:    */   {
/* 366:518 */     synchronized (OpenGLPackageAccess.global_lock)
/* 367:    */     {
/* 368:519 */       return event_x;
/* 369:    */     }
/* 370:    */   }
/* 371:    */   
/* 372:    */   public static int getEventY()
/* 373:    */   {
/* 374:527 */     synchronized (OpenGLPackageAccess.global_lock)
/* 375:    */     {
/* 376:528 */       return event_y;
/* 377:    */     }
/* 378:    */   }
/* 379:    */   
/* 380:    */   public static int getEventDWheel()
/* 381:    */   {
/* 382:536 */     synchronized (OpenGLPackageAccess.global_lock)
/* 383:    */     {
/* 384:537 */       return event_dwheel;
/* 385:    */     }
/* 386:    */   }
/* 387:    */   
/* 388:    */   public static long getEventNanoseconds()
/* 389:    */   {
/* 390:550 */     synchronized (OpenGLPackageAccess.global_lock)
/* 391:    */     {
/* 392:551 */       return event_nanos;
/* 393:    */     }
/* 394:    */   }
/* 395:    */   
/* 396:    */   public static int getX()
/* 397:    */   {
/* 398:562 */     synchronized (OpenGLPackageAccess.global_lock)
/* 399:    */     {
/* 400:563 */       return x;
/* 401:    */     }
/* 402:    */   }
/* 403:    */   
/* 404:    */   public static int getY()
/* 405:    */   {
/* 406:574 */     synchronized (OpenGLPackageAccess.global_lock)
/* 407:    */     {
/* 408:575 */       return y;
/* 409:    */     }
/* 410:    */   }
/* 411:    */   
/* 412:    */   public static int getDX()
/* 413:    */   {
/* 414:583 */     synchronized (OpenGLPackageAccess.global_lock)
/* 415:    */     {
/* 416:584 */       int result = dx;
/* 417:585 */       dx = 0;
/* 418:586 */       return result;
/* 419:    */     }
/* 420:    */   }
/* 421:    */   
/* 422:    */   public static int getDY()
/* 423:    */   {
/* 424:594 */     synchronized (OpenGLPackageAccess.global_lock)
/* 425:    */     {
/* 426:595 */       int result = dy;
/* 427:596 */       dy = 0;
/* 428:597 */       return result;
/* 429:    */     }
/* 430:    */   }
/* 431:    */   
/* 432:    */   public static int getDWheel()
/* 433:    */   {
/* 434:605 */     synchronized (OpenGLPackageAccess.global_lock)
/* 435:    */     {
/* 436:606 */       int result = dwheel;
/* 437:607 */       dwheel = 0;
/* 438:608 */       return result;
/* 439:    */     }
/* 440:    */   }
/* 441:    */   
/* 442:    */   public static int getButtonCount()
/* 443:    */   {
/* 444:616 */     synchronized (OpenGLPackageAccess.global_lock)
/* 445:    */     {
/* 446:617 */       return buttonCount;
/* 447:    */     }
/* 448:    */   }
/* 449:    */   
/* 450:    */   public static boolean hasWheel()
/* 451:    */   {
/* 452:625 */     synchronized (OpenGLPackageAccess.global_lock)
/* 453:    */     {
/* 454:626 */       return hasWheel;
/* 455:    */     }
/* 456:    */   }
/* 457:    */   
/* 458:    */   public static boolean isGrabbed()
/* 459:    */   {
/* 460:634 */     synchronized (OpenGLPackageAccess.global_lock)
/* 461:    */     {
/* 462:635 */       return isGrabbed;
/* 463:    */     }
/* 464:    */   }
/* 465:    */   
/* 466:    */   public static void setGrabbed(boolean grab)
/* 467:    */   {
/* 468:648 */     synchronized (OpenGLPackageAccess.global_lock)
/* 469:    */     {
/* 470:649 */       boolean grabbed = isGrabbed;
/* 471:650 */       isGrabbed = grab;
/* 472:651 */       if (isCreated())
/* 473:    */       {
/* 474:652 */         if ((grab) && (!grabbed))
/* 475:    */         {
/* 476:654 */           grab_x = x;
/* 477:655 */           grab_y = y;
/* 478:    */         }
/* 479:657 */         else if ((!grab) && (grabbed))
/* 480:    */         {
/* 481:659 */           if ((Cursor.getCapabilities() & 0x1) != 0) {
/* 482:660 */             implementation.setCursorPosition(grab_x, grab_y);
/* 483:    */           }
/* 484:    */         }
/* 485:663 */         implementation.grabMouse(grab);
/* 486:    */         
/* 487:665 */         poll();
/* 488:666 */         event_x = x;
/* 489:667 */         event_y = y;
/* 490:668 */         last_event_raw_x = x;
/* 491:669 */         last_event_raw_y = y;
/* 492:670 */         resetMouse();
/* 493:    */       }
/* 494:    */     }
/* 495:    */   }
/* 496:    */   
/* 497:    */   public static void updateCursor()
/* 498:    */   {
/* 499:681 */     synchronized (OpenGLPackageAccess.global_lock)
/* 500:    */     {
/* 501:682 */       if ((emulateCursorAnimation) && (currentCursor != null) && (currentCursor.hasTimedOut()) && (isInsideWindow()))
/* 502:    */       {
/* 503:683 */         currentCursor.nextCursor();
/* 504:    */         try
/* 505:    */         {
/* 506:685 */           setNativeCursor(currentCursor);
/* 507:    */         }
/* 508:    */         catch (LWJGLException e)
/* 509:    */         {
/* 510:687 */           if (LWJGLUtil.DEBUG) {
/* 511:687 */             e.printStackTrace();
/* 512:    */           }
/* 513:    */         }
/* 514:    */       }
/* 515:    */     }
/* 516:    */   }
/* 517:    */   
/* 518:    */   static boolean getPrivilegedBoolean(String property_name)
/* 519:    */   {
/* 520:695 */     Boolean value = (Boolean)AccessController.doPrivileged(new PrivilegedAction()
/* 521:    */     {
/* 522:    */       public Boolean run()
/* 523:    */       {
/* 524:697 */         return Boolean.valueOf(Boolean.getBoolean(this.val$property_name));
/* 525:    */       }
/* 526:699 */     });
/* 527:700 */     return value.booleanValue();
/* 528:    */   }
/* 529:    */   
/* 530:    */   public static boolean isInsideWindow()
/* 531:    */   {
/* 532:710 */     return implementation.isInsideWindow();
/* 533:    */   }
/* 534:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.Mouse
 * JD-Core Version:    0.7.0.1
 */