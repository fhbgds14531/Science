/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.Buffer;
/*   4:    */ import java.util.Arrays;
/*   5:    */ 
/*   6:    */ class BaseReferences
/*   7:    */ {
/*   8:    */   int elementArrayBuffer;
/*   9:    */   int arrayBuffer;
/*  10:    */   final Buffer[] glVertexAttribPointer_buffer;
/*  11:    */   final Buffer[] glTexCoordPointer_buffer;
/*  12:    */   int glClientActiveTexture;
/*  13:    */   int vertexArrayObject;
/*  14:    */   int pixelPackBuffer;
/*  15:    */   int pixelUnpackBuffer;
/*  16:    */   int indirectBuffer;
/*  17:    */   
/*  18:    */   BaseReferences(ContextCapabilities caps)
/*  19:    */   {
/*  20:    */     int max_vertex_attribs;
/*  21:    */     int max_vertex_attribs;
/*  22: 58 */     if ((caps.OpenGL20) || (caps.GL_ARB_vertex_shader)) {
/*  23: 59 */       max_vertex_attribs = GL11.glGetInteger(34921);
/*  24:    */     } else {
/*  25: 61 */       max_vertex_attribs = 0;
/*  26:    */     }
/*  27: 62 */     this.glVertexAttribPointer_buffer = new Buffer[max_vertex_attribs];
/*  28:    */     int max_texture_units;
/*  29:    */     int max_texture_units;
/*  30: 65 */     if (caps.OpenGL20)
/*  31:    */     {
/*  32: 66 */       max_texture_units = GL11.glGetInteger(34930);
/*  33:    */     }
/*  34:    */     else
/*  35:    */     {
/*  36:    */       int max_texture_units;
/*  37: 67 */       if ((caps.OpenGL13) || (caps.GL_ARB_multitexture)) {
/*  38: 68 */         max_texture_units = GL11.glGetInteger(34018);
/*  39:    */       } else {
/*  40: 70 */         max_texture_units = 1;
/*  41:    */       }
/*  42:    */     }
/*  43: 71 */     this.glTexCoordPointer_buffer = new Buffer[max_texture_units];
/*  44:    */   }
/*  45:    */   
/*  46:    */   void clear()
/*  47:    */   {
/*  48: 75 */     this.elementArrayBuffer = 0;
/*  49: 76 */     this.arrayBuffer = 0;
/*  50: 77 */     this.glClientActiveTexture = 0;
/*  51: 78 */     Arrays.fill(this.glVertexAttribPointer_buffer, null);
/*  52: 79 */     Arrays.fill(this.glTexCoordPointer_buffer, null);
/*  53:    */     
/*  54: 81 */     this.vertexArrayObject = 0;
/*  55:    */     
/*  56: 83 */     this.pixelPackBuffer = 0;
/*  57: 84 */     this.pixelUnpackBuffer = 0;
/*  58:    */     
/*  59: 86 */     this.indirectBuffer = 0;
/*  60:    */   }
/*  61:    */   
/*  62:    */   void copy(BaseReferences references, int mask)
/*  63:    */   {
/*  64: 90 */     if ((mask & 0x2) != 0)
/*  65:    */     {
/*  66: 91 */       this.elementArrayBuffer = references.elementArrayBuffer;
/*  67: 92 */       this.arrayBuffer = references.arrayBuffer;
/*  68: 93 */       this.glClientActiveTexture = references.glClientActiveTexture;
/*  69: 94 */       System.arraycopy(references.glVertexAttribPointer_buffer, 0, this.glVertexAttribPointer_buffer, 0, this.glVertexAttribPointer_buffer.length);
/*  70: 95 */       System.arraycopy(references.glTexCoordPointer_buffer, 0, this.glTexCoordPointer_buffer, 0, this.glTexCoordPointer_buffer.length);
/*  71:    */       
/*  72: 97 */       this.vertexArrayObject = references.vertexArrayObject;
/*  73:    */       
/*  74: 99 */       this.indirectBuffer = references.indirectBuffer;
/*  75:    */     }
/*  76:102 */     if ((mask & 0x1) != 0)
/*  77:    */     {
/*  78:103 */       this.pixelPackBuffer = references.pixelPackBuffer;
/*  79:104 */       this.pixelUnpackBuffer = references.pixelUnpackBuffer;
/*  80:    */     }
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.BaseReferences
 * JD-Core Version:    0.7.0.1
 */