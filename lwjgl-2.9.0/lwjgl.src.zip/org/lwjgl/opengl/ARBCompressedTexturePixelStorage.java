package org.lwjgl.opengl;

public final class ARBCompressedTexturePixelStorage
{
  public static final int GL_UNPACK_COMPRESSED_BLOCK_WIDTH = 37159;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_HEIGHT = 37160;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_DEPTH = 37161;
  public static final int GL_UNPACK_COMPRESSED_BLOCK_SIZE = 37162;
  public static final int GL_PACK_COMPRESSED_BLOCK_WIDTH = 37163;
  public static final int GL_PACK_COMPRESSED_BLOCK_HEIGHT = 37164;
  public static final int GL_PACK_COMPRESSED_BLOCK_DEPTH = 37165;
  public static final int GL_PACK_COMPRESSED_BLOCK_SIZE = 37166;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBCompressedTexturePixelStorage
 * JD-Core Version:    0.7.0.1
 */