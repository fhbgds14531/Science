/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTBindableUniform
/*  6:   */ {
/*  7:   */   public static final int GL_MAX_VERTEX_BINDABLE_UNIFORMS_EXT = 36322;
/*  8:   */   public static final int GL_MAX_FRAGMENT_BINDABLE_UNIFORMS_EXT = 36323;
/*  9:   */   public static final int GL_MAX_GEOMETRY_BINDABLE_UNIFORMS_EXT = 36324;
/* 10:   */   public static final int GL_MAX_BINDABLE_UNIFORM_SIZE_EXT = 36333;
/* 11:   */   public static final int GL_UNIFORM_BUFFER_BINDING_EXT = 36335;
/* 12:   */   public static final int GL_UNIFORM_BUFFER_EXT = 36334;
/* 13:   */   
/* 14:   */   public static void glUniformBufferEXT(int program, int location, int buffer)
/* 15:   */   {
/* 16:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 17:31 */     long function_pointer = caps.glUniformBufferEXT;
/* 18:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 19:33 */     nglUniformBufferEXT(program, location, buffer, function_pointer);
/* 20:   */   }
/* 21:   */   
/* 22:   */   static native void nglUniformBufferEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 23:   */   
/* 24:   */   public static int glGetUniformBufferSizeEXT(int program, int location)
/* 25:   */   {
/* 26:38 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:39 */     long function_pointer = caps.glGetUniformBufferSizeEXT;
/* 28:40 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:41 */     int __result = nglGetUniformBufferSizeEXT(program, location, function_pointer);
/* 30:42 */     return __result;
/* 31:   */   }
/* 32:   */   
/* 33:   */   static native int nglGetUniformBufferSizeEXT(int paramInt1, int paramInt2, long paramLong);
/* 34:   */   
/* 35:   */   public static long glGetUniformOffsetEXT(int program, int location)
/* 36:   */   {
/* 37:47 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 38:48 */     long function_pointer = caps.glGetUniformOffsetEXT;
/* 39:49 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 40:50 */     long __result = nglGetUniformOffsetEXT(program, location, function_pointer);
/* 41:51 */     return __result;
/* 42:   */   }
/* 43:   */   
/* 44:   */   static native long nglGetUniformOffsetEXT(int paramInt1, int paramInt2, long paramLong);
/* 45:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBindableUniform
 * JD-Core Version:    0.7.0.1
 */