package org.lwjgl.opencl;

public final class KHRFp16
{
  public static final int CL_DEVICE_HALF_FP_CONFIG = 4147;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRFp16
 * JD-Core Version:    0.7.0.1
 */