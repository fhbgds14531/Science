/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class APPLESetMemObjectDestructor
/*  6:   */ {
/*  7:   */   public static int clSetMemObjectDestructorAPPLE(CLMem memobj, CLMemObjectDestructorCallback pfn_notify)
/*  8:   */   {
/*  9:13 */     long function_pointer = CLCapabilities.clSetMemObjectDestructorAPPLE;
/* 10:14 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 11:15 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 12:16 */     int __result = 0;
/* 13:   */     try
/* 14:   */     {
/* 15:18 */       __result = nclSetMemObjectDestructorAPPLE(memobj.getPointer(), pfn_notify.getPointer(), user_data, function_pointer);
/* 16:19 */       return __result;
/* 17:   */     }
/* 18:   */     finally
/* 19:   */     {
/* 20:21 */       CallbackUtil.checkCallback(__result, user_data);
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   static native int nclSetMemObjectDestructorAPPLE(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 25:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.APPLESetMemObjectDestructor
 * JD-Core Version:    0.7.0.1
 */