package org.lwjgl.opengl;

public final class NVDeepTexture3D
{
  public static final int GL_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV = 37072;
  public static final int GL_MAX_DEEP_3D_TEXTURE_DEPTH_NV = 37073;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVDeepTexture3D
 * JD-Core Version:    0.7.0.1
 */