/*    1:     */ package org.lwjgl.opencl;
/*    2:     */ 
/*    3:     */ import java.nio.Buffer;
/*    4:     */ import java.nio.ByteBuffer;
/*    5:     */ import java.nio.ByteOrder;
/*    6:     */ import java.nio.DoubleBuffer;
/*    7:     */ import java.nio.FloatBuffer;
/*    8:     */ import java.nio.IntBuffer;
/*    9:     */ import java.nio.LongBuffer;
/*   10:     */ import java.nio.ShortBuffer;
/*   11:     */ import org.lwjgl.BufferChecks;
/*   12:     */ import org.lwjgl.LWJGLUtil;
/*   13:     */ import org.lwjgl.MemoryUtil;
/*   14:     */ import org.lwjgl.PointerBuffer;
/*   15:     */ 
/*   16:     */ public final class CL10
/*   17:     */ {
/*   18:     */   public static final int CL_SUCCESS = 0;
/*   19:     */   public static final int CL_DEVICE_NOT_FOUND = -1;
/*   20:     */   public static final int CL_DEVICE_NOT_AVAILABLE = -2;
/*   21:     */   public static final int CL_COMPILER_NOT_AVAILABLE = -3;
/*   22:     */   public static final int CL_MEM_OBJECT_ALLOCATION_FAILURE = -4;
/*   23:     */   public static final int CL_OUT_OF_RESOURCES = -5;
/*   24:     */   public static final int CL_OUT_OF_HOST_MEMORY = -6;
/*   25:     */   public static final int CL_PROFILING_INFO_NOT_AVAILABLE = -7;
/*   26:     */   public static final int CL_MEM_COPY_OVERLAP = -8;
/*   27:     */   public static final int CL_IMAGE_FORMAT_MISMATCH = -9;
/*   28:     */   public static final int CL_IMAGE_FORMAT_NOT_SUPPORTED = -10;
/*   29:     */   public static final int CL_BUILD_PROGRAM_FAILURE = -11;
/*   30:     */   public static final int CL_MAP_FAILURE = -12;
/*   31:     */   public static final int CL_INVALID_VALUE = -30;
/*   32:     */   public static final int CL_INVALID_DEVICE_TYPE = -31;
/*   33:     */   public static final int CL_INVALID_PLATFORM = -32;
/*   34:     */   public static final int CL_INVALID_DEVICE = -33;
/*   35:     */   public static final int CL_INVALID_CONTEXT = -34;
/*   36:     */   public static final int CL_INVALID_QUEUE_PROPERTIES = -35;
/*   37:     */   public static final int CL_INVALID_COMMAND_QUEUE = -36;
/*   38:     */   public static final int CL_INVALID_HOST_PTR = -37;
/*   39:     */   public static final int CL_INVALID_MEM_OBJECT = -38;
/*   40:     */   public static final int CL_INVALID_IMAGE_FORMAT_DESCRIPTOR = -39;
/*   41:     */   public static final int CL_INVALID_IMAGE_SIZE = -40;
/*   42:     */   public static final int CL_INVALID_SAMPLER = -41;
/*   43:     */   public static final int CL_INVALID_BINARY = -42;
/*   44:     */   public static final int CL_INVALID_BUILD_OPTIONS = -43;
/*   45:     */   public static final int CL_INVALID_PROGRAM = -44;
/*   46:     */   public static final int CL_INVALID_PROGRAM_EXECUTABLE = -45;
/*   47:     */   public static final int CL_INVALID_KERNEL_NAME = -46;
/*   48:     */   public static final int CL_INVALID_KERNEL_DEFINITION = -47;
/*   49:     */   public static final int CL_INVALID_KERNEL = -48;
/*   50:     */   public static final int CL_INVALID_ARG_INDEX = -49;
/*   51:     */   public static final int CL_INVALID_ARG_VALUE = -50;
/*   52:     */   public static final int CL_INVALID_ARG_SIZE = -51;
/*   53:     */   public static final int CL_INVALID_KERNEL_ARGS = -52;
/*   54:     */   public static final int CL_INVALID_WORK_DIMENSION = -53;
/*   55:     */   public static final int CL_INVALID_WORK_GROUP_SIZE = -54;
/*   56:     */   public static final int CL_INVALID_WORK_ITEM_SIZE = -55;
/*   57:     */   public static final int CL_INVALID_GLOBAL_OFFSET = -56;
/*   58:     */   public static final int CL_INVALID_EVENT_WAIT_LIST = -57;
/*   59:     */   public static final int CL_INVALID_EVENT = -58;
/*   60:     */   public static final int CL_INVALID_OPERATION = -59;
/*   61:     */   public static final int CL_INVALID_GL_OBJECT = -60;
/*   62:     */   public static final int CL_INVALID_BUFFER_SIZE = -61;
/*   63:     */   public static final int CL_INVALID_MIP_LEVEL = -62;
/*   64:     */   public static final int CL_INVALID_GLOBAL_WORK_SIZE = -63;
/*   65:     */   public static final int CL_VERSION_1_0 = 1;
/*   66:     */   public static final int CL_FALSE = 0;
/*   67:     */   public static final int CL_TRUE = 1;
/*   68:     */   public static final int CL_PLATFORM_PROFILE = 2304;
/*   69:     */   public static final int CL_PLATFORM_VERSION = 2305;
/*   70:     */   public static final int CL_PLATFORM_NAME = 2306;
/*   71:     */   public static final int CL_PLATFORM_VENDOR = 2307;
/*   72:     */   public static final int CL_PLATFORM_EXTENSIONS = 2308;
/*   73:     */   public static final int CL_DEVICE_TYPE_DEFAULT = 1;
/*   74:     */   public static final int CL_DEVICE_TYPE_CPU = 2;
/*   75:     */   public static final int CL_DEVICE_TYPE_GPU = 4;
/*   76:     */   public static final int CL_DEVICE_TYPE_ACCELERATOR = 8;
/*   77:     */   public static final int CL_DEVICE_TYPE_ALL = -1;
/*   78:     */   public static final int CL_DEVICE_TYPE = 4096;
/*   79:     */   public static final int CL_DEVICE_VENDOR_ID = 4097;
/*   80:     */   public static final int CL_DEVICE_MAX_COMPUTE_UNITS = 4098;
/*   81:     */   public static final int CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS = 4099;
/*   82:     */   public static final int CL_DEVICE_MAX_WORK_GROUP_SIZE = 4100;
/*   83:     */   public static final int CL_DEVICE_MAX_WORK_ITEM_SIZES = 4101;
/*   84:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_CHAR = 4102;
/*   85:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_SHORT = 4103;
/*   86:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_ = 4104;
/*   87:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_LONG = 4105;
/*   88:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_FLOAT = 4106;
/*   89:     */   public static final int CL_DEVICE_PREFERRED_VECTOR_WIDTH_DOUBLE = 4107;
/*   90:     */   public static final int CL_DEVICE_MAX_CLOCK_FREQUENCY = 4108;
/*   91:     */   public static final int CL_DEVICE_ADDRESS_BITS = 4109;
/*   92:     */   public static final int CL_DEVICE_MAX_READ_IMAGE_ARGS = 4110;
/*   93:     */   public static final int CL_DEVICE_MAX_WRITE_IMAGE_ARGS = 4111;
/*   94:     */   public static final int CL_DEVICE_MAX_MEM_ALLOC_SIZE = 4112;
/*   95:     */   public static final int CL_DEVICE_IMAGE2D_MAX_WIDTH = 4113;
/*   96:     */   public static final int CL_DEVICE_IMAGE2D_MAX_HEIGHT = 4114;
/*   97:     */   public static final int CL_DEVICE_IMAGE3D_MAX_WIDTH = 4115;
/*   98:     */   public static final int CL_DEVICE_IMAGE3D_MAX_HEIGHT = 4116;
/*   99:     */   public static final int CL_DEVICE_IMAGE3D_MAX_DEPTH = 4117;
/*  100:     */   public static final int CL_DEVICE_IMAGE_SUPPORT = 4118;
/*  101:     */   public static final int CL_DEVICE_MAX_PARAMETER_SIZE = 4119;
/*  102:     */   public static final int CL_DEVICE_MAX_SAMPLERS = 4120;
/*  103:     */   public static final int CL_DEVICE_MEM_BASE_ADDR_ALIGN = 4121;
/*  104:     */   public static final int CL_DEVICE_MIN_DATA_TYPE_ALIGN_SIZE = 4122;
/*  105:     */   public static final int CL_DEVICE_SINGLE_FP_CONFIG = 4123;
/*  106:     */   public static final int CL_DEVICE_GLOBAL_MEM_CACHE_TYPE = 4124;
/*  107:     */   public static final int CL_DEVICE_GLOBAL_MEM_CACHELINE_SIZE = 4125;
/*  108:     */   public static final int CL_DEVICE_GLOBAL_MEM_CACHE_SIZE = 4126;
/*  109:     */   public static final int CL_DEVICE_GLOBAL_MEM_SIZE = 4127;
/*  110:     */   public static final int CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE = 4128;
/*  111:     */   public static final int CL_DEVICE_MAX_CONSTANT_ARGS = 4129;
/*  112:     */   public static final int CL_DEVICE_LOCAL_MEM_TYPE = 4130;
/*  113:     */   public static final int CL_DEVICE_LOCAL_MEM_SIZE = 4131;
/*  114:     */   public static final int CL_DEVICE_ERROR_CORRECTION_SUPPORT = 4132;
/*  115:     */   public static final int CL_DEVICE_PROFILING_TIMER_RESOLUTION = 4133;
/*  116:     */   public static final int CL_DEVICE_ENDIAN_LITTLE = 4134;
/*  117:     */   public static final int CL_DEVICE_AVAILABLE = 4135;
/*  118:     */   public static final int CL_DEVICE_COMPILER_AVAILABLE = 4136;
/*  119:     */   public static final int CL_DEVICE_EXECUTION_CAPABILITIES = 4137;
/*  120:     */   public static final int CL_DEVICE_QUEUE_PROPERTIES = 4138;
/*  121:     */   public static final int CL_DEVICE_NAME = 4139;
/*  122:     */   public static final int CL_DEVICE_VENDOR = 4140;
/*  123:     */   public static final int CL_DRIVER_VERSION = 4141;
/*  124:     */   public static final int CL_DEVICE_PROFILE = 4142;
/*  125:     */   public static final int CL_DEVICE_VERSION = 4143;
/*  126:     */   public static final int CL_DEVICE_EXTENSIONS = 4144;
/*  127:     */   public static final int CL_DEVICE_PLATFORM = 4145;
/*  128:     */   public static final int CL_FP_DENORM = 1;
/*  129:     */   public static final int CL_FP_INF_NAN = 2;
/*  130:     */   public static final int CL_FP_ROUND_TO_NEAREST = 4;
/*  131:     */   public static final int CL_FP_ROUND_TO_ZERO = 8;
/*  132:     */   public static final int CL_FP_ROUND_TO_INF = 16;
/*  133:     */   public static final int CL_FP_FMA = 32;
/*  134:     */   public static final int CL_NONE = 0;
/*  135:     */   public static final int CL_READ_ONLY_CACHE = 1;
/*  136:     */   public static final int CL_READ_WRITE_CACHE = 2;
/*  137:     */   public static final int CL_LOCAL = 1;
/*  138:     */   public static final int CL_GLOBAL = 2;
/*  139:     */   public static final int CL_EXEC_KERNEL = 1;
/*  140:     */   public static final int CL_EXEC_NATIVE_KERNEL = 2;
/*  141:     */   public static final int CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE = 1;
/*  142:     */   public static final int CL_QUEUE_PROFILING_ENABLE = 2;
/*  143:     */   public static final int CL_CONTEXT_REFERENCE_COUNT = 4224;
/*  144:     */   public static final int CL_CONTEXT_DEVICES = 4225;
/*  145:     */   public static final int CL_CONTEXT_PROPERTIES = 4226;
/*  146:     */   public static final int CL_CONTEXT_PLATFORM = 4228;
/*  147:     */   public static final int CL_QUEUE_CONTEXT = 4240;
/*  148:     */   public static final int CL_QUEUE_DEVICE = 4241;
/*  149:     */   public static final int CL_QUEUE_REFERENCE_COUNT = 4242;
/*  150:     */   public static final int CL_QUEUE_PROPERTIES = 4243;
/*  151:     */   public static final int CL_MEM_READ_WRITE = 1;
/*  152:     */   public static final int CL_MEM_WRITE_ONLY = 2;
/*  153:     */   public static final int CL_MEM_READ_ONLY = 4;
/*  154:     */   public static final int CL_MEM_USE_HOST_PTR = 8;
/*  155:     */   public static final int CL_MEM_ALLOC_HOST_PTR = 16;
/*  156:     */   public static final int CL_MEM_COPY_HOST_PTR = 32;
/*  157:     */   public static final int CL_R = 4272;
/*  158:     */   public static final int CL_A = 4273;
/*  159:     */   public static final int CL_RG = 4274;
/*  160:     */   public static final int CL_RA = 4275;
/*  161:     */   public static final int CL_RGB = 4276;
/*  162:     */   public static final int CL_RGBA = 4277;
/*  163:     */   public static final int CL_BGRA = 4278;
/*  164:     */   public static final int CL_ARGB = 4279;
/*  165:     */   public static final int CL_INTENSITY = 4280;
/*  166:     */   public static final int CL_LUMINANCE = 4281;
/*  167:     */   public static final int CL_SNORM_INT8 = 4304;
/*  168:     */   public static final int CL_SNORM_INT16 = 4305;
/*  169:     */   public static final int CL_UNORM_INT8 = 4306;
/*  170:     */   public static final int CL_UNORM_INT16 = 4307;
/*  171:     */   public static final int CL_UNORM_SHORT_565 = 4308;
/*  172:     */   public static final int CL_UNORM_SHORT_555 = 4309;
/*  173:     */   public static final int CL_UNORM_INT_101010 = 4310;
/*  174:     */   public static final int CL_SIGNED_INT8 = 4311;
/*  175:     */   public static final int CL_SIGNED_INT16 = 4312;
/*  176:     */   public static final int CL_SIGNED_INT32 = 4313;
/*  177:     */   public static final int CL_UNSIGNED_INT8 = 4314;
/*  178:     */   public static final int CL_UNSIGNED_INT16 = 4315;
/*  179:     */   public static final int CL_UNSIGNED_INT32 = 4316;
/*  180:     */   public static final int CL_HALF_FLOAT = 4317;
/*  181:     */   public static final int CL_FLOAT = 4318;
/*  182:     */   public static final int CL_MEM_OBJECT_BUFFER = 4336;
/*  183:     */   public static final int CL_MEM_OBJECT_IMAGE2D = 4337;
/*  184:     */   public static final int CL_MEM_OBJECT_IMAGE3D = 4338;
/*  185:     */   public static final int CL_MEM_TYPE = 4352;
/*  186:     */   public static final int CL_MEM_FLAGS = 4353;
/*  187:     */   public static final int CL_MEM_SIZE = 4354;
/*  188:     */   public static final int CL_MEM_HOST_PTR = 4355;
/*  189:     */   public static final int CL_MEM_MAP_COUNT = 4356;
/*  190:     */   public static final int CL_MEM_REFERENCE_COUNT = 4357;
/*  191:     */   public static final int CL_MEM_CONTEXT = 4358;
/*  192:     */   public static final int CL_IMAGE_FORMAT = 4368;
/*  193:     */   public static final int CL_IMAGE_ELEMENT_SIZE = 4369;
/*  194:     */   public static final int CL_IMAGE_ROW_PITCH = 4370;
/*  195:     */   public static final int CL_IMAGE_SLICE_PITCH = 4371;
/*  196:     */   public static final int CL_IMAGE_WIDTH = 4372;
/*  197:     */   public static final int CL_IMAGE_HEIGHT = 4373;
/*  198:     */   public static final int CL_IMAGE_DEPTH = 4374;
/*  199:     */   public static final int CL_ADDRESS_NONE = 4400;
/*  200:     */   public static final int CL_ADDRESS_CLAMP_TO_EDGE = 4401;
/*  201:     */   public static final int CL_ADDRESS_CLAMP = 4402;
/*  202:     */   public static final int CL_ADDRESS_REPEAT = 4403;
/*  203:     */   public static final int CL_FILTER_NEAREST = 4416;
/*  204:     */   public static final int CL_FILTER_LINEAR = 4417;
/*  205:     */   public static final int CL_SAMPLER_REFERENCE_COUNT = 4432;
/*  206:     */   public static final int CL_SAMPLER_CONTEXT = 4433;
/*  207:     */   public static final int CL_SAMPLER_NORMALIZED_COORDS = 4434;
/*  208:     */   public static final int CL_SAMPLER_ADDRESSING_MODE = 4435;
/*  209:     */   public static final int CL_SAMPLER_FILTER_MODE = 4436;
/*  210:     */   public static final int CL_MAP_READ = 1;
/*  211:     */   public static final int CL_MAP_WRITE = 2;
/*  212:     */   public static final int CL_PROGRAM_REFERENCE_COUNT = 4448;
/*  213:     */   public static final int CL_PROGRAM_CONTEXT = 4449;
/*  214:     */   public static final int CL_PROGRAM_NUM_DEVICES = 4450;
/*  215:     */   public static final int CL_PROGRAM_DEVICES = 4451;
/*  216:     */   public static final int CL_PROGRAM_SOURCE = 4452;
/*  217:     */   public static final int CL_PROGRAM_BINARY_SIZES = 4453;
/*  218:     */   public static final int CL_PROGRAM_BINARIES = 4454;
/*  219:     */   public static final int CL_PROGRAM_BUILD_STATUS = 4481;
/*  220:     */   public static final int CL_PROGRAM_BUILD_OPTIONS = 4482;
/*  221:     */   public static final int CL_PROGRAM_BUILD_LOG = 4483;
/*  222:     */   public static final int CL_BUILD_SUCCESS = 0;
/*  223:     */   public static final int CL_BUILD_NONE = -1;
/*  224:     */   public static final int CL_BUILD_ERROR = -2;
/*  225:     */   public static final int CL_BUILD_IN_PROGRESS = -3;
/*  226:     */   public static final int CL_KERNEL_FUNCTION_NAME = 4496;
/*  227:     */   public static final int CL_KERNEL_NUM_ARGS = 4497;
/*  228:     */   public static final int CL_KERNEL_REFERENCE_COUNT = 4498;
/*  229:     */   public static final int CL_KERNEL_CONTEXT = 4499;
/*  230:     */   public static final int CL_KERNEL_PROGRAM = 4500;
/*  231:     */   public static final int CL_KERNEL_WORK_GROUP_SIZE = 4528;
/*  232:     */   public static final int CL_KERNEL_COMPILE_WORK_GROUP_SIZE = 4529;
/*  233:     */   public static final int CL_KERNEL_LOCAL_MEM_SIZE = 4530;
/*  234:     */   public static final int CL_EVENT_COMMAND_QUEUE = 4560;
/*  235:     */   public static final int CL_EVENT_COMMAND_TYPE = 4561;
/*  236:     */   public static final int CL_EVENT_REFERENCE_COUNT = 4562;
/*  237:     */   public static final int CL_EVENT_COMMAND_EXECUTION_STATUS = 4563;
/*  238:     */   public static final int CL_COMMAND_NDRANGE_KERNEL = 4592;
/*  239:     */   public static final int CL_COMMAND_TASK = 4593;
/*  240:     */   public static final int CL_COMMAND_NATIVE_KERNEL = 4594;
/*  241:     */   public static final int CL_COMMAND_READ_BUFFER = 4595;
/*  242:     */   public static final int CL_COMMAND_WRITE_BUFFER = 4596;
/*  243:     */   public static final int CL_COMMAND_COPY_BUFFER = 4597;
/*  244:     */   public static final int CL_COMMAND_READ_IMAGE = 4598;
/*  245:     */   public static final int CL_COMMAND_WRITE_IMAGE = 4599;
/*  246:     */   public static final int CL_COMMAND_COPY_IMAGE = 4600;
/*  247:     */   public static final int CL_COMMAND_COPY_IMAGE_TO_BUFFER = 4601;
/*  248:     */   public static final int CL_COMMAND_COPY_BUFFER_TO_IMAGE = 4602;
/*  249:     */   public static final int CL_COMMAND_MAP_BUFFER = 4603;
/*  250:     */   public static final int CL_COMMAND_MAP_IMAGE = 4604;
/*  251:     */   public static final int CL_COMMAND_UNMAP_MEM_OBJECT = 4605;
/*  252:     */   public static final int CL_COMMAND_MARKER = 4606;
/*  253:     */   public static final int CL_COMMAND_ACQUIRE_GL_OBJECTS = 4607;
/*  254:     */   public static final int CL_COMMAND_RELEASE_GL_OBJECTS = 4608;
/*  255:     */   public static final int CL_COMPLETE = 0;
/*  256:     */   public static final int CL_RUNNING = 1;
/*  257:     */   public static final int CL_SUBMITTED = 2;
/*  258:     */   public static final int CL_QUEUED = 3;
/*  259:     */   public static final int CL_PROFILING_COMMAND_QUEUED = 4736;
/*  260:     */   public static final int CL_PROFILING_COMMAND_SUBMIT = 4737;
/*  261:     */   public static final int CL_PROFILING_COMMAND_START = 4738;
/*  262:     */   public static final int CL_PROFILING_COMMAND_END = 4739;
/*  263:     */   
/*  264:     */   public static int clGetPlatformIDs(PointerBuffer platforms, IntBuffer num_platforms)
/*  265:     */   {
/*  266: 393 */     long function_pointer = CLCapabilities.clGetPlatformIDs;
/*  267: 394 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  268: 395 */     if (platforms != null) {
/*  269: 396 */       BufferChecks.checkDirect(platforms);
/*  270:     */     }
/*  271: 397 */     if (num_platforms != null) {
/*  272: 398 */       BufferChecks.checkBuffer(num_platforms, 1);
/*  273:     */     }
/*  274: 399 */     if (num_platforms == null) {
/*  275: 399 */       num_platforms = APIUtil.getBufferInt();
/*  276:     */     }
/*  277: 400 */     int __result = nclGetPlatformIDs(platforms == null ? 0 : platforms.remaining(), MemoryUtil.getAddressSafe(platforms), MemoryUtil.getAddressSafe(num_platforms), function_pointer);
/*  278: 401 */     if ((__result == 0) && (platforms != null)) {
/*  279: 401 */       CLPlatform.registerCLPlatforms(platforms, num_platforms);
/*  280:     */     }
/*  281: 402 */     return __result;
/*  282:     */   }
/*  283:     */   
/*  284:     */   static native int nclGetPlatformIDs(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  285:     */   
/*  286:     */   public static int clGetPlatformInfo(CLPlatform platform, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  287:     */   {
/*  288: 407 */     long function_pointer = CLCapabilities.clGetPlatformInfo;
/*  289: 408 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  290: 409 */     if (param_value != null) {
/*  291: 410 */       BufferChecks.checkDirect(param_value);
/*  292:     */     }
/*  293: 411 */     if (param_value_size_ret != null) {
/*  294: 412 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/*  295:     */     }
/*  296: 413 */     int __result = nclGetPlatformInfo(platform == null ? 0L : platform.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/*  297: 414 */     return __result;
/*  298:     */   }
/*  299:     */   
/*  300:     */   static native int nclGetPlatformInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  301:     */   
/*  302:     */   public static int clGetDeviceIDs(CLPlatform platform, long device_type, PointerBuffer devices, IntBuffer num_devices)
/*  303:     */   {
/*  304: 419 */     long function_pointer = CLCapabilities.clGetDeviceIDs;
/*  305: 420 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  306: 421 */     if (devices != null) {
/*  307: 422 */       BufferChecks.checkDirect(devices);
/*  308:     */     }
/*  309: 423 */     if (num_devices != null) {
/*  310: 424 */       BufferChecks.checkBuffer(num_devices, 1);
/*  311:     */     } else {
/*  312: 426 */       num_devices = APIUtil.getBufferInt();
/*  313:     */     }
/*  314: 427 */     int __result = nclGetDeviceIDs(platform.getPointer(), device_type, devices == null ? 0 : devices.remaining(), MemoryUtil.getAddressSafe(devices), MemoryUtil.getAddressSafe(num_devices), function_pointer);
/*  315: 428 */     if ((__result == 0) && (devices != null)) {
/*  316: 428 */       platform.registerCLDevices(devices, num_devices);
/*  317:     */     }
/*  318: 429 */     return __result;
/*  319:     */   }
/*  320:     */   
/*  321:     */   static native int nclGetDeviceIDs(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/*  322:     */   
/*  323:     */   public static int clGetDeviceInfo(CLDevice device, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  324:     */   {
/*  325: 434 */     long function_pointer = CLCapabilities.clGetDeviceInfo;
/*  326: 435 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  327: 436 */     if (param_value != null) {
/*  328: 437 */       BufferChecks.checkDirect(param_value);
/*  329:     */     }
/*  330: 438 */     if (param_value_size_ret != null) {
/*  331: 439 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/*  332:     */     }
/*  333: 440 */     int __result = nclGetDeviceInfo(device.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/*  334: 441 */     return __result;
/*  335:     */   }
/*  336:     */   
/*  337:     */   static native int nclGetDeviceInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  338:     */   
/*  339:     */   public static CLContext clCreateContext(PointerBuffer properties, PointerBuffer devices, CLContextCallback pfn_notify, IntBuffer errcode_ret)
/*  340:     */   {
/*  341: 449 */     long function_pointer = CLCapabilities.clCreateContext;
/*  342: 450 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  343: 451 */     BufferChecks.checkBuffer(properties, 3);
/*  344: 452 */     BufferChecks.checkNullTerminated(properties);
/*  345: 453 */     BufferChecks.checkBuffer(devices, 1);
/*  346: 454 */     if (errcode_ret != null) {
/*  347: 455 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  348:     */     }
/*  349: 456 */     long user_data = (pfn_notify == null) || (pfn_notify.isCustom()) ? 0L : CallbackUtil.createGlobalRef(pfn_notify);
/*  350: 457 */     CLContext __result = null;
/*  351:     */     try
/*  352:     */     {
/*  353: 459 */       __result = new CLContext(nclCreateContext(MemoryUtil.getAddress(properties), devices.remaining(), MemoryUtil.getAddress(devices), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), APIUtil.getCLPlatform(properties));
/*  354: 460 */       return __result;
/*  355:     */     }
/*  356:     */     finally
/*  357:     */     {
/*  358: 462 */       if (__result != null) {
/*  359: 462 */         __result.setContextCallback(user_data);
/*  360:     */       }
/*  361:     */     }
/*  362:     */   }
/*  363:     */   
/*  364:     */   static native long nclCreateContext(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*  365:     */   
/*  366:     */   public static CLContext clCreateContext(PointerBuffer properties, CLDevice device, CLContextCallback pfn_notify, IntBuffer errcode_ret)
/*  367:     */   {
/*  368: 473 */     long function_pointer = CLCapabilities.clCreateContext;
/*  369: 474 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  370: 475 */     BufferChecks.checkBuffer(properties, 3);
/*  371: 476 */     BufferChecks.checkNullTerminated(properties);
/*  372: 477 */     if (errcode_ret != null) {
/*  373: 478 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  374:     */     }
/*  375: 479 */     long user_data = (pfn_notify == null) || (pfn_notify.isCustom()) ? 0L : CallbackUtil.createGlobalRef(pfn_notify);
/*  376: 480 */     CLContext __result = null;
/*  377:     */     try
/*  378:     */     {
/*  379: 482 */       __result = new CLContext(nclCreateContext(MemoryUtil.getAddress(properties), 1, APIUtil.getPointer(device), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), APIUtil.getCLPlatform(properties));
/*  380: 483 */       return __result;
/*  381:     */     }
/*  382:     */     finally
/*  383:     */     {
/*  384: 485 */       if (__result != null) {
/*  385: 485 */         __result.setContextCallback(user_data);
/*  386:     */       }
/*  387:     */     }
/*  388:     */   }
/*  389:     */   
/*  390:     */   public static CLContext clCreateContextFromType(PointerBuffer properties, long device_type, CLContextCallback pfn_notify, IntBuffer errcode_ret)
/*  391:     */   {
/*  392: 493 */     long function_pointer = CLCapabilities.clCreateContextFromType;
/*  393: 494 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  394: 495 */     BufferChecks.checkBuffer(properties, 3);
/*  395: 496 */     BufferChecks.checkNullTerminated(properties);
/*  396: 497 */     if (errcode_ret != null) {
/*  397: 498 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  398:     */     }
/*  399: 499 */     long user_data = (pfn_notify == null) || (pfn_notify.isCustom()) ? 0L : CallbackUtil.createGlobalRef(pfn_notify);
/*  400: 500 */     CLContext __result = null;
/*  401:     */     try
/*  402:     */     {
/*  403: 502 */       __result = new CLContext(nclCreateContextFromType(MemoryUtil.getAddress(properties), device_type, pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), APIUtil.getCLPlatform(properties));
/*  404: 503 */       return __result;
/*  405:     */     }
/*  406:     */     finally
/*  407:     */     {
/*  408: 505 */       if (__result != null) {
/*  409: 505 */         __result.setContextCallback(user_data);
/*  410:     */       }
/*  411:     */     }
/*  412:     */   }
/*  413:     */   
/*  414:     */   static native long nclCreateContextFromType(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*  415:     */   
/*  416:     */   public static int clRetainContext(CLContext context)
/*  417:     */   {
/*  418: 511 */     long function_pointer = CLCapabilities.clRetainContext;
/*  419: 512 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  420: 513 */     int __result = nclRetainContext(context.getPointer(), function_pointer);
/*  421: 514 */     if (__result == 0) {
/*  422: 514 */       context.retain();
/*  423:     */     }
/*  424: 515 */     return __result;
/*  425:     */   }
/*  426:     */   
/*  427:     */   static native int nclRetainContext(long paramLong1, long paramLong2);
/*  428:     */   
/*  429:     */   public static int clReleaseContext(CLContext context)
/*  430:     */   {
/*  431: 520 */     long function_pointer = CLCapabilities.clReleaseContext;
/*  432: 521 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  433: 522 */     APIUtil.releaseObjects(context);
/*  434: 523 */     int __result = nclReleaseContext(context.getPointer(), function_pointer);
/*  435: 524 */     if (__result == 0) {
/*  436: 524 */       context.releaseImpl();
/*  437:     */     }
/*  438: 525 */     return __result;
/*  439:     */   }
/*  440:     */   
/*  441:     */   static native int nclReleaseContext(long paramLong1, long paramLong2);
/*  442:     */   
/*  443:     */   public static int clGetContextInfo(CLContext context, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  444:     */   {
/*  445: 530 */     long function_pointer = CLCapabilities.clGetContextInfo;
/*  446: 531 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  447: 532 */     if (param_value != null) {
/*  448: 533 */       BufferChecks.checkDirect(param_value);
/*  449:     */     }
/*  450: 534 */     if (param_value_size_ret != null) {
/*  451: 535 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/*  452:     */     }
/*  453: 536 */     if ((param_value_size_ret == null) && (APIUtil.isDevicesParam(param_name))) {
/*  454: 536 */       param_value_size_ret = APIUtil.getBufferPointer();
/*  455:     */     }
/*  456: 537 */     int __result = nclGetContextInfo(context.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/*  457: 538 */     if ((__result == 0) && (param_value != null) && (APIUtil.isDevicesParam(param_name))) {
/*  458: 538 */       ((CLPlatform)context.getParent()).registerCLDevices(param_value, param_value_size_ret);
/*  459:     */     }
/*  460: 539 */     return __result;
/*  461:     */   }
/*  462:     */   
/*  463:     */   static native int nclGetContextInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  464:     */   
/*  465:     */   public static CLCommandQueue clCreateCommandQueue(CLContext context, CLDevice device, long properties, IntBuffer errcode_ret)
/*  466:     */   {
/*  467: 544 */     long function_pointer = CLCapabilities.clCreateCommandQueue;
/*  468: 545 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  469: 546 */     if (errcode_ret != null) {
/*  470: 547 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  471:     */     }
/*  472: 548 */     CLCommandQueue __result = new CLCommandQueue(nclCreateCommandQueue(context.getPointer(), device.getPointer(), properties, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context, device);
/*  473: 549 */     return __result;
/*  474:     */   }
/*  475:     */   
/*  476:     */   static native long nclCreateCommandQueue(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  477:     */   
/*  478:     */   public static int clRetainCommandQueue(CLCommandQueue command_queue)
/*  479:     */   {
/*  480: 554 */     long function_pointer = CLCapabilities.clRetainCommandQueue;
/*  481: 555 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  482: 556 */     int __result = nclRetainCommandQueue(command_queue.getPointer(), function_pointer);
/*  483: 557 */     if (__result == 0) {
/*  484: 557 */       command_queue.retain();
/*  485:     */     }
/*  486: 558 */     return __result;
/*  487:     */   }
/*  488:     */   
/*  489:     */   static native int nclRetainCommandQueue(long paramLong1, long paramLong2);
/*  490:     */   
/*  491:     */   public static int clReleaseCommandQueue(CLCommandQueue command_queue)
/*  492:     */   {
/*  493: 563 */     long function_pointer = CLCapabilities.clReleaseCommandQueue;
/*  494: 564 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  495: 565 */     APIUtil.releaseObjects(command_queue);
/*  496: 566 */     int __result = nclReleaseCommandQueue(command_queue.getPointer(), function_pointer);
/*  497: 567 */     if (__result == 0) {
/*  498: 567 */       command_queue.release();
/*  499:     */     }
/*  500: 568 */     return __result;
/*  501:     */   }
/*  502:     */   
/*  503:     */   static native int nclReleaseCommandQueue(long paramLong1, long paramLong2);
/*  504:     */   
/*  505:     */   public static int clGetCommandQueueInfo(CLCommandQueue command_queue, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  506:     */   {
/*  507: 573 */     long function_pointer = CLCapabilities.clGetCommandQueueInfo;
/*  508: 574 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  509: 575 */     if (param_value != null) {
/*  510: 576 */       BufferChecks.checkDirect(param_value);
/*  511:     */     }
/*  512: 577 */     if (param_value_size_ret != null) {
/*  513: 578 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/*  514:     */     }
/*  515: 579 */     int __result = nclGetCommandQueueInfo(command_queue.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/*  516: 580 */     return __result;
/*  517:     */   }
/*  518:     */   
/*  519:     */   static native int nclGetCommandQueueInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  520:     */   
/*  521:     */   public static CLMem clCreateBuffer(CLContext context, long flags, long host_ptr_size, IntBuffer errcode_ret)
/*  522:     */   {
/*  523: 585 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  524: 586 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  525: 587 */     if (errcode_ret != null) {
/*  526: 588 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  527:     */     }
/*  528: 589 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr_size, 0L, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  529: 590 */     return __result;
/*  530:     */   }
/*  531:     */   
/*  532:     */   public static CLMem clCreateBuffer(CLContext context, long flags, ByteBuffer host_ptr, IntBuffer errcode_ret)
/*  533:     */   {
/*  534: 593 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  535: 594 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  536: 595 */     BufferChecks.checkDirect(host_ptr);
/*  537: 596 */     if (errcode_ret != null) {
/*  538: 597 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  539:     */     }
/*  540: 598 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining(), MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  541: 599 */     return __result;
/*  542:     */   }
/*  543:     */   
/*  544:     */   public static CLMem clCreateBuffer(CLContext context, long flags, DoubleBuffer host_ptr, IntBuffer errcode_ret)
/*  545:     */   {
/*  546: 602 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  547: 603 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  548: 604 */     BufferChecks.checkDirect(host_ptr);
/*  549: 605 */     if (errcode_ret != null) {
/*  550: 606 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  551:     */     }
/*  552: 607 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining() << 3, MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  553: 608 */     return __result;
/*  554:     */   }
/*  555:     */   
/*  556:     */   public static CLMem clCreateBuffer(CLContext context, long flags, FloatBuffer host_ptr, IntBuffer errcode_ret)
/*  557:     */   {
/*  558: 611 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  559: 612 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  560: 613 */     BufferChecks.checkDirect(host_ptr);
/*  561: 614 */     if (errcode_ret != null) {
/*  562: 615 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  563:     */     }
/*  564: 616 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining() << 2, MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  565: 617 */     return __result;
/*  566:     */   }
/*  567:     */   
/*  568:     */   public static CLMem clCreateBuffer(CLContext context, long flags, IntBuffer host_ptr, IntBuffer errcode_ret)
/*  569:     */   {
/*  570: 620 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  571: 621 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  572: 622 */     BufferChecks.checkDirect(host_ptr);
/*  573: 623 */     if (errcode_ret != null) {
/*  574: 624 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  575:     */     }
/*  576: 625 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining() << 2, MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  577: 626 */     return __result;
/*  578:     */   }
/*  579:     */   
/*  580:     */   public static CLMem clCreateBuffer(CLContext context, long flags, LongBuffer host_ptr, IntBuffer errcode_ret)
/*  581:     */   {
/*  582: 629 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  583: 630 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  584: 631 */     BufferChecks.checkDirect(host_ptr);
/*  585: 632 */     if (errcode_ret != null) {
/*  586: 633 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  587:     */     }
/*  588: 634 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining() << 3, MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  589: 635 */     return __result;
/*  590:     */   }
/*  591:     */   
/*  592:     */   public static CLMem clCreateBuffer(CLContext context, long flags, ShortBuffer host_ptr, IntBuffer errcode_ret)
/*  593:     */   {
/*  594: 638 */     long function_pointer = CLCapabilities.clCreateBuffer;
/*  595: 639 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  596: 640 */     BufferChecks.checkDirect(host_ptr);
/*  597: 641 */     if (errcode_ret != null) {
/*  598: 642 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  599:     */     }
/*  600: 643 */     CLMem __result = new CLMem(nclCreateBuffer(context.getPointer(), flags, host_ptr.remaining() << 1, MemoryUtil.getAddress(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  601: 644 */     return __result;
/*  602:     */   }
/*  603:     */   
/*  604:     */   static native long nclCreateBuffer(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*  605:     */   
/*  606:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  607:     */   {
/*  608: 649 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  609: 650 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  610: 651 */     BufferChecks.checkDirect(ptr);
/*  611: 652 */     if (event_wait_list != null) {
/*  612: 653 */       BufferChecks.checkDirect(event_wait_list);
/*  613:     */     }
/*  614: 654 */     if (event != null) {
/*  615: 655 */       BufferChecks.checkBuffer(event, 1);
/*  616:     */     }
/*  617: 656 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining(), MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  618: 657 */     if (__result == 0) {
/*  619: 657 */       command_queue.registerCLEvent(event);
/*  620:     */     }
/*  621: 658 */     return __result;
/*  622:     */   }
/*  623:     */   
/*  624:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, DoubleBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  625:     */   {
/*  626: 661 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  627: 662 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  628: 663 */     BufferChecks.checkDirect(ptr);
/*  629: 664 */     if (event_wait_list != null) {
/*  630: 665 */       BufferChecks.checkDirect(event_wait_list);
/*  631:     */     }
/*  632: 666 */     if (event != null) {
/*  633: 667 */       BufferChecks.checkBuffer(event, 1);
/*  634:     */     }
/*  635: 668 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining() << 3, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  636: 669 */     if (__result == 0) {
/*  637: 669 */       command_queue.registerCLEvent(event);
/*  638:     */     }
/*  639: 670 */     return __result;
/*  640:     */   }
/*  641:     */   
/*  642:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  643:     */   {
/*  644: 673 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  645: 674 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  646: 675 */     BufferChecks.checkDirect(ptr);
/*  647: 676 */     if (event_wait_list != null) {
/*  648: 677 */       BufferChecks.checkDirect(event_wait_list);
/*  649:     */     }
/*  650: 678 */     if (event != null) {
/*  651: 679 */       BufferChecks.checkBuffer(event, 1);
/*  652:     */     }
/*  653: 680 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining() << 2, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  654: 681 */     if (__result == 0) {
/*  655: 681 */       command_queue.registerCLEvent(event);
/*  656:     */     }
/*  657: 682 */     return __result;
/*  658:     */   }
/*  659:     */   
/*  660:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  661:     */   {
/*  662: 685 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  663: 686 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  664: 687 */     BufferChecks.checkDirect(ptr);
/*  665: 688 */     if (event_wait_list != null) {
/*  666: 689 */       BufferChecks.checkDirect(event_wait_list);
/*  667:     */     }
/*  668: 690 */     if (event != null) {
/*  669: 691 */       BufferChecks.checkBuffer(event, 1);
/*  670:     */     }
/*  671: 692 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining() << 2, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  672: 693 */     if (__result == 0) {
/*  673: 693 */       command_queue.registerCLEvent(event);
/*  674:     */     }
/*  675: 694 */     return __result;
/*  676:     */   }
/*  677:     */   
/*  678:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, LongBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  679:     */   {
/*  680: 697 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  681: 698 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  682: 699 */     BufferChecks.checkDirect(ptr);
/*  683: 700 */     if (event_wait_list != null) {
/*  684: 701 */       BufferChecks.checkDirect(event_wait_list);
/*  685:     */     }
/*  686: 702 */     if (event != null) {
/*  687: 703 */       BufferChecks.checkBuffer(event, 1);
/*  688:     */     }
/*  689: 704 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining() << 3, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  690: 705 */     if (__result == 0) {
/*  691: 705 */       command_queue.registerCLEvent(event);
/*  692:     */     }
/*  693: 706 */     return __result;
/*  694:     */   }
/*  695:     */   
/*  696:     */   public static int clEnqueueReadBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_read, long offset, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  697:     */   {
/*  698: 709 */     long function_pointer = CLCapabilities.clEnqueueReadBuffer;
/*  699: 710 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  700: 711 */     BufferChecks.checkDirect(ptr);
/*  701: 712 */     if (event_wait_list != null) {
/*  702: 713 */       BufferChecks.checkDirect(event_wait_list);
/*  703:     */     }
/*  704: 714 */     if (event != null) {
/*  705: 715 */       BufferChecks.checkBuffer(event, 1);
/*  706:     */     }
/*  707: 716 */     int __result = nclEnqueueReadBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_read, offset, ptr.remaining() << 1, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  708: 717 */     if (__result == 0) {
/*  709: 717 */       command_queue.registerCLEvent(event);
/*  710:     */     }
/*  711: 718 */     return __result;
/*  712:     */   }
/*  713:     */   
/*  714:     */   static native int nclEnqueueReadBuffer(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, long paramLong7, long paramLong8);
/*  715:     */   
/*  716:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  717:     */   {
/*  718: 723 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  719: 724 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  720: 725 */     BufferChecks.checkDirect(ptr);
/*  721: 726 */     if (event_wait_list != null) {
/*  722: 727 */       BufferChecks.checkDirect(event_wait_list);
/*  723:     */     }
/*  724: 728 */     if (event != null) {
/*  725: 729 */       BufferChecks.checkBuffer(event, 1);
/*  726:     */     }
/*  727: 730 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining(), MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  728: 731 */     if (__result == 0) {
/*  729: 731 */       command_queue.registerCLEvent(event);
/*  730:     */     }
/*  731: 732 */     return __result;
/*  732:     */   }
/*  733:     */   
/*  734:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, DoubleBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  735:     */   {
/*  736: 735 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  737: 736 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  738: 737 */     BufferChecks.checkDirect(ptr);
/*  739: 738 */     if (event_wait_list != null) {
/*  740: 739 */       BufferChecks.checkDirect(event_wait_list);
/*  741:     */     }
/*  742: 740 */     if (event != null) {
/*  743: 741 */       BufferChecks.checkBuffer(event, 1);
/*  744:     */     }
/*  745: 742 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining() << 3, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  746: 743 */     if (__result == 0) {
/*  747: 743 */       command_queue.registerCLEvent(event);
/*  748:     */     }
/*  749: 744 */     return __result;
/*  750:     */   }
/*  751:     */   
/*  752:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  753:     */   {
/*  754: 747 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  755: 748 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  756: 749 */     BufferChecks.checkDirect(ptr);
/*  757: 750 */     if (event_wait_list != null) {
/*  758: 751 */       BufferChecks.checkDirect(event_wait_list);
/*  759:     */     }
/*  760: 752 */     if (event != null) {
/*  761: 753 */       BufferChecks.checkBuffer(event, 1);
/*  762:     */     }
/*  763: 754 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining() << 2, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  764: 755 */     if (__result == 0) {
/*  765: 755 */       command_queue.registerCLEvent(event);
/*  766:     */     }
/*  767: 756 */     return __result;
/*  768:     */   }
/*  769:     */   
/*  770:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  771:     */   {
/*  772: 759 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  773: 760 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  774: 761 */     BufferChecks.checkDirect(ptr);
/*  775: 762 */     if (event_wait_list != null) {
/*  776: 763 */       BufferChecks.checkDirect(event_wait_list);
/*  777:     */     }
/*  778: 764 */     if (event != null) {
/*  779: 765 */       BufferChecks.checkBuffer(event, 1);
/*  780:     */     }
/*  781: 766 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining() << 2, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  782: 767 */     if (__result == 0) {
/*  783: 767 */       command_queue.registerCLEvent(event);
/*  784:     */     }
/*  785: 768 */     return __result;
/*  786:     */   }
/*  787:     */   
/*  788:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, LongBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  789:     */   {
/*  790: 771 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  791: 772 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  792: 773 */     BufferChecks.checkDirect(ptr);
/*  793: 774 */     if (event_wait_list != null) {
/*  794: 775 */       BufferChecks.checkDirect(event_wait_list);
/*  795:     */     }
/*  796: 776 */     if (event != null) {
/*  797: 777 */       BufferChecks.checkBuffer(event, 1);
/*  798:     */     }
/*  799: 778 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining() << 3, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  800: 779 */     if (__result == 0) {
/*  801: 779 */       command_queue.registerCLEvent(event);
/*  802:     */     }
/*  803: 780 */     return __result;
/*  804:     */   }
/*  805:     */   
/*  806:     */   public static int clEnqueueWriteBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_write, long offset, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/*  807:     */   {
/*  808: 783 */     long function_pointer = CLCapabilities.clEnqueueWriteBuffer;
/*  809: 784 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  810: 785 */     BufferChecks.checkDirect(ptr);
/*  811: 786 */     if (event_wait_list != null) {
/*  812: 787 */       BufferChecks.checkDirect(event_wait_list);
/*  813:     */     }
/*  814: 788 */     if (event != null) {
/*  815: 789 */       BufferChecks.checkBuffer(event, 1);
/*  816:     */     }
/*  817: 790 */     int __result = nclEnqueueWriteBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_write, offset, ptr.remaining() << 1, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  818: 791 */     if (__result == 0) {
/*  819: 791 */       command_queue.registerCLEvent(event);
/*  820:     */     }
/*  821: 792 */     return __result;
/*  822:     */   }
/*  823:     */   
/*  824:     */   static native int nclEnqueueWriteBuffer(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, long paramLong7, long paramLong8);
/*  825:     */   
/*  826:     */   public static int clEnqueueCopyBuffer(CLCommandQueue command_queue, CLMem src_buffer, CLMem dst_buffer, long src_offset, long dst_offset, long size, PointerBuffer event_wait_list, PointerBuffer event)
/*  827:     */   {
/*  828: 797 */     long function_pointer = CLCapabilities.clEnqueueCopyBuffer;
/*  829: 798 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  830: 799 */     if (event_wait_list != null) {
/*  831: 800 */       BufferChecks.checkDirect(event_wait_list);
/*  832:     */     }
/*  833: 801 */     if (event != null) {
/*  834: 802 */       BufferChecks.checkBuffer(event, 1);
/*  835:     */     }
/*  836: 803 */     int __result = nclEnqueueCopyBuffer(command_queue.getPointer(), src_buffer.getPointer(), dst_buffer.getPointer(), src_offset, dst_offset, size, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/*  837: 804 */     if (__result == 0) {
/*  838: 804 */       command_queue.registerCLEvent(event);
/*  839:     */     }
/*  840: 805 */     return __result;
/*  841:     */   }
/*  842:     */   
/*  843:     */   static native int nclEnqueueCopyBuffer(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt, long paramLong7, long paramLong8, long paramLong9);
/*  844:     */   
/*  845:     */   public static ByteBuffer clEnqueueMapBuffer(CLCommandQueue command_queue, CLMem buffer, int blocking_map, long map_flags, long offset, long size, PointerBuffer event_wait_list, PointerBuffer event, IntBuffer errcode_ret)
/*  846:     */   {
/*  847: 810 */     long function_pointer = CLCapabilities.clEnqueueMapBuffer;
/*  848: 811 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  849: 812 */     if (event_wait_list != null) {
/*  850: 813 */       BufferChecks.checkDirect(event_wait_list);
/*  851:     */     }
/*  852: 814 */     if (event != null) {
/*  853: 815 */       BufferChecks.checkBuffer(event, 1);
/*  854:     */     }
/*  855: 816 */     if (errcode_ret != null) {
/*  856: 817 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  857:     */     }
/*  858: 818 */     ByteBuffer __result = nclEnqueueMapBuffer(command_queue.getPointer(), buffer.getPointer(), blocking_map, map_flags, offset, size, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), MemoryUtil.getAddressSafe(errcode_ret), size, function_pointer);
/*  859: 819 */     if (__result != null) {
/*  860: 819 */       command_queue.registerCLEvent(event);
/*  861:     */     }
/*  862: 820 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/*  863:     */   }
/*  864:     */   
/*  865:     */   static native ByteBuffer nclEnqueueMapBuffer(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10);
/*  866:     */   
/*  867:     */   public static CLMem clCreateImage2D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_row_pitch, ByteBuffer host_ptr, IntBuffer errcode_ret)
/*  868:     */   {
/*  869: 825 */     long function_pointer = CLCapabilities.clCreateImage2D;
/*  870: 826 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  871: 827 */     BufferChecks.checkBuffer(image_format, 8);
/*  872: 828 */     if (host_ptr != null) {
/*  873: 829 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage2DSize(image_format, image_width, image_height, image_row_pitch));
/*  874:     */     }
/*  875: 830 */     if (errcode_ret != null) {
/*  876: 831 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  877:     */     }
/*  878: 832 */     CLMem __result = new CLMem(nclCreateImage2D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_row_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  879: 833 */     return __result;
/*  880:     */   }
/*  881:     */   
/*  882:     */   public static CLMem clCreateImage2D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_row_pitch, FloatBuffer host_ptr, IntBuffer errcode_ret)
/*  883:     */   {
/*  884: 836 */     long function_pointer = CLCapabilities.clCreateImage2D;
/*  885: 837 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  886: 838 */     BufferChecks.checkBuffer(image_format, 8);
/*  887: 839 */     if (host_ptr != null) {
/*  888: 840 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage2DSize(image_format, image_width, image_height, image_row_pitch));
/*  889:     */     }
/*  890: 841 */     if (errcode_ret != null) {
/*  891: 842 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  892:     */     }
/*  893: 843 */     CLMem __result = new CLMem(nclCreateImage2D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_row_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  894: 844 */     return __result;
/*  895:     */   }
/*  896:     */   
/*  897:     */   public static CLMem clCreateImage2D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_row_pitch, IntBuffer host_ptr, IntBuffer errcode_ret)
/*  898:     */   {
/*  899: 847 */     long function_pointer = CLCapabilities.clCreateImage2D;
/*  900: 848 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  901: 849 */     BufferChecks.checkBuffer(image_format, 8);
/*  902: 850 */     if (host_ptr != null) {
/*  903: 851 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage2DSize(image_format, image_width, image_height, image_row_pitch));
/*  904:     */     }
/*  905: 852 */     if (errcode_ret != null) {
/*  906: 853 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  907:     */     }
/*  908: 854 */     CLMem __result = new CLMem(nclCreateImage2D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_row_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  909: 855 */     return __result;
/*  910:     */   }
/*  911:     */   
/*  912:     */   public static CLMem clCreateImage2D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_row_pitch, ShortBuffer host_ptr, IntBuffer errcode_ret)
/*  913:     */   {
/*  914: 858 */     long function_pointer = CLCapabilities.clCreateImage2D;
/*  915: 859 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  916: 860 */     BufferChecks.checkBuffer(image_format, 8);
/*  917: 861 */     if (host_ptr != null) {
/*  918: 862 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage2DSize(image_format, image_width, image_height, image_row_pitch));
/*  919:     */     }
/*  920: 863 */     if (errcode_ret != null) {
/*  921: 864 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  922:     */     }
/*  923: 865 */     CLMem __result = new CLMem(nclCreateImage2D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_row_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  924: 866 */     return __result;
/*  925:     */   }
/*  926:     */   
/*  927:     */   static native long nclCreateImage2D(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9);
/*  928:     */   
/*  929:     */   public static CLMem clCreateImage3D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, ByteBuffer host_ptr, IntBuffer errcode_ret)
/*  930:     */   {
/*  931: 871 */     long function_pointer = CLCapabilities.clCreateImage3D;
/*  932: 872 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  933: 873 */     BufferChecks.checkBuffer(image_format, 8);
/*  934: 874 */     if (host_ptr != null) {
/*  935: 875 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage3DSize(image_format, image_width, image_height, image_height, image_row_pitch, image_slice_pitch));
/*  936:     */     }
/*  937: 876 */     if (errcode_ret != null) {
/*  938: 877 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  939:     */     }
/*  940: 878 */     CLMem __result = new CLMem(nclCreateImage3D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  941: 879 */     return __result;
/*  942:     */   }
/*  943:     */   
/*  944:     */   public static CLMem clCreateImage3D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, FloatBuffer host_ptr, IntBuffer errcode_ret)
/*  945:     */   {
/*  946: 882 */     long function_pointer = CLCapabilities.clCreateImage3D;
/*  947: 883 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  948: 884 */     BufferChecks.checkBuffer(image_format, 8);
/*  949: 885 */     if (host_ptr != null) {
/*  950: 886 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage3DSize(image_format, image_width, image_height, image_height, image_row_pitch, image_slice_pitch));
/*  951:     */     }
/*  952: 887 */     if (errcode_ret != null) {
/*  953: 888 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  954:     */     }
/*  955: 889 */     CLMem __result = new CLMem(nclCreateImage3D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  956: 890 */     return __result;
/*  957:     */   }
/*  958:     */   
/*  959:     */   public static CLMem clCreateImage3D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, IntBuffer host_ptr, IntBuffer errcode_ret)
/*  960:     */   {
/*  961: 893 */     long function_pointer = CLCapabilities.clCreateImage3D;
/*  962: 894 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  963: 895 */     BufferChecks.checkBuffer(image_format, 8);
/*  964: 896 */     if (host_ptr != null) {
/*  965: 897 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage3DSize(image_format, image_width, image_height, image_height, image_row_pitch, image_slice_pitch));
/*  966:     */     }
/*  967: 898 */     if (errcode_ret != null) {
/*  968: 899 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  969:     */     }
/*  970: 900 */     CLMem __result = new CLMem(nclCreateImage3D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  971: 901 */     return __result;
/*  972:     */   }
/*  973:     */   
/*  974:     */   public static CLMem clCreateImage3D(CLContext context, long flags, ByteBuffer image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, ShortBuffer host_ptr, IntBuffer errcode_ret)
/*  975:     */   {
/*  976: 904 */     long function_pointer = CLCapabilities.clCreateImage3D;
/*  977: 905 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  978: 906 */     BufferChecks.checkBuffer(image_format, 8);
/*  979: 907 */     if (host_ptr != null) {
/*  980: 908 */       BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage3DSize(image_format, image_width, image_height, image_height, image_row_pitch, image_slice_pitch));
/*  981:     */     }
/*  982: 909 */     if (errcode_ret != null) {
/*  983: 910 */       BufferChecks.checkBuffer(errcode_ret, 1);
/*  984:     */     }
/*  985: 911 */     CLMem __result = new CLMem(nclCreateImage3D(context.getPointer(), flags, MemoryUtil.getAddress(image_format), image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, MemoryUtil.getAddressSafe(host_ptr), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/*  986: 912 */     return __result;
/*  987:     */   }
/*  988:     */   
/*  989:     */   static native long nclCreateImage3D(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10, long paramLong11);
/*  990:     */   
/*  991:     */   public static int clGetSupportedImageFormats(CLContext context, long flags, int image_type, ByteBuffer image_formats, IntBuffer num_image_formats)
/*  992:     */   {
/*  993: 917 */     long function_pointer = CLCapabilities.clGetSupportedImageFormats;
/*  994: 918 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  995: 919 */     if (image_formats != null) {
/*  996: 920 */       BufferChecks.checkDirect(image_formats);
/*  997:     */     }
/*  998: 921 */     if (num_image_formats != null) {
/*  999: 922 */       BufferChecks.checkBuffer(num_image_formats, 1);
/* 1000:     */     }
/* 1001: 923 */     int __result = nclGetSupportedImageFormats(context.getPointer(), flags, image_type, (image_formats == null ? 0 : image_formats.remaining()) / 8, MemoryUtil.getAddressSafe(image_formats), MemoryUtil.getAddressSafe(num_image_formats), function_pointer);
/* 1002: 924 */     return __result;
/* 1003:     */   }
/* 1004:     */   
/* 1005:     */   static native int nclGetSupportedImageFormats(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3, long paramLong4, long paramLong5);
/* 1006:     */   
/* 1007:     */   public static int clEnqueueReadImage(CLCommandQueue command_queue, CLMem image, int blocking_read, PointerBuffer origin, PointerBuffer region, long row_pitch, long slice_pitch, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1008:     */   {
/* 1009: 929 */     long function_pointer = CLCapabilities.clEnqueueReadImage;
/* 1010: 930 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1011: 931 */     BufferChecks.checkBuffer(origin, 3);
/* 1012: 932 */     BufferChecks.checkBuffer(region, 3);
/* 1013: 933 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, row_pitch, slice_pitch));
/* 1014: 934 */     if (event_wait_list != null) {
/* 1015: 935 */       BufferChecks.checkDirect(event_wait_list);
/* 1016:     */     }
/* 1017: 936 */     if (event != null) {
/* 1018: 937 */       BufferChecks.checkBuffer(event, 1);
/* 1019:     */     }
/* 1020: 938 */     int __result = nclEnqueueReadImage(command_queue.getPointer(), image.getPointer(), blocking_read, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), row_pitch, slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1021: 939 */     if (__result == 0) {
/* 1022: 939 */       command_queue.registerCLEvent(event);
/* 1023:     */     }
/* 1024: 940 */     return __result;
/* 1025:     */   }
/* 1026:     */   
/* 1027:     */   public static int clEnqueueReadImage(CLCommandQueue command_queue, CLMem image, int blocking_read, PointerBuffer origin, PointerBuffer region, long row_pitch, long slice_pitch, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1028:     */   {
/* 1029: 943 */     long function_pointer = CLCapabilities.clEnqueueReadImage;
/* 1030: 944 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1031: 945 */     BufferChecks.checkBuffer(origin, 3);
/* 1032: 946 */     BufferChecks.checkBuffer(region, 3);
/* 1033: 947 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, row_pitch, slice_pitch));
/* 1034: 948 */     if (event_wait_list != null) {
/* 1035: 949 */       BufferChecks.checkDirect(event_wait_list);
/* 1036:     */     }
/* 1037: 950 */     if (event != null) {
/* 1038: 951 */       BufferChecks.checkBuffer(event, 1);
/* 1039:     */     }
/* 1040: 952 */     int __result = nclEnqueueReadImage(command_queue.getPointer(), image.getPointer(), blocking_read, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), row_pitch, slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1041: 953 */     if (__result == 0) {
/* 1042: 953 */       command_queue.registerCLEvent(event);
/* 1043:     */     }
/* 1044: 954 */     return __result;
/* 1045:     */   }
/* 1046:     */   
/* 1047:     */   public static int clEnqueueReadImage(CLCommandQueue command_queue, CLMem image, int blocking_read, PointerBuffer origin, PointerBuffer region, long row_pitch, long slice_pitch, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1048:     */   {
/* 1049: 957 */     long function_pointer = CLCapabilities.clEnqueueReadImage;
/* 1050: 958 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1051: 959 */     BufferChecks.checkBuffer(origin, 3);
/* 1052: 960 */     BufferChecks.checkBuffer(region, 3);
/* 1053: 961 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, row_pitch, slice_pitch));
/* 1054: 962 */     if (event_wait_list != null) {
/* 1055: 963 */       BufferChecks.checkDirect(event_wait_list);
/* 1056:     */     }
/* 1057: 964 */     if (event != null) {
/* 1058: 965 */       BufferChecks.checkBuffer(event, 1);
/* 1059:     */     }
/* 1060: 966 */     int __result = nclEnqueueReadImage(command_queue.getPointer(), image.getPointer(), blocking_read, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), row_pitch, slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1061: 967 */     if (__result == 0) {
/* 1062: 967 */       command_queue.registerCLEvent(event);
/* 1063:     */     }
/* 1064: 968 */     return __result;
/* 1065:     */   }
/* 1066:     */   
/* 1067:     */   public static int clEnqueueReadImage(CLCommandQueue command_queue, CLMem image, int blocking_read, PointerBuffer origin, PointerBuffer region, long row_pitch, long slice_pitch, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1068:     */   {
/* 1069: 971 */     long function_pointer = CLCapabilities.clEnqueueReadImage;
/* 1070: 972 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1071: 973 */     BufferChecks.checkBuffer(origin, 3);
/* 1072: 974 */     BufferChecks.checkBuffer(region, 3);
/* 1073: 975 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, row_pitch, slice_pitch));
/* 1074: 976 */     if (event_wait_list != null) {
/* 1075: 977 */       BufferChecks.checkDirect(event_wait_list);
/* 1076:     */     }
/* 1077: 978 */     if (event != null) {
/* 1078: 979 */       BufferChecks.checkBuffer(event, 1);
/* 1079:     */     }
/* 1080: 980 */     int __result = nclEnqueueReadImage(command_queue.getPointer(), image.getPointer(), blocking_read, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), row_pitch, slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1081: 981 */     if (__result == 0) {
/* 1082: 981 */       command_queue.registerCLEvent(event);
/* 1083:     */     }
/* 1084: 982 */     return __result;
/* 1085:     */   }
/* 1086:     */   
/* 1087:     */   static native int nclEnqueueReadImage(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, int paramInt2, long paramLong8, long paramLong9, long paramLong10);
/* 1088:     */   
/* 1089:     */   public static int clEnqueueWriteImage(CLCommandQueue command_queue, CLMem image, int blocking_write, PointerBuffer origin, PointerBuffer region, long input_row_pitch, long input_slice_pitch, ByteBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1090:     */   {
/* 1091: 987 */     long function_pointer = CLCapabilities.clEnqueueWriteImage;
/* 1092: 988 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1093: 989 */     BufferChecks.checkBuffer(origin, 3);
/* 1094: 990 */     BufferChecks.checkBuffer(region, 3);
/* 1095: 991 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, input_row_pitch, input_slice_pitch));
/* 1096: 992 */     if (event_wait_list != null) {
/* 1097: 993 */       BufferChecks.checkDirect(event_wait_list);
/* 1098:     */     }
/* 1099: 994 */     if (event != null) {
/* 1100: 995 */       BufferChecks.checkBuffer(event, 1);
/* 1101:     */     }
/* 1102: 996 */     int __result = nclEnqueueWriteImage(command_queue.getPointer(), image.getPointer(), blocking_write, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), input_row_pitch, input_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1103: 997 */     if (__result == 0) {
/* 1104: 997 */       command_queue.registerCLEvent(event);
/* 1105:     */     }
/* 1106: 998 */     return __result;
/* 1107:     */   }
/* 1108:     */   
/* 1109:     */   public static int clEnqueueWriteImage(CLCommandQueue command_queue, CLMem image, int blocking_write, PointerBuffer origin, PointerBuffer region, long input_row_pitch, long input_slice_pitch, FloatBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1110:     */   {
/* 1111:1001 */     long function_pointer = CLCapabilities.clEnqueueWriteImage;
/* 1112:1002 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1113:1003 */     BufferChecks.checkBuffer(origin, 3);
/* 1114:1004 */     BufferChecks.checkBuffer(region, 3);
/* 1115:1005 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, input_row_pitch, input_slice_pitch));
/* 1116:1006 */     if (event_wait_list != null) {
/* 1117:1007 */       BufferChecks.checkDirect(event_wait_list);
/* 1118:     */     }
/* 1119:1008 */     if (event != null) {
/* 1120:1009 */       BufferChecks.checkBuffer(event, 1);
/* 1121:     */     }
/* 1122:1010 */     int __result = nclEnqueueWriteImage(command_queue.getPointer(), image.getPointer(), blocking_write, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), input_row_pitch, input_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1123:1011 */     if (__result == 0) {
/* 1124:1011 */       command_queue.registerCLEvent(event);
/* 1125:     */     }
/* 1126:1012 */     return __result;
/* 1127:     */   }
/* 1128:     */   
/* 1129:     */   public static int clEnqueueWriteImage(CLCommandQueue command_queue, CLMem image, int blocking_write, PointerBuffer origin, PointerBuffer region, long input_row_pitch, long input_slice_pitch, IntBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1130:     */   {
/* 1131:1015 */     long function_pointer = CLCapabilities.clEnqueueWriteImage;
/* 1132:1016 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1133:1017 */     BufferChecks.checkBuffer(origin, 3);
/* 1134:1018 */     BufferChecks.checkBuffer(region, 3);
/* 1135:1019 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, input_row_pitch, input_slice_pitch));
/* 1136:1020 */     if (event_wait_list != null) {
/* 1137:1021 */       BufferChecks.checkDirect(event_wait_list);
/* 1138:     */     }
/* 1139:1022 */     if (event != null) {
/* 1140:1023 */       BufferChecks.checkBuffer(event, 1);
/* 1141:     */     }
/* 1142:1024 */     int __result = nclEnqueueWriteImage(command_queue.getPointer(), image.getPointer(), blocking_write, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), input_row_pitch, input_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1143:1025 */     if (__result == 0) {
/* 1144:1025 */       command_queue.registerCLEvent(event);
/* 1145:     */     }
/* 1146:1026 */     return __result;
/* 1147:     */   }
/* 1148:     */   
/* 1149:     */   public static int clEnqueueWriteImage(CLCommandQueue command_queue, CLMem image, int blocking_write, PointerBuffer origin, PointerBuffer region, long input_row_pitch, long input_slice_pitch, ShortBuffer ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1150:     */   {
/* 1151:1029 */     long function_pointer = CLCapabilities.clEnqueueWriteImage;
/* 1152:1030 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1153:1031 */     BufferChecks.checkBuffer(origin, 3);
/* 1154:1032 */     BufferChecks.checkBuffer(region, 3);
/* 1155:1033 */     BufferChecks.checkBuffer(ptr, CLChecks.calculateImageSize(region, input_row_pitch, input_slice_pitch));
/* 1156:1034 */     if (event_wait_list != null) {
/* 1157:1035 */       BufferChecks.checkDirect(event_wait_list);
/* 1158:     */     }
/* 1159:1036 */     if (event != null) {
/* 1160:1037 */       BufferChecks.checkBuffer(event, 1);
/* 1161:     */     }
/* 1162:1038 */     int __result = nclEnqueueWriteImage(command_queue.getPointer(), image.getPointer(), blocking_write, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), input_row_pitch, input_slice_pitch, MemoryUtil.getAddress(ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1163:1039 */     if (__result == 0) {
/* 1164:1039 */       command_queue.registerCLEvent(event);
/* 1165:     */     }
/* 1166:1040 */     return __result;
/* 1167:     */   }
/* 1168:     */   
/* 1169:     */   static native int nclEnqueueWriteImage(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, int paramInt2, long paramLong8, long paramLong9, long paramLong10);
/* 1170:     */   
/* 1171:     */   public static int clEnqueueCopyImage(CLCommandQueue command_queue, CLMem src_image, CLMem dst_image, PointerBuffer src_origin, PointerBuffer dst_origin, PointerBuffer region, PointerBuffer event_wait_list, PointerBuffer event)
/* 1172:     */   {
/* 1173:1045 */     long function_pointer = CLCapabilities.clEnqueueCopyImage;
/* 1174:1046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1175:1047 */     BufferChecks.checkBuffer(src_origin, 3);
/* 1176:1048 */     BufferChecks.checkBuffer(dst_origin, 3);
/* 1177:1049 */     BufferChecks.checkBuffer(region, 3);
/* 1178:1050 */     if (event_wait_list != null) {
/* 1179:1051 */       BufferChecks.checkDirect(event_wait_list);
/* 1180:     */     }
/* 1181:1052 */     if (event != null) {
/* 1182:1053 */       BufferChecks.checkBuffer(event, 1);
/* 1183:     */     }
/* 1184:1054 */     int __result = nclEnqueueCopyImage(command_queue.getPointer(), src_image.getPointer(), dst_image.getPointer(), MemoryUtil.getAddress(src_origin), MemoryUtil.getAddress(dst_origin), MemoryUtil.getAddress(region), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1185:1055 */     if (__result == 0) {
/* 1186:1055 */       command_queue.registerCLEvent(event);
/* 1187:     */     }
/* 1188:1056 */     return __result;
/* 1189:     */   }
/* 1190:     */   
/* 1191:     */   static native int nclEnqueueCopyImage(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt, long paramLong7, long paramLong8, long paramLong9);
/* 1192:     */   
/* 1193:     */   public static int clEnqueueCopyImageToBuffer(CLCommandQueue command_queue, CLMem src_image, CLMem dst_buffer, PointerBuffer src_origin, PointerBuffer region, long dst_offset, PointerBuffer event_wait_list, PointerBuffer event)
/* 1194:     */   {
/* 1195:1061 */     long function_pointer = CLCapabilities.clEnqueueCopyImageToBuffer;
/* 1196:1062 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1197:1063 */     BufferChecks.checkBuffer(src_origin, 3);
/* 1198:1064 */     BufferChecks.checkBuffer(region, 3);
/* 1199:1065 */     if (event_wait_list != null) {
/* 1200:1066 */       BufferChecks.checkDirect(event_wait_list);
/* 1201:     */     }
/* 1202:1067 */     if (event != null) {
/* 1203:1068 */       BufferChecks.checkBuffer(event, 1);
/* 1204:     */     }
/* 1205:1069 */     int __result = nclEnqueueCopyImageToBuffer(command_queue.getPointer(), src_image.getPointer(), dst_buffer.getPointer(), MemoryUtil.getAddress(src_origin), MemoryUtil.getAddress(region), dst_offset, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1206:1070 */     if (__result == 0) {
/* 1207:1070 */       command_queue.registerCLEvent(event);
/* 1208:     */     }
/* 1209:1071 */     return __result;
/* 1210:     */   }
/* 1211:     */   
/* 1212:     */   static native int nclEnqueueCopyImageToBuffer(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt, long paramLong7, long paramLong8, long paramLong9);
/* 1213:     */   
/* 1214:     */   public static int clEnqueueCopyBufferToImage(CLCommandQueue command_queue, CLMem src_buffer, CLMem dst_image, long src_offset, PointerBuffer dst_origin, PointerBuffer region, PointerBuffer event_wait_list, PointerBuffer event)
/* 1215:     */   {
/* 1216:1076 */     long function_pointer = CLCapabilities.clEnqueueCopyBufferToImage;
/* 1217:1077 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1218:1078 */     BufferChecks.checkBuffer(dst_origin, 3);
/* 1219:1079 */     BufferChecks.checkBuffer(region, 3);
/* 1220:1080 */     if (event_wait_list != null) {
/* 1221:1081 */       BufferChecks.checkDirect(event_wait_list);
/* 1222:     */     }
/* 1223:1082 */     if (event != null) {
/* 1224:1083 */       BufferChecks.checkBuffer(event, 1);
/* 1225:     */     }
/* 1226:1084 */     int __result = nclEnqueueCopyBufferToImage(command_queue.getPointer(), src_buffer.getPointer(), dst_image.getPointer(), src_offset, MemoryUtil.getAddress(dst_origin), MemoryUtil.getAddress(region), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1227:1085 */     if (__result == 0) {
/* 1228:1085 */       command_queue.registerCLEvent(event);
/* 1229:     */     }
/* 1230:1086 */     return __result;
/* 1231:     */   }
/* 1232:     */   
/* 1233:     */   static native int nclEnqueueCopyBufferToImage(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt, long paramLong7, long paramLong8, long paramLong9);
/* 1234:     */   
/* 1235:     */   public static ByteBuffer clEnqueueMapImage(CLCommandQueue command_queue, CLMem image, int blocking_map, long map_flags, PointerBuffer origin, PointerBuffer region, PointerBuffer image_row_pitch, PointerBuffer image_slice_pitch, PointerBuffer event_wait_list, PointerBuffer event, IntBuffer errcode_ret)
/* 1236:     */   {
/* 1237:1091 */     long function_pointer = CLCapabilities.clEnqueueMapImage;
/* 1238:1092 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1239:1093 */     BufferChecks.checkBuffer(origin, 3);
/* 1240:1094 */     BufferChecks.checkBuffer(region, 3);
/* 1241:1095 */     BufferChecks.checkBuffer(image_row_pitch, 1);
/* 1242:1096 */     if (image_slice_pitch != null) {
/* 1243:1097 */       BufferChecks.checkBuffer(image_slice_pitch, 1);
/* 1244:     */     }
/* 1245:1098 */     if (event_wait_list != null) {
/* 1246:1099 */       BufferChecks.checkDirect(event_wait_list);
/* 1247:     */     }
/* 1248:1100 */     if (event != null) {
/* 1249:1101 */       BufferChecks.checkBuffer(event, 1);
/* 1250:     */     }
/* 1251:1102 */     if (errcode_ret != null) {
/* 1252:1103 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1253:     */     }
/* 1254:1104 */     ByteBuffer __result = nclEnqueueMapImage(command_queue.getPointer(), image.getPointer(), blocking_map, map_flags, MemoryUtil.getAddress(origin), MemoryUtil.getAddress(region), MemoryUtil.getAddress(image_row_pitch), MemoryUtil.getAddressSafe(image_slice_pitch), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), MemoryUtil.getAddressSafe(errcode_ret), function_pointer);
/* 1255:1105 */     if (__result != null) {
/* 1256:1105 */       command_queue.registerCLEvent(event);
/* 1257:     */     }
/* 1258:1106 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 1259:     */   }
/* 1260:     */   
/* 1261:     */   static native ByteBuffer nclEnqueueMapImage(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, int paramInt2, long paramLong8, long paramLong9, long paramLong10, long paramLong11);
/* 1262:     */   
/* 1263:     */   public static int clGetImageInfo(CLMem image, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1264:     */   {
/* 1265:1111 */     long function_pointer = CLCapabilities.clGetImageInfo;
/* 1266:1112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1267:1113 */     if (param_value != null) {
/* 1268:1114 */       BufferChecks.checkDirect(param_value);
/* 1269:     */     }
/* 1270:1115 */     if (param_value_size_ret != null) {
/* 1271:1116 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1272:     */     }
/* 1273:1117 */     int __result = nclGetImageInfo(image.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1274:1118 */     return __result;
/* 1275:     */   }
/* 1276:     */   
/* 1277:     */   static native int nclGetImageInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1278:     */   
/* 1279:     */   public static int clRetainMemObject(CLMem memobj)
/* 1280:     */   {
/* 1281:1123 */     long function_pointer = CLCapabilities.clRetainMemObject;
/* 1282:1124 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1283:1125 */     int __result = nclRetainMemObject(memobj.getPointer(), function_pointer);
/* 1284:1126 */     if (__result == 0) {
/* 1285:1126 */       memobj.retain();
/* 1286:     */     }
/* 1287:1127 */     return __result;
/* 1288:     */   }
/* 1289:     */   
/* 1290:     */   static native int nclRetainMemObject(long paramLong1, long paramLong2);
/* 1291:     */   
/* 1292:     */   public static int clReleaseMemObject(CLMem memobj)
/* 1293:     */   {
/* 1294:1132 */     long function_pointer = CLCapabilities.clReleaseMemObject;
/* 1295:1133 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1296:1134 */     int __result = nclReleaseMemObject(memobj.getPointer(), function_pointer);
/* 1297:1135 */     if (__result == 0) {
/* 1298:1135 */       memobj.release();
/* 1299:     */     }
/* 1300:1136 */     return __result;
/* 1301:     */   }
/* 1302:     */   
/* 1303:     */   static native int nclReleaseMemObject(long paramLong1, long paramLong2);
/* 1304:     */   
/* 1305:     */   public static int clEnqueueUnmapMemObject(CLCommandQueue command_queue, CLMem memobj, ByteBuffer mapped_ptr, PointerBuffer event_wait_list, PointerBuffer event)
/* 1306:     */   {
/* 1307:1141 */     long function_pointer = CLCapabilities.clEnqueueUnmapMemObject;
/* 1308:1142 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1309:1143 */     BufferChecks.checkDirect(mapped_ptr);
/* 1310:1144 */     if (event_wait_list != null) {
/* 1311:1145 */       BufferChecks.checkDirect(event_wait_list);
/* 1312:     */     }
/* 1313:1146 */     if (event != null) {
/* 1314:1147 */       BufferChecks.checkBuffer(event, 1);
/* 1315:     */     }
/* 1316:1148 */     int __result = nclEnqueueUnmapMemObject(command_queue.getPointer(), memobj.getPointer(), MemoryUtil.getAddress(mapped_ptr), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1317:1149 */     if (__result == 0) {
/* 1318:1149 */       command_queue.registerCLEvent(event);
/* 1319:     */     }
/* 1320:1150 */     return __result;
/* 1321:     */   }
/* 1322:     */   
/* 1323:     */   static native int nclEnqueueUnmapMemObject(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5, long paramLong6);
/* 1324:     */   
/* 1325:     */   public static int clGetMemObjectInfo(CLMem memobj, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1326:     */   {
/* 1327:1155 */     long function_pointer = CLCapabilities.clGetMemObjectInfo;
/* 1328:1156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1329:1157 */     if (param_value != null) {
/* 1330:1158 */       BufferChecks.checkDirect(param_value);
/* 1331:     */     }
/* 1332:1159 */     if (param_value_size_ret != null) {
/* 1333:1160 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1334:     */     }
/* 1335:1161 */     int __result = nclGetMemObjectInfo(memobj.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1336:1162 */     return __result;
/* 1337:     */   }
/* 1338:     */   
/* 1339:     */   static native int nclGetMemObjectInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1340:     */   
/* 1341:     */   public static CLSampler clCreateSampler(CLContext context, int normalized_coords, int addressing_mode, int filter_mode, IntBuffer errcode_ret)
/* 1342:     */   {
/* 1343:1167 */     long function_pointer = CLCapabilities.clCreateSampler;
/* 1344:1168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1345:1169 */     if (errcode_ret != null) {
/* 1346:1170 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1347:     */     }
/* 1348:1171 */     CLSampler __result = new CLSampler(nclCreateSampler(context.getPointer(), normalized_coords, addressing_mode, filter_mode, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1349:1172 */     return __result;
/* 1350:     */   }
/* 1351:     */   
/* 1352:     */   static native long nclCreateSampler(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, long paramLong3);
/* 1353:     */   
/* 1354:     */   public static int clRetainSampler(CLSampler sampler)
/* 1355:     */   {
/* 1356:1177 */     long function_pointer = CLCapabilities.clRetainSampler;
/* 1357:1178 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1358:1179 */     int __result = nclRetainSampler(sampler.getPointer(), function_pointer);
/* 1359:1180 */     if (__result == 0) {
/* 1360:1180 */       sampler.retain();
/* 1361:     */     }
/* 1362:1181 */     return __result;
/* 1363:     */   }
/* 1364:     */   
/* 1365:     */   static native int nclRetainSampler(long paramLong1, long paramLong2);
/* 1366:     */   
/* 1367:     */   public static int clReleaseSampler(CLSampler sampler)
/* 1368:     */   {
/* 1369:1186 */     long function_pointer = CLCapabilities.clReleaseSampler;
/* 1370:1187 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1371:1188 */     int __result = nclReleaseSampler(sampler.getPointer(), function_pointer);
/* 1372:1189 */     if (__result == 0) {
/* 1373:1189 */       sampler.release();
/* 1374:     */     }
/* 1375:1190 */     return __result;
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   static native int nclReleaseSampler(long paramLong1, long paramLong2);
/* 1379:     */   
/* 1380:     */   public static int clGetSamplerInfo(CLSampler sampler, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1381:     */   {
/* 1382:1195 */     long function_pointer = CLCapabilities.clGetSamplerInfo;
/* 1383:1196 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1384:1197 */     if (param_value != null) {
/* 1385:1198 */       BufferChecks.checkDirect(param_value);
/* 1386:     */     }
/* 1387:1199 */     if (param_value_size_ret != null) {
/* 1388:1200 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1389:     */     }
/* 1390:1201 */     int __result = nclGetSamplerInfo(sampler.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1391:1202 */     return __result;
/* 1392:     */   }
/* 1393:     */   
/* 1394:     */   static native int nclGetSamplerInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1395:     */   
/* 1396:     */   public static CLProgram clCreateProgramWithSource(CLContext context, ByteBuffer string, IntBuffer errcode_ret)
/* 1397:     */   {
/* 1398:1207 */     long function_pointer = CLCapabilities.clCreateProgramWithSource;
/* 1399:1208 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1400:1209 */     BufferChecks.checkDirect(string);
/* 1401:1210 */     if (errcode_ret != null) {
/* 1402:1211 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1403:     */     }
/* 1404:1212 */     CLProgram __result = new CLProgram(nclCreateProgramWithSource(context.getPointer(), 1, MemoryUtil.getAddress(string), string.remaining(), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1405:1213 */     return __result;
/* 1406:     */   }
/* 1407:     */   
/* 1408:     */   static native long nclCreateProgramWithSource(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1409:     */   
/* 1410:     */   public static CLProgram clCreateProgramWithSource(CLContext context, ByteBuffer strings, PointerBuffer lengths, IntBuffer errcode_ret)
/* 1411:     */   {
/* 1412:1219 */     long function_pointer = CLCapabilities.clCreateProgramWithSource;
/* 1413:1220 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1414:1221 */     BufferChecks.checkBuffer(strings, APIUtil.getSize(lengths));
/* 1415:1222 */     BufferChecks.checkBuffer(lengths, 1);
/* 1416:1223 */     if (errcode_ret != null) {
/* 1417:1224 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1418:     */     }
/* 1419:1225 */     CLProgram __result = new CLProgram(nclCreateProgramWithSource2(context.getPointer(), lengths.remaining(), MemoryUtil.getAddress(strings), MemoryUtil.getAddress(lengths), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1420:1226 */     return __result;
/* 1421:     */   }
/* 1422:     */   
/* 1423:     */   static native long nclCreateProgramWithSource2(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1424:     */   
/* 1425:     */   public static CLProgram clCreateProgramWithSource(CLContext context, ByteBuffer[] strings, IntBuffer errcode_ret)
/* 1426:     */   {
/* 1427:1232 */     long function_pointer = CLCapabilities.clCreateProgramWithSource;
/* 1428:1233 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1429:1234 */     BufferChecks.checkArray(strings, 1);
/* 1430:1235 */     if (errcode_ret != null) {
/* 1431:1236 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1432:     */     }
/* 1433:1237 */     CLProgram __result = new CLProgram(nclCreateProgramWithSource3(context.getPointer(), strings.length, strings, APIUtil.getLengths(strings), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1434:1238 */     return __result;
/* 1435:     */   }
/* 1436:     */   
/* 1437:     */   static native long nclCreateProgramWithSource3(long paramLong1, int paramInt, ByteBuffer[] paramArrayOfByteBuffer, long paramLong2, long paramLong3, long paramLong4);
/* 1438:     */   
/* 1439:     */   public static CLProgram clCreateProgramWithSource(CLContext context, CharSequence string, IntBuffer errcode_ret)
/* 1440:     */   {
/* 1441:1244 */     long function_pointer = CLCapabilities.clCreateProgramWithSource;
/* 1442:1245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1443:1246 */     if (errcode_ret != null) {
/* 1444:1247 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1445:     */     }
/* 1446:1248 */     CLProgram __result = new CLProgram(nclCreateProgramWithSource(context.getPointer(), 1, APIUtil.getBuffer(string), string.length(), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1447:1249 */     return __result;
/* 1448:     */   }
/* 1449:     */   
/* 1450:     */   public static CLProgram clCreateProgramWithSource(CLContext context, CharSequence[] strings, IntBuffer errcode_ret)
/* 1451:     */   {
/* 1452:1254 */     long function_pointer = CLCapabilities.clCreateProgramWithSource;
/* 1453:1255 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1454:1256 */     BufferChecks.checkArray(strings);
/* 1455:1257 */     if (errcode_ret != null) {
/* 1456:1258 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1457:     */     }
/* 1458:1259 */     CLProgram __result = new CLProgram(nclCreateProgramWithSource4(context.getPointer(), strings.length, APIUtil.getBuffer(strings), APIUtil.getLengths(strings), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1459:1260 */     return __result;
/* 1460:     */   }
/* 1461:     */   
/* 1462:     */   static native long nclCreateProgramWithSource4(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1463:     */   
/* 1464:     */   public static CLProgram clCreateProgramWithBinary(CLContext context, CLDevice device, ByteBuffer binary, IntBuffer binary_status, IntBuffer errcode_ret)
/* 1465:     */   {
/* 1466:1265 */     long function_pointer = CLCapabilities.clCreateProgramWithBinary;
/* 1467:1266 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1468:1267 */     BufferChecks.checkDirect(binary);
/* 1469:1268 */     BufferChecks.checkBuffer(binary_status, 1);
/* 1470:1269 */     if (errcode_ret != null) {
/* 1471:1270 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1472:     */     }
/* 1473:1271 */     CLProgram __result = new CLProgram(nclCreateProgramWithBinary(context.getPointer(), 1, device.getPointer(), binary.remaining(), MemoryUtil.getAddress(binary), MemoryUtil.getAddress(binary_status), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1474:1272 */     return __result;
/* 1475:     */   }
/* 1476:     */   
/* 1477:     */   static native long nclCreateProgramWithBinary(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/* 1478:     */   
/* 1479:     */   public static CLProgram clCreateProgramWithBinary(CLContext context, PointerBuffer device_list, PointerBuffer lengths, ByteBuffer binaries, IntBuffer binary_status, IntBuffer errcode_ret)
/* 1480:     */   {
/* 1481:1278 */     long function_pointer = CLCapabilities.clCreateProgramWithBinary;
/* 1482:1279 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1483:1280 */     BufferChecks.checkBuffer(device_list, 1);
/* 1484:1281 */     BufferChecks.checkBuffer(lengths, device_list.remaining());
/* 1485:1282 */     BufferChecks.checkBuffer(binaries, APIUtil.getSize(lengths));
/* 1486:1283 */     BufferChecks.checkBuffer(binary_status, device_list.remaining());
/* 1487:1284 */     if (errcode_ret != null) {
/* 1488:1285 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1489:     */     }
/* 1490:1286 */     CLProgram __result = new CLProgram(nclCreateProgramWithBinary2(context.getPointer(), device_list.remaining(), MemoryUtil.getAddress(device_list), MemoryUtil.getAddress(lengths), MemoryUtil.getAddress(binaries), MemoryUtil.getAddress(binary_status), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1491:1287 */     return __result;
/* 1492:     */   }
/* 1493:     */   
/* 1494:     */   static native long nclCreateProgramWithBinary2(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/* 1495:     */   
/* 1496:     */   public static CLProgram clCreateProgramWithBinary(CLContext context, PointerBuffer device_list, ByteBuffer[] binaries, IntBuffer binary_status, IntBuffer errcode_ret)
/* 1497:     */   {
/* 1498:1293 */     long function_pointer = CLCapabilities.clCreateProgramWithBinary;
/* 1499:1294 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1500:1295 */     BufferChecks.checkBuffer(device_list, binaries.length);
/* 1501:1296 */     BufferChecks.checkArray(binaries, 1);
/* 1502:1297 */     BufferChecks.checkBuffer(binary_status, binaries.length);
/* 1503:1298 */     if (errcode_ret != null) {
/* 1504:1299 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1505:     */     }
/* 1506:1300 */     CLProgram __result = new CLProgram(nclCreateProgramWithBinary3(context.getPointer(), binaries.length, MemoryUtil.getAddress(device_list), APIUtil.getLengths(binaries), binaries, MemoryUtil.getAddress(binary_status), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 1507:1301 */     return __result;
/* 1508:     */   }
/* 1509:     */   
/* 1510:     */   static native long nclCreateProgramWithBinary3(long paramLong1, int paramInt, long paramLong2, long paramLong3, ByteBuffer[] paramArrayOfByteBuffer, long paramLong4, long paramLong5, long paramLong6);
/* 1511:     */   
/* 1512:     */   public static int clRetainProgram(CLProgram program)
/* 1513:     */   {
/* 1514:1306 */     long function_pointer = CLCapabilities.clRetainProgram;
/* 1515:1307 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1516:1308 */     int __result = nclRetainProgram(program.getPointer(), function_pointer);
/* 1517:1309 */     if (__result == 0) {
/* 1518:1309 */       program.retain();
/* 1519:     */     }
/* 1520:1310 */     return __result;
/* 1521:     */   }
/* 1522:     */   
/* 1523:     */   static native int nclRetainProgram(long paramLong1, long paramLong2);
/* 1524:     */   
/* 1525:     */   public static int clReleaseProgram(CLProgram program)
/* 1526:     */   {
/* 1527:1315 */     long function_pointer = CLCapabilities.clReleaseProgram;
/* 1528:1316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1529:1317 */     APIUtil.releaseObjects(program);
/* 1530:1318 */     int __result = nclReleaseProgram(program.getPointer(), function_pointer);
/* 1531:1319 */     if (__result == 0) {
/* 1532:1319 */       program.release();
/* 1533:     */     }
/* 1534:1320 */     return __result;
/* 1535:     */   }
/* 1536:     */   
/* 1537:     */   static native int nclReleaseProgram(long paramLong1, long paramLong2);
/* 1538:     */   
/* 1539:     */   public static int clBuildProgram(CLProgram program, PointerBuffer device_list, ByteBuffer options, CLBuildProgramCallback pfn_notify)
/* 1540:     */   {
/* 1541:1325 */     long function_pointer = CLCapabilities.clBuildProgram;
/* 1542:1326 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1543:1327 */     if (device_list != null) {
/* 1544:1328 */       BufferChecks.checkDirect(device_list);
/* 1545:     */     }
/* 1546:1329 */     BufferChecks.checkDirect(options);
/* 1547:1330 */     BufferChecks.checkNullTerminated(options);
/* 1548:1331 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 1549:1332 */     if (pfn_notify != null) {
/* 1550:1332 */       pfn_notify.setContext((CLContext)program.getParent());
/* 1551:     */     }
/* 1552:1333 */     int __result = 0;
/* 1553:     */     try
/* 1554:     */     {
/* 1555:1335 */       __result = nclBuildProgram(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), MemoryUtil.getAddress(options), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 1556:1336 */       return __result;
/* 1557:     */     }
/* 1558:     */     finally
/* 1559:     */     {
/* 1560:1338 */       CallbackUtil.checkCallback(__result, user_data);
/* 1561:     */     }
/* 1562:     */   }
/* 1563:     */   
/* 1564:     */   static native int nclBuildProgram(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/* 1565:     */   
/* 1566:     */   public static int clBuildProgram(CLProgram program, PointerBuffer device_list, CharSequence options, CLBuildProgramCallback pfn_notify)
/* 1567:     */   {
/* 1568:1345 */     long function_pointer = CLCapabilities.clBuildProgram;
/* 1569:1346 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1570:1347 */     if (device_list != null) {
/* 1571:1348 */       BufferChecks.checkDirect(device_list);
/* 1572:     */     }
/* 1573:1349 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 1574:1350 */     if (pfn_notify != null) {
/* 1575:1350 */       pfn_notify.setContext((CLContext)program.getParent());
/* 1576:     */     }
/* 1577:1351 */     int __result = 0;
/* 1578:     */     try
/* 1579:     */     {
/* 1580:1353 */       __result = nclBuildProgram(program.getPointer(), device_list == null ? 0 : device_list.remaining(), MemoryUtil.getAddressSafe(device_list), APIUtil.getBufferNT(options), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 1581:1354 */       return __result;
/* 1582:     */     }
/* 1583:     */     finally
/* 1584:     */     {
/* 1585:1356 */       CallbackUtil.checkCallback(__result, user_data);
/* 1586:     */     }
/* 1587:     */   }
/* 1588:     */   
/* 1589:     */   public static int clBuildProgram(CLProgram program, CLDevice device, CharSequence options, CLBuildProgramCallback pfn_notify)
/* 1590:     */   {
/* 1591:1362 */     long function_pointer = CLCapabilities.clBuildProgram;
/* 1592:1363 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1593:1364 */     long user_data = CallbackUtil.createGlobalRef(pfn_notify);
/* 1594:1365 */     if (pfn_notify != null) {
/* 1595:1365 */       pfn_notify.setContext((CLContext)program.getParent());
/* 1596:     */     }
/* 1597:1366 */     int __result = 0;
/* 1598:     */     try
/* 1599:     */     {
/* 1600:1368 */       __result = nclBuildProgram(program.getPointer(), 1, APIUtil.getPointer(device), APIUtil.getBufferNT(options), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, function_pointer);
/* 1601:1369 */       return __result;
/* 1602:     */     }
/* 1603:     */     finally
/* 1604:     */     {
/* 1605:1371 */       CallbackUtil.checkCallback(__result, user_data);
/* 1606:     */     }
/* 1607:     */   }
/* 1608:     */   
/* 1609:     */   public static int clUnloadCompiler()
/* 1610:     */   {
/* 1611:1376 */     long function_pointer = CLCapabilities.clUnloadCompiler;
/* 1612:1377 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1613:1378 */     int __result = nclUnloadCompiler(function_pointer);
/* 1614:1379 */     return __result;
/* 1615:     */   }
/* 1616:     */   
/* 1617:     */   static native int nclUnloadCompiler(long paramLong);
/* 1618:     */   
/* 1619:     */   public static int clGetProgramInfo(CLProgram program, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1620:     */   {
/* 1621:1384 */     long function_pointer = CLCapabilities.clGetProgramInfo;
/* 1622:1385 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1623:1386 */     if (param_value != null) {
/* 1624:1387 */       BufferChecks.checkDirect(param_value);
/* 1625:     */     }
/* 1626:1388 */     if (param_value_size_ret != null) {
/* 1627:1389 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1628:     */     }
/* 1629:1390 */     int __result = nclGetProgramInfo(program.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1630:1391 */     return __result;
/* 1631:     */   }
/* 1632:     */   
/* 1633:     */   static native int nclGetProgramInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1634:     */   
/* 1635:     */   public static int clGetProgramInfo(CLProgram program, PointerBuffer sizes, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1636:     */   {
/* 1637:1410 */     long function_pointer = CLCapabilities.clGetProgramInfo;
/* 1638:1411 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1639:1412 */     BufferChecks.checkBuffer(sizes, 1);
/* 1640:1413 */     BufferChecks.checkBuffer(param_value, APIUtil.getSize(sizes));
/* 1641:1414 */     if (param_value_size_ret != null) {
/* 1642:1415 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1643:     */     }
/* 1644:1416 */     int __result = nclGetProgramInfo2(program.getPointer(), 4454, sizes.remainingByte(), MemoryUtil.getAddress(sizes), MemoryUtil.getAddress(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1645:1417 */     return __result;
/* 1646:     */   }
/* 1647:     */   
/* 1648:     */   static native int nclGetProgramInfo2(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/* 1649:     */   
/* 1650:     */   public static int clGetProgramInfo(CLProgram program, ByteBuffer[] param_value, PointerBuffer param_value_size_ret)
/* 1651:     */   {
/* 1652:1436 */     long function_pointer = CLCapabilities.clGetProgramInfo;
/* 1653:1437 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1654:1438 */     BufferChecks.checkArray(param_value);
/* 1655:1439 */     if (param_value_size_ret != null) {
/* 1656:1440 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1657:     */     }
/* 1658:1441 */     int __result = nclGetProgramInfo3(program.getPointer(), 4454, param_value.length * PointerBuffer.getPointerSize(), param_value, MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1659:1442 */     return __result;
/* 1660:     */   }
/* 1661:     */   
/* 1662:     */   static native int nclGetProgramInfo3(long paramLong1, int paramInt, long paramLong2, ByteBuffer[] paramArrayOfByteBuffer, long paramLong3, long paramLong4);
/* 1663:     */   
/* 1664:     */   public static int clGetProgramBuildInfo(CLProgram program, CLDevice device, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1665:     */   {
/* 1666:1447 */     long function_pointer = CLCapabilities.clGetProgramBuildInfo;
/* 1667:1448 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1668:1449 */     if (param_value != null) {
/* 1669:1450 */       BufferChecks.checkDirect(param_value);
/* 1670:     */     }
/* 1671:1451 */     if (param_value_size_ret != null) {
/* 1672:1452 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1673:     */     }
/* 1674:1453 */     int __result = nclGetProgramBuildInfo(program.getPointer(), device.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1675:1454 */     return __result;
/* 1676:     */   }
/* 1677:     */   
/* 1678:     */   static native int nclGetProgramBuildInfo(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/* 1679:     */   
/* 1680:     */   public static CLKernel clCreateKernel(CLProgram program, ByteBuffer kernel_name, IntBuffer errcode_ret)
/* 1681:     */   {
/* 1682:1459 */     long function_pointer = CLCapabilities.clCreateKernel;
/* 1683:1460 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1684:1461 */     BufferChecks.checkDirect(kernel_name);
/* 1685:1462 */     BufferChecks.checkNullTerminated(kernel_name);
/* 1686:1463 */     if (errcode_ret != null) {
/* 1687:1464 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1688:     */     }
/* 1689:1465 */     CLKernel __result = new CLKernel(nclCreateKernel(program.getPointer(), MemoryUtil.getAddress(kernel_name), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), program);
/* 1690:1466 */     return __result;
/* 1691:     */   }
/* 1692:     */   
/* 1693:     */   static native long nclCreateKernel(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 1694:     */   
/* 1695:     */   public static CLKernel clCreateKernel(CLProgram program, CharSequence kernel_name, IntBuffer errcode_ret)
/* 1696:     */   {
/* 1697:1472 */     long function_pointer = CLCapabilities.clCreateKernel;
/* 1698:1473 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1699:1474 */     if (errcode_ret != null) {
/* 1700:1475 */       BufferChecks.checkBuffer(errcode_ret, 1);
/* 1701:     */     }
/* 1702:1476 */     CLKernel __result = new CLKernel(nclCreateKernel(program.getPointer(), APIUtil.getBufferNT(kernel_name), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), program);
/* 1703:1477 */     return __result;
/* 1704:     */   }
/* 1705:     */   
/* 1706:     */   public static int clCreateKernelsInProgram(CLProgram program, PointerBuffer kernels, IntBuffer num_kernels_ret)
/* 1707:     */   {
/* 1708:1481 */     long function_pointer = CLCapabilities.clCreateKernelsInProgram;
/* 1709:1482 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1710:1483 */     if (kernels != null) {
/* 1711:1484 */       BufferChecks.checkDirect(kernels);
/* 1712:     */     }
/* 1713:1485 */     if (num_kernels_ret != null) {
/* 1714:1486 */       BufferChecks.checkBuffer(num_kernels_ret, 1);
/* 1715:     */     }
/* 1716:1487 */     int __result = nclCreateKernelsInProgram(program.getPointer(), kernels == null ? 0 : kernels.remaining(), MemoryUtil.getAddressSafe(kernels), MemoryUtil.getAddressSafe(num_kernels_ret), function_pointer);
/* 1717:1488 */     if ((__result == 0) && (kernels != null)) {
/* 1718:1488 */       program.registerCLKernels(kernels);
/* 1719:     */     }
/* 1720:1489 */     return __result;
/* 1721:     */   }
/* 1722:     */   
/* 1723:     */   static native int nclCreateKernelsInProgram(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/* 1724:     */   
/* 1725:     */   public static int clRetainKernel(CLKernel kernel)
/* 1726:     */   {
/* 1727:1494 */     long function_pointer = CLCapabilities.clRetainKernel;
/* 1728:1495 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1729:1496 */     int __result = nclRetainKernel(kernel.getPointer(), function_pointer);
/* 1730:1497 */     if (__result == 0) {
/* 1731:1497 */       kernel.retain();
/* 1732:     */     }
/* 1733:1498 */     return __result;
/* 1734:     */   }
/* 1735:     */   
/* 1736:     */   static native int nclRetainKernel(long paramLong1, long paramLong2);
/* 1737:     */   
/* 1738:     */   public static int clReleaseKernel(CLKernel kernel)
/* 1739:     */   {
/* 1740:1503 */     long function_pointer = CLCapabilities.clReleaseKernel;
/* 1741:1504 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1742:1505 */     int __result = nclReleaseKernel(kernel.getPointer(), function_pointer);
/* 1743:1506 */     if (__result == 0) {
/* 1744:1506 */       kernel.release();
/* 1745:     */     }
/* 1746:1507 */     return __result;
/* 1747:     */   }
/* 1748:     */   
/* 1749:     */   static native int nclReleaseKernel(long paramLong1, long paramLong2);
/* 1750:     */   
/* 1751:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, long arg_value_arg_size)
/* 1752:     */   {
/* 1753:1512 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1754:1513 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1755:1514 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value_arg_size, 0L, function_pointer);
/* 1756:1515 */     return __result;
/* 1757:     */   }
/* 1758:     */   
/* 1759:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, ByteBuffer arg_value)
/* 1760:     */   {
/* 1761:1518 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1762:1519 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1763:1520 */     BufferChecks.checkDirect(arg_value);
/* 1764:1521 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining(), MemoryUtil.getAddress(arg_value), function_pointer);
/* 1765:1522 */     return __result;
/* 1766:     */   }
/* 1767:     */   
/* 1768:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, DoubleBuffer arg_value)
/* 1769:     */   {
/* 1770:1525 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1771:1526 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1772:1527 */     BufferChecks.checkDirect(arg_value);
/* 1773:1528 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining() << 3, MemoryUtil.getAddress(arg_value), function_pointer);
/* 1774:1529 */     return __result;
/* 1775:     */   }
/* 1776:     */   
/* 1777:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, FloatBuffer arg_value)
/* 1778:     */   {
/* 1779:1532 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1780:1533 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1781:1534 */     BufferChecks.checkDirect(arg_value);
/* 1782:1535 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining() << 2, MemoryUtil.getAddress(arg_value), function_pointer);
/* 1783:1536 */     return __result;
/* 1784:     */   }
/* 1785:     */   
/* 1786:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, IntBuffer arg_value)
/* 1787:     */   {
/* 1788:1539 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1789:1540 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1790:1541 */     BufferChecks.checkDirect(arg_value);
/* 1791:1542 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining() << 2, MemoryUtil.getAddress(arg_value), function_pointer);
/* 1792:1543 */     return __result;
/* 1793:     */   }
/* 1794:     */   
/* 1795:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, LongBuffer arg_value)
/* 1796:     */   {
/* 1797:1546 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1798:1547 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1799:1548 */     BufferChecks.checkDirect(arg_value);
/* 1800:1549 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining() << 3, MemoryUtil.getAddress(arg_value), function_pointer);
/* 1801:1550 */     return __result;
/* 1802:     */   }
/* 1803:     */   
/* 1804:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, ShortBuffer arg_value)
/* 1805:     */   {
/* 1806:1553 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1807:1554 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1808:1555 */     BufferChecks.checkDirect(arg_value);
/* 1809:1556 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_value.remaining() << 1, MemoryUtil.getAddress(arg_value), function_pointer);
/* 1810:1557 */     return __result;
/* 1811:     */   }
/* 1812:     */   
/* 1813:     */   static native int nclSetKernelArg(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4);
/* 1814:     */   
/* 1815:     */   public static int clSetKernelArg(CLKernel kernel, int arg_index, CLObject arg_value)
/* 1816:     */   {
/* 1817:1563 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1818:1564 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1819:1565 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, PointerBuffer.getPointerSize(), APIUtil.getPointerSafe(arg_value), function_pointer);
/* 1820:1566 */     return __result;
/* 1821:     */   }
/* 1822:     */   
/* 1823:     */   static int clSetKernelArg(CLKernel kernel, int arg_index, long arg_size, Buffer arg_value)
/* 1824:     */   {
/* 1825:1571 */     long function_pointer = CLCapabilities.clSetKernelArg;
/* 1826:1572 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1827:1573 */     int __result = nclSetKernelArg(kernel.getPointer(), arg_index, arg_size, MemoryUtil.getAddress0(arg_value), function_pointer);
/* 1828:1574 */     return __result;
/* 1829:     */   }
/* 1830:     */   
/* 1831:     */   public static int clGetKernelInfo(CLKernel kernel, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1832:     */   {
/* 1833:1578 */     long function_pointer = CLCapabilities.clGetKernelInfo;
/* 1834:1579 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1835:1580 */     if (param_value != null) {
/* 1836:1581 */       BufferChecks.checkDirect(param_value);
/* 1837:     */     }
/* 1838:1582 */     if (param_value_size_ret != null) {
/* 1839:1583 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1840:     */     }
/* 1841:1584 */     int __result = nclGetKernelInfo(kernel.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1842:1585 */     return __result;
/* 1843:     */   }
/* 1844:     */   
/* 1845:     */   static native int nclGetKernelInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1846:     */   
/* 1847:     */   public static int clGetKernelWorkGroupInfo(CLKernel kernel, CLDevice device, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1848:     */   {
/* 1849:1590 */     long function_pointer = CLCapabilities.clGetKernelWorkGroupInfo;
/* 1850:1591 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1851:1592 */     if (param_value != null) {
/* 1852:1593 */       BufferChecks.checkDirect(param_value);
/* 1853:     */     }
/* 1854:1594 */     if (param_value_size_ret != null) {
/* 1855:1595 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1856:     */     }
/* 1857:1596 */     int __result = nclGetKernelWorkGroupInfo(kernel.getPointer(), device == null ? 0L : device.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1858:1597 */     return __result;
/* 1859:     */   }
/* 1860:     */   
/* 1861:     */   static native int nclGetKernelWorkGroupInfo(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/* 1862:     */   
/* 1863:     */   public static int clEnqueueNDRangeKernel(CLCommandQueue command_queue, CLKernel kernel, int work_dim, PointerBuffer global_work_offset, PointerBuffer global_work_size, PointerBuffer local_work_size, PointerBuffer event_wait_list, PointerBuffer event)
/* 1864:     */   {
/* 1865:1602 */     long function_pointer = CLCapabilities.clEnqueueNDRangeKernel;
/* 1866:1603 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1867:1604 */     if (global_work_offset != null) {
/* 1868:1605 */       BufferChecks.checkBuffer(global_work_offset, work_dim);
/* 1869:     */     }
/* 1870:1606 */     if (global_work_size != null) {
/* 1871:1607 */       BufferChecks.checkBuffer(global_work_size, work_dim);
/* 1872:     */     }
/* 1873:1608 */     if (local_work_size != null) {
/* 1874:1609 */       BufferChecks.checkBuffer(local_work_size, work_dim);
/* 1875:     */     }
/* 1876:1610 */     if (event_wait_list != null) {
/* 1877:1611 */       BufferChecks.checkDirect(event_wait_list);
/* 1878:     */     }
/* 1879:1612 */     if (event != null) {
/* 1880:1613 */       BufferChecks.checkBuffer(event, 1);
/* 1881:     */     }
/* 1882:1614 */     int __result = nclEnqueueNDRangeKernel(command_queue.getPointer(), kernel.getPointer(), work_dim, MemoryUtil.getAddressSafe(global_work_offset), MemoryUtil.getAddressSafe(global_work_size), MemoryUtil.getAddressSafe(local_work_size), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1883:1615 */     if (__result == 0) {
/* 1884:1615 */       command_queue.registerCLEvent(event);
/* 1885:     */     }
/* 1886:1616 */     return __result;
/* 1887:     */   }
/* 1888:     */   
/* 1889:     */   static native int nclEnqueueNDRangeKernel(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, long paramLong7, long paramLong8);
/* 1890:     */   
/* 1891:     */   public static int clEnqueueTask(CLCommandQueue command_queue, CLKernel kernel, PointerBuffer event_wait_list, PointerBuffer event)
/* 1892:     */   {
/* 1893:1621 */     long function_pointer = CLCapabilities.clEnqueueTask;
/* 1894:1622 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1895:1623 */     if (event_wait_list != null) {
/* 1896:1624 */       BufferChecks.checkDirect(event_wait_list);
/* 1897:     */     }
/* 1898:1625 */     if (event != null) {
/* 1899:1626 */       BufferChecks.checkBuffer(event, 1);
/* 1900:     */     }
/* 1901:1627 */     int __result = nclEnqueueTask(command_queue.getPointer(), kernel.getPointer(), event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1902:1628 */     if (__result == 0) {
/* 1903:1628 */       command_queue.registerCLEvent(event);
/* 1904:     */     }
/* 1905:1629 */     return __result;
/* 1906:     */   }
/* 1907:     */   
/* 1908:     */   static native int nclEnqueueTask(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/* 1909:     */   
/* 1910:     */   public static int clEnqueueNativeKernel(CLCommandQueue command_queue, CLNativeKernel user_func, CLMem[] mem_list, long[] sizes, PointerBuffer event_wait_list, PointerBuffer event)
/* 1911:     */   {
/* 1912:1650 */     long function_pointer = CLCapabilities.clEnqueueNativeKernel;
/* 1913:1651 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1914:1652 */     if (mem_list != null) {
/* 1915:1653 */       BufferChecks.checkArray(mem_list, 1);
/* 1916:     */     }
/* 1917:1654 */     if (sizes != null) {
/* 1918:1655 */       BufferChecks.checkArray(sizes, mem_list.length);
/* 1919:     */     }
/* 1920:1656 */     if (event_wait_list != null) {
/* 1921:1657 */       BufferChecks.checkDirect(event_wait_list);
/* 1922:     */     }
/* 1923:1658 */     if (event != null) {
/* 1924:1659 */       BufferChecks.checkBuffer(event, 1);
/* 1925:     */     }
/* 1926:1660 */     long user_func_ref = CallbackUtil.createGlobalRef(user_func);
/* 1927:1661 */     ByteBuffer args = APIUtil.getNativeKernelArgs(user_func_ref, mem_list, sizes);
/* 1928:1662 */     int __result = 0;
/* 1929:     */     try
/* 1930:     */     {
/* 1931:1664 */       __result = nclEnqueueNativeKernel(command_queue.getPointer(), user_func.getPointer(), MemoryUtil.getAddress0(args), args.remaining(), mem_list == null ? 0 : mem_list.length, mem_list, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 1932:1665 */       if (__result == 0) {
/* 1933:1665 */         command_queue.registerCLEvent(event);
/* 1934:     */       }
/* 1935:1666 */       return __result;
/* 1936:     */     }
/* 1937:     */     finally
/* 1938:     */     {
/* 1939:1668 */       CallbackUtil.checkCallback(__result, user_func_ref);
/* 1940:     */     }
/* 1941:     */   }
/* 1942:     */   
/* 1943:     */   static native int nclEnqueueNativeKernel(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt1, CLMem[] paramArrayOfCLMem, int paramInt2, long paramLong5, long paramLong6, long paramLong7);
/* 1944:     */   
/* 1945:     */   public static int clWaitForEvents(PointerBuffer event_list)
/* 1946:     */   {
/* 1947:1674 */     long function_pointer = CLCapabilities.clWaitForEvents;
/* 1948:1675 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1949:1676 */     BufferChecks.checkBuffer(event_list, 1);
/* 1950:1677 */     int __result = nclWaitForEvents(event_list.remaining(), MemoryUtil.getAddress(event_list), function_pointer);
/* 1951:1678 */     return __result;
/* 1952:     */   }
/* 1953:     */   
/* 1954:     */   static native int nclWaitForEvents(int paramInt, long paramLong1, long paramLong2);
/* 1955:     */   
/* 1956:     */   public static int clWaitForEvents(CLEvent event)
/* 1957:     */   {
/* 1958:1684 */     long function_pointer = CLCapabilities.clWaitForEvents;
/* 1959:1685 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1960:1686 */     int __result = nclWaitForEvents(1, APIUtil.getPointer(event), function_pointer);
/* 1961:1687 */     return __result;
/* 1962:     */   }
/* 1963:     */   
/* 1964:     */   public static int clGetEventInfo(CLEvent event, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 1965:     */   {
/* 1966:1691 */     long function_pointer = CLCapabilities.clGetEventInfo;
/* 1967:1692 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1968:1693 */     if (param_value != null) {
/* 1969:1694 */       BufferChecks.checkDirect(param_value);
/* 1970:     */     }
/* 1971:1695 */     if (param_value_size_ret != null) {
/* 1972:1696 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 1973:     */     }
/* 1974:1697 */     int __result = nclGetEventInfo(event.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 1975:1698 */     return __result;
/* 1976:     */   }
/* 1977:     */   
/* 1978:     */   static native int nclGetEventInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1979:     */   
/* 1980:     */   public static int clRetainEvent(CLEvent event)
/* 1981:     */   {
/* 1982:1703 */     long function_pointer = CLCapabilities.clRetainEvent;
/* 1983:1704 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1984:1705 */     int __result = nclRetainEvent(event.getPointer(), function_pointer);
/* 1985:1706 */     if (__result == 0) {
/* 1986:1706 */       event.retain();
/* 1987:     */     }
/* 1988:1707 */     return __result;
/* 1989:     */   }
/* 1990:     */   
/* 1991:     */   static native int nclRetainEvent(long paramLong1, long paramLong2);
/* 1992:     */   
/* 1993:     */   public static int clReleaseEvent(CLEvent event)
/* 1994:     */   {
/* 1995:1712 */     long function_pointer = CLCapabilities.clReleaseEvent;
/* 1996:1713 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1997:1714 */     int __result = nclReleaseEvent(event.getPointer(), function_pointer);
/* 1998:1715 */     if (__result == 0) {
/* 1999:1715 */       event.release();
/* 2000:     */     }
/* 2001:1716 */     return __result;
/* 2002:     */   }
/* 2003:     */   
/* 2004:     */   static native int nclReleaseEvent(long paramLong1, long paramLong2);
/* 2005:     */   
/* 2006:     */   public static int clEnqueueMarker(CLCommandQueue command_queue, PointerBuffer event)
/* 2007:     */   {
/* 2008:1721 */     long function_pointer = CLCapabilities.clEnqueueMarker;
/* 2009:1722 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2010:1723 */     BufferChecks.checkBuffer(event, 1);
/* 2011:1724 */     int __result = nclEnqueueMarker(command_queue.getPointer(), MemoryUtil.getAddress(event), function_pointer);
/* 2012:1725 */     if (__result == 0) {
/* 2013:1725 */       command_queue.registerCLEvent(event);
/* 2014:     */     }
/* 2015:1726 */     return __result;
/* 2016:     */   }
/* 2017:     */   
/* 2018:     */   static native int nclEnqueueMarker(long paramLong1, long paramLong2, long paramLong3);
/* 2019:     */   
/* 2020:     */   public static int clEnqueueBarrier(CLCommandQueue command_queue)
/* 2021:     */   {
/* 2022:1731 */     long function_pointer = CLCapabilities.clEnqueueBarrier;
/* 2023:1732 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2024:1733 */     int __result = nclEnqueueBarrier(command_queue.getPointer(), function_pointer);
/* 2025:1734 */     return __result;
/* 2026:     */   }
/* 2027:     */   
/* 2028:     */   static native int nclEnqueueBarrier(long paramLong1, long paramLong2);
/* 2029:     */   
/* 2030:     */   public static int clEnqueueWaitForEvents(CLCommandQueue command_queue, PointerBuffer event_list)
/* 2031:     */   {
/* 2032:1739 */     long function_pointer = CLCapabilities.clEnqueueWaitForEvents;
/* 2033:1740 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2034:1741 */     BufferChecks.checkBuffer(event_list, 1);
/* 2035:1742 */     int __result = nclEnqueueWaitForEvents(command_queue.getPointer(), event_list.remaining(), MemoryUtil.getAddress(event_list), function_pointer);
/* 2036:1743 */     return __result;
/* 2037:     */   }
/* 2038:     */   
/* 2039:     */   static native int nclEnqueueWaitForEvents(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/* 2040:     */   
/* 2041:     */   public static int clEnqueueWaitForEvents(CLCommandQueue command_queue, CLEvent event)
/* 2042:     */   {
/* 2043:1749 */     long function_pointer = CLCapabilities.clEnqueueWaitForEvents;
/* 2044:1750 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2045:1751 */     int __result = nclEnqueueWaitForEvents(command_queue.getPointer(), 1, APIUtil.getPointer(event), function_pointer);
/* 2046:1752 */     return __result;
/* 2047:     */   }
/* 2048:     */   
/* 2049:     */   public static int clGetEventProfilingInfo(CLEvent event, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 2050:     */   {
/* 2051:1756 */     long function_pointer = CLCapabilities.clGetEventProfilingInfo;
/* 2052:1757 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2053:1758 */     if (param_value != null) {
/* 2054:1759 */       BufferChecks.checkDirect(param_value);
/* 2055:     */     }
/* 2056:1760 */     if (param_value_size_ret != null) {
/* 2057:1761 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 2058:     */     }
/* 2059:1762 */     int __result = nclGetEventProfilingInfo(event.getPointer(), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 2060:1763 */     return __result;
/* 2061:     */   }
/* 2062:     */   
/* 2063:     */   static native int nclGetEventProfilingInfo(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 2064:     */   
/* 2065:     */   public static int clFlush(CLCommandQueue command_queue)
/* 2066:     */   {
/* 2067:1768 */     long function_pointer = CLCapabilities.clFlush;
/* 2068:1769 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2069:1770 */     int __result = nclFlush(command_queue.getPointer(), function_pointer);
/* 2070:1771 */     return __result;
/* 2071:     */   }
/* 2072:     */   
/* 2073:     */   static native int nclFlush(long paramLong1, long paramLong2);
/* 2074:     */   
/* 2075:     */   public static int clFinish(CLCommandQueue command_queue)
/* 2076:     */   {
/* 2077:1776 */     long function_pointer = CLCapabilities.clFinish;
/* 2078:1777 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2079:1778 */     int __result = nclFinish(command_queue.getPointer(), function_pointer);
/* 2080:1779 */     return __result;
/* 2081:     */   }
/* 2082:     */   
/* 2083:     */   static native int nclFinish(long paramLong1, long paramLong2);
/* 2084:     */   
/* 2085:     */   static CLFunctionAddress clGetExtensionFunctionAddress(ByteBuffer func_name)
/* 2086:     */   {
/* 2087:1784 */     long function_pointer = CLCapabilities.clGetExtensionFunctionAddress;
/* 2088:1785 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2089:1786 */     BufferChecks.checkDirect(func_name);
/* 2090:1787 */     BufferChecks.checkNullTerminated(func_name);
/* 2091:1788 */     CLFunctionAddress __result = new CLFunctionAddress(nclGetExtensionFunctionAddress(MemoryUtil.getAddress(func_name), function_pointer));
/* 2092:1789 */     return __result;
/* 2093:     */   }
/* 2094:     */   
/* 2095:     */   static native long nclGetExtensionFunctionAddress(long paramLong1, long paramLong2);
/* 2096:     */   
/* 2097:     */   static CLFunctionAddress clGetExtensionFunctionAddress(CharSequence func_name)
/* 2098:     */   {
/* 2099:1795 */     long function_pointer = CLCapabilities.clGetExtensionFunctionAddress;
/* 2100:1796 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2101:1797 */     CLFunctionAddress __result = new CLFunctionAddress(nclGetExtensionFunctionAddress(APIUtil.getBufferNT(func_name), function_pointer));
/* 2102:1798 */     return __result;
/* 2103:     */   }
/* 2104:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL10
 * JD-Core Version:    0.7.0.1
 */