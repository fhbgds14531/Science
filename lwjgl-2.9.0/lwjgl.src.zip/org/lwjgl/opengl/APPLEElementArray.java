/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class APPLEElementArray
/* 10:   */ {
/* 11:   */   public static final int GL_ELEMENT_ARRAY_APPLE = 34664;
/* 12:   */   public static final int GL_ELEMENT_ARRAY_TYPE_APPLE = 34665;
/* 13:   */   public static final int GL_ELEMENT_ARRAY_POINTER_APPLE = 34666;
/* 14:   */   
/* 15:   */   public static void glElementPointerAPPLE(ByteBuffer pointer)
/* 16:   */   {
/* 17:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 18:31 */     long function_pointer = caps.glElementPointerAPPLE;
/* 19:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 20:33 */     BufferChecks.checkDirect(pointer);
/* 21:34 */     nglElementPointerAPPLE(5121, MemoryUtil.getAddress(pointer), function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glElementPointerAPPLE(IntBuffer pointer)
/* 25:   */   {
/* 26:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:38 */     long function_pointer = caps.glElementPointerAPPLE;
/* 28:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:40 */     BufferChecks.checkDirect(pointer);
/* 30:41 */     nglElementPointerAPPLE(5125, MemoryUtil.getAddress(pointer), function_pointer);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static void glElementPointerAPPLE(ShortBuffer pointer)
/* 34:   */   {
/* 35:44 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 36:45 */     long function_pointer = caps.glElementPointerAPPLE;
/* 37:46 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 38:47 */     BufferChecks.checkDirect(pointer);
/* 39:48 */     nglElementPointerAPPLE(5123, MemoryUtil.getAddress(pointer), function_pointer);
/* 40:   */   }
/* 41:   */   
/* 42:   */   static native void nglElementPointerAPPLE(int paramInt, long paramLong1, long paramLong2);
/* 43:   */   
/* 44:   */   public static void glDrawElementArrayAPPLE(int mode, int first, int count)
/* 45:   */   {
/* 46:53 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 47:54 */     long function_pointer = caps.glDrawElementArrayAPPLE;
/* 48:55 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 49:56 */     nglDrawElementArrayAPPLE(mode, first, count, function_pointer);
/* 50:   */   }
/* 51:   */   
/* 52:   */   static native void nglDrawElementArrayAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 53:   */   
/* 54:   */   public static void glDrawRangeElementArrayAPPLE(int mode, int start, int end, int first, int count)
/* 55:   */   {
/* 56:61 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 57:62 */     long function_pointer = caps.glDrawRangeElementArrayAPPLE;
/* 58:63 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 59:64 */     nglDrawRangeElementArrayAPPLE(mode, start, end, first, count, function_pointer);
/* 60:   */   }
/* 61:   */   
/* 62:   */   static native void nglDrawRangeElementArrayAPPLE(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 63:   */   
/* 64:   */   public static void glMultiDrawElementArrayAPPLE(int mode, IntBuffer first, IntBuffer count)
/* 65:   */   {
/* 66:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 67:70 */     long function_pointer = caps.glMultiDrawElementArrayAPPLE;
/* 68:71 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 69:72 */     BufferChecks.checkDirect(first);
/* 70:73 */     BufferChecks.checkBuffer(count, first.remaining());
/* 71:74 */     nglMultiDrawElementArrayAPPLE(mode, MemoryUtil.getAddress(first), MemoryUtil.getAddress(count), first.remaining(), function_pointer);
/* 72:   */   }
/* 73:   */   
/* 74:   */   static native void nglMultiDrawElementArrayAPPLE(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 75:   */   
/* 76:   */   public static void glMultiDrawRangeElementArrayAPPLE(int mode, int start, int end, IntBuffer first, IntBuffer count)
/* 77:   */   {
/* 78:79 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 79:80 */     long function_pointer = caps.glMultiDrawRangeElementArrayAPPLE;
/* 80:81 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 81:82 */     BufferChecks.checkDirect(first);
/* 82:83 */     BufferChecks.checkBuffer(count, first.remaining());
/* 83:84 */     nglMultiDrawRangeElementArrayAPPLE(mode, start, end, MemoryUtil.getAddress(first), MemoryUtil.getAddress(count), first.remaining(), function_pointer);
/* 84:   */   }
/* 85:   */   
/* 86:   */   static native void nglMultiDrawRangeElementArrayAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, int paramInt4, long paramLong3);
/* 87:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEElementArray
 * JD-Core Version:    0.7.0.1
 */