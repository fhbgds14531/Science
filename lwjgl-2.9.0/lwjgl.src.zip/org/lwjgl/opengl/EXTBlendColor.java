/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTBlendColor
/*  6:   */ {
/*  7:   */   public static final int GL_CONSTANT_COLOR_EXT = 32769;
/*  8:   */   public static final int GL_ONE_MINUS_CONSTANT_COLOR_EXT = 32770;
/*  9:   */   public static final int GL_CONSTANT_ALPHA_EXT = 32771;
/* 10:   */   public static final int GL_ONE_MINUS_CONSTANT_ALPHA_EXT = 32772;
/* 11:   */   public static final int GL_BLEND_COLOR_EXT = 32773;
/* 12:   */   
/* 13:   */   public static void glBlendColorEXT(float red, float green, float blue, float alpha)
/* 14:   */   {
/* 15:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 16:28 */     long function_pointer = caps.glBlendColorEXT;
/* 17:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 18:30 */     nglBlendColorEXT(red, green, blue, alpha, function_pointer);
/* 19:   */   }
/* 20:   */   
/* 21:   */   static native void nglBlendColorEXT(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 22:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBlendColor
 * JD-Core Version:    0.7.0.1
 */