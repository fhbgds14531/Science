/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBSampleShading
/*  6:   */ {
/*  7:   */   public static final int GL_SAMPLE_SHADING_ARB = 35894;
/*  8:   */   public static final int GL_MIN_SAMPLE_SHADING_VALUE_ARB = 35895;
/*  9:   */   
/* 10:   */   public static void glMinSampleShadingARB(float value)
/* 11:   */   {
/* 12:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:27 */     long function_pointer = caps.glMinSampleShadingARB;
/* 14:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:29 */     nglMinSampleShadingARB(value, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglMinSampleShadingARB(float paramFloat, long paramLong);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBSampleShading
 * JD-Core Version:    0.7.0.1
 */