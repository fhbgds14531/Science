/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class AMDDebugOutput
/*   9:    */ {
/*  10:    */   public static final int GL_MAX_DEBUG_MESSAGE_LENGTH_AMD = 37187;
/*  11:    */   public static final int GL_MAX_DEBUG_LOGGED_MESSAGES_AMD = 37188;
/*  12:    */   public static final int GL_DEBUG_LOGGED_MESSAGES_AMD = 37189;
/*  13:    */   public static final int GL_DEBUG_SEVERITY_HIGH_AMD = 37190;
/*  14:    */   public static final int GL_DEBUG_SEVERITY_MEDIUM_AMD = 37191;
/*  15:    */   public static final int GL_DEBUG_SEVERITY_LOW_AMD = 37192;
/*  16:    */   public static final int GL_DEBUG_CATEGORY_API_ERROR_AMD = 37193;
/*  17:    */   public static final int GL_DEBUG_CATEGORY_WINDOW_SYSTEM_AMD = 37194;
/*  18:    */   public static final int GL_DEBUG_CATEGORY_DEPRECATION_AMD = 37195;
/*  19:    */   public static final int GL_DEBUG_CATEGORY_UNDEFINED_BEHAVIOR_AMD = 37196;
/*  20:    */   public static final int GL_DEBUG_CATEGORY_PERFORMANCE_AMD = 37197;
/*  21:    */   public static final int GL_DEBUG_CATEGORY_SHADER_COMPILER_AMD = 37198;
/*  22:    */   public static final int GL_DEBUG_CATEGORY_APPLICATION_AMD = 37199;
/*  23:    */   public static final int GL_DEBUG_CATEGORY_OTHER_AMD = 37200;
/*  24:    */   
/*  25:    */   public static void glDebugMessageEnableAMD(int category, int severity, IntBuffer ids, boolean enabled)
/*  26:    */   {
/*  27: 42 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  28: 43 */     long function_pointer = caps.glDebugMessageEnableAMD;
/*  29: 44 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  30: 45 */     if (ids != null) {
/*  31: 46 */       BufferChecks.checkDirect(ids);
/*  32:    */     }
/*  33: 47 */     nglDebugMessageEnableAMD(category, severity, ids == null ? 0 : ids.remaining(), MemoryUtil.getAddressSafe(ids), enabled, function_pointer);
/*  34:    */   }
/*  35:    */   
/*  36:    */   static native void nglDebugMessageEnableAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong1, boolean paramBoolean, long paramLong2);
/*  37:    */   
/*  38:    */   public static void glDebugMessageInsertAMD(int category, int severity, int id, ByteBuffer buf)
/*  39:    */   {
/*  40: 52 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  41: 53 */     long function_pointer = caps.glDebugMessageInsertAMD;
/*  42: 54 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  43: 55 */     BufferChecks.checkDirect(buf);
/*  44: 56 */     nglDebugMessageInsertAMD(category, severity, id, buf.remaining(), MemoryUtil.getAddress(buf), function_pointer);
/*  45:    */   }
/*  46:    */   
/*  47:    */   static native void nglDebugMessageInsertAMD(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  48:    */   
/*  49:    */   public static void glDebugMessageInsertAMD(int category, int severity, int id, CharSequence buf)
/*  50:    */   {
/*  51: 62 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  52: 63 */     long function_pointer = caps.glDebugMessageInsertAMD;
/*  53: 64 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  54: 65 */     nglDebugMessageInsertAMD(category, severity, id, buf.length(), APIUtil.getBuffer(caps, buf), function_pointer);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static void glDebugMessageCallbackAMD(AMDDebugOutputCallback callback)
/*  58:    */   {
/*  59: 76 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 77 */     long function_pointer = caps.glDebugMessageCallbackAMD;
/*  61: 78 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 79 */     long userParam = callback == null ? 0L : CallbackUtil.createGlobalRef(callback.getHandler());
/*  63: 80 */     CallbackUtil.registerContextCallbackAMD(userParam);
/*  64: 81 */     nglDebugMessageCallbackAMD(callback == null ? 0L : callback.getPointer(), userParam, function_pointer);
/*  65:    */   }
/*  66:    */   
/*  67:    */   static native void nglDebugMessageCallbackAMD(long paramLong1, long paramLong2, long paramLong3);
/*  68:    */   
/*  69:    */   public static int glGetDebugMessageLogAMD(int count, IntBuffer categories, IntBuffer severities, IntBuffer ids, IntBuffer lengths, ByteBuffer messageLog)
/*  70:    */   {
/*  71: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  72: 87 */     long function_pointer = caps.glGetDebugMessageLogAMD;
/*  73: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  74: 89 */     if (categories != null) {
/*  75: 90 */       BufferChecks.checkBuffer(categories, count);
/*  76:    */     }
/*  77: 91 */     if (severities != null) {
/*  78: 92 */       BufferChecks.checkBuffer(severities, count);
/*  79:    */     }
/*  80: 93 */     if (ids != null) {
/*  81: 94 */       BufferChecks.checkBuffer(ids, count);
/*  82:    */     }
/*  83: 95 */     if (lengths != null) {
/*  84: 96 */       BufferChecks.checkBuffer(lengths, count);
/*  85:    */     }
/*  86: 97 */     if (messageLog != null) {
/*  87: 98 */       BufferChecks.checkDirect(messageLog);
/*  88:    */     }
/*  89: 99 */     int __result = nglGetDebugMessageLogAMD(count, messageLog == null ? 0 : messageLog.remaining(), MemoryUtil.getAddressSafe(categories), MemoryUtil.getAddressSafe(severities), MemoryUtil.getAddressSafe(ids), MemoryUtil.getAddressSafe(lengths), MemoryUtil.getAddressSafe(messageLog), function_pointer);
/*  90:100 */     return __result;
/*  91:    */   }
/*  92:    */   
/*  93:    */   static native int nglGetDebugMessageLogAMD(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*  94:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDDebugOutput
 * JD-Core Version:    0.7.0.1
 */