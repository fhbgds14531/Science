/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class EXTTransformFeedback
/*   9:    */ {
/*  10:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_EXT = 35982;
/*  11:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_START_EXT = 35972;
/*  12:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_SIZE_EXT = 35973;
/*  13:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_BINDING_EXT = 35983;
/*  14:    */   public static final int GL_INTERLEAVED_ATTRIBS_EXT = 35980;
/*  15:    */   public static final int GL_SEPARATE_ATTRIBS_EXT = 35981;
/*  16:    */   public static final int GL_PRIMITIVES_GENERATED_EXT = 35975;
/*  17:    */   public static final int GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN_EXT = 35976;
/*  18:    */   public static final int GL_RASTERIZER_DISCARD_EXT = 35977;
/*  19:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS_EXT = 35978;
/*  20:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS_EXT = 35979;
/*  21:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS_EXT = 35968;
/*  22:    */   public static final int GL_TRANSFORM_FEEDBACK_VARYINGS_EXT = 35971;
/*  23:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_MODE_EXT = 35967;
/*  24:    */   public static final int GL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH_EXT = 35958;
/*  25:    */   
/*  26:    */   public static void glBindBufferRangeEXT(int target, int index, int buffer, long offset, long size)
/*  27:    */   {
/*  28: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  29: 71 */     long function_pointer = caps.glBindBufferRangeEXT;
/*  30: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  31: 73 */     nglBindBufferRangeEXT(target, index, buffer, offset, size, function_pointer);
/*  32:    */   }
/*  33:    */   
/*  34:    */   static native void nglBindBufferRangeEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/*  35:    */   
/*  36:    */   public static void glBindBufferOffsetEXT(int target, int index, int buffer, long offset)
/*  37:    */   {
/*  38: 78 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  39: 79 */     long function_pointer = caps.glBindBufferOffsetEXT;
/*  40: 80 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  41: 81 */     nglBindBufferOffsetEXT(target, index, buffer, offset, function_pointer);
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native void nglBindBufferOffsetEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  45:    */   
/*  46:    */   public static void glBindBufferBaseEXT(int target, int index, int buffer)
/*  47:    */   {
/*  48: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  49: 87 */     long function_pointer = caps.glBindBufferBaseEXT;
/*  50: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  51: 89 */     nglBindBufferBaseEXT(target, index, buffer, function_pointer);
/*  52:    */   }
/*  53:    */   
/*  54:    */   static native void nglBindBufferBaseEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  55:    */   
/*  56:    */   public static void glBeginTransformFeedbackEXT(int primitiveMode)
/*  57:    */   {
/*  58: 94 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  59: 95 */     long function_pointer = caps.glBeginTransformFeedbackEXT;
/*  60: 96 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 97 */     nglBeginTransformFeedbackEXT(primitiveMode, function_pointer);
/*  62:    */   }
/*  63:    */   
/*  64:    */   static native void nglBeginTransformFeedbackEXT(int paramInt, long paramLong);
/*  65:    */   
/*  66:    */   public static void glEndTransformFeedbackEXT()
/*  67:    */   {
/*  68:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  69:103 */     long function_pointer = caps.glEndTransformFeedbackEXT;
/*  70:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  71:105 */     nglEndTransformFeedbackEXT(function_pointer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static native void nglEndTransformFeedbackEXT(long paramLong);
/*  75:    */   
/*  76:    */   public static void glTransformFeedbackVaryingsEXT(int program, int count, ByteBuffer varyings, int bufferMode)
/*  77:    */   {
/*  78:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79:111 */     long function_pointer = caps.glTransformFeedbackVaryingsEXT;
/*  80:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81:113 */     BufferChecks.checkDirect(varyings);
/*  82:114 */     BufferChecks.checkNullTerminated(varyings, count);
/*  83:115 */     nglTransformFeedbackVaryingsEXT(program, count, MemoryUtil.getAddress(varyings), bufferMode, function_pointer);
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native void nglTransformFeedbackVaryingsEXT(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  87:    */   
/*  88:    */   public static void glTransformFeedbackVaryingsEXT(int program, CharSequence[] varyings, int bufferMode)
/*  89:    */   {
/*  90:121 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91:122 */     long function_pointer = caps.glTransformFeedbackVaryingsEXT;
/*  92:123 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93:124 */     BufferChecks.checkArray(varyings);
/*  94:125 */     nglTransformFeedbackVaryingsEXT(program, varyings.length, APIUtil.getBufferNT(caps, varyings), bufferMode, function_pointer);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void glGetTransformFeedbackVaryingEXT(int program, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/*  98:    */   {
/*  99:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 100:130 */     long function_pointer = caps.glGetTransformFeedbackVaryingEXT;
/* 101:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 102:132 */     if (length != null) {
/* 103:133 */       BufferChecks.checkBuffer(length, 1);
/* 104:    */     }
/* 105:134 */     BufferChecks.checkBuffer(size, 1);
/* 106:135 */     BufferChecks.checkBuffer(type, 1);
/* 107:136 */     BufferChecks.checkDirect(name);
/* 108:137 */     nglGetTransformFeedbackVaryingEXT(program, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 109:    */   }
/* 110:    */   
/* 111:    */   static native void nglGetTransformFeedbackVaryingEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 112:    */   
/* 113:    */   public static String glGetTransformFeedbackVaryingEXT(int program, int index, int bufSize, IntBuffer size, IntBuffer type)
/* 114:    */   {
/* 115:143 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116:144 */     long function_pointer = caps.glGetTransformFeedbackVaryingEXT;
/* 117:145 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:146 */     BufferChecks.checkBuffer(size, 1);
/* 119:147 */     BufferChecks.checkBuffer(type, 1);
/* 120:148 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 121:149 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufSize);
/* 122:150 */     nglGetTransformFeedbackVaryingEXT(program, index, bufSize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 123:151 */     name.limit(name_length.get(0));
/* 124:152 */     return APIUtil.getString(caps, name);
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTransformFeedback
 * JD-Core Version:    0.7.0.1
 */