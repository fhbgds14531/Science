package org.lwjgl.opengl;

public final class EXTStencilWrap
{
  public static final int GL_INCR_WRAP_EXT = 34055;
  public static final int GL_DECR_WRAP_EXT = 34056;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTStencilWrap
 * JD-Core Version:    0.7.0.1
 */