/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.nio.LongBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.LWJGLUtil;
/*   8:    */ 
/*   9:    */ public final class NVVideoCaptureUtil
/*  10:    */ {
/*  11:    */   private static void checkExtension()
/*  12:    */   {
/*  13: 54 */     if ((LWJGLUtil.CHECKS) && (!GLContext.getCapabilities().GL_NV_video_capture)) {
/*  14: 55 */       throw new IllegalStateException("NV_video_capture is not supported");
/*  15:    */     }
/*  16:    */   }
/*  17:    */   
/*  18:    */   private static ByteBuffer getPeerInfo()
/*  19:    */   {
/*  20: 59 */     return ContextGL.getCurrentContext().getPeerInfo().getHandle();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static boolean glBindVideoCaptureDeviceNV(int video_slot, long device)
/*  24:    */   {
/*  25: 73 */     checkExtension();
/*  26: 74 */     return nglBindVideoCaptureDeviceNV(getPeerInfo(), video_slot, device);
/*  27:    */   }
/*  28:    */   
/*  29:    */   private static native boolean nglBindVideoCaptureDeviceNV(ByteBuffer paramByteBuffer, int paramInt, long paramLong);
/*  30:    */   
/*  31:    */   public static int glEnumerateVideoCaptureDevicesNV(LongBuffer devices)
/*  32:    */   {
/*  33:    */     
/*  34: 93 */     if (devices != null) {
/*  35: 94 */       BufferChecks.checkBuffer(devices, 1);
/*  36:    */     }
/*  37: 95 */     return nglEnumerateVideoCaptureDevicesNV(getPeerInfo(), devices, devices == null ? 0 : devices.position());
/*  38:    */   }
/*  39:    */   
/*  40:    */   private static native int nglEnumerateVideoCaptureDevicesNV(ByteBuffer paramByteBuffer, LongBuffer paramLongBuffer, int paramInt);
/*  41:    */   
/*  42:    */   public static boolean glLockVideoCaptureDeviceNV(long device)
/*  43:    */   {
/*  44:112 */     checkExtension();
/*  45:113 */     return nglLockVideoCaptureDeviceNV(getPeerInfo(), device);
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static native boolean nglLockVideoCaptureDeviceNV(ByteBuffer paramByteBuffer, long paramLong);
/*  49:    */   
/*  50:    */   public static boolean glQueryVideoCaptureDeviceNV(long device, int attribute, IntBuffer value)
/*  51:    */   {
/*  52:129 */     checkExtension();
/*  53:    */     
/*  54:131 */     BufferChecks.checkBuffer(value, 1);
/*  55:132 */     return nglQueryVideoCaptureDeviceNV(getPeerInfo(), device, attribute, value, value.position());
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static native boolean nglQueryVideoCaptureDeviceNV(ByteBuffer paramByteBuffer, long paramLong, int paramInt1, IntBuffer paramIntBuffer, int paramInt2);
/*  59:    */   
/*  60:    */   public static boolean glReleaseVideoCaptureDeviceNV(long device)
/*  61:    */   {
/*  62:146 */     checkExtension();
/*  63:147 */     return nglReleaseVideoCaptureDeviceNV(getPeerInfo(), device);
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static native boolean nglReleaseVideoCaptureDeviceNV(ByteBuffer paramByteBuffer, long paramLong);
/*  67:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVideoCaptureUtil
 * JD-Core Version:    0.7.0.1
 */