/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ 
/*   6:    */ final class CallbackUtil
/*   7:    */ {
/*   8: 45 */   private static final Map<ContextCapabilities, Long> contextUserParamsARB = new HashMap();
/*   9: 47 */   private static final Map<ContextCapabilities, Long> contextUserParamsAMD = new HashMap();
/*  10: 49 */   private static final Map<ContextCapabilities, Long> contextUserParamsKHR = new HashMap();
/*  11:    */   
/*  12:    */   static long createGlobalRef(Object obj)
/*  13:    */   {
/*  14: 61 */     return obj == null ? 0L : ncreateGlobalRef(obj);
/*  15:    */   }
/*  16:    */   
/*  17:    */   private static native long ncreateGlobalRef(Object paramObject);
/*  18:    */   
/*  19:    */   private static native void deleteGlobalRef(long paramLong);
/*  20:    */   
/*  21:    */   private static void registerContextCallback(long userParam, Map<ContextCapabilities, Long> contextUserData)
/*  22:    */   {
/*  23: 90 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  24: 91 */     if (caps == null)
/*  25:    */     {
/*  26: 92 */       deleteGlobalRef(userParam);
/*  27: 93 */       throw new IllegalStateException("No context is current.");
/*  28:    */     }
/*  29: 96 */     Long userParam_old = (Long)contextUserData.remove(caps);
/*  30: 97 */     if (userParam_old != null) {
/*  31: 98 */       deleteGlobalRef(userParam_old.longValue());
/*  32:    */     }
/*  33:100 */     if (userParam != 0L) {
/*  34:101 */       contextUserData.put(caps, Long.valueOf(userParam));
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   static void unregisterCallbacks(Object context)
/*  39:    */   {
/*  40:111 */     ContextCapabilities caps = GLContext.getCapabilities(context);
/*  41:    */     
/*  42:113 */     Long userParam = (Long)contextUserParamsARB.remove(caps);
/*  43:114 */     if (userParam != null) {
/*  44:115 */       deleteGlobalRef(userParam.longValue());
/*  45:    */     }
/*  46:117 */     userParam = (Long)contextUserParamsAMD.remove(caps);
/*  47:118 */     if (userParam != null) {
/*  48:119 */       deleteGlobalRef(userParam.longValue());
/*  49:    */     }
/*  50:121 */     userParam = (Long)contextUserParamsKHR.remove(caps);
/*  51:122 */     if (userParam != null) {
/*  52:123 */       deleteGlobalRef(userParam.longValue());
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   static native long getDebugOutputCallbackARB();
/*  57:    */   
/*  58:    */   static void registerContextCallbackARB(long userParam)
/*  59:    */   {
/*  60:143 */     registerContextCallback(userParam, contextUserParamsARB);
/*  61:    */   }
/*  62:    */   
/*  63:    */   static native long getDebugOutputCallbackAMD();
/*  64:    */   
/*  65:    */   static void registerContextCallbackAMD(long userParam)
/*  66:    */   {
/*  67:163 */     registerContextCallback(userParam, contextUserParamsAMD);
/*  68:    */   }
/*  69:    */   
/*  70:    */   static native long getDebugCallbackKHR();
/*  71:    */   
/*  72:    */   static void registerContextCallbackKHR(long userParam)
/*  73:    */   {
/*  74:183 */     registerContextCallback(userParam, contextUserParamsKHR);
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.CallbackUtil
 * JD-Core Version:    0.7.0.1
 */