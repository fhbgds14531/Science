/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.PointerBuffer;
/*   4:    */ 
/*   5:    */ public final class CLCommandQueue
/*   6:    */   extends CLObjectChild<CLContext>
/*   7:    */ {
/*   8: 43 */   private static final InfoUtil<CLCommandQueue> util = CLPlatform.getInfoUtilInstance(CLCommandQueue.class, "CL_COMMAND_QUEUE_UTIL");
/*   9:    */   private final CLDevice device;
/*  10:    */   private final CLObjectRegistry<CLEvent> clEvents;
/*  11:    */   
/*  12:    */   CLCommandQueue(long pointer, CLContext context, CLDevice device)
/*  13:    */   {
/*  14: 50 */     super(pointer, context);
/*  15: 51 */     if (isValid())
/*  16:    */     {
/*  17: 52 */       this.device = device;
/*  18: 53 */       this.clEvents = new CLObjectRegistry();
/*  19: 54 */       context.getCLCommandQueueRegistry().registerObject(this);
/*  20:    */     }
/*  21:    */     else
/*  22:    */     {
/*  23: 56 */       this.device = null;
/*  24: 57 */       this.clEvents = null;
/*  25:    */     }
/*  26:    */   }
/*  27:    */   
/*  28:    */   public CLDevice getCLDevice()
/*  29:    */   {
/*  30: 62 */     return this.device;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public CLEvent getCLEvent(long id)
/*  34:    */   {
/*  35: 73 */     return (CLEvent)this.clEvents.getObject(id);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public int getInfoInt(int param_name)
/*  39:    */   {
/*  40: 86 */     return util.getInfoInt(this, param_name);
/*  41:    */   }
/*  42:    */   
/*  43:    */   CLObjectRegistry<CLEvent> getCLEventRegistry()
/*  44:    */   {
/*  45: 91 */     return this.clEvents;
/*  46:    */   }
/*  47:    */   
/*  48:    */   void registerCLEvent(PointerBuffer event)
/*  49:    */   {
/*  50: 99 */     if (event != null) {
/*  51:100 */       new CLEvent(event.get(event.position()), this);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   int release()
/*  56:    */   {
/*  57:    */     try
/*  58:    */     {
/*  59:105 */       return super.release();
/*  60:    */     }
/*  61:    */     finally
/*  62:    */     {
/*  63:107 */       if (!isValid()) {
/*  64:108 */         ((CLContext)getParent()).getCLCommandQueueRegistry().unregisterObject(this);
/*  65:    */       }
/*  66:    */     }
/*  67:    */   }
/*  68:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLCommandQueue
 * JD-Core Version:    0.7.0.1
 */