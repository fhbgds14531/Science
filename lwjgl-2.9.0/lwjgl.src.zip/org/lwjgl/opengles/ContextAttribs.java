/*  1:   */ package org.lwjgl.opengles;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferUtils;
/*  5:   */ 
/*  6:   */ public final class ContextAttribs
/*  7:   */ {
/*  8:   */   private int version;
/*  9:   */   
/* 10:   */   public ContextAttribs()
/* 11:   */   {
/* 12:49 */     this(2);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public ContextAttribs(int version)
/* 16:   */   {
/* 17:53 */     if (3 < version) {
/* 18:54 */       throw new IllegalArgumentException("Invalid OpenGL ES version specified: " + version);
/* 19:   */     }
/* 20:56 */     this.version = version;
/* 21:   */   }
/* 22:   */   
/* 23:   */   private ContextAttribs(ContextAttribs attribs)
/* 24:   */   {
/* 25:60 */     this.version = attribs.version;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public int getVersion()
/* 29:   */   {
/* 30:64 */     return this.version;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public IntBuffer getAttribList()
/* 34:   */   {
/* 35:68 */     int attribCount = 1;
/* 36:   */     
/* 37:70 */     IntBuffer attribs = BufferUtils.createIntBuffer(attribCount * 2 + 1);
/* 38:   */     
/* 39:72 */     attribs.put(12440).put(this.version);
/* 40:   */     
/* 41:74 */     attribs.put(12344);
/* 42:75 */     attribs.rewind();
/* 43:76 */     return attribs;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public String toString()
/* 47:   */   {
/* 48:80 */     StringBuilder sb = new StringBuilder(32);
/* 49:   */     
/* 50:82 */     sb.append("ContextAttribs:");
/* 51:83 */     sb.append(" Version=").append(this.version);
/* 52:   */     
/* 53:85 */     return sb.toString();
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengles.ContextAttribs
 * JD-Core Version:    0.7.0.1
 */