package org.lwjgl.opengl;

public final class ARBFramebufferSRGB
{
  public static final int GLX_FRAMEBUFFER_SRGB_CAPABLE_ARB = 8370;
  public static final int WGL_FRAMEBUFFER_SRGB_CAPABLE_ARB = 8361;
  public static final int GL_FRAMEBUFFER_SRGB_ARB = 36281;
  public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_ARB = 36282;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBFramebufferSRGB
 * JD-Core Version:    0.7.0.1
 */