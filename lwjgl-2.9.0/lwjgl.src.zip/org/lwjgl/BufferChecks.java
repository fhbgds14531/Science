/*   1:    */ 
/*   2:    */ 
/*   3:    */ java.nio.Buffer
/*   4:    */ java.nio.ByteBuffer
/*   5:    */ java.nio.DoubleBuffer
/*   6:    */ java.nio.FloatBuffer
/*   7:    */ java.nio.IntBuffer
/*   8:    */ java.nio.LongBuffer
/*   9:    */ java.nio.ShortBuffer
/*  10:    */ 
/*  11:    */ BufferChecks
/*  12:    */ 
/*  13:    */   checkFunctionAddress
/*  14:    */   
/*  15: 57 */      (CHECKS==0L {
/*  16: 58 */       "Function is not supported"
/*  17:    */     
/*  18:    */   
/*  19:    */   
/*  20:    */   checkNullTerminated
/*  21:    */   
/*  22: 66 */      (CHECKSgetlimit()1!=0 {
/*  23: 67 */       "Missing null termination"
/*  24:    */     
/*  25:    */   
/*  26:    */   
/*  27:    */   checkNullTerminated, 
/*  28:    */   
/*  29: 72 */      (CHECKS
/*  30:    */     
/*  31: 73 */        = 0
/*  32: 74 */        ( = position(); <limit(); ++ {
/*  33: 75 */          (get==0 {
/*  34: 76 */           ++
/*  35:    */         
/*  36:    */       
/*  37: 79 */        (< {
/*  38: 80 */         "Missing null termination"
/*  39:    */       
/*  40:    */     
/*  41:    */   
/*  42:    */   
/*  43:    */   checkNullTerminated
/*  44:    */   
/*  45: 86 */      (CHECKSgetlimit()1!=0 {
/*  46: 87 */       "Missing null termination"
/*  47:    */     
/*  48:    */   
/*  49:    */   
/*  50:    */   checkNullTerminated
/*  51:    */   
/*  52: 93 */      (CHECKSgetlimit()1!=0L {
/*  53: 94 */       "Missing null termination"
/*  54:    */     
/*  55:    */   
/*  56:    */   
/*  57:    */   checkNullTerminated
/*  58:    */   
/*  59:100 */      (CHECKSgetlimit()1!=0L {
/*  60:101 */       "Missing null termination"
/*  61:    */     
/*  62:    */   
/*  63:    */   
/*  64:    */   checkNotNull
/*  65:    */   
/*  66:106 */      (CHECKS== {
/*  67:107 */       "Null argument"
/*  68:    */     
/*  69:    */   
/*  70:    */   
/*  71:    */   checkDirect
/*  72:    */   
/*  73:114 */      (CHECKSisDirect() {
/*  74:115 */       "ByteBuffer is not direct"
/*  75:    */     
/*  76:    */   
/*  77:    */   
/*  78:    */   checkDirect
/*  79:    */   
/*  80:120 */      (CHECKSisDirect() {
/*  81:121 */       "ShortBuffer is not direct"
/*  82:    */     
/*  83:    */   
/*  84:    */   
/*  85:    */   checkDirect
/*  86:    */   
/*  87:126 */      (CHECKSisDirect() {
/*  88:127 */       "IntBuffer is not direct"
/*  89:    */     
/*  90:    */   
/*  91:    */   
/*  92:    */   checkDirect
/*  93:    */   
/*  94:132 */      (CHECKSisDirect() {
/*  95:133 */       "LongBuffer is not direct"
/*  96:    */     
/*  97:    */   
/*  98:    */   
/*  99:    */   checkDirect
/* 100:    */   
/* 101:138 */      (CHECKSisDirect() {
/* 102:139 */       "FloatBuffer is not direct"
/* 103:    */     
/* 104:    */   
/* 105:    */   
/* 106:    */   checkDirect
/* 107:    */   
/* 108:144 */      (CHECKSisDirect() {
/* 109:145 */       "DoubleBuffer is not direct"
/* 110:    */     
/* 111:    */   
/* 112:    */   
/* 113:    */   checkDirect {}
/* 114:    */   
/* 115:    */   checkArray[]
/* 116:    */   
/* 117:154 */      (CHECKS==length==0 {
/* 118:155 */       "Invalid array"
/* 119:    */     
/* 120:    */   
/* 121:    */   
/* 122:    */   throwBufferSizeException, 
/* 123:    */   
/* 124:162 */     "Number of remaining buffer elements is "remaining()", must be at least "". Because at most "" elements can be returned, a buffer with at least "" elements is required, regardless of actual returned element count"
/* 125:    */   
/* 126:    */   
/* 127:    */   throwBufferSizeException, 
/* 128:    */   
/* 129:166 */     "Number of remaining pointer buffer elements is "remaining()", must be at least "
/* 130:    */   
/* 131:    */   
/* 132:    */   throwArraySizeException[], 
/* 133:    */   
/* 134:170 */     "Number of array elements is "length", must be at least "
/* 135:    */   
/* 136:    */   
/* 137:    */   throwArraySizeException[], 
/* 138:    */   
/* 139:174 */     "Number of array elements is "length", must be at least "
/* 140:    */   
/* 141:    */   
/* 142:    */   checkBufferSize, 
/* 143:    */   
/* 144:188 */      (CHECKSremaining()< {
/* 145:189 */       throwBufferSizeException, 
/* 146:    */     
/* 147:    */   
/* 148:    */   
/* 149:    */   checkBuffer, 
/* 150:    */   
/* 151:    */     
/* 152:204 */      (
/* 153:    */     
/* 154:205 */       checkBuffer, 
/* 155:206 */        = 0
/* 156:    */     
/* 157:    */     
/* 158:    */     
/* 159:    */       
/* 160:207 */        (
/* 161:    */       
/* 162:208 */         checkBuffer, 
/* 163:209 */          = 1
/* 164:    */       
/* 165:    */       
/* 166:    */       
/* 167:    */         
/* 168:210 */          (
/* 169:    */         
/* 170:211 */           checkBuffer, 
/* 171:212 */            = 2
/* 172:    */         
/* 173:    */         
/* 174:    */         
/* 175:    */           
/* 176:213 */            (
/* 177:    */           
/* 178:214 */             checkBuffer, 
/* 179:215 */              = 4
/* 180:    */           
/* 181:    */           
/* 182:    */           
/* 183:    */             
/* 184:216 */              (
/* 185:    */             
/* 186:217 */               checkBuffer, 
/* 187:218 */                = 2
/* 188:    */             
/* 189:    */             
/* 190:    */             
/* 191:    */               
/* 192:219 */                (
/* 193:    */               
/* 194:220 */                 checkBuffer, 
/* 195:221 */                  = 4
/* 196:    */               
/* 197:    */               
/* 198:    */               
/* 199:223 */                 "Unsupported Buffer type specified: "getClass()
/* 200:    */               
/* 201:    */             
/* 202:    */           
/* 203:    */         
/* 204:    */       
/* 205:    */     
/* 206:    */     
/* 207:225 */     position()
/* 208:    */   
/* 209:    */   
/* 210:    */   checkBuffer, 
/* 211:    */   
/* 212:229 */      (CHECKS
/* 213:    */     
/* 214:230 */       checkBufferSize, 
/* 215:231 */       checkDirect
/* 216:    */     
/* 217:    */   
/* 218:    */   
/* 219:    */   checkBuffer, 
/* 220:    */   
/* 221:236 */      (CHECKS
/* 222:    */     
/* 223:237 */       checkBufferSize, 
/* 224:238 */       checkDirect
/* 225:    */     
/* 226:    */   
/* 227:    */   
/* 228:    */   checkBuffer, 
/* 229:    */   
/* 230:243 */      (CHECKS
/* 231:    */     
/* 232:244 */       checkBufferSize, 
/* 233:245 */       checkDirect
/* 234:    */     
/* 235:    */   
/* 236:    */   
/* 237:    */   checkBuffer, 
/* 238:    */   
/* 239:250 */      (CHECKS
/* 240:    */     
/* 241:251 */       checkBufferSize, 
/* 242:252 */       checkDirect
/* 243:    */     
/* 244:    */   
/* 245:    */   
/* 246:    */   checkBuffer, 
/* 247:    */   
/* 248:257 */      (CHECKS
/* 249:    */     
/* 250:258 */       checkBufferSize, 
/* 251:259 */       checkDirect
/* 252:    */     
/* 253:    */   
/* 254:    */   
/* 255:    */   checkBuffer, 
/* 256:    */   
/* 257:264 */      (CHECKS
/* 258:    */     
/* 259:265 */       checkBufferSize, 
/* 260:266 */       checkDirect
/* 261:    */     
/* 262:    */   
/* 263:    */   
/* 264:    */   checkBuffer, 
/* 265:    */   
/* 266:271 */      (CHECKSremaining()< {
/* 267:272 */       throwBufferSizeException, 
/* 268:    */     
/* 269:    */   
/* 270:    */   
/* 271:    */   checkArray[], 
/* 272:    */   
/* 273:277 */      (CHECKSlength< {
/* 274:278 */       throwArraySizeException, 
/* 275:    */     
/* 276:    */   
/* 277:    */   
/* 278:    */   checkArray[], 
/* 279:    */   
/* 280:282 */      (CHECKSlength< {
/* 281:283 */       throwArraySizeException, 
/* 282:    */     
/* 283:    */   
/* 284:    */ 


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.BufferChecks
 * JD-Core Version:    0.7.0.1
 */