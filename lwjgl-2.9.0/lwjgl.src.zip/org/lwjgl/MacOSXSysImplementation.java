/*  1:   */ package org.lwjgl;
/*  2:   */ 
/*  3:   */ import com.apple.eio.FileManager;
/*  4:   */ import java.awt.Toolkit;
/*  5:   */ 
/*  6:   */ final class MacOSXSysImplementation
/*  7:   */   extends J2SESysImplementation
/*  8:   */ {
/*  9:   */   private static final int JNI_VERSION = 25;
/* 10:   */   
/* 11:   */   static
/* 12:   */   {
/* 13:51 */     Toolkit.getDefaultToolkit();
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getRequiredJNIVersion()
/* 17:   */   {
/* 18:55 */     return 25;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean openURL(String url)
/* 22:   */   {
/* 23:   */     try
/* 24:   */     {
/* 25:60 */       FileManager.openURL(url);
/* 26:61 */       return true;
/* 27:   */     }
/* 28:   */     catch (Exception e)
/* 29:   */     {
/* 30:63 */       LWJGLUtil.log("Exception occurred while trying to invoke browser: " + e);
/* 31:   */     }
/* 32:64 */     return false;
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.MacOSXSysImplementation
 * JD-Core Version:    0.7.0.1
 */