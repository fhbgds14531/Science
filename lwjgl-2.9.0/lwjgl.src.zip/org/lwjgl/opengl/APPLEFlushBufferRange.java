/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class APPLEFlushBufferRange
/*  6:   */ {
/*  7:   */   public static final int GL_BUFFER_SERIALIZED_MODIFY_APPLE = 35346;
/*  8:   */   public static final int GL_BUFFER_FLUSHING_UNMAP_APPLE = 35347;
/*  9:   */   
/* 10:   */   public static void glBufferParameteriAPPLE(int target, int pname, int param)
/* 11:   */   {
/* 12:20 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:21 */     long function_pointer = caps.glBufferParameteriAPPLE;
/* 14:22 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:23 */     nglBufferParameteriAPPLE(target, pname, param, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglBufferParameteriAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 19:   */   
/* 20:   */   public static void glFlushMappedBufferRangeAPPLE(int target, long offset, long size)
/* 21:   */   {
/* 22:28 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:29 */     long function_pointer = caps.glFlushMappedBufferRangeAPPLE;
/* 24:30 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:31 */     nglFlushMappedBufferRangeAPPLE(target, offset, size, function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglFlushMappedBufferRangeAPPLE(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 29:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEFlushBufferRange
 * JD-Core Version:    0.7.0.1
 */