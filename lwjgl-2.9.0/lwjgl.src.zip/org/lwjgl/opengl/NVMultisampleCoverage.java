package org.lwjgl.opengl;

public final class NVMultisampleCoverage
{
  public static final int GL_COVERAGE_SAMPLES_NV = 32937;
  public static final int GL_COLOR_SAMPLES_NV = 36384;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVMultisampleCoverage
 * JD-Core Version:    0.7.0.1
 */