/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVDepthBufferFloat
/*  6:   */ {
/*  7:   */   public static final int GL_DEPTH_COMPONENT32F_NV = 36267;
/*  8:   */   public static final int GL_DEPTH32F_STENCIL8_NV = 36268;
/*  9:   */   public static final int GL_FLOAT_32_UNSIGNED_INT_24_8_REV_NV = 36269;
/* 10:   */   public static final int GL_DEPTH_BUFFER_FLOAT_MODE_NV = 36271;
/* 11:   */   
/* 12:   */   public static void glDepthRangedNV(double n, double f)
/* 13:   */   {
/* 14:35 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:36 */     long function_pointer = caps.glDepthRangedNV;
/* 16:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:38 */     nglDepthRangedNV(n, f, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglDepthRangedNV(double paramDouble1, double paramDouble2, long paramLong);
/* 21:   */   
/* 22:   */   public static void glClearDepthdNV(double d)
/* 23:   */   {
/* 24:43 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:44 */     long function_pointer = caps.glClearDepthdNV;
/* 26:45 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:46 */     nglClearDepthdNV(d, function_pointer);
/* 28:   */   }
/* 29:   */   
/* 30:   */   static native void nglClearDepthdNV(double paramDouble, long paramLong);
/* 31:   */   
/* 32:   */   public static void glDepthBoundsdNV(double zmin, double zmax)
/* 33:   */   {
/* 34:51 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 35:52 */     long function_pointer = caps.glDepthBoundsdNV;
/* 36:53 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 37:54 */     nglDepthBoundsdNV(zmin, zmax, function_pointer);
/* 38:   */   }
/* 39:   */   
/* 40:   */   static native void nglDepthBoundsdNV(double paramDouble1, double paramDouble2, long paramLong);
/* 41:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVDepthBufferFloat
 * JD-Core Version:    0.7.0.1
 */