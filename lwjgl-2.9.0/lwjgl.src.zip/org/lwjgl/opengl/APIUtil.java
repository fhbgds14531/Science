/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.LongBuffer;
/*   8:    */ import org.lwjgl.BufferUtils;
/*   9:    */ import org.lwjgl.LWJGLUtil;
/*  10:    */ import org.lwjgl.MemoryUtil;
/*  11:    */ 
/*  12:    */ final class APIUtil
/*  13:    */ {
/*  14:    */   private static final int INITIAL_BUFFER_SIZE = 256;
/*  15:    */   private static final int INITIAL_LENGTHS_SIZE = 4;
/*  16:    */   private static final int BUFFERS_SIZE = 32;
/*  17:    */   private char[] array;
/*  18:    */   private ByteBuffer buffer;
/*  19:    */   private IntBuffer lengths;
/*  20:    */   private final IntBuffer ints;
/*  21:    */   private final LongBuffer longs;
/*  22:    */   private final FloatBuffer floats;
/*  23:    */   private final DoubleBuffer doubles;
/*  24:    */   
/*  25:    */   APIUtil()
/*  26:    */   {
/*  27: 63 */     this.array = new char[256];
/*  28: 64 */     this.buffer = BufferUtils.createByteBuffer(256);
/*  29: 65 */     this.lengths = BufferUtils.createIntBuffer(4);
/*  30:    */     
/*  31: 67 */     this.ints = BufferUtils.createIntBuffer(32);
/*  32: 68 */     this.longs = BufferUtils.createLongBuffer(32);
/*  33:    */     
/*  34: 70 */     this.floats = BufferUtils.createFloatBuffer(32);
/*  35: 71 */     this.doubles = BufferUtils.createDoubleBuffer(32);
/*  36:    */   }
/*  37:    */   
/*  38:    */   private static char[] getArray(ContextCapabilities caps, int size)
/*  39:    */   {
/*  40: 75 */     char[] array = caps.util.array;
/*  41: 77 */     if (array.length < size)
/*  42:    */     {
/*  43: 78 */       int sizeNew = array.length << 1;
/*  44: 79 */       while (sizeNew < size) {
/*  45: 80 */         sizeNew <<= 1;
/*  46:    */       }
/*  47: 82 */       array = new char[size];
/*  48: 83 */       caps.util.array = array;
/*  49:    */     }
/*  50: 86 */     return array;
/*  51:    */   }
/*  52:    */   
/*  53:    */   static ByteBuffer getBufferByte(ContextCapabilities caps, int size)
/*  54:    */   {
/*  55: 90 */     ByteBuffer buffer = caps.util.buffer;
/*  56: 92 */     if (buffer.capacity() < size)
/*  57:    */     {
/*  58: 93 */       int sizeNew = buffer.capacity() << 1;
/*  59: 94 */       while (sizeNew < size) {
/*  60: 95 */         sizeNew <<= 1;
/*  61:    */       }
/*  62: 97 */       buffer = BufferUtils.createByteBuffer(size);
/*  63: 98 */       caps.util.buffer = buffer;
/*  64:    */     }
/*  65:    */     else
/*  66:    */     {
/*  67:100 */       buffer.clear();
/*  68:    */     }
/*  69:102 */     return buffer;
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static ByteBuffer getBufferByteOffset(ContextCapabilities caps, int size)
/*  73:    */   {
/*  74:106 */     ByteBuffer buffer = caps.util.buffer;
/*  75:108 */     if (buffer.capacity() < size)
/*  76:    */     {
/*  77:109 */       int sizeNew = buffer.capacity() << 1;
/*  78:110 */       while (sizeNew < size) {
/*  79:111 */         sizeNew <<= 1;
/*  80:    */       }
/*  81:113 */       ByteBuffer bufferNew = BufferUtils.createByteBuffer(size);
/*  82:114 */       bufferNew.put(buffer);
/*  83:115 */       caps.util.buffer = (buffer = bufferNew);
/*  84:    */     }
/*  85:    */     else
/*  86:    */     {
/*  87:117 */       buffer.position(buffer.limit());
/*  88:118 */       buffer.limit(buffer.capacity());
/*  89:    */     }
/*  90:121 */     return buffer;
/*  91:    */   }
/*  92:    */   
/*  93:    */   static IntBuffer getBufferInt(ContextCapabilities caps)
/*  94:    */   {
/*  95:124 */     return caps.util.ints;
/*  96:    */   }
/*  97:    */   
/*  98:    */   static LongBuffer getBufferLong(ContextCapabilities caps)
/*  99:    */   {
/* 100:126 */     return caps.util.longs;
/* 101:    */   }
/* 102:    */   
/* 103:    */   static FloatBuffer getBufferFloat(ContextCapabilities caps)
/* 104:    */   {
/* 105:128 */     return caps.util.floats;
/* 106:    */   }
/* 107:    */   
/* 108:    */   static DoubleBuffer getBufferDouble(ContextCapabilities caps)
/* 109:    */   {
/* 110:130 */     return caps.util.doubles;
/* 111:    */   }
/* 112:    */   
/* 113:    */   static IntBuffer getLengths(ContextCapabilities caps)
/* 114:    */   {
/* 115:133 */     return getLengths(caps, 1);
/* 116:    */   }
/* 117:    */   
/* 118:    */   static IntBuffer getLengths(ContextCapabilities caps, int size)
/* 119:    */   {
/* 120:137 */     IntBuffer lengths = caps.util.lengths;
/* 121:139 */     if (lengths.capacity() < size)
/* 122:    */     {
/* 123:140 */       int sizeNew = lengths.capacity();
/* 124:141 */       while (sizeNew < size) {
/* 125:142 */         sizeNew <<= 1;
/* 126:    */       }
/* 127:144 */       lengths = BufferUtils.createIntBuffer(size);
/* 128:145 */       caps.util.lengths = lengths;
/* 129:    */     }
/* 130:    */     else
/* 131:    */     {
/* 132:147 */       lengths.clear();
/* 133:    */     }
/* 134:149 */     return lengths;
/* 135:    */   }
/* 136:    */   
/* 137:    */   private static ByteBuffer encode(ByteBuffer buffer, CharSequence string)
/* 138:    */   {
/* 139:159 */     for (int i = 0; i < string.length(); i++)
/* 140:    */     {
/* 141:160 */       char c = string.charAt(i);
/* 142:161 */       if ((LWJGLUtil.DEBUG) && ('' <= c)) {
/* 143:162 */         buffer.put((byte)26);
/* 144:    */       } else {
/* 145:164 */         buffer.put((byte)c);
/* 146:    */       }
/* 147:    */     }
/* 148:167 */     return buffer;
/* 149:    */   }
/* 150:    */   
/* 151:    */   static String getString(ContextCapabilities caps, ByteBuffer buffer)
/* 152:    */   {
/* 153:178 */     int length = buffer.remaining();
/* 154:179 */     char[] charArray = getArray(caps, length);
/* 155:181 */     for (int i = buffer.position(); i < buffer.limit(); i++) {
/* 156:182 */       charArray[(i - buffer.position())] = ((char)buffer.get(i));
/* 157:    */     }
/* 158:184 */     return new String(charArray, 0, length);
/* 159:    */   }
/* 160:    */   
/* 161:    */   static long getBuffer(ContextCapabilities caps, CharSequence string)
/* 162:    */   {
/* 163:195 */     ByteBuffer buffer = encode(getBufferByte(caps, string.length()), string);
/* 164:196 */     buffer.flip();
/* 165:197 */     return MemoryUtil.getAddress0(buffer);
/* 166:    */   }
/* 167:    */   
/* 168:    */   static long getBuffer(ContextCapabilities caps, CharSequence string, int offset)
/* 169:    */   {
/* 170:208 */     ByteBuffer buffer = encode(getBufferByteOffset(caps, offset + string.length()), string);
/* 171:209 */     buffer.flip();
/* 172:210 */     return MemoryUtil.getAddress(buffer);
/* 173:    */   }
/* 174:    */   
/* 175:    */   static long getBufferNT(ContextCapabilities caps, CharSequence string)
/* 176:    */   {
/* 177:221 */     ByteBuffer buffer = encode(getBufferByte(caps, string.length() + 1), string);
/* 178:222 */     buffer.put((byte)0);
/* 179:223 */     buffer.flip();
/* 180:224 */     return MemoryUtil.getAddress0(buffer);
/* 181:    */   }
/* 182:    */   
/* 183:    */   static int getTotalLength(CharSequence[] strings)
/* 184:    */   {
/* 185:228 */     int length = 0;
/* 186:229 */     for (CharSequence string : strings) {
/* 187:230 */       length += string.length();
/* 188:    */     }
/* 189:232 */     return length;
/* 190:    */   }
/* 191:    */   
/* 192:    */   static long getBuffer(ContextCapabilities caps, CharSequence[] strings)
/* 193:    */   {
/* 194:243 */     ByteBuffer buffer = getBufferByte(caps, getTotalLength(strings));
/* 195:245 */     for (CharSequence string : strings) {
/* 196:246 */       encode(buffer, string);
/* 197:    */     }
/* 198:248 */     buffer.flip();
/* 199:249 */     return MemoryUtil.getAddress0(buffer);
/* 200:    */   }
/* 201:    */   
/* 202:    */   static long getBufferNT(ContextCapabilities caps, CharSequence[] strings)
/* 203:    */   {
/* 204:260 */     ByteBuffer buffer = getBufferByte(caps, getTotalLength(strings) + strings.length);
/* 205:262 */     for (CharSequence string : strings)
/* 206:    */     {
/* 207:263 */       encode(buffer, string);
/* 208:264 */       buffer.put((byte)0);
/* 209:    */     }
/* 210:267 */     buffer.flip();
/* 211:268 */     return MemoryUtil.getAddress0(buffer);
/* 212:    */   }
/* 213:    */   
/* 214:    */   static long getLengths(ContextCapabilities caps, CharSequence[] strings)
/* 215:    */   {
/* 216:279 */     IntBuffer buffer = getLengths(caps, strings.length);
/* 217:281 */     for (CharSequence string : strings) {
/* 218:282 */       buffer.put(string.length());
/* 219:    */     }
/* 220:284 */     buffer.flip();
/* 221:285 */     return MemoryUtil.getAddress0(buffer);
/* 222:    */   }
/* 223:    */   
/* 224:    */   static long getInt(ContextCapabilities caps, int value)
/* 225:    */   {
/* 226:289 */     return MemoryUtil.getAddress0(getBufferInt(caps).put(0, value));
/* 227:    */   }
/* 228:    */   
/* 229:    */   static long getBufferByte0(ContextCapabilities caps)
/* 230:    */   {
/* 231:293 */     return MemoryUtil.getAddress0(getBufferByte(caps, 0));
/* 232:    */   }
/* 233:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APIUtil
 * JD-Core Version:    0.7.0.1
 */