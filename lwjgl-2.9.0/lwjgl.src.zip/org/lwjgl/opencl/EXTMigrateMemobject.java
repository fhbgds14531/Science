/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ import org.lwjgl.MemoryUtil;
/*  5:   */ import org.lwjgl.PointerBuffer;
/*  6:   */ 
/*  7:   */ public final class EXTMigrateMemobject
/*  8:   */ {
/*  9:   */   public static final int CL_MIGRATE_MEM_OBJECT_HOST_EXT = 1;
/* 10:   */   public static final int CL_COMMAND_MIGRATE_MEM_OBJECT_EXT = 16448;
/* 11:   */   
/* 12:   */   public static int clEnqueueMigrateMemObjectEXT(CLCommandQueue command_queue, PointerBuffer mem_objects, long flags, PointerBuffer event_wait_list, PointerBuffer event)
/* 13:   */   {
/* 14:25 */     long function_pointer = CLCapabilities.clEnqueueMigrateMemObjectEXT;
/* 15:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:27 */     BufferChecks.checkBuffer(mem_objects, 1);
/* 17:28 */     if (event_wait_list != null) {
/* 18:29 */       BufferChecks.checkDirect(event_wait_list);
/* 19:   */     }
/* 20:30 */     if (event != null) {
/* 21:31 */       BufferChecks.checkBuffer(event, 1);
/* 22:   */     }
/* 23:32 */     int __result = nclEnqueueMigrateMemObjectEXT(command_queue.getPointer(), mem_objects.remaining(), MemoryUtil.getAddress(mem_objects), flags, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 24:33 */     if (__result == 0) {
/* 25:33 */       command_queue.registerCLEvent(event);
/* 26:   */     }
/* 27:34 */     return __result;
/* 28:   */   }
/* 29:   */   
/* 30:   */   static native int nclEnqueueMigrateMemObjectEXT(long paramLong1, int paramInt1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, long paramLong5, long paramLong6);
/* 31:   */   
/* 32:   */   public static int clEnqueueMigrateMemObjectEXT(CLCommandQueue command_queue, CLMem mem_object, long flags, PointerBuffer event_wait_list, PointerBuffer event)
/* 33:   */   {
/* 34:40 */     long function_pointer = CLCapabilities.clEnqueueMigrateMemObjectEXT;
/* 35:41 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:42 */     if (event_wait_list != null) {
/* 37:43 */       BufferChecks.checkDirect(event_wait_list);
/* 38:   */     }
/* 39:44 */     if (event != null) {
/* 40:45 */       BufferChecks.checkBuffer(event, 1);
/* 41:   */     }
/* 42:46 */     int __result = nclEnqueueMigrateMemObjectEXT(command_queue.getPointer(), 1, APIUtil.getPointer(mem_object), flags, event_wait_list == null ? 0 : event_wait_list.remaining(), MemoryUtil.getAddressSafe(event_wait_list), MemoryUtil.getAddressSafe(event), function_pointer);
/* 43:47 */     if (__result == 0) {
/* 44:47 */       command_queue.registerCLEvent(event);
/* 45:   */     }
/* 46:48 */     return __result;
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.EXTMigrateMemobject
 * JD-Core Version:    0.7.0.1
 */