/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVOcclusionQuery
/*   8:    */ {
/*   9:    */   public static final int GL_OCCLUSION_TEST_HP = 33125;
/*  10:    */   public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;
/*  11:    */   public static final int GL_PIXEL_COUNTER_BITS_NV = 34916;
/*  12:    */   public static final int GL_CURRENT_OCCLUSION_QUERY_ID_NV = 34917;
/*  13:    */   public static final int GL_PIXEL_COUNT_NV = 34918;
/*  14:    */   public static final int GL_PIXEL_COUNT_AVAILABLE_NV = 34919;
/*  15:    */   
/*  16:    */   public static void glGenOcclusionQueriesNV(IntBuffer piIDs)
/*  17:    */   {
/*  18: 20 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  19: 21 */     long function_pointer = caps.glGenOcclusionQueriesNV;
/*  20: 22 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  21: 23 */     BufferChecks.checkDirect(piIDs);
/*  22: 24 */     nglGenOcclusionQueriesNV(piIDs.remaining(), MemoryUtil.getAddress(piIDs), function_pointer);
/*  23:    */   }
/*  24:    */   
/*  25:    */   static native void nglGenOcclusionQueriesNV(int paramInt, long paramLong1, long paramLong2);
/*  26:    */   
/*  27:    */   public static int glGenOcclusionQueriesNV()
/*  28:    */   {
/*  29: 30 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  30: 31 */     long function_pointer = caps.glGenOcclusionQueriesNV;
/*  31: 32 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  32: 33 */     IntBuffer piIDs = APIUtil.getBufferInt(caps);
/*  33: 34 */     nglGenOcclusionQueriesNV(1, MemoryUtil.getAddress(piIDs), function_pointer);
/*  34: 35 */     return piIDs.get(0);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void glDeleteOcclusionQueriesNV(IntBuffer piIDs)
/*  38:    */   {
/*  39: 39 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  40: 40 */     long function_pointer = caps.glDeleteOcclusionQueriesNV;
/*  41: 41 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  42: 42 */     BufferChecks.checkDirect(piIDs);
/*  43: 43 */     nglDeleteOcclusionQueriesNV(piIDs.remaining(), MemoryUtil.getAddress(piIDs), function_pointer);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static native void nglDeleteOcclusionQueriesNV(int paramInt, long paramLong1, long paramLong2);
/*  47:    */   
/*  48:    */   public static void glDeleteOcclusionQueriesNV(int piID)
/*  49:    */   {
/*  50: 49 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  51: 50 */     long function_pointer = caps.glDeleteOcclusionQueriesNV;
/*  52: 51 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  53: 52 */     nglDeleteOcclusionQueriesNV(1, APIUtil.getInt(caps, piID), function_pointer);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static boolean glIsOcclusionQueryNV(int id)
/*  57:    */   {
/*  58: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  59: 57 */     long function_pointer = caps.glIsOcclusionQueryNV;
/*  60: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 59 */     boolean __result = nglIsOcclusionQueryNV(id, function_pointer);
/*  62: 60 */     return __result;
/*  63:    */   }
/*  64:    */   
/*  65:    */   static native boolean nglIsOcclusionQueryNV(int paramInt, long paramLong);
/*  66:    */   
/*  67:    */   public static void glBeginOcclusionQueryNV(int id)
/*  68:    */   {
/*  69: 65 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  70: 66 */     long function_pointer = caps.glBeginOcclusionQueryNV;
/*  71: 67 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  72: 68 */     nglBeginOcclusionQueryNV(id, function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   static native void nglBeginOcclusionQueryNV(int paramInt, long paramLong);
/*  76:    */   
/*  77:    */   public static void glEndOcclusionQueryNV()
/*  78:    */   {
/*  79: 73 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  80: 74 */     long function_pointer = caps.glEndOcclusionQueryNV;
/*  81: 75 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  82: 76 */     nglEndOcclusionQueryNV(function_pointer);
/*  83:    */   }
/*  84:    */   
/*  85:    */   static native void nglEndOcclusionQueryNV(long paramLong);
/*  86:    */   
/*  87:    */   public static void glGetOcclusionQueryuNV(int id, int pname, IntBuffer params)
/*  88:    */   {
/*  89: 81 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  90: 82 */     long function_pointer = caps.glGetOcclusionQueryuivNV;
/*  91: 83 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  92: 84 */     BufferChecks.checkBuffer(params, 1);
/*  93: 85 */     nglGetOcclusionQueryuivNV(id, pname, MemoryUtil.getAddress(params), function_pointer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   static native void nglGetOcclusionQueryuivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  97:    */   
/*  98:    */   public static int glGetOcclusionQueryuiNV(int id, int pname)
/*  99:    */   {
/* 100: 91 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 101: 92 */     long function_pointer = caps.glGetOcclusionQueryuivNV;
/* 102: 93 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 103: 94 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 104: 95 */     nglGetOcclusionQueryuivNV(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 105: 96 */     return params.get(0);
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static void glGetOcclusionQueryNV(int id, int pname, IntBuffer params)
/* 109:    */   {
/* 110:100 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 111:101 */     long function_pointer = caps.glGetOcclusionQueryivNV;
/* 112:102 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 113:103 */     BufferChecks.checkBuffer(params, 1);
/* 114:104 */     nglGetOcclusionQueryivNV(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 115:    */   }
/* 116:    */   
/* 117:    */   static native void nglGetOcclusionQueryivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 118:    */   
/* 119:    */   public static int glGetOcclusionQueryiNV(int id, int pname)
/* 120:    */   {
/* 121:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 122:111 */     long function_pointer = caps.glGetOcclusionQueryivNV;
/* 123:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 124:113 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 125:114 */     nglGetOcclusionQueryivNV(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 126:115 */     return params.get(0);
/* 127:    */   }
/* 128:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVOcclusionQuery
 * JD-Core Version:    0.7.0.1
 */