/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import net.java.games.input.Controller.Type;
/*   5:    */ import net.java.games.input.ControllerEnvironment;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ 
/*   8:    */ public class Controllers
/*   9:    */ {
/*  10: 47 */   private static ArrayList<JInputController> controllers = new ArrayList();
/*  11:    */   private static int controllerCount;
/*  12: 52 */   private static ArrayList<ControllerEvent> events = new ArrayList();
/*  13:    */   private static ControllerEvent event;
/*  14:    */   private static boolean created;
/*  15:    */   
/*  16:    */   public static void create()
/*  17:    */     throws LWJGLException
/*  18:    */   {
/*  19: 65 */     if (created) {
/*  20: 66 */       return;
/*  21:    */     }
/*  22:    */     try
/*  23:    */     {
/*  24: 69 */       ControllerEnvironment env = ControllerEnvironment.getDefaultEnvironment();
/*  25:    */       
/*  26: 71 */       net.java.games.input.Controller[] found = env.getControllers();
/*  27: 72 */       ArrayList<net.java.games.input.Controller> lollers = new ArrayList();
/*  28: 73 */       for (net.java.games.input.Controller c : found) {
/*  29: 74 */         if ((!c.getType().equals(Controller.Type.KEYBOARD)) && (!c.getType().equals(Controller.Type.MOUSE))) {
/*  30: 76 */           lollers.add(c);
/*  31:    */         }
/*  32:    */       }
/*  33: 80 */       for (net.java.games.input.Controller c : lollers) {
/*  34: 81 */         createController(c);
/*  35:    */       }
/*  36: 84 */       created = true;
/*  37:    */     }
/*  38:    */     catch (Throwable e)
/*  39:    */     {
/*  40: 86 */       throw new LWJGLException("Failed to initialise controllers", e);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static void createController(net.java.games.input.Controller c)
/*  45:    */   {
/*  46: 96 */     net.java.games.input.Controller[] subControllers = c.getControllers();
/*  47: 97 */     if (subControllers.length == 0)
/*  48:    */     {
/*  49: 98 */       JInputController controller = new JInputController(controllerCount, c);
/*  50:    */       
/*  51:100 */       controllers.add(controller);
/*  52:101 */       controllerCount += 1;
/*  53:    */     }
/*  54:    */     else
/*  55:    */     {
/*  56:103 */       for (net.java.games.input.Controller sub : subControllers) {
/*  57:104 */         createController(sub);
/*  58:    */       }
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static Controller getController(int index)
/*  63:    */   {
/*  64:116 */     return (Controller)controllers.get(index);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static int getControllerCount()
/*  68:    */   {
/*  69:125 */     return controllers.size();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static void poll()
/*  73:    */   {
/*  74:133 */     for (int i = 0; i < controllers.size(); i++) {
/*  75:134 */       getController(i).poll();
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static void clearEvents()
/*  80:    */   {
/*  81:142 */     events.clear();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static boolean next()
/*  85:    */   {
/*  86:151 */     if (events.size() == 0)
/*  87:    */     {
/*  88:152 */       event = null;
/*  89:153 */       return false;
/*  90:    */     }
/*  91:156 */     event = (ControllerEvent)events.remove(0);
/*  92:    */     
/*  93:158 */     return event != null;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static boolean isCreated()
/*  97:    */   {
/*  98:165 */     return created;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static void destroy() {}
/* 102:    */   
/* 103:    */   public static Controller getEventSource()
/* 104:    */   {
/* 105:196 */     return event.getSource();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static int getEventControlIndex()
/* 109:    */   {
/* 110:205 */     return event.getControlIndex();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static boolean isEventButton()
/* 114:    */   {
/* 115:214 */     return event.isButton();
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static boolean isEventAxis()
/* 119:    */   {
/* 120:223 */     return event.isAxis();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static boolean isEventXAxis()
/* 124:    */   {
/* 125:232 */     return event.isXAxis();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static boolean isEventYAxis()
/* 129:    */   {
/* 130:241 */     return event.isYAxis();
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static boolean isEventPovX()
/* 134:    */   {
/* 135:250 */     return event.isPovX();
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static boolean isEventPovY()
/* 139:    */   {
/* 140:259 */     return event.isPovY();
/* 141:    */   }
/* 142:    */   
/* 143:    */   public static long getEventNanoseconds()
/* 144:    */   {
/* 145:268 */     return event.getTimeStamp();
/* 146:    */   }
/* 147:    */   
/* 148:    */   static void addEvent(ControllerEvent event)
/* 149:    */   {
/* 150:277 */     if (event != null) {
/* 151:278 */       events.add(event);
/* 152:    */     }
/* 153:    */   }
/* 154:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.Controllers
 * JD-Core Version:    0.7.0.1
 */