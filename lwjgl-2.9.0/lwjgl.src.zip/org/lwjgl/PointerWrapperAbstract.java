/*  1:   */ package org.lwjgl;
/*  2:   */ 
/*  3:   */ public abstract class PointerWrapperAbstract
/*  4:   */   implements PointerWrapper
/*  5:   */ {
/*  6:   */   protected final long pointer;
/*  7:   */   
/*  8:   */   protected PointerWrapperAbstract(long pointer)
/*  9:   */   {
/* 10:44 */     this.pointer = pointer;
/* 11:   */   }
/* 12:   */   
/* 13:   */   public boolean isValid()
/* 14:   */   {
/* 15:56 */     return this.pointer != 0L;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public final void checkValid()
/* 19:   */   {
/* 20:65 */     if ((LWJGLUtil.DEBUG) && (!isValid())) {
/* 21:66 */       throw new IllegalStateException("This " + getClass().getSimpleName() + " pointer is not valid.");
/* 22:   */     }
/* 23:   */   }
/* 24:   */   
/* 25:   */   public final long getPointer()
/* 26:   */   {
/* 27:70 */     checkValid();
/* 28:71 */     return this.pointer;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public boolean equals(Object o)
/* 32:   */   {
/* 33:75 */     if (this == o) {
/* 34:75 */       return true;
/* 35:   */     }
/* 36:76 */     if (!(o instanceof PointerWrapperAbstract)) {
/* 37:76 */       return false;
/* 38:   */     }
/* 39:78 */     PointerWrapperAbstract that = (PointerWrapperAbstract)o;
/* 40:80 */     if (this.pointer != that.pointer) {
/* 41:80 */       return false;
/* 42:   */     }
/* 43:82 */     return true;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int hashCode()
/* 47:   */   {
/* 48:86 */     return (int)(this.pointer ^ this.pointer >>> 32);
/* 49:   */   }
/* 50:   */   
/* 51:   */   public String toString()
/* 52:   */   {
/* 53:90 */     return getClass().getSimpleName() + " pointer (0x" + Long.toHexString(this.pointer).toUpperCase() + ")";
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.PointerWrapperAbstract
 * JD-Core Version:    0.7.0.1
 */