/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ShortBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVHalfFloat
/*   8:    */ {
/*   9:    */   public static final int GL_HALF_FLOAT_NV = 5131;
/*  10:    */   
/*  11:    */   public static void glVertex2hNV(short x, short y)
/*  12:    */   {
/*  13: 22 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  14: 23 */     long function_pointer = caps.glVertex2hNV;
/*  15: 24 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  16: 25 */     nglVertex2hNV(x, y, function_pointer);
/*  17:    */   }
/*  18:    */   
/*  19:    */   static native void nglVertex2hNV(short paramShort1, short paramShort2, long paramLong);
/*  20:    */   
/*  21:    */   public static void glVertex3hNV(short x, short y, short z)
/*  22:    */   {
/*  23: 30 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  24: 31 */     long function_pointer = caps.glVertex3hNV;
/*  25: 32 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  26: 33 */     nglVertex3hNV(x, y, z, function_pointer);
/*  27:    */   }
/*  28:    */   
/*  29:    */   static native void nglVertex3hNV(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/*  30:    */   
/*  31:    */   public static void glVertex4hNV(short x, short y, short z, short w)
/*  32:    */   {
/*  33: 38 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  34: 39 */     long function_pointer = caps.glVertex4hNV;
/*  35: 40 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  36: 41 */     nglVertex4hNV(x, y, z, w, function_pointer);
/*  37:    */   }
/*  38:    */   
/*  39:    */   static native void nglVertex4hNV(short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/*  40:    */   
/*  41:    */   public static void glNormal3hNV(short nx, short ny, short nz)
/*  42:    */   {
/*  43: 46 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  44: 47 */     long function_pointer = caps.glNormal3hNV;
/*  45: 48 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  46: 49 */     nglNormal3hNV(nx, ny, nz, function_pointer);
/*  47:    */   }
/*  48:    */   
/*  49:    */   static native void nglNormal3hNV(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/*  50:    */   
/*  51:    */   public static void glColor3hNV(short red, short green, short blue)
/*  52:    */   {
/*  53: 54 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  54: 55 */     long function_pointer = caps.glColor3hNV;
/*  55: 56 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  56: 57 */     nglColor3hNV(red, green, blue, function_pointer);
/*  57:    */   }
/*  58:    */   
/*  59:    */   static native void nglColor3hNV(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/*  60:    */   
/*  61:    */   public static void glColor4hNV(short red, short green, short blue, short alpha)
/*  62:    */   {
/*  63: 62 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  64: 63 */     long function_pointer = caps.glColor4hNV;
/*  65: 64 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  66: 65 */     nglColor4hNV(red, green, blue, alpha, function_pointer);
/*  67:    */   }
/*  68:    */   
/*  69:    */   static native void nglColor4hNV(short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/*  70:    */   
/*  71:    */   public static void glTexCoord1hNV(short s)
/*  72:    */   {
/*  73: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  74: 71 */     long function_pointer = caps.glTexCoord1hNV;
/*  75: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  76: 73 */     nglTexCoord1hNV(s, function_pointer);
/*  77:    */   }
/*  78:    */   
/*  79:    */   static native void nglTexCoord1hNV(short paramShort, long paramLong);
/*  80:    */   
/*  81:    */   public static void glTexCoord2hNV(short s, short t)
/*  82:    */   {
/*  83: 78 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  84: 79 */     long function_pointer = caps.glTexCoord2hNV;
/*  85: 80 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  86: 81 */     nglTexCoord2hNV(s, t, function_pointer);
/*  87:    */   }
/*  88:    */   
/*  89:    */   static native void nglTexCoord2hNV(short paramShort1, short paramShort2, long paramLong);
/*  90:    */   
/*  91:    */   public static void glTexCoord3hNV(short s, short t, short r)
/*  92:    */   {
/*  93: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  94: 87 */     long function_pointer = caps.glTexCoord3hNV;
/*  95: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  96: 89 */     nglTexCoord3hNV(s, t, r, function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglTexCoord3hNV(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 100:    */   
/* 101:    */   public static void glTexCoord4hNV(short s, short t, short r, short q)
/* 102:    */   {
/* 103: 94 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104: 95 */     long function_pointer = caps.glTexCoord4hNV;
/* 105: 96 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106: 97 */     nglTexCoord4hNV(s, t, r, q, function_pointer);
/* 107:    */   }
/* 108:    */   
/* 109:    */   static native void nglTexCoord4hNV(short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 110:    */   
/* 111:    */   public static void glMultiTexCoord1hNV(int target, short s)
/* 112:    */   {
/* 113:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 114:103 */     long function_pointer = caps.glMultiTexCoord1hNV;
/* 115:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 116:105 */     nglMultiTexCoord1hNV(target, s, function_pointer);
/* 117:    */   }
/* 118:    */   
/* 119:    */   static native void nglMultiTexCoord1hNV(int paramInt, short paramShort, long paramLong);
/* 120:    */   
/* 121:    */   public static void glMultiTexCoord2hNV(int target, short s, short t)
/* 122:    */   {
/* 123:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 124:111 */     long function_pointer = caps.glMultiTexCoord2hNV;
/* 125:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:113 */     nglMultiTexCoord2hNV(target, s, t, function_pointer);
/* 127:    */   }
/* 128:    */   
/* 129:    */   static native void nglMultiTexCoord2hNV(int paramInt, short paramShort1, short paramShort2, long paramLong);
/* 130:    */   
/* 131:    */   public static void glMultiTexCoord3hNV(int target, short s, short t, short r)
/* 132:    */   {
/* 133:118 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 134:119 */     long function_pointer = caps.glMultiTexCoord3hNV;
/* 135:120 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 136:121 */     nglMultiTexCoord3hNV(target, s, t, r, function_pointer);
/* 137:    */   }
/* 138:    */   
/* 139:    */   static native void nglMultiTexCoord3hNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 140:    */   
/* 141:    */   public static void glMultiTexCoord4hNV(int target, short s, short t, short r, short q)
/* 142:    */   {
/* 143:126 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 144:127 */     long function_pointer = caps.glMultiTexCoord4hNV;
/* 145:128 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 146:129 */     nglMultiTexCoord4hNV(target, s, t, r, q, function_pointer);
/* 147:    */   }
/* 148:    */   
/* 149:    */   static native void nglMultiTexCoord4hNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 150:    */   
/* 151:    */   public static void glFogCoordhNV(short fog)
/* 152:    */   {
/* 153:134 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 154:135 */     long function_pointer = caps.glFogCoordhNV;
/* 155:136 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 156:137 */     nglFogCoordhNV(fog, function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static native void nglFogCoordhNV(short paramShort, long paramLong);
/* 160:    */   
/* 161:    */   public static void glSecondaryColor3hNV(short red, short green, short blue)
/* 162:    */   {
/* 163:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 164:143 */     long function_pointer = caps.glSecondaryColor3hNV;
/* 165:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 166:145 */     nglSecondaryColor3hNV(red, green, blue, function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglSecondaryColor3hNV(short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 170:    */   
/* 171:    */   public static void glVertexWeighthNV(short weight)
/* 172:    */   {
/* 173:150 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:151 */     long function_pointer = caps.glVertexWeighthNV;
/* 175:152 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:153 */     nglVertexWeighthNV(weight, function_pointer);
/* 177:    */   }
/* 178:    */   
/* 179:    */   static native void nglVertexWeighthNV(short paramShort, long paramLong);
/* 180:    */   
/* 181:    */   public static void glVertexAttrib1hNV(int index, short x)
/* 182:    */   {
/* 183:158 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 184:159 */     long function_pointer = caps.glVertexAttrib1hNV;
/* 185:160 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 186:161 */     nglVertexAttrib1hNV(index, x, function_pointer);
/* 187:    */   }
/* 188:    */   
/* 189:    */   static native void nglVertexAttrib1hNV(int paramInt, short paramShort, long paramLong);
/* 190:    */   
/* 191:    */   public static void glVertexAttrib2hNV(int index, short x, short y)
/* 192:    */   {
/* 193:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 194:167 */     long function_pointer = caps.glVertexAttrib2hNV;
/* 195:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 196:169 */     nglVertexAttrib2hNV(index, x, y, function_pointer);
/* 197:    */   }
/* 198:    */   
/* 199:    */   static native void nglVertexAttrib2hNV(int paramInt, short paramShort1, short paramShort2, long paramLong);
/* 200:    */   
/* 201:    */   public static void glVertexAttrib3hNV(int index, short x, short y, short z)
/* 202:    */   {
/* 203:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 204:175 */     long function_pointer = caps.glVertexAttrib3hNV;
/* 205:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 206:177 */     nglVertexAttrib3hNV(index, x, y, z, function_pointer);
/* 207:    */   }
/* 208:    */   
/* 209:    */   static native void nglVertexAttrib3hNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 210:    */   
/* 211:    */   public static void glVertexAttrib4hNV(int index, short x, short y, short z, short w)
/* 212:    */   {
/* 213:182 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 214:183 */     long function_pointer = caps.glVertexAttrib4hNV;
/* 215:184 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 216:185 */     nglVertexAttrib4hNV(index, x, y, z, w, function_pointer);
/* 217:    */   }
/* 218:    */   
/* 219:    */   static native void nglVertexAttrib4hNV(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 220:    */   
/* 221:    */   public static void glVertexAttribs1NV(int index, ShortBuffer attribs)
/* 222:    */   {
/* 223:190 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 224:191 */     long function_pointer = caps.glVertexAttribs1hvNV;
/* 225:192 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 226:193 */     BufferChecks.checkDirect(attribs);
/* 227:194 */     nglVertexAttribs1hvNV(index, attribs.remaining(), MemoryUtil.getAddress(attribs), function_pointer);
/* 228:    */   }
/* 229:    */   
/* 230:    */   static native void nglVertexAttribs1hvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 231:    */   
/* 232:    */   public static void glVertexAttribs2NV(int index, ShortBuffer attribs)
/* 233:    */   {
/* 234:199 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 235:200 */     long function_pointer = caps.glVertexAttribs2hvNV;
/* 236:201 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 237:202 */     BufferChecks.checkDirect(attribs);
/* 238:203 */     nglVertexAttribs2hvNV(index, attribs.remaining() >> 1, MemoryUtil.getAddress(attribs), function_pointer);
/* 239:    */   }
/* 240:    */   
/* 241:    */   static native void nglVertexAttribs2hvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 242:    */   
/* 243:    */   public static void glVertexAttribs3NV(int index, ShortBuffer attribs)
/* 244:    */   {
/* 245:208 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 246:209 */     long function_pointer = caps.glVertexAttribs3hvNV;
/* 247:210 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 248:211 */     BufferChecks.checkDirect(attribs);
/* 249:212 */     nglVertexAttribs3hvNV(index, attribs.remaining() / 3, MemoryUtil.getAddress(attribs), function_pointer);
/* 250:    */   }
/* 251:    */   
/* 252:    */   static native void nglVertexAttribs3hvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 253:    */   
/* 254:    */   public static void glVertexAttribs4NV(int index, ShortBuffer attribs)
/* 255:    */   {
/* 256:217 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 257:218 */     long function_pointer = caps.glVertexAttribs4hvNV;
/* 258:219 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 259:220 */     BufferChecks.checkDirect(attribs);
/* 260:221 */     nglVertexAttribs4hvNV(index, attribs.remaining() >> 2, MemoryUtil.getAddress(attribs), function_pointer);
/* 261:    */   }
/* 262:    */   
/* 263:    */   static native void nglVertexAttribs4hvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 264:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVHalfFloat
 * JD-Core Version:    0.7.0.1
 */