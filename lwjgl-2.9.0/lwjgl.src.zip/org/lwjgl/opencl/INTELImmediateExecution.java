package org.lwjgl.opencl;

public final class INTELImmediateExecution
{
  public static final int CL_QUEUE_IMMEDIATE_EXECUTION_ENABLE_INTEL = 4;
  public static final int CL_EXEC_IMMEDIATE_EXECUTION_INTEL = 4;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.INTELImmediateExecution
 * JD-Core Version:    0.7.0.1
 */