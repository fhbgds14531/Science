package org.lwjgl.opengl;

public final class ARBDepthClamp
{
  public static final int GL_DEPTH_CLAMP = 34383;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDepthClamp
 * JD-Core Version:    0.7.0.1
 */