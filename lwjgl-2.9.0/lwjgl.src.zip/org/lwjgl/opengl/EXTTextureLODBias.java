package org.lwjgl.opengl;

public final class EXTTextureLODBias
{
  public static final int GL_TEXTURE_FILTER_CONTROL_EXT = 34048;
  public static final int GL_TEXTURE_LOD_BIAS_EXT = 34049;
  public static final int GL_MAX_TEXTURE_LOD_BIAS_EXT = 34045;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureLODBias
 * JD-Core Version:    0.7.0.1
 */