/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class ARBClearBufferObject
/*  8:   */ {
/*  9:   */   public static void glClearBufferData(int target, int internalformat, int format, int type, ByteBuffer data)
/* 10:   */   {
/* 11:13 */     GL43.glClearBufferData(target, internalformat, format, type, data);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void glClearBufferSubData(int target, int internalformat, long offset, int format, int type, ByteBuffer data)
/* 15:   */   {
/* 16:17 */     GL43.glClearBufferSubData(target, internalformat, offset, format, type, data);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void glClearNamedBufferDataEXT(int buffer, int internalformat, int format, int type, ByteBuffer data)
/* 20:   */   {
/* 21:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 22:22 */     long function_pointer = caps.glClearNamedBufferDataEXT;
/* 23:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 24:24 */     BufferChecks.checkBuffer(data, 1);
/* 25:25 */     nglClearNamedBufferDataEXT(buffer, internalformat, format, type, MemoryUtil.getAddress(data), function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglClearNamedBufferDataEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 29:   */   
/* 30:   */   public static void glClearNamedBufferSubDataEXT(int buffer, int internalformat, long offset, int format, int type, ByteBuffer data)
/* 31:   */   {
/* 32:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:31 */     long function_pointer = caps.glClearNamedBufferSubDataEXT;
/* 34:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:33 */     BufferChecks.checkDirect(data);
/* 36:34 */     nglClearNamedBufferSubDataEXT(buffer, internalformat, offset, data.remaining(), format, type, MemoryUtil.getAddress(data), function_pointer);
/* 37:   */   }
/* 38:   */   
/* 39:   */   static native void nglClearNamedBufferSubDataEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2, int paramInt3, int paramInt4, long paramLong3, long paramLong4);
/* 40:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBClearBufferObject
 * JD-Core Version:    0.7.0.1
 */