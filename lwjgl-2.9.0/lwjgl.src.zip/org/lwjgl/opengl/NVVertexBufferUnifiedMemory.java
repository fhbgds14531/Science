/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.LongBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVVertexBufferUnifiedMemory
/*   8:    */ {
/*   9:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_UNIFIED_NV = 36638;
/*  10:    */   public static final int GL_ELEMENT_ARRAY_UNIFIED_NV = 36639;
/*  11:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_ADDRESS_NV = 36640;
/*  12:    */   public static final int GL_TEXTURE_COORD_ARRAY_ADDRESS_NV = 36645;
/*  13:    */   public static final int GL_VERTEX_ARRAY_ADDRESS_NV = 36641;
/*  14:    */   public static final int GL_NORMAL_ARRAY_ADDRESS_NV = 36642;
/*  15:    */   public static final int GL_COLOR_ARRAY_ADDRESS_NV = 36643;
/*  16:    */   public static final int GL_INDEX_ARRAY_ADDRESS_NV = 36644;
/*  17:    */   public static final int GL_EDGE_FLAG_ARRAY_ADDRESS_NV = 36646;
/*  18:    */   public static final int GL_SECONDARY_COLOR_ARRAY_ADDRESS_NV = 36647;
/*  19:    */   public static final int GL_FOG_COORD_ARRAY_ADDRESS_NV = 36648;
/*  20:    */   public static final int GL_ELEMENT_ARRAY_ADDRESS_NV = 36649;
/*  21:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_LENGTH_NV = 36650;
/*  22:    */   public static final int GL_TEXTURE_COORD_ARRAY_LENGTH_NV = 36655;
/*  23:    */   public static final int GL_VERTEX_ARRAY_LENGTH_NV = 36651;
/*  24:    */   public static final int GL_NORMAL_ARRAY_LENGTH_NV = 36652;
/*  25:    */   public static final int GL_COLOR_ARRAY_LENGTH_NV = 36653;
/*  26:    */   public static final int GL_INDEX_ARRAY_LENGTH_NV = 36654;
/*  27:    */   public static final int GL_EDGE_FLAG_ARRAY_LENGTH_NV = 36656;
/*  28:    */   public static final int GL_SECONDARY_COLOR_ARRAY_LENGTH_NV = 36657;
/*  29:    */   public static final int GL_FOG_COORD_ARRAY_LENGTH_NV = 36658;
/*  30:    */   public static final int GL_ELEMENT_ARRAY_LENGTH_NV = 36659;
/*  31:    */   
/*  32:    */   public static void glBufferAddressRangeNV(int pname, int index, long address, long length)
/*  33:    */   {
/*  34: 58 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  35: 59 */     long function_pointer = caps.glBufferAddressRangeNV;
/*  36: 60 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  37: 61 */     nglBufferAddressRangeNV(pname, index, address, length, function_pointer);
/*  38:    */   }
/*  39:    */   
/*  40:    */   static native void nglBufferAddressRangeNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  41:    */   
/*  42:    */   public static void glVertexFormatNV(int size, int type, int stride)
/*  43:    */   {
/*  44: 66 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  45: 67 */     long function_pointer = caps.glVertexFormatNV;
/*  46: 68 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  47: 69 */     nglVertexFormatNV(size, type, stride, function_pointer);
/*  48:    */   }
/*  49:    */   
/*  50:    */   static native void nglVertexFormatNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  51:    */   
/*  52:    */   public static void glNormalFormatNV(int type, int stride)
/*  53:    */   {
/*  54: 74 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  55: 75 */     long function_pointer = caps.glNormalFormatNV;
/*  56: 76 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  57: 77 */     nglNormalFormatNV(type, stride, function_pointer);
/*  58:    */   }
/*  59:    */   
/*  60:    */   static native void nglNormalFormatNV(int paramInt1, int paramInt2, long paramLong);
/*  61:    */   
/*  62:    */   public static void glColorFormatNV(int size, int type, int stride)
/*  63:    */   {
/*  64: 82 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  65: 83 */     long function_pointer = caps.glColorFormatNV;
/*  66: 84 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  67: 85 */     nglColorFormatNV(size, type, stride, function_pointer);
/*  68:    */   }
/*  69:    */   
/*  70:    */   static native void nglColorFormatNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  71:    */   
/*  72:    */   public static void glIndexFormatNV(int type, int stride)
/*  73:    */   {
/*  74: 90 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  75: 91 */     long function_pointer = caps.glIndexFormatNV;
/*  76: 92 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  77: 93 */     nglIndexFormatNV(type, stride, function_pointer);
/*  78:    */   }
/*  79:    */   
/*  80:    */   static native void nglIndexFormatNV(int paramInt1, int paramInt2, long paramLong);
/*  81:    */   
/*  82:    */   public static void glTexCoordFormatNV(int size, int type, int stride)
/*  83:    */   {
/*  84: 98 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  85: 99 */     long function_pointer = caps.glTexCoordFormatNV;
/*  86:100 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  87:101 */     nglTexCoordFormatNV(size, type, stride, function_pointer);
/*  88:    */   }
/*  89:    */   
/*  90:    */   static native void nglTexCoordFormatNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  91:    */   
/*  92:    */   public static void glEdgeFlagFormatNV(int stride)
/*  93:    */   {
/*  94:106 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  95:107 */     long function_pointer = caps.glEdgeFlagFormatNV;
/*  96:108 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  97:109 */     nglEdgeFlagFormatNV(stride, function_pointer);
/*  98:    */   }
/*  99:    */   
/* 100:    */   static native void nglEdgeFlagFormatNV(int paramInt, long paramLong);
/* 101:    */   
/* 102:    */   public static void glSecondaryColorFormatNV(int size, int type, int stride)
/* 103:    */   {
/* 104:114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 105:115 */     long function_pointer = caps.glSecondaryColorFormatNV;
/* 106:116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 107:117 */     nglSecondaryColorFormatNV(size, type, stride, function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglSecondaryColorFormatNV(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 111:    */   
/* 112:    */   public static void glFogCoordFormatNV(int type, int stride)
/* 113:    */   {
/* 114:122 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:123 */     long function_pointer = caps.glFogCoordFormatNV;
/* 116:124 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:125 */     nglFogCoordFormatNV(type, stride, function_pointer);
/* 118:    */   }
/* 119:    */   
/* 120:    */   static native void nglFogCoordFormatNV(int paramInt1, int paramInt2, long paramLong);
/* 121:    */   
/* 122:    */   public static void glVertexAttribFormatNV(int index, int size, int type, boolean normalized, int stride)
/* 123:    */   {
/* 124:130 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:131 */     long function_pointer = caps.glVertexAttribFormatNV;
/* 126:132 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:133 */     nglVertexAttribFormatNV(index, size, type, normalized, stride, function_pointer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   static native void nglVertexAttribFormatNV(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong);
/* 131:    */   
/* 132:    */   public static void glVertexAttribIFormatNV(int index, int size, int type, int stride)
/* 133:    */   {
/* 134:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 135:139 */     long function_pointer = caps.glVertexAttribIFormatNV;
/* 136:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 137:141 */     nglVertexAttribIFormatNV(index, size, type, stride, function_pointer);
/* 138:    */   }
/* 139:    */   
/* 140:    */   static native void nglVertexAttribIFormatNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 141:    */   
/* 142:    */   public static void glGetIntegeruNV(int value, int index, LongBuffer result)
/* 143:    */   {
/* 144:146 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 145:147 */     long function_pointer = caps.glGetIntegerui64i_vNV;
/* 146:148 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 147:149 */     BufferChecks.checkBuffer(result, 1);
/* 148:150 */     nglGetIntegerui64i_vNV(value, index, MemoryUtil.getAddress(result), function_pointer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   static native void nglGetIntegerui64i_vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 152:    */   
/* 153:    */   public static long glGetIntegerui64NV(int value, int index)
/* 154:    */   {
/* 155:156 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 156:157 */     long function_pointer = caps.glGetIntegerui64i_vNV;
/* 157:158 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 158:159 */     LongBuffer result = APIUtil.getBufferLong(caps);
/* 159:160 */     nglGetIntegerui64i_vNV(value, index, MemoryUtil.getAddress(result), function_pointer);
/* 160:161 */     return result.get(0);
/* 161:    */   }
/* 162:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexBufferUnifiedMemory
 * JD-Core Version:    0.7.0.1
 */