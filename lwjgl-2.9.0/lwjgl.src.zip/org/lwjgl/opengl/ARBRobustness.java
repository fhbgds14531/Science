/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.DoubleBuffer;
/*    5:     */ import java.nio.FloatBuffer;
/*    6:     */ import java.nio.IntBuffer;
/*    7:     */ import java.nio.ShortBuffer;
/*    8:     */ import org.lwjgl.BufferChecks;
/*    9:     */ import org.lwjgl.MemoryUtil;
/*   10:     */ 
/*   11:     */ public final class ARBRobustness
/*   12:     */ {
/*   13:     */   public static final int GL_NO_ERROR = 0;
/*   14:     */   public static final int GL_GUILTY_CONTEXT_RESET_ARB = 33363;
/*   15:     */   public static final int GL_INNOCENT_CONTEXT_RESET_ARB = 33364;
/*   16:     */   public static final int GL_UNKNOWN_CONTEXT_RESET_ARB = 33365;
/*   17:     */   public static final int GL_RESET_NOTIFICATION_STRATEGY_ARB = 33366;
/*   18:     */   public static final int GL_LOSE_CONTEXT_ON_RESET_ARB = 33362;
/*   19:     */   public static final int GL_NO_RESET_NOTIFICATION_ARB = 33377;
/*   20:     */   public static final int GL_CONTEXT_FLAG_ROBUST_ACCESS_BIT_ARB = 4;
/*   21:     */   
/*   22:     */   public static int glGetGraphicsResetStatusARB()
/*   23:     */   {
/*   24:  39 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   25:  40 */     long function_pointer = caps.glGetGraphicsResetStatusARB;
/*   26:  41 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   27:  42 */     int __result = nglGetGraphicsResetStatusARB(function_pointer);
/*   28:  43 */     return __result;
/*   29:     */   }
/*   30:     */   
/*   31:     */   static native int nglGetGraphicsResetStatusARB(long paramLong);
/*   32:     */   
/*   33:     */   public static void glGetnMapdvARB(int target, int query, DoubleBuffer v)
/*   34:     */   {
/*   35:  48 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   36:  49 */     long function_pointer = caps.glGetnMapdvARB;
/*   37:  50 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   38:  51 */     BufferChecks.checkDirect(v);
/*   39:  52 */     nglGetnMapdvARB(target, query, v.remaining() << 3, MemoryUtil.getAddress(v), function_pointer);
/*   40:     */   }
/*   41:     */   
/*   42:     */   static native void nglGetnMapdvARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*   43:     */   
/*   44:     */   public static void glGetnMapfvARB(int target, int query, FloatBuffer v)
/*   45:     */   {
/*   46:  57 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   47:  58 */     long function_pointer = caps.glGetnMapfvARB;
/*   48:  59 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   49:  60 */     BufferChecks.checkDirect(v);
/*   50:  61 */     nglGetnMapfvARB(target, query, v.remaining() << 2, MemoryUtil.getAddress(v), function_pointer);
/*   51:     */   }
/*   52:     */   
/*   53:     */   static native void nglGetnMapfvARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*   54:     */   
/*   55:     */   public static void glGetnMapivARB(int target, int query, IntBuffer v)
/*   56:     */   {
/*   57:  66 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   58:  67 */     long function_pointer = caps.glGetnMapivARB;
/*   59:  68 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   60:  69 */     BufferChecks.checkDirect(v);
/*   61:  70 */     nglGetnMapivARB(target, query, v.remaining() << 2, MemoryUtil.getAddress(v), function_pointer);
/*   62:     */   }
/*   63:     */   
/*   64:     */   static native void nglGetnMapivARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*   65:     */   
/*   66:     */   public static void glGetnPixelMapfvARB(int map, FloatBuffer values)
/*   67:     */   {
/*   68:  75 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   69:  76 */     long function_pointer = caps.glGetnPixelMapfvARB;
/*   70:  77 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   71:  78 */     BufferChecks.checkDirect(values);
/*   72:  79 */     nglGetnPixelMapfvARB(map, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/*   73:     */   }
/*   74:     */   
/*   75:     */   static native void nglGetnPixelMapfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*   76:     */   
/*   77:     */   public static void glGetnPixelMapuivARB(int map, IntBuffer values)
/*   78:     */   {
/*   79:  84 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   80:  85 */     long function_pointer = caps.glGetnPixelMapuivARB;
/*   81:  86 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   82:  87 */     BufferChecks.checkDirect(values);
/*   83:  88 */     nglGetnPixelMapuivARB(map, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/*   84:     */   }
/*   85:     */   
/*   86:     */   static native void nglGetnPixelMapuivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*   87:     */   
/*   88:     */   public static void glGetnPixelMapusvARB(int map, ShortBuffer values)
/*   89:     */   {
/*   90:  93 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   91:  94 */     long function_pointer = caps.glGetnPixelMapusvARB;
/*   92:  95 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   93:  96 */     BufferChecks.checkDirect(values);
/*   94:  97 */     nglGetnPixelMapusvARB(map, values.remaining() << 1, MemoryUtil.getAddress(values), function_pointer);
/*   95:     */   }
/*   96:     */   
/*   97:     */   static native void nglGetnPixelMapusvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*   98:     */   
/*   99:     */   public static void glGetnPolygonStippleARB(ByteBuffer pattern)
/*  100:     */   {
/*  101: 102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  102: 103 */     long function_pointer = caps.glGetnPolygonStippleARB;
/*  103: 104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  104: 105 */     BufferChecks.checkDirect(pattern);
/*  105: 106 */     nglGetnPolygonStippleARB(pattern.remaining(), MemoryUtil.getAddress(pattern), function_pointer);
/*  106:     */   }
/*  107:     */   
/*  108:     */   static native void nglGetnPolygonStippleARB(int paramInt, long paramLong1, long paramLong2);
/*  109:     */   
/*  110:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, ByteBuffer img)
/*  111:     */   {
/*  112: 111 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  113: 112 */     long function_pointer = caps.glGetnTexImageARB;
/*  114: 113 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  115: 114 */     GLChecks.ensurePackPBOdisabled(caps);
/*  116: 115 */     BufferChecks.checkDirect(img);
/*  117: 116 */     nglGetnTexImageARB(target, level, format, type, img.remaining(), MemoryUtil.getAddress(img), function_pointer);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, DoubleBuffer img)
/*  121:     */   {
/*  122: 119 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  123: 120 */     long function_pointer = caps.glGetnTexImageARB;
/*  124: 121 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  125: 122 */     GLChecks.ensurePackPBOdisabled(caps);
/*  126: 123 */     BufferChecks.checkDirect(img);
/*  127: 124 */     nglGetnTexImageARB(target, level, format, type, img.remaining() << 3, MemoryUtil.getAddress(img), function_pointer);
/*  128:     */   }
/*  129:     */   
/*  130:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, FloatBuffer img)
/*  131:     */   {
/*  132: 127 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  133: 128 */     long function_pointer = caps.glGetnTexImageARB;
/*  134: 129 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  135: 130 */     GLChecks.ensurePackPBOdisabled(caps);
/*  136: 131 */     BufferChecks.checkDirect(img);
/*  137: 132 */     nglGetnTexImageARB(target, level, format, type, img.remaining() << 2, MemoryUtil.getAddress(img), function_pointer);
/*  138:     */   }
/*  139:     */   
/*  140:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, IntBuffer img)
/*  141:     */   {
/*  142: 135 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  143: 136 */     long function_pointer = caps.glGetnTexImageARB;
/*  144: 137 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  145: 138 */     GLChecks.ensurePackPBOdisabled(caps);
/*  146: 139 */     BufferChecks.checkDirect(img);
/*  147: 140 */     nglGetnTexImageARB(target, level, format, type, img.remaining() << 2, MemoryUtil.getAddress(img), function_pointer);
/*  148:     */   }
/*  149:     */   
/*  150:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, ShortBuffer img)
/*  151:     */   {
/*  152: 143 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  153: 144 */     long function_pointer = caps.glGetnTexImageARB;
/*  154: 145 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  155: 146 */     GLChecks.ensurePackPBOdisabled(caps);
/*  156: 147 */     BufferChecks.checkDirect(img);
/*  157: 148 */     nglGetnTexImageARB(target, level, format, type, img.remaining() << 1, MemoryUtil.getAddress(img), function_pointer);
/*  158:     */   }
/*  159:     */   
/*  160:     */   static native void nglGetnTexImageARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  161:     */   
/*  162:     */   public static void glGetnTexImageARB(int target, int level, int format, int type, int img_bufSize, long img_buffer_offset)
/*  163:     */   {
/*  164: 152 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  165: 153 */     long function_pointer = caps.glGetnTexImageARB;
/*  166: 154 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  167: 155 */     GLChecks.ensurePackPBOenabled(caps);
/*  168: 156 */     nglGetnTexImageARBBO(target, level, format, type, img_bufSize, img_buffer_offset, function_pointer);
/*  169:     */   }
/*  170:     */   
/*  171:     */   static native void nglGetnTexImageARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  172:     */   
/*  173:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, ByteBuffer data)
/*  174:     */   {
/*  175: 161 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  176: 162 */     long function_pointer = caps.glReadnPixelsARB;
/*  177: 163 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  178: 164 */     GLChecks.ensurePackPBOdisabled(caps);
/*  179: 165 */     BufferChecks.checkDirect(data);
/*  180: 166 */     nglReadnPixelsARB(x, y, width, height, format, type, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/*  181:     */   }
/*  182:     */   
/*  183:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, DoubleBuffer data)
/*  184:     */   {
/*  185: 169 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  186: 170 */     long function_pointer = caps.glReadnPixelsARB;
/*  187: 171 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  188: 172 */     GLChecks.ensurePackPBOdisabled(caps);
/*  189: 173 */     BufferChecks.checkDirect(data);
/*  190: 174 */     nglReadnPixelsARB(x, y, width, height, format, type, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/*  191:     */   }
/*  192:     */   
/*  193:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, FloatBuffer data)
/*  194:     */   {
/*  195: 177 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  196: 178 */     long function_pointer = caps.glReadnPixelsARB;
/*  197: 179 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  198: 180 */     GLChecks.ensurePackPBOdisabled(caps);
/*  199: 181 */     BufferChecks.checkDirect(data);
/*  200: 182 */     nglReadnPixelsARB(x, y, width, height, format, type, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/*  201:     */   }
/*  202:     */   
/*  203:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, IntBuffer data)
/*  204:     */   {
/*  205: 185 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  206: 186 */     long function_pointer = caps.glReadnPixelsARB;
/*  207: 187 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  208: 188 */     GLChecks.ensurePackPBOdisabled(caps);
/*  209: 189 */     BufferChecks.checkDirect(data);
/*  210: 190 */     nglReadnPixelsARB(x, y, width, height, format, type, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/*  211:     */   }
/*  212:     */   
/*  213:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, ShortBuffer data)
/*  214:     */   {
/*  215: 193 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  216: 194 */     long function_pointer = caps.glReadnPixelsARB;
/*  217: 195 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  218: 196 */     GLChecks.ensurePackPBOdisabled(caps);
/*  219: 197 */     BufferChecks.checkDirect(data);
/*  220: 198 */     nglReadnPixelsARB(x, y, width, height, format, type, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/*  221:     */   }
/*  222:     */   
/*  223:     */   static native void nglReadnPixelsARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  224:     */   
/*  225:     */   public static void glReadnPixelsARB(int x, int y, int width, int height, int format, int type, int data_bufSize, long data_buffer_offset)
/*  226:     */   {
/*  227: 202 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  228: 203 */     long function_pointer = caps.glReadnPixelsARB;
/*  229: 204 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  230: 205 */     GLChecks.ensurePackPBOenabled(caps);
/*  231: 206 */     nglReadnPixelsARBBO(x, y, width, height, format, type, data_bufSize, data_buffer_offset, function_pointer);
/*  232:     */   }
/*  233:     */   
/*  234:     */   static native void nglReadnPixelsARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  235:     */   
/*  236:     */   public static void glGetnColorTableARB(int target, int format, int type, ByteBuffer table)
/*  237:     */   {
/*  238: 211 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  239: 212 */     long function_pointer = caps.glGetnColorTableARB;
/*  240: 213 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  241: 214 */     BufferChecks.checkDirect(table);
/*  242: 215 */     nglGetnColorTableARB(target, format, type, table.remaining(), MemoryUtil.getAddress(table), function_pointer);
/*  243:     */   }
/*  244:     */   
/*  245:     */   public static void glGetnColorTableARB(int target, int format, int type, DoubleBuffer table)
/*  246:     */   {
/*  247: 218 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  248: 219 */     long function_pointer = caps.glGetnColorTableARB;
/*  249: 220 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  250: 221 */     BufferChecks.checkDirect(table);
/*  251: 222 */     nglGetnColorTableARB(target, format, type, table.remaining() << 3, MemoryUtil.getAddress(table), function_pointer);
/*  252:     */   }
/*  253:     */   
/*  254:     */   public static void glGetnColorTableARB(int target, int format, int type, FloatBuffer table)
/*  255:     */   {
/*  256: 225 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  257: 226 */     long function_pointer = caps.glGetnColorTableARB;
/*  258: 227 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  259: 228 */     BufferChecks.checkDirect(table);
/*  260: 229 */     nglGetnColorTableARB(target, format, type, table.remaining() << 2, MemoryUtil.getAddress(table), function_pointer);
/*  261:     */   }
/*  262:     */   
/*  263:     */   static native void nglGetnColorTableARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  264:     */   
/*  265:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, ByteBuffer image)
/*  266:     */   {
/*  267: 234 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  268: 235 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  269: 236 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  270: 237 */     GLChecks.ensurePackPBOdisabled(caps);
/*  271: 238 */     BufferChecks.checkDirect(image);
/*  272: 239 */     nglGetnConvolutionFilterARB(target, format, type, image.remaining(), MemoryUtil.getAddress(image), function_pointer);
/*  273:     */   }
/*  274:     */   
/*  275:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, DoubleBuffer image)
/*  276:     */   {
/*  277: 242 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  278: 243 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  279: 244 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  280: 245 */     GLChecks.ensurePackPBOdisabled(caps);
/*  281: 246 */     BufferChecks.checkDirect(image);
/*  282: 247 */     nglGetnConvolutionFilterARB(target, format, type, image.remaining() << 3, MemoryUtil.getAddress(image), function_pointer);
/*  283:     */   }
/*  284:     */   
/*  285:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, FloatBuffer image)
/*  286:     */   {
/*  287: 250 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  288: 251 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  289: 252 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  290: 253 */     GLChecks.ensurePackPBOdisabled(caps);
/*  291: 254 */     BufferChecks.checkDirect(image);
/*  292: 255 */     nglGetnConvolutionFilterARB(target, format, type, image.remaining() << 2, MemoryUtil.getAddress(image), function_pointer);
/*  293:     */   }
/*  294:     */   
/*  295:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, IntBuffer image)
/*  296:     */   {
/*  297: 258 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  298: 259 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  299: 260 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  300: 261 */     GLChecks.ensurePackPBOdisabled(caps);
/*  301: 262 */     BufferChecks.checkDirect(image);
/*  302: 263 */     nglGetnConvolutionFilterARB(target, format, type, image.remaining() << 2, MemoryUtil.getAddress(image), function_pointer);
/*  303:     */   }
/*  304:     */   
/*  305:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, ShortBuffer image)
/*  306:     */   {
/*  307: 266 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  308: 267 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  309: 268 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  310: 269 */     GLChecks.ensurePackPBOdisabled(caps);
/*  311: 270 */     BufferChecks.checkDirect(image);
/*  312: 271 */     nglGetnConvolutionFilterARB(target, format, type, image.remaining() << 1, MemoryUtil.getAddress(image), function_pointer);
/*  313:     */   }
/*  314:     */   
/*  315:     */   static native void nglGetnConvolutionFilterARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  316:     */   
/*  317:     */   public static void glGetnConvolutionFilterARB(int target, int format, int type, int image_bufSize, long image_buffer_offset)
/*  318:     */   {
/*  319: 275 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  320: 276 */     long function_pointer = caps.glGetnConvolutionFilterARB;
/*  321: 277 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  322: 278 */     GLChecks.ensurePackPBOenabled(caps);
/*  323: 279 */     nglGetnConvolutionFilterARBBO(target, format, type, image_bufSize, image_buffer_offset, function_pointer);
/*  324:     */   }
/*  325:     */   
/*  326:     */   static native void nglGetnConvolutionFilterARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/*  327:     */   
/*  328:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ByteBuffer column, ByteBuffer span)
/*  329:     */   {
/*  330: 284 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  331: 285 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  332: 286 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  333: 287 */     GLChecks.ensurePackPBOdisabled(caps);
/*  334: 288 */     BufferChecks.checkDirect(row);
/*  335: 289 */     BufferChecks.checkDirect(column);
/*  336: 290 */     BufferChecks.checkDirect(span);
/*  337: 291 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  338:     */   }
/*  339:     */   
/*  340:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ByteBuffer column, DoubleBuffer span)
/*  341:     */   {
/*  342: 294 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  343: 295 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  344: 296 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  345: 297 */     GLChecks.ensurePackPBOdisabled(caps);
/*  346: 298 */     BufferChecks.checkDirect(row);
/*  347: 299 */     BufferChecks.checkDirect(column);
/*  348: 300 */     BufferChecks.checkDirect(span);
/*  349: 301 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  350:     */   }
/*  351:     */   
/*  352:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ByteBuffer column, FloatBuffer span)
/*  353:     */   {
/*  354: 304 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  355: 305 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  356: 306 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  357: 307 */     GLChecks.ensurePackPBOdisabled(caps);
/*  358: 308 */     BufferChecks.checkDirect(row);
/*  359: 309 */     BufferChecks.checkDirect(column);
/*  360: 310 */     BufferChecks.checkDirect(span);
/*  361: 311 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  362:     */   }
/*  363:     */   
/*  364:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ByteBuffer column, IntBuffer span)
/*  365:     */   {
/*  366: 314 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  367: 315 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  368: 316 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  369: 317 */     GLChecks.ensurePackPBOdisabled(caps);
/*  370: 318 */     BufferChecks.checkDirect(row);
/*  371: 319 */     BufferChecks.checkDirect(column);
/*  372: 320 */     BufferChecks.checkDirect(span);
/*  373: 321 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  374:     */   }
/*  375:     */   
/*  376:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ByteBuffer column, ShortBuffer span)
/*  377:     */   {
/*  378: 324 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  379: 325 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  380: 326 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  381: 327 */     GLChecks.ensurePackPBOdisabled(caps);
/*  382: 328 */     BufferChecks.checkDirect(row);
/*  383: 329 */     BufferChecks.checkDirect(column);
/*  384: 330 */     BufferChecks.checkDirect(span);
/*  385: 331 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  386:     */   }
/*  387:     */   
/*  388:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, DoubleBuffer column, ByteBuffer span)
/*  389:     */   {
/*  390: 334 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  391: 335 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  392: 336 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  393: 337 */     GLChecks.ensurePackPBOdisabled(caps);
/*  394: 338 */     BufferChecks.checkDirect(row);
/*  395: 339 */     BufferChecks.checkDirect(column);
/*  396: 340 */     BufferChecks.checkDirect(span);
/*  397: 341 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  398:     */   }
/*  399:     */   
/*  400:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, DoubleBuffer column, DoubleBuffer span)
/*  401:     */   {
/*  402: 344 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  403: 345 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  404: 346 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  405: 347 */     GLChecks.ensurePackPBOdisabled(caps);
/*  406: 348 */     BufferChecks.checkDirect(row);
/*  407: 349 */     BufferChecks.checkDirect(column);
/*  408: 350 */     BufferChecks.checkDirect(span);
/*  409: 351 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  410:     */   }
/*  411:     */   
/*  412:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, DoubleBuffer column, FloatBuffer span)
/*  413:     */   {
/*  414: 354 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  415: 355 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  416: 356 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  417: 357 */     GLChecks.ensurePackPBOdisabled(caps);
/*  418: 358 */     BufferChecks.checkDirect(row);
/*  419: 359 */     BufferChecks.checkDirect(column);
/*  420: 360 */     BufferChecks.checkDirect(span);
/*  421: 361 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  422:     */   }
/*  423:     */   
/*  424:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, DoubleBuffer column, IntBuffer span)
/*  425:     */   {
/*  426: 364 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  427: 365 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  428: 366 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  429: 367 */     GLChecks.ensurePackPBOdisabled(caps);
/*  430: 368 */     BufferChecks.checkDirect(row);
/*  431: 369 */     BufferChecks.checkDirect(column);
/*  432: 370 */     BufferChecks.checkDirect(span);
/*  433: 371 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  434:     */   }
/*  435:     */   
/*  436:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, DoubleBuffer column, ShortBuffer span)
/*  437:     */   {
/*  438: 374 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  439: 375 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  440: 376 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  441: 377 */     GLChecks.ensurePackPBOdisabled(caps);
/*  442: 378 */     BufferChecks.checkDirect(row);
/*  443: 379 */     BufferChecks.checkDirect(column);
/*  444: 380 */     BufferChecks.checkDirect(span);
/*  445: 381 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  446:     */   }
/*  447:     */   
/*  448:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, FloatBuffer column, ByteBuffer span)
/*  449:     */   {
/*  450: 384 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  451: 385 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  452: 386 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  453: 387 */     GLChecks.ensurePackPBOdisabled(caps);
/*  454: 388 */     BufferChecks.checkDirect(row);
/*  455: 389 */     BufferChecks.checkDirect(column);
/*  456: 390 */     BufferChecks.checkDirect(span);
/*  457: 391 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  458:     */   }
/*  459:     */   
/*  460:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, FloatBuffer column, DoubleBuffer span)
/*  461:     */   {
/*  462: 394 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  463: 395 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  464: 396 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  465: 397 */     GLChecks.ensurePackPBOdisabled(caps);
/*  466: 398 */     BufferChecks.checkDirect(row);
/*  467: 399 */     BufferChecks.checkDirect(column);
/*  468: 400 */     BufferChecks.checkDirect(span);
/*  469: 401 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  470:     */   }
/*  471:     */   
/*  472:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, FloatBuffer column, FloatBuffer span)
/*  473:     */   {
/*  474: 404 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  475: 405 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  476: 406 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  477: 407 */     GLChecks.ensurePackPBOdisabled(caps);
/*  478: 408 */     BufferChecks.checkDirect(row);
/*  479: 409 */     BufferChecks.checkDirect(column);
/*  480: 410 */     BufferChecks.checkDirect(span);
/*  481: 411 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  482:     */   }
/*  483:     */   
/*  484:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, FloatBuffer column, IntBuffer span)
/*  485:     */   {
/*  486: 414 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  487: 415 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  488: 416 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  489: 417 */     GLChecks.ensurePackPBOdisabled(caps);
/*  490: 418 */     BufferChecks.checkDirect(row);
/*  491: 419 */     BufferChecks.checkDirect(column);
/*  492: 420 */     BufferChecks.checkDirect(span);
/*  493: 421 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  494:     */   }
/*  495:     */   
/*  496:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, FloatBuffer column, ShortBuffer span)
/*  497:     */   {
/*  498: 424 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  499: 425 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  500: 426 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  501: 427 */     GLChecks.ensurePackPBOdisabled(caps);
/*  502: 428 */     BufferChecks.checkDirect(row);
/*  503: 429 */     BufferChecks.checkDirect(column);
/*  504: 430 */     BufferChecks.checkDirect(span);
/*  505: 431 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  506:     */   }
/*  507:     */   
/*  508:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, IntBuffer column, ByteBuffer span)
/*  509:     */   {
/*  510: 434 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  511: 435 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  512: 436 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  513: 437 */     GLChecks.ensurePackPBOdisabled(caps);
/*  514: 438 */     BufferChecks.checkDirect(row);
/*  515: 439 */     BufferChecks.checkDirect(column);
/*  516: 440 */     BufferChecks.checkDirect(span);
/*  517: 441 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  518:     */   }
/*  519:     */   
/*  520:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, IntBuffer column, DoubleBuffer span)
/*  521:     */   {
/*  522: 444 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  523: 445 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  524: 446 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  525: 447 */     GLChecks.ensurePackPBOdisabled(caps);
/*  526: 448 */     BufferChecks.checkDirect(row);
/*  527: 449 */     BufferChecks.checkDirect(column);
/*  528: 450 */     BufferChecks.checkDirect(span);
/*  529: 451 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  530:     */   }
/*  531:     */   
/*  532:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, IntBuffer column, FloatBuffer span)
/*  533:     */   {
/*  534: 454 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  535: 455 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  536: 456 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  537: 457 */     GLChecks.ensurePackPBOdisabled(caps);
/*  538: 458 */     BufferChecks.checkDirect(row);
/*  539: 459 */     BufferChecks.checkDirect(column);
/*  540: 460 */     BufferChecks.checkDirect(span);
/*  541: 461 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  542:     */   }
/*  543:     */   
/*  544:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, IntBuffer column, IntBuffer span)
/*  545:     */   {
/*  546: 464 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  547: 465 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  548: 466 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  549: 467 */     GLChecks.ensurePackPBOdisabled(caps);
/*  550: 468 */     BufferChecks.checkDirect(row);
/*  551: 469 */     BufferChecks.checkDirect(column);
/*  552: 470 */     BufferChecks.checkDirect(span);
/*  553: 471 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  554:     */   }
/*  555:     */   
/*  556:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, IntBuffer column, ShortBuffer span)
/*  557:     */   {
/*  558: 474 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  559: 475 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  560: 476 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  561: 477 */     GLChecks.ensurePackPBOdisabled(caps);
/*  562: 478 */     BufferChecks.checkDirect(row);
/*  563: 479 */     BufferChecks.checkDirect(column);
/*  564: 480 */     BufferChecks.checkDirect(span);
/*  565: 481 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  566:     */   }
/*  567:     */   
/*  568:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ShortBuffer column, ByteBuffer span)
/*  569:     */   {
/*  570: 484 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  571: 485 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  572: 486 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  573: 487 */     GLChecks.ensurePackPBOdisabled(caps);
/*  574: 488 */     BufferChecks.checkDirect(row);
/*  575: 489 */     BufferChecks.checkDirect(column);
/*  576: 490 */     BufferChecks.checkDirect(span);
/*  577: 491 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  578:     */   }
/*  579:     */   
/*  580:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ShortBuffer column, DoubleBuffer span)
/*  581:     */   {
/*  582: 494 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  583: 495 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  584: 496 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  585: 497 */     GLChecks.ensurePackPBOdisabled(caps);
/*  586: 498 */     BufferChecks.checkDirect(row);
/*  587: 499 */     BufferChecks.checkDirect(column);
/*  588: 500 */     BufferChecks.checkDirect(span);
/*  589: 501 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  590:     */   }
/*  591:     */   
/*  592:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ShortBuffer column, FloatBuffer span)
/*  593:     */   {
/*  594: 504 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  595: 505 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  596: 506 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  597: 507 */     GLChecks.ensurePackPBOdisabled(caps);
/*  598: 508 */     BufferChecks.checkDirect(row);
/*  599: 509 */     BufferChecks.checkDirect(column);
/*  600: 510 */     BufferChecks.checkDirect(span);
/*  601: 511 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  602:     */   }
/*  603:     */   
/*  604:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ShortBuffer column, IntBuffer span)
/*  605:     */   {
/*  606: 514 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  607: 515 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  608: 516 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  609: 517 */     GLChecks.ensurePackPBOdisabled(caps);
/*  610: 518 */     BufferChecks.checkDirect(row);
/*  611: 519 */     BufferChecks.checkDirect(column);
/*  612: 520 */     BufferChecks.checkDirect(span);
/*  613: 521 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  614:     */   }
/*  615:     */   
/*  616:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ByteBuffer row, ShortBuffer column, ShortBuffer span)
/*  617:     */   {
/*  618: 524 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  619: 525 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  620: 526 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  621: 527 */     GLChecks.ensurePackPBOdisabled(caps);
/*  622: 528 */     BufferChecks.checkDirect(row);
/*  623: 529 */     BufferChecks.checkDirect(column);
/*  624: 530 */     BufferChecks.checkDirect(span);
/*  625: 531 */     nglGetnSeparableFilterARB(target, format, type, row.remaining(), MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  626:     */   }
/*  627:     */   
/*  628:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ByteBuffer column, ByteBuffer span)
/*  629:     */   {
/*  630: 534 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  631: 535 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  632: 536 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  633: 537 */     GLChecks.ensurePackPBOdisabled(caps);
/*  634: 538 */     BufferChecks.checkDirect(row);
/*  635: 539 */     BufferChecks.checkDirect(column);
/*  636: 540 */     BufferChecks.checkDirect(span);
/*  637: 541 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  638:     */   }
/*  639:     */   
/*  640:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ByteBuffer column, DoubleBuffer span)
/*  641:     */   {
/*  642: 544 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  643: 545 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  644: 546 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  645: 547 */     GLChecks.ensurePackPBOdisabled(caps);
/*  646: 548 */     BufferChecks.checkDirect(row);
/*  647: 549 */     BufferChecks.checkDirect(column);
/*  648: 550 */     BufferChecks.checkDirect(span);
/*  649: 551 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  650:     */   }
/*  651:     */   
/*  652:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ByteBuffer column, FloatBuffer span)
/*  653:     */   {
/*  654: 554 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  655: 555 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  656: 556 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  657: 557 */     GLChecks.ensurePackPBOdisabled(caps);
/*  658: 558 */     BufferChecks.checkDirect(row);
/*  659: 559 */     BufferChecks.checkDirect(column);
/*  660: 560 */     BufferChecks.checkDirect(span);
/*  661: 561 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  662:     */   }
/*  663:     */   
/*  664:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ByteBuffer column, IntBuffer span)
/*  665:     */   {
/*  666: 564 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  667: 565 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  668: 566 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  669: 567 */     GLChecks.ensurePackPBOdisabled(caps);
/*  670: 568 */     BufferChecks.checkDirect(row);
/*  671: 569 */     BufferChecks.checkDirect(column);
/*  672: 570 */     BufferChecks.checkDirect(span);
/*  673: 571 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  674:     */   }
/*  675:     */   
/*  676:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ByteBuffer column, ShortBuffer span)
/*  677:     */   {
/*  678: 574 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  679: 575 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  680: 576 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  681: 577 */     GLChecks.ensurePackPBOdisabled(caps);
/*  682: 578 */     BufferChecks.checkDirect(row);
/*  683: 579 */     BufferChecks.checkDirect(column);
/*  684: 580 */     BufferChecks.checkDirect(span);
/*  685: 581 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  686:     */   }
/*  687:     */   
/*  688:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, ByteBuffer span)
/*  689:     */   {
/*  690: 584 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  691: 585 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  692: 586 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  693: 587 */     GLChecks.ensurePackPBOdisabled(caps);
/*  694: 588 */     BufferChecks.checkDirect(row);
/*  695: 589 */     BufferChecks.checkDirect(column);
/*  696: 590 */     BufferChecks.checkDirect(span);
/*  697: 591 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  698:     */   }
/*  699:     */   
/*  700:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, DoubleBuffer span)
/*  701:     */   {
/*  702: 594 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  703: 595 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  704: 596 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  705: 597 */     GLChecks.ensurePackPBOdisabled(caps);
/*  706: 598 */     BufferChecks.checkDirect(row);
/*  707: 599 */     BufferChecks.checkDirect(column);
/*  708: 600 */     BufferChecks.checkDirect(span);
/*  709: 601 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  710:     */   }
/*  711:     */   
/*  712:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, FloatBuffer span)
/*  713:     */   {
/*  714: 604 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  715: 605 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  716: 606 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  717: 607 */     GLChecks.ensurePackPBOdisabled(caps);
/*  718: 608 */     BufferChecks.checkDirect(row);
/*  719: 609 */     BufferChecks.checkDirect(column);
/*  720: 610 */     BufferChecks.checkDirect(span);
/*  721: 611 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  722:     */   }
/*  723:     */   
/*  724:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, IntBuffer span)
/*  725:     */   {
/*  726: 614 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  727: 615 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  728: 616 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  729: 617 */     GLChecks.ensurePackPBOdisabled(caps);
/*  730: 618 */     BufferChecks.checkDirect(row);
/*  731: 619 */     BufferChecks.checkDirect(column);
/*  732: 620 */     BufferChecks.checkDirect(span);
/*  733: 621 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  734:     */   }
/*  735:     */   
/*  736:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, ShortBuffer span)
/*  737:     */   {
/*  738: 624 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  739: 625 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  740: 626 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  741: 627 */     GLChecks.ensurePackPBOdisabled(caps);
/*  742: 628 */     BufferChecks.checkDirect(row);
/*  743: 629 */     BufferChecks.checkDirect(column);
/*  744: 630 */     BufferChecks.checkDirect(span);
/*  745: 631 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  746:     */   }
/*  747:     */   
/*  748:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, FloatBuffer column, ByteBuffer span)
/*  749:     */   {
/*  750: 634 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  751: 635 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  752: 636 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  753: 637 */     GLChecks.ensurePackPBOdisabled(caps);
/*  754: 638 */     BufferChecks.checkDirect(row);
/*  755: 639 */     BufferChecks.checkDirect(column);
/*  756: 640 */     BufferChecks.checkDirect(span);
/*  757: 641 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  758:     */   }
/*  759:     */   
/*  760:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, FloatBuffer column, DoubleBuffer span)
/*  761:     */   {
/*  762: 644 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  763: 645 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  764: 646 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  765: 647 */     GLChecks.ensurePackPBOdisabled(caps);
/*  766: 648 */     BufferChecks.checkDirect(row);
/*  767: 649 */     BufferChecks.checkDirect(column);
/*  768: 650 */     BufferChecks.checkDirect(span);
/*  769: 651 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  770:     */   }
/*  771:     */   
/*  772:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, FloatBuffer column, FloatBuffer span)
/*  773:     */   {
/*  774: 654 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  775: 655 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  776: 656 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  777: 657 */     GLChecks.ensurePackPBOdisabled(caps);
/*  778: 658 */     BufferChecks.checkDirect(row);
/*  779: 659 */     BufferChecks.checkDirect(column);
/*  780: 660 */     BufferChecks.checkDirect(span);
/*  781: 661 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  782:     */   }
/*  783:     */   
/*  784:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, FloatBuffer column, IntBuffer span)
/*  785:     */   {
/*  786: 664 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  787: 665 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  788: 666 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  789: 667 */     GLChecks.ensurePackPBOdisabled(caps);
/*  790: 668 */     BufferChecks.checkDirect(row);
/*  791: 669 */     BufferChecks.checkDirect(column);
/*  792: 670 */     BufferChecks.checkDirect(span);
/*  793: 671 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  794:     */   }
/*  795:     */   
/*  796:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, FloatBuffer column, ShortBuffer span)
/*  797:     */   {
/*  798: 674 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  799: 675 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  800: 676 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  801: 677 */     GLChecks.ensurePackPBOdisabled(caps);
/*  802: 678 */     BufferChecks.checkDirect(row);
/*  803: 679 */     BufferChecks.checkDirect(column);
/*  804: 680 */     BufferChecks.checkDirect(span);
/*  805: 681 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  806:     */   }
/*  807:     */   
/*  808:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, IntBuffer column, ByteBuffer span)
/*  809:     */   {
/*  810: 684 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  811: 685 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  812: 686 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  813: 687 */     GLChecks.ensurePackPBOdisabled(caps);
/*  814: 688 */     BufferChecks.checkDirect(row);
/*  815: 689 */     BufferChecks.checkDirect(column);
/*  816: 690 */     BufferChecks.checkDirect(span);
/*  817: 691 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  818:     */   }
/*  819:     */   
/*  820:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, IntBuffer column, DoubleBuffer span)
/*  821:     */   {
/*  822: 694 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  823: 695 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  824: 696 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  825: 697 */     GLChecks.ensurePackPBOdisabled(caps);
/*  826: 698 */     BufferChecks.checkDirect(row);
/*  827: 699 */     BufferChecks.checkDirect(column);
/*  828: 700 */     BufferChecks.checkDirect(span);
/*  829: 701 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  830:     */   }
/*  831:     */   
/*  832:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, IntBuffer column, FloatBuffer span)
/*  833:     */   {
/*  834: 704 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  835: 705 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  836: 706 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  837: 707 */     GLChecks.ensurePackPBOdisabled(caps);
/*  838: 708 */     BufferChecks.checkDirect(row);
/*  839: 709 */     BufferChecks.checkDirect(column);
/*  840: 710 */     BufferChecks.checkDirect(span);
/*  841: 711 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  842:     */   }
/*  843:     */   
/*  844:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, IntBuffer column, IntBuffer span)
/*  845:     */   {
/*  846: 714 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  847: 715 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  848: 716 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  849: 717 */     GLChecks.ensurePackPBOdisabled(caps);
/*  850: 718 */     BufferChecks.checkDirect(row);
/*  851: 719 */     BufferChecks.checkDirect(column);
/*  852: 720 */     BufferChecks.checkDirect(span);
/*  853: 721 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  854:     */   }
/*  855:     */   
/*  856:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, IntBuffer column, ShortBuffer span)
/*  857:     */   {
/*  858: 724 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  859: 725 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  860: 726 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  861: 727 */     GLChecks.ensurePackPBOdisabled(caps);
/*  862: 728 */     BufferChecks.checkDirect(row);
/*  863: 729 */     BufferChecks.checkDirect(column);
/*  864: 730 */     BufferChecks.checkDirect(span);
/*  865: 731 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  866:     */   }
/*  867:     */   
/*  868:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ShortBuffer column, ByteBuffer span)
/*  869:     */   {
/*  870: 734 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  871: 735 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  872: 736 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  873: 737 */     GLChecks.ensurePackPBOdisabled(caps);
/*  874: 738 */     BufferChecks.checkDirect(row);
/*  875: 739 */     BufferChecks.checkDirect(column);
/*  876: 740 */     BufferChecks.checkDirect(span);
/*  877: 741 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  878:     */   }
/*  879:     */   
/*  880:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ShortBuffer column, DoubleBuffer span)
/*  881:     */   {
/*  882: 744 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  883: 745 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  884: 746 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  885: 747 */     GLChecks.ensurePackPBOdisabled(caps);
/*  886: 748 */     BufferChecks.checkDirect(row);
/*  887: 749 */     BufferChecks.checkDirect(column);
/*  888: 750 */     BufferChecks.checkDirect(span);
/*  889: 751 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  890:     */   }
/*  891:     */   
/*  892:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ShortBuffer column, FloatBuffer span)
/*  893:     */   {
/*  894: 754 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  895: 755 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  896: 756 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  897: 757 */     GLChecks.ensurePackPBOdisabled(caps);
/*  898: 758 */     BufferChecks.checkDirect(row);
/*  899: 759 */     BufferChecks.checkDirect(column);
/*  900: 760 */     BufferChecks.checkDirect(span);
/*  901: 761 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  902:     */   }
/*  903:     */   
/*  904:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ShortBuffer column, IntBuffer span)
/*  905:     */   {
/*  906: 764 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  907: 765 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  908: 766 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  909: 767 */     GLChecks.ensurePackPBOdisabled(caps);
/*  910: 768 */     BufferChecks.checkDirect(row);
/*  911: 769 */     BufferChecks.checkDirect(column);
/*  912: 770 */     BufferChecks.checkDirect(span);
/*  913: 771 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  914:     */   }
/*  915:     */   
/*  916:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, DoubleBuffer row, ShortBuffer column, ShortBuffer span)
/*  917:     */   {
/*  918: 774 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  919: 775 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  920: 776 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  921: 777 */     GLChecks.ensurePackPBOdisabled(caps);
/*  922: 778 */     BufferChecks.checkDirect(row);
/*  923: 779 */     BufferChecks.checkDirect(column);
/*  924: 780 */     BufferChecks.checkDirect(span);
/*  925: 781 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 3, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  926:     */   }
/*  927:     */   
/*  928:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ByteBuffer column, ByteBuffer span)
/*  929:     */   {
/*  930: 784 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  931: 785 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  932: 786 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  933: 787 */     GLChecks.ensurePackPBOdisabled(caps);
/*  934: 788 */     BufferChecks.checkDirect(row);
/*  935: 789 */     BufferChecks.checkDirect(column);
/*  936: 790 */     BufferChecks.checkDirect(span);
/*  937: 791 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  938:     */   }
/*  939:     */   
/*  940:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ByteBuffer column, DoubleBuffer span)
/*  941:     */   {
/*  942: 794 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  943: 795 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  944: 796 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  945: 797 */     GLChecks.ensurePackPBOdisabled(caps);
/*  946: 798 */     BufferChecks.checkDirect(row);
/*  947: 799 */     BufferChecks.checkDirect(column);
/*  948: 800 */     BufferChecks.checkDirect(span);
/*  949: 801 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  950:     */   }
/*  951:     */   
/*  952:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ByteBuffer column, FloatBuffer span)
/*  953:     */   {
/*  954: 804 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  955: 805 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  956: 806 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  957: 807 */     GLChecks.ensurePackPBOdisabled(caps);
/*  958: 808 */     BufferChecks.checkDirect(row);
/*  959: 809 */     BufferChecks.checkDirect(column);
/*  960: 810 */     BufferChecks.checkDirect(span);
/*  961: 811 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  962:     */   }
/*  963:     */   
/*  964:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ByteBuffer column, IntBuffer span)
/*  965:     */   {
/*  966: 814 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  967: 815 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  968: 816 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  969: 817 */     GLChecks.ensurePackPBOdisabled(caps);
/*  970: 818 */     BufferChecks.checkDirect(row);
/*  971: 819 */     BufferChecks.checkDirect(column);
/*  972: 820 */     BufferChecks.checkDirect(span);
/*  973: 821 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  974:     */   }
/*  975:     */   
/*  976:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ByteBuffer column, ShortBuffer span)
/*  977:     */   {
/*  978: 824 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  979: 825 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  980: 826 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  981: 827 */     GLChecks.ensurePackPBOdisabled(caps);
/*  982: 828 */     BufferChecks.checkDirect(row);
/*  983: 829 */     BufferChecks.checkDirect(column);
/*  984: 830 */     BufferChecks.checkDirect(span);
/*  985: 831 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  986:     */   }
/*  987:     */   
/*  988:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, DoubleBuffer column, ByteBuffer span)
/*  989:     */   {
/*  990: 834 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  991: 835 */     long function_pointer = caps.glGetnSeparableFilterARB;
/*  992: 836 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  993: 837 */     GLChecks.ensurePackPBOdisabled(caps);
/*  994: 838 */     BufferChecks.checkDirect(row);
/*  995: 839 */     BufferChecks.checkDirect(column);
/*  996: 840 */     BufferChecks.checkDirect(span);
/*  997: 841 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/*  998:     */   }
/*  999:     */   
/* 1000:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1001:     */   {
/* 1002: 844 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1003: 845 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1004: 846 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1005: 847 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1006: 848 */     BufferChecks.checkDirect(row);
/* 1007: 849 */     BufferChecks.checkDirect(column);
/* 1008: 850 */     BufferChecks.checkDirect(span);
/* 1009: 851 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, DoubleBuffer column, FloatBuffer span)
/* 1013:     */   {
/* 1014: 854 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1015: 855 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1016: 856 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1017: 857 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1018: 858 */     BufferChecks.checkDirect(row);
/* 1019: 859 */     BufferChecks.checkDirect(column);
/* 1020: 860 */     BufferChecks.checkDirect(span);
/* 1021: 861 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1022:     */   }
/* 1023:     */   
/* 1024:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, DoubleBuffer column, IntBuffer span)
/* 1025:     */   {
/* 1026: 864 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1027: 865 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1028: 866 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1029: 867 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1030: 868 */     BufferChecks.checkDirect(row);
/* 1031: 869 */     BufferChecks.checkDirect(column);
/* 1032: 870 */     BufferChecks.checkDirect(span);
/* 1033: 871 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1034:     */   }
/* 1035:     */   
/* 1036:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1037:     */   {
/* 1038: 874 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1039: 875 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1040: 876 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1041: 877 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1042: 878 */     BufferChecks.checkDirect(row);
/* 1043: 879 */     BufferChecks.checkDirect(column);
/* 1044: 880 */     BufferChecks.checkDirect(span);
/* 1045: 881 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1046:     */   }
/* 1047:     */   
/* 1048:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, FloatBuffer column, ByteBuffer span)
/* 1049:     */   {
/* 1050: 884 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1051: 885 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1052: 886 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1053: 887 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1054: 888 */     BufferChecks.checkDirect(row);
/* 1055: 889 */     BufferChecks.checkDirect(column);
/* 1056: 890 */     BufferChecks.checkDirect(span);
/* 1057: 891 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1058:     */   }
/* 1059:     */   
/* 1060:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, FloatBuffer column, DoubleBuffer span)
/* 1061:     */   {
/* 1062: 894 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1063: 895 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1064: 896 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1065: 897 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1066: 898 */     BufferChecks.checkDirect(row);
/* 1067: 899 */     BufferChecks.checkDirect(column);
/* 1068: 900 */     BufferChecks.checkDirect(span);
/* 1069: 901 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, FloatBuffer column, FloatBuffer span)
/* 1073:     */   {
/* 1074: 904 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1075: 905 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1076: 906 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1077: 907 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1078: 908 */     BufferChecks.checkDirect(row);
/* 1079: 909 */     BufferChecks.checkDirect(column);
/* 1080: 910 */     BufferChecks.checkDirect(span);
/* 1081: 911 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1082:     */   }
/* 1083:     */   
/* 1084:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, FloatBuffer column, IntBuffer span)
/* 1085:     */   {
/* 1086: 914 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1087: 915 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1088: 916 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1089: 917 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1090: 918 */     BufferChecks.checkDirect(row);
/* 1091: 919 */     BufferChecks.checkDirect(column);
/* 1092: 920 */     BufferChecks.checkDirect(span);
/* 1093: 921 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1094:     */   }
/* 1095:     */   
/* 1096:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, FloatBuffer column, ShortBuffer span)
/* 1097:     */   {
/* 1098: 924 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1099: 925 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1100: 926 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1101: 927 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1102: 928 */     BufferChecks.checkDirect(row);
/* 1103: 929 */     BufferChecks.checkDirect(column);
/* 1104: 930 */     BufferChecks.checkDirect(span);
/* 1105: 931 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1106:     */   }
/* 1107:     */   
/* 1108:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, IntBuffer column, ByteBuffer span)
/* 1109:     */   {
/* 1110: 934 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1111: 935 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1112: 936 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1113: 937 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1114: 938 */     BufferChecks.checkDirect(row);
/* 1115: 939 */     BufferChecks.checkDirect(column);
/* 1116: 940 */     BufferChecks.checkDirect(span);
/* 1117: 941 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1118:     */   }
/* 1119:     */   
/* 1120:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, IntBuffer column, DoubleBuffer span)
/* 1121:     */   {
/* 1122: 944 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1123: 945 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1124: 946 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1125: 947 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1126: 948 */     BufferChecks.checkDirect(row);
/* 1127: 949 */     BufferChecks.checkDirect(column);
/* 1128: 950 */     BufferChecks.checkDirect(span);
/* 1129: 951 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, IntBuffer column, FloatBuffer span)
/* 1133:     */   {
/* 1134: 954 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1135: 955 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1136: 956 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1137: 957 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1138: 958 */     BufferChecks.checkDirect(row);
/* 1139: 959 */     BufferChecks.checkDirect(column);
/* 1140: 960 */     BufferChecks.checkDirect(span);
/* 1141: 961 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1142:     */   }
/* 1143:     */   
/* 1144:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, IntBuffer column, IntBuffer span)
/* 1145:     */   {
/* 1146: 964 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1147: 965 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1148: 966 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1149: 967 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1150: 968 */     BufferChecks.checkDirect(row);
/* 1151: 969 */     BufferChecks.checkDirect(column);
/* 1152: 970 */     BufferChecks.checkDirect(span);
/* 1153: 971 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1154:     */   }
/* 1155:     */   
/* 1156:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, IntBuffer column, ShortBuffer span)
/* 1157:     */   {
/* 1158: 974 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1159: 975 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1160: 976 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1161: 977 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1162: 978 */     BufferChecks.checkDirect(row);
/* 1163: 979 */     BufferChecks.checkDirect(column);
/* 1164: 980 */     BufferChecks.checkDirect(span);
/* 1165: 981 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1166:     */   }
/* 1167:     */   
/* 1168:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ShortBuffer column, ByteBuffer span)
/* 1169:     */   {
/* 1170: 984 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1171: 985 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1172: 986 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1173: 987 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1174: 988 */     BufferChecks.checkDirect(row);
/* 1175: 989 */     BufferChecks.checkDirect(column);
/* 1176: 990 */     BufferChecks.checkDirect(span);
/* 1177: 991 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1178:     */   }
/* 1179:     */   
/* 1180:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1181:     */   {
/* 1182: 994 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1183: 995 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1184: 996 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1185: 997 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1186: 998 */     BufferChecks.checkDirect(row);
/* 1187: 999 */     BufferChecks.checkDirect(column);
/* 1188:1000 */     BufferChecks.checkDirect(span);
/* 1189:1001 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1190:     */   }
/* 1191:     */   
/* 1192:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ShortBuffer column, FloatBuffer span)
/* 1193:     */   {
/* 1194:1004 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1195:1005 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1196:1006 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1197:1007 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1198:1008 */     BufferChecks.checkDirect(row);
/* 1199:1009 */     BufferChecks.checkDirect(column);
/* 1200:1010 */     BufferChecks.checkDirect(span);
/* 1201:1011 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1202:     */   }
/* 1203:     */   
/* 1204:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ShortBuffer column, IntBuffer span)
/* 1205:     */   {
/* 1206:1014 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1207:1015 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1208:1016 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1209:1017 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1210:1018 */     BufferChecks.checkDirect(row);
/* 1211:1019 */     BufferChecks.checkDirect(column);
/* 1212:1020 */     BufferChecks.checkDirect(span);
/* 1213:1021 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1214:     */   }
/* 1215:     */   
/* 1216:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, FloatBuffer row, ShortBuffer column, ShortBuffer span)
/* 1217:     */   {
/* 1218:1024 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1219:1025 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1220:1026 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1221:1027 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1222:1028 */     BufferChecks.checkDirect(row);
/* 1223:1029 */     BufferChecks.checkDirect(column);
/* 1224:1030 */     BufferChecks.checkDirect(span);
/* 1225:1031 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1226:     */   }
/* 1227:     */   
/* 1228:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ByteBuffer column, ByteBuffer span)
/* 1229:     */   {
/* 1230:1034 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1231:1035 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1232:1036 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1233:1037 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1234:1038 */     BufferChecks.checkDirect(row);
/* 1235:1039 */     BufferChecks.checkDirect(column);
/* 1236:1040 */     BufferChecks.checkDirect(span);
/* 1237:1041 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1238:     */   }
/* 1239:     */   
/* 1240:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1241:     */   {
/* 1242:1044 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1243:1045 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1244:1046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1245:1047 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1246:1048 */     BufferChecks.checkDirect(row);
/* 1247:1049 */     BufferChecks.checkDirect(column);
/* 1248:1050 */     BufferChecks.checkDirect(span);
/* 1249:1051 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1250:     */   }
/* 1251:     */   
/* 1252:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ByteBuffer column, FloatBuffer span)
/* 1253:     */   {
/* 1254:1054 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1255:1055 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1256:1056 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1257:1057 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1258:1058 */     BufferChecks.checkDirect(row);
/* 1259:1059 */     BufferChecks.checkDirect(column);
/* 1260:1060 */     BufferChecks.checkDirect(span);
/* 1261:1061 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1262:     */   }
/* 1263:     */   
/* 1264:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ByteBuffer column, IntBuffer span)
/* 1265:     */   {
/* 1266:1064 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1267:1065 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1268:1066 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1269:1067 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1270:1068 */     BufferChecks.checkDirect(row);
/* 1271:1069 */     BufferChecks.checkDirect(column);
/* 1272:1070 */     BufferChecks.checkDirect(span);
/* 1273:1071 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1274:     */   }
/* 1275:     */   
/* 1276:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ByteBuffer column, ShortBuffer span)
/* 1277:     */   {
/* 1278:1074 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1279:1075 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1280:1076 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1281:1077 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1282:1078 */     BufferChecks.checkDirect(row);
/* 1283:1079 */     BufferChecks.checkDirect(column);
/* 1284:1080 */     BufferChecks.checkDirect(span);
/* 1285:1081 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1286:     */   }
/* 1287:     */   
/* 1288:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1289:     */   {
/* 1290:1084 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1291:1085 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1292:1086 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1293:1087 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1294:1088 */     BufferChecks.checkDirect(row);
/* 1295:1089 */     BufferChecks.checkDirect(column);
/* 1296:1090 */     BufferChecks.checkDirect(span);
/* 1297:1091 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1298:     */   }
/* 1299:     */   
/* 1300:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1301:     */   {
/* 1302:1094 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1303:1095 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1304:1096 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1305:1097 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1306:1098 */     BufferChecks.checkDirect(row);
/* 1307:1099 */     BufferChecks.checkDirect(column);
/* 1308:1100 */     BufferChecks.checkDirect(span);
/* 1309:1101 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, DoubleBuffer column, FloatBuffer span)
/* 1313:     */   {
/* 1314:1104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1315:1105 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1316:1106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1317:1107 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1318:1108 */     BufferChecks.checkDirect(row);
/* 1319:1109 */     BufferChecks.checkDirect(column);
/* 1320:1110 */     BufferChecks.checkDirect(span);
/* 1321:1111 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1322:     */   }
/* 1323:     */   
/* 1324:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, DoubleBuffer column, IntBuffer span)
/* 1325:     */   {
/* 1326:1114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1327:1115 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1328:1116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1329:1117 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1330:1118 */     BufferChecks.checkDirect(row);
/* 1331:1119 */     BufferChecks.checkDirect(column);
/* 1332:1120 */     BufferChecks.checkDirect(span);
/* 1333:1121 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1334:     */   }
/* 1335:     */   
/* 1336:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1337:     */   {
/* 1338:1124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1339:1125 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1340:1126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1341:1127 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1342:1128 */     BufferChecks.checkDirect(row);
/* 1343:1129 */     BufferChecks.checkDirect(column);
/* 1344:1130 */     BufferChecks.checkDirect(span);
/* 1345:1131 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1346:     */   }
/* 1347:     */   
/* 1348:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, FloatBuffer column, ByteBuffer span)
/* 1349:     */   {
/* 1350:1134 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1351:1135 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1352:1136 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1353:1137 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1354:1138 */     BufferChecks.checkDirect(row);
/* 1355:1139 */     BufferChecks.checkDirect(column);
/* 1356:1140 */     BufferChecks.checkDirect(span);
/* 1357:1141 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1358:     */   }
/* 1359:     */   
/* 1360:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, FloatBuffer column, DoubleBuffer span)
/* 1361:     */   {
/* 1362:1144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1363:1145 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1364:1146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1365:1147 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1366:1148 */     BufferChecks.checkDirect(row);
/* 1367:1149 */     BufferChecks.checkDirect(column);
/* 1368:1150 */     BufferChecks.checkDirect(span);
/* 1369:1151 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1370:     */   }
/* 1371:     */   
/* 1372:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, FloatBuffer column, FloatBuffer span)
/* 1373:     */   {
/* 1374:1154 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1375:1155 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1376:1156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1377:1157 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1378:1158 */     BufferChecks.checkDirect(row);
/* 1379:1159 */     BufferChecks.checkDirect(column);
/* 1380:1160 */     BufferChecks.checkDirect(span);
/* 1381:1161 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1382:     */   }
/* 1383:     */   
/* 1384:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, FloatBuffer column, IntBuffer span)
/* 1385:     */   {
/* 1386:1164 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1387:1165 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1388:1166 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1389:1167 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1390:1168 */     BufferChecks.checkDirect(row);
/* 1391:1169 */     BufferChecks.checkDirect(column);
/* 1392:1170 */     BufferChecks.checkDirect(span);
/* 1393:1171 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1394:     */   }
/* 1395:     */   
/* 1396:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, FloatBuffer column, ShortBuffer span)
/* 1397:     */   {
/* 1398:1174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1399:1175 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1400:1176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1401:1177 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1402:1178 */     BufferChecks.checkDirect(row);
/* 1403:1179 */     BufferChecks.checkDirect(column);
/* 1404:1180 */     BufferChecks.checkDirect(span);
/* 1405:1181 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1406:     */   }
/* 1407:     */   
/* 1408:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, IntBuffer column, ByteBuffer span)
/* 1409:     */   {
/* 1410:1184 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1411:1185 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1412:1186 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1413:1187 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1414:1188 */     BufferChecks.checkDirect(row);
/* 1415:1189 */     BufferChecks.checkDirect(column);
/* 1416:1190 */     BufferChecks.checkDirect(span);
/* 1417:1191 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1418:     */   }
/* 1419:     */   
/* 1420:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, IntBuffer column, DoubleBuffer span)
/* 1421:     */   {
/* 1422:1194 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1423:1195 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1424:1196 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1425:1197 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1426:1198 */     BufferChecks.checkDirect(row);
/* 1427:1199 */     BufferChecks.checkDirect(column);
/* 1428:1200 */     BufferChecks.checkDirect(span);
/* 1429:1201 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1430:     */   }
/* 1431:     */   
/* 1432:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, IntBuffer column, FloatBuffer span)
/* 1433:     */   {
/* 1434:1204 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1435:1205 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1436:1206 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1437:1207 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1438:1208 */     BufferChecks.checkDirect(row);
/* 1439:1209 */     BufferChecks.checkDirect(column);
/* 1440:1210 */     BufferChecks.checkDirect(span);
/* 1441:1211 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1442:     */   }
/* 1443:     */   
/* 1444:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, IntBuffer column, IntBuffer span)
/* 1445:     */   {
/* 1446:1214 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1447:1215 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1448:1216 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1449:1217 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1450:1218 */     BufferChecks.checkDirect(row);
/* 1451:1219 */     BufferChecks.checkDirect(column);
/* 1452:1220 */     BufferChecks.checkDirect(span);
/* 1453:1221 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1454:     */   }
/* 1455:     */   
/* 1456:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, IntBuffer column, ShortBuffer span)
/* 1457:     */   {
/* 1458:1224 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1459:1225 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1460:1226 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1461:1227 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1462:1228 */     BufferChecks.checkDirect(row);
/* 1463:1229 */     BufferChecks.checkDirect(column);
/* 1464:1230 */     BufferChecks.checkDirect(span);
/* 1465:1231 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1466:     */   }
/* 1467:     */   
/* 1468:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ShortBuffer column, ByteBuffer span)
/* 1469:     */   {
/* 1470:1234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1471:1235 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1472:1236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1473:1237 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1474:1238 */     BufferChecks.checkDirect(row);
/* 1475:1239 */     BufferChecks.checkDirect(column);
/* 1476:1240 */     BufferChecks.checkDirect(span);
/* 1477:1241 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1478:     */   }
/* 1479:     */   
/* 1480:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1481:     */   {
/* 1482:1244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1483:1245 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1484:1246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1485:1247 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1486:1248 */     BufferChecks.checkDirect(row);
/* 1487:1249 */     BufferChecks.checkDirect(column);
/* 1488:1250 */     BufferChecks.checkDirect(span);
/* 1489:1251 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1490:     */   }
/* 1491:     */   
/* 1492:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ShortBuffer column, FloatBuffer span)
/* 1493:     */   {
/* 1494:1254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1495:1255 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1496:1256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1497:1257 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1498:1258 */     BufferChecks.checkDirect(row);
/* 1499:1259 */     BufferChecks.checkDirect(column);
/* 1500:1260 */     BufferChecks.checkDirect(span);
/* 1501:1261 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1502:     */   }
/* 1503:     */   
/* 1504:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ShortBuffer column, IntBuffer span)
/* 1505:     */   {
/* 1506:1264 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1507:1265 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1508:1266 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1509:1267 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1510:1268 */     BufferChecks.checkDirect(row);
/* 1511:1269 */     BufferChecks.checkDirect(column);
/* 1512:1270 */     BufferChecks.checkDirect(span);
/* 1513:1271 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1514:     */   }
/* 1515:     */   
/* 1516:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, IntBuffer row, ShortBuffer column, ShortBuffer span)
/* 1517:     */   {
/* 1518:1274 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1519:1275 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1520:1276 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1521:1277 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1522:1278 */     BufferChecks.checkDirect(row);
/* 1523:1279 */     BufferChecks.checkDirect(column);
/* 1524:1280 */     BufferChecks.checkDirect(span);
/* 1525:1281 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 2, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1526:     */   }
/* 1527:     */   
/* 1528:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ByteBuffer column, ByteBuffer span)
/* 1529:     */   {
/* 1530:1284 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1531:1285 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1532:1286 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1533:1287 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1534:1288 */     BufferChecks.checkDirect(row);
/* 1535:1289 */     BufferChecks.checkDirect(column);
/* 1536:1290 */     BufferChecks.checkDirect(span);
/* 1537:1291 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1538:     */   }
/* 1539:     */   
/* 1540:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1541:     */   {
/* 1542:1294 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1543:1295 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1544:1296 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1545:1297 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1546:1298 */     BufferChecks.checkDirect(row);
/* 1547:1299 */     BufferChecks.checkDirect(column);
/* 1548:1300 */     BufferChecks.checkDirect(span);
/* 1549:1301 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1550:     */   }
/* 1551:     */   
/* 1552:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ByteBuffer column, FloatBuffer span)
/* 1553:     */   {
/* 1554:1304 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1555:1305 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1556:1306 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1557:1307 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1558:1308 */     BufferChecks.checkDirect(row);
/* 1559:1309 */     BufferChecks.checkDirect(column);
/* 1560:1310 */     BufferChecks.checkDirect(span);
/* 1561:1311 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1562:     */   }
/* 1563:     */   
/* 1564:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ByteBuffer column, IntBuffer span)
/* 1565:     */   {
/* 1566:1314 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1567:1315 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1568:1316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1569:1317 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1570:1318 */     BufferChecks.checkDirect(row);
/* 1571:1319 */     BufferChecks.checkDirect(column);
/* 1572:1320 */     BufferChecks.checkDirect(span);
/* 1573:1321 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1574:     */   }
/* 1575:     */   
/* 1576:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ByteBuffer column, ShortBuffer span)
/* 1577:     */   {
/* 1578:1324 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1579:1325 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1580:1326 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1581:1327 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1582:1328 */     BufferChecks.checkDirect(row);
/* 1583:1329 */     BufferChecks.checkDirect(column);
/* 1584:1330 */     BufferChecks.checkDirect(span);
/* 1585:1331 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining(), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1586:     */   }
/* 1587:     */   
/* 1588:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1589:     */   {
/* 1590:1334 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1591:1335 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1592:1336 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1593:1337 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1594:1338 */     BufferChecks.checkDirect(row);
/* 1595:1339 */     BufferChecks.checkDirect(column);
/* 1596:1340 */     BufferChecks.checkDirect(span);
/* 1597:1341 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1598:     */   }
/* 1599:     */   
/* 1600:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1601:     */   {
/* 1602:1344 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1603:1345 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1604:1346 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1605:1347 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1606:1348 */     BufferChecks.checkDirect(row);
/* 1607:1349 */     BufferChecks.checkDirect(column);
/* 1608:1350 */     BufferChecks.checkDirect(span);
/* 1609:1351 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1610:     */   }
/* 1611:     */   
/* 1612:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, DoubleBuffer column, FloatBuffer span)
/* 1613:     */   {
/* 1614:1354 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1615:1355 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1616:1356 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1617:1357 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1618:1358 */     BufferChecks.checkDirect(row);
/* 1619:1359 */     BufferChecks.checkDirect(column);
/* 1620:1360 */     BufferChecks.checkDirect(span);
/* 1621:1361 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1622:     */   }
/* 1623:     */   
/* 1624:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, DoubleBuffer column, IntBuffer span)
/* 1625:     */   {
/* 1626:1364 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1627:1365 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1628:1366 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1629:1367 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1630:1368 */     BufferChecks.checkDirect(row);
/* 1631:1369 */     BufferChecks.checkDirect(column);
/* 1632:1370 */     BufferChecks.checkDirect(span);
/* 1633:1371 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1634:     */   }
/* 1635:     */   
/* 1636:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1637:     */   {
/* 1638:1374 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1639:1375 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1640:1376 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1641:1377 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1642:1378 */     BufferChecks.checkDirect(row);
/* 1643:1379 */     BufferChecks.checkDirect(column);
/* 1644:1380 */     BufferChecks.checkDirect(span);
/* 1645:1381 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 3, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1646:     */   }
/* 1647:     */   
/* 1648:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, FloatBuffer column, ByteBuffer span)
/* 1649:     */   {
/* 1650:1384 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1651:1385 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1652:1386 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1653:1387 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1654:1388 */     BufferChecks.checkDirect(row);
/* 1655:1389 */     BufferChecks.checkDirect(column);
/* 1656:1390 */     BufferChecks.checkDirect(span);
/* 1657:1391 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1658:     */   }
/* 1659:     */   
/* 1660:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, FloatBuffer column, DoubleBuffer span)
/* 1661:     */   {
/* 1662:1394 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1663:1395 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1664:1396 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1665:1397 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1666:1398 */     BufferChecks.checkDirect(row);
/* 1667:1399 */     BufferChecks.checkDirect(column);
/* 1668:1400 */     BufferChecks.checkDirect(span);
/* 1669:1401 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1670:     */   }
/* 1671:     */   
/* 1672:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, FloatBuffer column, FloatBuffer span)
/* 1673:     */   {
/* 1674:1404 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1675:1405 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1676:1406 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1677:1407 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1678:1408 */     BufferChecks.checkDirect(row);
/* 1679:1409 */     BufferChecks.checkDirect(column);
/* 1680:1410 */     BufferChecks.checkDirect(span);
/* 1681:1411 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1682:     */   }
/* 1683:     */   
/* 1684:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, FloatBuffer column, IntBuffer span)
/* 1685:     */   {
/* 1686:1414 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1687:1415 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1688:1416 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1689:1417 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1690:1418 */     BufferChecks.checkDirect(row);
/* 1691:1419 */     BufferChecks.checkDirect(column);
/* 1692:1420 */     BufferChecks.checkDirect(span);
/* 1693:1421 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1694:     */   }
/* 1695:     */   
/* 1696:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, FloatBuffer column, ShortBuffer span)
/* 1697:     */   {
/* 1698:1424 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1699:1425 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1700:1426 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1701:1427 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1702:1428 */     BufferChecks.checkDirect(row);
/* 1703:1429 */     BufferChecks.checkDirect(column);
/* 1704:1430 */     BufferChecks.checkDirect(span);
/* 1705:1431 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1706:     */   }
/* 1707:     */   
/* 1708:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, IntBuffer column, ByteBuffer span)
/* 1709:     */   {
/* 1710:1434 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1711:1435 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1712:1436 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1713:1437 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1714:1438 */     BufferChecks.checkDirect(row);
/* 1715:1439 */     BufferChecks.checkDirect(column);
/* 1716:1440 */     BufferChecks.checkDirect(span);
/* 1717:1441 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1718:     */   }
/* 1719:     */   
/* 1720:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, IntBuffer column, DoubleBuffer span)
/* 1721:     */   {
/* 1722:1444 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1723:1445 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1724:1446 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1725:1447 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1726:1448 */     BufferChecks.checkDirect(row);
/* 1727:1449 */     BufferChecks.checkDirect(column);
/* 1728:1450 */     BufferChecks.checkDirect(span);
/* 1729:1451 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1730:     */   }
/* 1731:     */   
/* 1732:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, IntBuffer column, FloatBuffer span)
/* 1733:     */   {
/* 1734:1454 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1735:1455 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1736:1456 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1737:1457 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1738:1458 */     BufferChecks.checkDirect(row);
/* 1739:1459 */     BufferChecks.checkDirect(column);
/* 1740:1460 */     BufferChecks.checkDirect(span);
/* 1741:1461 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1742:     */   }
/* 1743:     */   
/* 1744:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, IntBuffer column, IntBuffer span)
/* 1745:     */   {
/* 1746:1464 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1747:1465 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1748:1466 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1749:1467 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1750:1468 */     BufferChecks.checkDirect(row);
/* 1751:1469 */     BufferChecks.checkDirect(column);
/* 1752:1470 */     BufferChecks.checkDirect(span);
/* 1753:1471 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1754:     */   }
/* 1755:     */   
/* 1756:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, IntBuffer column, ShortBuffer span)
/* 1757:     */   {
/* 1758:1474 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1759:1475 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1760:1476 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1761:1477 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1762:1478 */     BufferChecks.checkDirect(row);
/* 1763:1479 */     BufferChecks.checkDirect(column);
/* 1764:1480 */     BufferChecks.checkDirect(span);
/* 1765:1481 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 2, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1766:     */   }
/* 1767:     */   
/* 1768:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ShortBuffer column, ByteBuffer span)
/* 1769:     */   {
/* 1770:1484 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1771:1485 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1772:1486 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1773:1487 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1774:1488 */     BufferChecks.checkDirect(row);
/* 1775:1489 */     BufferChecks.checkDirect(column);
/* 1776:1490 */     BufferChecks.checkDirect(span);
/* 1777:1491 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1778:     */   }
/* 1779:     */   
/* 1780:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1781:     */   {
/* 1782:1494 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1783:1495 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1784:1496 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1785:1497 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1786:1498 */     BufferChecks.checkDirect(row);
/* 1787:1499 */     BufferChecks.checkDirect(column);
/* 1788:1500 */     BufferChecks.checkDirect(span);
/* 1789:1501 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1790:     */   }
/* 1791:     */   
/* 1792:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ShortBuffer column, FloatBuffer span)
/* 1793:     */   {
/* 1794:1504 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1795:1505 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1796:1506 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1797:1507 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1798:1508 */     BufferChecks.checkDirect(row);
/* 1799:1509 */     BufferChecks.checkDirect(column);
/* 1800:1510 */     BufferChecks.checkDirect(span);
/* 1801:1511 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1802:     */   }
/* 1803:     */   
/* 1804:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ShortBuffer column, IntBuffer span)
/* 1805:     */   {
/* 1806:1514 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1807:1515 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1808:1516 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1809:1517 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1810:1518 */     BufferChecks.checkDirect(row);
/* 1811:1519 */     BufferChecks.checkDirect(column);
/* 1812:1520 */     BufferChecks.checkDirect(span);
/* 1813:1521 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1814:     */   }
/* 1815:     */   
/* 1816:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, ShortBuffer row, ShortBuffer column, ShortBuffer span)
/* 1817:     */   {
/* 1818:1524 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1819:1525 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1820:1526 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1821:1527 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1822:1528 */     BufferChecks.checkDirect(row);
/* 1823:1529 */     BufferChecks.checkDirect(column);
/* 1824:1530 */     BufferChecks.checkDirect(span);
/* 1825:1531 */     nglGetnSeparableFilterARB(target, format, type, row.remaining() << 1, MemoryUtil.getAddress(row), column.remaining() << 1, MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1826:     */   }
/* 1827:     */   
/* 1828:     */   static native void nglGetnSeparableFilterARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, int paramInt5, long paramLong2, long paramLong3, long paramLong4);
/* 1829:     */   
/* 1830:     */   public static void glGetnSeparableFilterARB(int target, int format, int type, int row_rowBufSize, long row_buffer_offset, int column_columnBufSize, long column_buffer_offset, long span_buffer_offset)
/* 1831:     */   {
/* 1832:1535 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1833:1536 */     long function_pointer = caps.glGetnSeparableFilterARB;
/* 1834:1537 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1835:1538 */     GLChecks.ensurePackPBOenabled(caps);
/* 1836:1539 */     nglGetnSeparableFilterARBBO(target, format, type, row_rowBufSize, row_buffer_offset, column_columnBufSize, column_buffer_offset, span_buffer_offset, function_pointer);
/* 1837:     */   }
/* 1838:     */   
/* 1839:     */   static native void nglGetnSeparableFilterARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, int paramInt5, long paramLong2, long paramLong3, long paramLong4);
/* 1840:     */   
/* 1841:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, ByteBuffer values)
/* 1842:     */   {
/* 1843:1544 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1844:1545 */     long function_pointer = caps.glGetnHistogramARB;
/* 1845:1546 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1846:1547 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1847:1548 */     BufferChecks.checkDirect(values);
/* 1848:1549 */     nglGetnHistogramARB(target, reset, format, type, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 1849:     */   }
/* 1850:     */   
/* 1851:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, DoubleBuffer values)
/* 1852:     */   {
/* 1853:1552 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1854:1553 */     long function_pointer = caps.glGetnHistogramARB;
/* 1855:1554 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1856:1555 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1857:1556 */     BufferChecks.checkDirect(values);
/* 1858:1557 */     nglGetnHistogramARB(target, reset, format, type, values.remaining() << 3, MemoryUtil.getAddress(values), function_pointer);
/* 1859:     */   }
/* 1860:     */   
/* 1861:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, FloatBuffer values)
/* 1862:     */   {
/* 1863:1560 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1864:1561 */     long function_pointer = caps.glGetnHistogramARB;
/* 1865:1562 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1866:1563 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1867:1564 */     BufferChecks.checkDirect(values);
/* 1868:1565 */     nglGetnHistogramARB(target, reset, format, type, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/* 1869:     */   }
/* 1870:     */   
/* 1871:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, IntBuffer values)
/* 1872:     */   {
/* 1873:1568 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1874:1569 */     long function_pointer = caps.glGetnHistogramARB;
/* 1875:1570 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1876:1571 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1877:1572 */     BufferChecks.checkDirect(values);
/* 1878:1573 */     nglGetnHistogramARB(target, reset, format, type, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/* 1879:     */   }
/* 1880:     */   
/* 1881:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, ShortBuffer values)
/* 1882:     */   {
/* 1883:1576 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1884:1577 */     long function_pointer = caps.glGetnHistogramARB;
/* 1885:1578 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1886:1579 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1887:1580 */     BufferChecks.checkDirect(values);
/* 1888:1581 */     nglGetnHistogramARB(target, reset, format, type, values.remaining() << 1, MemoryUtil.getAddress(values), function_pointer);
/* 1889:     */   }
/* 1890:     */   
/* 1891:     */   static native void nglGetnHistogramARB(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1892:     */   
/* 1893:     */   public static void glGetnHistogramARB(int target, boolean reset, int format, int type, int values_bufSize, long values_buffer_offset)
/* 1894:     */   {
/* 1895:1585 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1896:1586 */     long function_pointer = caps.glGetnHistogramARB;
/* 1897:1587 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1898:1588 */     GLChecks.ensurePackPBOenabled(caps);
/* 1899:1589 */     nglGetnHistogramARBBO(target, reset, format, type, values_bufSize, values_buffer_offset, function_pointer);
/* 1900:     */   }
/* 1901:     */   
/* 1902:     */   static native void nglGetnHistogramARBBO(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1903:     */   
/* 1904:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, ByteBuffer values)
/* 1905:     */   {
/* 1906:1594 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1907:1595 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1908:1596 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1909:1597 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1910:1598 */     BufferChecks.checkDirect(values);
/* 1911:1599 */     nglGetnMinmaxARB(target, reset, format, type, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 1912:     */   }
/* 1913:     */   
/* 1914:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, DoubleBuffer values)
/* 1915:     */   {
/* 1916:1602 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1917:1603 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1918:1604 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1919:1605 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1920:1606 */     BufferChecks.checkDirect(values);
/* 1921:1607 */     nglGetnMinmaxARB(target, reset, format, type, values.remaining() << 3, MemoryUtil.getAddress(values), function_pointer);
/* 1922:     */   }
/* 1923:     */   
/* 1924:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, FloatBuffer values)
/* 1925:     */   {
/* 1926:1610 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1927:1611 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1928:1612 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1929:1613 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1930:1614 */     BufferChecks.checkDirect(values);
/* 1931:1615 */     nglGetnMinmaxARB(target, reset, format, type, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/* 1932:     */   }
/* 1933:     */   
/* 1934:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, IntBuffer values)
/* 1935:     */   {
/* 1936:1618 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1937:1619 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1938:1620 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1939:1621 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1940:1622 */     BufferChecks.checkDirect(values);
/* 1941:1623 */     nglGetnMinmaxARB(target, reset, format, type, values.remaining() << 2, MemoryUtil.getAddress(values), function_pointer);
/* 1942:     */   }
/* 1943:     */   
/* 1944:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, ShortBuffer values)
/* 1945:     */   {
/* 1946:1626 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1947:1627 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1948:1628 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1949:1629 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1950:1630 */     BufferChecks.checkDirect(values);
/* 1951:1631 */     nglGetnMinmaxARB(target, reset, format, type, values.remaining() << 1, MemoryUtil.getAddress(values), function_pointer);
/* 1952:     */   }
/* 1953:     */   
/* 1954:     */   static native void nglGetnMinmaxARB(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1955:     */   
/* 1956:     */   public static void glGetnMinmaxARB(int target, boolean reset, int format, int type, int values_bufSize, long values_buffer_offset)
/* 1957:     */   {
/* 1958:1635 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1959:1636 */     long function_pointer = caps.glGetnMinmaxARB;
/* 1960:1637 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1961:1638 */     GLChecks.ensurePackPBOenabled(caps);
/* 1962:1639 */     nglGetnMinmaxARBBO(target, reset, format, type, values_bufSize, values_buffer_offset, function_pointer);
/* 1963:     */   }
/* 1964:     */   
/* 1965:     */   static native void nglGetnMinmaxARBBO(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1966:     */   
/* 1967:     */   public static void glGetnCompressedTexImageARB(int target, int lod, ByteBuffer img)
/* 1968:     */   {
/* 1969:1644 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1970:1645 */     long function_pointer = caps.glGetnCompressedTexImageARB;
/* 1971:1646 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1972:1647 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1973:1648 */     BufferChecks.checkDirect(img);
/* 1974:1649 */     nglGetnCompressedTexImageARB(target, lod, img.remaining(), MemoryUtil.getAddress(img), function_pointer);
/* 1975:     */   }
/* 1976:     */   
/* 1977:     */   public static void glGetnCompressedTexImageARB(int target, int lod, IntBuffer img)
/* 1978:     */   {
/* 1979:1652 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1980:1653 */     long function_pointer = caps.glGetnCompressedTexImageARB;
/* 1981:1654 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1982:1655 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1983:1656 */     BufferChecks.checkDirect(img);
/* 1984:1657 */     nglGetnCompressedTexImageARB(target, lod, img.remaining() << 2, MemoryUtil.getAddress(img), function_pointer);
/* 1985:     */   }
/* 1986:     */   
/* 1987:     */   public static void glGetnCompressedTexImageARB(int target, int lod, ShortBuffer img)
/* 1988:     */   {
/* 1989:1660 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1990:1661 */     long function_pointer = caps.glGetnCompressedTexImageARB;
/* 1991:1662 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1992:1663 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1993:1664 */     BufferChecks.checkDirect(img);
/* 1994:1665 */     nglGetnCompressedTexImageARB(target, lod, img.remaining() << 1, MemoryUtil.getAddress(img), function_pointer);
/* 1995:     */   }
/* 1996:     */   
/* 1997:     */   static native void nglGetnCompressedTexImageARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1998:     */   
/* 1999:     */   public static void glGetnCompressedTexImageARB(int target, int lod, int img_bufSize, long img_buffer_offset)
/* 2000:     */   {
/* 2001:1669 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2002:1670 */     long function_pointer = caps.glGetnCompressedTexImageARB;
/* 2003:1671 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2004:1672 */     GLChecks.ensurePackPBOenabled(caps);
/* 2005:1673 */     nglGetnCompressedTexImageARBBO(target, lod, img_bufSize, img_buffer_offset, function_pointer);
/* 2006:     */   }
/* 2007:     */   
/* 2008:     */   static native void nglGetnCompressedTexImageARBBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2009:     */   
/* 2010:     */   public static void glGetnUniformfvARB(int program, int location, FloatBuffer params)
/* 2011:     */   {
/* 2012:1678 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2013:1679 */     long function_pointer = caps.glGetnUniformfvARB;
/* 2014:1680 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2015:1681 */     BufferChecks.checkDirect(params);
/* 2016:1682 */     nglGetnUniformfvARB(program, location, params.remaining() << 2, MemoryUtil.getAddress(params), function_pointer);
/* 2017:     */   }
/* 2018:     */   
/* 2019:     */   static native void nglGetnUniformfvARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2020:     */   
/* 2021:     */   public static void glGetnUniformivARB(int program, int location, IntBuffer params)
/* 2022:     */   {
/* 2023:1687 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2024:1688 */     long function_pointer = caps.glGetnUniformivARB;
/* 2025:1689 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2026:1690 */     BufferChecks.checkDirect(params);
/* 2027:1691 */     nglGetnUniformivARB(program, location, params.remaining() << 2, MemoryUtil.getAddress(params), function_pointer);
/* 2028:     */   }
/* 2029:     */   
/* 2030:     */   static native void nglGetnUniformivARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2031:     */   
/* 2032:     */   public static void glGetnUniformuivARB(int program, int location, IntBuffer params)
/* 2033:     */   {
/* 2034:1696 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2035:1697 */     long function_pointer = caps.glGetnUniformuivARB;
/* 2036:1698 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2037:1699 */     BufferChecks.checkDirect(params);
/* 2038:1700 */     nglGetnUniformuivARB(program, location, params.remaining() << 2, MemoryUtil.getAddress(params), function_pointer);
/* 2039:     */   }
/* 2040:     */   
/* 2041:     */   static native void nglGetnUniformuivARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2042:     */   
/* 2043:     */   public static void glGetnUniformdvARB(int program, int location, DoubleBuffer params)
/* 2044:     */   {
/* 2045:1705 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2046:1706 */     long function_pointer = caps.glGetnUniformdvARB;
/* 2047:1707 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2048:1708 */     BufferChecks.checkDirect(params);
/* 2049:1709 */     nglGetnUniformdvARB(program, location, params.remaining() << 3, MemoryUtil.getAddress(params), function_pointer);
/* 2050:     */   }
/* 2051:     */   
/* 2052:     */   static native void nglGetnUniformdvARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2053:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBRobustness
 * JD-Core Version:    0.7.0.1
 */