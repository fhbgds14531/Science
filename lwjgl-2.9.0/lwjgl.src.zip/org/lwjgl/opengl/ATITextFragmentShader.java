package org.lwjgl.opengl;

public final class ATITextFragmentShader
{
  public static final int GL_TEXT_FRAGMENT_SHADER_ATI = 33280;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATITextFragmentShader
 * JD-Core Version:    0.7.0.1
 */