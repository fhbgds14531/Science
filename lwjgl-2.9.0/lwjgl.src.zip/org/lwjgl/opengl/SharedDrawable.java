/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.LWJGLException;
/*  4:   */ 
/*  5:   */ public final class SharedDrawable
/*  6:   */   extends DrawableGL
/*  7:   */ {
/*  8:   */   public SharedDrawable(Drawable drawable)
/*  9:   */     throws LWJGLException
/* 10:   */   {
/* 11:50 */     this.context = ((ContextGL)((DrawableLWJGL)drawable).createSharedContext());
/* 12:   */   }
/* 13:   */   
/* 14:   */   public ContextGL createSharedContext()
/* 15:   */   {
/* 16:54 */     throw new UnsupportedOperationException();
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.SharedDrawable
 * JD-Core Version:    0.7.0.1
 */