/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerWrapperAbstract;
/*  4:   */ 
/*  5:   */ public final class GLSync
/*  6:   */   extends PointerWrapperAbstract
/*  7:   */ {
/*  8:   */   GLSync(long sync)
/*  9:   */   {
/* 10:44 */     super(sync);
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GLSync
 * JD-Core Version:    0.7.0.1
 */