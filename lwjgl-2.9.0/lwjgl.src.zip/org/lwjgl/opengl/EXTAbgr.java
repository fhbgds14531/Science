package org.lwjgl.opengl;

public final class EXTAbgr
{
  public static final int GL_ABGR_EXT = 32768;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTAbgr
 * JD-Core Version:    0.7.0.1
 */