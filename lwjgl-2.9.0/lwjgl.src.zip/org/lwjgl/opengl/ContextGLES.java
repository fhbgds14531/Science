/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.LWJGLException;
/*   4:    */ import org.lwjgl.LWJGLUtil;
/*   5:    */ import org.lwjgl.Sys;
/*   6:    */ import org.lwjgl.opengles.ContextAttribs;
/*   7:    */ import org.lwjgl.opengles.ContextCapabilities;
/*   8:    */ import org.lwjgl.opengles.EGL;
/*   9:    */ import org.lwjgl.opengles.EGLContext;
/*  10:    */ import org.lwjgl.opengles.EGLDisplay;
/*  11:    */ import org.lwjgl.opengles.EGLSurface;
/*  12:    */ import org.lwjgl.opengles.GLContext;
/*  13:    */ import org.lwjgl.opengles.GLES20;
/*  14:    */ import org.lwjgl.opengles.PowerManagementEventException;
/*  15:    */ 
/*  16:    */ final class ContextGLES
/*  17:    */   implements Context
/*  18:    */ {
/*  19: 58 */   private static final ThreadLocal<ContextGLES> current_context_local = new ThreadLocal();
/*  20:    */   private final DrawableGLES drawable;
/*  21:    */   private final EGLContext eglContext;
/*  22:    */   private final ContextAttribs contextAttribs;
/*  23:    */   private boolean destroyed;
/*  24:    */   private boolean destroy_requested;
/*  25:    */   private Thread thread;
/*  26:    */   
/*  27:    */   static
/*  28:    */   {
/*  29: 75 */     Sys.initialize();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public EGLContext getEGLContext()
/*  33:    */   {
/*  34: 79 */     return this.eglContext;
/*  35:    */   }
/*  36:    */   
/*  37:    */   ContextAttribs getContextAttribs()
/*  38:    */   {
/*  39: 83 */     return this.contextAttribs;
/*  40:    */   }
/*  41:    */   
/*  42:    */   static ContextGLES getCurrentContext()
/*  43:    */   {
/*  44: 87 */     return (ContextGLES)current_context_local.get();
/*  45:    */   }
/*  46:    */   
/*  47:    */   ContextGLES(DrawableGLES drawable, ContextAttribs attribs, ContextGLES shared_context)
/*  48:    */     throws LWJGLException
/*  49:    */   {
/*  50: 92 */     if (drawable == null) {
/*  51: 93 */       throw new IllegalArgumentException();
/*  52:    */     }
/*  53: 95 */     ContextGLES context_lock = shared_context != null ? shared_context : this;
/*  54: 98 */     synchronized (context_lock)
/*  55:    */     {
/*  56: 99 */       if ((shared_context != null) && (shared_context.destroyed)) {
/*  57:100 */         throw new IllegalArgumentException("Shared context is destroyed");
/*  58:    */       }
/*  59:102 */       this.drawable = drawable;
/*  60:103 */       this.contextAttribs = attribs;
/*  61:104 */       this.eglContext = drawable.getEGLDisplay().createContext(drawable.getEGLConfig(), shared_context == null ? null : shared_context.eglContext, attribs == null ? new ContextAttribs(2).getAttribList() : attribs.getAttribList());
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void releaseCurrent()
/*  66:    */     throws LWJGLException, PowerManagementEventException
/*  67:    */   {
/*  68:112 */     EGL.eglReleaseCurrent(this.drawable.getEGLDisplay());
/*  69:113 */     GLContext.useContext(null);
/*  70:114 */     current_context_local.set(null);
/*  71:116 */     synchronized (this)
/*  72:    */     {
/*  73:117 */       this.thread = null;
/*  74:118 */       checkDestroy();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static void swapBuffers()
/*  79:    */     throws LWJGLException, PowerManagementEventException
/*  80:    */   {
/*  81:124 */     ContextGLES current_context = getCurrentContext();
/*  82:125 */     if (current_context != null) {
/*  83:126 */       current_context.drawable.getEGLSurface().swapBuffers();
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   private boolean canAccess()
/*  88:    */   {
/*  89:130 */     return (this.thread == null) || (Thread.currentThread() == this.thread);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private void checkAccess()
/*  93:    */   {
/*  94:134 */     if (!canAccess()) {
/*  95:135 */       throw new IllegalStateException("From thread " + Thread.currentThread() + ": " + this.thread + " already has the context current");
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public synchronized void makeCurrent()
/* 100:    */     throws LWJGLException, PowerManagementEventException
/* 101:    */   {
/* 102:140 */     checkAccess();
/* 103:141 */     if (this.destroyed) {
/* 104:142 */       throw new IllegalStateException("Context is destroyed");
/* 105:    */     }
/* 106:143 */     this.thread = Thread.currentThread();
/* 107:144 */     current_context_local.set(this);
/* 108:145 */     this.eglContext.makeCurrent(this.drawable.getEGLSurface());
/* 109:146 */     GLContext.useContext(this);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public synchronized boolean isCurrent()
/* 113:    */     throws LWJGLException
/* 114:    */   {
/* 115:151 */     if (this.destroyed) {
/* 116:152 */       throw new IllegalStateException("Context is destroyed");
/* 117:    */     }
/* 118:153 */     return EGL.eglIsCurrentContext(this.eglContext);
/* 119:    */   }
/* 120:    */   
/* 121:    */   private void checkDestroy()
/* 122:    */   {
/* 123:157 */     if ((!this.destroyed) && (this.destroy_requested)) {
/* 124:    */       try
/* 125:    */       {
/* 126:159 */         this.eglContext.destroy();
/* 127:160 */         this.destroyed = true;
/* 128:161 */         this.thread = null;
/* 129:    */       }
/* 130:    */       catch (LWJGLException e)
/* 131:    */       {
/* 132:163 */         LWJGLUtil.log("Exception occurred while destroying context: " + e);
/* 133:    */       }
/* 134:    */     }
/* 135:    */   }
/* 136:    */   
/* 137:    */   public static void setSwapInterval(int value)
/* 138:    */   {
/* 139:176 */     ContextGLES current_context = getCurrentContext();
/* 140:177 */     if (current_context != null) {
/* 141:    */       try
/* 142:    */       {
/* 143:179 */         current_context.drawable.getEGLDisplay().setSwapInterval(value);
/* 144:    */       }
/* 145:    */       catch (LWJGLException e)
/* 146:    */       {
/* 147:181 */         LWJGLUtil.log("Failed to set swap interval. Reason: " + e.getMessage());
/* 148:    */       }
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   public synchronized void forceDestroy()
/* 153:    */     throws LWJGLException
/* 154:    */   {
/* 155:192 */     checkAccess();
/* 156:193 */     destroy();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public synchronized void destroy()
/* 160:    */     throws LWJGLException
/* 161:    */   {
/* 162:201 */     if (this.destroyed) {
/* 163:202 */       return;
/* 164:    */     }
/* 165:203 */     this.destroy_requested = true;
/* 166:204 */     boolean was_current = isCurrent();
/* 167:205 */     int error = 0;
/* 168:206 */     if (was_current)
/* 169:    */     {
/* 170:207 */       if ((GLContext.getCapabilities() != null) && (GLContext.getCapabilities().OpenGLES20)) {
/* 171:208 */         error = GLES20.glGetError();
/* 172:    */       }
/* 173:    */       try
/* 174:    */       {
/* 175:211 */         releaseCurrent();
/* 176:    */       }
/* 177:    */       catch (PowerManagementEventException e) {}
/* 178:    */     }
/* 179:216 */     checkDestroy();
/* 180:217 */     if ((was_current) && (error != 0)) {
/* 181:218 */       throw new OpenGLException(error);
/* 182:    */     }
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void releaseDrawable()
/* 186:    */     throws LWJGLException
/* 187:    */   {}
/* 188:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ContextGLES
 * JD-Core Version:    0.7.0.1
 */