/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.Buffer;
/*  4:   */ 
/*  5:   */ class References
/*  6:   */   extends BaseReferences
/*  7:   */ {
/*  8:   */   Buffer ARB_matrix_palette_glMatrixIndexPointerARB_pPointer;
/*  9:   */   Buffer ARB_vertex_blend_glWeightPointerARB_pPointer;
/* 10:   */   Buffer EXT_fog_coord_glFogCoordPointerEXT_data;
/* 11:   */   Buffer EXT_secondary_color_glSecondaryColorPointerEXT_pPointer;
/* 12:   */   Buffer EXT_vertex_shader_glVariantPointerEXT_pAddr;
/* 13:   */   Buffer EXT_vertex_weighting_glVertexWeightPointerEXT_pPointer;
/* 14:   */   Buffer GL11_glColorPointer_pointer;
/* 15:   */   Buffer GL11_glEdgeFlagPointer_pointer;
/* 16:   */   Buffer GL11_glNormalPointer_pointer;
/* 17:   */   Buffer GL11_glVertexPointer_pointer;
/* 18:   */   Buffer GL14_glFogCoordPointer_data;
/* 19:   */   
/* 20:   */   References(ContextCapabilities caps)
/* 21:   */   {
/* 22: 7 */     super(caps);
/* 23:   */   }
/* 24:   */   
/* 25:   */   void copy(References references, int mask)
/* 26:   */   {
/* 27:22 */     super.copy(references, mask);
/* 28:23 */     if ((mask & 0x2) != 0)
/* 29:   */     {
/* 30:24 */       this.ARB_matrix_palette_glMatrixIndexPointerARB_pPointer = references.ARB_matrix_palette_glMatrixIndexPointerARB_pPointer;
/* 31:25 */       this.ARB_vertex_blend_glWeightPointerARB_pPointer = references.ARB_vertex_blend_glWeightPointerARB_pPointer;
/* 32:26 */       this.EXT_fog_coord_glFogCoordPointerEXT_data = references.EXT_fog_coord_glFogCoordPointerEXT_data;
/* 33:27 */       this.EXT_secondary_color_glSecondaryColorPointerEXT_pPointer = references.EXT_secondary_color_glSecondaryColorPointerEXT_pPointer;
/* 34:28 */       this.EXT_vertex_shader_glVariantPointerEXT_pAddr = references.EXT_vertex_shader_glVariantPointerEXT_pAddr;
/* 35:29 */       this.EXT_vertex_weighting_glVertexWeightPointerEXT_pPointer = references.EXT_vertex_weighting_glVertexWeightPointerEXT_pPointer;
/* 36:30 */       this.GL11_glColorPointer_pointer = references.GL11_glColorPointer_pointer;
/* 37:31 */       this.GL11_glEdgeFlagPointer_pointer = references.GL11_glEdgeFlagPointer_pointer;
/* 38:32 */       this.GL11_glNormalPointer_pointer = references.GL11_glNormalPointer_pointer;
/* 39:33 */       this.GL11_glVertexPointer_pointer = references.GL11_glVertexPointer_pointer;
/* 40:34 */       this.GL14_glFogCoordPointer_data = references.GL14_glFogCoordPointer_data;
/* 41:   */     }
/* 42:   */   }
/* 43:   */   
/* 44:   */   void clear()
/* 45:   */   {
/* 46:38 */     super.clear();
/* 47:39 */     this.ARB_matrix_palette_glMatrixIndexPointerARB_pPointer = null;
/* 48:40 */     this.ARB_vertex_blend_glWeightPointerARB_pPointer = null;
/* 49:41 */     this.EXT_fog_coord_glFogCoordPointerEXT_data = null;
/* 50:42 */     this.EXT_secondary_color_glSecondaryColorPointerEXT_pPointer = null;
/* 51:43 */     this.EXT_vertex_shader_glVariantPointerEXT_pAddr = null;
/* 52:44 */     this.EXT_vertex_weighting_glVertexWeightPointerEXT_pPointer = null;
/* 53:45 */     this.GL11_glColorPointer_pointer = null;
/* 54:46 */     this.GL11_glEdgeFlagPointer_pointer = null;
/* 55:47 */     this.GL11_glNormalPointer_pointer = null;
/* 56:48 */     this.GL11_glVertexPointer_pointer = null;
/* 57:49 */     this.GL14_glFogCoordPointer_data = null;
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.References
 * JD-Core Version:    0.7.0.1
 */