/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.util.Set;
/*  4:   */ import java.util.StringTokenizer;
/*  5:   */ 
/*  6:   */ public class CLPlatformCapabilities
/*  7:   */ {
/*  8:   */   public final int majorVersion;
/*  9:   */   public final int minorVersion;
/* 10:   */   public final boolean OpenCL11;
/* 11:   */   public final boolean OpenCL12;
/* 12:   */   public final boolean CL_KHR_d3d10_sharing;
/* 13:   */   public final boolean CL_KHR_gl_event;
/* 14:   */   public final boolean CL_KHR_gl_sharing;
/* 15:   */   public final boolean CL_KHR_icd;
/* 16:   */   
/* 17:   */   public CLPlatformCapabilities(CLPlatform platform)
/* 18:   */   {
/* 19:21 */     String extensionList = platform.getInfoString(2308);
/* 20:22 */     String version = platform.getInfoString(2305);
/* 21:23 */     if (!version.startsWith("OpenCL ")) {
/* 22:24 */       throw new RuntimeException("Invalid OpenCL version string: " + version);
/* 23:   */     }
/* 24:   */     try
/* 25:   */     {
/* 26:27 */       StringTokenizer tokenizer = new StringTokenizer(version.substring(7), ". ");
/* 27:   */       
/* 28:29 */       this.majorVersion = Integer.parseInt(tokenizer.nextToken());
/* 29:30 */       this.minorVersion = Integer.parseInt(tokenizer.nextToken());
/* 30:   */       
/* 31:32 */       this.OpenCL11 = ((1 < this.majorVersion) || ((1 == this.majorVersion) && (1 <= this.minorVersion)));
/* 32:33 */       this.OpenCL12 = ((1 < this.majorVersion) || ((1 == this.majorVersion) && (2 <= this.minorVersion)));
/* 33:   */     }
/* 34:   */     catch (RuntimeException e)
/* 35:   */     {
/* 36:35 */       throw new RuntimeException("The major and/or minor OpenCL version \"" + version + "\" is malformed: " + e.getMessage());
/* 37:   */     }
/* 38:38 */     Set<String> extensions = APIUtil.getExtensions(extensionList);
/* 39:39 */     this.CL_KHR_d3d10_sharing = extensions.contains("cl_khr_d3d10_sharing");
/* 40:40 */     this.CL_KHR_gl_event = ((extensions.contains("cl_khr_gl_event")) && (CLCapabilities.CL_KHR_gl_event));
/* 41:41 */     this.CL_KHR_gl_sharing = ((extensions.contains("cl_khr_gl_sharing")) && (CLCapabilities.CL_KHR_gl_sharing));
/* 42:42 */     this.CL_KHR_icd = ((extensions.contains("cl_khr_icd")) && (CLCapabilities.CL_KHR_icd));
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int getMajorVersion()
/* 46:   */   {
/* 47:46 */     return this.majorVersion;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public int getMinorVersion()
/* 51:   */   {
/* 52:50 */     return this.minorVersion;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String toString()
/* 56:   */   {
/* 57:54 */     StringBuilder buf = new StringBuilder();
/* 58:   */     
/* 59:56 */     buf.append("OpenCL ").append(this.majorVersion).append('.').append(this.minorVersion);
/* 60:   */     
/* 61:58 */     buf.append(" - Extensions: ");
/* 62:59 */     if (this.CL_KHR_d3d10_sharing) {
/* 63:59 */       buf.append("cl_khr_d3d10_sharing ");
/* 64:   */     }
/* 65:60 */     if (this.CL_KHR_gl_event) {
/* 66:60 */       buf.append("cl_khr_gl_event ");
/* 67:   */     }
/* 68:61 */     if (this.CL_KHR_gl_sharing) {
/* 69:61 */       buf.append("cl_khr_gl_sharing ");
/* 70:   */     }
/* 71:62 */     if (this.CL_KHR_icd) {
/* 72:62 */       buf.append("cl_khr_icd ");
/* 73:   */     }
/* 74:64 */     return buf.toString();
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLPlatformCapabilities
 * JD-Core Version:    0.7.0.1
 */