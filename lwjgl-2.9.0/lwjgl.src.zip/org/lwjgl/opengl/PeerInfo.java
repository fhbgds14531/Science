/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ import org.lwjgl.LWJGLUtil;
/*  6:   */ 
/*  7:   */ abstract class PeerInfo
/*  8:   */ {
/*  9:   */   private final ByteBuffer handle;
/* 10:   */   private Thread locking_thread;
/* 11:   */   private int lock_count;
/* 12:   */   
/* 13:   */   protected PeerInfo(ByteBuffer handle)
/* 14:   */   {
/* 15:51 */     this.handle = handle;
/* 16:   */   }
/* 17:   */   
/* 18:   */   private void lockAndInitHandle()
/* 19:   */     throws LWJGLException
/* 20:   */   {
/* 21:55 */     doLockAndInitHandle();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public final synchronized void unlock()
/* 25:   */     throws LWJGLException
/* 26:   */   {
/* 27:59 */     if (this.lock_count <= 0) {
/* 28:60 */       throw new IllegalStateException("PeerInfo not locked!");
/* 29:   */     }
/* 30:61 */     if (Thread.currentThread() != this.locking_thread) {
/* 31:62 */       throw new IllegalStateException("PeerInfo already locked by " + this.locking_thread);
/* 32:   */     }
/* 33:63 */     this.lock_count -= 1;
/* 34:64 */     if (this.lock_count == 0)
/* 35:   */     {
/* 36:65 */       doUnlock();
/* 37:66 */       this.locking_thread = null;
/* 38:67 */       notify();
/* 39:   */     }
/* 40:   */   }
/* 41:   */   
/* 42:   */   protected abstract void doLockAndInitHandle()
/* 43:   */     throws LWJGLException;
/* 44:   */   
/* 45:   */   protected abstract void doUnlock()
/* 46:   */     throws LWJGLException;
/* 47:   */   
/* 48:   */   public final synchronized ByteBuffer lockAndGetHandle()
/* 49:   */     throws LWJGLException
/* 50:   */   {
/* 51:75 */     Thread this_thread = Thread.currentThread();
/* 52:76 */     while ((this.locking_thread != null) && (this.locking_thread != this_thread)) {
/* 53:   */       try
/* 54:   */       {
/* 55:78 */         wait();
/* 56:   */       }
/* 57:   */       catch (InterruptedException e)
/* 58:   */       {
/* 59:80 */         LWJGLUtil.log("Interrupted while waiting for PeerInfo lock: " + e);
/* 60:   */       }
/* 61:   */     }
/* 62:83 */     if (this.lock_count == 0)
/* 63:   */     {
/* 64:84 */       this.locking_thread = this_thread;
/* 65:85 */       doLockAndInitHandle();
/* 66:   */     }
/* 67:87 */     this.lock_count += 1;
/* 68:88 */     return getHandle();
/* 69:   */   }
/* 70:   */   
/* 71:   */   protected final ByteBuffer getHandle()
/* 72:   */   {
/* 73:92 */     return this.handle;
/* 74:   */   }
/* 75:   */   
/* 76:   */   public void destroy() {}
/* 77:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.PeerInfo
 * JD-Core Version:    0.7.0.1
 */