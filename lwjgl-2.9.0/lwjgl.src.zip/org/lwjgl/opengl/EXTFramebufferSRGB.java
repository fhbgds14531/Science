package org.lwjgl.opengl;

public final class EXTFramebufferSRGB
{
  public static final int GLX_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8370;
  public static final int WGL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 8361;
  public static final int GL_FRAMEBUFFER_SRGB_EXT = 36281;
  public static final int GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = 36282;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTFramebufferSRGB
 * JD-Core Version:    0.7.0.1
 */