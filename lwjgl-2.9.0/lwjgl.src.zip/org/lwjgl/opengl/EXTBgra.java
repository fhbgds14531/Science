package org.lwjgl.opengl;

public final class EXTBgra
{
  public static final int GL_BGR_EXT = 32992;
  public static final int GL_BGRA_EXT = 32993;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBgra
 * JD-Core Version:    0.7.0.1
 */