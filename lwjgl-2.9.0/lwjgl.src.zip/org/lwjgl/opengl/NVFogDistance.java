package org.lwjgl.opengl;

public final class NVFogDistance
{
  public static final int GL_FOG_DISTANCE_MODE_NV = 34138;
  public static final int GL_EYE_RADIAL_NV = 34139;
  public static final int GL_EYE_PLANE_ABSOLUTE_NV = 34140;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVFogDistance
 * JD-Core Version:    0.7.0.1
 */