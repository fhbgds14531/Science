/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBTransformFeedbackInstanced
/*  4:   */ {
/*  5:   */   public static void glDrawTransformFeedbackInstanced(int mode, int id, int primcount)
/*  6:   */   {
/*  7:13 */     GL42.glDrawTransformFeedbackInstanced(mode, id, primcount);
/*  8:   */   }
/*  9:   */   
/* 10:   */   public static void glDrawTransformFeedbackStreamInstanced(int mode, int id, int stream, int primcount)
/* 11:   */   {
/* 12:17 */     GL42.glDrawTransformFeedbackStreamInstanced(mode, id, stream, primcount);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTransformFeedbackInstanced
 * JD-Core Version:    0.7.0.1
 */