/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.LongBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVVertexAttribInteger64bit
/*   8:    */ {
/*   9:    */   public static final int GL_INT64_NV = 5134;
/*  10:    */   public static final int GL_UNSIGNED_INT64_NV = 5135;
/*  11:    */   
/*  12:    */   public static void glVertexAttribL1i64NV(int index, long x)
/*  13:    */   {
/*  14: 20 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  15: 21 */     long function_pointer = caps.glVertexAttribL1i64NV;
/*  16: 22 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  17: 23 */     nglVertexAttribL1i64NV(index, x, function_pointer);
/*  18:    */   }
/*  19:    */   
/*  20:    */   static native void nglVertexAttribL1i64NV(int paramInt, long paramLong1, long paramLong2);
/*  21:    */   
/*  22:    */   public static void glVertexAttribL2i64NV(int index, long x, long y)
/*  23:    */   {
/*  24: 28 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  25: 29 */     long function_pointer = caps.glVertexAttribL2i64NV;
/*  26: 30 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  27: 31 */     nglVertexAttribL2i64NV(index, x, y, function_pointer);
/*  28:    */   }
/*  29:    */   
/*  30:    */   static native void nglVertexAttribL2i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  31:    */   
/*  32:    */   public static void glVertexAttribL3i64NV(int index, long x, long y, long z)
/*  33:    */   {
/*  34: 36 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  35: 37 */     long function_pointer = caps.glVertexAttribL3i64NV;
/*  36: 38 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  37: 39 */     nglVertexAttribL3i64NV(index, x, y, z, function_pointer);
/*  38:    */   }
/*  39:    */   
/*  40:    */   static native void nglVertexAttribL3i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*  41:    */   
/*  42:    */   public static void glVertexAttribL4i64NV(int index, long x, long y, long z, long w)
/*  43:    */   {
/*  44: 44 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  45: 45 */     long function_pointer = caps.glVertexAttribL4i64NV;
/*  46: 46 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  47: 47 */     nglVertexAttribL4i64NV(index, x, y, z, w, function_pointer);
/*  48:    */   }
/*  49:    */   
/*  50:    */   static native void nglVertexAttribL4i64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  51:    */   
/*  52:    */   public static void glVertexAttribL1NV(int index, LongBuffer v)
/*  53:    */   {
/*  54: 52 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  55: 53 */     long function_pointer = caps.glVertexAttribL1i64vNV;
/*  56: 54 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  57: 55 */     BufferChecks.checkBuffer(v, 1);
/*  58: 56 */     nglVertexAttribL1i64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/*  59:    */   }
/*  60:    */   
/*  61:    */   static native void nglVertexAttribL1i64vNV(int paramInt, long paramLong1, long paramLong2);
/*  62:    */   
/*  63:    */   public static void glVertexAttribL2NV(int index, LongBuffer v)
/*  64:    */   {
/*  65: 61 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  66: 62 */     long function_pointer = caps.glVertexAttribL2i64vNV;
/*  67: 63 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  68: 64 */     BufferChecks.checkBuffer(v, 2);
/*  69: 65 */     nglVertexAttribL2i64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/*  70:    */   }
/*  71:    */   
/*  72:    */   static native void nglVertexAttribL2i64vNV(int paramInt, long paramLong1, long paramLong2);
/*  73:    */   
/*  74:    */   public static void glVertexAttribL3NV(int index, LongBuffer v)
/*  75:    */   {
/*  76: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  77: 71 */     long function_pointer = caps.glVertexAttribL3i64vNV;
/*  78: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  79: 73 */     BufferChecks.checkBuffer(v, 3);
/*  80: 74 */     nglVertexAttribL3i64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/*  81:    */   }
/*  82:    */   
/*  83:    */   static native void nglVertexAttribL3i64vNV(int paramInt, long paramLong1, long paramLong2);
/*  84:    */   
/*  85:    */   public static void glVertexAttribL4NV(int index, LongBuffer v)
/*  86:    */   {
/*  87: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  88: 80 */     long function_pointer = caps.glVertexAttribL4i64vNV;
/*  89: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  90: 82 */     BufferChecks.checkBuffer(v, 4);
/*  91: 83 */     nglVertexAttribL4i64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/*  92:    */   }
/*  93:    */   
/*  94:    */   static native void nglVertexAttribL4i64vNV(int paramInt, long paramLong1, long paramLong2);
/*  95:    */   
/*  96:    */   public static void glVertexAttribL1ui64NV(int index, long x)
/*  97:    */   {
/*  98: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  99: 89 */     long function_pointer = caps.glVertexAttribL1ui64NV;
/* 100: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101: 91 */     nglVertexAttribL1ui64NV(index, x, function_pointer);
/* 102:    */   }
/* 103:    */   
/* 104:    */   static native void nglVertexAttribL1ui64NV(int paramInt, long paramLong1, long paramLong2);
/* 105:    */   
/* 106:    */   public static void glVertexAttribL2ui64NV(int index, long x, long y)
/* 107:    */   {
/* 108: 96 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 109: 97 */     long function_pointer = caps.glVertexAttribL2ui64NV;
/* 110: 98 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 111: 99 */     nglVertexAttribL2ui64NV(index, x, y, function_pointer);
/* 112:    */   }
/* 113:    */   
/* 114:    */   static native void nglVertexAttribL2ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 115:    */   
/* 116:    */   public static void glVertexAttribL3ui64NV(int index, long x, long y, long z)
/* 117:    */   {
/* 118:104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 119:105 */     long function_pointer = caps.glVertexAttribL3ui64NV;
/* 120:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 121:107 */     nglVertexAttribL3ui64NV(index, x, y, z, function_pointer);
/* 122:    */   }
/* 123:    */   
/* 124:    */   static native void nglVertexAttribL3ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 125:    */   
/* 126:    */   public static void glVertexAttribL4ui64NV(int index, long x, long y, long z, long w)
/* 127:    */   {
/* 128:112 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 129:113 */     long function_pointer = caps.glVertexAttribL4ui64NV;
/* 130:114 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 131:115 */     nglVertexAttribL4ui64NV(index, x, y, z, w, function_pointer);
/* 132:    */   }
/* 133:    */   
/* 134:    */   static native void nglVertexAttribL4ui64NV(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 135:    */   
/* 136:    */   public static void glVertexAttribL1uNV(int index, LongBuffer v)
/* 137:    */   {
/* 138:120 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:121 */     long function_pointer = caps.glVertexAttribL1ui64vNV;
/* 140:122 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:123 */     BufferChecks.checkBuffer(v, 1);
/* 142:124 */     nglVertexAttribL1ui64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/* 143:    */   }
/* 144:    */   
/* 145:    */   static native void nglVertexAttribL1ui64vNV(int paramInt, long paramLong1, long paramLong2);
/* 146:    */   
/* 147:    */   public static void glVertexAttribL2uNV(int index, LongBuffer v)
/* 148:    */   {
/* 149:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:130 */     long function_pointer = caps.glVertexAttribL2ui64vNV;
/* 151:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:132 */     BufferChecks.checkBuffer(v, 2);
/* 153:133 */     nglVertexAttribL2ui64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/* 154:    */   }
/* 155:    */   
/* 156:    */   static native void nglVertexAttribL2ui64vNV(int paramInt, long paramLong1, long paramLong2);
/* 157:    */   
/* 158:    */   public static void glVertexAttribL3uNV(int index, LongBuffer v)
/* 159:    */   {
/* 160:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:139 */     long function_pointer = caps.glVertexAttribL3ui64vNV;
/* 162:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:141 */     BufferChecks.checkBuffer(v, 3);
/* 164:142 */     nglVertexAttribL3ui64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/* 165:    */   }
/* 166:    */   
/* 167:    */   static native void nglVertexAttribL3ui64vNV(int paramInt, long paramLong1, long paramLong2);
/* 168:    */   
/* 169:    */   public static void glVertexAttribL4uNV(int index, LongBuffer v)
/* 170:    */   {
/* 171:147 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 172:148 */     long function_pointer = caps.glVertexAttribL4ui64vNV;
/* 173:149 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 174:150 */     BufferChecks.checkBuffer(v, 4);
/* 175:151 */     nglVertexAttribL4ui64vNV(index, MemoryUtil.getAddress(v), function_pointer);
/* 176:    */   }
/* 177:    */   
/* 178:    */   static native void nglVertexAttribL4ui64vNV(int paramInt, long paramLong1, long paramLong2);
/* 179:    */   
/* 180:    */   public static void glGetVertexAttribLNV(int index, int pname, LongBuffer params)
/* 181:    */   {
/* 182:156 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 183:157 */     long function_pointer = caps.glGetVertexAttribLi64vNV;
/* 184:158 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 185:159 */     BufferChecks.checkBuffer(params, 4);
/* 186:160 */     nglGetVertexAttribLi64vNV(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 187:    */   }
/* 188:    */   
/* 189:    */   static native void nglGetVertexAttribLi64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 190:    */   
/* 191:    */   public static void glGetVertexAttribLuNV(int index, int pname, LongBuffer params)
/* 192:    */   {
/* 193:165 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 194:166 */     long function_pointer = caps.glGetVertexAttribLui64vNV;
/* 195:167 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 196:168 */     BufferChecks.checkBuffer(params, 4);
/* 197:169 */     nglGetVertexAttribLui64vNV(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 198:    */   }
/* 199:    */   
/* 200:    */   static native void nglGetVertexAttribLui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 201:    */   
/* 202:    */   public static void glVertexAttribLFormatNV(int index, int size, int type, int stride)
/* 203:    */   {
/* 204:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 205:175 */     long function_pointer = caps.glVertexAttribLFormatNV;
/* 206:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 207:177 */     nglVertexAttribLFormatNV(index, size, type, stride, function_pointer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   static native void nglVertexAttribLFormatNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 211:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexAttribInteger64bit
 * JD-Core Version:    0.7.0.1
 */