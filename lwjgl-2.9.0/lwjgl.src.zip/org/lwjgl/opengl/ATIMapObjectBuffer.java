/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.ByteOrder;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.LWJGLUtil;
/*  7:   */ 
/*  8:   */ public final class ATIMapObjectBuffer
/*  9:   */ {
/* 10:   */   public static ByteBuffer glMapObjectBufferATI(int buffer, ByteBuffer old_buffer)
/* 11:   */   {
/* 12:36 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:37 */     long function_pointer = caps.glMapObjectBufferATI;
/* 14:38 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:39 */     if (old_buffer != null) {
/* 16:40 */       BufferChecks.checkDirect(old_buffer);
/* 17:   */     }
/* 18:41 */     ByteBuffer __result = nglMapObjectBufferATI(buffer, GLChecks.getBufferObjectSizeATI(caps, buffer), old_buffer, function_pointer);
/* 19:42 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static ByteBuffer glMapObjectBufferATI(int buffer, long length, ByteBuffer old_buffer)
/* 23:   */   {
/* 24:68 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:69 */     long function_pointer = caps.glMapObjectBufferATI;
/* 26:70 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:71 */     if (old_buffer != null) {
/* 28:72 */       BufferChecks.checkDirect(old_buffer);
/* 29:   */     }
/* 30:73 */     ByteBuffer __result = nglMapObjectBufferATI(buffer, length, old_buffer, function_pointer);
/* 31:74 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 32:   */   }
/* 33:   */   
/* 34:   */   static native ByteBuffer nglMapObjectBufferATI(int paramInt, long paramLong1, ByteBuffer paramByteBuffer, long paramLong2);
/* 35:   */   
/* 36:   */   public static void glUnmapObjectBufferATI(int buffer)
/* 37:   */   {
/* 38:79 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 39:80 */     long function_pointer = caps.glUnmapObjectBufferATI;
/* 40:81 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 41:82 */     nglUnmapObjectBufferATI(buffer, function_pointer);
/* 42:   */   }
/* 43:   */   
/* 44:   */   static native void nglUnmapObjectBufferATI(int paramInt, long paramLong);
/* 45:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIMapObjectBuffer
 * JD-Core Version:    0.7.0.1
 */