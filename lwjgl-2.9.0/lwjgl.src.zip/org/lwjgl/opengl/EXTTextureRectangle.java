package org.lwjgl.opengl;

public final class EXTTextureRectangle
{
  public static final int GL_TEXTURE_RECTANGLE_EXT = 34037;
  public static final int GL_TEXTURE_BINDING_RECTANGLE_EXT = 34038;
  public static final int GL_PROXY_TEXTURE_RECTANGLE_EXT = 34039;
  public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 34040;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureRectangle
 * JD-Core Version:    0.7.0.1
 */