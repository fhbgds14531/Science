/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.MemoryUtil;
/*   8:    */ 
/*   9:    */ public final class ARBShaderObjects
/*  10:    */ {
/*  11:    */   public static final int GL_PROGRAM_OBJECT_ARB = 35648;
/*  12:    */   public static final int GL_OBJECT_TYPE_ARB = 35662;
/*  13:    */   public static final int GL_OBJECT_SUBTYPE_ARB = 35663;
/*  14:    */   public static final int GL_OBJECT_DELETE_STATUS_ARB = 35712;
/*  15:    */   public static final int GL_OBJECT_COMPILE_STATUS_ARB = 35713;
/*  16:    */   public static final int GL_OBJECT_LINK_STATUS_ARB = 35714;
/*  17:    */   public static final int GL_OBJECT_VALIDATE_STATUS_ARB = 35715;
/*  18:    */   public static final int GL_OBJECT_INFO_LOG_LENGTH_ARB = 35716;
/*  19:    */   public static final int GL_OBJECT_ATTACHED_OBJECTS_ARB = 35717;
/*  20:    */   public static final int GL_OBJECT_ACTIVE_UNIFORMS_ARB = 35718;
/*  21:    */   public static final int GL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB = 35719;
/*  22:    */   public static final int GL_OBJECT_SHADER_SOURCE_LENGTH_ARB = 35720;
/*  23:    */   public static final int GL_SHADER_OBJECT_ARB = 35656;
/*  24:    */   public static final int GL_FLOAT_VEC2_ARB = 35664;
/*  25:    */   public static final int GL_FLOAT_VEC3_ARB = 35665;
/*  26:    */   public static final int GL_FLOAT_VEC4_ARB = 35666;
/*  27:    */   public static final int GL_INT_VEC2_ARB = 35667;
/*  28:    */   public static final int GL_INT_VEC3_ARB = 35668;
/*  29:    */   public static final int GL_INT_VEC4_ARB = 35669;
/*  30:    */   public static final int GL_BOOL_ARB = 35670;
/*  31:    */   public static final int GL_BOOL_VEC2_ARB = 35671;
/*  32:    */   public static final int GL_BOOL_VEC3_ARB = 35672;
/*  33:    */   public static final int GL_BOOL_VEC4_ARB = 35673;
/*  34:    */   public static final int GL_FLOAT_MAT2_ARB = 35674;
/*  35:    */   public static final int GL_FLOAT_MAT3_ARB = 35675;
/*  36:    */   public static final int GL_FLOAT_MAT4_ARB = 35676;
/*  37:    */   public static final int GL_SAMPLER_1D_ARB = 35677;
/*  38:    */   public static final int GL_SAMPLER_2D_ARB = 35678;
/*  39:    */   public static final int GL_SAMPLER_3D_ARB = 35679;
/*  40:    */   public static final int GL_SAMPLER_CUBE_ARB = 35680;
/*  41:    */   public static final int GL_SAMPLER_1D_SHADOW_ARB = 35681;
/*  42:    */   public static final int GL_SAMPLER_2D_SHADOW_ARB = 35682;
/*  43:    */   public static final int GL_SAMPLER_2D_RECT_ARB = 35683;
/*  44:    */   public static final int GL_SAMPLER_2D_RECT_SHADOW_ARB = 35684;
/*  45:    */   
/*  46:    */   public static void glDeleteObjectARB(int obj)
/*  47:    */   {
/*  48: 63 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  49: 64 */     long function_pointer = caps.glDeleteObjectARB;
/*  50: 65 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  51: 66 */     nglDeleteObjectARB(obj, function_pointer);
/*  52:    */   }
/*  53:    */   
/*  54:    */   static native void nglDeleteObjectARB(int paramInt, long paramLong);
/*  55:    */   
/*  56:    */   public static int glGetHandleARB(int pname)
/*  57:    */   {
/*  58: 71 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  59: 72 */     long function_pointer = caps.glGetHandleARB;
/*  60: 73 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 74 */     int __result = nglGetHandleARB(pname, function_pointer);
/*  62: 75 */     return __result;
/*  63:    */   }
/*  64:    */   
/*  65:    */   static native int nglGetHandleARB(int paramInt, long paramLong);
/*  66:    */   
/*  67:    */   public static void glDetachObjectARB(int containerObj, int attachedObj)
/*  68:    */   {
/*  69: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  70: 81 */     long function_pointer = caps.glDetachObjectARB;
/*  71: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  72: 83 */     nglDetachObjectARB(containerObj, attachedObj, function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   static native void nglDetachObjectARB(int paramInt1, int paramInt2, long paramLong);
/*  76:    */   
/*  77:    */   public static int glCreateShaderObjectARB(int shaderType)
/*  78:    */   {
/*  79: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  80: 89 */     long function_pointer = caps.glCreateShaderObjectARB;
/*  81: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  82: 91 */     int __result = nglCreateShaderObjectARB(shaderType, function_pointer);
/*  83: 92 */     return __result;
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native int nglCreateShaderObjectARB(int paramInt, long paramLong);
/*  87:    */   
/*  88:    */   public static void glShaderSourceARB(int shader, ByteBuffer string)
/*  89:    */   {
/*  90:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91:103 */     long function_pointer = caps.glShaderSourceARB;
/*  92:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93:105 */     BufferChecks.checkDirect(string);
/*  94:106 */     nglShaderSourceARB(shader, 1, MemoryUtil.getAddress(string), string.remaining(), function_pointer);
/*  95:    */   }
/*  96:    */   
/*  97:    */   static native void nglShaderSourceARB(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  98:    */   
/*  99:    */   public static void glShaderSourceARB(int shader, CharSequence string)
/* 100:    */   {
/* 101:112 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 102:113 */     long function_pointer = caps.glShaderSourceARB;
/* 103:114 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 104:115 */     nglShaderSourceARB(shader, 1, APIUtil.getBuffer(caps, string), string.length(), function_pointer);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static void glShaderSourceARB(int shader, CharSequence[] strings)
/* 108:    */   {
/* 109:120 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110:121 */     long function_pointer = caps.glShaderSourceARB;
/* 111:122 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:123 */     BufferChecks.checkArray(strings);
/* 113:124 */     nglShaderSourceARB3(shader, strings.length, APIUtil.getBuffer(caps, strings), APIUtil.getLengths(caps, strings), function_pointer);
/* 114:    */   }
/* 115:    */   
/* 116:    */   static native void nglShaderSourceARB3(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 117:    */   
/* 118:    */   public static void glCompileShaderARB(int shaderObj)
/* 119:    */   {
/* 120:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 121:130 */     long function_pointer = caps.glCompileShaderARB;
/* 122:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 123:132 */     nglCompileShaderARB(shaderObj, function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglCompileShaderARB(int paramInt, long paramLong);
/* 127:    */   
/* 128:    */   public static int glCreateProgramObjectARB()
/* 129:    */   {
/* 130:137 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:138 */     long function_pointer = caps.glCreateProgramObjectARB;
/* 132:139 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:140 */     int __result = nglCreateProgramObjectARB(function_pointer);
/* 134:141 */     return __result;
/* 135:    */   }
/* 136:    */   
/* 137:    */   static native int nglCreateProgramObjectARB(long paramLong);
/* 138:    */   
/* 139:    */   public static void glAttachObjectARB(int containerObj, int obj)
/* 140:    */   {
/* 141:146 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 142:147 */     long function_pointer = caps.glAttachObjectARB;
/* 143:148 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 144:149 */     nglAttachObjectARB(containerObj, obj, function_pointer);
/* 145:    */   }
/* 146:    */   
/* 147:    */   static native void nglAttachObjectARB(int paramInt1, int paramInt2, long paramLong);
/* 148:    */   
/* 149:    */   public static void glLinkProgramARB(int programObj)
/* 150:    */   {
/* 151:154 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 152:155 */     long function_pointer = caps.glLinkProgramARB;
/* 153:156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 154:157 */     nglLinkProgramARB(programObj, function_pointer);
/* 155:    */   }
/* 156:    */   
/* 157:    */   static native void nglLinkProgramARB(int paramInt, long paramLong);
/* 158:    */   
/* 159:    */   public static void glUseProgramObjectARB(int programObj)
/* 160:    */   {
/* 161:162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 162:163 */     long function_pointer = caps.glUseProgramObjectARB;
/* 163:164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 164:165 */     nglUseProgramObjectARB(programObj, function_pointer);
/* 165:    */   }
/* 166:    */   
/* 167:    */   static native void nglUseProgramObjectARB(int paramInt, long paramLong);
/* 168:    */   
/* 169:    */   public static void glValidateProgramARB(int programObj)
/* 170:    */   {
/* 171:170 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 172:171 */     long function_pointer = caps.glValidateProgramARB;
/* 173:172 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 174:173 */     nglValidateProgramARB(programObj, function_pointer);
/* 175:    */   }
/* 176:    */   
/* 177:    */   static native void nglValidateProgramARB(int paramInt, long paramLong);
/* 178:    */   
/* 179:    */   public static void glUniform1fARB(int location, float v0)
/* 180:    */   {
/* 181:178 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 182:179 */     long function_pointer = caps.glUniform1fARB;
/* 183:180 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 184:181 */     nglUniform1fARB(location, v0, function_pointer);
/* 185:    */   }
/* 186:    */   
/* 187:    */   static native void nglUniform1fARB(int paramInt, float paramFloat, long paramLong);
/* 188:    */   
/* 189:    */   public static void glUniform2fARB(int location, float v0, float v1)
/* 190:    */   {
/* 191:186 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 192:187 */     long function_pointer = caps.glUniform2fARB;
/* 193:188 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 194:189 */     nglUniform2fARB(location, v0, v1, function_pointer);
/* 195:    */   }
/* 196:    */   
/* 197:    */   static native void nglUniform2fARB(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/* 198:    */   
/* 199:    */   public static void glUniform3fARB(int location, float v0, float v1, float v2)
/* 200:    */   {
/* 201:194 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 202:195 */     long function_pointer = caps.glUniform3fARB;
/* 203:196 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 204:197 */     nglUniform3fARB(location, v0, v1, v2, function_pointer);
/* 205:    */   }
/* 206:    */   
/* 207:    */   static native void nglUniform3fARB(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 208:    */   
/* 209:    */   public static void glUniform4fARB(int location, float v0, float v1, float v2, float v3)
/* 210:    */   {
/* 211:202 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 212:203 */     long function_pointer = caps.glUniform4fARB;
/* 213:204 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 214:205 */     nglUniform4fARB(location, v0, v1, v2, v3, function_pointer);
/* 215:    */   }
/* 216:    */   
/* 217:    */   static native void nglUniform4fARB(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 218:    */   
/* 219:    */   public static void glUniform1iARB(int location, int v0)
/* 220:    */   {
/* 221:210 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 222:211 */     long function_pointer = caps.glUniform1iARB;
/* 223:212 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 224:213 */     nglUniform1iARB(location, v0, function_pointer);
/* 225:    */   }
/* 226:    */   
/* 227:    */   static native void nglUniform1iARB(int paramInt1, int paramInt2, long paramLong);
/* 228:    */   
/* 229:    */   public static void glUniform2iARB(int location, int v0, int v1)
/* 230:    */   {
/* 231:218 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 232:219 */     long function_pointer = caps.glUniform2iARB;
/* 233:220 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 234:221 */     nglUniform2iARB(location, v0, v1, function_pointer);
/* 235:    */   }
/* 236:    */   
/* 237:    */   static native void nglUniform2iARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 238:    */   
/* 239:    */   public static void glUniform3iARB(int location, int v0, int v1, int v2)
/* 240:    */   {
/* 241:226 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 242:227 */     long function_pointer = caps.glUniform3iARB;
/* 243:228 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 244:229 */     nglUniform3iARB(location, v0, v1, v2, function_pointer);
/* 245:    */   }
/* 246:    */   
/* 247:    */   static native void nglUniform3iARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 248:    */   
/* 249:    */   public static void glUniform4iARB(int location, int v0, int v1, int v2, int v3)
/* 250:    */   {
/* 251:234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 252:235 */     long function_pointer = caps.glUniform4iARB;
/* 253:236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 254:237 */     nglUniform4iARB(location, v0, v1, v2, v3, function_pointer);
/* 255:    */   }
/* 256:    */   
/* 257:    */   static native void nglUniform4iARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 258:    */   
/* 259:    */   public static void glUniform1ARB(int location, FloatBuffer values)
/* 260:    */   {
/* 261:242 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 262:243 */     long function_pointer = caps.glUniform1fvARB;
/* 263:244 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 264:245 */     BufferChecks.checkDirect(values);
/* 265:246 */     nglUniform1fvARB(location, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 266:    */   }
/* 267:    */   
/* 268:    */   static native void nglUniform1fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 269:    */   
/* 270:    */   public static void glUniform2ARB(int location, FloatBuffer values)
/* 271:    */   {
/* 272:251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 273:252 */     long function_pointer = caps.glUniform2fvARB;
/* 274:253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 275:254 */     BufferChecks.checkDirect(values);
/* 276:255 */     nglUniform2fvARB(location, values.remaining() >> 1, MemoryUtil.getAddress(values), function_pointer);
/* 277:    */   }
/* 278:    */   
/* 279:    */   static native void nglUniform2fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 280:    */   
/* 281:    */   public static void glUniform3ARB(int location, FloatBuffer values)
/* 282:    */   {
/* 283:260 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 284:261 */     long function_pointer = caps.glUniform3fvARB;
/* 285:262 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 286:263 */     BufferChecks.checkDirect(values);
/* 287:264 */     nglUniform3fvARB(location, values.remaining() / 3, MemoryUtil.getAddress(values), function_pointer);
/* 288:    */   }
/* 289:    */   
/* 290:    */   static native void nglUniform3fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 291:    */   
/* 292:    */   public static void glUniform4ARB(int location, FloatBuffer values)
/* 293:    */   {
/* 294:269 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 295:270 */     long function_pointer = caps.glUniform4fvARB;
/* 296:271 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 297:272 */     BufferChecks.checkDirect(values);
/* 298:273 */     nglUniform4fvARB(location, values.remaining() >> 2, MemoryUtil.getAddress(values), function_pointer);
/* 299:    */   }
/* 300:    */   
/* 301:    */   static native void nglUniform4fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 302:    */   
/* 303:    */   public static void glUniform1ARB(int location, IntBuffer values)
/* 304:    */   {
/* 305:278 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 306:279 */     long function_pointer = caps.glUniform1ivARB;
/* 307:280 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 308:281 */     BufferChecks.checkDirect(values);
/* 309:282 */     nglUniform1ivARB(location, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 310:    */   }
/* 311:    */   
/* 312:    */   static native void nglUniform1ivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 313:    */   
/* 314:    */   public static void glUniform2ARB(int location, IntBuffer values)
/* 315:    */   {
/* 316:287 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 317:288 */     long function_pointer = caps.glUniform2ivARB;
/* 318:289 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 319:290 */     BufferChecks.checkDirect(values);
/* 320:291 */     nglUniform2ivARB(location, values.remaining() >> 1, MemoryUtil.getAddress(values), function_pointer);
/* 321:    */   }
/* 322:    */   
/* 323:    */   static native void nglUniform2ivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 324:    */   
/* 325:    */   public static void glUniform3ARB(int location, IntBuffer values)
/* 326:    */   {
/* 327:296 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 328:297 */     long function_pointer = caps.glUniform3ivARB;
/* 329:298 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 330:299 */     BufferChecks.checkDirect(values);
/* 331:300 */     nglUniform3ivARB(location, values.remaining() / 3, MemoryUtil.getAddress(values), function_pointer);
/* 332:    */   }
/* 333:    */   
/* 334:    */   static native void nglUniform3ivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 335:    */   
/* 336:    */   public static void glUniform4ARB(int location, IntBuffer values)
/* 337:    */   {
/* 338:305 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 339:306 */     long function_pointer = caps.glUniform4ivARB;
/* 340:307 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 341:308 */     BufferChecks.checkDirect(values);
/* 342:309 */     nglUniform4ivARB(location, values.remaining() >> 2, MemoryUtil.getAddress(values), function_pointer);
/* 343:    */   }
/* 344:    */   
/* 345:    */   static native void nglUniform4ivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 346:    */   
/* 347:    */   public static void glUniformMatrix2ARB(int location, boolean transpose, FloatBuffer matrices)
/* 348:    */   {
/* 349:314 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 350:315 */     long function_pointer = caps.glUniformMatrix2fvARB;
/* 351:316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 352:317 */     BufferChecks.checkDirect(matrices);
/* 353:318 */     nglUniformMatrix2fvARB(location, matrices.remaining() >> 2, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/* 354:    */   }
/* 355:    */   
/* 356:    */   static native void nglUniformMatrix2fvARB(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 357:    */   
/* 358:    */   public static void glUniformMatrix3ARB(int location, boolean transpose, FloatBuffer matrices)
/* 359:    */   {
/* 360:323 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 361:324 */     long function_pointer = caps.glUniformMatrix3fvARB;
/* 362:325 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 363:326 */     BufferChecks.checkDirect(matrices);
/* 364:327 */     nglUniformMatrix3fvARB(location, matrices.remaining() / 9, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/* 365:    */   }
/* 366:    */   
/* 367:    */   static native void nglUniformMatrix3fvARB(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 368:    */   
/* 369:    */   public static void glUniformMatrix4ARB(int location, boolean transpose, FloatBuffer matrices)
/* 370:    */   {
/* 371:332 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 372:333 */     long function_pointer = caps.glUniformMatrix4fvARB;
/* 373:334 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 374:335 */     BufferChecks.checkDirect(matrices);
/* 375:336 */     nglUniformMatrix4fvARB(location, matrices.remaining() >> 4, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/* 376:    */   }
/* 377:    */   
/* 378:    */   static native void nglUniformMatrix4fvARB(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 379:    */   
/* 380:    */   public static void glGetObjectParameterARB(int obj, int pname, FloatBuffer params)
/* 381:    */   {
/* 382:341 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 383:342 */     long function_pointer = caps.glGetObjectParameterfvARB;
/* 384:343 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 385:344 */     BufferChecks.checkDirect(params);
/* 386:345 */     nglGetObjectParameterfvARB(obj, pname, MemoryUtil.getAddress(params), function_pointer);
/* 387:    */   }
/* 388:    */   
/* 389:    */   static native void nglGetObjectParameterfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 390:    */   
/* 391:    */   public static float glGetObjectParameterfARB(int obj, int pname)
/* 392:    */   {
/* 393:351 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 394:352 */     long function_pointer = caps.glGetObjectParameterfvARB;
/* 395:353 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 396:354 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 397:355 */     nglGetObjectParameterfvARB(obj, pname, MemoryUtil.getAddress(params), function_pointer);
/* 398:356 */     return params.get(0);
/* 399:    */   }
/* 400:    */   
/* 401:    */   public static void glGetObjectParameterARB(int obj, int pname, IntBuffer params)
/* 402:    */   {
/* 403:360 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 404:361 */     long function_pointer = caps.glGetObjectParameterivARB;
/* 405:362 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 406:363 */     BufferChecks.checkDirect(params);
/* 407:364 */     nglGetObjectParameterivARB(obj, pname, MemoryUtil.getAddress(params), function_pointer);
/* 408:    */   }
/* 409:    */   
/* 410:    */   static native void nglGetObjectParameterivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 411:    */   
/* 412:    */   public static int glGetObjectParameteriARB(int obj, int pname)
/* 413:    */   {
/* 414:370 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 415:371 */     long function_pointer = caps.glGetObjectParameterivARB;
/* 416:372 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 417:373 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 418:374 */     nglGetObjectParameterivARB(obj, pname, MemoryUtil.getAddress(params), function_pointer);
/* 419:375 */     return params.get(0);
/* 420:    */   }
/* 421:    */   
/* 422:    */   public static void glGetInfoLogARB(int obj, IntBuffer length, ByteBuffer infoLog)
/* 423:    */   {
/* 424:379 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 425:380 */     long function_pointer = caps.glGetInfoLogARB;
/* 426:381 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 427:382 */     if (length != null) {
/* 428:383 */       BufferChecks.checkBuffer(length, 1);
/* 429:    */     }
/* 430:384 */     BufferChecks.checkDirect(infoLog);
/* 431:385 */     nglGetInfoLogARB(obj, infoLog.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(infoLog), function_pointer);
/* 432:    */   }
/* 433:    */   
/* 434:    */   static native void nglGetInfoLogARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 435:    */   
/* 436:    */   public static String glGetInfoLogARB(int obj, int maxLength)
/* 437:    */   {
/* 438:391 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 439:392 */     long function_pointer = caps.glGetInfoLogARB;
/* 440:393 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 441:394 */     IntBuffer infoLog_length = APIUtil.getLengths(caps);
/* 442:395 */     ByteBuffer infoLog = APIUtil.getBufferByte(caps, maxLength);
/* 443:396 */     nglGetInfoLogARB(obj, maxLength, MemoryUtil.getAddress0(infoLog_length), MemoryUtil.getAddress(infoLog), function_pointer);
/* 444:397 */     infoLog.limit(infoLog_length.get(0));
/* 445:398 */     return APIUtil.getString(caps, infoLog);
/* 446:    */   }
/* 447:    */   
/* 448:    */   public static void glGetAttachedObjectsARB(int containerObj, IntBuffer count, IntBuffer obj)
/* 449:    */   {
/* 450:402 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 451:403 */     long function_pointer = caps.glGetAttachedObjectsARB;
/* 452:404 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 453:405 */     if (count != null) {
/* 454:406 */       BufferChecks.checkBuffer(count, 1);
/* 455:    */     }
/* 456:407 */     BufferChecks.checkDirect(obj);
/* 457:408 */     nglGetAttachedObjectsARB(containerObj, obj.remaining(), MemoryUtil.getAddressSafe(count), MemoryUtil.getAddress(obj), function_pointer);
/* 458:    */   }
/* 459:    */   
/* 460:    */   static native void nglGetAttachedObjectsARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 461:    */   
/* 462:    */   public static int glGetUniformLocationARB(int programObj, ByteBuffer name)
/* 463:    */   {
/* 464:419 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 465:420 */     long function_pointer = caps.glGetUniformLocationARB;
/* 466:421 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 467:422 */     BufferChecks.checkDirect(name);
/* 468:423 */     BufferChecks.checkNullTerminated(name);
/* 469:424 */     int __result = nglGetUniformLocationARB(programObj, MemoryUtil.getAddress(name), function_pointer);
/* 470:425 */     return __result;
/* 471:    */   }
/* 472:    */   
/* 473:    */   static native int nglGetUniformLocationARB(int paramInt, long paramLong1, long paramLong2);
/* 474:    */   
/* 475:    */   public static int glGetUniformLocationARB(int programObj, CharSequence name)
/* 476:    */   {
/* 477:431 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 478:432 */     long function_pointer = caps.glGetUniformLocationARB;
/* 479:433 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 480:434 */     int __result = nglGetUniformLocationARB(programObj, APIUtil.getBufferNT(caps, name), function_pointer);
/* 481:435 */     return __result;
/* 482:    */   }
/* 483:    */   
/* 484:    */   public static void glGetActiveUniformARB(int programObj, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/* 485:    */   {
/* 486:439 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 487:440 */     long function_pointer = caps.glGetActiveUniformARB;
/* 488:441 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 489:442 */     if (length != null) {
/* 490:443 */       BufferChecks.checkBuffer(length, 1);
/* 491:    */     }
/* 492:444 */     BufferChecks.checkBuffer(size, 1);
/* 493:445 */     BufferChecks.checkBuffer(type, 1);
/* 494:446 */     BufferChecks.checkDirect(name);
/* 495:447 */     nglGetActiveUniformARB(programObj, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 496:    */   }
/* 497:    */   
/* 498:    */   static native void nglGetActiveUniformARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 499:    */   
/* 500:    */   public static String glGetActiveUniformARB(int programObj, int index, int maxLength, IntBuffer sizeType)
/* 501:    */   {
/* 502:457 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 503:458 */     long function_pointer = caps.glGetActiveUniformARB;
/* 504:459 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 505:460 */     BufferChecks.checkBuffer(sizeType, 2);
/* 506:461 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 507:462 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 508:463 */     nglGetActiveUniformARB(programObj, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(sizeType), MemoryUtil.getAddress(sizeType, sizeType.position() + 1), MemoryUtil.getAddress(name), function_pointer);
/* 509:464 */     name.limit(name_length.get(0));
/* 510:465 */     return APIUtil.getString(caps, name);
/* 511:    */   }
/* 512:    */   
/* 513:    */   public static String glGetActiveUniformARB(int programObj, int index, int maxLength)
/* 514:    */   {
/* 515:474 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 516:475 */     long function_pointer = caps.glGetActiveUniformARB;
/* 517:476 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 518:477 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 519:478 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 520:479 */     nglGetActiveUniformARB(programObj, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress0(APIUtil.getBufferInt(caps)), MemoryUtil.getAddress(APIUtil.getBufferInt(caps), 1), MemoryUtil.getAddress(name), function_pointer);
/* 521:480 */     name.limit(name_length.get(0));
/* 522:481 */     return APIUtil.getString(caps, name);
/* 523:    */   }
/* 524:    */   
/* 525:    */   public static int glGetActiveUniformSizeARB(int programObj, int index)
/* 526:    */   {
/* 527:490 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 528:491 */     long function_pointer = caps.glGetActiveUniformARB;
/* 529:492 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 530:493 */     IntBuffer size = APIUtil.getBufferInt(caps);
/* 531:494 */     nglGetActiveUniformARB(programObj, index, 0, 0L, MemoryUtil.getAddress(size), MemoryUtil.getAddress(size, 1), APIUtil.getBufferByte0(caps), function_pointer);
/* 532:495 */     return size.get(0);
/* 533:    */   }
/* 534:    */   
/* 535:    */   public static int glGetActiveUniformTypeARB(int programObj, int index)
/* 536:    */   {
/* 537:504 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 538:505 */     long function_pointer = caps.glGetActiveUniformARB;
/* 539:506 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 540:507 */     IntBuffer type = APIUtil.getBufferInt(caps);
/* 541:508 */     nglGetActiveUniformARB(programObj, index, 0, 0L, MemoryUtil.getAddress(type, 1), MemoryUtil.getAddress(type), APIUtil.getBufferByte0(caps), function_pointer);
/* 542:509 */     return type.get(0);
/* 543:    */   }
/* 544:    */   
/* 545:    */   public static void glGetUniformARB(int programObj, int location, FloatBuffer params)
/* 546:    */   {
/* 547:513 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 548:514 */     long function_pointer = caps.glGetUniformfvARB;
/* 549:515 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 550:516 */     BufferChecks.checkDirect(params);
/* 551:517 */     nglGetUniformfvARB(programObj, location, MemoryUtil.getAddress(params), function_pointer);
/* 552:    */   }
/* 553:    */   
/* 554:    */   static native void nglGetUniformfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 555:    */   
/* 556:    */   public static void glGetUniformARB(int programObj, int location, IntBuffer params)
/* 557:    */   {
/* 558:522 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 559:523 */     long function_pointer = caps.glGetUniformivARB;
/* 560:524 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 561:525 */     BufferChecks.checkDirect(params);
/* 562:526 */     nglGetUniformivARB(programObj, location, MemoryUtil.getAddress(params), function_pointer);
/* 563:    */   }
/* 564:    */   
/* 565:    */   static native void nglGetUniformivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 566:    */   
/* 567:    */   public static void glGetShaderSourceARB(int obj, IntBuffer length, ByteBuffer source)
/* 568:    */   {
/* 569:531 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 570:532 */     long function_pointer = caps.glGetShaderSourceARB;
/* 571:533 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 572:534 */     if (length != null) {
/* 573:535 */       BufferChecks.checkBuffer(length, 1);
/* 574:    */     }
/* 575:536 */     BufferChecks.checkDirect(source);
/* 576:537 */     nglGetShaderSourceARB(obj, source.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(source), function_pointer);
/* 577:    */   }
/* 578:    */   
/* 579:    */   static native void nglGetShaderSourceARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 580:    */   
/* 581:    */   public static String glGetShaderSourceARB(int obj, int maxLength)
/* 582:    */   {
/* 583:543 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 584:544 */     long function_pointer = caps.glGetShaderSourceARB;
/* 585:545 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 586:546 */     IntBuffer source_length = APIUtil.getLengths(caps);
/* 587:547 */     ByteBuffer source = APIUtil.getBufferByte(caps, maxLength);
/* 588:548 */     nglGetShaderSourceARB(obj, maxLength, MemoryUtil.getAddress0(source_length), MemoryUtil.getAddress(source), function_pointer);
/* 589:549 */     source.limit(source_length.get(0));
/* 590:550 */     return APIUtil.getString(caps, source);
/* 591:    */   }
/* 592:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShaderObjects
 * JD-Core Version:    0.7.0.1
 */