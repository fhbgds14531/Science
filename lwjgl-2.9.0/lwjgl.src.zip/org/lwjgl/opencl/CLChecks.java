/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import org.lwjgl.LWJGLUtil;
/*   5:    */ import org.lwjgl.PointerBuffer;
/*   6:    */ 
/*   7:    */ final class CLChecks
/*   8:    */ {
/*   9:    */   static int calculateBufferRectSize(PointerBuffer offset, PointerBuffer region, long row_pitch, long slice_pitch)
/*  10:    */   {
/*  11: 64 */     if (!LWJGLUtil.CHECKS) {
/*  12: 65 */       return 0;
/*  13:    */     }
/*  14: 67 */     long x = offset.get(0);
/*  15: 68 */     long y = offset.get(1);
/*  16: 69 */     long z = offset.get(2);
/*  17: 71 */     if ((LWJGLUtil.DEBUG) && ((x < 0L) || (y < 0L) || (z < 0L))) {
/*  18: 72 */       throw new IllegalArgumentException("Invalid cl_mem host offset: " + x + ", " + y + ", " + z);
/*  19:    */     }
/*  20: 74 */     long w = region.get(0);
/*  21: 75 */     long h = region.get(1);
/*  22: 76 */     long d = region.get(2);
/*  23: 78 */     if ((LWJGLUtil.DEBUG) && ((w < 1L) || (h < 1L) || (d < 1L))) {
/*  24: 79 */       throw new IllegalArgumentException("Invalid cl_mem rectangle region dimensions: " + w + " x " + h + " x " + d);
/*  25:    */     }
/*  26: 81 */     if (row_pitch == 0L) {
/*  27: 82 */       row_pitch = w;
/*  28: 83 */     } else if ((LWJGLUtil.DEBUG) && (row_pitch < w)) {
/*  29: 84 */       throw new IllegalArgumentException("Invalid host row pitch specified: " + row_pitch);
/*  30:    */     }
/*  31: 86 */     if (slice_pitch == 0L) {
/*  32: 87 */       slice_pitch = row_pitch * h;
/*  33: 88 */     } else if ((LWJGLUtil.DEBUG) && (slice_pitch < row_pitch * h)) {
/*  34: 89 */       throw new IllegalArgumentException("Invalid host slice pitch specified: " + slice_pitch);
/*  35:    */     }
/*  36: 91 */     return (int)(z * slice_pitch + y * row_pitch + x + w * h * d);
/*  37:    */   }
/*  38:    */   
/*  39:    */   static int calculateImageSize(PointerBuffer region, long row_pitch, long slice_pitch)
/*  40:    */   {
/*  41:106 */     if (!LWJGLUtil.CHECKS) {
/*  42:107 */       return 0;
/*  43:    */     }
/*  44:109 */     long w = region.get(0);
/*  45:110 */     long h = region.get(1);
/*  46:111 */     long d = region.get(2);
/*  47:113 */     if ((LWJGLUtil.DEBUG) && ((w < 1L) || (h < 1L) || (d < 1L))) {
/*  48:114 */       throw new IllegalArgumentException("Invalid cl_mem image region dimensions: " + w + " x " + h + " x " + d);
/*  49:    */     }
/*  50:116 */     if (row_pitch == 0L) {
/*  51:117 */       row_pitch = w;
/*  52:118 */     } else if ((LWJGLUtil.DEBUG) && (row_pitch < w)) {
/*  53:119 */       throw new IllegalArgumentException("Invalid row pitch specified: " + row_pitch);
/*  54:    */     }
/*  55:121 */     if (slice_pitch == 0L) {
/*  56:122 */       slice_pitch = row_pitch * h;
/*  57:123 */     } else if ((LWJGLUtil.DEBUG) && (slice_pitch < row_pitch * h)) {
/*  58:124 */       throw new IllegalArgumentException("Invalid slice pitch specified: " + slice_pitch);
/*  59:    */     }
/*  60:126 */     return (int)(slice_pitch * d);
/*  61:    */   }
/*  62:    */   
/*  63:    */   static int calculateImage2DSize(ByteBuffer format, long w, long h, long row_pitch)
/*  64:    */   {
/*  65:141 */     if (!LWJGLUtil.CHECKS) {
/*  66:142 */       return 0;
/*  67:    */     }
/*  68:144 */     if ((LWJGLUtil.DEBUG) && ((w < 1L) || (h < 1L))) {
/*  69:145 */       throw new IllegalArgumentException("Invalid 2D image dimensions: " + w + " x " + h);
/*  70:    */     }
/*  71:147 */     int elementSize = getElementSize(format);
/*  72:149 */     if (row_pitch == 0L) {
/*  73:150 */       row_pitch = w * elementSize;
/*  74:151 */     } else if ((LWJGLUtil.DEBUG) && ((row_pitch < w * elementSize) || (row_pitch % elementSize != 0L))) {
/*  75:152 */       throw new IllegalArgumentException("Invalid image_row_pitch specified: " + row_pitch);
/*  76:    */     }
/*  77:154 */     return (int)(row_pitch * h);
/*  78:    */   }
/*  79:    */   
/*  80:    */   static int calculateImage3DSize(ByteBuffer format, long w, long h, long d, long row_pitch, long slice_pitch)
/*  81:    */   {
/*  82:170 */     if (!LWJGLUtil.CHECKS) {
/*  83:171 */       return 0;
/*  84:    */     }
/*  85:173 */     if ((LWJGLUtil.DEBUG) && ((w < 1L) || (h < 1L) || (d < 2L))) {
/*  86:174 */       throw new IllegalArgumentException("Invalid 3D image dimensions: " + w + " x " + h + " x " + d);
/*  87:    */     }
/*  88:176 */     int elementSize = getElementSize(format);
/*  89:178 */     if (row_pitch == 0L) {
/*  90:179 */       row_pitch = w * elementSize;
/*  91:180 */     } else if ((LWJGLUtil.DEBUG) && ((row_pitch < w * elementSize) || (row_pitch % elementSize != 0L))) {
/*  92:181 */       throw new IllegalArgumentException("Invalid image_row_pitch specified: " + row_pitch);
/*  93:    */     }
/*  94:183 */     if (slice_pitch == 0L) {
/*  95:184 */       slice_pitch = row_pitch * h;
/*  96:185 */     } else if ((LWJGLUtil.DEBUG) && ((row_pitch < row_pitch * h) || (slice_pitch % row_pitch != 0L))) {
/*  97:186 */       throw new IllegalArgumentException("Invalid image_slice_pitch specified: " + row_pitch);
/*  98:    */     }
/*  99:188 */     return (int)(slice_pitch * d);
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static int getElementSize(ByteBuffer format)
/* 103:    */   {
/* 104:199 */     int channelOrder = format.getInt(format.position() + 0);
/* 105:200 */     int channelType = format.getInt(format.position() + 4);
/* 106:    */     
/* 107:202 */     return getChannelCount(channelOrder) * getChannelSize(channelType);
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static int getChannelCount(int channelOrder)
/* 111:    */   {
/* 112:213 */     switch (channelOrder)
/* 113:    */     {
/* 114:    */     case 4272: 
/* 115:    */     case 4273: 
/* 116:    */     case 4280: 
/* 117:    */     case 4281: 
/* 118:    */     case 4282: 
/* 119:219 */       return 1;
/* 120:    */     case 4274: 
/* 121:    */     case 4275: 
/* 122:    */     case 4283: 
/* 123:223 */       return 2;
/* 124:    */     case 4276: 
/* 125:    */     case 4284: 
/* 126:226 */       return 3;
/* 127:    */     case 4277: 
/* 128:    */     case 4278: 
/* 129:    */     case 4279: 
/* 130:230 */       return 4;
/* 131:    */     }
/* 132:232 */     throw new IllegalArgumentException("Invalid cl_channel_order specified: " + LWJGLUtil.toHexString(channelOrder));
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static int getChannelSize(int channelType)
/* 136:    */   {
/* 137:244 */     switch (channelType)
/* 138:    */     {
/* 139:    */     case 4304: 
/* 140:    */     case 4306: 
/* 141:    */     case 4311: 
/* 142:    */     case 4314: 
/* 143:249 */       return 1;
/* 144:    */     case 4305: 
/* 145:    */     case 4307: 
/* 146:    */     case 4308: 
/* 147:    */     case 4309: 
/* 148:    */     case 4312: 
/* 149:    */     case 4315: 
/* 150:    */     case 4317: 
/* 151:257 */       return 2;
/* 152:    */     case 4310: 
/* 153:    */     case 4313: 
/* 154:    */     case 4316: 
/* 155:    */     case 4318: 
/* 156:262 */       return 4;
/* 157:    */     }
/* 158:264 */     throw new IllegalArgumentException("Invalid cl_channel_type specified: " + LWJGLUtil.toHexString(channelType));
/* 159:    */   }
/* 160:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLChecks
 * JD-Core Version:    0.7.0.1
 */