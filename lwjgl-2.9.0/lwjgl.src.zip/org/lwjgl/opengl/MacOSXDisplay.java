/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.awt.Robot;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.List;
/*  10:    */ import org.lwjgl.BufferUtils;
/*  11:    */ import org.lwjgl.LWJGLException;
/*  12:    */ import org.lwjgl.MemoryUtil;
/*  13:    */ 
/*  14:    */ final class MacOSXDisplay
/*  15:    */   implements DisplayImplementation
/*  16:    */ {
/*  17:    */   private static final int PBUFFER_HANDLE_SIZE = 24;
/*  18:    */   private static final int GAMMA_LENGTH = 256;
/*  19:    */   private Canvas canvas;
/*  20:    */   private Robot robot;
/*  21:    */   private MacOSXMouseEventQueue mouse_queue;
/*  22:    */   private KeyboardEventQueue keyboard_queue;
/*  23:    */   private DisplayMode requested_mode;
/*  24:    */   private MacOSXNativeMouse mouse;
/*  25:    */   private MacOSXNativeKeyboard keyboard;
/*  26:    */   private ByteBuffer window;
/*  27:    */   private ByteBuffer context;
/*  28: 80 */   private boolean skipViewportValue = false;
/*  29: 81 */   private static final IntBuffer current_viewport = BufferUtils.createIntBuffer(16);
/*  30:    */   private boolean mouseInsideWindow;
/*  31:    */   private boolean close_requested;
/*  32: 87 */   private boolean native_mode = true;
/*  33: 89 */   private boolean updateNativeCursor = false;
/*  34: 91 */   private long currentNativeCursor = 0L;
/*  35:    */   
/*  36:    */   private native ByteBuffer nCreateWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/*  37:    */     throws LWJGLException;
/*  38:    */   
/*  39:    */   private native Object nGetCurrentDisplayMode();
/*  40:    */   
/*  41:    */   private native void nGetDisplayModes(Object paramObject);
/*  42:    */   
/*  43:    */   private native boolean nIsMiniaturized(ByteBuffer paramByteBuffer);
/*  44:    */   
/*  45:    */   private native boolean nIsFocused(ByteBuffer paramByteBuffer);
/*  46:    */   
/*  47:    */   private native void nSetResizable(ByteBuffer paramByteBuffer, boolean paramBoolean);
/*  48:    */   
/*  49:    */   private native void nResizeWindow(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*  50:    */   
/*  51:    */   private native boolean nWasResized(ByteBuffer paramByteBuffer);
/*  52:    */   
/*  53:    */   private native int nGetX(ByteBuffer paramByteBuffer);
/*  54:    */   
/*  55:    */   private native int nGetY(ByteBuffer paramByteBuffer);
/*  56:    */   
/*  57:    */   private native int nGetWidth(ByteBuffer paramByteBuffer);
/*  58:    */   
/*  59:    */   private native int nGetHeight(ByteBuffer paramByteBuffer);
/*  60:    */   
/*  61:    */   private native boolean nIsNativeMode(ByteBuffer paramByteBuffer);
/*  62:    */   
/*  63:    */   private static boolean isUndecorated()
/*  64:    */   {
/*  65:124 */     return Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated");
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void createWindow(DrawableLWJGL drawable, DisplayMode mode, Canvas parent, int x, int y)
/*  69:    */     throws LWJGLException
/*  70:    */   {
/*  71:128 */     boolean fullscreen = Display.isFullscreen();
/*  72:129 */     boolean resizable = Display.isResizable();
/*  73:130 */     boolean parented = (parent != null) && (!fullscreen);
/*  74:132 */     if (parented) {
/*  75:132 */       this.canvas = parent;
/*  76:    */     } else {
/*  77:133 */       this.canvas = null;
/*  78:    */     }
/*  79:135 */     this.close_requested = false;
/*  80:    */     
/*  81:137 */     DrawableGL gl_drawable = (DrawableGL)Display.getDrawable();
/*  82:138 */     PeerInfo peer_info = gl_drawable.peer_info;
/*  83:139 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  84:140 */     ByteBuffer window_handle = parented ? ((MacOSXCanvasPeerInfo)peer_info).window_handle : this.window;
/*  85:    */     try
/*  86:    */     {
/*  87:144 */       this.window = nCreateWindow(x, y, mode.getWidth(), mode.getHeight(), fullscreen, isUndecorated(), resizable, parented, peer_handle, window_handle);
/*  88:148 */       if (fullscreen)
/*  89:    */       {
/*  90:150 */         this.skipViewportValue = true;
/*  91:152 */         if ((current_viewport.get(2) == 0) && (current_viewport.get(3) == 0))
/*  92:    */         {
/*  93:153 */           current_viewport.put(2, mode.getWidth());
/*  94:154 */           current_viewport.put(3, mode.getHeight());
/*  95:    */         }
/*  96:    */       }
/*  97:158 */       this.native_mode = nIsNativeMode(peer_handle);
/*  98:160 */       if (!this.native_mode) {
/*  99:161 */         this.robot = AWTUtil.createRobot(this.canvas);
/* 100:    */       }
/* 101:    */     }
/* 102:    */     catch (LWJGLException e)
/* 103:    */     {
/* 104:166 */       throw e;
/* 105:    */     }
/* 106:    */     finally
/* 107:    */     {
/* 108:168 */       peer_info.unlock();
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void doHandleQuit()
/* 113:    */   {
/* 114:173 */     synchronized (this)
/* 115:    */     {
/* 116:174 */       this.close_requested = true;
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public void mouseInsideWindow(boolean inside)
/* 121:    */   {
/* 122:179 */     synchronized (this)
/* 123:    */     {
/* 124:180 */       this.mouseInsideWindow = inside;
/* 125:    */     }
/* 126:182 */     this.updateNativeCursor = true;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public native void nDestroyCALayer(ByteBuffer paramByteBuffer);
/* 130:    */   
/* 131:    */   public native void nDestroyWindow(ByteBuffer paramByteBuffer);
/* 132:    */   
/* 133:    */   public void destroyWindow()
/* 134:    */   {
/* 135:191 */     if (!this.native_mode)
/* 136:    */     {
/* 137:192 */       DrawableGL gl_drawable = (DrawableGL)Display.getDrawable();
/* 138:193 */       PeerInfo peer_info = gl_drawable.peer_info;
/* 139:194 */       if (peer_info != null)
/* 140:    */       {
/* 141:195 */         ByteBuffer peer_handle = peer_info.getHandle();
/* 142:196 */         nDestroyCALayer(peer_handle);
/* 143:    */       }
/* 144:198 */       this.robot = null;
/* 145:    */     }
/* 146:201 */     nDestroyWindow(this.window);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public int getGammaRampLength()
/* 150:    */   {
/* 151:205 */     return 256;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public native void setGammaRamp(FloatBuffer paramFloatBuffer)
/* 155:    */     throws LWJGLException;
/* 156:    */   
/* 157:    */   public String getAdapter()
/* 158:    */   {
/* 159:211 */     return null;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public String getVersion()
/* 163:    */   {
/* 164:215 */     return null;
/* 165:    */   }
/* 166:    */   
/* 167:    */   private static boolean equals(DisplayMode mode1, DisplayMode mode2)
/* 168:    */   {
/* 169:219 */     return (mode1.getWidth() == mode2.getWidth()) && (mode1.getHeight() == mode2.getHeight()) && (mode1.getBitsPerPixel() == mode2.getBitsPerPixel()) && (mode1.getFrequency() == mode2.getFrequency());
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void switchDisplayMode(DisplayMode mode)
/* 173:    */     throws LWJGLException
/* 174:    */   {
/* 175:224 */     DisplayMode[] modes = getAvailableDisplayModes();
/* 176:226 */     for (DisplayMode available_mode : modes) {
/* 177:227 */       if (equals(available_mode, mode))
/* 178:    */       {
/* 179:228 */         this.requested_mode = available_mode;
/* 180:229 */         return;
/* 181:    */       }
/* 182:    */     }
/* 183:233 */     throw new LWJGLException(mode + " is not supported");
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void resetDisplayMode()
/* 187:    */   {
/* 188:237 */     this.requested_mode = null;
/* 189:238 */     restoreGamma();
/* 190:    */   }
/* 191:    */   
/* 192:    */   private native void restoreGamma();
/* 193:    */   
/* 194:    */   public Object createDisplayMode(int width, int height, int bitsPerPixel, int refreshRate)
/* 195:    */   {
/* 196:244 */     return new DisplayMode(width, height, bitsPerPixel, refreshRate);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public DisplayMode init()
/* 200:    */     throws LWJGLException
/* 201:    */   {
/* 202:248 */     return (DisplayMode)nGetCurrentDisplayMode();
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void addDisplayMode(Object modesList, int width, int height, int bitsPerPixel, int refreshRate)
/* 206:    */   {
/* 207:252 */     List<DisplayMode> modes = (List)modesList;
/* 208:253 */     DisplayMode displayMode = new DisplayMode(width, height, bitsPerPixel, refreshRate);
/* 209:254 */     modes.add(displayMode);
/* 210:    */   }
/* 211:    */   
/* 212:    */   public DisplayMode[] getAvailableDisplayModes()
/* 213:    */     throws LWJGLException
/* 214:    */   {
/* 215:258 */     List<DisplayMode> modes = new ArrayList();
/* 216:259 */     nGetDisplayModes(modes);
/* 217:260 */     return (DisplayMode[])modes.toArray(new DisplayMode[modes.size()]);
/* 218:    */   }
/* 219:    */   
/* 220:    */   private native void nSetTitle(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2);
/* 221:    */   
/* 222:    */   public void setTitle(String title)
/* 223:    */   {
/* 224:266 */     ByteBuffer buffer = MemoryUtil.encodeUTF8(title);
/* 225:267 */     nSetTitle(this.window, buffer);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public boolean isCloseRequested()
/* 229:    */   {
/* 230:    */     boolean result;
/* 231:272 */     synchronized (this)
/* 232:    */     {
/* 233:273 */       result = this.close_requested;
/* 234:274 */       this.close_requested = false;
/* 235:    */     }
/* 236:276 */     return result;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public boolean isVisible()
/* 240:    */   {
/* 241:280 */     return true;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public boolean isActive()
/* 245:    */   {
/* 246:284 */     if (this.native_mode) {
/* 247:285 */       return nIsFocused(this.window);
/* 248:    */     }
/* 249:288 */     return Display.getParent().hasFocus();
/* 250:    */   }
/* 251:    */   
/* 252:    */   public Canvas getCanvas()
/* 253:    */   {
/* 254:293 */     return this.canvas;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public boolean isDirty()
/* 258:    */   {
/* 259:297 */     return false;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public PeerInfo createPeerInfo(PixelFormat pixel_format, ContextAttribs attribs)
/* 263:    */     throws LWJGLException
/* 264:    */   {
/* 265:    */     try
/* 266:    */     {
/* 267:302 */       return new MacOSXDisplayPeerInfo(pixel_format, attribs, true);
/* 268:    */     }
/* 269:    */     catch (LWJGLException e) {}
/* 270:304 */     return new MacOSXDisplayPeerInfo(pixel_format, attribs, false);
/* 271:    */   }
/* 272:    */   
/* 273:    */   public void update()
/* 274:    */   {
/* 275:309 */     boolean should_update = true;
/* 276:    */     
/* 277:311 */     DrawableGL drawable = (DrawableGL)Display.getDrawable();
/* 278:312 */     if (should_update)
/* 279:    */     {
/* 280:313 */       drawable.context.update();
/* 281:315 */       if (this.skipViewportValue) {
/* 282:315 */         this.skipViewportValue = false;
/* 283:    */       } else {
/* 284:316 */         GL11.glGetInteger(2978, current_viewport);
/* 285:    */       }
/* 286:317 */       GL11.glViewport(current_viewport.get(0), current_viewport.get(1), current_viewport.get(2), current_viewport.get(3));
/* 287:    */     }
/* 288:320 */     if ((this.native_mode) && (this.updateNativeCursor))
/* 289:    */     {
/* 290:321 */       this.updateNativeCursor = false;
/* 291:    */       try
/* 292:    */       {
/* 293:323 */         setNativeCursor(Long.valueOf(this.currentNativeCursor));
/* 294:    */       }
/* 295:    */       catch (LWJGLException e)
/* 296:    */       {
/* 297:325 */         e.printStackTrace();
/* 298:    */       }
/* 299:    */     }
/* 300:    */   }
/* 301:    */   
/* 302:    */   public void reshape(int x, int y, int width, int height) {}
/* 303:    */   
/* 304:    */   public boolean hasWheel()
/* 305:    */   {
/* 306:338 */     return AWTUtil.hasWheel();
/* 307:    */   }
/* 308:    */   
/* 309:    */   public int getButtonCount()
/* 310:    */   {
/* 311:342 */     return AWTUtil.getButtonCount();
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void createMouse()
/* 315:    */     throws LWJGLException
/* 316:    */   {
/* 317:346 */     if (this.native_mode)
/* 318:    */     {
/* 319:347 */       this.mouse = new MacOSXNativeMouse(this, this.window);
/* 320:348 */       this.mouse.register();
/* 321:    */     }
/* 322:    */     else
/* 323:    */     {
/* 324:351 */       this.mouse_queue = new MacOSXMouseEventQueue(this.canvas);
/* 325:352 */       this.mouse_queue.register();
/* 326:    */     }
/* 327:    */   }
/* 328:    */   
/* 329:    */   public void destroyMouse()
/* 330:    */   {
/* 331:357 */     if (this.native_mode)
/* 332:    */     {
/* 333:    */       try
/* 334:    */       {
/* 335:360 */         MacOSXNativeMouse.setCursor(0L);
/* 336:    */       }
/* 337:    */       catch (LWJGLException e) {}
/* 338:364 */       grabMouse(false);
/* 339:366 */       if (this.mouse != null) {
/* 340:367 */         this.mouse.unregister();
/* 341:    */       }
/* 342:369 */       this.mouse = null;
/* 343:    */     }
/* 344:    */     else
/* 345:    */     {
/* 346:372 */       if (this.mouse_queue != null)
/* 347:    */       {
/* 348:373 */         MacOSXMouseEventQueue.nGrabMouse(false);
/* 349:374 */         this.mouse_queue.unregister();
/* 350:    */       }
/* 351:376 */       this.mouse_queue = null;
/* 352:    */     }
/* 353:    */   }
/* 354:    */   
/* 355:    */   public void pollMouse(IntBuffer coord_buffer, ByteBuffer buttons_buffer)
/* 356:    */   {
/* 357:381 */     if (this.native_mode) {
/* 358:382 */       this.mouse.poll(coord_buffer, buttons_buffer);
/* 359:    */     } else {
/* 360:385 */       this.mouse_queue.poll(coord_buffer, buttons_buffer);
/* 361:    */     }
/* 362:    */   }
/* 363:    */   
/* 364:    */   public void readMouse(ByteBuffer buffer)
/* 365:    */   {
/* 366:390 */     if (this.native_mode) {
/* 367:391 */       this.mouse.copyEvents(buffer);
/* 368:    */     } else {
/* 369:394 */       this.mouse_queue.copyEvents(buffer);
/* 370:    */     }
/* 371:    */   }
/* 372:    */   
/* 373:    */   public void grabMouse(boolean grab)
/* 374:    */   {
/* 375:399 */     if (this.native_mode) {
/* 376:400 */       this.mouse.setGrabbed(grab);
/* 377:    */     } else {
/* 378:403 */       this.mouse_queue.setGrabbed(grab);
/* 379:    */     }
/* 380:    */   }
/* 381:    */   
/* 382:    */   public int getNativeCursorCapabilities()
/* 383:    */   {
/* 384:408 */     if (this.native_mode) {
/* 385:409 */       return 7;
/* 386:    */     }
/* 387:412 */     return AWTUtil.getNativeCursorCapabilities();
/* 388:    */   }
/* 389:    */   
/* 390:    */   public void setCursorPosition(int x, int y)
/* 391:    */   {
/* 392:416 */     if ((this.native_mode) && 
/* 393:417 */       (this.mouse != null)) {
/* 394:418 */       this.mouse.setCursorPosition(x, y);
/* 395:    */     }
/* 396:    */   }
/* 397:    */   
/* 398:    */   public void setNativeCursor(Object handle)
/* 399:    */     throws LWJGLException
/* 400:    */   {
/* 401:427 */     if (this.native_mode)
/* 402:    */     {
/* 403:428 */       this.currentNativeCursor = getCursorHandle(handle);
/* 404:429 */       if (Display.isCreated()) {
/* 405:430 */         if (this.mouseInsideWindow) {
/* 406:430 */           MacOSXNativeMouse.setCursor(this.currentNativeCursor);
/* 407:    */         } else {
/* 408:431 */           MacOSXNativeMouse.setCursor(0L);
/* 409:    */         }
/* 410:    */       }
/* 411:    */     }
/* 412:    */   }
/* 413:    */   
/* 414:    */   public int getMinCursorSize()
/* 415:    */   {
/* 416:437 */     return AWTUtil.getMinCursorSize();
/* 417:    */   }
/* 418:    */   
/* 419:    */   public int getMaxCursorSize()
/* 420:    */   {
/* 421:441 */     return AWTUtil.getMaxCursorSize();
/* 422:    */   }
/* 423:    */   
/* 424:    */   public void createKeyboard()
/* 425:    */     throws LWJGLException
/* 426:    */   {
/* 427:446 */     if (this.native_mode)
/* 428:    */     {
/* 429:447 */       this.keyboard = new MacOSXNativeKeyboard(this.window);
/* 430:448 */       this.keyboard.register();
/* 431:    */     }
/* 432:    */     else
/* 433:    */     {
/* 434:451 */       this.keyboard_queue = new KeyboardEventQueue(this.canvas);
/* 435:452 */       this.keyboard_queue.register();
/* 436:    */     }
/* 437:    */   }
/* 438:    */   
/* 439:    */   public void destroyKeyboard()
/* 440:    */   {
/* 441:457 */     if (this.native_mode)
/* 442:    */     {
/* 443:458 */       if (this.keyboard != null) {
/* 444:459 */         this.keyboard.unregister();
/* 445:    */       }
/* 446:461 */       this.keyboard = null;
/* 447:    */     }
/* 448:    */     else
/* 449:    */     {
/* 450:464 */       if (this.keyboard_queue != null) {
/* 451:465 */         this.keyboard_queue.unregister();
/* 452:    */       }
/* 453:467 */       this.keyboard_queue = null;
/* 454:    */     }
/* 455:    */   }
/* 456:    */   
/* 457:    */   public void pollKeyboard(ByteBuffer keyDownBuffer)
/* 458:    */   {
/* 459:472 */     if (this.native_mode) {
/* 460:473 */       this.keyboard.poll(keyDownBuffer);
/* 461:    */     } else {
/* 462:476 */       this.keyboard_queue.poll(keyDownBuffer);
/* 463:    */     }
/* 464:    */   }
/* 465:    */   
/* 466:    */   public void readKeyboard(ByteBuffer buffer)
/* 467:    */   {
/* 468:481 */     if (this.native_mode) {
/* 469:482 */       this.keyboard.copyEvents(buffer);
/* 470:    */     } else {
/* 471:485 */       this.keyboard_queue.copyEvents(buffer);
/* 472:    */     }
/* 473:    */   }
/* 474:    */   
/* 475:    */   public Object createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/* 476:    */     throws LWJGLException
/* 477:    */   {
/* 478:491 */     if (this.native_mode)
/* 479:    */     {
/* 480:492 */       long cursor = MacOSXNativeMouse.createCursor(width, height, xHotspot, yHotspot, numImages, images, delays);
/* 481:493 */       return Long.valueOf(cursor);
/* 482:    */     }
/* 483:496 */     return AWTUtil.createCursor(width, height, xHotspot, yHotspot, numImages, images, delays);
/* 484:    */   }
/* 485:    */   
/* 486:    */   public void destroyCursor(Object cursor_handle)
/* 487:    */   {
/* 488:501 */     long handle = getCursorHandle(cursor_handle);
/* 489:504 */     if (this.currentNativeCursor == handle) {
/* 490:505 */       this.currentNativeCursor = 0L;
/* 491:    */     }
/* 492:508 */     MacOSXNativeMouse.destroyCursor(handle);
/* 493:    */   }
/* 494:    */   
/* 495:    */   private static long getCursorHandle(Object cursor_handle)
/* 496:    */   {
/* 497:512 */     return cursor_handle != null ? ((Long)cursor_handle).longValue() : 0L;
/* 498:    */   }
/* 499:    */   
/* 500:    */   public int getPbufferCapabilities()
/* 501:    */   {
/* 502:516 */     return 1;
/* 503:    */   }
/* 504:    */   
/* 505:    */   public boolean isBufferLost(PeerInfo handle)
/* 506:    */   {
/* 507:520 */     return false;
/* 508:    */   }
/* 509:    */   
/* 510:    */   public PeerInfo createPbuffer(int width, int height, PixelFormat pixel_format, ContextAttribs attribs, IntBuffer pixelFormatCaps, IntBuffer pBufferAttribs)
/* 511:    */     throws LWJGLException
/* 512:    */   {
/* 513:526 */     return new MacOSXPbufferPeerInfo(width, height, pixel_format, attribs);
/* 514:    */   }
/* 515:    */   
/* 516:    */   public void setPbufferAttrib(PeerInfo handle, int attrib, int value)
/* 517:    */   {
/* 518:530 */     throw new UnsupportedOperationException();
/* 519:    */   }
/* 520:    */   
/* 521:    */   public void bindTexImageToPbuffer(PeerInfo handle, int buffer)
/* 522:    */   {
/* 523:534 */     throw new UnsupportedOperationException();
/* 524:    */   }
/* 525:    */   
/* 526:    */   public void releaseTexImageFromPbuffer(PeerInfo handle, int buffer)
/* 527:    */   {
/* 528:538 */     throw new UnsupportedOperationException();
/* 529:    */   }
/* 530:    */   
/* 531:    */   public int setIcon(ByteBuffer[] icons)
/* 532:    */   {
/* 533:582 */     return 0;
/* 534:    */   }
/* 535:    */   
/* 536:    */   public int getX()
/* 537:    */   {
/* 538:586 */     return nGetX(this.window);
/* 539:    */   }
/* 540:    */   
/* 541:    */   public int getY()
/* 542:    */   {
/* 543:590 */     return nGetY(this.window);
/* 544:    */   }
/* 545:    */   
/* 546:    */   public int getWidth()
/* 547:    */   {
/* 548:594 */     return nGetWidth(this.window);
/* 549:    */   }
/* 550:    */   
/* 551:    */   public int getHeight()
/* 552:    */   {
/* 553:598 */     return nGetHeight(this.window);
/* 554:    */   }
/* 555:    */   
/* 556:    */   public boolean isInsideWindow()
/* 557:    */   {
/* 558:602 */     return this.mouseInsideWindow;
/* 559:    */   }
/* 560:    */   
/* 561:    */   public void setResizable(boolean resizable)
/* 562:    */   {
/* 563:606 */     nSetResizable(this.window, resizable);
/* 564:    */   }
/* 565:    */   
/* 566:    */   public boolean wasResized()
/* 567:    */   {
/* 568:610 */     return nWasResized(this.window);
/* 569:    */   }
/* 570:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXDisplay
 * JD-Core Version:    0.7.0.1
 */