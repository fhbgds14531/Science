/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import org.lwjgl.LWJGLException;
/*   5:    */ import org.lwjgl.LWJGLUtil;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ import org.lwjgl.Sys;
/*   8:    */ 
/*   9:    */ public final class CL
/*  10:    */ {
/*  11:    */   private static boolean created;
/*  12:    */   
/*  13:    */   private static native void nCreate(String paramString)
/*  14:    */     throws LWJGLException;
/*  15:    */   
/*  16:    */   private static native void nCreateDefault()
/*  17:    */     throws LWJGLException;
/*  18:    */   
/*  19:    */   private static native void nDestroy();
/*  20:    */   
/*  21:    */   public static boolean isCreated()
/*  22:    */   {
/*  23: 76 */     return created;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static void create()
/*  27:    */     throws LWJGLException
/*  28:    */   {
/*  29: 80 */     if (created) {
/*  30:    */       return;
/*  31:    */     }
/*  32:    */     String libname;
/*  33:    */     String[] library_names;
/*  34: 86 */     switch (LWJGLUtil.getPlatform())
/*  35:    */     {
/*  36:    */     case 3: 
/*  37: 88 */       libname = "OpenCL";
/*  38: 89 */       library_names = new String[] { "OpenCL.dll" };
/*  39: 90 */       break;
/*  40:    */     case 1: 
/*  41: 92 */       libname = "OpenCL";
/*  42: 93 */       library_names = new String[] { "libOpenCL64.so", "libOpenCL.so" };
/*  43: 94 */       break;
/*  44:    */     case 2: 
/*  45: 96 */       libname = "OpenCL";
/*  46: 97 */       library_names = new String[] { "OpenCL.dylib" };
/*  47: 98 */       break;
/*  48:    */     default: 
/*  49:100 */       throw new LWJGLException("Unknown platform: " + LWJGLUtil.getPlatform());
/*  50:    */     }
/*  51:103 */     String[] oclPaths = LWJGLUtil.getLibraryPaths(libname, library_names, CL.class.getClassLoader());
/*  52:104 */     LWJGLUtil.log("Found " + oclPaths.length + " OpenCL paths");
/*  53:105 */     for (String oclPath : oclPaths) {
/*  54:    */       try
/*  55:    */       {
/*  56:107 */         nCreate(oclPath);
/*  57:108 */         created = true;
/*  58:    */       }
/*  59:    */       catch (LWJGLException e)
/*  60:    */       {
/*  61:111 */         LWJGLUtil.log("Failed to load " + oclPath + ": " + e.getMessage());
/*  62:    */       }
/*  63:    */     }
/*  64:115 */     if ((!created) && (LWJGLUtil.getPlatform() == 2))
/*  65:    */     {
/*  66:117 */       nCreateDefault();
/*  67:118 */       created = true;
/*  68:    */     }
/*  69:121 */     if (!created) {
/*  70:122 */       throw new LWJGLException("Could not locate OpenCL library.");
/*  71:    */     }
/*  72:124 */     if (!CLCapabilities.OpenCL10) {
/*  73:125 */       throw new RuntimeException("OpenCL 1.0 not supported.");
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static void destroy() {}
/*  78:    */   
/*  79:    */   static long getFunctionAddress(String[] aliases)
/*  80:    */   {
/*  81:139 */     for (String aliase : aliases)
/*  82:    */     {
/*  83:140 */       long address = getFunctionAddress(aliase);
/*  84:141 */       if (address != 0L) {
/*  85:142 */         return address;
/*  86:    */       }
/*  87:    */     }
/*  88:144 */     return 0L;
/*  89:    */   }
/*  90:    */   
/*  91:    */   static long getFunctionAddress(String name)
/*  92:    */   {
/*  93:149 */     ByteBuffer buffer = MemoryUtil.encodeASCII(name);
/*  94:150 */     return ngetFunctionAddress(MemoryUtil.getAddress(buffer));
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static native long ngetFunctionAddress(long paramLong);
/*  98:    */   
/*  99:    */   static native ByteBuffer getHostBuffer(long paramLong, int paramInt);
/* 100:    */   
/* 101:    */   private static native void resetNativeStubs(Class paramClass);
/* 102:    */   
/* 103:    */   static {}
/* 104:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CL
 * JD-Core Version:    0.7.0.1
 */