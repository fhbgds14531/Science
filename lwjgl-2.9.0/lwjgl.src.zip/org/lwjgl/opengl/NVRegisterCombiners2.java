/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class NVRegisterCombiners2
/*  8:   */ {
/*  9:   */   public static final int GL_PER_STAGE_CONSTANTS_NV = 34101;
/* 10:   */   
/* 11:   */   public static void glCombinerStageParameterNV(int stage, int pname, FloatBuffer params)
/* 12:   */   {
/* 13:15 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:16 */     long function_pointer = caps.glCombinerStageParameterfvNV;
/* 15:17 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:18 */     BufferChecks.checkBuffer(params, 4);
/* 17:19 */     nglCombinerStageParameterfvNV(stage, pname, MemoryUtil.getAddress(params), function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglCombinerStageParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 21:   */   
/* 22:   */   public static void glGetCombinerStageParameterNV(int stage, int pname, FloatBuffer params)
/* 23:   */   {
/* 24:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:25 */     long function_pointer = caps.glGetCombinerStageParameterfvNV;
/* 26:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:27 */     BufferChecks.checkBuffer(params, 4);
/* 28:28 */     nglGetCombinerStageParameterfvNV(stage, pname, MemoryUtil.getAddress(params), function_pointer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   static native void nglGetCombinerStageParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 32:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVRegisterCombiners2
 * JD-Core Version:    0.7.0.1
 */