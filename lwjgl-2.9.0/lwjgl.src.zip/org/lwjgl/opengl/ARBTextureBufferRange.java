/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBTextureBufferRange
/*  6:   */ {
/*  7:   */   public static final int GL_TEXTURE_BUFFER_OFFSET = 37277;
/*  8:   */   public static final int GL_TEXTURE_BUFFER_SIZE = 37278;
/*  9:   */   public static final int GL_TEXTURE_BUFFER_OFFSET_ALIGNMENT = 37279;
/* 10:   */   
/* 11:   */   public static void glTexBufferRange(int target, int internalformat, int buffer, long offset, long size)
/* 12:   */   {
/* 13:25 */     GL43.glTexBufferRange(target, internalformat, buffer, offset, size);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static void glTextureBufferRangeEXT(int texture, int target, int internalformat, int buffer, long offset, long size)
/* 17:   */   {
/* 18:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 19:30 */     long function_pointer = caps.glTextureBufferRangeEXT;
/* 20:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 21:32 */     nglTextureBufferRangeEXT(texture, target, internalformat, buffer, offset, size, function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   static native void nglTextureBufferRangeEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2, long paramLong3);
/* 25:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureBufferRange
 * JD-Core Version:    0.7.0.1
 */