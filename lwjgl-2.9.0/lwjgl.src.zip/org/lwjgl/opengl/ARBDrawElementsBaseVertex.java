/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ 
/*  7:   */ public final class ARBDrawElementsBaseVertex
/*  8:   */ {
/*  9:   */   public static void glDrawElementsBaseVertex(int mode, ByteBuffer indices, int basevertex)
/* 10:   */   {
/* 11:13 */     GL32.glDrawElementsBaseVertex(mode, indices, basevertex);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static void glDrawElementsBaseVertex(int mode, IntBuffer indices, int basevertex)
/* 15:   */   {
/* 16:16 */     GL32.glDrawElementsBaseVertex(mode, indices, basevertex);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void glDrawElementsBaseVertex(int mode, ShortBuffer indices, int basevertex)
/* 20:   */   {
/* 21:19 */     GL32.glDrawElementsBaseVertex(mode, indices, basevertex);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glDrawElementsBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int basevertex)
/* 25:   */   {
/* 26:22 */     GL32.glDrawElementsBaseVertex(mode, indices_count, type, indices_buffer_offset, basevertex);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ByteBuffer indices, int basevertex)
/* 30:   */   {
/* 31:26 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, IntBuffer indices, int basevertex)
/* 35:   */   {
/* 36:29 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, ShortBuffer indices, int basevertex)
/* 40:   */   {
/* 41:32 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices, basevertex);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static void glDrawRangeElementsBaseVertex(int mode, int start, int end, int indices_count, int type, long indices_buffer_offset, int basevertex)
/* 45:   */   {
/* 46:35 */     GL32.glDrawRangeElementsBaseVertex(mode, start, end, indices_count, type, indices_buffer_offset, basevertex);
/* 47:   */   }
/* 48:   */   
/* 49:   */   public static void glDrawElementsInstancedBaseVertex(int mode, ByteBuffer indices, int primcount, int basevertex)
/* 50:   */   {
/* 51:39 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public static void glDrawElementsInstancedBaseVertex(int mode, IntBuffer indices, int primcount, int basevertex)
/* 55:   */   {
/* 56:42 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static void glDrawElementsInstancedBaseVertex(int mode, ShortBuffer indices, int primcount, int basevertex)
/* 60:   */   {
/* 61:45 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices, primcount, basevertex);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public static void glDrawElementsInstancedBaseVertex(int mode, int indices_count, int type, long indices_buffer_offset, int primcount, int basevertex)
/* 65:   */   {
/* 66:48 */     GL32.glDrawElementsInstancedBaseVertex(mode, indices_count, type, indices_buffer_offset, primcount, basevertex);
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDrawElementsBaseVertex
 * JD-Core Version:    0.7.0.1
 */