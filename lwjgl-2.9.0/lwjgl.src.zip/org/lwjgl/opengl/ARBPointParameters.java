/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class ARBPointParameters
/*  8:   */ {
/*  9:   */   public static final int GL_POINT_SIZE_MIN_ARB = 33062;
/* 10:   */   public static final int GL_POINT_SIZE_MAX_ARB = 33063;
/* 11:   */   public static final int GL_POINT_FADE_THRESHOLD_SIZE_ARB = 33064;
/* 12:   */   public static final int GL_POINT_DISTANCE_ATTENUATION_ARB = 33065;
/* 13:   */   
/* 14:   */   public static void glPointParameterfARB(int pname, float param)
/* 15:   */   {
/* 16:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 17:19 */     long function_pointer = caps.glPointParameterfARB;
/* 18:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 19:21 */     nglPointParameterfARB(pname, param, function_pointer);
/* 20:   */   }
/* 21:   */   
/* 22:   */   static native void nglPointParameterfARB(int paramInt, float paramFloat, long paramLong);
/* 23:   */   
/* 24:   */   public static void glPointParameterARB(int pname, FloatBuffer pfParams)
/* 25:   */   {
/* 26:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:27 */     long function_pointer = caps.glPointParameterfvARB;
/* 28:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:29 */     BufferChecks.checkBuffer(pfParams, 4);
/* 30:30 */     nglPointParameterfvARB(pname, MemoryUtil.getAddress(pfParams), function_pointer);
/* 31:   */   }
/* 32:   */   
/* 33:   */   static native void nglPointParameterfvARB(int paramInt, long paramLong1, long paramLong2);
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBPointParameters
 * JD-Core Version:    0.7.0.1
 */