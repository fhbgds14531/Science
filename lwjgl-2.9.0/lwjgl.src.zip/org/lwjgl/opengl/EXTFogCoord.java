/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.DoubleBuffer;
/*  4:   */ import java.nio.FloatBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.LWJGLUtil;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class EXTFogCoord
/* 10:   */ {
/* 11:   */   public static final int GL_FOG_COORDINATE_SOURCE_EXT = 33872;
/* 12:   */   public static final int GL_FOG_COORDINATE_EXT = 33873;
/* 13:   */   public static final int GL_FRAGMENT_DEPTH_EXT = 33874;
/* 14:   */   public static final int GL_CURRENT_FOG_COORDINATE_EXT = 33875;
/* 15:   */   public static final int GL_FOG_COORDINATE_ARRAY_TYPE_EXT = 33876;
/* 16:   */   public static final int GL_FOG_COORDINATE_ARRAY_STRIDE_EXT = 33877;
/* 17:   */   public static final int GL_FOG_COORDINATE_ARRAY_POINTER_EXT = 33878;
/* 18:   */   public static final int GL_FOG_COORDINATE_ARRAY_EXT = 33879;
/* 19:   */   
/* 20:   */   public static void glFogCoordfEXT(float coord)
/* 21:   */   {
/* 22:22 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:23 */     long function_pointer = caps.glFogCoordfEXT;
/* 24:24 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:25 */     nglFogCoordfEXT(coord, function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglFogCoordfEXT(float paramFloat, long paramLong);
/* 29:   */   
/* 30:   */   public static void glFogCoorddEXT(double coord)
/* 31:   */   {
/* 32:30 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 33:31 */     long function_pointer = caps.glFogCoorddEXT;
/* 34:32 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 35:33 */     nglFogCoorddEXT(coord, function_pointer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   static native void nglFogCoorddEXT(double paramDouble, long paramLong);
/* 39:   */   
/* 40:   */   public static void glFogCoordPointerEXT(int stride, DoubleBuffer data)
/* 41:   */   {
/* 42:38 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:39 */     long function_pointer = caps.glFogCoordPointerEXT;
/* 44:40 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 45:41 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 46:42 */     BufferChecks.checkDirect(data);
/* 47:43 */     if (LWJGLUtil.CHECKS) {
/* 48:43 */       StateTracker.getReferences(caps).EXT_fog_coord_glFogCoordPointerEXT_data = data;
/* 49:   */     }
/* 50:44 */     nglFogCoordPointerEXT(5130, stride, MemoryUtil.getAddress(data), function_pointer);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static void glFogCoordPointerEXT(int stride, FloatBuffer data)
/* 54:   */   {
/* 55:47 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 56:48 */     long function_pointer = caps.glFogCoordPointerEXT;
/* 57:49 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 58:50 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 59:51 */     BufferChecks.checkDirect(data);
/* 60:52 */     if (LWJGLUtil.CHECKS) {
/* 61:52 */       StateTracker.getReferences(caps).EXT_fog_coord_glFogCoordPointerEXT_data = data;
/* 62:   */     }
/* 63:53 */     nglFogCoordPointerEXT(5126, stride, MemoryUtil.getAddress(data), function_pointer);
/* 64:   */   }
/* 65:   */   
/* 66:   */   static native void nglFogCoordPointerEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 67:   */   
/* 68:   */   public static void glFogCoordPointerEXT(int type, int stride, long data_buffer_offset)
/* 69:   */   {
/* 70:57 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 71:58 */     long function_pointer = caps.glFogCoordPointerEXT;
/* 72:59 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 73:60 */     GLChecks.ensureArrayVBOenabled(caps);
/* 74:61 */     nglFogCoordPointerEXTBO(type, stride, data_buffer_offset, function_pointer);
/* 75:   */   }
/* 76:   */   
/* 77:   */   static native void nglFogCoordPointerEXTBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 78:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTFogCoord
 * JD-Core Version:    0.7.0.1
 */