/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import org.lwjgl.PointerWrapperAbstract;
/*   6:    */ 
/*   7:    */ public final class ARBDebugOutputCallback
/*   8:    */   extends PointerWrapperAbstract
/*   9:    */ {
/*  10:    */   private static final int GL_DEBUG_SEVERITY_HIGH_ARB = 37190;
/*  11:    */   private static final int GL_DEBUG_SEVERITY_MEDIUM_ARB = 37191;
/*  12:    */   private static final int GL_DEBUG_SEVERITY_LOW_ARB = 37192;
/*  13:    */   private static final int GL_DEBUG_SOURCE_API_ARB = 33350;
/*  14:    */   private static final int GL_DEBUG_SOURCE_WINDOW_SYSTEM_ARB = 33351;
/*  15:    */   private static final int GL_DEBUG_SOURCE_SHADER_COMPILER_ARB = 33352;
/*  16:    */   private static final int GL_DEBUG_SOURCE_THIRD_PARTY_ARB = 33353;
/*  17:    */   private static final int GL_DEBUG_SOURCE_APPLICATION_ARB = 33354;
/*  18:    */   private static final int GL_DEBUG_SOURCE_OTHER_ARB = 33355;
/*  19:    */   private static final int GL_DEBUG_TYPE_ERROR_ARB = 33356;
/*  20:    */   private static final int GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR_ARB = 33357;
/*  21:    */   private static final int GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR_ARB = 33358;
/*  22:    */   private static final int GL_DEBUG_TYPE_PORTABILITY_ARB = 33359;
/*  23:    */   private static final int GL_DEBUG_TYPE_PERFORMANCE_ARB = 33360;
/*  24:    */   private static final int GL_DEBUG_TYPE_OTHER_ARB = 33361;
/*  25:    */   private static final long CALLBACK_POINTER;
/*  26:    */   private final Handler handler;
/*  27:    */   
/*  28:    */   static
/*  29:    */   {
/*  30: 73 */     long pointer = 0L;
/*  31:    */     try
/*  32:    */     {
/*  33: 76 */       pointer = ((Long)Class.forName("org.lwjgl.opengl.CallbackUtil").getDeclaredMethod("getDebugOutputCallbackARB", new Class[0]).invoke(null, new Object[0])).longValue();
/*  34:    */     }
/*  35:    */     catch (Exception e) {}
/*  36: 80 */     CALLBACK_POINTER = pointer;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public ARBDebugOutputCallback()
/*  40:    */   {
/*  41: 90 */     this(new Handler()
/*  42:    */     {
/*  43:    */       public void handleMessage(int source, int type, int id, int severity, String message)
/*  44:    */       {
/*  45: 92 */         System.err.println("[LWJGL] ARB_debug_output message");
/*  46: 93 */         System.err.println("\tID: " + id);
/*  47:    */         String description;
/*  48: 96 */         switch (source)
/*  49:    */         {
/*  50:    */         case 33350: 
/*  51: 98 */           description = "API";
/*  52: 99 */           break;
/*  53:    */         case 33351: 
/*  54:101 */           description = "WINDOW SYSTEM";
/*  55:102 */           break;
/*  56:    */         case 33352: 
/*  57:104 */           description = "SHADER COMPILER";
/*  58:105 */           break;
/*  59:    */         case 33353: 
/*  60:107 */           description = "THIRD PARTY";
/*  61:108 */           break;
/*  62:    */         case 33354: 
/*  63:110 */           description = "APPLICATION";
/*  64:111 */           break;
/*  65:    */         case 33355: 
/*  66:113 */           description = "OTHER";
/*  67:114 */           break;
/*  68:    */         default: 
/*  69:116 */           description = printUnknownToken(source);
/*  70:    */         }
/*  71:118 */         System.err.println("\tSource: " + description);
/*  72:120 */         switch (type)
/*  73:    */         {
/*  74:    */         case 33356: 
/*  75:122 */           description = "ERROR";
/*  76:123 */           break;
/*  77:    */         case 33357: 
/*  78:125 */           description = "DEPRECATED BEHAVIOR";
/*  79:126 */           break;
/*  80:    */         case 33358: 
/*  81:128 */           description = "UNDEFINED BEHAVIOR";
/*  82:129 */           break;
/*  83:    */         case 33359: 
/*  84:131 */           description = "PORTABILITY";
/*  85:132 */           break;
/*  86:    */         case 33360: 
/*  87:134 */           description = "PERFORMANCE";
/*  88:135 */           break;
/*  89:    */         case 33361: 
/*  90:137 */           description = "OTHER";
/*  91:138 */           break;
/*  92:    */         default: 
/*  93:140 */           description = printUnknownToken(type);
/*  94:    */         }
/*  95:142 */         System.err.println("\tType: " + description);
/*  96:144 */         switch (severity)
/*  97:    */         {
/*  98:    */         case 37190: 
/*  99:146 */           description = "HIGH";
/* 100:147 */           break;
/* 101:    */         case 37191: 
/* 102:149 */           description = "MEDIUM";
/* 103:150 */           break;
/* 104:    */         case 37192: 
/* 105:152 */           description = "LOW";
/* 106:153 */           break;
/* 107:    */         default: 
/* 108:155 */           description = printUnknownToken(severity);
/* 109:    */         }
/* 110:157 */         System.err.println("\tSeverity: " + description);
/* 111:    */         
/* 112:159 */         System.err.println("\tMessage: " + message);
/* 113:    */       }
/* 114:    */       
/* 115:    */       private String printUnknownToken(int token)
/* 116:    */       {
/* 117:163 */         return "Unknown (0x" + Integer.toHexString(token).toUpperCase() + ")";
/* 118:    */       }
/* 119:    */     });
/* 120:    */   }
/* 121:    */   
/* 122:    */   public ARBDebugOutputCallback(Handler handler)
/* 123:    */   {
/* 124:176 */     super(CALLBACK_POINTER);
/* 125:    */     
/* 126:178 */     this.handler = handler;
/* 127:    */   }
/* 128:    */   
/* 129:    */   Handler getHandler()
/* 130:    */   {
/* 131:182 */     return this.handler;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static abstract interface Handler
/* 135:    */   {
/* 136:    */     public abstract void handleMessage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString);
/* 137:    */   }
/* 138:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDebugOutputCallback
 * JD-Core Version:    0.7.0.1
 */