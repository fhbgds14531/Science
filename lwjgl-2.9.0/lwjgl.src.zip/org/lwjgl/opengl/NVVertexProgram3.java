package org.lwjgl.opengl;

public final class NVVertexProgram3
{
  public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB = 35660;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVertexProgram3
 * JD-Core Version:    0.7.0.1
 */