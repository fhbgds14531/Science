package org.lwjgl.opencl;

public abstract class CLLinkProgramCallback
  extends CLProgramCallback
{}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLLinkProgramCallback
 * JD-Core Version:    0.7.0.1
 */