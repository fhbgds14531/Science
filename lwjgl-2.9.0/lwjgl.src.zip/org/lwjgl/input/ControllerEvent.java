/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ class ControllerEvent
/*   4:    */ {
/*   5:    */   public static final int BUTTON = 1;
/*   6:    */   public static final int AXIS = 2;
/*   7:    */   public static final int POVX = 3;
/*   8:    */   public static final int POVY = 4;
/*   9:    */   private Controller source;
/*  10:    */   private int index;
/*  11:    */   private int type;
/*  12:    */   private boolean xaxis;
/*  13:    */   private boolean yaxis;
/*  14:    */   private long timeStamp;
/*  15:    */   
/*  16:    */   ControllerEvent(Controller source, long timeStamp, int type, int index, boolean xaxis, boolean yaxis)
/*  17:    */   {
/*  18: 73 */     this.source = source;
/*  19: 74 */     this.timeStamp = timeStamp;
/*  20: 75 */     this.type = type;
/*  21: 76 */     this.index = index;
/*  22: 77 */     this.xaxis = xaxis;
/*  23: 78 */     this.yaxis = yaxis;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public long getTimeStamp()
/*  27:    */   {
/*  28: 88 */     return this.timeStamp;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Controller getSource()
/*  32:    */   {
/*  33: 97 */     return this.source;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int getControlIndex()
/*  37:    */   {
/*  38:106 */     return this.index;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public boolean isButton()
/*  42:    */   {
/*  43:115 */     return this.type == 1;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isAxis()
/*  47:    */   {
/*  48:124 */     return this.type == 2;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean isPovY()
/*  52:    */   {
/*  53:133 */     return this.type == 4;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean isPovX()
/*  57:    */   {
/*  58:142 */     return this.type == 3;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean isXAxis()
/*  62:    */   {
/*  63:151 */     return this.xaxis;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isYAxis()
/*  67:    */   {
/*  68:160 */     return this.yaxis;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public String toString()
/*  72:    */   {
/*  73:167 */     return "[" + this.source + " type=" + this.type + " xaxis=" + this.xaxis + " yaxis=" + this.yaxis + "]";
/*  74:    */   }
/*  75:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.ControllerEvent
 * JD-Core Version:    0.7.0.1
 */