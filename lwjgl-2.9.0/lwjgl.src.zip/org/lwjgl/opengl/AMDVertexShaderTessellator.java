/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class AMDVertexShaderTessellator
/*  6:   */ {
/*  7:   */   public static final int GL_SAMPLER_BUFFER_AMD = 36865;
/*  8:   */   public static final int GL_INT_SAMPLER_BUFFER_AMD = 36866;
/*  9:   */   public static final int GL_UNSIGNED_INT_SAMPLER_BUFFER_AMD = 36867;
/* 10:   */   public static final int GL_DISCRETE_AMD = 36870;
/* 11:   */   public static final int GL_CONTINUOUS_AMD = 36871;
/* 12:   */   public static final int GL_TESSELLATION_MODE_AMD = 36868;
/* 13:   */   public static final int GL_TESSELLATION_FACTOR_AMD = 36869;
/* 14:   */   
/* 15:   */   public static void glTessellationFactorAMD(float factor)
/* 16:   */   {
/* 17:36 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 18:37 */     long function_pointer = caps.glTessellationFactorAMD;
/* 19:38 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 20:39 */     nglTessellationFactorAMD(factor, function_pointer);
/* 21:   */   }
/* 22:   */   
/* 23:   */   static native void nglTessellationFactorAMD(float paramFloat, long paramLong);
/* 24:   */   
/* 25:   */   public static void glTessellationModeAMD(int mode)
/* 26:   */   {
/* 27:44 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 28:45 */     long function_pointer = caps.glTessellationModeAMD;
/* 29:46 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 30:47 */     nglTessellationModeAMD(mode, function_pointer);
/* 31:   */   }
/* 32:   */   
/* 33:   */   static native void nglTessellationModeAMD(int paramInt, long paramLong);
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDVertexShaderTessellator
 * JD-Core Version:    0.7.0.1
 */