/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.Sys;
/*   4:    */ 
/*   5:    */ class Sync
/*   6:    */ {
/*   7:    */   private static final long NANOS_IN_SECOND = 1000000000L;
/*   8: 49 */   private static long nextFrame = 0L;
/*   9: 52 */   private static boolean initialised = false;
/*  10: 55 */   private static RunningAvg sleepDurations = new RunningAvg(10);
/*  11: 56 */   private static RunningAvg yieldDurations = new RunningAvg(10);
/*  12:    */   
/*  13:    */   public static void sync(int fps)
/*  14:    */   {
/*  15: 66 */     if (fps <= 0) {
/*  16: 66 */       return;
/*  17:    */     }
/*  18: 67 */     if (!initialised) {
/*  19: 67 */       initialise();
/*  20:    */     }
/*  21:    */     try
/*  22:    */     {
/*  23:    */       long t1;
/*  24: 71 */       for (long t0 = getTime(); nextFrame - t0 > sleepDurations.avg(); t0 = t1)
/*  25:    */       {
/*  26: 72 */         Thread.sleep(1L);
/*  27: 73 */         sleepDurations.add((t1 = getTime()) - t0);
/*  28:    */       }
/*  29: 77 */       sleepDurations.dampenForLowResTicker();
/*  30:    */       long t1;
/*  31: 80 */       for (long t0 = getTime(); nextFrame - t0 > yieldDurations.avg(); t0 = t1)
/*  32:    */       {
/*  33: 81 */         Thread.yield();
/*  34: 82 */         yieldDurations.add((t1 = getTime()) - t0);
/*  35:    */       }
/*  36:    */     }
/*  37:    */     catch (InterruptedException e) {}
/*  38: 89 */     nextFrame = Math.max(nextFrame + 1000000000L / fps, getTime());
/*  39:    */   }
/*  40:    */   
/*  41:    */   private static void initialise()
/*  42:    */   {
/*  43: 99 */     initialised = true;
/*  44:    */     
/*  45:101 */     sleepDurations.init(1000000L);
/*  46:102 */     yieldDurations.init((int)(-(getTime() - getTime()) * 1.333D));
/*  47:    */     
/*  48:104 */     nextFrame = getTime();
/*  49:    */     
/*  50:106 */     String osName = System.getProperty("os.name");
/*  51:108 */     if (osName.startsWith("Win"))
/*  52:    */     {
/*  53:113 */       Thread timerAccuracyThread = new Thread(new Runnable()
/*  54:    */       {
/*  55:    */         public void run()
/*  56:    */         {
/*  57:    */           try
/*  58:    */           {
/*  59:116 */             Thread.sleep(9223372036854775807L);
/*  60:    */           }
/*  61:    */           catch (Exception e) {}
/*  62:    */         }
/*  63:120 */       });
/*  64:121 */       timerAccuracyThread.setName("LWJGL Timer");
/*  65:122 */       timerAccuracyThread.setDaemon(true);
/*  66:123 */       timerAccuracyThread.start();
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static long getTime()
/*  71:    */   {
/*  72:133 */     return Sys.getTime() * 1000000000L / Sys.getTimerResolution();
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static class RunningAvg
/*  76:    */   {
/*  77:    */     private final long[] slots;
/*  78:    */     private int offset;
/*  79:    */     private static final long DAMPEN_THRESHOLD = 10000000L;
/*  80:    */     private static final float DAMPEN_FACTOR = 0.9F;
/*  81:    */     
/*  82:    */     public RunningAvg(int slotCount)
/*  83:    */     {
/*  84:144 */       this.slots = new long[slotCount];
/*  85:145 */       this.offset = 0;
/*  86:    */     }
/*  87:    */     
/*  88:    */     public void init(long value)
/*  89:    */     {
/*  90:149 */       while (this.offset < this.slots.length) {
/*  91:150 */         this.slots[(this.offset++)] = value;
/*  92:    */       }
/*  93:    */     }
/*  94:    */     
/*  95:    */     public void add(long value)
/*  96:    */     {
/*  97:155 */       this.slots[(this.offset++ % this.slots.length)] = value;
/*  98:156 */       this.offset %= this.slots.length;
/*  99:    */     }
/* 100:    */     
/* 101:    */     public long avg()
/* 102:    */     {
/* 103:160 */       long sum = 0L;
/* 104:161 */       for (int i = 0; i < this.slots.length; i++) {
/* 105:162 */         sum += this.slots[i];
/* 106:    */       }
/* 107:164 */       return sum / this.slots.length;
/* 108:    */     }
/* 109:    */     
/* 110:    */     public void dampenForLowResTicker()
/* 111:    */     {
/* 112:168 */       if (avg() > 10000000L) {
/* 113:169 */         for (int i = 0; i < this.slots.length; i++)
/* 114:    */         {
/* 115:170 */           int tmp27_26 = i; long[] tmp27_23 = this.slots;tmp27_23[tmp27_26] = (((float)tmp27_23[tmp27_26] * 0.9F));
/* 116:    */         }
/* 117:    */       }
/* 118:    */     }
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.Sync
 * JD-Core Version:    0.7.0.1
 */