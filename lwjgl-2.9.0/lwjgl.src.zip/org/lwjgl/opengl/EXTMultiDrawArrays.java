/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class EXTMultiDrawArrays
/*  8:   */ {
/*  9:   */   public static void glMultiDrawArraysEXT(int mode, IntBuffer piFirst, IntBuffer piCount)
/* 10:   */   {
/* 11:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 12:14 */     long function_pointer = caps.glMultiDrawArraysEXT;
/* 13:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 14:16 */     BufferChecks.checkDirect(piFirst);
/* 15:17 */     BufferChecks.checkBuffer(piCount, piFirst.remaining());
/* 16:18 */     nglMultiDrawArraysEXT(mode, MemoryUtil.getAddress(piFirst), MemoryUtil.getAddress(piCount), piFirst.remaining(), function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nglMultiDrawArraysEXT(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 20:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTMultiDrawArrays
 * JD-Core Version:    0.7.0.1
 */