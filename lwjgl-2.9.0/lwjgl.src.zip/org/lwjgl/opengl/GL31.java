/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import java.nio.ShortBuffer;
/*   6:    */ import org.lwjgl.BufferChecks;
/*   7:    */ import org.lwjgl.MemoryUtil;
/*   8:    */ 
/*   9:    */ public final class GL31
/*  10:    */ {
/*  11:    */   public static final int GL_RED_SNORM = 36752;
/*  12:    */   public static final int GL_RG_SNORM = 36753;
/*  13:    */   public static final int GL_RGB_SNORM = 36754;
/*  14:    */   public static final int GL_RGBA_SNORM = 36755;
/*  15:    */   public static final int GL_R8_SNORM = 36756;
/*  16:    */   public static final int GL_RG8_SNORM = 36757;
/*  17:    */   public static final int GL_RGB8_SNORM = 36758;
/*  18:    */   public static final int GL_RGBA8_SNORM = 36759;
/*  19:    */   public static final int GL_R16_SNORM = 36760;
/*  20:    */   public static final int GL_RG16_SNORM = 36761;
/*  21:    */   public static final int GL_RGB16_SNORM = 36762;
/*  22:    */   public static final int GL_RGBA16_SNORM = 36763;
/*  23:    */   public static final int GL_SIGNED_NORMALIZED = 36764;
/*  24:    */   public static final int GL_COPY_READ_BUFFER_BINDING = 36662;
/*  25:    */   public static final int GL_COPY_WRITE_BUFFER_BINDING = 36663;
/*  26:    */   public static final int GL_COPY_READ_BUFFER = 36662;
/*  27:    */   public static final int GL_COPY_WRITE_BUFFER = 36663;
/*  28:    */   public static final int GL_PRIMITIVE_RESTART = 36765;
/*  29:    */   public static final int GL_PRIMITIVE_RESTART_INDEX = 36766;
/*  30:    */   public static final int GL_TEXTURE_BUFFER = 35882;
/*  31:    */   public static final int GL_MAX_TEXTURE_BUFFER_SIZE = 35883;
/*  32:    */   public static final int GL_TEXTURE_BINDING_BUFFER = 35884;
/*  33:    */   public static final int GL_TEXTURE_BUFFER_DATA_STORE_BINDING = 35885;
/*  34:    */   public static final int GL_TEXTURE_BUFFER_FORMAT = 35886;
/*  35:    */   public static final int GL_TEXTURE_RECTANGLE = 34037;
/*  36:    */   public static final int GL_TEXTURE_BINDING_RECTANGLE = 34038;
/*  37:    */   public static final int GL_PROXY_TEXTURE_RECTANGLE = 34039;
/*  38:    */   public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE = 34040;
/*  39:    */   public static final int GL_SAMPLER_2D_RECT = 35683;
/*  40:    */   public static final int GL_SAMPLER_2D_RECT_SHADOW = 35684;
/*  41:    */   public static final int GL_UNIFORM_BUFFER = 35345;
/*  42:    */   public static final int GL_UNIFORM_BUFFER_BINDING = 35368;
/*  43:    */   public static final int GL_UNIFORM_BUFFER_START = 35369;
/*  44:    */   public static final int GL_UNIFORM_BUFFER_SIZE = 35370;
/*  45:    */   public static final int GL_MAX_VERTEX_UNIFORM_BLOCKS = 35371;
/*  46:    */   public static final int GL_MAX_GEOMETRY_UNIFORM_BLOCKS = 35372;
/*  47:    */   public static final int GL_MAX_FRAGMENT_UNIFORM_BLOCKS = 35373;
/*  48:    */   public static final int GL_MAX_COMBINED_UNIFORM_BLOCKS = 35374;
/*  49:    */   public static final int GL_MAX_UNIFORM_BUFFER_BINDINGS = 35375;
/*  50:    */   public static final int GL_MAX_UNIFORM_BLOCK_SIZE = 35376;
/*  51:    */   public static final int GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS = 35377;
/*  52:    */   public static final int GL_MAX_COMBINED_GEOMETRY_UNIFORM_COMPONENTS = 35378;
/*  53:    */   public static final int GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS = 35379;
/*  54:    */   public static final int GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT = 35380;
/*  55:    */   public static final int GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH = 35381;
/*  56:    */   public static final int GL_ACTIVE_UNIFORM_BLOCKS = 35382;
/*  57:    */   public static final int GL_UNIFORM_TYPE = 35383;
/*  58:    */   public static final int GL_UNIFORM_SIZE = 35384;
/*  59:    */   public static final int GL_UNIFORM_NAME_LENGTH = 35385;
/*  60:    */   public static final int GL_UNIFORM_BLOCK_INDEX = 35386;
/*  61:    */   public static final int GL_UNIFORM_OFFSET = 35387;
/*  62:    */   public static final int GL_UNIFORM_ARRAY_STRIDE = 35388;
/*  63:    */   public static final int GL_UNIFORM_MATRIX_STRIDE = 35389;
/*  64:    */   public static final int GL_UNIFORM_IS_ROW_MAJOR = 35390;
/*  65:    */   public static final int GL_UNIFORM_BLOCK_BINDING = 35391;
/*  66:    */   public static final int GL_UNIFORM_BLOCK_DATA_SIZE = 35392;
/*  67:    */   public static final int GL_UNIFORM_BLOCK_NAME_LENGTH = 35393;
/*  68:    */   public static final int GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS = 35394;
/*  69:    */   public static final int GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES = 35395;
/*  70:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER = 35396;
/*  71:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_GEOMETRY_SHADER = 35397;
/*  72:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER = 35398;
/*  73:    */   public static final int GL_INVALID_INDEX = -1;
/*  74:    */   
/*  75:    */   public static void glDrawArraysInstanced(int mode, int first, int count, int primcount)
/*  76:    */   {
/*  77:173 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  78:174 */     long function_pointer = caps.glDrawArraysInstanced;
/*  79:175 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  80:176 */     nglDrawArraysInstanced(mode, first, count, primcount, function_pointer);
/*  81:    */   }
/*  82:    */   
/*  83:    */   static native void nglDrawArraysInstanced(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  84:    */   
/*  85:    */   public static void glDrawElementsInstanced(int mode, ByteBuffer indices, int primcount)
/*  86:    */   {
/*  87:181 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  88:182 */     long function_pointer = caps.glDrawElementsInstanced;
/*  89:183 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  90:184 */     GLChecks.ensureElementVBOdisabled(caps);
/*  91:185 */     BufferChecks.checkDirect(indices);
/*  92:186 */     nglDrawElementsInstanced(mode, indices.remaining(), 5121, MemoryUtil.getAddress(indices), primcount, function_pointer);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static void glDrawElementsInstanced(int mode, IntBuffer indices, int primcount)
/*  96:    */   {
/*  97:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98:190 */     long function_pointer = caps.glDrawElementsInstanced;
/*  99:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100:192 */     GLChecks.ensureElementVBOdisabled(caps);
/* 101:193 */     BufferChecks.checkDirect(indices);
/* 102:194 */     nglDrawElementsInstanced(mode, indices.remaining(), 5125, MemoryUtil.getAddress(indices), primcount, function_pointer);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static void glDrawElementsInstanced(int mode, ShortBuffer indices, int primcount)
/* 106:    */   {
/* 107:197 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 108:198 */     long function_pointer = caps.glDrawElementsInstanced;
/* 109:199 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 110:200 */     GLChecks.ensureElementVBOdisabled(caps);
/* 111:201 */     BufferChecks.checkDirect(indices);
/* 112:202 */     nglDrawElementsInstanced(mode, indices.remaining(), 5123, MemoryUtil.getAddress(indices), primcount, function_pointer);
/* 113:    */   }
/* 114:    */   
/* 115:    */   static native void nglDrawElementsInstanced(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 116:    */   
/* 117:    */   public static void glDrawElementsInstanced(int mode, int indices_count, int type, long indices_buffer_offset, int primcount)
/* 118:    */   {
/* 119:206 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 120:207 */     long function_pointer = caps.glDrawElementsInstanced;
/* 121:208 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 122:209 */     GLChecks.ensureElementVBOenabled(caps);
/* 123:210 */     nglDrawElementsInstancedBO(mode, indices_count, type, indices_buffer_offset, primcount, function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglDrawElementsInstancedBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 127:    */   
/* 128:    */   public static void glCopyBufferSubData(int readtarget, int writetarget, long readoffset, long writeoffset, long size)
/* 129:    */   {
/* 130:215 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:216 */     long function_pointer = caps.glCopyBufferSubData;
/* 132:217 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:218 */     nglCopyBufferSubData(readtarget, writetarget, readoffset, writeoffset, size, function_pointer);
/* 134:    */   }
/* 135:    */   
/* 136:    */   static native void nglCopyBufferSubData(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 137:    */   
/* 138:    */   public static void glPrimitiveRestartIndex(int index)
/* 139:    */   {
/* 140:223 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 141:224 */     long function_pointer = caps.glPrimitiveRestartIndex;
/* 142:225 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 143:226 */     nglPrimitiveRestartIndex(index, function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   static native void nglPrimitiveRestartIndex(int paramInt, long paramLong);
/* 147:    */   
/* 148:    */   public static void glTexBuffer(int target, int internalformat, int buffer)
/* 149:    */   {
/* 150:231 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 151:232 */     long function_pointer = caps.glTexBuffer;
/* 152:233 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 153:234 */     nglTexBuffer(target, internalformat, buffer, function_pointer);
/* 154:    */   }
/* 155:    */   
/* 156:    */   static native void nglTexBuffer(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 157:    */   
/* 158:    */   public static void glGetUniformIndices(int program, ByteBuffer uniformNames, IntBuffer uniformIndices)
/* 159:    */   {
/* 160:239 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:240 */     long function_pointer = caps.glGetUniformIndices;
/* 162:241 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:242 */     BufferChecks.checkDirect(uniformNames);
/* 164:243 */     BufferChecks.checkNullTerminated(uniformNames, uniformIndices.remaining());
/* 165:244 */     BufferChecks.checkDirect(uniformIndices);
/* 166:245 */     nglGetUniformIndices(program, uniformIndices.remaining(), MemoryUtil.getAddress(uniformNames), MemoryUtil.getAddress(uniformIndices), function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglGetUniformIndices(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 170:    */   
/* 171:    */   public static void glGetUniformIndices(int program, CharSequence[] uniformNames, IntBuffer uniformIndices)
/* 172:    */   {
/* 173:251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:252 */     long function_pointer = caps.glGetUniformIndices;
/* 175:253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:254 */     BufferChecks.checkArray(uniformNames);
/* 177:255 */     BufferChecks.checkBuffer(uniformIndices, uniformNames.length);
/* 178:256 */     nglGetUniformIndices(program, uniformNames.length, APIUtil.getBufferNT(caps, uniformNames), MemoryUtil.getAddress(uniformIndices), function_pointer);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static void glGetActiveUniforms(int program, IntBuffer uniformIndices, int pname, IntBuffer params)
/* 182:    */   {
/* 183:260 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 184:261 */     long function_pointer = caps.glGetActiveUniformsiv;
/* 185:262 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 186:263 */     BufferChecks.checkDirect(uniformIndices);
/* 187:264 */     BufferChecks.checkBuffer(params, uniformIndices.remaining());
/* 188:265 */     nglGetActiveUniformsiv(program, uniformIndices.remaining(), MemoryUtil.getAddress(uniformIndices), pname, MemoryUtil.getAddress(params), function_pointer);
/* 189:    */   }
/* 190:    */   
/* 191:    */   static native void nglGetActiveUniformsiv(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2, long paramLong3);
/* 192:    */   
/* 193:    */   @Deprecated
/* 194:    */   public static int glGetActiveUniforms(int program, int uniformIndex, int pname)
/* 195:    */   {
/* 196:276 */     return glGetActiveUniformsi(program, uniformIndex, pname);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public static int glGetActiveUniformsi(int program, int uniformIndex, int pname)
/* 200:    */   {
/* 201:281 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 202:282 */     long function_pointer = caps.glGetActiveUniformsiv;
/* 203:283 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 204:284 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 205:285 */     nglGetActiveUniformsiv(program, 1, MemoryUtil.getAddress(params.put(1, uniformIndex), 1), pname, MemoryUtil.getAddress(params), function_pointer);
/* 206:286 */     return params.get(0);
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static void glGetActiveUniformName(int program, int uniformIndex, IntBuffer length, ByteBuffer uniformName)
/* 210:    */   {
/* 211:290 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 212:291 */     long function_pointer = caps.glGetActiveUniformName;
/* 213:292 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 214:293 */     if (length != null) {
/* 215:294 */       BufferChecks.checkBuffer(length, 1);
/* 216:    */     }
/* 217:295 */     BufferChecks.checkDirect(uniformName);
/* 218:296 */     nglGetActiveUniformName(program, uniformIndex, uniformName.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(uniformName), function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglGetActiveUniformName(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/* 222:    */   
/* 223:    */   public static String glGetActiveUniformName(int program, int uniformIndex, int bufSize)
/* 224:    */   {
/* 225:302 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:303 */     long function_pointer = caps.glGetActiveUniformName;
/* 227:304 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:305 */     IntBuffer uniformName_length = APIUtil.getLengths(caps);
/* 229:306 */     ByteBuffer uniformName = APIUtil.getBufferByte(caps, bufSize);
/* 230:307 */     nglGetActiveUniformName(program, uniformIndex, bufSize, MemoryUtil.getAddress0(uniformName_length), MemoryUtil.getAddress(uniformName), function_pointer);
/* 231:308 */     uniformName.limit(uniformName_length.get(0));
/* 232:309 */     return APIUtil.getString(caps, uniformName);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static int glGetUniformBlockIndex(int program, ByteBuffer uniformBlockName)
/* 236:    */   {
/* 237:313 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 238:314 */     long function_pointer = caps.glGetUniformBlockIndex;
/* 239:315 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 240:316 */     BufferChecks.checkDirect(uniformBlockName);
/* 241:317 */     BufferChecks.checkNullTerminated(uniformBlockName);
/* 242:318 */     int __result = nglGetUniformBlockIndex(program, MemoryUtil.getAddress(uniformBlockName), function_pointer);
/* 243:319 */     return __result;
/* 244:    */   }
/* 245:    */   
/* 246:    */   static native int nglGetUniformBlockIndex(int paramInt, long paramLong1, long paramLong2);
/* 247:    */   
/* 248:    */   public static int glGetUniformBlockIndex(int program, CharSequence uniformBlockName)
/* 249:    */   {
/* 250:325 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 251:326 */     long function_pointer = caps.glGetUniformBlockIndex;
/* 252:327 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 253:328 */     int __result = nglGetUniformBlockIndex(program, APIUtil.getBufferNT(caps, uniformBlockName), function_pointer);
/* 254:329 */     return __result;
/* 255:    */   }
/* 256:    */   
/* 257:    */   public static void glGetActiveUniformBlock(int program, int uniformBlockIndex, int pname, IntBuffer params)
/* 258:    */   {
/* 259:333 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 260:334 */     long function_pointer = caps.glGetActiveUniformBlockiv;
/* 261:335 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 262:336 */     BufferChecks.checkBuffer(params, 16);
/* 263:337 */     nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, MemoryUtil.getAddress(params), function_pointer);
/* 264:    */   }
/* 265:    */   
/* 266:    */   static native void nglGetActiveUniformBlockiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 267:    */   
/* 268:    */   @Deprecated
/* 269:    */   public static int glGetActiveUniformBlock(int program, int uniformBlockIndex, int pname)
/* 270:    */   {
/* 271:348 */     return glGetActiveUniformBlocki(program, uniformBlockIndex, pname);
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static int glGetActiveUniformBlocki(int program, int uniformBlockIndex, int pname)
/* 275:    */   {
/* 276:353 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 277:354 */     long function_pointer = caps.glGetActiveUniformBlockiv;
/* 278:355 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 279:356 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 280:357 */     nglGetActiveUniformBlockiv(program, uniformBlockIndex, pname, MemoryUtil.getAddress(params), function_pointer);
/* 281:358 */     return params.get(0);
/* 282:    */   }
/* 283:    */   
/* 284:    */   public static void glGetActiveUniformBlockName(int program, int uniformBlockIndex, IntBuffer length, ByteBuffer uniformBlockName)
/* 285:    */   {
/* 286:362 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 287:363 */     long function_pointer = caps.glGetActiveUniformBlockName;
/* 288:364 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 289:365 */     if (length != null) {
/* 290:366 */       BufferChecks.checkBuffer(length, 1);
/* 291:    */     }
/* 292:367 */     BufferChecks.checkDirect(uniformBlockName);
/* 293:368 */     nglGetActiveUniformBlockName(program, uniformBlockIndex, uniformBlockName.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(uniformBlockName), function_pointer);
/* 294:    */   }
/* 295:    */   
/* 296:    */   static native void nglGetActiveUniformBlockName(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3);
/* 297:    */   
/* 298:    */   public static String glGetActiveUniformBlockName(int program, int uniformBlockIndex, int bufSize)
/* 299:    */   {
/* 300:374 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 301:375 */     long function_pointer = caps.glGetActiveUniformBlockName;
/* 302:376 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 303:377 */     IntBuffer uniformBlockName_length = APIUtil.getLengths(caps);
/* 304:378 */     ByteBuffer uniformBlockName = APIUtil.getBufferByte(caps, bufSize);
/* 305:379 */     nglGetActiveUniformBlockName(program, uniformBlockIndex, bufSize, MemoryUtil.getAddress0(uniformBlockName_length), MemoryUtil.getAddress(uniformBlockName), function_pointer);
/* 306:380 */     uniformBlockName.limit(uniformBlockName_length.get(0));
/* 307:381 */     return APIUtil.getString(caps, uniformBlockName);
/* 308:    */   }
/* 309:    */   
/* 310:    */   public static void glUniformBlockBinding(int program, int uniformBlockIndex, int uniformBlockBinding)
/* 311:    */   {
/* 312:385 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 313:386 */     long function_pointer = caps.glUniformBlockBinding;
/* 314:387 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 315:388 */     nglUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding, function_pointer);
/* 316:    */   }
/* 317:    */   
/* 318:    */   static native void nglUniformBlockBinding(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 319:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL31
 * JD-Core Version:    0.7.0.1
 */