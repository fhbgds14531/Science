/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerWrapperAbstract;
/*  4:   */ 
/*  5:   */ public abstract class CLEventCallback
/*  6:   */   extends PointerWrapperAbstract
/*  7:   */ {
/*  8:   */   private CLObjectRegistry<CLEvent> eventRegistry;
/*  9:   */   
/* 10:   */   protected CLEventCallback()
/* 11:   */   {
/* 12:48 */     super(CallbackUtil.getEventCallback());
/* 13:   */   }
/* 14:   */   
/* 15:   */   void setRegistry(CLObjectRegistry<CLEvent> eventRegistry)
/* 16:   */   {
/* 17:57 */     this.eventRegistry = eventRegistry;
/* 18:   */   }
/* 19:   */   
/* 20:   */   private void handleMessage(long event_address, int event_command_exec_status)
/* 21:   */   {
/* 22:66 */     handleMessage((CLEvent)this.eventRegistry.getObject(event_address), event_command_exec_status);
/* 23:   */   }
/* 24:   */   
/* 25:   */   protected abstract void handleMessage(CLEvent paramCLEvent, int paramInt);
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLEventCallback
 * JD-Core Version:    0.7.0.1
 */