/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ public final class PixelFormat
/*   4:    */   implements PixelFormatLWJGL
/*   5:    */ {
/*   6:    */   private int bpp;
/*   7:    */   private int alpha;
/*   8:    */   private int depth;
/*   9:    */   private int stencil;
/*  10:    */   private int samples;
/*  11:    */   private int colorSamples;
/*  12:    */   private int num_aux_buffers;
/*  13:    */   private int accum_bpp;
/*  14:    */   private int accum_alpha;
/*  15:    */   private boolean stereo;
/*  16:    */   private boolean floating_point;
/*  17:    */   private boolean floating_point_packed;
/*  18:    */   private boolean sRGB;
/*  19:    */   
/*  20:    */   public PixelFormat()
/*  21:    */   {
/*  22:102 */     this(0, 8, 0);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public PixelFormat(int alpha, int depth, int stencil)
/*  26:    */   {
/*  27:106 */     this(alpha, depth, stencil, 0);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public PixelFormat(int alpha, int depth, int stencil, int samples)
/*  31:    */   {
/*  32:110 */     this(0, alpha, depth, stencil, samples);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public PixelFormat(int bpp, int alpha, int depth, int stencil, int samples)
/*  36:    */   {
/*  37:114 */     this(bpp, alpha, depth, stencil, samples, 0, 0, 0, false);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public PixelFormat(int bpp, int alpha, int depth, int stencil, int samples, int num_aux_buffers, int accum_bpp, int accum_alpha, boolean stereo)
/*  41:    */   {
/*  42:118 */     this(bpp, alpha, depth, stencil, samples, num_aux_buffers, accum_bpp, accum_alpha, stereo, false);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public PixelFormat(int bpp, int alpha, int depth, int stencil, int samples, int num_aux_buffers, int accum_bpp, int accum_alpha, boolean stereo, boolean floating_point)
/*  46:    */   {
/*  47:122 */     this.bpp = bpp;
/*  48:123 */     this.alpha = alpha;
/*  49:124 */     this.depth = depth;
/*  50:125 */     this.stencil = stencil;
/*  51:    */     
/*  52:127 */     this.samples = samples;
/*  53:    */     
/*  54:129 */     this.num_aux_buffers = num_aux_buffers;
/*  55:    */     
/*  56:131 */     this.accum_bpp = accum_bpp;
/*  57:132 */     this.accum_alpha = accum_alpha;
/*  58:    */     
/*  59:134 */     this.stereo = stereo;
/*  60:    */     
/*  61:136 */     this.floating_point = floating_point;
/*  62:137 */     this.floating_point_packed = false;
/*  63:138 */     this.sRGB = false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   private PixelFormat(PixelFormat pf)
/*  67:    */   {
/*  68:142 */     this.bpp = pf.bpp;
/*  69:143 */     this.alpha = pf.alpha;
/*  70:144 */     this.depth = pf.depth;
/*  71:145 */     this.stencil = pf.stencil;
/*  72:    */     
/*  73:147 */     this.samples = pf.samples;
/*  74:148 */     this.colorSamples = pf.colorSamples;
/*  75:    */     
/*  76:150 */     this.num_aux_buffers = pf.num_aux_buffers;
/*  77:    */     
/*  78:152 */     this.accum_bpp = pf.accum_bpp;
/*  79:153 */     this.accum_alpha = pf.accum_alpha;
/*  80:    */     
/*  81:155 */     this.stereo = pf.stereo;
/*  82:    */     
/*  83:157 */     this.floating_point = pf.floating_point;
/*  84:158 */     this.floating_point_packed = pf.floating_point_packed;
/*  85:159 */     this.sRGB = pf.sRGB;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public int getBitsPerPixel()
/*  89:    */   {
/*  90:163 */     return this.bpp;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public PixelFormat withBitsPerPixel(int bpp)
/*  94:    */   {
/*  95:174 */     if (bpp < 0) {
/*  96:175 */       throw new IllegalArgumentException("Invalid number of bits per pixel specified: " + bpp);
/*  97:    */     }
/*  98:177 */     PixelFormat pf = new PixelFormat(this);
/*  99:178 */     pf.bpp = bpp;
/* 100:179 */     return pf;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public int getAlphaBits()
/* 104:    */   {
/* 105:183 */     return this.alpha;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public PixelFormat withAlphaBits(int alpha)
/* 109:    */   {
/* 110:194 */     if (alpha < 0) {
/* 111:195 */       throw new IllegalArgumentException("Invalid number of alpha bits specified: " + alpha);
/* 112:    */     }
/* 113:197 */     PixelFormat pf = new PixelFormat(this);
/* 114:198 */     pf.alpha = alpha;
/* 115:199 */     return pf;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public int getDepthBits()
/* 119:    */   {
/* 120:203 */     return this.depth;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public PixelFormat withDepthBits(int depth)
/* 124:    */   {
/* 125:214 */     if (depth < 0) {
/* 126:215 */       throw new IllegalArgumentException("Invalid number of depth bits specified: " + depth);
/* 127:    */     }
/* 128:217 */     PixelFormat pf = new PixelFormat(this);
/* 129:218 */     pf.depth = depth;
/* 130:219 */     return pf;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public int getStencilBits()
/* 134:    */   {
/* 135:223 */     return this.stencil;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public PixelFormat withStencilBits(int stencil)
/* 139:    */   {
/* 140:234 */     if (stencil < 0) {
/* 141:235 */       throw new IllegalArgumentException("Invalid number of stencil bits specified: " + stencil);
/* 142:    */     }
/* 143:237 */     PixelFormat pf = new PixelFormat(this);
/* 144:238 */     pf.stencil = stencil;
/* 145:239 */     return pf;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public int getSamples()
/* 149:    */   {
/* 150:243 */     return this.samples;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public PixelFormat withSamples(int samples)
/* 154:    */   {
/* 155:254 */     if (samples < 0) {
/* 156:255 */       throw new IllegalArgumentException("Invalid number of samples specified: " + samples);
/* 157:    */     }
/* 158:257 */     PixelFormat pf = new PixelFormat(this);
/* 159:258 */     pf.samples = samples;
/* 160:259 */     return pf;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public PixelFormat withCoverageSamples(int colorSamples)
/* 164:    */   {
/* 165:272 */     return withCoverageSamples(colorSamples, this.samples);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public PixelFormat withCoverageSamples(int colorSamples, int coverageSamples)
/* 169:    */   {
/* 170:285 */     if ((coverageSamples < 0) || (colorSamples < 0) || ((coverageSamples == 0) && (0 < colorSamples)) || (coverageSamples < colorSamples)) {
/* 171:286 */       throw new IllegalArgumentException("Invalid number of coverage samples specified: " + coverageSamples + " - " + colorSamples);
/* 172:    */     }
/* 173:288 */     PixelFormat pf = new PixelFormat(this);
/* 174:289 */     pf.samples = coverageSamples;
/* 175:290 */     pf.colorSamples = colorSamples;
/* 176:291 */     return pf;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public int getAuxBuffers()
/* 180:    */   {
/* 181:295 */     return this.num_aux_buffers;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public PixelFormat withAuxBuffers(int num_aux_buffers)
/* 185:    */   {
/* 186:306 */     if (num_aux_buffers < 0) {
/* 187:307 */       throw new IllegalArgumentException("Invalid number of auxiliary buffers specified: " + num_aux_buffers);
/* 188:    */     }
/* 189:309 */     PixelFormat pf = new PixelFormat(this);
/* 190:310 */     pf.num_aux_buffers = num_aux_buffers;
/* 191:311 */     return pf;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public int getAccumulationBitsPerPixel()
/* 195:    */   {
/* 196:315 */     return this.accum_bpp;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public PixelFormat withAccumulationBitsPerPixel(int accum_bpp)
/* 200:    */   {
/* 201:326 */     if (accum_bpp < 0) {
/* 202:327 */       throw new IllegalArgumentException("Invalid number of bits per pixel in the accumulation buffer specified: " + accum_bpp);
/* 203:    */     }
/* 204:329 */     PixelFormat pf = new PixelFormat(this);
/* 205:330 */     pf.accum_bpp = accum_bpp;
/* 206:331 */     return pf;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public int getAccumulationAlpha()
/* 210:    */   {
/* 211:335 */     return this.accum_alpha;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public PixelFormat withAccumulationAlpha(int accum_alpha)
/* 215:    */   {
/* 216:346 */     if (accum_alpha < 0) {
/* 217:347 */       throw new IllegalArgumentException("Invalid number of alpha bits in the accumulation buffer specified: " + accum_alpha);
/* 218:    */     }
/* 219:349 */     PixelFormat pf = new PixelFormat(this);
/* 220:350 */     pf.accum_alpha = accum_alpha;
/* 221:351 */     return pf;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public boolean isStereo()
/* 225:    */   {
/* 226:355 */     return this.stereo;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public PixelFormat withStereo(boolean stereo)
/* 230:    */   {
/* 231:366 */     PixelFormat pf = new PixelFormat(this);
/* 232:367 */     pf.stereo = stereo;
/* 233:368 */     return pf;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public boolean isFloatingPoint()
/* 237:    */   {
/* 238:372 */     return this.floating_point;
/* 239:    */   }
/* 240:    */   
/* 241:    */   public PixelFormat withFloatingPoint(boolean floating_point)
/* 242:    */   {
/* 243:384 */     PixelFormat pf = new PixelFormat(this);
/* 244:385 */     pf.floating_point = floating_point;
/* 245:386 */     if (floating_point) {
/* 246:387 */       pf.floating_point_packed = false;
/* 247:    */     }
/* 248:388 */     return pf;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public PixelFormat withFloatingPointPacked(boolean floating_point_packed)
/* 252:    */   {
/* 253:400 */     PixelFormat pf = new PixelFormat(this);
/* 254:401 */     pf.floating_point_packed = floating_point_packed;
/* 255:402 */     if (floating_point_packed) {
/* 256:403 */       pf.floating_point = false;
/* 257:    */     }
/* 258:404 */     return pf;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public boolean isSRGB()
/* 262:    */   {
/* 263:408 */     return this.sRGB;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public PixelFormat withSRGB(boolean sRGB)
/* 267:    */   {
/* 268:419 */     PixelFormat pf = new PixelFormat(this);
/* 269:420 */     pf.sRGB = sRGB;
/* 270:421 */     return pf;
/* 271:    */   }
/* 272:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.PixelFormat
 * JD-Core Version:    0.7.0.1
 */