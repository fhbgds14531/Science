/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTBlendEquationSeparate
/*  6:   */ {
/*  7:   */   public static final int GL_BLEND_EQUATION_RGB_EXT = 32777;
/*  8:   */   public static final int GL_BLEND_EQUATION_ALPHA_EXT = 34877;
/*  9:   */   
/* 10:   */   public static void glBlendEquationSeparateEXT(int modeRGB, int modeAlpha)
/* 11:   */   {
/* 12:20 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:21 */     long function_pointer = caps.glBlendEquationSeparateEXT;
/* 14:22 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:23 */     nglBlendEquationSeparateEXT(modeRGB, modeAlpha, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglBlendEquationSeparateEXT(int paramInt1, int paramInt2, long paramLong);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBlendEquationSeparate
 * JD-Core Version:    0.7.0.1
 */