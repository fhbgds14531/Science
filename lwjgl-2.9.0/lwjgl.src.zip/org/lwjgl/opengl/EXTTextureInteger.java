/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class EXTTextureInteger
/*   8:    */ {
/*   9:    */   public static final int GL_RGBA_INTEGER_MODE_EXT = 36254;
/*  10:    */   public static final int GL_RGBA32UI_EXT = 36208;
/*  11:    */   public static final int GL_RGB32UI_EXT = 36209;
/*  12:    */   public static final int GL_ALPHA32UI_EXT = 36210;
/*  13:    */   public static final int GL_INTENSITY32UI_EXT = 36211;
/*  14:    */   public static final int GL_LUMINANCE32UI_EXT = 36212;
/*  15:    */   public static final int GL_LUMINANCE_ALPHA32UI_EXT = 36213;
/*  16:    */   public static final int GL_RGBA16UI_EXT = 36214;
/*  17:    */   public static final int GL_RGB16UI_EXT = 36215;
/*  18:    */   public static final int GL_ALPHA16UI_EXT = 36216;
/*  19:    */   public static final int GL_INTENSITY16UI_EXT = 36217;
/*  20:    */   public static final int GL_LUMINANCE16UI_EXT = 36218;
/*  21:    */   public static final int GL_LUMINANCE_ALPHA16UI_EXT = 36219;
/*  22:    */   public static final int GL_RGBA8UI_EXT = 36220;
/*  23:    */   public static final int GL_RGB8UI_EXT = 36221;
/*  24:    */   public static final int GL_ALPHA8UI_EXT = 36222;
/*  25:    */   public static final int GL_INTENSITY8UI_EXT = 36223;
/*  26:    */   public static final int GL_LUMINANCE8UI_EXT = 36224;
/*  27:    */   public static final int GL_LUMINANCE_ALPHA8UI_EXT = 36225;
/*  28:    */   public static final int GL_RGBA32I_EXT = 36226;
/*  29:    */   public static final int GL_RGB32I_EXT = 36227;
/*  30:    */   public static final int GL_ALPHA32I_EXT = 36228;
/*  31:    */   public static final int GL_INTENSITY32I_EXT = 36229;
/*  32:    */   public static final int GL_LUMINANCE32I_EXT = 36230;
/*  33:    */   public static final int GL_LUMINANCE_ALPHA32I_EXT = 36231;
/*  34:    */   public static final int GL_RGBA16I_EXT = 36232;
/*  35:    */   public static final int GL_RGB16I_EXT = 36233;
/*  36:    */   public static final int GL_ALPHA16I_EXT = 36234;
/*  37:    */   public static final int GL_INTENSITY16I_EXT = 36235;
/*  38:    */   public static final int GL_LUMINANCE16I_EXT = 36236;
/*  39:    */   public static final int GL_LUMINANCE_ALPHA16I_EXT = 36237;
/*  40:    */   public static final int GL_RGBA8I_EXT = 36238;
/*  41:    */   public static final int GL_RGB8I_EXT = 36239;
/*  42:    */   public static final int GL_ALPHA8I_EXT = 36240;
/*  43:    */   public static final int GL_INTENSITY8I_EXT = 36241;
/*  44:    */   public static final int GL_LUMINANCE8I_EXT = 36242;
/*  45:    */   public static final int GL_LUMINANCE_ALPHA8I_EXT = 36243;
/*  46:    */   public static final int GL_RED_INTEGER_EXT = 36244;
/*  47:    */   public static final int GL_GREEN_INTEGER_EXT = 36245;
/*  48:    */   public static final int GL_BLUE_INTEGER_EXT = 36246;
/*  49:    */   public static final int GL_ALPHA_INTEGER_EXT = 36247;
/*  50:    */   public static final int GL_RGB_INTEGER_EXT = 36248;
/*  51:    */   public static final int GL_RGBA_INTEGER_EXT = 36249;
/*  52:    */   public static final int GL_BGR_INTEGER_EXT = 36250;
/*  53:    */   public static final int GL_BGRA_INTEGER_EXT = 36251;
/*  54:    */   public static final int GL_LUMINANCE_INTEGER_EXT = 36252;
/*  55:    */   public static final int GL_LUMINANCE_ALPHA_INTEGER_EXT = 36253;
/*  56:    */   
/*  57:    */   public static void glClearColorIiEXT(int r, int g, int b, int a)
/*  58:    */   {
/*  59: 76 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 77 */     long function_pointer = caps.glClearColorIiEXT;
/*  61: 78 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 79 */     nglClearColorIiEXT(r, g, b, a, function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   static native void nglClearColorIiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  66:    */   
/*  67:    */   public static void glClearColorIuiEXT(int r, int g, int b, int a)
/*  68:    */   {
/*  69: 84 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  70: 85 */     long function_pointer = caps.glClearColorIuiEXT;
/*  71: 86 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  72: 87 */     nglClearColorIuiEXT(r, g, b, a, function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   static native void nglClearColorIuiEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  76:    */   
/*  77:    */   public static void glTexParameterIEXT(int target, int pname, IntBuffer params)
/*  78:    */   {
/*  79: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  80: 93 */     long function_pointer = caps.glTexParameterIivEXT;
/*  81: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  82: 95 */     BufferChecks.checkBuffer(params, 4);
/*  83: 96 */     nglTexParameterIivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native void nglTexParameterIivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  87:    */   
/*  88:    */   public static void glTexParameterIiEXT(int target, int pname, int param)
/*  89:    */   {
/*  90:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91:103 */     long function_pointer = caps.glTexParameterIivEXT;
/*  92:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93:105 */     nglTexParameterIivEXT(target, pname, APIUtil.getInt(caps, param), function_pointer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static void glTexParameterIuEXT(int target, int pname, IntBuffer params)
/*  97:    */   {
/*  98:109 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  99:110 */     long function_pointer = caps.glTexParameterIuivEXT;
/* 100:111 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101:112 */     BufferChecks.checkBuffer(params, 4);
/* 102:113 */     nglTexParameterIuivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 103:    */   }
/* 104:    */   
/* 105:    */   static native void nglTexParameterIuivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 106:    */   
/* 107:    */   public static void glTexParameterIuiEXT(int target, int pname, int param)
/* 108:    */   {
/* 109:119 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110:120 */     long function_pointer = caps.glTexParameterIuivEXT;
/* 111:121 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:122 */     nglTexParameterIuivEXT(target, pname, APIUtil.getInt(caps, param), function_pointer);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static void glGetTexParameterIEXT(int target, int pname, IntBuffer params)
/* 116:    */   {
/* 117:126 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 118:127 */     long function_pointer = caps.glGetTexParameterIivEXT;
/* 119:128 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 120:129 */     BufferChecks.checkBuffer(params, 4);
/* 121:130 */     nglGetTexParameterIivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 122:    */   }
/* 123:    */   
/* 124:    */   static native void nglGetTexParameterIivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 125:    */   
/* 126:    */   public static int glGetTexParameterIiEXT(int target, int pname)
/* 127:    */   {
/* 128:136 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 129:137 */     long function_pointer = caps.glGetTexParameterIivEXT;
/* 130:138 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 131:139 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 132:140 */     nglGetTexParameterIivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 133:141 */     return params.get(0);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static void glGetTexParameterIuEXT(int target, int pname, IntBuffer params)
/* 137:    */   {
/* 138:145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:146 */     long function_pointer = caps.glGetTexParameterIuivEXT;
/* 140:147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:148 */     BufferChecks.checkBuffer(params, 4);
/* 142:149 */     nglGetTexParameterIuivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 143:    */   }
/* 144:    */   
/* 145:    */   static native void nglGetTexParameterIuivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 146:    */   
/* 147:    */   public static int glGetTexParameterIuiEXT(int target, int pname)
/* 148:    */   {
/* 149:155 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:156 */     long function_pointer = caps.glGetTexParameterIuivEXT;
/* 151:157 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:158 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 153:159 */     nglGetTexParameterIuivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 154:160 */     return params.get(0);
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureInteger
 * JD-Core Version:    0.7.0.1
 */