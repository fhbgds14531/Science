/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBInvalidateSubdata
/*  6:   */ {
/*  7:   */   public static void glInvalidateTexSubImage(int texture, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth)
/*  8:   */   {
/*  9:13 */     GL43.glInvalidateTexSubImage(texture, level, xoffset, yoffset, zoffset, width, height, depth);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static void glInvalidateTexImage(int texture, int level)
/* 13:   */   {
/* 14:17 */     GL43.glInvalidateTexImage(texture, level);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static void glInvalidateBufferSubData(int buffer, long offset, long length)
/* 18:   */   {
/* 19:21 */     GL43.glInvalidateBufferSubData(buffer, offset, length);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static void glInvalidateBufferData(int buffer)
/* 23:   */   {
/* 24:25 */     GL43.glInvalidateBufferData(buffer);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static void glInvalidateFramebuffer(int target, IntBuffer attachments)
/* 28:   */   {
/* 29:29 */     GL43.glInvalidateFramebuffer(target, attachments);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static void glInvalidateSubFramebuffer(int target, IntBuffer attachments, int x, int y, int width, int height)
/* 33:   */   {
/* 34:33 */     GL43.glInvalidateSubFramebuffer(target, attachments, x, y, width, height);
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBInvalidateSubdata
 * JD-Core Version:    0.7.0.1
 */