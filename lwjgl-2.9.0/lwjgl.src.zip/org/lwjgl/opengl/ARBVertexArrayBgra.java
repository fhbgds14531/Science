package org.lwjgl.opengl;

public final class ARBVertexArrayBgra
{
  public static final int GL_BGRA = 32993;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexArrayBgra
 * JD-Core Version:    0.7.0.1
 */