/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.Buffer;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import org.lwjgl.opencl.api.CLBufferRegion;
/*   7:    */ import org.lwjgl.opencl.api.CLImageFormat;
/*   8:    */ 
/*   9:    */ public final class CLMem
/*  10:    */   extends CLObjectChild<CLContext>
/*  11:    */ {
/*  12: 48 */   private static final CLMemUtil util = (CLMemUtil)CLPlatform.getInfoUtilInstance(CLMem.class, "CL_MEM_UTIL");
/*  13:    */   
/*  14:    */   CLMem(long pointer, CLContext context)
/*  15:    */   {
/*  16: 51 */     super(pointer, context);
/*  17: 52 */     if (isValid()) {
/*  18: 53 */       context.getCLMemRegistry().registerObject(this);
/*  19:    */     }
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static CLMem createImage2D(CLContext context, long flags, CLImageFormat image_format, long image_width, long image_height, long image_row_pitch, Buffer host_ptr, IntBuffer errcode_ret)
/*  23:    */   {
/*  24: 75 */     return util.createImage2D(context, flags, image_format, image_width, image_height, image_row_pitch, host_ptr, errcode_ret);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static CLMem createImage3D(CLContext context, long flags, CLImageFormat image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, Buffer host_ptr, IntBuffer errcode_ret)
/*  28:    */   {
/*  29: 97 */     return util.createImage3D(context, flags, image_format, image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, host_ptr, errcode_ret);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public CLMem createSubBuffer(long flags, int buffer_create_type, CLBufferRegion buffer_create_info, IntBuffer errcode_ret)
/*  33:    */   {
/*  34:101 */     return util.createSubBuffer(this, flags, buffer_create_type, buffer_create_info, errcode_ret);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int getInfoInt(int param_name)
/*  38:    */   {
/*  39:112 */     return util.getInfoInt(this, param_name);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public long getInfoSize(int param_name)
/*  43:    */   {
/*  44:123 */     return util.getInfoSize(this, param_name);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public long getInfoLong(int param_name)
/*  48:    */   {
/*  49:135 */     return util.getInfoLong(this, param_name);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ByteBuffer getInfoHostBuffer()
/*  53:    */   {
/*  54:146 */     return util.getInfoHostBuffer(this);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public long getImageInfoSize(int param_name)
/*  58:    */   {
/*  59:159 */     return util.getImageInfoSize(this, param_name);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public CLImageFormat getImageFormat()
/*  63:    */   {
/*  64:168 */     return util.getImageInfoFormat(this);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getImageChannelOrder()
/*  68:    */   {
/*  69:177 */     return util.getImageInfoFormat(this, 0);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public int getImageChannelType()
/*  73:    */   {
/*  74:186 */     return util.getImageInfoFormat(this, 1);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public int getGLObjectType()
/*  78:    */   {
/*  79:198 */     return util.getGLObjectType(this);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public int getGLObjectName()
/*  83:    */   {
/*  84:208 */     return util.getGLObjectName(this);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public int getGLTextureInfoInt(int param_name)
/*  88:    */   {
/*  89:222 */     return util.getGLTextureInfoInt(this, param_name);
/*  90:    */   }
/*  91:    */   
/*  92:    */   static CLMem create(long pointer, CLContext context)
/*  93:    */   {
/*  94:261 */     CLMem clMem = (CLMem)context.getCLMemRegistry().getObject(pointer);
/*  95:262 */     if (clMem == null) {
/*  96:263 */       clMem = new CLMem(pointer, context);
/*  97:    */     } else {
/*  98:265 */       clMem.retain();
/*  99:    */     }
/* 100:267 */     return clMem;
/* 101:    */   }
/* 102:    */   
/* 103:    */   int release()
/* 104:    */   {
/* 105:    */     try
/* 106:    */     {
/* 107:272 */       return super.release();
/* 108:    */     }
/* 109:    */     finally
/* 110:    */     {
/* 111:274 */       if (!isValid()) {
/* 112:275 */         ((CLContext)getParent()).getCLMemRegistry().unregisterObject(this);
/* 113:    */       }
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   static abstract interface CLMemUtil
/* 118:    */     extends InfoUtil<CLMem>
/* 119:    */   {
/* 120:    */     public abstract CLMem createImage2D(CLContext paramCLContext, long paramLong1, CLImageFormat paramCLImageFormat, long paramLong2, long paramLong3, long paramLong4, Buffer paramBuffer, IntBuffer paramIntBuffer);
/* 121:    */     
/* 122:    */     public abstract CLMem createImage3D(CLContext paramCLContext, long paramLong1, CLImageFormat paramCLImageFormat, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, Buffer paramBuffer, IntBuffer paramIntBuffer);
/* 123:    */     
/* 124:    */     public abstract CLMem createSubBuffer(CLMem paramCLMem, long paramLong, int paramInt, CLBufferRegion paramCLBufferRegion, IntBuffer paramIntBuffer);
/* 125:    */     
/* 126:    */     public abstract ByteBuffer getInfoHostBuffer(CLMem paramCLMem);
/* 127:    */     
/* 128:    */     public abstract long getImageInfoSize(CLMem paramCLMem, int paramInt);
/* 129:    */     
/* 130:    */     public abstract CLImageFormat getImageInfoFormat(CLMem paramCLMem);
/* 131:    */     
/* 132:    */     public abstract int getImageInfoFormat(CLMem paramCLMem, int paramInt);
/* 133:    */     
/* 134:    */     public abstract int getGLObjectType(CLMem paramCLMem);
/* 135:    */     
/* 136:    */     public abstract int getGLObjectName(CLMem paramCLMem);
/* 137:    */     
/* 138:    */     public abstract int getGLTextureInfoInt(CLMem paramCLMem, int paramInt);
/* 139:    */   }
/* 140:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLMem
 * JD-Core Version:    0.7.0.1
 */