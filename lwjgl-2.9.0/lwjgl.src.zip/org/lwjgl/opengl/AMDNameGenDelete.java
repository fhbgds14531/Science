/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class AMDNameGenDelete
/*  8:   */ {
/*  9:   */   public static final int GL_DATA_BUFFER_AMD = 37201;
/* 10:   */   public static final int GL_PERFORMANCE_MONITOR_AMD = 37202;
/* 11:   */   public static final int GL_QUERY_OBJECT_AMD = 37203;
/* 12:   */   public static final int GL_VERTEX_ARRAY_OBJECT_AMD = 37204;
/* 13:   */   public static final int GL_SAMPLER_OBJECT_AMD = 37205;
/* 14:   */   
/* 15:   */   public static void glGenNamesAMD(int identifier, IntBuffer names)
/* 16:   */   {
/* 17:22 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 18:23 */     long function_pointer = caps.glGenNamesAMD;
/* 19:24 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 20:25 */     BufferChecks.checkDirect(names);
/* 21:26 */     nglGenNamesAMD(identifier, names.remaining(), MemoryUtil.getAddress(names), function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   static native void nglGenNamesAMD(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 25:   */   
/* 26:   */   public static int glGenNamesAMD(int identifier)
/* 27:   */   {
/* 28:32 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 29:33 */     long function_pointer = caps.glGenNamesAMD;
/* 30:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 31:35 */     IntBuffer names = APIUtil.getBufferInt(caps);
/* 32:36 */     nglGenNamesAMD(identifier, 1, MemoryUtil.getAddress(names), function_pointer);
/* 33:37 */     return names.get(0);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static void glDeleteNamesAMD(int identifier, IntBuffer names)
/* 37:   */   {
/* 38:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 39:42 */     long function_pointer = caps.glDeleteNamesAMD;
/* 40:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 41:44 */     BufferChecks.checkDirect(names);
/* 42:45 */     nglDeleteNamesAMD(identifier, names.remaining(), MemoryUtil.getAddress(names), function_pointer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   static native void nglDeleteNamesAMD(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 46:   */   
/* 47:   */   public static void glDeleteNamesAMD(int identifier, int name)
/* 48:   */   {
/* 49:51 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 50:52 */     long function_pointer = caps.glDeleteNamesAMD;
/* 51:53 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 52:54 */     nglDeleteNamesAMD(identifier, 1, APIUtil.getInt(caps, name), function_pointer);
/* 53:   */   }
/* 54:   */   
/* 55:   */   public static boolean glIsNameAMD(int identifier, int name)
/* 56:   */   {
/* 57:58 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 58:59 */     long function_pointer = caps.glIsNameAMD;
/* 59:60 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 60:61 */     boolean __result = nglIsNameAMD(identifier, name, function_pointer);
/* 61:62 */     return __result;
/* 62:   */   }
/* 63:   */   
/* 64:   */   static native boolean nglIsNameAMD(int paramInt1, int paramInt2, long paramLong);
/* 65:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDNameGenDelete
 * JD-Core Version:    0.7.0.1
 */