/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.Buffer;
/*  4:   */ import java.nio.ByteBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class APPLETextureRange
/*  9:   */ {
/* 10:   */   public static final int GL_TEXTURE_STORAGE_HINT_APPLE = 34236;
/* 11:   */   public static final int GL_STORAGE_PRIVATE_APPLE = 34237;
/* 12:   */   public static final int GL_STORAGE_CACHED_APPLE = 34238;
/* 13:   */   public static final int GL_STORAGE_SHARED_APPLE = 34239;
/* 14:   */   public static final int GL_TEXTURE_RANGE_LENGTH_APPLE = 34231;
/* 15:   */   public static final int GL_TEXTURE_RANGE_POINTER_APPLE = 34232;
/* 16:   */   
/* 17:   */   public static void glTextureRangeAPPLE(int target, ByteBuffer pointer)
/* 18:   */   {
/* 19:39 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:40 */     long function_pointer = caps.glTextureRangeAPPLE;
/* 21:41 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:42 */     BufferChecks.checkDirect(pointer);
/* 23:43 */     nglTextureRangeAPPLE(target, pointer.remaining(), MemoryUtil.getAddress(pointer), function_pointer);
/* 24:   */   }
/* 25:   */   
/* 26:   */   static native void nglTextureRangeAPPLE(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 27:   */   
/* 28:   */   public static Buffer glGetTexParameterPointervAPPLE(int target, int pname, long result_size)
/* 29:   */   {
/* 30:48 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 31:49 */     long function_pointer = caps.glGetTexParameterPointervAPPLE;
/* 32:50 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 33:51 */     Buffer __result = nglGetTexParameterPointervAPPLE(target, pname, result_size, function_pointer);
/* 34:52 */     return __result;
/* 35:   */   }
/* 36:   */   
/* 37:   */   static native Buffer nglGetTexParameterPointervAPPLE(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 38:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLETextureRange
 * JD-Core Version:    0.7.0.1
 */