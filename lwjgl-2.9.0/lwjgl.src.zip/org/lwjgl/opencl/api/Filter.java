package org.lwjgl.opencl.api;

public abstract interface Filter<T>
{
  public abstract boolean accept(T paramT);
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.api.Filter
 * JD-Core Version:    0.7.0.1
 */