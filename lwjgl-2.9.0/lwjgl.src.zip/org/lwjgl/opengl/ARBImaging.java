/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.DoubleBuffer;
/*    5:     */ import java.nio.FloatBuffer;
/*    6:     */ import java.nio.IntBuffer;
/*    7:     */ import java.nio.ShortBuffer;
/*    8:     */ import org.lwjgl.BufferChecks;
/*    9:     */ import org.lwjgl.MemoryUtil;
/*   10:     */ 
/*   11:     */ public final class ARBImaging
/*   12:     */ {
/*   13:     */   public static final int GL_CONSTANT_COLOR = 32769;
/*   14:     */   public static final int GL_ONE_MINUS_CONSTANT_COLOR = 32770;
/*   15:     */   public static final int GL_CONSTANT_ALPHA = 32771;
/*   16:     */   public static final int GL_ONE_MINUS_CONSTANT_ALPHA = 32772;
/*   17:     */   public static final int GL_BLEND_COLOR = 32773;
/*   18:     */   public static final int GL_FUNC_ADD = 32774;
/*   19:     */   public static final int GL_MIN = 32775;
/*   20:     */   public static final int GL_MAX = 32776;
/*   21:     */   public static final int GL_BLEND_EQUATION = 32777;
/*   22:     */   public static final int GL_FUNC_SUBTRACT = 32778;
/*   23:     */   public static final int GL_FUNC_REVERSE_SUBTRACT = 32779;
/*   24:     */   public static final int GL_COLOR_MATRIX = 32945;
/*   25:     */   public static final int GL_COLOR_MATRIX_STACK_DEPTH = 32946;
/*   26:     */   public static final int GL_MAX_COLOR_MATRIX_STACK_DEPTH = 32947;
/*   27:     */   public static final int GL_POST_COLOR_MATRIX_RED_SCALE = 32948;
/*   28:     */   public static final int GL_POST_COLOR_MATRIX_GREEN_SCALE = 32949;
/*   29:     */   public static final int GL_POST_COLOR_MATRIX_BLUE_SCALE = 32950;
/*   30:     */   public static final int GL_POST_COLOR_MATRIX_ALPHA_SCALE = 32951;
/*   31:     */   public static final int GL_POST_COLOR_MATRIX_RED_BIAS = 32952;
/*   32:     */   public static final int GL_POST_COLOR_MATRIX_GREEN_BIAS = 32953;
/*   33:     */   public static final int GL_POST_COLOR_MATRIX_BLUE_BIAS = 32954;
/*   34:     */   public static final int GL_POST_COLOR_MATRIX_ALPHA_BIAS = 32955;
/*   35:     */   public static final int GL_COLOR_TABLE = 32976;
/*   36:     */   public static final int GL_POST_CONVOLUTION_COLOR_TABLE = 32977;
/*   37:     */   public static final int GL_POST_COLOR_MATRIX_COLOR_TABLE = 32978;
/*   38:     */   public static final int GL_PROXY_COLOR_TABLE = 32979;
/*   39:     */   public static final int GL_PROXY_POST_CONVOLUTION_COLOR_TABLE = 32980;
/*   40:     */   public static final int GL_PROXY_POST_COLOR_MATRIX_COLOR_TABLE = 32981;
/*   41:     */   public static final int GL_COLOR_TABLE_SCALE = 32982;
/*   42:     */   public static final int GL_COLOR_TABLE_BIAS = 32983;
/*   43:     */   public static final int GL_COLOR_TABLE_FORMAT = 32984;
/*   44:     */   public static final int GL_COLOR_TABLE_WIDTH = 32985;
/*   45:     */   public static final int GL_COLOR_TABLE_RED_SIZE = 32986;
/*   46:     */   public static final int GL_COLOR_TABLE_GREEN_SIZE = 32987;
/*   47:     */   public static final int GL_COLOR_TABLE_BLUE_SIZE = 32988;
/*   48:     */   public static final int GL_COLOR_TABLE_ALPHA_SIZE = 32989;
/*   49:     */   public static final int GL_COLOR_TABLE_LUMINANCE_SIZE = 32990;
/*   50:     */   public static final int GL_COLOR_TABLE_INTENSITY_SIZE = 32991;
/*   51:     */   public static final int GL_CONVOLUTION_1D = 32784;
/*   52:     */   public static final int GL_CONVOLUTION_2D = 32785;
/*   53:     */   public static final int GL_SEPARABLE_2D = 32786;
/*   54:     */   public static final int GL_CONVOLUTION_BORDER_MODE = 32787;
/*   55:     */   public static final int GL_CONVOLUTION_FILTER_SCALE = 32788;
/*   56:     */   public static final int GL_CONVOLUTION_FILTER_BIAS = 32789;
/*   57:     */   public static final int GL_REDUCE = 32790;
/*   58:     */   public static final int GL_CONVOLUTION_FORMAT = 32791;
/*   59:     */   public static final int GL_CONVOLUTION_WIDTH = 32792;
/*   60:     */   public static final int GL_CONVOLUTION_HEIGHT = 32793;
/*   61:     */   public static final int GL_MAX_CONVOLUTION_WIDTH = 32794;
/*   62:     */   public static final int GL_MAX_CONVOLUTION_HEIGHT = 32795;
/*   63:     */   public static final int GL_POST_CONVOLUTION_RED_SCALE = 32796;
/*   64:     */   public static final int GL_POST_CONVOLUTION_GREEN_SCALE = 32797;
/*   65:     */   public static final int GL_POST_CONVOLUTION_BLUE_SCALE = 32798;
/*   66:     */   public static final int GL_POST_CONVOLUTION_ALPHA_SCALE = 32799;
/*   67:     */   public static final int GL_POST_CONVOLUTION_RED_BIAS = 32800;
/*   68:     */   public static final int GL_POST_CONVOLUTION_GREEN_BIAS = 32801;
/*   69:     */   public static final int GL_POST_CONVOLUTION_BLUE_BIAS = 32802;
/*   70:     */   public static final int GL_POST_CONVOLUTION_ALPHA_BIAS = 32803;
/*   71:     */   public static final int GL_IGNORE_BORDER = 33104;
/*   72:     */   public static final int GL_CONSTANT_BORDER = 33105;
/*   73:     */   public static final int GL_REPLICATE_BORDER = 33107;
/*   74:     */   public static final int GL_CONVOLUTION_BORDER_COLOR = 33108;
/*   75:     */   public static final int GL_HISTOGRAM = 32804;
/*   76:     */   public static final int GL_PROXY_HISTOGRAM = 32805;
/*   77:     */   public static final int GL_HISTOGRAM_WIDTH = 32806;
/*   78:     */   public static final int GL_HISTOGRAM_FORMAT = 32807;
/*   79:     */   public static final int GL_HISTOGRAM_RED_SIZE = 32808;
/*   80:     */   public static final int GL_HISTOGRAM_GREEN_SIZE = 32809;
/*   81:     */   public static final int GL_HISTOGRAM_BLUE_SIZE = 32810;
/*   82:     */   public static final int GL_HISTOGRAM_ALPHA_SIZE = 32811;
/*   83:     */   public static final int GL_HISTOGRAM_LUMINANCE_SIZE = 32812;
/*   84:     */   public static final int GL_HISTOGRAM_SINK = 32813;
/*   85:     */   public static final int GL_MINMAX = 32814;
/*   86:     */   public static final int GL_MINMAX_FORMAT = 32815;
/*   87:     */   public static final int GL_MINMAX_SINK = 32816;
/*   88:     */   public static final int GL_TABLE_TOO_LARGE = 32817;
/*   89:     */   
/*   90:     */   public static void glColorTable(int target, int internalFormat, int width, int format, int type, ByteBuffer data)
/*   91:     */   {
/*   92:  98 */     ContextCapabilities caps = GLContext.getCapabilities();
/*   93:  99 */     long function_pointer = caps.glColorTable;
/*   94: 100 */     BufferChecks.checkFunctionAddress(function_pointer);
/*   95: 101 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*   96: 102 */     BufferChecks.checkBuffer(data, 256);
/*   97: 103 */     nglColorTable(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*   98:     */   }
/*   99:     */   
/*  100:     */   public static void glColorTable(int target, int internalFormat, int width, int format, int type, DoubleBuffer data)
/*  101:     */   {
/*  102: 106 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  103: 107 */     long function_pointer = caps.glColorTable;
/*  104: 108 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  105: 109 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  106: 110 */     BufferChecks.checkBuffer(data, 256);
/*  107: 111 */     nglColorTable(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  108:     */   }
/*  109:     */   
/*  110:     */   public static void glColorTable(int target, int internalFormat, int width, int format, int type, FloatBuffer data)
/*  111:     */   {
/*  112: 114 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  113: 115 */     long function_pointer = caps.glColorTable;
/*  114: 116 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  115: 117 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  116: 118 */     BufferChecks.checkBuffer(data, 256);
/*  117: 119 */     nglColorTable(target, internalFormat, width, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  118:     */   }
/*  119:     */   
/*  120:     */   static native void nglColorTable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  121:     */   
/*  122:     */   public static void glColorTable(int target, int internalFormat, int width, int format, int type, long data_buffer_offset)
/*  123:     */   {
/*  124: 123 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  125: 124 */     long function_pointer = caps.glColorTable;
/*  126: 125 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  127: 126 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  128: 127 */     nglColorTableBO(target, internalFormat, width, format, type, data_buffer_offset, function_pointer);
/*  129:     */   }
/*  130:     */   
/*  131:     */   static native void nglColorTableBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  132:     */   
/*  133:     */   public static void glColorSubTable(int target, int start, int count, int format, int type, ByteBuffer data)
/*  134:     */   {
/*  135: 132 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  136: 133 */     long function_pointer = caps.glColorSubTable;
/*  137: 134 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  138: 135 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  139: 136 */     BufferChecks.checkBuffer(data, 256);
/*  140: 137 */     nglColorSubTable(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  141:     */   }
/*  142:     */   
/*  143:     */   public static void glColorSubTable(int target, int start, int count, int format, int type, DoubleBuffer data)
/*  144:     */   {
/*  145: 140 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  146: 141 */     long function_pointer = caps.glColorSubTable;
/*  147: 142 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  148: 143 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  149: 144 */     BufferChecks.checkBuffer(data, 256);
/*  150: 145 */     nglColorSubTable(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  151:     */   }
/*  152:     */   
/*  153:     */   public static void glColorSubTable(int target, int start, int count, int format, int type, FloatBuffer data)
/*  154:     */   {
/*  155: 148 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  156: 149 */     long function_pointer = caps.glColorSubTable;
/*  157: 150 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  158: 151 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  159: 152 */     BufferChecks.checkBuffer(data, 256);
/*  160: 153 */     nglColorSubTable(target, start, count, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  161:     */   }
/*  162:     */   
/*  163:     */   static native void nglColorSubTable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  164:     */   
/*  165:     */   public static void glColorSubTable(int target, int start, int count, int format, int type, long data_buffer_offset)
/*  166:     */   {
/*  167: 157 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  168: 158 */     long function_pointer = caps.glColorSubTable;
/*  169: 159 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  170: 160 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  171: 161 */     nglColorSubTableBO(target, start, count, format, type, data_buffer_offset, function_pointer);
/*  172:     */   }
/*  173:     */   
/*  174:     */   static native void nglColorSubTableBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  175:     */   
/*  176:     */   public static void glColorTableParameter(int target, int pname, IntBuffer params)
/*  177:     */   {
/*  178: 166 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  179: 167 */     long function_pointer = caps.glColorTableParameteriv;
/*  180: 168 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  181: 169 */     BufferChecks.checkBuffer(params, 4);
/*  182: 170 */     nglColorTableParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  183:     */   }
/*  184:     */   
/*  185:     */   static native void nglColorTableParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  186:     */   
/*  187:     */   public static void glColorTableParameter(int target, int pname, FloatBuffer params)
/*  188:     */   {
/*  189: 175 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  190: 176 */     long function_pointer = caps.glColorTableParameterfv;
/*  191: 177 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  192: 178 */     BufferChecks.checkBuffer(params, 4);
/*  193: 179 */     nglColorTableParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  194:     */   }
/*  195:     */   
/*  196:     */   static native void nglColorTableParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  197:     */   
/*  198:     */   public static void glCopyColorSubTable(int target, int start, int x, int y, int width)
/*  199:     */   {
/*  200: 184 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  201: 185 */     long function_pointer = caps.glCopyColorSubTable;
/*  202: 186 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  203: 187 */     nglCopyColorSubTable(target, start, x, y, width, function_pointer);
/*  204:     */   }
/*  205:     */   
/*  206:     */   static native void nglCopyColorSubTable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  207:     */   
/*  208:     */   public static void glCopyColorTable(int target, int internalformat, int x, int y, int width)
/*  209:     */   {
/*  210: 192 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  211: 193 */     long function_pointer = caps.glCopyColorTable;
/*  212: 194 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  213: 195 */     nglCopyColorTable(target, internalformat, x, y, width, function_pointer);
/*  214:     */   }
/*  215:     */   
/*  216:     */   static native void nglCopyColorTable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  217:     */   
/*  218:     */   public static void glGetColorTable(int target, int format, int type, ByteBuffer data)
/*  219:     */   {
/*  220: 200 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  221: 201 */     long function_pointer = caps.glGetColorTable;
/*  222: 202 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  223: 203 */     BufferChecks.checkBuffer(data, 256);
/*  224: 204 */     nglGetColorTable(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  225:     */   }
/*  226:     */   
/*  227:     */   public static void glGetColorTable(int target, int format, int type, DoubleBuffer data)
/*  228:     */   {
/*  229: 207 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  230: 208 */     long function_pointer = caps.glGetColorTable;
/*  231: 209 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  232: 210 */     BufferChecks.checkBuffer(data, 256);
/*  233: 211 */     nglGetColorTable(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  234:     */   }
/*  235:     */   
/*  236:     */   public static void glGetColorTable(int target, int format, int type, FloatBuffer data)
/*  237:     */   {
/*  238: 214 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  239: 215 */     long function_pointer = caps.glGetColorTable;
/*  240: 216 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  241: 217 */     BufferChecks.checkBuffer(data, 256);
/*  242: 218 */     nglGetColorTable(target, format, type, MemoryUtil.getAddress(data), function_pointer);
/*  243:     */   }
/*  244:     */   
/*  245:     */   static native void nglGetColorTable(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  246:     */   
/*  247:     */   public static void glGetColorTableParameter(int target, int pname, IntBuffer params)
/*  248:     */   {
/*  249: 223 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  250: 224 */     long function_pointer = caps.glGetColorTableParameteriv;
/*  251: 225 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  252: 226 */     BufferChecks.checkBuffer(params, 4);
/*  253: 227 */     nglGetColorTableParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  254:     */   }
/*  255:     */   
/*  256:     */   static native void nglGetColorTableParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  257:     */   
/*  258:     */   public static void glGetColorTableParameter(int target, int pname, FloatBuffer params)
/*  259:     */   {
/*  260: 232 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  261: 233 */     long function_pointer = caps.glGetColorTableParameterfv;
/*  262: 234 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  263: 235 */     BufferChecks.checkBuffer(params, 4);
/*  264: 236 */     nglGetColorTableParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  265:     */   }
/*  266:     */   
/*  267:     */   static native void nglGetColorTableParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  268:     */   
/*  269:     */   public static void glBlendEquation(int mode)
/*  270:     */   {
/*  271: 241 */     GL14.glBlendEquation(mode);
/*  272:     */   }
/*  273:     */   
/*  274:     */   public static void glBlendColor(float red, float green, float blue, float alpha)
/*  275:     */   {
/*  276: 245 */     GL14.glBlendColor(red, green, blue, alpha);
/*  277:     */   }
/*  278:     */   
/*  279:     */   public static void glHistogram(int target, int width, int internalformat, boolean sink)
/*  280:     */   {
/*  281: 249 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  282: 250 */     long function_pointer = caps.glHistogram;
/*  283: 251 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  284: 252 */     nglHistogram(target, width, internalformat, sink, function_pointer);
/*  285:     */   }
/*  286:     */   
/*  287:     */   static native void nglHistogram(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, long paramLong);
/*  288:     */   
/*  289:     */   public static void glResetHistogram(int target)
/*  290:     */   {
/*  291: 257 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  292: 258 */     long function_pointer = caps.glResetHistogram;
/*  293: 259 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  294: 260 */     nglResetHistogram(target, function_pointer);
/*  295:     */   }
/*  296:     */   
/*  297:     */   static native void nglResetHistogram(int paramInt, long paramLong);
/*  298:     */   
/*  299:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, ByteBuffer values)
/*  300:     */   {
/*  301: 265 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  302: 266 */     long function_pointer = caps.glGetHistogram;
/*  303: 267 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  304: 268 */     GLChecks.ensurePackPBOdisabled(caps);
/*  305: 269 */     BufferChecks.checkBuffer(values, 256);
/*  306: 270 */     nglGetHistogram(target, reset, format, type, MemoryUtil.getAddress(values), function_pointer);
/*  307:     */   }
/*  308:     */   
/*  309:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, DoubleBuffer values)
/*  310:     */   {
/*  311: 273 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  312: 274 */     long function_pointer = caps.glGetHistogram;
/*  313: 275 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  314: 276 */     GLChecks.ensurePackPBOdisabled(caps);
/*  315: 277 */     BufferChecks.checkBuffer(values, 256);
/*  316: 278 */     nglGetHistogram(target, reset, format, type, MemoryUtil.getAddress(values), function_pointer);
/*  317:     */   }
/*  318:     */   
/*  319:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, FloatBuffer values)
/*  320:     */   {
/*  321: 281 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  322: 282 */     long function_pointer = caps.glGetHistogram;
/*  323: 283 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  324: 284 */     GLChecks.ensurePackPBOdisabled(caps);
/*  325: 285 */     BufferChecks.checkBuffer(values, 256);
/*  326: 286 */     nglGetHistogram(target, reset, format, type, MemoryUtil.getAddress(values), function_pointer);
/*  327:     */   }
/*  328:     */   
/*  329:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, IntBuffer values)
/*  330:     */   {
/*  331: 289 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  332: 290 */     long function_pointer = caps.glGetHistogram;
/*  333: 291 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  334: 292 */     GLChecks.ensurePackPBOdisabled(caps);
/*  335: 293 */     BufferChecks.checkBuffer(values, 256);
/*  336: 294 */     nglGetHistogram(target, reset, format, type, MemoryUtil.getAddress(values), function_pointer);
/*  337:     */   }
/*  338:     */   
/*  339:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, ShortBuffer values)
/*  340:     */   {
/*  341: 297 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  342: 298 */     long function_pointer = caps.glGetHistogram;
/*  343: 299 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  344: 300 */     GLChecks.ensurePackPBOdisabled(caps);
/*  345: 301 */     BufferChecks.checkBuffer(values, 256);
/*  346: 302 */     nglGetHistogram(target, reset, format, type, MemoryUtil.getAddress(values), function_pointer);
/*  347:     */   }
/*  348:     */   
/*  349:     */   static native void nglGetHistogram(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  350:     */   
/*  351:     */   public static void glGetHistogram(int target, boolean reset, int format, int type, long values_buffer_offset)
/*  352:     */   {
/*  353: 306 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  354: 307 */     long function_pointer = caps.glGetHistogram;
/*  355: 308 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  356: 309 */     GLChecks.ensurePackPBOenabled(caps);
/*  357: 310 */     nglGetHistogramBO(target, reset, format, type, values_buffer_offset, function_pointer);
/*  358:     */   }
/*  359:     */   
/*  360:     */   static native void nglGetHistogramBO(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  361:     */   
/*  362:     */   public static void glGetHistogramParameter(int target, int pname, FloatBuffer params)
/*  363:     */   {
/*  364: 315 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  365: 316 */     long function_pointer = caps.glGetHistogramParameterfv;
/*  366: 317 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  367: 318 */     BufferChecks.checkBuffer(params, 256);
/*  368: 319 */     nglGetHistogramParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  369:     */   }
/*  370:     */   
/*  371:     */   static native void nglGetHistogramParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  372:     */   
/*  373:     */   public static void glGetHistogramParameter(int target, int pname, IntBuffer params)
/*  374:     */   {
/*  375: 324 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  376: 325 */     long function_pointer = caps.glGetHistogramParameteriv;
/*  377: 326 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  378: 327 */     BufferChecks.checkBuffer(params, 256);
/*  379: 328 */     nglGetHistogramParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  380:     */   }
/*  381:     */   
/*  382:     */   static native void nglGetHistogramParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  383:     */   
/*  384:     */   public static void glMinmax(int target, int internalformat, boolean sink)
/*  385:     */   {
/*  386: 333 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  387: 334 */     long function_pointer = caps.glMinmax;
/*  388: 335 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  389: 336 */     nglMinmax(target, internalformat, sink, function_pointer);
/*  390:     */   }
/*  391:     */   
/*  392:     */   static native void nglMinmax(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong);
/*  393:     */   
/*  394:     */   public static void glResetMinmax(int target)
/*  395:     */   {
/*  396: 341 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  397: 342 */     long function_pointer = caps.glResetMinmax;
/*  398: 343 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  399: 344 */     nglResetMinmax(target, function_pointer);
/*  400:     */   }
/*  401:     */   
/*  402:     */   static native void nglResetMinmax(int paramInt, long paramLong);
/*  403:     */   
/*  404:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, ByteBuffer values)
/*  405:     */   {
/*  406: 349 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  407: 350 */     long function_pointer = caps.glGetMinmax;
/*  408: 351 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  409: 352 */     GLChecks.ensurePackPBOdisabled(caps);
/*  410: 353 */     BufferChecks.checkBuffer(values, 4);
/*  411: 354 */     nglGetMinmax(target, reset, format, types, MemoryUtil.getAddress(values), function_pointer);
/*  412:     */   }
/*  413:     */   
/*  414:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, DoubleBuffer values)
/*  415:     */   {
/*  416: 357 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  417: 358 */     long function_pointer = caps.glGetMinmax;
/*  418: 359 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  419: 360 */     GLChecks.ensurePackPBOdisabled(caps);
/*  420: 361 */     BufferChecks.checkBuffer(values, 4);
/*  421: 362 */     nglGetMinmax(target, reset, format, types, MemoryUtil.getAddress(values), function_pointer);
/*  422:     */   }
/*  423:     */   
/*  424:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, FloatBuffer values)
/*  425:     */   {
/*  426: 365 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  427: 366 */     long function_pointer = caps.glGetMinmax;
/*  428: 367 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  429: 368 */     GLChecks.ensurePackPBOdisabled(caps);
/*  430: 369 */     BufferChecks.checkBuffer(values, 4);
/*  431: 370 */     nglGetMinmax(target, reset, format, types, MemoryUtil.getAddress(values), function_pointer);
/*  432:     */   }
/*  433:     */   
/*  434:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, IntBuffer values)
/*  435:     */   {
/*  436: 373 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  437: 374 */     long function_pointer = caps.glGetMinmax;
/*  438: 375 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  439: 376 */     GLChecks.ensurePackPBOdisabled(caps);
/*  440: 377 */     BufferChecks.checkBuffer(values, 4);
/*  441: 378 */     nglGetMinmax(target, reset, format, types, MemoryUtil.getAddress(values), function_pointer);
/*  442:     */   }
/*  443:     */   
/*  444:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, ShortBuffer values)
/*  445:     */   {
/*  446: 381 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  447: 382 */     long function_pointer = caps.glGetMinmax;
/*  448: 383 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  449: 384 */     GLChecks.ensurePackPBOdisabled(caps);
/*  450: 385 */     BufferChecks.checkBuffer(values, 4);
/*  451: 386 */     nglGetMinmax(target, reset, format, types, MemoryUtil.getAddress(values), function_pointer);
/*  452:     */   }
/*  453:     */   
/*  454:     */   static native void nglGetMinmax(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  455:     */   
/*  456:     */   public static void glGetMinmax(int target, boolean reset, int format, int types, long values_buffer_offset)
/*  457:     */   {
/*  458: 390 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  459: 391 */     long function_pointer = caps.glGetMinmax;
/*  460: 392 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  461: 393 */     GLChecks.ensurePackPBOenabled(caps);
/*  462: 394 */     nglGetMinmaxBO(target, reset, format, types, values_buffer_offset, function_pointer);
/*  463:     */   }
/*  464:     */   
/*  465:     */   static native void nglGetMinmaxBO(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  466:     */   
/*  467:     */   public static void glGetMinmaxParameter(int target, int pname, FloatBuffer params)
/*  468:     */   {
/*  469: 399 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  470: 400 */     long function_pointer = caps.glGetMinmaxParameterfv;
/*  471: 401 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  472: 402 */     BufferChecks.checkBuffer(params, 4);
/*  473: 403 */     nglGetMinmaxParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  474:     */   }
/*  475:     */   
/*  476:     */   static native void nglGetMinmaxParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  477:     */   
/*  478:     */   public static void glGetMinmaxParameter(int target, int pname, IntBuffer params)
/*  479:     */   {
/*  480: 408 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  481: 409 */     long function_pointer = caps.glGetMinmaxParameteriv;
/*  482: 410 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  483: 411 */     BufferChecks.checkBuffer(params, 4);
/*  484: 412 */     nglGetMinmaxParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  485:     */   }
/*  486:     */   
/*  487:     */   static native void nglGetMinmaxParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  488:     */   
/*  489:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, ByteBuffer image)
/*  490:     */   {
/*  491: 417 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  492: 418 */     long function_pointer = caps.glConvolutionFilter1D;
/*  493: 419 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  494: 420 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  495: 421 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, 1, 1));
/*  496: 422 */     nglConvolutionFilter1D(target, internalformat, width, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  497:     */   }
/*  498:     */   
/*  499:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, DoubleBuffer image)
/*  500:     */   {
/*  501: 425 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  502: 426 */     long function_pointer = caps.glConvolutionFilter1D;
/*  503: 427 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  504: 428 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  505: 429 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, 1, 1));
/*  506: 430 */     nglConvolutionFilter1D(target, internalformat, width, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  507:     */   }
/*  508:     */   
/*  509:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, FloatBuffer image)
/*  510:     */   {
/*  511: 433 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  512: 434 */     long function_pointer = caps.glConvolutionFilter1D;
/*  513: 435 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  514: 436 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  515: 437 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, 1, 1));
/*  516: 438 */     nglConvolutionFilter1D(target, internalformat, width, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  517:     */   }
/*  518:     */   
/*  519:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, IntBuffer image)
/*  520:     */   {
/*  521: 441 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  522: 442 */     long function_pointer = caps.glConvolutionFilter1D;
/*  523: 443 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  524: 444 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  525: 445 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, 1, 1));
/*  526: 446 */     nglConvolutionFilter1D(target, internalformat, width, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  527:     */   }
/*  528:     */   
/*  529:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, ShortBuffer image)
/*  530:     */   {
/*  531: 449 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  532: 450 */     long function_pointer = caps.glConvolutionFilter1D;
/*  533: 451 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  534: 452 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  535: 453 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, 1, 1));
/*  536: 454 */     nglConvolutionFilter1D(target, internalformat, width, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  537:     */   }
/*  538:     */   
/*  539:     */   static native void nglConvolutionFilter1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  540:     */   
/*  541:     */   public static void glConvolutionFilter1D(int target, int internalformat, int width, int format, int type, long image_buffer_offset)
/*  542:     */   {
/*  543: 458 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  544: 459 */     long function_pointer = caps.glConvolutionFilter1D;
/*  545: 460 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  546: 461 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  547: 462 */     nglConvolutionFilter1DBO(target, internalformat, width, format, type, image_buffer_offset, function_pointer);
/*  548:     */   }
/*  549:     */   
/*  550:     */   static native void nglConvolutionFilter1DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  551:     */   
/*  552:     */   public static void glConvolutionFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer image)
/*  553:     */   {
/*  554: 467 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  555: 468 */     long function_pointer = caps.glConvolutionFilter2D;
/*  556: 469 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  557: 470 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  558: 471 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, height, 1));
/*  559: 472 */     nglConvolutionFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  560:     */   }
/*  561:     */   
/*  562:     */   public static void glConvolutionFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer image)
/*  563:     */   {
/*  564: 475 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  565: 476 */     long function_pointer = caps.glConvolutionFilter2D;
/*  566: 477 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  567: 478 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  568: 479 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, height, 1));
/*  569: 480 */     nglConvolutionFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  570:     */   }
/*  571:     */   
/*  572:     */   public static void glConvolutionFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer image)
/*  573:     */   {
/*  574: 483 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  575: 484 */     long function_pointer = caps.glConvolutionFilter2D;
/*  576: 485 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  577: 486 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  578: 487 */     BufferChecks.checkBuffer(image, GLChecks.calculateImageStorage(image, format, type, width, height, 1));
/*  579: 488 */     nglConvolutionFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  580:     */   }
/*  581:     */   
/*  582:     */   static native void nglConvolutionFilter2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/*  583:     */   
/*  584:     */   public static void glConvolutionFilter2D(int target, int internalformat, int width, int height, int format, int type, long image_buffer_offset)
/*  585:     */   {
/*  586: 492 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  587: 493 */     long function_pointer = caps.glConvolutionFilter2D;
/*  588: 494 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  589: 495 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  590: 496 */     nglConvolutionFilter2DBO(target, internalformat, width, height, format, type, image_buffer_offset, function_pointer);
/*  591:     */   }
/*  592:     */   
/*  593:     */   static native void nglConvolutionFilter2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/*  594:     */   
/*  595:     */   public static void glConvolutionParameterf(int target, int pname, float params)
/*  596:     */   {
/*  597: 501 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  598: 502 */     long function_pointer = caps.glConvolutionParameterf;
/*  599: 503 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  600: 504 */     nglConvolutionParameterf(target, pname, params, function_pointer);
/*  601:     */   }
/*  602:     */   
/*  603:     */   static native void nglConvolutionParameterf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/*  604:     */   
/*  605:     */   public static void glConvolutionParameter(int target, int pname, FloatBuffer params)
/*  606:     */   {
/*  607: 509 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  608: 510 */     long function_pointer = caps.glConvolutionParameterfv;
/*  609: 511 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  610: 512 */     BufferChecks.checkBuffer(params, 4);
/*  611: 513 */     nglConvolutionParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  612:     */   }
/*  613:     */   
/*  614:     */   static native void nglConvolutionParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  615:     */   
/*  616:     */   public static void glConvolutionParameteri(int target, int pname, int params)
/*  617:     */   {
/*  618: 518 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  619: 519 */     long function_pointer = caps.glConvolutionParameteri;
/*  620: 520 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  621: 521 */     nglConvolutionParameteri(target, pname, params, function_pointer);
/*  622:     */   }
/*  623:     */   
/*  624:     */   static native void nglConvolutionParameteri(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  625:     */   
/*  626:     */   public static void glConvolutionParameter(int target, int pname, IntBuffer params)
/*  627:     */   {
/*  628: 526 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  629: 527 */     long function_pointer = caps.glConvolutionParameteriv;
/*  630: 528 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  631: 529 */     BufferChecks.checkBuffer(params, 4);
/*  632: 530 */     nglConvolutionParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  633:     */   }
/*  634:     */   
/*  635:     */   static native void nglConvolutionParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  636:     */   
/*  637:     */   public static void glCopyConvolutionFilter1D(int target, int internalformat, int x, int y, int width)
/*  638:     */   {
/*  639: 535 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  640: 536 */     long function_pointer = caps.glCopyConvolutionFilter1D;
/*  641: 537 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  642: 538 */     nglCopyConvolutionFilter1D(target, internalformat, x, y, width, function_pointer);
/*  643:     */   }
/*  644:     */   
/*  645:     */   static native void nglCopyConvolutionFilter1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  646:     */   
/*  647:     */   public static void glCopyConvolutionFilter2D(int target, int internalformat, int x, int y, int width, int height)
/*  648:     */   {
/*  649: 543 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  650: 544 */     long function_pointer = caps.glCopyConvolutionFilter2D;
/*  651: 545 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  652: 546 */     nglCopyConvolutionFilter2D(target, internalformat, x, y, width, height, function_pointer);
/*  653:     */   }
/*  654:     */   
/*  655:     */   static native void nglCopyConvolutionFilter2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  656:     */   
/*  657:     */   public static void glGetConvolutionFilter(int target, int format, int type, ByteBuffer image)
/*  658:     */   {
/*  659: 551 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  660: 552 */     long function_pointer = caps.glGetConvolutionFilter;
/*  661: 553 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  662: 554 */     GLChecks.ensurePackPBOdisabled(caps);
/*  663: 555 */     BufferChecks.checkDirect(image);
/*  664: 556 */     nglGetConvolutionFilter(target, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  665:     */   }
/*  666:     */   
/*  667:     */   public static void glGetConvolutionFilter(int target, int format, int type, DoubleBuffer image)
/*  668:     */   {
/*  669: 559 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  670: 560 */     long function_pointer = caps.glGetConvolutionFilter;
/*  671: 561 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  672: 562 */     GLChecks.ensurePackPBOdisabled(caps);
/*  673: 563 */     BufferChecks.checkDirect(image);
/*  674: 564 */     nglGetConvolutionFilter(target, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  675:     */   }
/*  676:     */   
/*  677:     */   public static void glGetConvolutionFilter(int target, int format, int type, FloatBuffer image)
/*  678:     */   {
/*  679: 567 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  680: 568 */     long function_pointer = caps.glGetConvolutionFilter;
/*  681: 569 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  682: 570 */     GLChecks.ensurePackPBOdisabled(caps);
/*  683: 571 */     BufferChecks.checkDirect(image);
/*  684: 572 */     nglGetConvolutionFilter(target, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  685:     */   }
/*  686:     */   
/*  687:     */   public static void glGetConvolutionFilter(int target, int format, int type, IntBuffer image)
/*  688:     */   {
/*  689: 575 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  690: 576 */     long function_pointer = caps.glGetConvolutionFilter;
/*  691: 577 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  692: 578 */     GLChecks.ensurePackPBOdisabled(caps);
/*  693: 579 */     BufferChecks.checkDirect(image);
/*  694: 580 */     nglGetConvolutionFilter(target, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  695:     */   }
/*  696:     */   
/*  697:     */   public static void glGetConvolutionFilter(int target, int format, int type, ShortBuffer image)
/*  698:     */   {
/*  699: 583 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  700: 584 */     long function_pointer = caps.glGetConvolutionFilter;
/*  701: 585 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  702: 586 */     GLChecks.ensurePackPBOdisabled(caps);
/*  703: 587 */     BufferChecks.checkDirect(image);
/*  704: 588 */     nglGetConvolutionFilter(target, format, type, MemoryUtil.getAddress(image), function_pointer);
/*  705:     */   }
/*  706:     */   
/*  707:     */   static native void nglGetConvolutionFilter(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  708:     */   
/*  709:     */   public static void glGetConvolutionFilter(int target, int format, int type, long image_buffer_offset)
/*  710:     */   {
/*  711: 592 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  712: 593 */     long function_pointer = caps.glGetConvolutionFilter;
/*  713: 594 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  714: 595 */     GLChecks.ensurePackPBOenabled(caps);
/*  715: 596 */     nglGetConvolutionFilterBO(target, format, type, image_buffer_offset, function_pointer);
/*  716:     */   }
/*  717:     */   
/*  718:     */   static native void nglGetConvolutionFilterBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  719:     */   
/*  720:     */   public static void glGetConvolutionParameter(int target, int pname, FloatBuffer params)
/*  721:     */   {
/*  722: 601 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  723: 602 */     long function_pointer = caps.glGetConvolutionParameterfv;
/*  724: 603 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  725: 604 */     BufferChecks.checkBuffer(params, 4);
/*  726: 605 */     nglGetConvolutionParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  727:     */   }
/*  728:     */   
/*  729:     */   static native void nglGetConvolutionParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  730:     */   
/*  731:     */   public static void glGetConvolutionParameter(int target, int pname, IntBuffer params)
/*  732:     */   {
/*  733: 610 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  734: 611 */     long function_pointer = caps.glGetConvolutionParameteriv;
/*  735: 612 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  736: 613 */     BufferChecks.checkBuffer(params, 4);
/*  737: 614 */     nglGetConvolutionParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  738:     */   }
/*  739:     */   
/*  740:     */   static native void nglGetConvolutionParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  741:     */   
/*  742:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer row, ByteBuffer column)
/*  743:     */   {
/*  744: 619 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  745: 620 */     long function_pointer = caps.glSeparableFilter2D;
/*  746: 621 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  747: 622 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  748: 623 */     BufferChecks.checkDirect(row);
/*  749: 624 */     BufferChecks.checkDirect(column);
/*  750: 625 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  751:     */   }
/*  752:     */   
/*  753:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer row, DoubleBuffer column)
/*  754:     */   {
/*  755: 628 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  756: 629 */     long function_pointer = caps.glSeparableFilter2D;
/*  757: 630 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  758: 631 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  759: 632 */     BufferChecks.checkDirect(row);
/*  760: 633 */     BufferChecks.checkDirect(column);
/*  761: 634 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  762:     */   }
/*  763:     */   
/*  764:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer row, FloatBuffer column)
/*  765:     */   {
/*  766: 637 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  767: 638 */     long function_pointer = caps.glSeparableFilter2D;
/*  768: 639 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  769: 640 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  770: 641 */     BufferChecks.checkDirect(row);
/*  771: 642 */     BufferChecks.checkDirect(column);
/*  772: 643 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  773:     */   }
/*  774:     */   
/*  775:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer row, IntBuffer column)
/*  776:     */   {
/*  777: 646 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  778: 647 */     long function_pointer = caps.glSeparableFilter2D;
/*  779: 648 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  780: 649 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  781: 650 */     BufferChecks.checkDirect(row);
/*  782: 651 */     BufferChecks.checkDirect(column);
/*  783: 652 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  784:     */   }
/*  785:     */   
/*  786:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ByteBuffer row, ShortBuffer column)
/*  787:     */   {
/*  788: 655 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  789: 656 */     long function_pointer = caps.glSeparableFilter2D;
/*  790: 657 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  791: 658 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  792: 659 */     BufferChecks.checkDirect(row);
/*  793: 660 */     BufferChecks.checkDirect(column);
/*  794: 661 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  795:     */   }
/*  796:     */   
/*  797:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, DoubleBuffer row, ByteBuffer column)
/*  798:     */   {
/*  799: 664 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  800: 665 */     long function_pointer = caps.glSeparableFilter2D;
/*  801: 666 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  802: 667 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  803: 668 */     BufferChecks.checkDirect(row);
/*  804: 669 */     BufferChecks.checkDirect(column);
/*  805: 670 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  806:     */   }
/*  807:     */   
/*  808:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, DoubleBuffer row, DoubleBuffer column)
/*  809:     */   {
/*  810: 673 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  811: 674 */     long function_pointer = caps.glSeparableFilter2D;
/*  812: 675 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  813: 676 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  814: 677 */     BufferChecks.checkDirect(row);
/*  815: 678 */     BufferChecks.checkDirect(column);
/*  816: 679 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  817:     */   }
/*  818:     */   
/*  819:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, DoubleBuffer row, FloatBuffer column)
/*  820:     */   {
/*  821: 682 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  822: 683 */     long function_pointer = caps.glSeparableFilter2D;
/*  823: 684 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  824: 685 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  825: 686 */     BufferChecks.checkDirect(row);
/*  826: 687 */     BufferChecks.checkDirect(column);
/*  827: 688 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  828:     */   }
/*  829:     */   
/*  830:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, DoubleBuffer row, IntBuffer column)
/*  831:     */   {
/*  832: 691 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  833: 692 */     long function_pointer = caps.glSeparableFilter2D;
/*  834: 693 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  835: 694 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  836: 695 */     BufferChecks.checkDirect(row);
/*  837: 696 */     BufferChecks.checkDirect(column);
/*  838: 697 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  839:     */   }
/*  840:     */   
/*  841:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, DoubleBuffer row, ShortBuffer column)
/*  842:     */   {
/*  843: 700 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  844: 701 */     long function_pointer = caps.glSeparableFilter2D;
/*  845: 702 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  846: 703 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  847: 704 */     BufferChecks.checkDirect(row);
/*  848: 705 */     BufferChecks.checkDirect(column);
/*  849: 706 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  850:     */   }
/*  851:     */   
/*  852:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, FloatBuffer row, ByteBuffer column)
/*  853:     */   {
/*  854: 709 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  855: 710 */     long function_pointer = caps.glSeparableFilter2D;
/*  856: 711 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  857: 712 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  858: 713 */     BufferChecks.checkDirect(row);
/*  859: 714 */     BufferChecks.checkDirect(column);
/*  860: 715 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  861:     */   }
/*  862:     */   
/*  863:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, FloatBuffer row, DoubleBuffer column)
/*  864:     */   {
/*  865: 718 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  866: 719 */     long function_pointer = caps.glSeparableFilter2D;
/*  867: 720 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  868: 721 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  869: 722 */     BufferChecks.checkDirect(row);
/*  870: 723 */     BufferChecks.checkDirect(column);
/*  871: 724 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  872:     */   }
/*  873:     */   
/*  874:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, FloatBuffer row, FloatBuffer column)
/*  875:     */   {
/*  876: 727 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  877: 728 */     long function_pointer = caps.glSeparableFilter2D;
/*  878: 729 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  879: 730 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  880: 731 */     BufferChecks.checkDirect(row);
/*  881: 732 */     BufferChecks.checkDirect(column);
/*  882: 733 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  883:     */   }
/*  884:     */   
/*  885:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, FloatBuffer row, IntBuffer column)
/*  886:     */   {
/*  887: 736 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  888: 737 */     long function_pointer = caps.glSeparableFilter2D;
/*  889: 738 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  890: 739 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  891: 740 */     BufferChecks.checkDirect(row);
/*  892: 741 */     BufferChecks.checkDirect(column);
/*  893: 742 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  894:     */   }
/*  895:     */   
/*  896:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, FloatBuffer row, ShortBuffer column)
/*  897:     */   {
/*  898: 745 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  899: 746 */     long function_pointer = caps.glSeparableFilter2D;
/*  900: 747 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  901: 748 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  902: 749 */     BufferChecks.checkDirect(row);
/*  903: 750 */     BufferChecks.checkDirect(column);
/*  904: 751 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  905:     */   }
/*  906:     */   
/*  907:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer row, ByteBuffer column)
/*  908:     */   {
/*  909: 754 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  910: 755 */     long function_pointer = caps.glSeparableFilter2D;
/*  911: 756 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  912: 757 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  913: 758 */     BufferChecks.checkDirect(row);
/*  914: 759 */     BufferChecks.checkDirect(column);
/*  915: 760 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  916:     */   }
/*  917:     */   
/*  918:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer row, DoubleBuffer column)
/*  919:     */   {
/*  920: 763 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  921: 764 */     long function_pointer = caps.glSeparableFilter2D;
/*  922: 765 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  923: 766 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  924: 767 */     BufferChecks.checkDirect(row);
/*  925: 768 */     BufferChecks.checkDirect(column);
/*  926: 769 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  927:     */   }
/*  928:     */   
/*  929:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer row, FloatBuffer column)
/*  930:     */   {
/*  931: 772 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  932: 773 */     long function_pointer = caps.glSeparableFilter2D;
/*  933: 774 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  934: 775 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  935: 776 */     BufferChecks.checkDirect(row);
/*  936: 777 */     BufferChecks.checkDirect(column);
/*  937: 778 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  938:     */   }
/*  939:     */   
/*  940:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer row, IntBuffer column)
/*  941:     */   {
/*  942: 781 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  943: 782 */     long function_pointer = caps.glSeparableFilter2D;
/*  944: 783 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  945: 784 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  946: 785 */     BufferChecks.checkDirect(row);
/*  947: 786 */     BufferChecks.checkDirect(column);
/*  948: 787 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  949:     */   }
/*  950:     */   
/*  951:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, IntBuffer row, ShortBuffer column)
/*  952:     */   {
/*  953: 790 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  954: 791 */     long function_pointer = caps.glSeparableFilter2D;
/*  955: 792 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  956: 793 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  957: 794 */     BufferChecks.checkDirect(row);
/*  958: 795 */     BufferChecks.checkDirect(column);
/*  959: 796 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  960:     */   }
/*  961:     */   
/*  962:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer row, ByteBuffer column)
/*  963:     */   {
/*  964: 799 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  965: 800 */     long function_pointer = caps.glSeparableFilter2D;
/*  966: 801 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  967: 802 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  968: 803 */     BufferChecks.checkDirect(row);
/*  969: 804 */     BufferChecks.checkDirect(column);
/*  970: 805 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  971:     */   }
/*  972:     */   
/*  973:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer row, DoubleBuffer column)
/*  974:     */   {
/*  975: 808 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  976: 809 */     long function_pointer = caps.glSeparableFilter2D;
/*  977: 810 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  978: 811 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  979: 812 */     BufferChecks.checkDirect(row);
/*  980: 813 */     BufferChecks.checkDirect(column);
/*  981: 814 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  982:     */   }
/*  983:     */   
/*  984:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer row, FloatBuffer column)
/*  985:     */   {
/*  986: 817 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  987: 818 */     long function_pointer = caps.glSeparableFilter2D;
/*  988: 819 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  989: 820 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  990: 821 */     BufferChecks.checkDirect(row);
/*  991: 822 */     BufferChecks.checkDirect(column);
/*  992: 823 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/*  993:     */   }
/*  994:     */   
/*  995:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer row, IntBuffer column)
/*  996:     */   {
/*  997: 826 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  998: 827 */     long function_pointer = caps.glSeparableFilter2D;
/*  999: 828 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1000: 829 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1001: 830 */     BufferChecks.checkDirect(row);
/* 1002: 831 */     BufferChecks.checkDirect(column);
/* 1003: 832 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/* 1004:     */   }
/* 1005:     */   
/* 1006:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, ShortBuffer row, ShortBuffer column)
/* 1007:     */   {
/* 1008: 835 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1009: 836 */     long function_pointer = caps.glSeparableFilter2D;
/* 1010: 837 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1011: 838 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1012: 839 */     BufferChecks.checkDirect(row);
/* 1013: 840 */     BufferChecks.checkDirect(column);
/* 1014: 841 */     nglSeparableFilter2D(target, internalformat, width, height, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), function_pointer);
/* 1015:     */   }
/* 1016:     */   
/* 1017:     */   static native void nglSeparableFilter2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2, long paramLong3);
/* 1018:     */   
/* 1019:     */   public static void glSeparableFilter2D(int target, int internalformat, int width, int height, int format, int type, long row_buffer_offset, long column_buffer_offset)
/* 1020:     */   {
/* 1021: 845 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1022: 846 */     long function_pointer = caps.glSeparableFilter2D;
/* 1023: 847 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1024: 848 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1025: 849 */     nglSeparableFilter2DBO(target, internalformat, width, height, format, type, row_buffer_offset, column_buffer_offset, function_pointer);
/* 1026:     */   }
/* 1027:     */   
/* 1028:     */   static native void nglSeparableFilter2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2, long paramLong3);
/* 1029:     */   
/* 1030:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ByteBuffer column, ByteBuffer span)
/* 1031:     */   {
/* 1032: 854 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1033: 855 */     long function_pointer = caps.glGetSeparableFilter;
/* 1034: 856 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1035: 857 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1036: 858 */     BufferChecks.checkDirect(row);
/* 1037: 859 */     BufferChecks.checkDirect(column);
/* 1038: 860 */     BufferChecks.checkDirect(span);
/* 1039: 861 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1043:     */   {
/* 1044: 864 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1045: 865 */     long function_pointer = caps.glGetSeparableFilter;
/* 1046: 866 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1047: 867 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1048: 868 */     BufferChecks.checkDirect(row);
/* 1049: 869 */     BufferChecks.checkDirect(column);
/* 1050: 870 */     BufferChecks.checkDirect(span);
/* 1051: 871 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1052:     */   }
/* 1053:     */   
/* 1054:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ByteBuffer column, IntBuffer span)
/* 1055:     */   {
/* 1056: 874 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1057: 875 */     long function_pointer = caps.glGetSeparableFilter;
/* 1058: 876 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1059: 877 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1060: 878 */     BufferChecks.checkDirect(row);
/* 1061: 879 */     BufferChecks.checkDirect(column);
/* 1062: 880 */     BufferChecks.checkDirect(span);
/* 1063: 881 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1064:     */   }
/* 1065:     */   
/* 1066:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ByteBuffer column, ShortBuffer span)
/* 1067:     */   {
/* 1068: 884 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1069: 885 */     long function_pointer = caps.glGetSeparableFilter;
/* 1070: 886 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1071: 887 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1072: 888 */     BufferChecks.checkDirect(row);
/* 1073: 889 */     BufferChecks.checkDirect(column);
/* 1074: 890 */     BufferChecks.checkDirect(span);
/* 1075: 891 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1076:     */   }
/* 1077:     */   
/* 1078:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1079:     */   {
/* 1080: 894 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1081: 895 */     long function_pointer = caps.glGetSeparableFilter;
/* 1082: 896 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1083: 897 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1084: 898 */     BufferChecks.checkDirect(row);
/* 1085: 899 */     BufferChecks.checkDirect(column);
/* 1086: 900 */     BufferChecks.checkDirect(span);
/* 1087: 901 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1088:     */   }
/* 1089:     */   
/* 1090:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1091:     */   {
/* 1092: 904 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1093: 905 */     long function_pointer = caps.glGetSeparableFilter;
/* 1094: 906 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1095: 907 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1096: 908 */     BufferChecks.checkDirect(row);
/* 1097: 909 */     BufferChecks.checkDirect(column);
/* 1098: 910 */     BufferChecks.checkDirect(span);
/* 1099: 911 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, DoubleBuffer column, IntBuffer span)
/* 1103:     */   {
/* 1104: 914 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1105: 915 */     long function_pointer = caps.glGetSeparableFilter;
/* 1106: 916 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1107: 917 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1108: 918 */     BufferChecks.checkDirect(row);
/* 1109: 919 */     BufferChecks.checkDirect(column);
/* 1110: 920 */     BufferChecks.checkDirect(span);
/* 1111: 921 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1112:     */   }
/* 1113:     */   
/* 1114:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1115:     */   {
/* 1116: 924 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1117: 925 */     long function_pointer = caps.glGetSeparableFilter;
/* 1118: 926 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1119: 927 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1120: 928 */     BufferChecks.checkDirect(row);
/* 1121: 929 */     BufferChecks.checkDirect(column);
/* 1122: 930 */     BufferChecks.checkDirect(span);
/* 1123: 931 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1124:     */   }
/* 1125:     */   
/* 1126:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, IntBuffer column, ByteBuffer span)
/* 1127:     */   {
/* 1128: 934 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1129: 935 */     long function_pointer = caps.glGetSeparableFilter;
/* 1130: 936 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1131: 937 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1132: 938 */     BufferChecks.checkDirect(row);
/* 1133: 939 */     BufferChecks.checkDirect(column);
/* 1134: 940 */     BufferChecks.checkDirect(span);
/* 1135: 941 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1136:     */   }
/* 1137:     */   
/* 1138:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, IntBuffer column, DoubleBuffer span)
/* 1139:     */   {
/* 1140: 944 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1141: 945 */     long function_pointer = caps.glGetSeparableFilter;
/* 1142: 946 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1143: 947 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1144: 948 */     BufferChecks.checkDirect(row);
/* 1145: 949 */     BufferChecks.checkDirect(column);
/* 1146: 950 */     BufferChecks.checkDirect(span);
/* 1147: 951 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1148:     */   }
/* 1149:     */   
/* 1150:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, IntBuffer column, IntBuffer span)
/* 1151:     */   {
/* 1152: 954 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1153: 955 */     long function_pointer = caps.glGetSeparableFilter;
/* 1154: 956 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1155: 957 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1156: 958 */     BufferChecks.checkDirect(row);
/* 1157: 959 */     BufferChecks.checkDirect(column);
/* 1158: 960 */     BufferChecks.checkDirect(span);
/* 1159: 961 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1160:     */   }
/* 1161:     */   
/* 1162:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, IntBuffer column, ShortBuffer span)
/* 1163:     */   {
/* 1164: 964 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1165: 965 */     long function_pointer = caps.glGetSeparableFilter;
/* 1166: 966 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1167: 967 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1168: 968 */     BufferChecks.checkDirect(row);
/* 1169: 969 */     BufferChecks.checkDirect(column);
/* 1170: 970 */     BufferChecks.checkDirect(span);
/* 1171: 971 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1172:     */   }
/* 1173:     */   
/* 1174:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ShortBuffer column, ByteBuffer span)
/* 1175:     */   {
/* 1176: 974 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1177: 975 */     long function_pointer = caps.glGetSeparableFilter;
/* 1178: 976 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1179: 977 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1180: 978 */     BufferChecks.checkDirect(row);
/* 1181: 979 */     BufferChecks.checkDirect(column);
/* 1182: 980 */     BufferChecks.checkDirect(span);
/* 1183: 981 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1184:     */   }
/* 1185:     */   
/* 1186:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1187:     */   {
/* 1188: 984 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1189: 985 */     long function_pointer = caps.glGetSeparableFilter;
/* 1190: 986 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1191: 987 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1192: 988 */     BufferChecks.checkDirect(row);
/* 1193: 989 */     BufferChecks.checkDirect(column);
/* 1194: 990 */     BufferChecks.checkDirect(span);
/* 1195: 991 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1196:     */   }
/* 1197:     */   
/* 1198:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ShortBuffer column, IntBuffer span)
/* 1199:     */   {
/* 1200: 994 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1201: 995 */     long function_pointer = caps.glGetSeparableFilter;
/* 1202: 996 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1203: 997 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1204: 998 */     BufferChecks.checkDirect(row);
/* 1205: 999 */     BufferChecks.checkDirect(column);
/* 1206:1000 */     BufferChecks.checkDirect(span);
/* 1207:1001 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1208:     */   }
/* 1209:     */   
/* 1210:     */   public static void glGetSeparableFilter(int target, int format, int type, ByteBuffer row, ShortBuffer column, ShortBuffer span)
/* 1211:     */   {
/* 1212:1004 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1213:1005 */     long function_pointer = caps.glGetSeparableFilter;
/* 1214:1006 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1215:1007 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1216:1008 */     BufferChecks.checkDirect(row);
/* 1217:1009 */     BufferChecks.checkDirect(column);
/* 1218:1010 */     BufferChecks.checkDirect(span);
/* 1219:1011 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1220:     */   }
/* 1221:     */   
/* 1222:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ByteBuffer column, ByteBuffer span)
/* 1223:     */   {
/* 1224:1014 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1225:1015 */     long function_pointer = caps.glGetSeparableFilter;
/* 1226:1016 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1227:1017 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1228:1018 */     BufferChecks.checkDirect(row);
/* 1229:1019 */     BufferChecks.checkDirect(column);
/* 1230:1020 */     BufferChecks.checkDirect(span);
/* 1231:1021 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1232:     */   }
/* 1233:     */   
/* 1234:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1235:     */   {
/* 1236:1024 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1237:1025 */     long function_pointer = caps.glGetSeparableFilter;
/* 1238:1026 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1239:1027 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1240:1028 */     BufferChecks.checkDirect(row);
/* 1241:1029 */     BufferChecks.checkDirect(column);
/* 1242:1030 */     BufferChecks.checkDirect(span);
/* 1243:1031 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1244:     */   }
/* 1245:     */   
/* 1246:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ByteBuffer column, IntBuffer span)
/* 1247:     */   {
/* 1248:1034 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1249:1035 */     long function_pointer = caps.glGetSeparableFilter;
/* 1250:1036 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1251:1037 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1252:1038 */     BufferChecks.checkDirect(row);
/* 1253:1039 */     BufferChecks.checkDirect(column);
/* 1254:1040 */     BufferChecks.checkDirect(span);
/* 1255:1041 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1256:     */   }
/* 1257:     */   
/* 1258:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ByteBuffer column, ShortBuffer span)
/* 1259:     */   {
/* 1260:1044 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1261:1045 */     long function_pointer = caps.glGetSeparableFilter;
/* 1262:1046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1263:1047 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1264:1048 */     BufferChecks.checkDirect(row);
/* 1265:1049 */     BufferChecks.checkDirect(column);
/* 1266:1050 */     BufferChecks.checkDirect(span);
/* 1267:1051 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1268:     */   }
/* 1269:     */   
/* 1270:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1271:     */   {
/* 1272:1054 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1273:1055 */     long function_pointer = caps.glGetSeparableFilter;
/* 1274:1056 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1275:1057 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1276:1058 */     BufferChecks.checkDirect(row);
/* 1277:1059 */     BufferChecks.checkDirect(column);
/* 1278:1060 */     BufferChecks.checkDirect(span);
/* 1279:1061 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1280:     */   }
/* 1281:     */   
/* 1282:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1283:     */   {
/* 1284:1064 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1285:1065 */     long function_pointer = caps.glGetSeparableFilter;
/* 1286:1066 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1287:1067 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1288:1068 */     BufferChecks.checkDirect(row);
/* 1289:1069 */     BufferChecks.checkDirect(column);
/* 1290:1070 */     BufferChecks.checkDirect(span);
/* 1291:1071 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1292:     */   }
/* 1293:     */   
/* 1294:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, IntBuffer span)
/* 1295:     */   {
/* 1296:1074 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1297:1075 */     long function_pointer = caps.glGetSeparableFilter;
/* 1298:1076 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1299:1077 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1300:1078 */     BufferChecks.checkDirect(row);
/* 1301:1079 */     BufferChecks.checkDirect(column);
/* 1302:1080 */     BufferChecks.checkDirect(span);
/* 1303:1081 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1304:     */   }
/* 1305:     */   
/* 1306:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1307:     */   {
/* 1308:1084 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1309:1085 */     long function_pointer = caps.glGetSeparableFilter;
/* 1310:1086 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1311:1087 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1312:1088 */     BufferChecks.checkDirect(row);
/* 1313:1089 */     BufferChecks.checkDirect(column);
/* 1314:1090 */     BufferChecks.checkDirect(span);
/* 1315:1091 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1316:     */   }
/* 1317:     */   
/* 1318:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, IntBuffer column, ByteBuffer span)
/* 1319:     */   {
/* 1320:1094 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1321:1095 */     long function_pointer = caps.glGetSeparableFilter;
/* 1322:1096 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1323:1097 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1324:1098 */     BufferChecks.checkDirect(row);
/* 1325:1099 */     BufferChecks.checkDirect(column);
/* 1326:1100 */     BufferChecks.checkDirect(span);
/* 1327:1101 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1328:     */   }
/* 1329:     */   
/* 1330:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, IntBuffer column, DoubleBuffer span)
/* 1331:     */   {
/* 1332:1104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1333:1105 */     long function_pointer = caps.glGetSeparableFilter;
/* 1334:1106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1335:1107 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1336:1108 */     BufferChecks.checkDirect(row);
/* 1337:1109 */     BufferChecks.checkDirect(column);
/* 1338:1110 */     BufferChecks.checkDirect(span);
/* 1339:1111 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1340:     */   }
/* 1341:     */   
/* 1342:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, IntBuffer column, IntBuffer span)
/* 1343:     */   {
/* 1344:1114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1345:1115 */     long function_pointer = caps.glGetSeparableFilter;
/* 1346:1116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1347:1117 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1348:1118 */     BufferChecks.checkDirect(row);
/* 1349:1119 */     BufferChecks.checkDirect(column);
/* 1350:1120 */     BufferChecks.checkDirect(span);
/* 1351:1121 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1352:     */   }
/* 1353:     */   
/* 1354:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, IntBuffer column, ShortBuffer span)
/* 1355:     */   {
/* 1356:1124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1357:1125 */     long function_pointer = caps.glGetSeparableFilter;
/* 1358:1126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1359:1127 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1360:1128 */     BufferChecks.checkDirect(row);
/* 1361:1129 */     BufferChecks.checkDirect(column);
/* 1362:1130 */     BufferChecks.checkDirect(span);
/* 1363:1131 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1364:     */   }
/* 1365:     */   
/* 1366:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ShortBuffer column, ByteBuffer span)
/* 1367:     */   {
/* 1368:1134 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1369:1135 */     long function_pointer = caps.glGetSeparableFilter;
/* 1370:1136 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1371:1137 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1372:1138 */     BufferChecks.checkDirect(row);
/* 1373:1139 */     BufferChecks.checkDirect(column);
/* 1374:1140 */     BufferChecks.checkDirect(span);
/* 1375:1141 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1379:     */   {
/* 1380:1144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1381:1145 */     long function_pointer = caps.glGetSeparableFilter;
/* 1382:1146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1383:1147 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1384:1148 */     BufferChecks.checkDirect(row);
/* 1385:1149 */     BufferChecks.checkDirect(column);
/* 1386:1150 */     BufferChecks.checkDirect(span);
/* 1387:1151 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1388:     */   }
/* 1389:     */   
/* 1390:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ShortBuffer column, IntBuffer span)
/* 1391:     */   {
/* 1392:1154 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1393:1155 */     long function_pointer = caps.glGetSeparableFilter;
/* 1394:1156 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1395:1157 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1396:1158 */     BufferChecks.checkDirect(row);
/* 1397:1159 */     BufferChecks.checkDirect(column);
/* 1398:1160 */     BufferChecks.checkDirect(span);
/* 1399:1161 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1400:     */   }
/* 1401:     */   
/* 1402:     */   public static void glGetSeparableFilter(int target, int format, int type, DoubleBuffer row, ShortBuffer column, ShortBuffer span)
/* 1403:     */   {
/* 1404:1164 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1405:1165 */     long function_pointer = caps.glGetSeparableFilter;
/* 1406:1166 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1407:1167 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1408:1168 */     BufferChecks.checkDirect(row);
/* 1409:1169 */     BufferChecks.checkDirect(column);
/* 1410:1170 */     BufferChecks.checkDirect(span);
/* 1411:1171 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1412:     */   }
/* 1413:     */   
/* 1414:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ByteBuffer column, ByteBuffer span)
/* 1415:     */   {
/* 1416:1174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1417:1175 */     long function_pointer = caps.glGetSeparableFilter;
/* 1418:1176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1419:1177 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1420:1178 */     BufferChecks.checkDirect(row);
/* 1421:1179 */     BufferChecks.checkDirect(column);
/* 1422:1180 */     BufferChecks.checkDirect(span);
/* 1423:1181 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1424:     */   }
/* 1425:     */   
/* 1426:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1427:     */   {
/* 1428:1184 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1429:1185 */     long function_pointer = caps.glGetSeparableFilter;
/* 1430:1186 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1431:1187 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1432:1188 */     BufferChecks.checkDirect(row);
/* 1433:1189 */     BufferChecks.checkDirect(column);
/* 1434:1190 */     BufferChecks.checkDirect(span);
/* 1435:1191 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1436:     */   }
/* 1437:     */   
/* 1438:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ByteBuffer column, IntBuffer span)
/* 1439:     */   {
/* 1440:1194 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1441:1195 */     long function_pointer = caps.glGetSeparableFilter;
/* 1442:1196 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1443:1197 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1444:1198 */     BufferChecks.checkDirect(row);
/* 1445:1199 */     BufferChecks.checkDirect(column);
/* 1446:1200 */     BufferChecks.checkDirect(span);
/* 1447:1201 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1448:     */   }
/* 1449:     */   
/* 1450:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ByteBuffer column, ShortBuffer span)
/* 1451:     */   {
/* 1452:1204 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1453:1205 */     long function_pointer = caps.glGetSeparableFilter;
/* 1454:1206 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1455:1207 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1456:1208 */     BufferChecks.checkDirect(row);
/* 1457:1209 */     BufferChecks.checkDirect(column);
/* 1458:1210 */     BufferChecks.checkDirect(span);
/* 1459:1211 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1460:     */   }
/* 1461:     */   
/* 1462:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1463:     */   {
/* 1464:1214 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1465:1215 */     long function_pointer = caps.glGetSeparableFilter;
/* 1466:1216 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1467:1217 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1468:1218 */     BufferChecks.checkDirect(row);
/* 1469:1219 */     BufferChecks.checkDirect(column);
/* 1470:1220 */     BufferChecks.checkDirect(span);
/* 1471:1221 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1472:     */   }
/* 1473:     */   
/* 1474:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1475:     */   {
/* 1476:1224 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1477:1225 */     long function_pointer = caps.glGetSeparableFilter;
/* 1478:1226 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1479:1227 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1480:1228 */     BufferChecks.checkDirect(row);
/* 1481:1229 */     BufferChecks.checkDirect(column);
/* 1482:1230 */     BufferChecks.checkDirect(span);
/* 1483:1231 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1484:     */   }
/* 1485:     */   
/* 1486:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, DoubleBuffer column, IntBuffer span)
/* 1487:     */   {
/* 1488:1234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1489:1235 */     long function_pointer = caps.glGetSeparableFilter;
/* 1490:1236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1491:1237 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1492:1238 */     BufferChecks.checkDirect(row);
/* 1493:1239 */     BufferChecks.checkDirect(column);
/* 1494:1240 */     BufferChecks.checkDirect(span);
/* 1495:1241 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1496:     */   }
/* 1497:     */   
/* 1498:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1499:     */   {
/* 1500:1244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1501:1245 */     long function_pointer = caps.glGetSeparableFilter;
/* 1502:1246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1503:1247 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1504:1248 */     BufferChecks.checkDirect(row);
/* 1505:1249 */     BufferChecks.checkDirect(column);
/* 1506:1250 */     BufferChecks.checkDirect(span);
/* 1507:1251 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1508:     */   }
/* 1509:     */   
/* 1510:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, IntBuffer column, ByteBuffer span)
/* 1511:     */   {
/* 1512:1254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1513:1255 */     long function_pointer = caps.glGetSeparableFilter;
/* 1514:1256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1515:1257 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1516:1258 */     BufferChecks.checkDirect(row);
/* 1517:1259 */     BufferChecks.checkDirect(column);
/* 1518:1260 */     BufferChecks.checkDirect(span);
/* 1519:1261 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1520:     */   }
/* 1521:     */   
/* 1522:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, IntBuffer column, DoubleBuffer span)
/* 1523:     */   {
/* 1524:1264 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1525:1265 */     long function_pointer = caps.glGetSeparableFilter;
/* 1526:1266 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1527:1267 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1528:1268 */     BufferChecks.checkDirect(row);
/* 1529:1269 */     BufferChecks.checkDirect(column);
/* 1530:1270 */     BufferChecks.checkDirect(span);
/* 1531:1271 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1532:     */   }
/* 1533:     */   
/* 1534:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, IntBuffer column, IntBuffer span)
/* 1535:     */   {
/* 1536:1274 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1537:1275 */     long function_pointer = caps.glGetSeparableFilter;
/* 1538:1276 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1539:1277 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1540:1278 */     BufferChecks.checkDirect(row);
/* 1541:1279 */     BufferChecks.checkDirect(column);
/* 1542:1280 */     BufferChecks.checkDirect(span);
/* 1543:1281 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1544:     */   }
/* 1545:     */   
/* 1546:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, IntBuffer column, ShortBuffer span)
/* 1547:     */   {
/* 1548:1284 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1549:1285 */     long function_pointer = caps.glGetSeparableFilter;
/* 1550:1286 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1551:1287 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1552:1288 */     BufferChecks.checkDirect(row);
/* 1553:1289 */     BufferChecks.checkDirect(column);
/* 1554:1290 */     BufferChecks.checkDirect(span);
/* 1555:1291 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1556:     */   }
/* 1557:     */   
/* 1558:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ShortBuffer column, ByteBuffer span)
/* 1559:     */   {
/* 1560:1294 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1561:1295 */     long function_pointer = caps.glGetSeparableFilter;
/* 1562:1296 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1563:1297 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1564:1298 */     BufferChecks.checkDirect(row);
/* 1565:1299 */     BufferChecks.checkDirect(column);
/* 1566:1300 */     BufferChecks.checkDirect(span);
/* 1567:1301 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1568:     */   }
/* 1569:     */   
/* 1570:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1571:     */   {
/* 1572:1304 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1573:1305 */     long function_pointer = caps.glGetSeparableFilter;
/* 1574:1306 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1575:1307 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1576:1308 */     BufferChecks.checkDirect(row);
/* 1577:1309 */     BufferChecks.checkDirect(column);
/* 1578:1310 */     BufferChecks.checkDirect(span);
/* 1579:1311 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1580:     */   }
/* 1581:     */   
/* 1582:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ShortBuffer column, IntBuffer span)
/* 1583:     */   {
/* 1584:1314 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1585:1315 */     long function_pointer = caps.glGetSeparableFilter;
/* 1586:1316 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1587:1317 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1588:1318 */     BufferChecks.checkDirect(row);
/* 1589:1319 */     BufferChecks.checkDirect(column);
/* 1590:1320 */     BufferChecks.checkDirect(span);
/* 1591:1321 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1592:     */   }
/* 1593:     */   
/* 1594:     */   public static void glGetSeparableFilter(int target, int format, int type, FloatBuffer row, ShortBuffer column, ShortBuffer span)
/* 1595:     */   {
/* 1596:1324 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1597:1325 */     long function_pointer = caps.glGetSeparableFilter;
/* 1598:1326 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1599:1327 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1600:1328 */     BufferChecks.checkDirect(row);
/* 1601:1329 */     BufferChecks.checkDirect(column);
/* 1602:1330 */     BufferChecks.checkDirect(span);
/* 1603:1331 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1604:     */   }
/* 1605:     */   
/* 1606:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ByteBuffer column, ByteBuffer span)
/* 1607:     */   {
/* 1608:1334 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1609:1335 */     long function_pointer = caps.glGetSeparableFilter;
/* 1610:1336 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1611:1337 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1612:1338 */     BufferChecks.checkDirect(row);
/* 1613:1339 */     BufferChecks.checkDirect(column);
/* 1614:1340 */     BufferChecks.checkDirect(span);
/* 1615:1341 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1616:     */   }
/* 1617:     */   
/* 1618:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1619:     */   {
/* 1620:1344 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1621:1345 */     long function_pointer = caps.glGetSeparableFilter;
/* 1622:1346 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1623:1347 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1624:1348 */     BufferChecks.checkDirect(row);
/* 1625:1349 */     BufferChecks.checkDirect(column);
/* 1626:1350 */     BufferChecks.checkDirect(span);
/* 1627:1351 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1628:     */   }
/* 1629:     */   
/* 1630:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ByteBuffer column, IntBuffer span)
/* 1631:     */   {
/* 1632:1354 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1633:1355 */     long function_pointer = caps.glGetSeparableFilter;
/* 1634:1356 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1635:1357 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1636:1358 */     BufferChecks.checkDirect(row);
/* 1637:1359 */     BufferChecks.checkDirect(column);
/* 1638:1360 */     BufferChecks.checkDirect(span);
/* 1639:1361 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1640:     */   }
/* 1641:     */   
/* 1642:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ByteBuffer column, ShortBuffer span)
/* 1643:     */   {
/* 1644:1364 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1645:1365 */     long function_pointer = caps.glGetSeparableFilter;
/* 1646:1366 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1647:1367 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1648:1368 */     BufferChecks.checkDirect(row);
/* 1649:1369 */     BufferChecks.checkDirect(column);
/* 1650:1370 */     BufferChecks.checkDirect(span);
/* 1651:1371 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1652:     */   }
/* 1653:     */   
/* 1654:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1655:     */   {
/* 1656:1374 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1657:1375 */     long function_pointer = caps.glGetSeparableFilter;
/* 1658:1376 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1659:1377 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1660:1378 */     BufferChecks.checkDirect(row);
/* 1661:1379 */     BufferChecks.checkDirect(column);
/* 1662:1380 */     BufferChecks.checkDirect(span);
/* 1663:1381 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1664:     */   }
/* 1665:     */   
/* 1666:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1667:     */   {
/* 1668:1384 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1669:1385 */     long function_pointer = caps.glGetSeparableFilter;
/* 1670:1386 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1671:1387 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1672:1388 */     BufferChecks.checkDirect(row);
/* 1673:1389 */     BufferChecks.checkDirect(column);
/* 1674:1390 */     BufferChecks.checkDirect(span);
/* 1675:1391 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1676:     */   }
/* 1677:     */   
/* 1678:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, DoubleBuffer column, IntBuffer span)
/* 1679:     */   {
/* 1680:1394 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1681:1395 */     long function_pointer = caps.glGetSeparableFilter;
/* 1682:1396 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1683:1397 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1684:1398 */     BufferChecks.checkDirect(row);
/* 1685:1399 */     BufferChecks.checkDirect(column);
/* 1686:1400 */     BufferChecks.checkDirect(span);
/* 1687:1401 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1688:     */   }
/* 1689:     */   
/* 1690:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1691:     */   {
/* 1692:1404 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1693:1405 */     long function_pointer = caps.glGetSeparableFilter;
/* 1694:1406 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1695:1407 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1696:1408 */     BufferChecks.checkDirect(row);
/* 1697:1409 */     BufferChecks.checkDirect(column);
/* 1698:1410 */     BufferChecks.checkDirect(span);
/* 1699:1411 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1700:     */   }
/* 1701:     */   
/* 1702:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, IntBuffer column, ByteBuffer span)
/* 1703:     */   {
/* 1704:1414 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1705:1415 */     long function_pointer = caps.glGetSeparableFilter;
/* 1706:1416 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1707:1417 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1708:1418 */     BufferChecks.checkDirect(row);
/* 1709:1419 */     BufferChecks.checkDirect(column);
/* 1710:1420 */     BufferChecks.checkDirect(span);
/* 1711:1421 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1712:     */   }
/* 1713:     */   
/* 1714:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, IntBuffer column, DoubleBuffer span)
/* 1715:     */   {
/* 1716:1424 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1717:1425 */     long function_pointer = caps.glGetSeparableFilter;
/* 1718:1426 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1719:1427 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1720:1428 */     BufferChecks.checkDirect(row);
/* 1721:1429 */     BufferChecks.checkDirect(column);
/* 1722:1430 */     BufferChecks.checkDirect(span);
/* 1723:1431 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1724:     */   }
/* 1725:     */   
/* 1726:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, IntBuffer column, IntBuffer span)
/* 1727:     */   {
/* 1728:1434 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1729:1435 */     long function_pointer = caps.glGetSeparableFilter;
/* 1730:1436 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1731:1437 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1732:1438 */     BufferChecks.checkDirect(row);
/* 1733:1439 */     BufferChecks.checkDirect(column);
/* 1734:1440 */     BufferChecks.checkDirect(span);
/* 1735:1441 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1736:     */   }
/* 1737:     */   
/* 1738:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, IntBuffer column, ShortBuffer span)
/* 1739:     */   {
/* 1740:1444 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1741:1445 */     long function_pointer = caps.glGetSeparableFilter;
/* 1742:1446 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1743:1447 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1744:1448 */     BufferChecks.checkDirect(row);
/* 1745:1449 */     BufferChecks.checkDirect(column);
/* 1746:1450 */     BufferChecks.checkDirect(span);
/* 1747:1451 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1748:     */   }
/* 1749:     */   
/* 1750:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ShortBuffer column, ByteBuffer span)
/* 1751:     */   {
/* 1752:1454 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1753:1455 */     long function_pointer = caps.glGetSeparableFilter;
/* 1754:1456 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1755:1457 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1756:1458 */     BufferChecks.checkDirect(row);
/* 1757:1459 */     BufferChecks.checkDirect(column);
/* 1758:1460 */     BufferChecks.checkDirect(span);
/* 1759:1461 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1760:     */   }
/* 1761:     */   
/* 1762:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1763:     */   {
/* 1764:1464 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1765:1465 */     long function_pointer = caps.glGetSeparableFilter;
/* 1766:1466 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1767:1467 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1768:1468 */     BufferChecks.checkDirect(row);
/* 1769:1469 */     BufferChecks.checkDirect(column);
/* 1770:1470 */     BufferChecks.checkDirect(span);
/* 1771:1471 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1772:     */   }
/* 1773:     */   
/* 1774:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ShortBuffer column, IntBuffer span)
/* 1775:     */   {
/* 1776:1474 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1777:1475 */     long function_pointer = caps.glGetSeparableFilter;
/* 1778:1476 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1779:1477 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1780:1478 */     BufferChecks.checkDirect(row);
/* 1781:1479 */     BufferChecks.checkDirect(column);
/* 1782:1480 */     BufferChecks.checkDirect(span);
/* 1783:1481 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1784:     */   }
/* 1785:     */   
/* 1786:     */   public static void glGetSeparableFilter(int target, int format, int type, IntBuffer row, ShortBuffer column, ShortBuffer span)
/* 1787:     */   {
/* 1788:1484 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1789:1485 */     long function_pointer = caps.glGetSeparableFilter;
/* 1790:1486 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1791:1487 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1792:1488 */     BufferChecks.checkDirect(row);
/* 1793:1489 */     BufferChecks.checkDirect(column);
/* 1794:1490 */     BufferChecks.checkDirect(span);
/* 1795:1491 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1796:     */   }
/* 1797:     */   
/* 1798:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ByteBuffer column, ByteBuffer span)
/* 1799:     */   {
/* 1800:1494 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1801:1495 */     long function_pointer = caps.glGetSeparableFilter;
/* 1802:1496 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1803:1497 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1804:1498 */     BufferChecks.checkDirect(row);
/* 1805:1499 */     BufferChecks.checkDirect(column);
/* 1806:1500 */     BufferChecks.checkDirect(span);
/* 1807:1501 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1808:     */   }
/* 1809:     */   
/* 1810:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ByteBuffer column, DoubleBuffer span)
/* 1811:     */   {
/* 1812:1504 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1813:1505 */     long function_pointer = caps.glGetSeparableFilter;
/* 1814:1506 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1815:1507 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1816:1508 */     BufferChecks.checkDirect(row);
/* 1817:1509 */     BufferChecks.checkDirect(column);
/* 1818:1510 */     BufferChecks.checkDirect(span);
/* 1819:1511 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1820:     */   }
/* 1821:     */   
/* 1822:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ByteBuffer column, IntBuffer span)
/* 1823:     */   {
/* 1824:1514 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1825:1515 */     long function_pointer = caps.glGetSeparableFilter;
/* 1826:1516 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1827:1517 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1828:1518 */     BufferChecks.checkDirect(row);
/* 1829:1519 */     BufferChecks.checkDirect(column);
/* 1830:1520 */     BufferChecks.checkDirect(span);
/* 1831:1521 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1832:     */   }
/* 1833:     */   
/* 1834:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ByteBuffer column, ShortBuffer span)
/* 1835:     */   {
/* 1836:1524 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1837:1525 */     long function_pointer = caps.glGetSeparableFilter;
/* 1838:1526 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1839:1527 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1840:1528 */     BufferChecks.checkDirect(row);
/* 1841:1529 */     BufferChecks.checkDirect(column);
/* 1842:1530 */     BufferChecks.checkDirect(span);
/* 1843:1531 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1844:     */   }
/* 1845:     */   
/* 1846:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, DoubleBuffer column, ByteBuffer span)
/* 1847:     */   {
/* 1848:1534 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1849:1535 */     long function_pointer = caps.glGetSeparableFilter;
/* 1850:1536 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1851:1537 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1852:1538 */     BufferChecks.checkDirect(row);
/* 1853:1539 */     BufferChecks.checkDirect(column);
/* 1854:1540 */     BufferChecks.checkDirect(span);
/* 1855:1541 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1856:     */   }
/* 1857:     */   
/* 1858:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, DoubleBuffer column, DoubleBuffer span)
/* 1859:     */   {
/* 1860:1544 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1861:1545 */     long function_pointer = caps.glGetSeparableFilter;
/* 1862:1546 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1863:1547 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1864:1548 */     BufferChecks.checkDirect(row);
/* 1865:1549 */     BufferChecks.checkDirect(column);
/* 1866:1550 */     BufferChecks.checkDirect(span);
/* 1867:1551 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1868:     */   }
/* 1869:     */   
/* 1870:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, DoubleBuffer column, IntBuffer span)
/* 1871:     */   {
/* 1872:1554 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1873:1555 */     long function_pointer = caps.glGetSeparableFilter;
/* 1874:1556 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1875:1557 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1876:1558 */     BufferChecks.checkDirect(row);
/* 1877:1559 */     BufferChecks.checkDirect(column);
/* 1878:1560 */     BufferChecks.checkDirect(span);
/* 1879:1561 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1880:     */   }
/* 1881:     */   
/* 1882:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, DoubleBuffer column, ShortBuffer span)
/* 1883:     */   {
/* 1884:1564 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1885:1565 */     long function_pointer = caps.glGetSeparableFilter;
/* 1886:1566 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1887:1567 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1888:1568 */     BufferChecks.checkDirect(row);
/* 1889:1569 */     BufferChecks.checkDirect(column);
/* 1890:1570 */     BufferChecks.checkDirect(span);
/* 1891:1571 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1892:     */   }
/* 1893:     */   
/* 1894:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, IntBuffer column, ByteBuffer span)
/* 1895:     */   {
/* 1896:1574 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1897:1575 */     long function_pointer = caps.glGetSeparableFilter;
/* 1898:1576 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1899:1577 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1900:1578 */     BufferChecks.checkDirect(row);
/* 1901:1579 */     BufferChecks.checkDirect(column);
/* 1902:1580 */     BufferChecks.checkDirect(span);
/* 1903:1581 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1904:     */   }
/* 1905:     */   
/* 1906:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, IntBuffer column, DoubleBuffer span)
/* 1907:     */   {
/* 1908:1584 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1909:1585 */     long function_pointer = caps.glGetSeparableFilter;
/* 1910:1586 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1911:1587 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1912:1588 */     BufferChecks.checkDirect(row);
/* 1913:1589 */     BufferChecks.checkDirect(column);
/* 1914:1590 */     BufferChecks.checkDirect(span);
/* 1915:1591 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1916:     */   }
/* 1917:     */   
/* 1918:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, IntBuffer column, IntBuffer span)
/* 1919:     */   {
/* 1920:1594 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1921:1595 */     long function_pointer = caps.glGetSeparableFilter;
/* 1922:1596 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1923:1597 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1924:1598 */     BufferChecks.checkDirect(row);
/* 1925:1599 */     BufferChecks.checkDirect(column);
/* 1926:1600 */     BufferChecks.checkDirect(span);
/* 1927:1601 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1928:     */   }
/* 1929:     */   
/* 1930:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, IntBuffer column, ShortBuffer span)
/* 1931:     */   {
/* 1932:1604 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1933:1605 */     long function_pointer = caps.glGetSeparableFilter;
/* 1934:1606 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1935:1607 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1936:1608 */     BufferChecks.checkDirect(row);
/* 1937:1609 */     BufferChecks.checkDirect(column);
/* 1938:1610 */     BufferChecks.checkDirect(span);
/* 1939:1611 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1940:     */   }
/* 1941:     */   
/* 1942:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ShortBuffer column, ByteBuffer span)
/* 1943:     */   {
/* 1944:1614 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1945:1615 */     long function_pointer = caps.glGetSeparableFilter;
/* 1946:1616 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1947:1617 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1948:1618 */     BufferChecks.checkDirect(row);
/* 1949:1619 */     BufferChecks.checkDirect(column);
/* 1950:1620 */     BufferChecks.checkDirect(span);
/* 1951:1621 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1952:     */   }
/* 1953:     */   
/* 1954:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ShortBuffer column, DoubleBuffer span)
/* 1955:     */   {
/* 1956:1624 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1957:1625 */     long function_pointer = caps.glGetSeparableFilter;
/* 1958:1626 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1959:1627 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1960:1628 */     BufferChecks.checkDirect(row);
/* 1961:1629 */     BufferChecks.checkDirect(column);
/* 1962:1630 */     BufferChecks.checkDirect(span);
/* 1963:1631 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1964:     */   }
/* 1965:     */   
/* 1966:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ShortBuffer column, IntBuffer span)
/* 1967:     */   {
/* 1968:1634 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1969:1635 */     long function_pointer = caps.glGetSeparableFilter;
/* 1970:1636 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1971:1637 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1972:1638 */     BufferChecks.checkDirect(row);
/* 1973:1639 */     BufferChecks.checkDirect(column);
/* 1974:1640 */     BufferChecks.checkDirect(span);
/* 1975:1641 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1976:     */   }
/* 1977:     */   
/* 1978:     */   public static void glGetSeparableFilter(int target, int format, int type, ShortBuffer row, ShortBuffer column, ShortBuffer span)
/* 1979:     */   {
/* 1980:1644 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1981:1645 */     long function_pointer = caps.glGetSeparableFilter;
/* 1982:1646 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1983:1647 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1984:1648 */     BufferChecks.checkDirect(row);
/* 1985:1649 */     BufferChecks.checkDirect(column);
/* 1986:1650 */     BufferChecks.checkDirect(span);
/* 1987:1651 */     nglGetSeparableFilter(target, format, type, MemoryUtil.getAddress(row), MemoryUtil.getAddress(column), MemoryUtil.getAddress(span), function_pointer);
/* 1988:     */   }
/* 1989:     */   
/* 1990:     */   static native void nglGetSeparableFilter(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 1991:     */   
/* 1992:     */   public static void glGetSeparableFilter(int target, int format, int type, long row_buffer_offset, long column_buffer_offset, long span_buffer_offset)
/* 1993:     */   {
/* 1994:1655 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1995:1656 */     long function_pointer = caps.glGetSeparableFilter;
/* 1996:1657 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1997:1658 */     GLChecks.ensurePackPBOenabled(caps);
/* 1998:1659 */     nglGetSeparableFilterBO(target, format, type, row_buffer_offset, column_buffer_offset, span_buffer_offset, function_pointer);
/* 1999:     */   }
/* 2000:     */   
/* 2001:     */   static native void nglGetSeparableFilterBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 2002:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBImaging
 * JD-Core Version:    0.7.0.1
 */