/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBComputeShader
/*  4:   */ {
/*  5:   */   public static final int GL_COMPUTE_SHADER = 37305;
/*  6:   */   public static final int GL_MAX_COMPUTE_UNIFORM_BLOCKS = 37307;
/*  7:   */   public static final int GL_MAX_COMPUTE_TEXTURE_IMAGE_UNITS = 37308;
/*  8:   */   public static final int GL_MAX_COMPUTE_IMAGE_UNIFORMS = 37309;
/*  9:   */   public static final int GL_MAX_COMPUTE_SHARED_MEMORY_SIZE = 33378;
/* 10:   */   public static final int GL_MAX_COMPUTE_UNIFORM_COMPONENTS = 33379;
/* 11:   */   public static final int GL_MAX_COMPUTE_ATOMIC_COUNTER_BUFFERS = 33380;
/* 12:   */   public static final int GL_MAX_COMPUTE_ATOMIC_COUNTERS = 33381;
/* 13:   */   public static final int GL_MAX_COMBINED_COMPUTE_UNIFORM_COMPONENTS = 33382;
/* 14:   */   public static final int GL_MAX_COMPUTE_WORK_GROUP_INVOCATIONS = 37099;
/* 15:   */   public static final int GL_MAX_COMPUTE_WORK_GROUP_COUNT = 37310;
/* 16:   */   public static final int GL_MAX_COMPUTE_WORK_GROUP_SIZE = 37311;
/* 17:   */   public static final int GL_COMPUTE_WORK_GROUP_SIZE = 33383;
/* 18:   */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_COMPUTE_SHADER = 37100;
/* 19:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_COMPUTE_SHADER = 37101;
/* 20:   */   public static final int GL_DISPATCH_INDIRECT_BUFFER = 37102;
/* 21:   */   public static final int GL_DISPATCH_INDIRECT_BUFFER_BINDING = 37103;
/* 22:   */   public static final int GL_COMPUTE_SHADER_BIT = 32;
/* 23:   */   
/* 24:   */   public static void glDispatchCompute(int num_groups_x, int num_groups_y, int num_groups_z)
/* 25:   */   {
/* 26:73 */     GL43.glDispatchCompute(num_groups_x, num_groups_y, num_groups_z);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static void glDispatchComputeIndirect(long indirect)
/* 30:   */   {
/* 31:77 */     GL43.glDispatchComputeIndirect(indirect);
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBComputeShader
 * JD-Core Version:    0.7.0.1
 */