/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBMapBufferRange
/*  6:   */ {
/*  7:   */   public static final int GL_MAP_READ_BIT = 1;
/*  8:   */   public static final int GL_MAP_WRITE_BIT = 2;
/*  9:   */   public static final int GL_MAP_INVALIDATE_RANGE_BIT = 4;
/* 10:   */   public static final int GL_MAP_INVALIDATE_BUFFER_BIT = 8;
/* 11:   */   public static final int GL_MAP_FLUSH_EXPLICIT_BIT = 16;
/* 12:   */   public static final int GL_MAP_UNSYNCHRONIZED_BIT = 32;
/* 13:   */   
/* 14:   */   public static ByteBuffer glMapBufferRange(int target, long offset, long length, int access, ByteBuffer old_buffer)
/* 15:   */   {
/* 16:37 */     return GL30.glMapBufferRange(target, offset, length, access, old_buffer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static void glFlushMappedBufferRange(int target, long offset, long length)
/* 20:   */   {
/* 21:41 */     GL30.glFlushMappedBufferRange(target, offset, length);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBMapBufferRange
 * JD-Core Version:    0.7.0.1
 */