/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ 
/*  5:   */ class EventQueue
/*  6:   */ {
/*  7:   */   private static final int QUEUE_SIZE = 200;
/*  8:   */   private final int event_size;
/*  9:   */   private final ByteBuffer queue;
/* 10:   */   
/* 11:   */   protected EventQueue(int event_size)
/* 12:   */   {
/* 13:49 */     this.event_size = event_size;
/* 14:50 */     this.queue = ByteBuffer.allocate(200 * event_size);
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected synchronized void clearEvents()
/* 18:   */   {
/* 19:54 */     this.queue.clear();
/* 20:   */   }
/* 21:   */   
/* 22:   */   public synchronized void copyEvents(ByteBuffer dest)
/* 23:   */   {
/* 24:61 */     this.queue.flip();
/* 25:62 */     int old_limit = this.queue.limit();
/* 26:63 */     if (dest.remaining() < this.queue.remaining()) {
/* 27:64 */       this.queue.limit(dest.remaining() + this.queue.position());
/* 28:   */     }
/* 29:65 */     dest.put(this.queue);
/* 30:66 */     this.queue.limit(old_limit);
/* 31:67 */     this.queue.compact();
/* 32:   */   }
/* 33:   */   
/* 34:   */   public synchronized boolean putEvent(ByteBuffer event)
/* 35:   */   {
/* 36:75 */     if (event.remaining() != this.event_size) {
/* 37:76 */       throw new IllegalArgumentException("Internal error: event size " + this.event_size + " does not equal the given event size " + event.remaining());
/* 38:   */     }
/* 39:77 */     if (this.queue.remaining() >= event.remaining())
/* 40:   */     {
/* 41:78 */       this.queue.put(event);
/* 42:79 */       return true;
/* 43:   */     }
/* 44:81 */     return false;
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EventQueue
 * JD-Core Version:    0.7.0.1
 */