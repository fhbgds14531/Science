package org.lwjgl.opengl;

public final class ARBPointSprite
{
  public static final int GL_POINT_SPRITE_ARB = 34913;
  public static final int GL_COORD_REPLACE_ARB = 34914;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBPointSprite
 * JD-Core Version:    0.7.0.1
 */