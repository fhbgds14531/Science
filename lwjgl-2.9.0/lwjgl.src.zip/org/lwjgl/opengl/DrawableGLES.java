/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.BufferUtils;
/*   4:    */ import org.lwjgl.LWJGLException;
/*   5:    */ import org.lwjgl.LWJGLUtil;
/*   6:    */ import org.lwjgl.PointerBuffer;
/*   7:    */ import org.lwjgl.opengles.ContextAttribs;
/*   8:    */ import org.lwjgl.opengles.EGL;
/*   9:    */ import org.lwjgl.opengles.EGLConfig;
/*  10:    */ import org.lwjgl.opengles.EGLContext;
/*  11:    */ import org.lwjgl.opengles.EGLDisplay;
/*  12:    */ import org.lwjgl.opengles.EGLSurface;
/*  13:    */ import org.lwjgl.opengles.GLES20;
/*  14:    */ import org.lwjgl.opengles.PixelFormat;
/*  15:    */ import org.lwjgl.opengles.PowerManagementEventException;
/*  16:    */ import org.lwjgl.opengles.Util;
/*  17:    */ 
/*  18:    */ abstract class DrawableGLES
/*  19:    */   implements DrawableLWJGL
/*  20:    */ {
/*  21:    */   protected PixelFormat pixel_format;
/*  22:    */   protected EGLDisplay eglDisplay;
/*  23:    */   protected EGLConfig eglConfig;
/*  24:    */   protected EGLSurface eglSurface;
/*  25:    */   protected ContextGLES context;
/*  26:    */   protected Drawable shared_drawable;
/*  27:    */   
/*  28:    */   public void setPixelFormat(PixelFormatLWJGL pf)
/*  29:    */     throws LWJGLException
/*  30:    */   {
/*  31: 68 */     synchronized (GlobalLock.lock)
/*  32:    */     {
/*  33: 69 */       this.pixel_format = ((PixelFormat)pf);
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public PixelFormatLWJGL getPixelFormat()
/*  38:    */   {
/*  39: 74 */     synchronized (GlobalLock.lock)
/*  40:    */     {
/*  41: 75 */       return this.pixel_format;
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void initialize(long window, long display_id, int eglSurfaceType, PixelFormat pf)
/*  46:    */     throws LWJGLException
/*  47:    */   {
/*  48: 80 */     synchronized (GlobalLock.lock)
/*  49:    */     {
/*  50: 81 */       if (this.eglSurface != null)
/*  51:    */       {
/*  52: 82 */         this.eglSurface.destroy();
/*  53: 83 */         this.eglSurface = null;
/*  54:    */       }
/*  55: 86 */       if (this.eglDisplay != null)
/*  56:    */       {
/*  57: 87 */         this.eglDisplay.terminate();
/*  58: 88 */         this.eglDisplay = null;
/*  59:    */       }
/*  60: 91 */       EGLDisplay eglDisplay = EGL.eglGetDisplay((int)display_id);
/*  61:    */       
/*  62: 93 */       int[] attribs = { 12329, 0, 12352, 4, 12333, 0 };
/*  63:    */       
/*  64:    */ 
/*  65:    */ 
/*  66:    */ 
/*  67:    */ 
/*  68: 99 */       EGLConfig[] configs = eglDisplay.chooseConfig(pf.getAttribBuffer(eglDisplay, eglSurfaceType, attribs), null, BufferUtils.createIntBuffer(1));
/*  69:100 */       if (configs.length == 0) {
/*  70:101 */         throw new LWJGLException("No EGLConfigs found for the specified PixelFormat.");
/*  71:    */       }
/*  72:103 */       EGLConfig eglConfig = pf.getBestMatch(configs);
/*  73:104 */       EGLSurface eglSurface = eglDisplay.createWindowSurface(eglConfig, window, null);
/*  74:105 */       pf.setSurfaceAttribs(eglSurface);
/*  75:    */       
/*  76:107 */       this.eglDisplay = eglDisplay;
/*  77:108 */       this.eglConfig = eglConfig;
/*  78:109 */       this.eglSurface = eglSurface;
/*  79:112 */       if (this.context != null) {
/*  80:113 */         this.context.getEGLContext().setDisplay(eglDisplay);
/*  81:    */       }
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void createContext(ContextAttribs attribs, Drawable shared_drawable)
/*  86:    */     throws LWJGLException
/*  87:    */   {
/*  88:118 */     synchronized (GlobalLock.lock)
/*  89:    */     {
/*  90:119 */       this.context = new ContextGLES(this, attribs, shared_drawable != null ? ((DrawableGLES)shared_drawable).getContext() : null);
/*  91:120 */       this.shared_drawable = shared_drawable;
/*  92:    */     }
/*  93:    */   }
/*  94:    */   
/*  95:    */   Drawable getSharedDrawable()
/*  96:    */   {
/*  97:125 */     synchronized (GlobalLock.lock)
/*  98:    */     {
/*  99:126 */       return this.shared_drawable;
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public EGLDisplay getEGLDisplay()
/* 104:    */   {
/* 105:131 */     synchronized (GlobalLock.lock)
/* 106:    */     {
/* 107:132 */       return this.eglDisplay;
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public EGLConfig getEGLConfig()
/* 112:    */   {
/* 113:137 */     synchronized (GlobalLock.lock)
/* 114:    */     {
/* 115:138 */       return this.eglConfig;
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   public EGLSurface getEGLSurface()
/* 120:    */   {
/* 121:143 */     synchronized (GlobalLock.lock)
/* 122:    */     {
/* 123:144 */       return this.eglSurface;
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   public ContextGLES getContext()
/* 128:    */   {
/* 129:149 */     synchronized (GlobalLock.lock)
/* 130:    */     {
/* 131:150 */       return this.context;
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public Context createSharedContext()
/* 136:    */     throws LWJGLException
/* 137:    */   {
/* 138:155 */     synchronized (GlobalLock.lock)
/* 139:    */     {
/* 140:156 */       checkDestroyed();
/* 141:157 */       return new ContextGLES(this, this.context.getContextAttribs(), this.context);
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void checkGLError() {}
/* 146:    */   
/* 147:    */   public void setSwapInterval(int swap_interval)
/* 148:    */   {
/* 149:166 */     ContextGLES.setSwapInterval(swap_interval);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void swapBuffers()
/* 153:    */     throws LWJGLException
/* 154:    */   {}
/* 155:    */   
/* 156:    */   public void initContext(float r, float g, float b)
/* 157:    */   {
/* 158:175 */     GLES20.glClearColor(r, g, b, 0.0F);
/* 159:    */     
/* 160:177 */     GLES20.glClear(16384);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public boolean isCurrent()
/* 164:    */     throws LWJGLException
/* 165:    */   {
/* 166:181 */     synchronized (GlobalLock.lock)
/* 167:    */     {
/* 168:182 */       checkDestroyed();
/* 169:183 */       return this.context.isCurrent();
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void makeCurrent()
/* 174:    */     throws LWJGLException, PowerManagementEventException
/* 175:    */   {
/* 176:188 */     synchronized (GlobalLock.lock)
/* 177:    */     {
/* 178:189 */       checkDestroyed();
/* 179:190 */       this.context.makeCurrent();
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   public void releaseContext()
/* 184:    */     throws LWJGLException, PowerManagementEventException
/* 185:    */   {
/* 186:195 */     synchronized (GlobalLock.lock)
/* 187:    */     {
/* 188:196 */       checkDestroyed();
/* 189:197 */       if (this.context.isCurrent()) {
/* 190:198 */         this.context.releaseCurrent();
/* 191:    */       }
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void destroy()
/* 196:    */   {
/* 197:203 */     synchronized (GlobalLock.lock)
/* 198:    */     {
/* 199:    */       try
/* 200:    */       {
/* 201:205 */         if (this.context != null)
/* 202:    */         {
/* 203:    */           try
/* 204:    */           {
/* 205:207 */             releaseContext();
/* 206:    */           }
/* 207:    */           catch (PowerManagementEventException e) {}
/* 208:212 */           this.context.forceDestroy();
/* 209:213 */           this.context = null;
/* 210:    */         }
/* 211:216 */         if (this.eglSurface != null)
/* 212:    */         {
/* 213:217 */           this.eglSurface.destroy();
/* 214:218 */           this.eglSurface = null;
/* 215:    */         }
/* 216:221 */         if (this.eglDisplay != null)
/* 217:    */         {
/* 218:222 */           this.eglDisplay.terminate();
/* 219:223 */           this.eglDisplay = null;
/* 220:    */         }
/* 221:226 */         this.pixel_format = null;
/* 222:227 */         this.shared_drawable = null;
/* 223:    */       }
/* 224:    */       catch (LWJGLException e)
/* 225:    */       {
/* 226:229 */         LWJGLUtil.log("Exception occurred while destroying Drawable: " + e);
/* 227:    */       }
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   protected void checkDestroyed()
/* 232:    */   {
/* 233:235 */     if (this.context == null) {
/* 234:236 */       throw new IllegalStateException("The Drawable has no context available.");
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   public void setCLSharingProperties(PointerBuffer properties)
/* 239:    */     throws LWJGLException
/* 240:    */   {
/* 241:240 */     throw new UnsupportedOperationException();
/* 242:    */   }
/* 243:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.DrawableGLES
 * JD-Core Version:    0.7.0.1
 */