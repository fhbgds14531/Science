/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferUtils;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ import org.lwjgl.Sys;
/*   7:    */ 
/*   8:    */ public final class Pbuffer
/*   9:    */   extends DrawableGL
/*  10:    */ {
/*  11:    */   public static final int PBUFFER_SUPPORTED = 1;
/*  12:    */   public static final int RENDER_TEXTURE_SUPPORTED = 2;
/*  13:    */   public static final int RENDER_TEXTURE_RECTANGLE_SUPPORTED = 4;
/*  14:    */   public static final int RENDER_DEPTH_TEXTURE_SUPPORTED = 8;
/*  15:    */   public static final int MIPMAP_LEVEL = 8315;
/*  16:    */   public static final int CUBE_MAP_FACE = 8316;
/*  17:    */   public static final int TEXTURE_CUBE_MAP_POSITIVE_X = 8317;
/*  18:    */   public static final int TEXTURE_CUBE_MAP_NEGATIVE_X = 8318;
/*  19:    */   public static final int TEXTURE_CUBE_MAP_POSITIVE_Y = 8319;
/*  20:    */   public static final int TEXTURE_CUBE_MAP_NEGATIVE_Y = 8320;
/*  21:    */   public static final int TEXTURE_CUBE_MAP_POSITIVE_Z = 8321;
/*  22:    */   public static final int TEXTURE_CUBE_MAP_NEGATIVE_Z = 8322;
/*  23:    */   public static final int FRONT_LEFT_BUFFER = 8323;
/*  24:    */   public static final int FRONT_RIGHT_BUFFER = 8324;
/*  25:    */   public static final int BACK_LEFT_BUFFER = 8325;
/*  26:    */   public static final int BACK_RIGHT_BUFFER = 8326;
/*  27:    */   public static final int DEPTH_BUFFER = 8359;
/*  28:    */   private final int width;
/*  29:    */   private final int height;
/*  30:    */   
/*  31:    */   public Pbuffer(int width, int height, PixelFormat pixel_format, Drawable shared_drawable)
/*  32:    */     throws LWJGLException
/*  33:    */   {
/*  34:166 */     this(width, height, pixel_format, null, shared_drawable);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public Pbuffer(int width, int height, PixelFormat pixel_format, RenderTexture renderTexture, Drawable shared_drawable)
/*  38:    */     throws LWJGLException
/*  39:    */   {
/*  40:190 */     this(width, height, pixel_format, renderTexture, shared_drawable, null);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Pbuffer(int width, int height, PixelFormat pixel_format, RenderTexture renderTexture, Drawable shared_drawable, ContextAttribs attribs)
/*  44:    */     throws LWJGLException
/*  45:    */   {
/*  46:215 */     if (pixel_format == null) {
/*  47:216 */       throw new NullPointerException("Pixel format must be non-null");
/*  48:    */     }
/*  49:217 */     this.width = width;
/*  50:218 */     this.height = height;
/*  51:219 */     this.peer_info = createPbuffer(width, height, pixel_format, attribs, renderTexture);
/*  52:220 */     Context shared_context = null;
/*  53:221 */     if (shared_drawable == null) {
/*  54:222 */       shared_drawable = Display.getDrawable();
/*  55:    */     }
/*  56:223 */     if (shared_drawable != null) {
/*  57:224 */       shared_context = ((DrawableLWJGL)shared_drawable).getContext();
/*  58:    */     }
/*  59:225 */     this.context = new ContextGL(this.peer_info, attribs, (ContextGL)shared_context);
/*  60:    */   }
/*  61:    */   
/*  62:    */   private static PeerInfo createPbuffer(int width, int height, PixelFormat pixel_format, ContextAttribs attribs, RenderTexture renderTexture)
/*  63:    */     throws LWJGLException
/*  64:    */   {
/*  65:229 */     if (renderTexture == null)
/*  66:    */     {
/*  67:233 */       IntBuffer defaultAttribs = BufferUtils.createIntBuffer(1);
/*  68:234 */       return Display.getImplementation().createPbuffer(width, height, pixel_format, attribs, null, defaultAttribs);
/*  69:    */     }
/*  70:236 */     return Display.getImplementation().createPbuffer(width, height, pixel_format, attribs, renderTexture.pixelFormatCaps, renderTexture.pBufferAttribs);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public synchronized boolean isBufferLost()
/*  74:    */   {
/*  75:249 */     checkDestroyed();
/*  76:250 */     return Display.getImplementation().isBufferLost(this.peer_info);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static int getCapabilities()
/*  80:    */   {
/*  81:259 */     return Display.getImplementation().getPbufferCapabilities();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public synchronized void setAttrib(int attrib, int value)
/*  85:    */   {
/*  86:279 */     checkDestroyed();
/*  87:280 */     Display.getImplementation().setPbufferAttrib(this.peer_info, attrib, value);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public synchronized void bindTexImage(int buffer)
/*  91:    */   {
/*  92:291 */     checkDestroyed();
/*  93:292 */     Display.getImplementation().bindTexImageToPbuffer(this.peer_info, buffer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public synchronized void releaseTexImage(int buffer)
/*  97:    */   {
/*  98:301 */     checkDestroyed();
/*  99:302 */     Display.getImplementation().releaseTexImageFromPbuffer(this.peer_info, buffer);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public synchronized int getHeight()
/* 103:    */   {
/* 104:309 */     checkDestroyed();
/* 105:310 */     return this.height;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public synchronized int getWidth()
/* 109:    */   {
/* 110:317 */     checkDestroyed();
/* 111:318 */     return this.width;
/* 112:    */   }
/* 113:    */   
/* 114:    */   static {}
/* 115:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.Pbuffer
 * JD-Core Version:    0.7.0.1
 */