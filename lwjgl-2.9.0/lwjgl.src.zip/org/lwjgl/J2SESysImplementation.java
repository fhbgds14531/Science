/*  1:   */ 
/*  2:   */ 
/*  3:   */ java.awt.Toolkit
/*  4:   */ java.awt.datatransfer.Clipboard
/*  5:   */ java.awt.datatransfer.DataFlavor
/*  6:   */ java.awt.datatransfer.Transferable
/*  7:   */ javax.swing.JOptionPane
/*  8:   */ javax.swing.UIManager
/*  9:   */ 
/* 10:   */ J2SESysImplementation
/* 11:   */   
/* 12:   */ 
/* 13:   */   getTime
/* 14:   */   
/* 15:47 */     currentTimeMillis()
/* 16:   */   
/* 17:   */   
/* 18:   */   alert, 
/* 19:   */   
/* 20:   */     
/* 21:   */     
/* 22:52 */       setLookAndFeelgetSystemLookAndFeelClassName()
/* 23:   */     
/* 24:   */      (
/* 25:   */     
/* 26:54 */       log"Caught exception while setting LAF: "
/* 27:   */     
/* 28:56 */     showMessageDialog, , , 2
/* 29:   */   
/* 30:   */   
/* 31:   */   getClipboard
/* 32:   */   
/* 33:   */     
/* 34:   */     
/* 35:61 */        = getDefaultToolkit()getSystemClipboard()
/* 36:62 */        = getContents
/* 37:63 */        (isDataFlavorSupportedstringFlavor {
/* 38:64 */         getTransferDatastringFlavor
/* 39:   */       
/* 40:   */     
/* 41:   */      (
/* 42:   */     
/* 43:67 */       log"Exception while getting clipboard: "
/* 44:   */     
/* 45:69 */     
/* 46:   */   
/* 47:   */ 


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.J2SESysImplementation
 * JD-Core Version:    0.7.0.1
 */