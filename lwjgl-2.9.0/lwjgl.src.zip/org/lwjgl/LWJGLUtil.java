/*   1:    */ 
/*   2:    */ 
/*   3:    */ java.io.File
/*   4:    */ java.io.InputStream
/*   5:    */ java.io.OutputStream
/*   6:    */ java.io.PrintStream
/*   7:    */ java.lang.reflect.Field
/*   8:    */ java.lang.reflect.Method
/*   9:    */ java.nio.ByteBuffer
/*  10:    */ java.security.AccessController
/*  11:    */ java.security.PrivilegedAction
/*  12:    */ java.security.PrivilegedActionException
/*  13:    */ java.security.PrivilegedExceptionAction
/*  14:    */ java.util.ArrayList
/*  15:    */ java.util.Arrays
/*  16:    */ java.util.HashMap
/*  17:    */ java.util.List
/*  18:    */ java.util.Map
/*  19:    */ java.util.StringTokenizer
/*  20:    */ 
/*  21:    */ LWJGLUtil
/*  22:    */ 
/*  23:    */   PLATFORM_LINUX = 1
/*  24:    */   PLATFORM_MACOSX = 2
/*  25:    */   PLATFORM_WINDOWS = 3
/*  26:    */   PLATFORM_LINUX_NAME = "linux"
/*  27:    */   PLATFORM_MACOSX_NAME = "macosx"
/*  28:    */   PLATFORM_WINDOWS_NAME = "windows"
/*  29:    */   LWJGL_ICON_DATA_16x16 = ""
/*  30:    */   LWJGL_ICON_DATA_32x32 = ""
/*  31:259 */   LWJGLIcon16x16 = loadIcon""
/*  32:262 */   LWJGLIcon32x32 = loadIcon""
/*  33:265 */   DEBUG = getPrivilegedBoolean"org.lwjgl.util.Debug"
/*  34:267 */   CHECKS = getPrivilegedBoolean"org.lwjgl.util.NoChecks"
/*  35:    */   PLATFORM
/*  36:    */   
/*  37:    */   static
/*  38:    */   
/*  39:272 */      = getPrivilegedProperty"os.name"
/*  40:273 */      (startsWith"Windows" {
/*  41:274 */       PLATFORM = 3
/*  42:275 */      (startsWith"Linux"startsWith"FreeBSD"startsWith"SunOS"startsWith"Unix" {
/*  43:276 */       PLATFORM = 1
/*  44:277 */      (startsWith"Mac OS X"startsWith"Darwin" {
/*  45:278 */       PLATFORM = 2
/*  46:    */      {
/*  47:280 */       "Unknown platform: "
/*  48:    */     
/*  49:    */   
/*  50:    */   
/*  51:    */   loadIcon
/*  52:    */   
/*  53:284 */      = length()
/*  54:285 */      = createByteBuffer
/*  55:286 */      ( = 0; <; ++ {
/*  56:287 */       put, charAt
/*  57:    */     
/*  58:289 */     asReadOnlyBuffer()
/*  59:    */   
/*  60:    */   
/*  61:    */   getPlatform
/*  62:    */   
/*  63:299 */     PLATFORM
/*  64:    */   
/*  65:    */   
/*  66:    */   getPlatformName
/*  67:    */   
/*  68:310 */      (
/*  69:    */     
/*  70:    */     1: 
/*  71:312 */       "linux"
/*  72:    */     2: 
/*  73:314 */       "macosx"
/*  74:    */     3: 
/*  75:316 */       "windows"
/*  76:    */     
/*  77:318 */     "unknown"
/*  78:    */   
/*  79:    */   
/*  80:    */   []getLibraryPaths, , 
/*  81:    */   
/*  82:331 */     getLibraryPaths, []  }, 
/*  83:    */   
/*  84:    */   
/*  85:    */   []getLibraryPaths, [], 
/*  86:    */   
/*  87:344 */      = ()
/*  88:    */     
/*  89:346 */      = getPathFromClassLoader, 
/*  90:347 */      (!=
/*  91:    */     
/*  92:348 */       log"getPathFromClassLoader: Path found: "
/*  93:349 */       add
/*  94:    */     
/*  95:352 */      ( : 
/*  96:    */     
/*  97:353 */        = getPathFromClassLoader"lwjgl", 
/*  98:354 */        (!=
/*  99:    */       
/* 100:355 */         log"getPathFromClassLoader: Path found: "
/* 101:356 */         addsubstring0, lastIndexOfseparatorseparator
/* 102:    */       
/* 103:361 */        = getPrivilegedProperty"org.lwjgl.librarypath"
/* 104:362 */        (!= {
/* 105:363 */         addseparator
/* 106:    */       
/* 107:367 */        = getPrivilegedProperty"java.library.path"
/* 108:    */       
/* 109:369 */        = , pathSeparator
/* 110:370 */        (hasMoreTokens()
/* 111:    */       
/* 112:371 */          = nextToken()
/* 113:372 */         addseparator
/* 114:    */       
/* 115:376 */        = getPrivilegedProperty"user.dir"
/* 116:377 */       addseparator
/* 117:    */       
/* 118:    */ 
/* 119:380 */       add
/* 120:    */     
/* 121:384 */     []toArraysize()
/* 122:    */   
/* 123:    */   
/* 124:    */   execPrivileged[]
/* 125:    */     
/* 126:    */   
/* 127:    */     
/* 128:    */     
/* 129:389 */        = doPrivileged()
/* 130:    */       
/* 131:    */         run
/* 132:    */           
/* 133:    */         
/* 134:391 */           getRuntime()execval$cmd_array);
/* 135:    */         }
/* 136:394 */       });
/* 137:395 */       process.getInputStream().close();
/* 138:396 */       process.getOutputStream().close();
/* 139:397 */       process.getErrorStream().close();
/* 140:    */     }
/* 141:    */     catch (PrivilegedActionException e)
/* 142:    */     {
/* 143:399 */       throw ((Exception)e.getCause());
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private static String getPrivilegedProperty(String property_name)
/* 148:    */   {
/* 149:404 */     (String)AccessController.doPrivileged(new PrivilegedAction()
/* 150:    */     {
/* 151:    */       public String run()
/* 152:    */       {
/* 153:406 */         return System.getProperty(this.val$property_name);
/* 154:    */       }
/* 155:    */     });
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static String getPathFromClassLoader(final String libname, final ClassLoader classloader)
/* 159:    */   {
/* 160:    */     try
/* 161:    */     {
/* 162:424 */       log("getPathFromClassLoader: searching for: " + libname);
/* 163:425 */       Class<?> c = classloader.getClass();
/* 164:426 */       while (c != null)
/* 165:    */       {
/* 166:427 */         Class<?> clazz = c;
/* 167:    */         try
/* 168:    */         {
/* 169:429 */           (String)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 170:    */           {
/* 171:    */             public String run()
/* 172:    */               throws Exception
/* 173:    */             {
/* 174:431 */               Method findLibrary = this.val$clazz.getDeclaredMethod("findLibrary", new Class[] { String.class });
/* 175:432 */               findLibrary.setAccessible(true);
/* 176:433 */               String path = (String)findLibrary.invoke(classloader, new Object[] { libname });
/* 177:434 */               return path;
/* 178:    */             }
/* 179:    */           });
/* 180:    */         }
/* 181:    */         catch (PrivilegedActionException e)
/* 182:    */         {
/* 183:438 */           log("Failed to locate findLibrary method: " + e.getCause());
/* 184:439 */           c = c.getSuperclass();
/* 185:    */         }
/* 186:    */       }
/* 187:    */     }
/* 188:    */     catch (Exception e)
/* 189:    */     {
/* 190:443 */       log("Failure locating " + e + " using classloader:" + e);
/* 191:    */     }
/* 192:445 */     return null;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static boolean getPrivilegedBoolean(String property_name)
/* 196:    */   {
/* 197:452 */     ((Boolean)AccessController.doPrivileged(new PrivilegedAction()
/* 198:    */     {
/* 199:    */       public Boolean run()
/* 200:    */       {
/* 201:454 */         return Boolean.valueOf(Boolean.getBoolean(this.val$property_name));
/* 202:    */       }
/* 203:    */     })).booleanValue();
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static Integer getPrivilegedInteger(String property_name)
/* 207:    */   {
/* 208:467 */     (Integer)AccessController.doPrivileged(new PrivilegedAction()
/* 209:    */     {
/* 210:    */       public Integer run()
/* 211:    */       {
/* 212:469 */         return Integer.getInteger(this.val$property_name);
/* 213:    */       }
/* 214:    */     });
/* 215:    */   }
/* 216:    */   
/* 217:    */   public static Integer getPrivilegedInteger(String property_name, final int default_val)
/* 218:    */   {
/* 219:483 */     (Integer)AccessController.doPrivileged(new PrivilegedAction()
/* 220:    */     {
/* 221:    */       public Integer run()
/* 222:    */       {
/* 223:485 */         return Integer.getInteger(this.val$property_name, default_val);
/* 224:    */       }
/* 225:    */     });
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static void log(CharSequence msg)
/* 229:    */   {
/* 230:496 */     if (DEBUG) {
/* 231:497 */       System.err.println("[LWJGL] " + msg);
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static boolean isMacOSXEqualsOrBetterThan(int major_required, int minor_required)
/* 236:    */   {
/* 237:507 */     String os_version = getPrivilegedProperty("os.version");
/* 238:508 */     StringTokenizer version_tokenizer = new StringTokenizer(os_version, ".");
/* 239:    */     int major;
/* 240:    */     int minor;
/* 241:    */     try
/* 242:    */     {
/* 243:512 */       String major_str = version_tokenizer.nextToken();
/* 244:513 */       String minor_str = version_tokenizer.nextToken();
/* 245:514 */       major = Integer.parseInt(major_str);
/* 246:515 */       minor = Integer.parseInt(minor_str);
/* 247:    */     }
/* 248:    */     catch (Exception e)
/* 249:    */     {
/* 250:517 */       log("Exception occurred while trying to determine OS version: " + e);
/* 251:    */       
/* 252:519 */       return false;
/* 253:    */     }
/* 254:521 */     return (major > major_required) || ((major == major_required) && (minor >= minor_required));
/* 255:    */   }
/* 256:    */   
/* 257:    */   public static Map<Integer, String> getClassTokens(TokenFilter filter, Map<Integer, String> target, Class... tokenClasses)
/* 258:    */   {
/* 259:539 */     return getClassTokens(filter, target, Arrays.asList(tokenClasses));
/* 260:    */   }
/* 261:    */   
/* 262:    */   public static Map<Integer, String> getClassTokens(TokenFilter filter, Map<Integer, String> target, Iterable<Class> tokenClasses)
/* 263:    */   {
/* 264:556 */     if (target == null) {
/* 265:557 */       target = new HashMap();
/* 266:    */     }
/* 267:559 */     int TOKEN_MODIFIERS = 25;
/* 268:561 */     for (Class tokenClass : tokenClasses) {
/* 269:562 */       for (Field field : tokenClass.getDeclaredFields()) {
/* 270:564 */         if (((field.getModifiers() & 0x19) == 25) && (field.getType() == Integer.TYPE)) {
/* 271:    */           try
/* 272:    */           {
/* 273:566 */             int value = field.getInt(null);
/* 274:567 */             if ((filter == null) || (filter.accept(field, value))) {
/* 275:570 */               if (target.containsKey(Integer.valueOf(value))) {
/* 276:571 */                 target.put(Integer.valueOf(value), toHexString(value));
/* 277:    */               } else {
/* 278:573 */                 target.put(Integer.valueOf(value), field.getName());
/* 279:    */               }
/* 280:    */             }
/* 281:    */           }
/* 282:    */           catch (IllegalAccessException e) {}
/* 283:    */         }
/* 284:    */       }
/* 285:    */     }
/* 286:581 */     return target;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public static String toHexString(int value)
/* 290:    */   {
/* 291:594 */     return "0x" + Integer.toHexString(value).toUpperCase();
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static abstract interface TokenFilter
/* 295:    */   {
/* 296:    */     public abstract boolean accept(Field paramField, int paramInt);
/* 297:    */   }
/* 298:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.LWJGLUtil
 * JD-Core Version:    0.7.0.1
 */