/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ final class WindowsKeycodes
/*   4:    */ {
/*   5:    */   public static final int VK_LBUTTON = 1;
/*   6:    */   public static final int VK_RBUTTON = 2;
/*   7:    */   public static final int VK_CANCEL = 3;
/*   8:    */   public static final int VK_MBUTTON = 4;
/*   9:    */   public static final int VK_XBUTTON1 = 5;
/*  10:    */   public static final int VK_XBUTTON2 = 6;
/*  11:    */   public static final int VK_BACK = 8;
/*  12:    */   public static final int VK_TAB = 9;
/*  13:    */   public static final int VK_CLEAR = 12;
/*  14:    */   public static final int VK_RETURN = 13;
/*  15:    */   public static final int VK_SHIFT = 16;
/*  16:    */   public static final int VK_CONTROL = 17;
/*  17:    */   public static final int VK_MENU = 18;
/*  18:    */   public static final int VK_PAUSE = 19;
/*  19:    */   public static final int VK_CAPITAL = 20;
/*  20:    */   public static final int VK_KANA = 21;
/*  21:    */   public static final int VK_HANGEUL = 21;
/*  22:    */   public static final int VK_HANGUL = 21;
/*  23:    */   public static final int VK_JUNJA = 23;
/*  24:    */   public static final int VK_FINAL = 24;
/*  25:    */   public static final int VK_HANJA = 25;
/*  26:    */   public static final int VK_KANJI = 25;
/*  27:    */   public static final int VK_ESCAPE = 27;
/*  28:    */   public static final int VK_CONVERT = 28;
/*  29:    */   public static final int VK_NONCONVERT = 29;
/*  30:    */   public static final int VK_ACCEPT = 30;
/*  31:    */   public static final int VK_MODECHANGE = 31;
/*  32:    */   public static final int VK_SPACE = 32;
/*  33:    */   public static final int VK_PRIOR = 33;
/*  34:    */   public static final int VK_NEXT = 34;
/*  35:    */   public static final int VK_END = 35;
/*  36:    */   public static final int VK_HOME = 36;
/*  37:    */   public static final int VK_LEFT = 37;
/*  38:    */   public static final int VK_UP = 38;
/*  39:    */   public static final int VK_RIGHT = 39;
/*  40:    */   public static final int VK_DOWN = 40;
/*  41:    */   public static final int VK_SELECT = 41;
/*  42:    */   public static final int VK_PRINT = 42;
/*  43:    */   public static final int VK_EXECUTE = 43;
/*  44:    */   public static final int VK_SNAPSHOT = 44;
/*  45:    */   public static final int VK_INSERT = 45;
/*  46:    */   public static final int VK_DELETE = 46;
/*  47:    */   public static final int VK_HELP = 47;
/*  48:    */   public static final int VK_0 = 48;
/*  49:    */   public static final int VK_1 = 49;
/*  50:    */   public static final int VK_2 = 50;
/*  51:    */   public static final int VK_3 = 51;
/*  52:    */   public static final int VK_4 = 52;
/*  53:    */   public static final int VK_5 = 53;
/*  54:    */   public static final int VK_6 = 54;
/*  55:    */   public static final int VK_7 = 55;
/*  56:    */   public static final int VK_8 = 56;
/*  57:    */   public static final int VK_9 = 57;
/*  58:    */   public static final int VK_A = 65;
/*  59:    */   public static final int VK_B = 66;
/*  60:    */   public static final int VK_C = 67;
/*  61:    */   public static final int VK_D = 68;
/*  62:    */   public static final int VK_E = 69;
/*  63:    */   public static final int VK_F = 70;
/*  64:    */   public static final int VK_G = 71;
/*  65:    */   public static final int VK_H = 72;
/*  66:    */   public static final int VK_I = 73;
/*  67:    */   public static final int VK_J = 74;
/*  68:    */   public static final int VK_K = 75;
/*  69:    */   public static final int VK_L = 76;
/*  70:    */   public static final int VK_M = 77;
/*  71:    */   public static final int VK_N = 78;
/*  72:    */   public static final int VK_O = 79;
/*  73:    */   public static final int VK_P = 80;
/*  74:    */   public static final int VK_Q = 81;
/*  75:    */   public static final int VK_R = 82;
/*  76:    */   public static final int VK_S = 83;
/*  77:    */   public static final int VK_T = 84;
/*  78:    */   public static final int VK_U = 85;
/*  79:    */   public static final int VK_V = 86;
/*  80:    */   public static final int VK_W = 87;
/*  81:    */   public static final int VK_X = 88;
/*  82:    */   public static final int VK_Y = 89;
/*  83:    */   public static final int VK_Z = 90;
/*  84:    */   public static final int VK_LWIN = 91;
/*  85:    */   public static final int VK_RWIN = 92;
/*  86:    */   public static final int VK_APPS = 93;
/*  87:    */   public static final int VK_SLEEP = 95;
/*  88:    */   public static final int VK_NUMPAD0 = 96;
/*  89:    */   public static final int VK_NUMPAD1 = 97;
/*  90:    */   public static final int VK_NUMPAD2 = 98;
/*  91:    */   public static final int VK_NUMPAD3 = 99;
/*  92:    */   public static final int VK_NUMPAD4 = 100;
/*  93:    */   public static final int VK_NUMPAD5 = 101;
/*  94:    */   public static final int VK_NUMPAD6 = 102;
/*  95:    */   public static final int VK_NUMPAD7 = 103;
/*  96:    */   public static final int VK_NUMPAD8 = 104;
/*  97:    */   public static final int VK_NUMPAD9 = 105;
/*  98:    */   public static final int VK_MULTIPLY = 106;
/*  99:    */   public static final int VK_ADD = 107;
/* 100:    */   public static final int VK_SEPARATOR = 108;
/* 101:    */   public static final int VK_SUBTRACT = 109;
/* 102:    */   public static final int VK_DECIMAL = 110;
/* 103:    */   public static final int VK_DIVIDE = 111;
/* 104:    */   public static final int VK_F1 = 112;
/* 105:    */   public static final int VK_F2 = 113;
/* 106:    */   public static final int VK_F3 = 114;
/* 107:    */   public static final int VK_F4 = 115;
/* 108:    */   public static final int VK_F5 = 116;
/* 109:    */   public static final int VK_F6 = 117;
/* 110:    */   public static final int VK_F7 = 118;
/* 111:    */   public static final int VK_F8 = 119;
/* 112:    */   public static final int VK_F9 = 120;
/* 113:    */   public static final int VK_F10 = 121;
/* 114:    */   public static final int VK_F11 = 122;
/* 115:    */   public static final int VK_F12 = 123;
/* 116:    */   public static final int VK_F13 = 124;
/* 117:    */   public static final int VK_F14 = 125;
/* 118:    */   public static final int VK_F15 = 126;
/* 119:    */   public static final int VK_F16 = 127;
/* 120:    */   public static final int VK_F17 = 128;
/* 121:    */   public static final int VK_F18 = 129;
/* 122:    */   public static final int VK_F19 = 130;
/* 123:    */   public static final int VK_F20 = 131;
/* 124:    */   public static final int VK_F21 = 132;
/* 125:    */   public static final int VK_F22 = 133;
/* 126:    */   public static final int VK_F23 = 134;
/* 127:    */   public static final int VK_F24 = 135;
/* 128:    */   public static final int VK_NUMLOCK = 144;
/* 129:    */   public static final int VK_SCROLL = 145;
/* 130:    */   public static final int VK_OEM_NEC_EQUAL = 146;
/* 131:    */   public static final int VK_OEM_FJ_JISHO = 146;
/* 132:    */   public static final int VK_OEM_FJ_MASSHOU = 147;
/* 133:    */   public static final int VK_OEM_FJ_TOUROKU = 148;
/* 134:    */   public static final int VK_OEM_FJ_LOYA = 149;
/* 135:    */   public static final int VK_OEM_FJ_ROYA = 150;
/* 136:    */   public static final int VK_LSHIFT = 160;
/* 137:    */   public static final int VK_RSHIFT = 161;
/* 138:    */   public static final int VK_LCONTROL = 162;
/* 139:    */   public static final int VK_RCONTROL = 163;
/* 140:    */   public static final int VK_LMENU = 164;
/* 141:    */   public static final int VK_RMENU = 165;
/* 142:    */   public static final int VK_BROWSER_BACK = 166;
/* 143:    */   public static final int VK_BROWSER_FORWARD = 167;
/* 144:    */   public static final int VK_BROWSER_REFRESH = 168;
/* 145:    */   public static final int VK_BROWSER_STOP = 169;
/* 146:    */   public static final int VK_BROWSER_SEARCH = 170;
/* 147:    */   public static final int VK_BROWSER_FAVORITES = 171;
/* 148:    */   public static final int VK_BROWSER_HOME = 172;
/* 149:    */   public static final int VK_VOLUME_MUTE = 173;
/* 150:    */   public static final int VK_VOLUME_DOWN = 174;
/* 151:    */   public static final int VK_VOLUME_UP = 175;
/* 152:    */   public static final int VK_MEDIA_NEXT_TRACK = 176;
/* 153:    */   public static final int VK_MEDIA_PREV_TRACK = 177;
/* 154:    */   public static final int VK_MEDIA_STOP = 178;
/* 155:    */   public static final int VK_MEDIA_PLAY_PAUSE = 179;
/* 156:    */   public static final int VK_LAUNCH_MAIL = 180;
/* 157:    */   public static final int VK_LAUNCH_MEDIA_SELECT = 181;
/* 158:    */   public static final int VK_LAUNCH_APP1 = 182;
/* 159:    */   public static final int VK_LAUNCH_APP2 = 183;
/* 160:    */   public static final int VK_OEM_1 = 186;
/* 161:    */   public static final int VK_OEM_PLUS = 187;
/* 162:    */   public static final int VK_OEM_COMMA = 188;
/* 163:    */   public static final int VK_OEM_MINUS = 189;
/* 164:    */   public static final int VK_OEM_PERIOD = 190;
/* 165:    */   public static final int VK_OEM_2 = 191;
/* 166:    */   public static final int VK_OEM_3 = 192;
/* 167:    */   public static final int VK_OEM_4 = 219;
/* 168:    */   public static final int VK_OEM_5 = 220;
/* 169:    */   public static final int VK_OEM_6 = 221;
/* 170:    */   public static final int VK_OEM_7 = 222;
/* 171:    */   public static final int VK_OEM_8 = 223;
/* 172:    */   public static final int VK_OEM_AX = 225;
/* 173:    */   public static final int VK_OEM_102 = 226;
/* 174:    */   public static final int VK_ICO_HELP = 227;
/* 175:    */   public static final int VK_ICO_00 = 228;
/* 176:    */   public static final int VK_PROCESSKEY = 229;
/* 177:    */   public static final int VK_ICO_CLEAR = 230;
/* 178:    */   public static final int VK_PACKET = 231;
/* 179:    */   public static final int VK_OEM_RESET = 233;
/* 180:    */   public static final int VK_OEM_JUMP = 234;
/* 181:    */   public static final int VK_OEM_PA1 = 235;
/* 182:    */   public static final int VK_OEM_PA2 = 236;
/* 183:    */   public static final int VK_OEM_PA3 = 237;
/* 184:    */   public static final int VK_OEM_WSCTRL = 238;
/* 185:    */   public static final int VK_OEM_CUSEL = 239;
/* 186:    */   public static final int VK_OEM_ATTN = 240;
/* 187:    */   public static final int VK_OEM_FINISH = 241;
/* 188:    */   public static final int VK_OEM_COPY = 242;
/* 189:    */   public static final int VK_OEM_AUTO = 243;
/* 190:    */   public static final int VK_OEM_ENLW = 244;
/* 191:    */   public static final int VK_OEM_BACKTAB = 245;
/* 192:    */   public static final int VK_ATTN = 246;
/* 193:    */   public static final int VK_CRSEL = 247;
/* 194:    */   public static final int VK_EXSEL = 248;
/* 195:    */   public static final int VK_EREOF = 249;
/* 196:    */   public static final int VK_PLAY = 250;
/* 197:    */   public static final int VK_ZOOM = 251;
/* 198:    */   public static final int VK_NONAME = 252;
/* 199:    */   public static final int VK_PA1 = 253;
/* 200:    */   public static final int VK_OEM_CLEAR = 254;
/* 201:    */   
/* 202:    */   public static int mapVirtualKeyToLWJGLCode(int virt_key)
/* 203:    */   {
/* 204:326 */     switch (virt_key)
/* 205:    */     {
/* 206:    */     case 27: 
/* 207:328 */       return 1;
/* 208:    */     case 49: 
/* 209:330 */       return 2;
/* 210:    */     case 50: 
/* 211:332 */       return 3;
/* 212:    */     case 51: 
/* 213:334 */       return 4;
/* 214:    */     case 52: 
/* 215:336 */       return 5;
/* 216:    */     case 53: 
/* 217:338 */       return 6;
/* 218:    */     case 54: 
/* 219:340 */       return 7;
/* 220:    */     case 55: 
/* 221:342 */       return 8;
/* 222:    */     case 56: 
/* 223:344 */       return 9;
/* 224:    */     case 57: 
/* 225:346 */       return 10;
/* 226:    */     case 48: 
/* 227:348 */       return 11;
/* 228:    */     case 189: 
/* 229:350 */       return 12;
/* 230:    */     case 187: 
/* 231:352 */       return 13;
/* 232:    */     case 8: 
/* 233:354 */       return 14;
/* 234:    */     case 9: 
/* 235:356 */       return 15;
/* 236:    */     case 81: 
/* 237:358 */       return 16;
/* 238:    */     case 87: 
/* 239:360 */       return 17;
/* 240:    */     case 69: 
/* 241:362 */       return 18;
/* 242:    */     case 82: 
/* 243:364 */       return 19;
/* 244:    */     case 84: 
/* 245:366 */       return 20;
/* 246:    */     case 89: 
/* 247:368 */       return 21;
/* 248:    */     case 85: 
/* 249:370 */       return 22;
/* 250:    */     case 73: 
/* 251:372 */       return 23;
/* 252:    */     case 79: 
/* 253:374 */       return 24;
/* 254:    */     case 80: 
/* 255:376 */       return 25;
/* 256:    */     case 219: 
/* 257:378 */       return 26;
/* 258:    */     case 221: 
/* 259:380 */       return 27;
/* 260:    */     case 13: 
/* 261:382 */       return 28;
/* 262:    */     case 162: 
/* 263:384 */       return 29;
/* 264:    */     case 65: 
/* 265:386 */       return 30;
/* 266:    */     case 83: 
/* 267:388 */       return 31;
/* 268:    */     case 68: 
/* 269:390 */       return 32;
/* 270:    */     case 70: 
/* 271:392 */       return 33;
/* 272:    */     case 71: 
/* 273:394 */       return 34;
/* 274:    */     case 72: 
/* 275:396 */       return 35;
/* 276:    */     case 74: 
/* 277:398 */       return 36;
/* 278:    */     case 75: 
/* 279:400 */       return 37;
/* 280:    */     case 76: 
/* 281:402 */       return 38;
/* 282:    */     case 186: 
/* 283:404 */       return 39;
/* 284:    */     case 222: 
/* 285:406 */       return 40;
/* 286:    */     case 192: 
/* 287:    */     case 223: 
/* 288:409 */       return 41;
/* 289:    */     case 160: 
/* 290:411 */       return 42;
/* 291:    */     case 220: 
/* 292:413 */       return 43;
/* 293:    */     case 90: 
/* 294:415 */       return 44;
/* 295:    */     case 88: 
/* 296:417 */       return 45;
/* 297:    */     case 67: 
/* 298:419 */       return 46;
/* 299:    */     case 86: 
/* 300:421 */       return 47;
/* 301:    */     case 66: 
/* 302:423 */       return 48;
/* 303:    */     case 78: 
/* 304:425 */       return 49;
/* 305:    */     case 77: 
/* 306:427 */       return 50;
/* 307:    */     case 188: 
/* 308:429 */       return 51;
/* 309:    */     case 190: 
/* 310:431 */       return 52;
/* 311:    */     case 191: 
/* 312:433 */       return 53;
/* 313:    */     case 161: 
/* 314:435 */       return 54;
/* 315:    */     case 106: 
/* 316:437 */       return 55;
/* 317:    */     case 164: 
/* 318:439 */       return 56;
/* 319:    */     case 32: 
/* 320:441 */       return 57;
/* 321:    */     case 20: 
/* 322:443 */       return 58;
/* 323:    */     case 112: 
/* 324:445 */       return 59;
/* 325:    */     case 113: 
/* 326:447 */       return 60;
/* 327:    */     case 114: 
/* 328:449 */       return 61;
/* 329:    */     case 115: 
/* 330:451 */       return 62;
/* 331:    */     case 116: 
/* 332:453 */       return 63;
/* 333:    */     case 117: 
/* 334:455 */       return 64;
/* 335:    */     case 118: 
/* 336:457 */       return 65;
/* 337:    */     case 119: 
/* 338:459 */       return 66;
/* 339:    */     case 120: 
/* 340:461 */       return 67;
/* 341:    */     case 121: 
/* 342:463 */       return 68;
/* 343:    */     case 144: 
/* 344:465 */       return 69;
/* 345:    */     case 145: 
/* 346:467 */       return 70;
/* 347:    */     case 103: 
/* 348:469 */       return 71;
/* 349:    */     case 104: 
/* 350:471 */       return 72;
/* 351:    */     case 105: 
/* 352:473 */       return 73;
/* 353:    */     case 109: 
/* 354:475 */       return 74;
/* 355:    */     case 100: 
/* 356:477 */       return 75;
/* 357:    */     case 101: 
/* 358:479 */       return 76;
/* 359:    */     case 102: 
/* 360:481 */       return 77;
/* 361:    */     case 107: 
/* 362:483 */       return 78;
/* 363:    */     case 97: 
/* 364:485 */       return 79;
/* 365:    */     case 98: 
/* 366:487 */       return 80;
/* 367:    */     case 99: 
/* 368:489 */       return 81;
/* 369:    */     case 96: 
/* 370:491 */       return 82;
/* 371:    */     case 110: 
/* 372:493 */       return 83;
/* 373:    */     case 122: 
/* 374:495 */       return 87;
/* 375:    */     case 123: 
/* 376:497 */       return 88;
/* 377:    */     case 124: 
/* 378:499 */       return 100;
/* 379:    */     case 125: 
/* 380:501 */       return 101;
/* 381:    */     case 126: 
/* 382:503 */       return 102;
/* 383:    */     case 21: 
/* 384:505 */       return 112;
/* 385:    */     case 28: 
/* 386:507 */       return 121;
/* 387:    */     case 29: 
/* 388:509 */       return 123;
/* 389:    */     case 25: 
/* 390:523 */       return 148;
/* 391:    */     case 163: 
/* 392:533 */       return 157;
/* 393:    */     case 108: 
/* 394:535 */       return 179;
/* 395:    */     case 111: 
/* 396:537 */       return 181;
/* 397:    */     case 44: 
/* 398:539 */       return 183;
/* 399:    */     case 165: 
/* 400:541 */       return 184;
/* 401:    */     case 19: 
/* 402:543 */       return 197;
/* 403:    */     case 36: 
/* 404:545 */       return 199;
/* 405:    */     case 38: 
/* 406:547 */       return 200;
/* 407:    */     case 33: 
/* 408:549 */       return 201;
/* 409:    */     case 37: 
/* 410:551 */       return 203;
/* 411:    */     case 39: 
/* 412:553 */       return 205;
/* 413:    */     case 35: 
/* 414:555 */       return 207;
/* 415:    */     case 40: 
/* 416:557 */       return 208;
/* 417:    */     case 34: 
/* 418:559 */       return 209;
/* 419:    */     case 45: 
/* 420:561 */       return 210;
/* 421:    */     case 46: 
/* 422:563 */       return 211;
/* 423:    */     case 91: 
/* 424:565 */       return 219;
/* 425:    */     case 92: 
/* 426:567 */       return 220;
/* 427:    */     case 93: 
/* 428:569 */       return 221;
/* 429:    */     case 95: 
/* 430:573 */       return 223;
/* 431:    */     }
/* 432:575 */     return 0;
/* 433:    */   }
/* 434:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsKeycodes
 * JD-Core Version:    0.7.0.1
 */