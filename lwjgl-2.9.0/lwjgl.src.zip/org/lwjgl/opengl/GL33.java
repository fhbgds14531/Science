/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import java.nio.LongBuffer;
/*   7:    */ import org.lwjgl.BufferChecks;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public final class GL33
/*  11:    */ {
/*  12:    */   public static final int GL_SRC1_COLOR = 35065;
/*  13:    */   public static final int GL_SRC1_ALPHA = 34185;
/*  14:    */   public static final int GL_ONE_MINUS_SRC1_COLOR = 35066;
/*  15:    */   public static final int GL_ONE_MINUS_SRC1_ALPHA = 35067;
/*  16:    */   public static final int GL_MAX_DUAL_SOURCE_DRAW_BUFFERS = 35068;
/*  17:    */   public static final int GL_ANY_SAMPLES_PASSED = 35887;
/*  18:    */   public static final int GL_SAMPLER_BINDING = 35097;
/*  19:    */   public static final int GL_RGB10_A2UI = 36975;
/*  20:    */   public static final int GL_TEXTURE_SWIZZLE_R = 36418;
/*  21:    */   public static final int GL_TEXTURE_SWIZZLE_G = 36419;
/*  22:    */   public static final int GL_TEXTURE_SWIZZLE_B = 36420;
/*  23:    */   public static final int GL_TEXTURE_SWIZZLE_A = 36421;
/*  24:    */   public static final int GL_TEXTURE_SWIZZLE_RGBA = 36422;
/*  25:    */   public static final int GL_TIME_ELAPSED = 35007;
/*  26:    */   public static final int GL_TIMESTAMP = 36392;
/*  27:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_DIVISOR = 35070;
/*  28:    */   public static final int GL_INT_2_10_10_10_REV = 36255;
/*  29:    */   
/*  30:    */   public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, ByteBuffer name)
/*  31:    */   {
/*  32: 91 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  33: 92 */     long function_pointer = caps.glBindFragDataLocationIndexed;
/*  34: 93 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  35: 94 */     BufferChecks.checkDirect(name);
/*  36: 95 */     BufferChecks.checkNullTerminated(name);
/*  37: 96 */     nglBindFragDataLocationIndexed(program, colorNumber, index, MemoryUtil.getAddress(name), function_pointer);
/*  38:    */   }
/*  39:    */   
/*  40:    */   static native void nglBindFragDataLocationIndexed(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  41:    */   
/*  42:    */   public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, CharSequence name)
/*  43:    */   {
/*  44:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  45:103 */     long function_pointer = caps.glBindFragDataLocationIndexed;
/*  46:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  47:105 */     nglBindFragDataLocationIndexed(program, colorNumber, index, APIUtil.getBufferNT(caps, name), function_pointer);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static int glGetFragDataIndex(int program, ByteBuffer name)
/*  51:    */   {
/*  52:109 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  53:110 */     long function_pointer = caps.glGetFragDataIndex;
/*  54:111 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  55:112 */     BufferChecks.checkDirect(name);
/*  56:113 */     BufferChecks.checkNullTerminated(name);
/*  57:114 */     int __result = nglGetFragDataIndex(program, MemoryUtil.getAddress(name), function_pointer);
/*  58:115 */     return __result;
/*  59:    */   }
/*  60:    */   
/*  61:    */   static native int nglGetFragDataIndex(int paramInt, long paramLong1, long paramLong2);
/*  62:    */   
/*  63:    */   public static int glGetFragDataIndex(int program, CharSequence name)
/*  64:    */   {
/*  65:121 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  66:122 */     long function_pointer = caps.glGetFragDataIndex;
/*  67:123 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  68:124 */     int __result = nglGetFragDataIndex(program, APIUtil.getBufferNT(caps, name), function_pointer);
/*  69:125 */     return __result;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static void glGenSamplers(IntBuffer samplers)
/*  73:    */   {
/*  74:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  75:130 */     long function_pointer = caps.glGenSamplers;
/*  76:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  77:132 */     BufferChecks.checkDirect(samplers);
/*  78:133 */     nglGenSamplers(samplers.remaining(), MemoryUtil.getAddress(samplers), function_pointer);
/*  79:    */   }
/*  80:    */   
/*  81:    */   static native void nglGenSamplers(int paramInt, long paramLong1, long paramLong2);
/*  82:    */   
/*  83:    */   public static int glGenSamplers()
/*  84:    */   {
/*  85:139 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  86:140 */     long function_pointer = caps.glGenSamplers;
/*  87:141 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  88:142 */     IntBuffer samplers = APIUtil.getBufferInt(caps);
/*  89:143 */     nglGenSamplers(1, MemoryUtil.getAddress(samplers), function_pointer);
/*  90:144 */     return samplers.get(0);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static void glDeleteSamplers(IntBuffer samplers)
/*  94:    */   {
/*  95:148 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  96:149 */     long function_pointer = caps.glDeleteSamplers;
/*  97:150 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  98:151 */     BufferChecks.checkDirect(samplers);
/*  99:152 */     nglDeleteSamplers(samplers.remaining(), MemoryUtil.getAddress(samplers), function_pointer);
/* 100:    */   }
/* 101:    */   
/* 102:    */   static native void nglDeleteSamplers(int paramInt, long paramLong1, long paramLong2);
/* 103:    */   
/* 104:    */   public static void glDeleteSamplers(int sampler)
/* 105:    */   {
/* 106:158 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 107:159 */     long function_pointer = caps.glDeleteSamplers;
/* 108:160 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 109:161 */     nglDeleteSamplers(1, APIUtil.getInt(caps, sampler), function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static boolean glIsSampler(int sampler)
/* 113:    */   {
/* 114:165 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:166 */     long function_pointer = caps.glIsSampler;
/* 116:167 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:168 */     boolean __result = nglIsSampler(sampler, function_pointer);
/* 118:169 */     return __result;
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native boolean nglIsSampler(int paramInt, long paramLong);
/* 122:    */   
/* 123:    */   public static void glBindSampler(int unit, int sampler)
/* 124:    */   {
/* 125:174 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:175 */     long function_pointer = caps.glBindSampler;
/* 127:176 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:177 */     nglBindSampler(unit, sampler, function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglBindSampler(int paramInt1, int paramInt2, long paramLong);
/* 132:    */   
/* 133:    */   public static void glSamplerParameteri(int sampler, int pname, int param)
/* 134:    */   {
/* 135:182 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 136:183 */     long function_pointer = caps.glSamplerParameteri;
/* 137:184 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 138:185 */     nglSamplerParameteri(sampler, pname, param, function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglSamplerParameteri(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 142:    */   
/* 143:    */   public static void glSamplerParameterf(int sampler, int pname, float param)
/* 144:    */   {
/* 145:190 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 146:191 */     long function_pointer = caps.glSamplerParameterf;
/* 147:192 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 148:193 */     nglSamplerParameterf(sampler, pname, param, function_pointer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   static native void nglSamplerParameterf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 152:    */   
/* 153:    */   public static void glSamplerParameter(int sampler, int pname, IntBuffer params)
/* 154:    */   {
/* 155:198 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 156:199 */     long function_pointer = caps.glSamplerParameteriv;
/* 157:200 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 158:201 */     BufferChecks.checkBuffer(params, 4);
/* 159:202 */     nglSamplerParameteriv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 160:    */   }
/* 161:    */   
/* 162:    */   static native void nglSamplerParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 163:    */   
/* 164:    */   public static void glSamplerParameter(int sampler, int pname, FloatBuffer params)
/* 165:    */   {
/* 166:207 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 167:208 */     long function_pointer = caps.glSamplerParameterfv;
/* 168:209 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 169:210 */     BufferChecks.checkBuffer(params, 4);
/* 170:211 */     nglSamplerParameterfv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 171:    */   }
/* 172:    */   
/* 173:    */   static native void nglSamplerParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 174:    */   
/* 175:    */   public static void glSamplerParameterI(int sampler, int pname, IntBuffer params)
/* 176:    */   {
/* 177:216 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 178:217 */     long function_pointer = caps.glSamplerParameterIiv;
/* 179:218 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 180:219 */     BufferChecks.checkBuffer(params, 4);
/* 181:220 */     nglSamplerParameterIiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 182:    */   }
/* 183:    */   
/* 184:    */   static native void nglSamplerParameterIiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 185:    */   
/* 186:    */   public static void glSamplerParameterIu(int sampler, int pname, IntBuffer params)
/* 187:    */   {
/* 188:225 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 189:226 */     long function_pointer = caps.glSamplerParameterIuiv;
/* 190:227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 191:228 */     BufferChecks.checkBuffer(params, 4);
/* 192:229 */     nglSamplerParameterIuiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   static native void nglSamplerParameterIuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 196:    */   
/* 197:    */   public static void glGetSamplerParameter(int sampler, int pname, IntBuffer params)
/* 198:    */   {
/* 199:234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:235 */     long function_pointer = caps.glGetSamplerParameteriv;
/* 201:236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:237 */     BufferChecks.checkBuffer(params, 4);
/* 203:238 */     nglGetSamplerParameteriv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   static native void nglGetSamplerParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 207:    */   
/* 208:    */   public static int glGetSamplerParameteri(int sampler, int pname)
/* 209:    */   {
/* 210:244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 211:245 */     long function_pointer = caps.glGetSamplerParameteriv;
/* 212:246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 213:247 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 214:248 */     nglGetSamplerParameteriv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 215:249 */     return params.get(0);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static void glGetSamplerParameter(int sampler, int pname, FloatBuffer params)
/* 219:    */   {
/* 220:253 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 221:254 */     long function_pointer = caps.glGetSamplerParameterfv;
/* 222:255 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 223:256 */     BufferChecks.checkBuffer(params, 4);
/* 224:257 */     nglGetSamplerParameterfv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 225:    */   }
/* 226:    */   
/* 227:    */   static native void nglGetSamplerParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 228:    */   
/* 229:    */   public static float glGetSamplerParameterf(int sampler, int pname)
/* 230:    */   {
/* 231:263 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 232:264 */     long function_pointer = caps.glGetSamplerParameterfv;
/* 233:265 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 234:266 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 235:267 */     nglGetSamplerParameterfv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 236:268 */     return params.get(0);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static void glGetSamplerParameterI(int sampler, int pname, IntBuffer params)
/* 240:    */   {
/* 241:272 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 242:273 */     long function_pointer = caps.glGetSamplerParameterIiv;
/* 243:274 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 244:275 */     BufferChecks.checkBuffer(params, 4);
/* 245:276 */     nglGetSamplerParameterIiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 246:    */   }
/* 247:    */   
/* 248:    */   static native void nglGetSamplerParameterIiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 249:    */   
/* 250:    */   public static int glGetSamplerParameterIi(int sampler, int pname)
/* 251:    */   {
/* 252:282 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 253:283 */     long function_pointer = caps.glGetSamplerParameterIiv;
/* 254:284 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 255:285 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 256:286 */     nglGetSamplerParameterIiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 257:287 */     return params.get(0);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public static void glGetSamplerParameterIu(int sampler, int pname, IntBuffer params)
/* 261:    */   {
/* 262:291 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 263:292 */     long function_pointer = caps.glGetSamplerParameterIuiv;
/* 264:293 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 265:294 */     BufferChecks.checkBuffer(params, 4);
/* 266:295 */     nglGetSamplerParameterIuiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 267:    */   }
/* 268:    */   
/* 269:    */   static native void nglGetSamplerParameterIuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 270:    */   
/* 271:    */   public static int glGetSamplerParameterIui(int sampler, int pname)
/* 272:    */   {
/* 273:301 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 274:302 */     long function_pointer = caps.glGetSamplerParameterIuiv;
/* 275:303 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 276:304 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 277:305 */     nglGetSamplerParameterIuiv(sampler, pname, MemoryUtil.getAddress(params), function_pointer);
/* 278:306 */     return params.get(0);
/* 279:    */   }
/* 280:    */   
/* 281:    */   public static void glQueryCounter(int id, int target)
/* 282:    */   {
/* 283:310 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 284:311 */     long function_pointer = caps.glQueryCounter;
/* 285:312 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 286:313 */     nglQueryCounter(id, target, function_pointer);
/* 287:    */   }
/* 288:    */   
/* 289:    */   static native void nglQueryCounter(int paramInt1, int paramInt2, long paramLong);
/* 290:    */   
/* 291:    */   public static void glGetQueryObject(int id, int pname, LongBuffer params)
/* 292:    */   {
/* 293:318 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 294:319 */     long function_pointer = caps.glGetQueryObjecti64v;
/* 295:320 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 296:321 */     BufferChecks.checkBuffer(params, 1);
/* 297:322 */     nglGetQueryObjecti64v(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 298:    */   }
/* 299:    */   
/* 300:    */   static native void nglGetQueryObjecti64v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 301:    */   
/* 302:    */   @Deprecated
/* 303:    */   public static long glGetQueryObject(int id, int pname)
/* 304:    */   {
/* 305:333 */     return glGetQueryObjecti64(id, pname);
/* 306:    */   }
/* 307:    */   
/* 308:    */   public static long glGetQueryObjecti64(int id, int pname)
/* 309:    */   {
/* 310:338 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 311:339 */     long function_pointer = caps.glGetQueryObjecti64v;
/* 312:340 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 313:341 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 314:342 */     nglGetQueryObjecti64v(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 315:343 */     return params.get(0);
/* 316:    */   }
/* 317:    */   
/* 318:    */   public static void glGetQueryObjectu(int id, int pname, LongBuffer params)
/* 319:    */   {
/* 320:347 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 321:348 */     long function_pointer = caps.glGetQueryObjectui64v;
/* 322:349 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 323:350 */     BufferChecks.checkBuffer(params, 1);
/* 324:351 */     nglGetQueryObjectui64v(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 325:    */   }
/* 326:    */   
/* 327:    */   static native void nglGetQueryObjectui64v(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 328:    */   
/* 329:    */   @Deprecated
/* 330:    */   public static long glGetQueryObjectu(int id, int pname)
/* 331:    */   {
/* 332:362 */     return glGetQueryObjectui64(id, pname);
/* 333:    */   }
/* 334:    */   
/* 335:    */   public static long glGetQueryObjectui64(int id, int pname)
/* 336:    */   {
/* 337:367 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 338:368 */     long function_pointer = caps.glGetQueryObjectui64v;
/* 339:369 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 340:370 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 341:371 */     nglGetQueryObjectui64v(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 342:372 */     return params.get(0);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public static void glVertexAttribDivisor(int index, int divisor)
/* 346:    */   {
/* 347:376 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 348:377 */     long function_pointer = caps.glVertexAttribDivisor;
/* 349:378 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 350:379 */     nglVertexAttribDivisor(index, divisor, function_pointer);
/* 351:    */   }
/* 352:    */   
/* 353:    */   static native void nglVertexAttribDivisor(int paramInt1, int paramInt2, long paramLong);
/* 354:    */   
/* 355:    */   public static void glVertexP2ui(int type, int value)
/* 356:    */   {
/* 357:384 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 358:385 */     long function_pointer = caps.glVertexP2ui;
/* 359:386 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 360:387 */     nglVertexP2ui(type, value, function_pointer);
/* 361:    */   }
/* 362:    */   
/* 363:    */   static native void nglVertexP2ui(int paramInt1, int paramInt2, long paramLong);
/* 364:    */   
/* 365:    */   public static void glVertexP3ui(int type, int value)
/* 366:    */   {
/* 367:392 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 368:393 */     long function_pointer = caps.glVertexP3ui;
/* 369:394 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 370:395 */     nglVertexP3ui(type, value, function_pointer);
/* 371:    */   }
/* 372:    */   
/* 373:    */   static native void nglVertexP3ui(int paramInt1, int paramInt2, long paramLong);
/* 374:    */   
/* 375:    */   public static void glVertexP4ui(int type, int value)
/* 376:    */   {
/* 377:400 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 378:401 */     long function_pointer = caps.glVertexP4ui;
/* 379:402 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 380:403 */     nglVertexP4ui(type, value, function_pointer);
/* 381:    */   }
/* 382:    */   
/* 383:    */   static native void nglVertexP4ui(int paramInt1, int paramInt2, long paramLong);
/* 384:    */   
/* 385:    */   public static void glVertexP2u(int type, IntBuffer value)
/* 386:    */   {
/* 387:408 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 388:409 */     long function_pointer = caps.glVertexP2uiv;
/* 389:410 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 390:411 */     BufferChecks.checkBuffer(value, 2);
/* 391:412 */     nglVertexP2uiv(type, MemoryUtil.getAddress(value), function_pointer);
/* 392:    */   }
/* 393:    */   
/* 394:    */   static native void nglVertexP2uiv(int paramInt, long paramLong1, long paramLong2);
/* 395:    */   
/* 396:    */   public static void glVertexP3u(int type, IntBuffer value)
/* 397:    */   {
/* 398:417 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 399:418 */     long function_pointer = caps.glVertexP3uiv;
/* 400:419 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 401:420 */     BufferChecks.checkBuffer(value, 3);
/* 402:421 */     nglVertexP3uiv(type, MemoryUtil.getAddress(value), function_pointer);
/* 403:    */   }
/* 404:    */   
/* 405:    */   static native void nglVertexP3uiv(int paramInt, long paramLong1, long paramLong2);
/* 406:    */   
/* 407:    */   public static void glVertexP4u(int type, IntBuffer value)
/* 408:    */   {
/* 409:426 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 410:427 */     long function_pointer = caps.glVertexP4uiv;
/* 411:428 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 412:429 */     BufferChecks.checkBuffer(value, 4);
/* 413:430 */     nglVertexP4uiv(type, MemoryUtil.getAddress(value), function_pointer);
/* 414:    */   }
/* 415:    */   
/* 416:    */   static native void nglVertexP4uiv(int paramInt, long paramLong1, long paramLong2);
/* 417:    */   
/* 418:    */   public static void glTexCoordP1ui(int type, int coords)
/* 419:    */   {
/* 420:435 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 421:436 */     long function_pointer = caps.glTexCoordP1ui;
/* 422:437 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 423:438 */     nglTexCoordP1ui(type, coords, function_pointer);
/* 424:    */   }
/* 425:    */   
/* 426:    */   static native void nglTexCoordP1ui(int paramInt1, int paramInt2, long paramLong);
/* 427:    */   
/* 428:    */   public static void glTexCoordP2ui(int type, int coords)
/* 429:    */   {
/* 430:443 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 431:444 */     long function_pointer = caps.glTexCoordP2ui;
/* 432:445 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 433:446 */     nglTexCoordP2ui(type, coords, function_pointer);
/* 434:    */   }
/* 435:    */   
/* 436:    */   static native void nglTexCoordP2ui(int paramInt1, int paramInt2, long paramLong);
/* 437:    */   
/* 438:    */   public static void glTexCoordP3ui(int type, int coords)
/* 439:    */   {
/* 440:451 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 441:452 */     long function_pointer = caps.glTexCoordP3ui;
/* 442:453 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 443:454 */     nglTexCoordP3ui(type, coords, function_pointer);
/* 444:    */   }
/* 445:    */   
/* 446:    */   static native void nglTexCoordP3ui(int paramInt1, int paramInt2, long paramLong);
/* 447:    */   
/* 448:    */   public static void glTexCoordP4ui(int type, int coords)
/* 449:    */   {
/* 450:459 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 451:460 */     long function_pointer = caps.glTexCoordP4ui;
/* 452:461 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 453:462 */     nglTexCoordP4ui(type, coords, function_pointer);
/* 454:    */   }
/* 455:    */   
/* 456:    */   static native void nglTexCoordP4ui(int paramInt1, int paramInt2, long paramLong);
/* 457:    */   
/* 458:    */   public static void glTexCoordP1u(int type, IntBuffer coords)
/* 459:    */   {
/* 460:467 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 461:468 */     long function_pointer = caps.glTexCoordP1uiv;
/* 462:469 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 463:470 */     BufferChecks.checkBuffer(coords, 1);
/* 464:471 */     nglTexCoordP1uiv(type, MemoryUtil.getAddress(coords), function_pointer);
/* 465:    */   }
/* 466:    */   
/* 467:    */   static native void nglTexCoordP1uiv(int paramInt, long paramLong1, long paramLong2);
/* 468:    */   
/* 469:    */   public static void glTexCoordP2u(int type, IntBuffer coords)
/* 470:    */   {
/* 471:476 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 472:477 */     long function_pointer = caps.glTexCoordP2uiv;
/* 473:478 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 474:479 */     BufferChecks.checkBuffer(coords, 2);
/* 475:480 */     nglTexCoordP2uiv(type, MemoryUtil.getAddress(coords), function_pointer);
/* 476:    */   }
/* 477:    */   
/* 478:    */   static native void nglTexCoordP2uiv(int paramInt, long paramLong1, long paramLong2);
/* 479:    */   
/* 480:    */   public static void glTexCoordP3u(int type, IntBuffer coords)
/* 481:    */   {
/* 482:485 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 483:486 */     long function_pointer = caps.glTexCoordP3uiv;
/* 484:487 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 485:488 */     BufferChecks.checkBuffer(coords, 3);
/* 486:489 */     nglTexCoordP3uiv(type, MemoryUtil.getAddress(coords), function_pointer);
/* 487:    */   }
/* 488:    */   
/* 489:    */   static native void nglTexCoordP3uiv(int paramInt, long paramLong1, long paramLong2);
/* 490:    */   
/* 491:    */   public static void glTexCoordP4u(int type, IntBuffer coords)
/* 492:    */   {
/* 493:494 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 494:495 */     long function_pointer = caps.glTexCoordP4uiv;
/* 495:496 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 496:497 */     BufferChecks.checkBuffer(coords, 4);
/* 497:498 */     nglTexCoordP4uiv(type, MemoryUtil.getAddress(coords), function_pointer);
/* 498:    */   }
/* 499:    */   
/* 500:    */   static native void nglTexCoordP4uiv(int paramInt, long paramLong1, long paramLong2);
/* 501:    */   
/* 502:    */   public static void glMultiTexCoordP1ui(int texture, int type, int coords)
/* 503:    */   {
/* 504:503 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 505:504 */     long function_pointer = caps.glMultiTexCoordP1ui;
/* 506:505 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 507:506 */     nglMultiTexCoordP1ui(texture, type, coords, function_pointer);
/* 508:    */   }
/* 509:    */   
/* 510:    */   static native void nglMultiTexCoordP1ui(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 511:    */   
/* 512:    */   public static void glMultiTexCoordP2ui(int texture, int type, int coords)
/* 513:    */   {
/* 514:511 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 515:512 */     long function_pointer = caps.glMultiTexCoordP2ui;
/* 516:513 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 517:514 */     nglMultiTexCoordP2ui(texture, type, coords, function_pointer);
/* 518:    */   }
/* 519:    */   
/* 520:    */   static native void nglMultiTexCoordP2ui(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 521:    */   
/* 522:    */   public static void glMultiTexCoordP3ui(int texture, int type, int coords)
/* 523:    */   {
/* 524:519 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 525:520 */     long function_pointer = caps.glMultiTexCoordP3ui;
/* 526:521 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 527:522 */     nglMultiTexCoordP3ui(texture, type, coords, function_pointer);
/* 528:    */   }
/* 529:    */   
/* 530:    */   static native void nglMultiTexCoordP3ui(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 531:    */   
/* 532:    */   public static void glMultiTexCoordP4ui(int texture, int type, int coords)
/* 533:    */   {
/* 534:527 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 535:528 */     long function_pointer = caps.glMultiTexCoordP4ui;
/* 536:529 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 537:530 */     nglMultiTexCoordP4ui(texture, type, coords, function_pointer);
/* 538:    */   }
/* 539:    */   
/* 540:    */   static native void nglMultiTexCoordP4ui(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 541:    */   
/* 542:    */   public static void glMultiTexCoordP1u(int texture, int type, IntBuffer coords)
/* 543:    */   {
/* 544:535 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 545:536 */     long function_pointer = caps.glMultiTexCoordP1uiv;
/* 546:537 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 547:538 */     BufferChecks.checkBuffer(coords, 1);
/* 548:539 */     nglMultiTexCoordP1uiv(texture, type, MemoryUtil.getAddress(coords), function_pointer);
/* 549:    */   }
/* 550:    */   
/* 551:    */   static native void nglMultiTexCoordP1uiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 552:    */   
/* 553:    */   public static void glMultiTexCoordP2u(int texture, int type, IntBuffer coords)
/* 554:    */   {
/* 555:544 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 556:545 */     long function_pointer = caps.glMultiTexCoordP2uiv;
/* 557:546 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 558:547 */     BufferChecks.checkBuffer(coords, 2);
/* 559:548 */     nglMultiTexCoordP2uiv(texture, type, MemoryUtil.getAddress(coords), function_pointer);
/* 560:    */   }
/* 561:    */   
/* 562:    */   static native void nglMultiTexCoordP2uiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 563:    */   
/* 564:    */   public static void glMultiTexCoordP3u(int texture, int type, IntBuffer coords)
/* 565:    */   {
/* 566:553 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 567:554 */     long function_pointer = caps.glMultiTexCoordP3uiv;
/* 568:555 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 569:556 */     BufferChecks.checkBuffer(coords, 3);
/* 570:557 */     nglMultiTexCoordP3uiv(texture, type, MemoryUtil.getAddress(coords), function_pointer);
/* 571:    */   }
/* 572:    */   
/* 573:    */   static native void nglMultiTexCoordP3uiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 574:    */   
/* 575:    */   public static void glMultiTexCoordP4u(int texture, int type, IntBuffer coords)
/* 576:    */   {
/* 577:562 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 578:563 */     long function_pointer = caps.glMultiTexCoordP4uiv;
/* 579:564 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 580:565 */     BufferChecks.checkBuffer(coords, 4);
/* 581:566 */     nglMultiTexCoordP4uiv(texture, type, MemoryUtil.getAddress(coords), function_pointer);
/* 582:    */   }
/* 583:    */   
/* 584:    */   static native void nglMultiTexCoordP4uiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 585:    */   
/* 586:    */   public static void glNormalP3ui(int type, int coords)
/* 587:    */   {
/* 588:571 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 589:572 */     long function_pointer = caps.glNormalP3ui;
/* 590:573 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 591:574 */     nglNormalP3ui(type, coords, function_pointer);
/* 592:    */   }
/* 593:    */   
/* 594:    */   static native void nglNormalP3ui(int paramInt1, int paramInt2, long paramLong);
/* 595:    */   
/* 596:    */   public static void glNormalP3u(int type, IntBuffer coords)
/* 597:    */   {
/* 598:579 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 599:580 */     long function_pointer = caps.glNormalP3uiv;
/* 600:581 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 601:582 */     BufferChecks.checkBuffer(coords, 3);
/* 602:583 */     nglNormalP3uiv(type, MemoryUtil.getAddress(coords), function_pointer);
/* 603:    */   }
/* 604:    */   
/* 605:    */   static native void nglNormalP3uiv(int paramInt, long paramLong1, long paramLong2);
/* 606:    */   
/* 607:    */   public static void glColorP3ui(int type, int color)
/* 608:    */   {
/* 609:588 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 610:589 */     long function_pointer = caps.glColorP3ui;
/* 611:590 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 612:591 */     nglColorP3ui(type, color, function_pointer);
/* 613:    */   }
/* 614:    */   
/* 615:    */   static native void nglColorP3ui(int paramInt1, int paramInt2, long paramLong);
/* 616:    */   
/* 617:    */   public static void glColorP4ui(int type, int color)
/* 618:    */   {
/* 619:596 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 620:597 */     long function_pointer = caps.glColorP4ui;
/* 621:598 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 622:599 */     nglColorP4ui(type, color, function_pointer);
/* 623:    */   }
/* 624:    */   
/* 625:    */   static native void nglColorP4ui(int paramInt1, int paramInt2, long paramLong);
/* 626:    */   
/* 627:    */   public static void glColorP3u(int type, IntBuffer color)
/* 628:    */   {
/* 629:604 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 630:605 */     long function_pointer = caps.glColorP3uiv;
/* 631:606 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 632:607 */     BufferChecks.checkBuffer(color, 3);
/* 633:608 */     nglColorP3uiv(type, MemoryUtil.getAddress(color), function_pointer);
/* 634:    */   }
/* 635:    */   
/* 636:    */   static native void nglColorP3uiv(int paramInt, long paramLong1, long paramLong2);
/* 637:    */   
/* 638:    */   public static void glColorP4u(int type, IntBuffer color)
/* 639:    */   {
/* 640:613 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 641:614 */     long function_pointer = caps.glColorP4uiv;
/* 642:615 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 643:616 */     BufferChecks.checkBuffer(color, 4);
/* 644:617 */     nglColorP4uiv(type, MemoryUtil.getAddress(color), function_pointer);
/* 645:    */   }
/* 646:    */   
/* 647:    */   static native void nglColorP4uiv(int paramInt, long paramLong1, long paramLong2);
/* 648:    */   
/* 649:    */   public static void glSecondaryColorP3ui(int type, int color)
/* 650:    */   {
/* 651:622 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 652:623 */     long function_pointer = caps.glSecondaryColorP3ui;
/* 653:624 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 654:625 */     nglSecondaryColorP3ui(type, color, function_pointer);
/* 655:    */   }
/* 656:    */   
/* 657:    */   static native void nglSecondaryColorP3ui(int paramInt1, int paramInt2, long paramLong);
/* 658:    */   
/* 659:    */   public static void glSecondaryColorP3u(int type, IntBuffer color)
/* 660:    */   {
/* 661:630 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 662:631 */     long function_pointer = caps.glSecondaryColorP3uiv;
/* 663:632 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 664:633 */     BufferChecks.checkBuffer(color, 3);
/* 665:634 */     nglSecondaryColorP3uiv(type, MemoryUtil.getAddress(color), function_pointer);
/* 666:    */   }
/* 667:    */   
/* 668:    */   static native void nglSecondaryColorP3uiv(int paramInt, long paramLong1, long paramLong2);
/* 669:    */   
/* 670:    */   public static void glVertexAttribP1ui(int index, int type, boolean normalized, int value)
/* 671:    */   {
/* 672:639 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 673:640 */     long function_pointer = caps.glVertexAttribP1ui;
/* 674:641 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 675:642 */     nglVertexAttribP1ui(index, type, normalized, value, function_pointer);
/* 676:    */   }
/* 677:    */   
/* 678:    */   static native void nglVertexAttribP1ui(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, long paramLong);
/* 679:    */   
/* 680:    */   public static void glVertexAttribP2ui(int index, int type, boolean normalized, int value)
/* 681:    */   {
/* 682:647 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 683:648 */     long function_pointer = caps.glVertexAttribP2ui;
/* 684:649 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 685:650 */     nglVertexAttribP2ui(index, type, normalized, value, function_pointer);
/* 686:    */   }
/* 687:    */   
/* 688:    */   static native void nglVertexAttribP2ui(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, long paramLong);
/* 689:    */   
/* 690:    */   public static void glVertexAttribP3ui(int index, int type, boolean normalized, int value)
/* 691:    */   {
/* 692:655 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 693:656 */     long function_pointer = caps.glVertexAttribP3ui;
/* 694:657 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 695:658 */     nglVertexAttribP3ui(index, type, normalized, value, function_pointer);
/* 696:    */   }
/* 697:    */   
/* 698:    */   static native void nglVertexAttribP3ui(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, long paramLong);
/* 699:    */   
/* 700:    */   public static void glVertexAttribP4ui(int index, int type, boolean normalized, int value)
/* 701:    */   {
/* 702:663 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 703:664 */     long function_pointer = caps.glVertexAttribP4ui;
/* 704:665 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 705:666 */     nglVertexAttribP4ui(index, type, normalized, value, function_pointer);
/* 706:    */   }
/* 707:    */   
/* 708:    */   static native void nglVertexAttribP4ui(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, long paramLong);
/* 709:    */   
/* 710:    */   public static void glVertexAttribP1u(int index, int type, boolean normalized, IntBuffer value)
/* 711:    */   {
/* 712:671 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 713:672 */     long function_pointer = caps.glVertexAttribP1uiv;
/* 714:673 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 715:674 */     BufferChecks.checkBuffer(value, 1);
/* 716:675 */     nglVertexAttribP1uiv(index, type, normalized, MemoryUtil.getAddress(value), function_pointer);
/* 717:    */   }
/* 718:    */   
/* 719:    */   static native void nglVertexAttribP1uiv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 720:    */   
/* 721:    */   public static void glVertexAttribP2u(int index, int type, boolean normalized, IntBuffer value)
/* 722:    */   {
/* 723:680 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 724:681 */     long function_pointer = caps.glVertexAttribP2uiv;
/* 725:682 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 726:683 */     BufferChecks.checkBuffer(value, 2);
/* 727:684 */     nglVertexAttribP2uiv(index, type, normalized, MemoryUtil.getAddress(value), function_pointer);
/* 728:    */   }
/* 729:    */   
/* 730:    */   static native void nglVertexAttribP2uiv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 731:    */   
/* 732:    */   public static void glVertexAttribP3u(int index, int type, boolean normalized, IntBuffer value)
/* 733:    */   {
/* 734:689 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 735:690 */     long function_pointer = caps.glVertexAttribP3uiv;
/* 736:691 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 737:692 */     BufferChecks.checkBuffer(value, 3);
/* 738:693 */     nglVertexAttribP3uiv(index, type, normalized, MemoryUtil.getAddress(value), function_pointer);
/* 739:    */   }
/* 740:    */   
/* 741:    */   static native void nglVertexAttribP3uiv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 742:    */   
/* 743:    */   public static void glVertexAttribP4u(int index, int type, boolean normalized, IntBuffer value)
/* 744:    */   {
/* 745:698 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 746:699 */     long function_pointer = caps.glVertexAttribP4uiv;
/* 747:700 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 748:701 */     BufferChecks.checkBuffer(value, 4);
/* 749:702 */     nglVertexAttribP4uiv(index, type, normalized, MemoryUtil.getAddress(value), function_pointer);
/* 750:    */   }
/* 751:    */   
/* 752:    */   static native void nglVertexAttribP4uiv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 753:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL33
 * JD-Core Version:    0.7.0.1
 */