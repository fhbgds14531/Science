/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBTextureMultisample
/*  6:   */ {
/*  7:   */   public static final int GL_SAMPLE_POSITION = 36432;
/*  8:   */   public static final int GL_SAMPLE_MASK = 36433;
/*  9:   */   public static final int GL_SAMPLE_MASK_VALUE = 36434;
/* 10:   */   public static final int GL_TEXTURE_2D_MULTISAMPLE = 37120;
/* 11:   */   public static final int GL_PROXY_TEXTURE_2D_MULTISAMPLE = 37121;
/* 12:   */   public static final int GL_TEXTURE_2D_MULTISAMPLE_ARRAY = 37122;
/* 13:   */   public static final int GL_PROXY_TEXTURE_2D_MULTISAMPLE_ARRAY = 37123;
/* 14:   */   public static final int GL_MAX_SAMPLE_MASK_WORDS = 36441;
/* 15:   */   public static final int GL_MAX_COLOR_TEXTURE_SAMPLES = 37134;
/* 16:   */   public static final int GL_MAX_DEPTH_TEXTURE_SAMPLES = 37135;
/* 17:   */   public static final int GL_MAX_INTEGER_SAMPLES = 37136;
/* 18:   */   public static final int GL_TEXTURE_BINDING_2D_MULTISAMPLE = 37124;
/* 19:   */   public static final int GL_TEXTURE_BINDING_2D_MULTISAMPLE_ARRAY = 37125;
/* 20:   */   public static final int GL_TEXTURE_SAMPLES = 37126;
/* 21:   */   public static final int GL_TEXTURE_FIXED_SAMPLE_LOCATIONS = 37127;
/* 22:   */   public static final int GL_SAMPLER_2D_MULTISAMPLE = 37128;
/* 23:   */   public static final int GL_INT_SAMPLER_2D_MULTISAMPLE = 37129;
/* 24:   */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE = 37130;
/* 25:   */   public static final int GL_SAMPLER_2D_MULTISAMPLE_ARRAY = 37131;
/* 26:   */   public static final int GL_INT_SAMPLER_2D_MULTISAMPLE_ARRAY = 37132;
/* 27:   */   public static final int GL_UNSIGNED_INT_SAMPLER_2D_MULTISAMPLE_ARRAY = 37133;
/* 28:   */   
/* 29:   */   public static void glTexImage2DMultisample(int target, int samples, int internalformat, int width, int height, boolean fixedsamplelocations)
/* 30:   */   {
/* 31:80 */     GL32.glTexImage2DMultisample(target, samples, internalformat, width, height, fixedsamplelocations);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static void glTexImage3DMultisample(int target, int samples, int internalformat, int width, int height, int depth, boolean fixedsamplelocations)
/* 35:   */   {
/* 36:84 */     GL32.glTexImage3DMultisample(target, samples, internalformat, width, height, depth, fixedsamplelocations);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public static void glGetMultisample(int pname, int index, FloatBuffer val)
/* 40:   */   {
/* 41:88 */     GL32.glGetMultisample(pname, index, val);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public static void glSampleMaski(int index, int mask)
/* 45:   */   {
/* 46:92 */     GL32.glSampleMaski(index, mask);
/* 47:   */   }
/* 48:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureMultisample
 * JD-Core Version:    0.7.0.1
 */