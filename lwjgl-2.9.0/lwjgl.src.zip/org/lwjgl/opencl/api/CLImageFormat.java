/*  1:   */ package org.lwjgl.opencl.api;
/*  2:   */ 
/*  3:   */ public final class CLImageFormat
/*  4:   */ {
/*  5:   */   public static final int STRUCT_SIZE = 8;
/*  6:   */   private final int channelOrder;
/*  7:   */   private final int channelType;
/*  8:   */   
/*  9:   */   public CLImageFormat(int channelOrder, int channelType)
/* 10:   */   {
/* 11:48 */     this.channelOrder = channelOrder;
/* 12:49 */     this.channelType = channelType;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int getChannelOrder()
/* 16:   */   {
/* 17:53 */     return this.channelOrder;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getChannelType()
/* 21:   */   {
/* 22:57 */     return this.channelType;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.api.CLImageFormat
 * JD-Core Version:    0.7.0.1
 */