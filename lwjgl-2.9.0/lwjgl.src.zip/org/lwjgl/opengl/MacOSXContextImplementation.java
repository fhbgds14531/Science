/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ 
/*   7:    */ final class MacOSXContextImplementation
/*   8:    */   implements ContextImplementation
/*   9:    */ {
/*  10:    */   public ByteBuffer create(PeerInfo peer_info, IntBuffer attribs, ByteBuffer shared_context_handle)
/*  11:    */     throws LWJGLException
/*  12:    */   {
/*  13: 47 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  14:    */     try
/*  15:    */     {
/*  16: 49 */       return nCreate(peer_handle, shared_context_handle);
/*  17:    */     }
/*  18:    */     finally
/*  19:    */     {
/*  20: 51 */       peer_info.unlock();
/*  21:    */     }
/*  22:    */   }
/*  23:    */   
/*  24:    */   private static native ByteBuffer nCreate(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/*  25:    */     throws LWJGLException;
/*  26:    */   
/*  27:    */   public void swapBuffers()
/*  28:    */     throws LWJGLException
/*  29:    */   {
/*  30: 58 */     ContextGL current_context = ContextGL.getCurrentContext();
/*  31: 59 */     if (current_context == null) {
/*  32: 60 */       throw new IllegalStateException("No context is current");
/*  33:    */     }
/*  34: 61 */     synchronized (current_context)
/*  35:    */     {
/*  36: 62 */       nSwapBuffers(current_context.getHandle());
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   native long getCGLShareGroup(ByteBuffer paramByteBuffer);
/*  41:    */   
/*  42:    */   private static native void nSwapBuffers(ByteBuffer paramByteBuffer)
/*  43:    */     throws LWJGLException;
/*  44:    */   
/*  45:    */   public void update(ByteBuffer context_handle)
/*  46:    */   {
/*  47: 71 */     nUpdate(context_handle);
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static native void nUpdate(ByteBuffer paramByteBuffer);
/*  51:    */   
/*  52:    */   public void releaseCurrentContext()
/*  53:    */     throws LWJGLException
/*  54:    */   {}
/*  55:    */   
/*  56:    */   private static native void nReleaseCurrentContext()
/*  57:    */     throws LWJGLException;
/*  58:    */   
/*  59:    */   public void releaseDrawable(ByteBuffer context_handle)
/*  60:    */     throws LWJGLException
/*  61:    */   {
/*  62: 83 */     clearDrawable(context_handle);
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static native void clearDrawable(ByteBuffer paramByteBuffer)
/*  66:    */     throws LWJGLException;
/*  67:    */   
/*  68:    */   static void resetView(PeerInfo peer_info, ContextGL context)
/*  69:    */     throws LWJGLException
/*  70:    */   {
/*  71: 89 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  72:    */     try
/*  73:    */     {
/*  74: 91 */       synchronized (context)
/*  75:    */       {
/*  76: 92 */         clearDrawable(context.getHandle());
/*  77: 93 */         setView(peer_handle, context.getHandle());
/*  78:    */       }
/*  79:    */     }
/*  80:    */     finally
/*  81:    */     {
/*  82: 96 */       peer_info.unlock();
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void makeCurrent(PeerInfo peer_info, ByteBuffer handle)
/*  87:    */     throws LWJGLException
/*  88:    */   {
/*  89:101 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  90:    */     try
/*  91:    */     {
/*  92:103 */       setView(peer_handle, handle);
/*  93:104 */       nMakeCurrent(handle);
/*  94:    */     }
/*  95:    */     finally
/*  96:    */     {
/*  97:106 */       peer_info.unlock();
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static native void setView(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/* 102:    */     throws LWJGLException;
/* 103:    */   
/* 104:    */   private static native void nMakeCurrent(ByteBuffer paramByteBuffer)
/* 105:    */     throws LWJGLException;
/* 106:    */   
/* 107:    */   public boolean isCurrent(ByteBuffer handle)
/* 108:    */     throws LWJGLException
/* 109:    */   {
/* 110:115 */     boolean result = nIsCurrent(handle);
/* 111:116 */     return result;
/* 112:    */   }
/* 113:    */   
/* 114:    */   private static native boolean nIsCurrent(ByteBuffer paramByteBuffer)
/* 115:    */     throws LWJGLException;
/* 116:    */   
/* 117:    */   public void setSwapInterval(int value)
/* 118:    */   {
/* 119:122 */     ContextGL current_context = ContextGL.getCurrentContext();
/* 120:123 */     synchronized (current_context)
/* 121:    */     {
/* 122:124 */       nSetSwapInterval(current_context.getHandle(), value);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static native void nSetSwapInterval(ByteBuffer paramByteBuffer, int paramInt);
/* 127:    */   
/* 128:    */   public void destroy(PeerInfo peer_info, ByteBuffer handle)
/* 129:    */     throws LWJGLException
/* 130:    */   {
/* 131:131 */     nDestroy(handle);
/* 132:    */   }
/* 133:    */   
/* 134:    */   private static native void nDestroy(ByteBuffer paramByteBuffer)
/* 135:    */     throws LWJGLException;
/* 136:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXContextImplementation
 * JD-Core Version:    0.7.0.1
 */