/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class ARBTextureCompression
/*   8:    */ {
/*   9:    */   public static final int GL_COMPRESSED_ALPHA_ARB = 34025;
/*  10:    */   public static final int GL_COMPRESSED_LUMINANCE_ARB = 34026;
/*  11:    */   public static final int GL_COMPRESSED_LUMINANCE_ALPHA_ARB = 34027;
/*  12:    */   public static final int GL_COMPRESSED_INTENSITY_ARB = 34028;
/*  13:    */   public static final int GL_COMPRESSED_RGB_ARB = 34029;
/*  14:    */   public static final int GL_COMPRESSED_RGBA_ARB = 34030;
/*  15:    */   public static final int GL_TEXTURE_COMPRESSION_HINT_ARB = 34031;
/*  16:    */   public static final int GL_TEXTURE_COMPRESSED_IMAGE_SIZE_ARB = 34464;
/*  17:    */   public static final int GL_TEXTURE_COMPRESSED_ARB = 34465;
/*  18:    */   public static final int GL_NUM_COMPRESSED_TEXTURE_FORMATS_ARB = 34466;
/*  19:    */   public static final int GL_COMPRESSED_TEXTURE_FORMATS_ARB = 34467;
/*  20:    */   
/*  21:    */   public static void glCompressedTexImage1DARB(int target, int level, int internalformat, int width, int border, ByteBuffer pData)
/*  22:    */   {
/*  23: 25 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  24: 26 */     long function_pointer = caps.glCompressedTexImage1DARB;
/*  25: 27 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  26: 28 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  27: 29 */     BufferChecks.checkDirect(pData);
/*  28: 30 */     nglCompressedTexImage1DARB(target, level, internalformat, width, border, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/*  29:    */   }
/*  30:    */   
/*  31:    */   static native void nglCompressedTexImage1DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/*  32:    */   
/*  33:    */   public static void glCompressedTexImage1DARB(int target, int level, int internalformat, int width, int border, int pData_imageSize, long pData_buffer_offset)
/*  34:    */   {
/*  35: 34 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 35 */     long function_pointer = caps.glCompressedTexImage1DARB;
/*  37: 36 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 37 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  39: 38 */     nglCompressedTexImage1DARBBO(target, level, internalformat, width, border, pData_imageSize, pData_buffer_offset, function_pointer);
/*  40:    */   }
/*  41:    */   
/*  42:    */   static native void nglCompressedTexImage1DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/*  43:    */   
/*  44:    */   public static void glCompressedTexImage2DARB(int target, int level, int internalformat, int width, int height, int border, ByteBuffer pData)
/*  45:    */   {
/*  46: 43 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  47: 44 */     long function_pointer = caps.glCompressedTexImage2DARB;
/*  48: 45 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  49: 46 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  50: 47 */     BufferChecks.checkDirect(pData);
/*  51: 48 */     nglCompressedTexImage2DARB(target, level, internalformat, width, height, border, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/*  52:    */   }
/*  53:    */   
/*  54:    */   static native void nglCompressedTexImage2DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  55:    */   
/*  56:    */   public static void glCompressedTexImage2DARB(int target, int level, int internalformat, int width, int height, int border, int pData_imageSize, long pData_buffer_offset)
/*  57:    */   {
/*  58: 52 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  59: 53 */     long function_pointer = caps.glCompressedTexImage2DARB;
/*  60: 54 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  61: 55 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  62: 56 */     nglCompressedTexImage2DARBBO(target, level, internalformat, width, height, border, pData_imageSize, pData_buffer_offset, function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   static native void nglCompressedTexImage2DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/*  66:    */   
/*  67:    */   public static void glCompressedTexImage3DARB(int target, int level, int internalformat, int width, int height, int depth, int border, ByteBuffer pData)
/*  68:    */   {
/*  69: 61 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  70: 62 */     long function_pointer = caps.glCompressedTexImage3DARB;
/*  71: 63 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  72: 64 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  73: 65 */     BufferChecks.checkDirect(pData);
/*  74: 66 */     nglCompressedTexImage3DARB(target, level, internalformat, width, height, depth, border, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native void nglCompressedTexImage3DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/*  78:    */   
/*  79:    */   public static void glCompressedTexImage3DARB(int target, int level, int internalformat, int width, int height, int depth, int border, int pData_imageSize, long pData_buffer_offset)
/*  80:    */   {
/*  81: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  82: 71 */     long function_pointer = caps.glCompressedTexImage3DARB;
/*  83: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  84: 73 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  85: 74 */     nglCompressedTexImage3DARBBO(target, level, internalformat, width, height, depth, border, pData_imageSize, pData_buffer_offset, function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglCompressedTexImage3DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/*  89:    */   
/*  90:    */   public static void glCompressedTexSubImage1DARB(int target, int level, int xoffset, int width, int format, ByteBuffer pData)
/*  91:    */   {
/*  92: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 80 */     long function_pointer = caps.glCompressedTexSubImage1DARB;
/*  94: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 82 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  96: 83 */     BufferChecks.checkDirect(pData);
/*  97: 84 */     nglCompressedTexSubImage1DARB(target, level, xoffset, width, format, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/*  98:    */   }
/*  99:    */   
/* 100:    */   static native void nglCompressedTexSubImage1DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 101:    */   
/* 102:    */   public static void glCompressedTexSubImage1DARB(int target, int level, int xoffset, int width, int format, int pData_imageSize, long pData_buffer_offset)
/* 103:    */   {
/* 104: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 105: 89 */     long function_pointer = caps.glCompressedTexSubImage1DARB;
/* 106: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 107: 91 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 108: 92 */     nglCompressedTexSubImage1DARBBO(target, level, xoffset, width, format, pData_imageSize, pData_buffer_offset, function_pointer);
/* 109:    */   }
/* 110:    */   
/* 111:    */   static native void nglCompressedTexSubImage1DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 112:    */   
/* 113:    */   public static void glCompressedTexSubImage2DARB(int target, int level, int xoffset, int yoffset, int width, int height, int format, ByteBuffer pData)
/* 114:    */   {
/* 115: 97 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116: 98 */     long function_pointer = caps.glCompressedTexSubImage2DARB;
/* 117: 99 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:100 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 119:101 */     BufferChecks.checkDirect(pData);
/* 120:102 */     nglCompressedTexSubImage2DARB(target, level, xoffset, yoffset, width, height, format, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/* 121:    */   }
/* 122:    */   
/* 123:    */   static native void nglCompressedTexSubImage2DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 124:    */   
/* 125:    */   public static void glCompressedTexSubImage2DARB(int target, int level, int xoffset, int yoffset, int width, int height, int format, int pData_imageSize, long pData_buffer_offset)
/* 126:    */   {
/* 127:106 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 128:107 */     long function_pointer = caps.glCompressedTexSubImage2DARB;
/* 129:108 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 130:109 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 131:110 */     nglCompressedTexSubImage2DARBBO(target, level, xoffset, yoffset, width, height, format, pData_imageSize, pData_buffer_offset, function_pointer);
/* 132:    */   }
/* 133:    */   
/* 134:    */   static native void nglCompressedTexSubImage2DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 135:    */   
/* 136:    */   public static void glCompressedTexSubImage3DARB(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, ByteBuffer pData)
/* 137:    */   {
/* 138:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:116 */     long function_pointer = caps.glCompressedTexSubImage3DARB;
/* 140:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:118 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 142:119 */     BufferChecks.checkDirect(pData);
/* 143:120 */     nglCompressedTexSubImage3DARB(target, level, xoffset, yoffset, zoffset, width, height, depth, format, pData.remaining(), MemoryUtil.getAddress(pData), function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   static native void nglCompressedTexSubImage3DARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 147:    */   
/* 148:    */   public static void glCompressedTexSubImage3DARB(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int pData_imageSize, long pData_buffer_offset)
/* 149:    */   {
/* 150:124 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 151:125 */     long function_pointer = caps.glCompressedTexSubImage3DARB;
/* 152:126 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 153:127 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 154:128 */     nglCompressedTexSubImage3DARBBO(target, level, xoffset, yoffset, zoffset, width, height, depth, format, pData_imageSize, pData_buffer_offset, function_pointer);
/* 155:    */   }
/* 156:    */   
/* 157:    */   static native void nglCompressedTexSubImage3DARBBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 158:    */   
/* 159:    */   public static void glGetCompressedTexImageARB(int target, int lod, ByteBuffer pImg)
/* 160:    */   {
/* 161:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 162:134 */     long function_pointer = caps.glGetCompressedTexImageARB;
/* 163:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 164:136 */     GLChecks.ensurePackPBOdisabled(caps);
/* 165:137 */     BufferChecks.checkDirect(pImg);
/* 166:138 */     nglGetCompressedTexImageARB(target, lod, MemoryUtil.getAddress(pImg), function_pointer);
/* 167:    */   }
/* 168:    */   
/* 169:    */   static native void nglGetCompressedTexImageARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 170:    */   
/* 171:    */   public static void glGetCompressedTexImageARB(int target, int lod, long pImg_buffer_offset)
/* 172:    */   {
/* 173:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 174:143 */     long function_pointer = caps.glGetCompressedTexImageARB;
/* 175:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 176:145 */     GLChecks.ensurePackPBOenabled(caps);
/* 177:146 */     nglGetCompressedTexImageARBBO(target, lod, pImg_buffer_offset, function_pointer);
/* 178:    */   }
/* 179:    */   
/* 180:    */   static native void nglGetCompressedTexImageARBBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 181:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureCompression
 * JD-Core Version:    0.7.0.1
 */