/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ abstract class CLObjectRetainable
/*  4:   */   extends CLObject
/*  5:   */ {
/*  6:   */   private int refCount;
/*  7:   */   
/*  8:   */   protected CLObjectRetainable(long pointer)
/*  9:   */   {
/* 10:44 */     super(pointer);
/* 11:46 */     if (super.isValid()) {
/* 12:47 */       this.refCount = 1;
/* 13:   */     }
/* 14:   */   }
/* 15:   */   
/* 16:   */   public final int getReferenceCount()
/* 17:   */   {
/* 18:51 */     return this.refCount;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public final boolean isValid()
/* 22:   */   {
/* 23:55 */     return this.refCount > 0;
/* 24:   */   }
/* 25:   */   
/* 26:   */   int retain()
/* 27:   */   {
/* 28:59 */     checkValid();
/* 29:   */     
/* 30:61 */     return ++this.refCount;
/* 31:   */   }
/* 32:   */   
/* 33:   */   int release()
/* 34:   */   {
/* 35:65 */     checkValid();
/* 36:   */     
/* 37:67 */     return --this.refCount;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLObjectRetainable
 * JD-Core Version:    0.7.0.1
 */