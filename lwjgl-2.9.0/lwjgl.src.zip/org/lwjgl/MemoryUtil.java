/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.nio.Buffer;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.nio.CharBuffer;
/*   7:    */ import java.nio.DoubleBuffer;
/*   8:    */ import java.nio.FloatBuffer;
/*   9:    */ import java.nio.IntBuffer;
/*  10:    */ import java.nio.LongBuffer;
/*  11:    */ import java.nio.ShortBuffer;
/*  12:    */ import java.nio.charset.CharacterCodingException;
/*  13:    */ import java.nio.charset.Charset;
/*  14:    */ import java.nio.charset.CharsetDecoder;
/*  15:    */ import java.nio.charset.CharsetEncoder;
/*  16:    */ import java.nio.charset.CoderResult;
/*  17:    */ 
/*  18:    */ public final class MemoryUtil
/*  19:    */ {
/*  20: 52 */   private static final Charset ascii = Charset.forName("ISO-8859-1");
/*  21: 53 */   private static final Charset utf8 = Charset.forName("UTF-8");
/*  22: 54 */   private static final Charset utf16 = Charset.forName("UTF-16LE");
/*  23:    */   private static final Accessor memUtil;
/*  24:    */   
/*  25:    */   static
/*  26:    */   {
/*  27:    */     Accessor util;
/*  28:    */     try
/*  29:    */     {
/*  30: 63 */       util = loadAccessor("org.lwjgl.MemoryUtilSun$AccessorUnsafe");
/*  31:    */     }
/*  32:    */     catch (Exception e0)
/*  33:    */     {
/*  34:    */       try
/*  35:    */       {
/*  36: 67 */         util = loadAccessor("org.lwjgl.MemoryUtilSun$AccessorReflectFast");
/*  37:    */       }
/*  38:    */       catch (Exception e1)
/*  39:    */       {
/*  40:    */         try
/*  41:    */         {
/*  42: 71 */           util = new AccessorReflect();
/*  43:    */         }
/*  44:    */         catch (Exception e2)
/*  45:    */         {
/*  46: 73 */           LWJGLUtil.log("Unsupported JVM detected, this will likely result in low performance. Please inform LWJGL developers.");
/*  47: 74 */           util = new AccessorJNI(null);
/*  48:    */         }
/*  49:    */       }
/*  50:    */     }
/*  51: 79 */     LWJGLUtil.log("MemoryUtil Accessor: " + util.getClass().getSimpleName());
/*  52: 80 */     memUtil = util;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static long getAddress0(Buffer buffer)
/*  56:    */   {
/*  57:113 */     return memUtil.getAddress(buffer);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static long getAddress0Safe(Buffer buffer)
/*  61:    */   {
/*  62:115 */     return buffer == null ? 0L : memUtil.getAddress(buffer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static long getAddress0(PointerBuffer buffer)
/*  66:    */   {
/*  67:117 */     return memUtil.getAddress(buffer.getBuffer());
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static long getAddress0Safe(PointerBuffer buffer)
/*  71:    */   {
/*  72:119 */     return buffer == null ? 0L : memUtil.getAddress(buffer.getBuffer());
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static long getAddress(ByteBuffer buffer)
/*  76:    */   {
/*  77:123 */     return getAddress(buffer, buffer.position());
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static long getAddress(ByteBuffer buffer, int position)
/*  81:    */   {
/*  82:125 */     return getAddress0(buffer) + position;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static long getAddress(ShortBuffer buffer)
/*  86:    */   {
/*  87:127 */     return getAddress(buffer, buffer.position());
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static long getAddress(ShortBuffer buffer, int position)
/*  91:    */   {
/*  92:129 */     return getAddress0(buffer) + (position << 1);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static long getAddress(CharBuffer buffer)
/*  96:    */   {
/*  97:131 */     return getAddress(buffer, buffer.position());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static long getAddress(CharBuffer buffer, int position)
/* 101:    */   {
/* 102:133 */     return getAddress0(buffer) + (position << 1);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static long getAddress(IntBuffer buffer)
/* 106:    */   {
/* 107:135 */     return getAddress(buffer, buffer.position());
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static long getAddress(IntBuffer buffer, int position)
/* 111:    */   {
/* 112:137 */     return getAddress0(buffer) + (position << 2);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static long getAddress(FloatBuffer buffer)
/* 116:    */   {
/* 117:139 */     return getAddress(buffer, buffer.position());
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static long getAddress(FloatBuffer buffer, int position)
/* 121:    */   {
/* 122:141 */     return getAddress0(buffer) + (position << 2);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static long getAddress(LongBuffer buffer)
/* 126:    */   {
/* 127:143 */     return getAddress(buffer, buffer.position());
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static long getAddress(LongBuffer buffer, int position)
/* 131:    */   {
/* 132:145 */     return getAddress0(buffer) + (position << 3);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static long getAddress(DoubleBuffer buffer)
/* 136:    */   {
/* 137:147 */     return getAddress(buffer, buffer.position());
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static long getAddress(DoubleBuffer buffer, int position)
/* 141:    */   {
/* 142:149 */     return getAddress0(buffer) + (position << 3);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static long getAddress(PointerBuffer buffer)
/* 146:    */   {
/* 147:151 */     return getAddress(buffer, buffer.position());
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static long getAddress(PointerBuffer buffer, int position)
/* 151:    */   {
/* 152:153 */     return getAddress0(buffer) + position * PointerBuffer.getPointerSize();
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static long getAddressSafe(ByteBuffer buffer)
/* 156:    */   {
/* 157:157 */     return buffer == null ? 0L : getAddress(buffer);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static long getAddressSafe(ByteBuffer buffer, int position)
/* 161:    */   {
/* 162:159 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static long getAddressSafe(ShortBuffer buffer)
/* 166:    */   {
/* 167:161 */     return buffer == null ? 0L : getAddress(buffer);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static long getAddressSafe(ShortBuffer buffer, int position)
/* 171:    */   {
/* 172:163 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static long getAddressSafe(CharBuffer buffer)
/* 176:    */   {
/* 177:165 */     return buffer == null ? 0L : getAddress(buffer);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static long getAddressSafe(CharBuffer buffer, int position)
/* 181:    */   {
/* 182:167 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static long getAddressSafe(IntBuffer buffer)
/* 186:    */   {
/* 187:169 */     return buffer == null ? 0L : getAddress(buffer);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static long getAddressSafe(IntBuffer buffer, int position)
/* 191:    */   {
/* 192:171 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static long getAddressSafe(FloatBuffer buffer)
/* 196:    */   {
/* 197:173 */     return buffer == null ? 0L : getAddress(buffer);
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static long getAddressSafe(FloatBuffer buffer, int position)
/* 201:    */   {
/* 202:175 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 203:    */   }
/* 204:    */   
/* 205:    */   public static long getAddressSafe(LongBuffer buffer)
/* 206:    */   {
/* 207:177 */     return buffer == null ? 0L : getAddress(buffer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static long getAddressSafe(LongBuffer buffer, int position)
/* 211:    */   {
/* 212:179 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static long getAddressSafe(DoubleBuffer buffer)
/* 216:    */   {
/* 217:181 */     return buffer == null ? 0L : getAddress(buffer);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static long getAddressSafe(DoubleBuffer buffer, int position)
/* 221:    */   {
/* 222:183 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static long getAddressSafe(PointerBuffer buffer)
/* 226:    */   {
/* 227:185 */     return buffer == null ? 0L : getAddress(buffer);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static long getAddressSafe(PointerBuffer buffer, int position)
/* 231:    */   {
/* 232:187 */     return buffer == null ? 0L : getAddress(buffer, position);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static ByteBuffer encodeASCII(CharSequence text)
/* 236:    */   {
/* 237:202 */     return encode(text, ascii);
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static ByteBuffer encodeUTF8(CharSequence text)
/* 241:    */   {
/* 242:216 */     return encode(text, utf8);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public static ByteBuffer encodeUTF16(CharSequence text)
/* 246:    */   {
/* 247:228 */     return encode(text, utf16);
/* 248:    */   }
/* 249:    */   
/* 250:    */   private static ByteBuffer encode(CharSequence text, Charset charset)
/* 251:    */   {
/* 252:240 */     if (text == null) {
/* 253:241 */       return null;
/* 254:    */     }
/* 255:243 */     return encode(CharBuffer.wrap(new CharSequenceNT(text)), charset);
/* 256:    */   }
/* 257:    */   
/* 258:    */   private static ByteBuffer encode(CharBuffer in, Charset charset)
/* 259:    */   {
/* 260:253 */     CharsetEncoder encoder = charset.newEncoder();
/* 261:    */     
/* 262:255 */     int n = (int)(in.remaining() * encoder.averageBytesPerChar());
/* 263:256 */     ByteBuffer out = BufferUtils.createByteBuffer(n);
/* 264:258 */     if ((n == 0) && (in.remaining() == 0)) {
/* 265:259 */       return out;
/* 266:    */     }
/* 267:261 */     encoder.reset();
/* 268:    */     for (;;)
/* 269:    */     {
/* 270:263 */       CoderResult cr = in.hasRemaining() ? encoder.encode(in, out, true) : CoderResult.UNDERFLOW;
/* 271:264 */       if (cr.isUnderflow()) {
/* 272:265 */         cr = encoder.flush(out);
/* 273:    */       }
/* 274:267 */       if (cr.isUnderflow()) {
/* 275:    */         break;
/* 276:    */       }
/* 277:270 */       if (cr.isOverflow())
/* 278:    */       {
/* 279:271 */         n = 2 * n + 1;
/* 280:272 */         ByteBuffer o = BufferUtils.createByteBuffer(n);
/* 281:273 */         out.flip();
/* 282:274 */         o.put(out);
/* 283:275 */         out = o;
/* 284:    */       }
/* 285:    */       else
/* 286:    */       {
/* 287:    */         try
/* 288:    */         {
/* 289:280 */           cr.throwException();
/* 290:    */         }
/* 291:    */         catch (CharacterCodingException e)
/* 292:    */         {
/* 293:282 */           throw new RuntimeException(e);
/* 294:    */         }
/* 295:    */       }
/* 296:    */     }
/* 297:285 */     out.flip();
/* 298:286 */     return out;
/* 299:    */   }
/* 300:    */   
/* 301:    */   public static String decodeASCII(ByteBuffer buffer)
/* 302:    */   {
/* 303:290 */     return decode(buffer, ascii);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public static String decodeUTF8(ByteBuffer buffer)
/* 307:    */   {
/* 308:294 */     return decode(buffer, utf8);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public static String decodeUTF16(ByteBuffer buffer)
/* 312:    */   {
/* 313:298 */     return decode(buffer, utf16);
/* 314:    */   }
/* 315:    */   
/* 316:    */   private static String decode(ByteBuffer buffer, Charset charset)
/* 317:    */   {
/* 318:302 */     if (buffer == null) {
/* 319:303 */       return null;
/* 320:    */     }
/* 321:305 */     return decodeImpl(buffer, charset);
/* 322:    */   }
/* 323:    */   
/* 324:    */   private static String decodeImpl(ByteBuffer in, Charset charset)
/* 325:    */   {
/* 326:309 */     CharsetDecoder decoder = charset.newDecoder();
/* 327:    */     
/* 328:311 */     int n = (int)(in.remaining() * decoder.averageCharsPerByte());
/* 329:312 */     CharBuffer out = BufferUtils.createCharBuffer(n);
/* 330:314 */     if ((n == 0) && (in.remaining() == 0)) {
/* 331:315 */       return "";
/* 332:    */     }
/* 333:317 */     decoder.reset();
/* 334:    */     for (;;)
/* 335:    */     {
/* 336:319 */       CoderResult cr = in.hasRemaining() ? decoder.decode(in, out, true) : CoderResult.UNDERFLOW;
/* 337:320 */       if (cr.isUnderflow()) {
/* 338:321 */         cr = decoder.flush(out);
/* 339:    */       }
/* 340:323 */       if (cr.isUnderflow()) {
/* 341:    */         break;
/* 342:    */       }
/* 343:325 */       if (cr.isOverflow())
/* 344:    */       {
/* 345:326 */         n = 2 * n + 1;
/* 346:327 */         CharBuffer o = BufferUtils.createCharBuffer(n);
/* 347:328 */         out.flip();
/* 348:329 */         o.put(out);
/* 349:330 */         out = o;
/* 350:    */       }
/* 351:    */       else
/* 352:    */       {
/* 353:    */         try
/* 354:    */         {
/* 355:334 */           cr.throwException();
/* 356:    */         }
/* 357:    */         catch (CharacterCodingException e)
/* 358:    */         {
/* 359:336 */           throw new RuntimeException(e);
/* 360:    */         }
/* 361:    */       }
/* 362:    */     }
/* 363:339 */     out.flip();
/* 364:340 */     return out.toString();
/* 365:    */   }
/* 366:    */   
/* 367:    */   private static class CharSequenceNT
/* 368:    */     implements CharSequence
/* 369:    */   {
/* 370:    */     final CharSequence source;
/* 371:    */     
/* 372:    */     CharSequenceNT(CharSequence source)
/* 373:    */     {
/* 374:349 */       this.source = source;
/* 375:    */     }
/* 376:    */     
/* 377:    */     public int length()
/* 378:    */     {
/* 379:353 */       return this.source.length() + 1;
/* 380:    */     }
/* 381:    */     
/* 382:    */     public char charAt(int index)
/* 383:    */     {
/* 384:358 */       return index == this.source.length() ? '\000' : this.source.charAt(index);
/* 385:    */     }
/* 386:    */     
/* 387:    */     public CharSequence subSequence(int start, int end)
/* 388:    */     {
/* 389:363 */       return new CharSequenceNT(this.source.subSequence(start, Math.min(end, this.source.length())));
/* 390:    */     }
/* 391:    */   }
/* 392:    */   
/* 393:    */   private static Accessor loadAccessor(String className)
/* 394:    */     throws Exception
/* 395:    */   {
/* 396:375 */     return (Accessor)Class.forName(className).newInstance();
/* 397:    */   }
/* 398:    */   
/* 399:    */   static abstract interface Accessor
/* 400:    */   {
/* 401:    */     public abstract long getAddress(Buffer paramBuffer);
/* 402:    */   }
/* 403:    */   
/* 404:    */   private static class AccessorJNI
/* 405:    */     implements MemoryUtil.Accessor
/* 406:    */   {
/* 407:    */     public long getAddress(Buffer buffer)
/* 408:    */     {
/* 409:382 */       return BufferUtils.getBufferAddress(buffer);
/* 410:    */     }
/* 411:    */   }
/* 412:    */   
/* 413:    */   private static class AccessorReflect
/* 414:    */     implements MemoryUtil.Accessor
/* 415:    */   {
/* 416:    */     private final Field address;
/* 417:    */     
/* 418:    */     AccessorReflect()
/* 419:    */     {
/* 420:    */       try
/* 421:    */       {
/* 422:394 */         this.address = MemoryUtil.getAddressField();
/* 423:    */       }
/* 424:    */       catch (NoSuchFieldException e)
/* 425:    */       {
/* 426:396 */         throw new UnsupportedOperationException(e);
/* 427:    */       }
/* 428:398 */       this.address.setAccessible(true);
/* 429:    */     }
/* 430:    */     
/* 431:    */     public long getAddress(Buffer buffer)
/* 432:    */     {
/* 433:    */       try
/* 434:    */       {
/* 435:403 */         return this.address.getLong(buffer);
/* 436:    */       }
/* 437:    */       catch (IllegalAccessException e) {}
/* 438:406 */       return 0L;
/* 439:    */     }
/* 440:    */   }
/* 441:    */   
/* 442:    */   static Field getAddressField()
/* 443:    */     throws NoSuchFieldException
/* 444:    */   {
/* 445:413 */     return getDeclaredFieldRecursive(ByteBuffer.class, "address");
/* 446:    */   }
/* 447:    */   
/* 448:    */   private static Field getDeclaredFieldRecursive(Class<?> root, String fieldName)
/* 449:    */     throws NoSuchFieldException
/* 450:    */   {
/* 451:417 */     Class<?> type = root;
/* 452:    */     do
/* 453:    */     {
/* 454:    */       try
/* 455:    */       {
/* 456:421 */         return type.getDeclaredField(fieldName);
/* 457:    */       }
/* 458:    */       catch (NoSuchFieldException e)
/* 459:    */       {
/* 460:423 */         type = type.getSuperclass();
/* 461:    */       }
/* 462:425 */     } while (type != null);
/* 463:427 */     throw new NoSuchFieldException(fieldName + " does not exist in " + root.getSimpleName() + " or any of its superclasses.");
/* 464:    */   }
/* 465:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.MemoryUtil
 * JD-Core Version:    0.7.0.1
 */