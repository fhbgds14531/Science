/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ public final class EFXUtil
/*   4:    */ {
/*   5:    */   private static final int EFFECT = 1111;
/*   6:    */   private static final int FILTER = 2222;
/*   7:    */   
/*   8:    */   public static boolean isEfxSupported()
/*   9:    */   {
/*  10: 65 */     if (!AL.isCreated()) {
/*  11: 66 */       throw new OpenALException("OpenAL has not been created.");
/*  12:    */     }
/*  13: 68 */     return ALC10.alcIsExtensionPresent(AL.getDevice(), "ALC_EXT_EFX");
/*  14:    */   }
/*  15:    */   
/*  16:    */   public static boolean isEffectSupported(int effectType)
/*  17:    */   {
/*  18: 83 */     switch (effectType)
/*  19:    */     {
/*  20:    */     case 0: 
/*  21:    */     case 1: 
/*  22:    */     case 2: 
/*  23:    */     case 3: 
/*  24:    */     case 4: 
/*  25:    */     case 5: 
/*  26:    */     case 6: 
/*  27:    */     case 7: 
/*  28:    */     case 8: 
/*  29:    */     case 9: 
/*  30:    */     case 10: 
/*  31:    */     case 11: 
/*  32:    */     case 12: 
/*  33:    */     case 32768: 
/*  34:    */       break;
/*  35:    */     default: 
/*  36:100 */       throw new IllegalArgumentException("Unknown or invalid effect type: " + effectType);
/*  37:    */     }
/*  38:103 */     return testSupportGeneric(1111, effectType);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static boolean isFilterSupported(int filterType)
/*  42:    */   {
/*  43:118 */     switch (filterType)
/*  44:    */     {
/*  45:    */     case 0: 
/*  46:    */     case 1: 
/*  47:    */     case 2: 
/*  48:    */     case 3: 
/*  49:    */       break;
/*  50:    */     default: 
/*  51:125 */       throw new IllegalArgumentException("Unknown or invalid filter type: " + filterType);
/*  52:    */     }
/*  53:128 */     return testSupportGeneric(2222, filterType);
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static boolean testSupportGeneric(int objectType, int typeValue)
/*  57:    */   {
/*  58:142 */     switch (objectType)
/*  59:    */     {
/*  60:    */     case 1111: 
/*  61:    */     case 2222: 
/*  62:    */       break;
/*  63:    */     default: 
/*  64:147 */       throw new IllegalArgumentException("Invalid objectType: " + objectType);
/*  65:    */     }
/*  66:150 */     boolean supported = false;
/*  67:151 */     if (isEfxSupported())
/*  68:    */     {
/*  69:154 */       AL10.alGetError();
/*  70:    */       
/*  71:156 */       int testObject = 0;
/*  72:    */       int genError;
/*  73:    */       try
/*  74:    */       {
/*  75:158 */         switch (objectType)
/*  76:    */         {
/*  77:    */         case 1111: 
/*  78:160 */           testObject = EFX10.alGenEffects();
/*  79:161 */           break;
/*  80:    */         case 2222: 
/*  81:163 */           testObject = EFX10.alGenFilters();
/*  82:164 */           break;
/*  83:    */         default: 
/*  84:166 */           throw new IllegalArgumentException("Invalid objectType: " + objectType);
/*  85:    */         }
/*  86:168 */         genError = AL10.alGetError();
/*  87:    */       }
/*  88:    */       catch (OpenALException debugBuildException)
/*  89:    */       {
/*  90:    */         int genError;
/*  91:172 */         if (debugBuildException.getMessage().contains("AL_OUT_OF_MEMORY")) {
/*  92:173 */           genError = 40965;
/*  93:    */         } else {
/*  94:175 */           genError = 40964;
/*  95:    */         }
/*  96:    */       }
/*  97:179 */       if (genError == 0)
/*  98:    */       {
/*  99:181 */         AL10.alGetError();
/* 100:    */         int setError;
/* 101:    */         try
/* 102:    */         {
/* 103:184 */           switch (objectType)
/* 104:    */           {
/* 105:    */           case 1111: 
/* 106:186 */             EFX10.alEffecti(testObject, 32769, typeValue);
/* 107:187 */             break;
/* 108:    */           case 2222: 
/* 109:189 */             EFX10.alFilteri(testObject, 32769, typeValue);
/* 110:190 */             break;
/* 111:    */           default: 
/* 112:192 */             throw new IllegalArgumentException("Invalid objectType: " + objectType);
/* 113:    */           }
/* 114:194 */           setError = AL10.alGetError();
/* 115:    */         }
/* 116:    */         catch (OpenALException debugBuildException)
/* 117:    */         {
/* 118:198 */           setError = 40963;
/* 119:    */         }
/* 120:201 */         if (setError == 0) {
/* 121:202 */           supported = true;
/* 122:    */         }
/* 123:    */         try
/* 124:    */         {
/* 125:207 */           switch (objectType)
/* 126:    */           {
/* 127:    */           case 1111: 
/* 128:209 */             EFX10.alDeleteEffects(testObject);
/* 129:210 */             break;
/* 130:    */           case 2222: 
/* 131:212 */             EFX10.alDeleteFilters(testObject);
/* 132:213 */             break;
/* 133:    */           default: 
/* 134:215 */             throw new IllegalArgumentException("Invalid objectType: " + objectType);
/* 135:    */           }
/* 136:    */         }
/* 137:    */         catch (OpenALException debugBuildException) {}
/* 138:    */       }
/* 139:221 */       else if (genError == 40965)
/* 140:    */       {
/* 141:222 */         throw new OpenALException(genError);
/* 142:    */       }
/* 143:    */     }
/* 144:226 */     return supported;
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.EFXUtil
 * JD-Core Version:    0.7.0.1
 */