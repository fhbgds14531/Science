/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.LongBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class NVBindlessTexture
/*   8:    */ {
/*   9:    */   public static long glGetTextureHandleNV(int texture)
/*  10:    */   {
/*  11: 13 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  12: 14 */     long function_pointer = caps.glGetTextureHandleNV;
/*  13: 15 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  14: 16 */     long __result = nglGetTextureHandleNV(texture, function_pointer);
/*  15: 17 */     return __result;
/*  16:    */   }
/*  17:    */   
/*  18:    */   static native long nglGetTextureHandleNV(int paramInt, long paramLong);
/*  19:    */   
/*  20:    */   public static long glGetTextureSamplerHandleNV(int texture, int sampler)
/*  21:    */   {
/*  22: 22 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  23: 23 */     long function_pointer = caps.glGetTextureSamplerHandleNV;
/*  24: 24 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  25: 25 */     long __result = nglGetTextureSamplerHandleNV(texture, sampler, function_pointer);
/*  26: 26 */     return __result;
/*  27:    */   }
/*  28:    */   
/*  29:    */   static native long nglGetTextureSamplerHandleNV(int paramInt1, int paramInt2, long paramLong);
/*  30:    */   
/*  31:    */   public static void glMakeTextureHandleResidentNV(long handle)
/*  32:    */   {
/*  33: 31 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  34: 32 */     long function_pointer = caps.glMakeTextureHandleResidentNV;
/*  35: 33 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  36: 34 */     nglMakeTextureHandleResidentNV(handle, function_pointer);
/*  37:    */   }
/*  38:    */   
/*  39:    */   static native void nglMakeTextureHandleResidentNV(long paramLong1, long paramLong2);
/*  40:    */   
/*  41:    */   public static void glMakeTextureHandleNonResidentNV(long handle)
/*  42:    */   {
/*  43: 39 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  44: 40 */     long function_pointer = caps.glMakeTextureHandleNonResidentNV;
/*  45: 41 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  46: 42 */     nglMakeTextureHandleNonResidentNV(handle, function_pointer);
/*  47:    */   }
/*  48:    */   
/*  49:    */   static native void nglMakeTextureHandleNonResidentNV(long paramLong1, long paramLong2);
/*  50:    */   
/*  51:    */   public static long glGetImageHandleNV(int texture, int level, boolean layered, int layer, int format)
/*  52:    */   {
/*  53: 47 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  54: 48 */     long function_pointer = caps.glGetImageHandleNV;
/*  55: 49 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  56: 50 */     long __result = nglGetImageHandleNV(texture, level, layered, layer, format, function_pointer);
/*  57: 51 */     return __result;
/*  58:    */   }
/*  59:    */   
/*  60:    */   static native long nglGetImageHandleNV(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, long paramLong);
/*  61:    */   
/*  62:    */   public static void glMakeImageHandleResidentNV(long handle, int access)
/*  63:    */   {
/*  64: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  65: 57 */     long function_pointer = caps.glMakeImageHandleResidentNV;
/*  66: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  67: 59 */     nglMakeImageHandleResidentNV(handle, access, function_pointer);
/*  68:    */   }
/*  69:    */   
/*  70:    */   static native void nglMakeImageHandleResidentNV(long paramLong1, int paramInt, long paramLong2);
/*  71:    */   
/*  72:    */   public static void glMakeImageHandleNonResidentNV(long handle)
/*  73:    */   {
/*  74: 64 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  75: 65 */     long function_pointer = caps.glMakeImageHandleNonResidentNV;
/*  76: 66 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  77: 67 */     nglMakeImageHandleNonResidentNV(handle, function_pointer);
/*  78:    */   }
/*  79:    */   
/*  80:    */   static native void nglMakeImageHandleNonResidentNV(long paramLong1, long paramLong2);
/*  81:    */   
/*  82:    */   public static void glUniformHandleui64NV(int location, long value)
/*  83:    */   {
/*  84: 72 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  85: 73 */     long function_pointer = caps.glUniformHandleui64NV;
/*  86: 74 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  87: 75 */     nglUniformHandleui64NV(location, value, function_pointer);
/*  88:    */   }
/*  89:    */   
/*  90:    */   static native void nglUniformHandleui64NV(int paramInt, long paramLong1, long paramLong2);
/*  91:    */   
/*  92:    */   public static void glUniformHandleuNV(int location, LongBuffer value)
/*  93:    */   {
/*  94: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  95: 81 */     long function_pointer = caps.glUniformHandleui64vNV;
/*  96: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  97: 83 */     BufferChecks.checkDirect(value);
/*  98: 84 */     nglUniformHandleui64vNV(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/*  99:    */   }
/* 100:    */   
/* 101:    */   static native void nglUniformHandleui64vNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 102:    */   
/* 103:    */   public static void glProgramUniformHandleui64NV(int program, int location, long value)
/* 104:    */   {
/* 105: 89 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106: 90 */     long function_pointer = caps.glProgramUniformHandleui64NV;
/* 107: 91 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108: 92 */     nglProgramUniformHandleui64NV(program, location, value, function_pointer);
/* 109:    */   }
/* 110:    */   
/* 111:    */   static native void nglProgramUniformHandleui64NV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 112:    */   
/* 113:    */   public static void glProgramUniformHandleuNV(int program, int location, LongBuffer values)
/* 114:    */   {
/* 115: 97 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116: 98 */     long function_pointer = caps.glProgramUniformHandleui64vNV;
/* 117: 99 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:100 */     BufferChecks.checkDirect(values);
/* 119:101 */     nglProgramUniformHandleui64vNV(program, location, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 120:    */   }
/* 121:    */   
/* 122:    */   static native void nglProgramUniformHandleui64vNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 123:    */   
/* 124:    */   public static boolean glIsTextureHandleResidentNV(long handle)
/* 125:    */   {
/* 126:106 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:107 */     long function_pointer = caps.glIsTextureHandleResidentNV;
/* 128:108 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:109 */     boolean __result = nglIsTextureHandleResidentNV(handle, function_pointer);
/* 130:110 */     return __result;
/* 131:    */   }
/* 132:    */   
/* 133:    */   static native boolean nglIsTextureHandleResidentNV(long paramLong1, long paramLong2);
/* 134:    */   
/* 135:    */   public static boolean glIsImageHandleResidentNV(long handle)
/* 136:    */   {
/* 137:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 138:116 */     long function_pointer = caps.glIsImageHandleResidentNV;
/* 139:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 140:118 */     boolean __result = nglIsImageHandleResidentNV(handle, function_pointer);
/* 141:119 */     return __result;
/* 142:    */   }
/* 143:    */   
/* 144:    */   static native boolean nglIsImageHandleResidentNV(long paramLong1, long paramLong2);
/* 145:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVBindlessTexture
 * JD-Core Version:    0.7.0.1
 */