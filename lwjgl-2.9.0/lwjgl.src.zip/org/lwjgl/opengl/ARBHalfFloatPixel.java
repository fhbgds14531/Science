package org.lwjgl.opengl;

public final class ARBHalfFloatPixel
{
  public static final int GL_HALF_FLOAT_ARB = 5131;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBHalfFloatPixel
 * JD-Core Version:    0.7.0.1
 */