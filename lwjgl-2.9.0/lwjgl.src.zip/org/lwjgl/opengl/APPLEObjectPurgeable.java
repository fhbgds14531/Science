/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class APPLEObjectPurgeable
/*  8:   */ {
/*  9:   */   public static final int GL_RELEASED_APPLE = 35353;
/* 10:   */   public static final int GL_VOLATILE_APPLE = 35354;
/* 11:   */   public static final int GL_RETAINED_APPLE = 35355;
/* 12:   */   public static final int GL_UNDEFINED_APPLE = 35356;
/* 13:   */   public static final int GL_PURGEABLE_APPLE = 35357;
/* 14:   */   public static final int GL_BUFFER_OBJECT_APPLE = 34227;
/* 15:   */   
/* 16:   */   public static int glObjectPurgeableAPPLE(int objectType, int name, int option)
/* 17:   */   {
/* 18:38 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 19:39 */     long function_pointer = caps.glObjectPurgeableAPPLE;
/* 20:40 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 21:41 */     int __result = nglObjectPurgeableAPPLE(objectType, name, option, function_pointer);
/* 22:42 */     return __result;
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native int nglObjectPurgeableAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 26:   */   
/* 27:   */   public static int glObjectUnpurgeableAPPLE(int objectType, int name, int option)
/* 28:   */   {
/* 29:47 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:48 */     long function_pointer = caps.glObjectUnpurgeableAPPLE;
/* 31:49 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:50 */     int __result = nglObjectUnpurgeableAPPLE(objectType, name, option, function_pointer);
/* 33:51 */     return __result;
/* 34:   */   }
/* 35:   */   
/* 36:   */   static native int nglObjectUnpurgeableAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 37:   */   
/* 38:   */   public static void glGetObjectParameterAPPLE(int objectType, int name, int pname, IntBuffer params)
/* 39:   */   {
/* 40:56 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 41:57 */     long function_pointer = caps.glGetObjectParameterivAPPLE;
/* 42:58 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 43:59 */     BufferChecks.checkBuffer(params, 1);
/* 44:60 */     nglGetObjectParameterivAPPLE(objectType, name, pname, MemoryUtil.getAddress(params), function_pointer);
/* 45:   */   }
/* 46:   */   
/* 47:   */   static native void nglGetObjectParameterivAPPLE(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 48:   */   
/* 49:   */   public static int glGetObjectParameteriAPPLE(int objectType, int name, int pname)
/* 50:   */   {
/* 51:66 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 52:67 */     long function_pointer = caps.glGetObjectParameterivAPPLE;
/* 53:68 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 54:69 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 55:70 */     nglGetObjectParameterivAPPLE(objectType, name, pname, MemoryUtil.getAddress(params), function_pointer);
/* 56:71 */     return params.get(0);
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEObjectPurgeable
 * JD-Core Version:    0.7.0.1
 */