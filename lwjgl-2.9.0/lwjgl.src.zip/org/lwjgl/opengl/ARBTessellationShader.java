/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ 
/*   5:    */ public final class ARBTessellationShader
/*   6:    */ {
/*   7:    */   public static final int GL_PATCHES = 14;
/*   8:    */   public static final int GL_PATCH_VERTICES = 36466;
/*   9:    */   public static final int GL_PATCH_DEFAULT_INNER_LEVEL = 36467;
/*  10:    */   public static final int GL_PATCH_DEFAULT_OUTER_LEVEL = 36468;
/*  11:    */   public static final int GL_TESS_CONTROL_OUTPUT_VERTICES = 36469;
/*  12:    */   public static final int GL_TESS_GEN_MODE = 36470;
/*  13:    */   public static final int GL_TESS_GEN_SPACING = 36471;
/*  14:    */   public static final int GL_TESS_GEN_VERTEX_ORDER = 36472;
/*  15:    */   public static final int GL_TESS_GEN_POINT_MODE = 36473;
/*  16:    */   public static final int GL_TRIANGLES = 4;
/*  17:    */   public static final int GL_QUADS = 7;
/*  18:    */   public static final int GL_ISOLINES = 36474;
/*  19:    */   public static final int GL_EQUAL = 514;
/*  20:    */   public static final int GL_FRACTIONAL_ODD = 36475;
/*  21:    */   public static final int GL_FRACTIONAL_EVEN = 36476;
/*  22:    */   public static final int GL_CCW = 2305;
/*  23:    */   public static final int GL_CW = 2304;
/*  24:    */   public static final int GL_FALSE = 0;
/*  25:    */   public static final int GL_TRUE = 1;
/*  26:    */   public static final int GL_MAX_PATCH_VERTICES = 36477;
/*  27:    */   public static final int GL_MAX_TESS_GEN_LEVEL = 36478;
/*  28:    */   public static final int GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS = 36479;
/*  29:    */   public static final int GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS = 36480;
/*  30:    */   public static final int GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS = 36481;
/*  31:    */   public static final int GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS = 36482;
/*  32:    */   public static final int GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS = 36483;
/*  33:    */   public static final int GL_MAX_TESS_PATCH_COMPONENTS = 36484;
/*  34:    */   public static final int GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS = 36485;
/*  35:    */   public static final int GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS = 36486;
/*  36:    */   public static final int GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS = 36489;
/*  37:    */   public static final int GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS = 36490;
/*  38:    */   public static final int GL_MAX_TESS_CONTROL_INPUT_COMPONENTS = 34924;
/*  39:    */   public static final int GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS = 34925;
/*  40:    */   public static final int GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS = 36382;
/*  41:    */   public static final int GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS = 36383;
/*  42:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER = 34032;
/*  43:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER = 34033;
/*  44:    */   public static final int GL_TESS_EVALUATION_SHADER = 36487;
/*  45:    */   public static final int GL_TESS_CONTROL_SHADER = 36488;
/*  46:    */   
/*  47:    */   public static void glPatchParameteri(int pname, int value)
/*  48:    */   {
/*  49:101 */     GL40.glPatchParameteri(pname, value);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static void glPatchParameter(int pname, FloatBuffer values)
/*  53:    */   {
/*  54:105 */     GL40.glPatchParameter(pname, values);
/*  55:    */   }
/*  56:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTessellationShader
 * JD-Core Version:    0.7.0.1
 */