/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.DoubleBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import java.nio.LongBuffer;
/*   7:    */ import org.lwjgl.BufferChecks;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public final class NVVideoCapture
/*  11:    */ {
/*  12:    */   public static final int GL_VIDEO_BUFFER_NV = 36896;
/*  13:    */   public static final int GL_VIDEO_BUFFER_BINDING_NV = 36897;
/*  14:    */   public static final int GL_FIELD_UPPER_NV = 36898;
/*  15:    */   public static final int GL_FIELD_LOWER_NV = 36899;
/*  16:    */   public static final int GL_NUM_VIDEO_CAPTURE_STREAMS_NV = 36900;
/*  17:    */   public static final int GL_NEXT_VIDEO_CAPTURE_BUFFER_STATUS_NV = 36901;
/*  18:    */   public static final int GL_LAST_VIDEO_CAPTURE_STATUS_NV = 36903;
/*  19:    */   public static final int GL_VIDEO_BUFFER_PITCH_NV = 36904;
/*  20:    */   public static final int GL_VIDEO_CAPTURE_FRAME_WIDTH_NV = 36920;
/*  21:    */   public static final int GL_VIDEO_CAPTURE_FRAME_HEIGHT_NV = 36921;
/*  22:    */   public static final int GL_VIDEO_CAPTURE_FIELD_UPPER_HEIGHT_NV = 36922;
/*  23:    */   public static final int GL_VIDEO_CAPTURE_FIELD_LOWER_HEIGHT_NV = 36923;
/*  24:    */   public static final int GL_VIDEO_CAPTURE_TO_422_SUPPORTED_NV = 36902;
/*  25:    */   public static final int GL_VIDEO_COLOR_CONVERSION_MATRIX_NV = 36905;
/*  26:    */   public static final int GL_VIDEO_COLOR_CONVERSION_MAX_NV = 36906;
/*  27:    */   public static final int GL_VIDEO_COLOR_CONVERSION_MIN_NV = 36907;
/*  28:    */   public static final int GL_VIDEO_COLOR_CONVERSION_OFFSET_NV = 36908;
/*  29:    */   public static final int GL_VIDEO_BUFFER_INTERNAL_FORMAT_NV = 36909;
/*  30:    */   public static final int GL_VIDEO_CAPTURE_SURFACE_ORIGIN_NV = 36924;
/*  31:    */   public static final int GL_PARTIAL_SUCCESS_NV = 36910;
/*  32:    */   public static final int GL_SUCCESS_NV = 36911;
/*  33:    */   public static final int GL_FAILURE_NV = 36912;
/*  34:    */   public static final int GL_YCBYCR8_422_NV = 36913;
/*  35:    */   public static final int GL_YCBAYCR8A_4224_NV = 36914;
/*  36:    */   public static final int GL_Z6Y10Z6CB10Z6Y10Z6CR10_422_NV = 36915;
/*  37:    */   public static final int GL_Z6Y10Z6CB10Z6A10Z6Y10Z6CR10Z6A10_4224_NV = 36916;
/*  38:    */   public static final int GL_Z4Y12Z4CB12Z4Y12Z4CR12_422_NV = 36917;
/*  39:    */   public static final int GL_Z4Y12Z4CB12Z4A12Z4Y12Z4CR12Z4A12_4224_NV = 36918;
/*  40:    */   public static final int GL_Z4Y12Z4CB12Z4CR12_444_NV = 36919;
/*  41:    */   public static final int GL_NUM_VIDEO_CAPTURE_SLOTS_NV = 8399;
/*  42:    */   public static final int GL_UNIQUE_ID_NV = 8398;
/*  43:    */   
/*  44:    */   public static void glBeginVideoCaptureNV(int video_capture_slot)
/*  45:    */   {
/*  46:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  47:102 */     long function_pointer = caps.glBeginVideoCaptureNV;
/*  48:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  49:104 */     nglBeginVideoCaptureNV(video_capture_slot, function_pointer);
/*  50:    */   }
/*  51:    */   
/*  52:    */   static native void nglBeginVideoCaptureNV(int paramInt, long paramLong);
/*  53:    */   
/*  54:    */   public static void glBindVideoCaptureStreamBufferNV(int video_capture_slot, int stream, int frame_region, long offset)
/*  55:    */   {
/*  56:109 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  57:110 */     long function_pointer = caps.glBindVideoCaptureStreamBufferNV;
/*  58:111 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  59:112 */     nglBindVideoCaptureStreamBufferNV(video_capture_slot, stream, frame_region, offset, function_pointer);
/*  60:    */   }
/*  61:    */   
/*  62:    */   static native void nglBindVideoCaptureStreamBufferNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  63:    */   
/*  64:    */   public static void glBindVideoCaptureStreamTextureNV(int video_capture_slot, int stream, int frame_region, int target, int texture)
/*  65:    */   {
/*  66:117 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  67:118 */     long function_pointer = caps.glBindVideoCaptureStreamTextureNV;
/*  68:119 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  69:120 */     nglBindVideoCaptureStreamTextureNV(video_capture_slot, stream, frame_region, target, texture, function_pointer);
/*  70:    */   }
/*  71:    */   
/*  72:    */   static native void nglBindVideoCaptureStreamTextureNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  73:    */   
/*  74:    */   public static void glEndVideoCaptureNV(int video_capture_slot)
/*  75:    */   {
/*  76:125 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  77:126 */     long function_pointer = caps.glEndVideoCaptureNV;
/*  78:127 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  79:128 */     nglEndVideoCaptureNV(video_capture_slot, function_pointer);
/*  80:    */   }
/*  81:    */   
/*  82:    */   static native void nglEndVideoCaptureNV(int paramInt, long paramLong);
/*  83:    */   
/*  84:    */   public static void glGetVideoCaptureNV(int video_capture_slot, int pname, IntBuffer params)
/*  85:    */   {
/*  86:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  87:134 */     long function_pointer = caps.glGetVideoCaptureivNV;
/*  88:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  89:136 */     BufferChecks.checkBuffer(params, 1);
/*  90:137 */     nglGetVideoCaptureivNV(video_capture_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/*  91:    */   }
/*  92:    */   
/*  93:    */   static native void nglGetVideoCaptureivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  94:    */   
/*  95:    */   public static int glGetVideoCaptureiNV(int video_capture_slot, int pname)
/*  96:    */   {
/*  97:143 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98:144 */     long function_pointer = caps.glGetVideoCaptureivNV;
/*  99:145 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100:146 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 101:147 */     nglGetVideoCaptureivNV(video_capture_slot, pname, MemoryUtil.getAddress(params), function_pointer);
/* 102:148 */     return params.get(0);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static void glGetVideoCaptureStreamNV(int video_capture_slot, int stream, int pname, IntBuffer params)
/* 106:    */   {
/* 107:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 108:153 */     long function_pointer = caps.glGetVideoCaptureStreamivNV;
/* 109:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 110:155 */     BufferChecks.checkBuffer(params, 1);
/* 111:156 */     nglGetVideoCaptureStreamivNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 112:    */   }
/* 113:    */   
/* 114:    */   static native void nglGetVideoCaptureStreamivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 115:    */   
/* 116:    */   public static int glGetVideoCaptureStreamiNV(int video_capture_slot, int stream, int pname)
/* 117:    */   {
/* 118:162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 119:163 */     long function_pointer = caps.glGetVideoCaptureStreamivNV;
/* 120:164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 121:165 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 122:166 */     nglGetVideoCaptureStreamivNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 123:167 */     return params.get(0);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static void glGetVideoCaptureStreamNV(int video_capture_slot, int stream, int pname, FloatBuffer params)
/* 127:    */   {
/* 128:171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 129:172 */     long function_pointer = caps.glGetVideoCaptureStreamfvNV;
/* 130:173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 131:174 */     BufferChecks.checkBuffer(params, 1);
/* 132:175 */     nglGetVideoCaptureStreamfvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 133:    */   }
/* 134:    */   
/* 135:    */   static native void nglGetVideoCaptureStreamfvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 136:    */   
/* 137:    */   public static float glGetVideoCaptureStreamfNV(int video_capture_slot, int stream, int pname)
/* 138:    */   {
/* 139:181 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 140:182 */     long function_pointer = caps.glGetVideoCaptureStreamfvNV;
/* 141:183 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 142:184 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 143:185 */     nglGetVideoCaptureStreamfvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 144:186 */     return params.get(0);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static void glGetVideoCaptureStreamNV(int video_capture_slot, int stream, int pname, DoubleBuffer params)
/* 148:    */   {
/* 149:190 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:191 */     long function_pointer = caps.glGetVideoCaptureStreamdvNV;
/* 151:192 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:193 */     BufferChecks.checkBuffer(params, 1);
/* 153:194 */     nglGetVideoCaptureStreamdvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 154:    */   }
/* 155:    */   
/* 156:    */   static native void nglGetVideoCaptureStreamdvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 157:    */   
/* 158:    */   public static double glGetVideoCaptureStreamdNV(int video_capture_slot, int stream, int pname)
/* 159:    */   {
/* 160:200 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:201 */     long function_pointer = caps.glGetVideoCaptureStreamdvNV;
/* 162:202 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:203 */     DoubleBuffer params = APIUtil.getBufferDouble(caps);
/* 164:204 */     nglGetVideoCaptureStreamdvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 165:205 */     return params.get(0);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static int glVideoCaptureNV(int video_capture_slot, IntBuffer sequence_num, LongBuffer capture_time)
/* 169:    */   {
/* 170:209 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 171:210 */     long function_pointer = caps.glVideoCaptureNV;
/* 172:211 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 173:212 */     BufferChecks.checkBuffer(sequence_num, 1);
/* 174:213 */     BufferChecks.checkBuffer(capture_time, 1);
/* 175:214 */     int __result = nglVideoCaptureNV(video_capture_slot, MemoryUtil.getAddress(sequence_num), MemoryUtil.getAddress(capture_time), function_pointer);
/* 176:215 */     return __result;
/* 177:    */   }
/* 178:    */   
/* 179:    */   static native int nglVideoCaptureNV(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/* 180:    */   
/* 181:    */   public static void glVideoCaptureStreamParameterNV(int video_capture_slot, int stream, int pname, IntBuffer params)
/* 182:    */   {
/* 183:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 184:221 */     long function_pointer = caps.glVideoCaptureStreamParameterivNV;
/* 185:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 186:223 */     BufferChecks.checkBuffer(params, 16);
/* 187:224 */     nglVideoCaptureStreamParameterivNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 188:    */   }
/* 189:    */   
/* 190:    */   static native void nglVideoCaptureStreamParameterivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 191:    */   
/* 192:    */   public static void glVideoCaptureStreamParameterNV(int video_capture_slot, int stream, int pname, FloatBuffer params)
/* 193:    */   {
/* 194:229 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 195:230 */     long function_pointer = caps.glVideoCaptureStreamParameterfvNV;
/* 196:231 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 197:232 */     BufferChecks.checkBuffer(params, 16);
/* 198:233 */     nglVideoCaptureStreamParameterfvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   static native void nglVideoCaptureStreamParameterfvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 202:    */   
/* 203:    */   public static void glVideoCaptureStreamParameterNV(int video_capture_slot, int stream, int pname, DoubleBuffer params)
/* 204:    */   {
/* 205:238 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 206:239 */     long function_pointer = caps.glVideoCaptureStreamParameterdvNV;
/* 207:240 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 208:241 */     BufferChecks.checkBuffer(params, 16);
/* 209:242 */     nglVideoCaptureStreamParameterdvNV(video_capture_slot, stream, pname, MemoryUtil.getAddress(params), function_pointer);
/* 210:    */   }
/* 211:    */   
/* 212:    */   static native void nglVideoCaptureStreamParameterdvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 213:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVVideoCapture
 * JD-Core Version:    0.7.0.1
 */