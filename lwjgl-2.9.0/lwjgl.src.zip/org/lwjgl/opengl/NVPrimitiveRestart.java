/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVPrimitiveRestart
/*  6:   */ {
/*  7:   */   public static final int GL_PRIMITIVE_RESTART_NV = 34136;
/*  8:   */   public static final int GL_PRIMITIVE_RESTART_INDEX_NV = 34137;
/*  9:   */   
/* 10:   */   public static void glPrimitiveRestartNV()
/* 11:   */   {
/* 12:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:28 */     long function_pointer = caps.glPrimitiveRestartNV;
/* 14:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:30 */     nglPrimitiveRestartNV(function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglPrimitiveRestartNV(long paramLong);
/* 19:   */   
/* 20:   */   public static void glPrimitiveRestartIndexNV(int index)
/* 21:   */   {
/* 22:35 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:36 */     long function_pointer = caps.glPrimitiveRestartIndexNV;
/* 24:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:38 */     nglPrimitiveRestartIndexNV(index, function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglPrimitiveRestartIndexNV(int paramInt, long paramLong);
/* 29:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPrimitiveRestart
 * JD-Core Version:    0.7.0.1
 */