/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class EXTDrawBuffers2
/*  9:   */ {
/* 10:   */   public static void glColorMaskIndexedEXT(int buf, boolean r, boolean g, boolean b, boolean a)
/* 11:   */   {
/* 12:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:14 */     long function_pointer = caps.glColorMaskIndexedEXT;
/* 14:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:16 */     nglColorMaskIndexedEXT(buf, r, g, b, a, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglColorMaskIndexedEXT(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong);
/* 19:   */   
/* 20:   */   public static void glGetBooleanIndexedEXT(int value, int index, ByteBuffer data)
/* 21:   */   {
/* 22:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:22 */     long function_pointer = caps.glGetBooleanIndexedvEXT;
/* 24:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:24 */     BufferChecks.checkBuffer(data, 4);
/* 26:25 */     nglGetBooleanIndexedvEXT(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   static native void nglGetBooleanIndexedvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 30:   */   
/* 31:   */   public static boolean glGetBooleanIndexedEXT(int value, int index)
/* 32:   */   {
/* 33:31 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 34:32 */     long function_pointer = caps.glGetBooleanIndexedvEXT;
/* 35:33 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:34 */     ByteBuffer data = APIUtil.getBufferByte(caps, 1);
/* 37:35 */     nglGetBooleanIndexedvEXT(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 38:36 */     return data.get(0) == 1;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static void glGetIntegerIndexedEXT(int value, int index, IntBuffer data)
/* 42:   */   {
/* 43:40 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 44:41 */     long function_pointer = caps.glGetIntegerIndexedvEXT;
/* 45:42 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 46:43 */     BufferChecks.checkBuffer(data, 4);
/* 47:44 */     nglGetIntegerIndexedvEXT(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 48:   */   }
/* 49:   */   
/* 50:   */   static native void nglGetIntegerIndexedvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 51:   */   
/* 52:   */   public static int glGetIntegerIndexedEXT(int value, int index)
/* 53:   */   {
/* 54:50 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 55:51 */     long function_pointer = caps.glGetIntegerIndexedvEXT;
/* 56:52 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 57:53 */     IntBuffer data = APIUtil.getBufferInt(caps);
/* 58:54 */     nglGetIntegerIndexedvEXT(value, index, MemoryUtil.getAddress(data), function_pointer);
/* 59:55 */     return data.get(0);
/* 60:   */   }
/* 61:   */   
/* 62:   */   public static void glEnableIndexedEXT(int target, int index)
/* 63:   */   {
/* 64:59 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 65:60 */     long function_pointer = caps.glEnableIndexedEXT;
/* 66:61 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 67:62 */     nglEnableIndexedEXT(target, index, function_pointer);
/* 68:   */   }
/* 69:   */   
/* 70:   */   static native void nglEnableIndexedEXT(int paramInt1, int paramInt2, long paramLong);
/* 71:   */   
/* 72:   */   public static void glDisableIndexedEXT(int target, int index)
/* 73:   */   {
/* 74:67 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 75:68 */     long function_pointer = caps.glDisableIndexedEXT;
/* 76:69 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 77:70 */     nglDisableIndexedEXT(target, index, function_pointer);
/* 78:   */   }
/* 79:   */   
/* 80:   */   static native void nglDisableIndexedEXT(int paramInt1, int paramInt2, long paramLong);
/* 81:   */   
/* 82:   */   public static boolean glIsEnabledIndexedEXT(int target, int index)
/* 83:   */   {
/* 84:75 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 85:76 */     long function_pointer = caps.glIsEnabledIndexedEXT;
/* 86:77 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 87:78 */     boolean __result = nglIsEnabledIndexedEXT(target, index, function_pointer);
/* 88:79 */     return __result;
/* 89:   */   }
/* 90:   */   
/* 91:   */   static native boolean nglIsEnabledIndexedEXT(int paramInt1, int paramInt2, long paramLong);
/* 92:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTDrawBuffers2
 * JD-Core Version:    0.7.0.1
 */