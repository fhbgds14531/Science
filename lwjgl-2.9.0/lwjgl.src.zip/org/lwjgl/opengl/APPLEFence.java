/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class APPLEFence
/*   8:    */ {
/*   9:    */   public static final int GL_DRAW_PIXELS_APPLE = 35338;
/*  10:    */   public static final int GL_FENCE_APPLE = 35339;
/*  11:    */   
/*  12:    */   public static void glGenFencesAPPLE(IntBuffer fences)
/*  13:    */   {
/*  14: 19 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  15: 20 */     long function_pointer = caps.glGenFencesAPPLE;
/*  16: 21 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  17: 22 */     BufferChecks.checkDirect(fences);
/*  18: 23 */     nglGenFencesAPPLE(fences.remaining(), MemoryUtil.getAddress(fences), function_pointer);
/*  19:    */   }
/*  20:    */   
/*  21:    */   static native void nglGenFencesAPPLE(int paramInt, long paramLong1, long paramLong2);
/*  22:    */   
/*  23:    */   public static int glGenFencesAPPLE()
/*  24:    */   {
/*  25: 29 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  26: 30 */     long function_pointer = caps.glGenFencesAPPLE;
/*  27: 31 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  28: 32 */     IntBuffer fences = APIUtil.getBufferInt(caps);
/*  29: 33 */     nglGenFencesAPPLE(1, MemoryUtil.getAddress(fences), function_pointer);
/*  30: 34 */     return fences.get(0);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static void glDeleteFencesAPPLE(IntBuffer fences)
/*  34:    */   {
/*  35: 38 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 39 */     long function_pointer = caps.glDeleteFencesAPPLE;
/*  37: 40 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 41 */     BufferChecks.checkDirect(fences);
/*  39: 42 */     nglDeleteFencesAPPLE(fences.remaining(), MemoryUtil.getAddress(fences), function_pointer);
/*  40:    */   }
/*  41:    */   
/*  42:    */   static native void nglDeleteFencesAPPLE(int paramInt, long paramLong1, long paramLong2);
/*  43:    */   
/*  44:    */   public static void glDeleteFencesAPPLE(int fence)
/*  45:    */   {
/*  46: 48 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  47: 49 */     long function_pointer = caps.glDeleteFencesAPPLE;
/*  48: 50 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  49: 51 */     nglDeleteFencesAPPLE(1, APIUtil.getInt(caps, fence), function_pointer);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static void glSetFenceAPPLE(int fence)
/*  53:    */   {
/*  54: 55 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  55: 56 */     long function_pointer = caps.glSetFenceAPPLE;
/*  56: 57 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  57: 58 */     nglSetFenceAPPLE(fence, function_pointer);
/*  58:    */   }
/*  59:    */   
/*  60:    */   static native void nglSetFenceAPPLE(int paramInt, long paramLong);
/*  61:    */   
/*  62:    */   public static boolean glIsFenceAPPLE(int fence)
/*  63:    */   {
/*  64: 63 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  65: 64 */     long function_pointer = caps.glIsFenceAPPLE;
/*  66: 65 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  67: 66 */     boolean __result = nglIsFenceAPPLE(fence, function_pointer);
/*  68: 67 */     return __result;
/*  69:    */   }
/*  70:    */   
/*  71:    */   static native boolean nglIsFenceAPPLE(int paramInt, long paramLong);
/*  72:    */   
/*  73:    */   public static boolean glTestFenceAPPLE(int fence)
/*  74:    */   {
/*  75: 72 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  76: 73 */     long function_pointer = caps.glTestFenceAPPLE;
/*  77: 74 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  78: 75 */     boolean __result = nglTestFenceAPPLE(fence, function_pointer);
/*  79: 76 */     return __result;
/*  80:    */   }
/*  81:    */   
/*  82:    */   static native boolean nglTestFenceAPPLE(int paramInt, long paramLong);
/*  83:    */   
/*  84:    */   public static void glFinishFenceAPPLE(int fence)
/*  85:    */   {
/*  86: 81 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  87: 82 */     long function_pointer = caps.glFinishFenceAPPLE;
/*  88: 83 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  89: 84 */     nglFinishFenceAPPLE(fence, function_pointer);
/*  90:    */   }
/*  91:    */   
/*  92:    */   static native void nglFinishFenceAPPLE(int paramInt, long paramLong);
/*  93:    */   
/*  94:    */   public static boolean glTestObjectAPPLE(int object, int name)
/*  95:    */   {
/*  96: 89 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  97: 90 */     long function_pointer = caps.glTestObjectAPPLE;
/*  98: 91 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  99: 92 */     boolean __result = nglTestObjectAPPLE(object, name, function_pointer);
/* 100: 93 */     return __result;
/* 101:    */   }
/* 102:    */   
/* 103:    */   static native boolean nglTestObjectAPPLE(int paramInt1, int paramInt2, long paramLong);
/* 104:    */   
/* 105:    */   public static void glFinishObjectAPPLE(int object, int name)
/* 106:    */   {
/* 107: 98 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 108: 99 */     long function_pointer = caps.glFinishObjectAPPLE;
/* 109:100 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 110:101 */     nglFinishObjectAPPLE(object, name, function_pointer);
/* 111:    */   }
/* 112:    */   
/* 113:    */   static native void nglFinishObjectAPPLE(int paramInt1, int paramInt2, long paramLong);
/* 114:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEFence
 * JD-Core Version:    0.7.0.1
 */