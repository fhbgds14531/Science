/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ 
/*   5:    */ final class FastLongMap<V>
/*   6:    */   implements Iterable<Entry<V>>
/*   7:    */ {
/*   8:    */   private Entry[] table;
/*   9:    */   private int size;
/*  10:    */   private int mask;
/*  11:    */   private int capacity;
/*  12:    */   private int threshold;
/*  13:    */   
/*  14:    */   FastLongMap()
/*  15:    */   {
/*  16: 32 */     this(16, 0.75F);
/*  17:    */   }
/*  18:    */   
/*  19:    */   FastLongMap(int initialCapacity)
/*  20:    */   {
/*  21: 37 */     this(initialCapacity, 0.75F);
/*  22:    */   }
/*  23:    */   
/*  24:    */   FastLongMap(int initialCapacity, float loadFactor)
/*  25:    */   {
/*  26: 41 */     if (initialCapacity > 1073741824) {
/*  27: 41 */       throw new IllegalArgumentException("initialCapacity is too large.");
/*  28:    */     }
/*  29: 42 */     if (initialCapacity < 0) {
/*  30: 42 */       throw new IllegalArgumentException("initialCapacity must be greater than zero.");
/*  31:    */     }
/*  32: 43 */     if (loadFactor <= 0.0F) {
/*  33: 43 */       throw new IllegalArgumentException("initialCapacity must be greater than zero.");
/*  34:    */     }
/*  35: 44 */     this.capacity = 1;
/*  36: 45 */     while (this.capacity < initialCapacity) {
/*  37: 46 */       this.capacity <<= 1;
/*  38:    */     }
/*  39: 47 */     this.threshold = ((int)(this.capacity * loadFactor));
/*  40: 48 */     this.table = new Entry[this.capacity];
/*  41: 49 */     this.mask = (this.capacity - 1);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private int index(long key)
/*  45:    */   {
/*  46: 53 */     return index(key, this.mask);
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static int index(long key, int mask)
/*  50:    */   {
/*  51: 57 */     int hash = (int)(key ^ key >>> 32);
/*  52: 58 */     return hash & mask;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public V put(long key, V value)
/*  56:    */   {
/*  57: 62 */     Entry<V>[] table = this.table;
/*  58: 63 */     int index = index(key);
/*  59: 66 */     for (Entry<V> e = table[index]; e != null; e = e.next) {
/*  60: 67 */       if (e.key == key)
/*  61:    */       {
/*  62: 68 */         V oldValue = e.value;
/*  63: 69 */         e.value = value;
/*  64: 70 */         return oldValue;
/*  65:    */       }
/*  66:    */     }
/*  67: 73 */     table[index] = new Entry(key, value, table[index]);
/*  68: 75 */     if (this.size++ >= this.threshold) {
/*  69: 76 */       rehash(table);
/*  70:    */     }
/*  71: 78 */     return null;
/*  72:    */   }
/*  73:    */   
/*  74:    */   private void rehash(Entry<V>[] table)
/*  75:    */   {
/*  76: 82 */     int newCapacity = 2 * this.capacity;
/*  77: 83 */     int newMask = newCapacity - 1;
/*  78:    */     
/*  79: 85 */     Entry<V>[] newTable = new Entry[newCapacity];
/*  80: 87 */     for (int i = 0; i < table.length; i++)
/*  81:    */     {
/*  82: 88 */       Entry<V> e = table[i];
/*  83: 89 */       if (e != null) {
/*  84:    */         do
/*  85:    */         {
/*  86: 91 */           Entry<V> next = e.next;
/*  87: 92 */           int index = index(e.key, newMask);
/*  88: 93 */           e.next = newTable[index];
/*  89: 94 */           newTable[index] = e;
/*  90: 95 */           e = next;
/*  91: 96 */         } while (e != null);
/*  92:    */       }
/*  93:    */     }
/*  94: 99 */     this.table = newTable;
/*  95:100 */     this.capacity = newCapacity;
/*  96:101 */     this.mask = newMask;
/*  97:102 */     this.threshold *= 2;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public V get(long key)
/* 101:    */   {
/* 102:106 */     int index = index(key);
/* 103:107 */     for (Entry<V> e = this.table[index]; e != null; e = e.next) {
/* 104:108 */       if (e.key == key) {
/* 105:108 */         return e.value;
/* 106:    */       }
/* 107:    */     }
/* 108:109 */     return null;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public boolean containsValue(Object value)
/* 112:    */   {
/* 113:113 */     Entry<V>[] table = this.table;
/* 114:114 */     for (int i = table.length - 1; i >= 0; i--) {
/* 115:115 */       for (Entry<V> e = table[i]; e != null; e = e.next) {
/* 116:116 */         if (e.value.equals(value)) {
/* 117:116 */           return true;
/* 118:    */         }
/* 119:    */       }
/* 120:    */     }
/* 121:117 */     return false;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public boolean containsKey(long key)
/* 125:    */   {
/* 126:121 */     int index = index(key);
/* 127:122 */     for (Entry<V> e = this.table[index]; e != null; e = e.next) {
/* 128:123 */       if (e.key == key) {
/* 129:123 */         return true;
/* 130:    */       }
/* 131:    */     }
/* 132:124 */     return false;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public V remove(long key)
/* 136:    */   {
/* 137:128 */     int index = index(key);
/* 138:    */     
/* 139:130 */     Entry<V> prev = this.table[index];
/* 140:131 */     Entry<V> e = prev;
/* 141:132 */     while (e != null)
/* 142:    */     {
/* 143:133 */       Entry<V> next = e.next;
/* 144:134 */       if (e.key == key)
/* 145:    */       {
/* 146:135 */         this.size -= 1;
/* 147:136 */         if (prev == e) {
/* 148:137 */           this.table[index] = next;
/* 149:    */         } else {
/* 150:139 */           prev.next = next;
/* 151:    */         }
/* 152:140 */         return e.value;
/* 153:    */       }
/* 154:142 */       prev = e;
/* 155:143 */       e = next;
/* 156:    */     }
/* 157:145 */     return null;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public int size()
/* 161:    */   {
/* 162:149 */     return this.size;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public boolean isEmpty()
/* 166:    */   {
/* 167:153 */     return this.size == 0;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void clear()
/* 171:    */   {
/* 172:157 */     Entry<V>[] table = this.table;
/* 173:158 */     for (int index = table.length - 1; index >= 0; index--) {
/* 174:159 */       table[index] = null;
/* 175:    */     }
/* 176:160 */     this.size = 0;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public FastLongMap<V>.EntryIterator iterator()
/* 180:    */   {
/* 181:164 */     return new EntryIterator();
/* 182:    */   }
/* 183:    */   
/* 184:    */   public class EntryIterator
/* 185:    */     implements Iterator<FastLongMap.Entry<V>>
/* 186:    */   {
/* 187:    */     private int nextIndex;
/* 188:    */     private FastLongMap.Entry<V> current;
/* 189:    */     
/* 190:    */     EntryIterator()
/* 191:    */     {
/* 192:173 */       reset();
/* 193:    */     }
/* 194:    */     
/* 195:    */     public void reset()
/* 196:    */     {
/* 197:177 */       this.current = null;
/* 198:    */       
/* 199:179 */       FastLongMap.Entry<V>[] table = FastLongMap.this.table;
/* 200:181 */       for (int i = table.length - 1; i >= 0; i--) {
/* 201:182 */         if (table[i] != null) {
/* 202:    */           break;
/* 203:    */         }
/* 204:    */       }
/* 205:183 */       this.nextIndex = i;
/* 206:    */     }
/* 207:    */     
/* 208:    */     public boolean hasNext()
/* 209:    */     {
/* 210:187 */       if (this.nextIndex >= 0) {
/* 211:187 */         return true;
/* 212:    */       }
/* 213:188 */       FastLongMap.Entry e = this.current;
/* 214:189 */       return (e != null) && (e.next != null);
/* 215:    */     }
/* 216:    */     
/* 217:    */     public FastLongMap.Entry<V> next()
/* 218:    */     {
/* 219:194 */       FastLongMap.Entry<V> e = this.current;
/* 220:195 */       if (e != null)
/* 221:    */       {
/* 222:196 */         e = e.next;
/* 223:197 */         if (e != null)
/* 224:    */         {
/* 225:198 */           this.current = e;
/* 226:199 */           return e;
/* 227:    */         }
/* 228:    */       }
/* 229:203 */       FastLongMap.Entry<V>[] table = FastLongMap.this.table;
/* 230:204 */       int i = this.nextIndex;
/* 231:205 */       e = this.current = table[i];
/* 232:    */       for (;;)
/* 233:    */       {
/* 234:206 */         i--;
/* 235:206 */         if (i >= 0) {
/* 236:207 */           if (table[i] != null) {
/* 237:    */             break;
/* 238:    */           }
/* 239:    */         }
/* 240:    */       }
/* 241:208 */       this.nextIndex = i;
/* 242:209 */       return e;
/* 243:    */     }
/* 244:    */     
/* 245:    */     public void remove()
/* 246:    */     {
/* 247:213 */       FastLongMap.this.remove(this.current.key);
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   static final class Entry<T>
/* 252:    */   {
/* 253:    */     final long key;
/* 254:    */     T value;
/* 255:    */     Entry<T> next;
/* 256:    */     
/* 257:    */     Entry(long key, T value, Entry<T> next)
/* 258:    */     {
/* 259:224 */       this.key = key;
/* 260:225 */       this.value = value;
/* 261:226 */       this.next = next;
/* 262:    */     }
/* 263:    */     
/* 264:    */     public long getKey()
/* 265:    */     {
/* 266:230 */       return this.key;
/* 267:    */     }
/* 268:    */     
/* 269:    */     public T getValue()
/* 270:    */     {
/* 271:234 */       return this.value;
/* 272:    */     }
/* 273:    */   }
/* 274:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.FastLongMap
 * JD-Core Version:    0.7.0.1
 */