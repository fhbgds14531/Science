/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.Graphics;
/*   6:    */ import java.awt.GraphicsDevice;
/*   7:    */ import java.awt.GraphicsEnvironment;
/*   8:    */ import java.awt.Point;
/*   9:    */ import java.awt.event.ComponentEvent;
/*  10:    */ import java.awt.event.ComponentListener;
/*  11:    */ import java.awt.event.HierarchyEvent;
/*  12:    */ import java.awt.event.HierarchyListener;
/*  13:    */ import org.lwjgl.LWJGLException;
/*  14:    */ import org.lwjgl.LWJGLUtil;
/*  15:    */ import org.lwjgl.PointerBuffer;
/*  16:    */ import org.lwjgl.Sys;
/*  17:    */ 
/*  18:    */ public class AWTGLCanvas
/*  19:    */   extends Canvas
/*  20:    */   implements DrawableLWJGL, ComponentListener, HierarchyListener
/*  21:    */ {
/*  22:    */   private boolean first_run;
/*  23:    */   private int reentry_count;
/*  24:    */   private ContextGL context;
/*  25:    */   private PeerInfo peer_info;
/*  26:    */   private final ContextAttribs attribs;
/*  27:    */   private final Drawable drawable;
/*  28:    */   private final PixelFormat pixel_format;
/*  29: 62 */   private Object SYNC_LOCK = new Object();
/*  30:    */   private boolean update_context;
/*  31: 88 */   private static final AWTCanvasImplementation implementation = createImplementation();
/*  32:    */   private static final long serialVersionUID = 1L;
/*  33:    */   
/*  34:    */   static AWTCanvasImplementation createImplementation()
/*  35:    */   {
/*  36: 92 */     switch ()
/*  37:    */     {
/*  38:    */     case 1: 
/*  39: 94 */       return new LinuxCanvasImplementation();
/*  40:    */     case 3: 
/*  41: 96 */       return new WindowsCanvasImplementation();
/*  42:    */     case 2: 
/*  43: 98 */       return new MacOSXCanvasImplementation();
/*  44:    */     }
/*  45:100 */     throw new IllegalStateException("Unsupported platform");
/*  46:    */   }
/*  47:    */   
/*  48:    */   private void setUpdate()
/*  49:    */   {
/*  50:105 */     synchronized (this.SYNC_LOCK)
/*  51:    */     {
/*  52:106 */       this.update_context = true;
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setPixelFormat(PixelFormatLWJGL pf)
/*  57:    */     throws LWJGLException
/*  58:    */   {
/*  59:111 */     throw new UnsupportedOperationException();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setPixelFormat(PixelFormatLWJGL pf, ContextAttribs attribs)
/*  63:    */     throws LWJGLException
/*  64:    */   {
/*  65:115 */     throw new UnsupportedOperationException();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public PixelFormatLWJGL getPixelFormat()
/*  69:    */   {
/*  70:119 */     return this.pixel_format;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public ContextGL getContext()
/*  74:    */   {
/*  75:124 */     return this.context;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public ContextGL createSharedContext()
/*  79:    */     throws LWJGLException
/*  80:    */   {
/*  81:129 */     synchronized (this.SYNC_LOCK)
/*  82:    */     {
/*  83:130 */       if (this.context == null) {
/*  84:130 */         throw new IllegalStateException("Canvas not yet displayable");
/*  85:    */       }
/*  86:132 */       return new ContextGL(this.peer_info, this.context.getContextAttribs(), this.context);
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void checkGLError() {}
/*  91:    */   
/*  92:    */   public void initContext(float r, float g, float b)
/*  93:    */   {
/*  94:142 */     GL11.glClearColor(r, g, b, 0.0F);
/*  95:    */     
/*  96:144 */     GL11.glClear(16384);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public AWTGLCanvas()
/* 100:    */     throws LWJGLException
/* 101:    */   {
/* 102:149 */     this(new PixelFormat());
/* 103:    */   }
/* 104:    */   
/* 105:    */   public AWTGLCanvas(PixelFormat pixel_format)
/* 106:    */     throws LWJGLException
/* 107:    */   {
/* 108:158 */     this(GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice(), pixel_format);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public AWTGLCanvas(GraphicsDevice device, PixelFormat pixel_format)
/* 112:    */     throws LWJGLException
/* 113:    */   {
/* 114:168 */     this(device, pixel_format, null);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public AWTGLCanvas(GraphicsDevice device, PixelFormat pixel_format, Drawable drawable)
/* 118:    */     throws LWJGLException
/* 119:    */   {
/* 120:179 */     this(device, pixel_format, drawable, null);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public AWTGLCanvas(GraphicsDevice device, PixelFormat pixel_format, Drawable drawable, ContextAttribs attribs)
/* 124:    */     throws LWJGLException
/* 125:    */   {
/* 126:191 */     super(implementation.findConfiguration(device, pixel_format));
/* 127:192 */     if (pixel_format == null) {
/* 128:193 */       throw new NullPointerException("Pixel format must be non-null");
/* 129:    */     }
/* 130:194 */     addHierarchyListener(this);
/* 131:195 */     addComponentListener(this);
/* 132:196 */     this.drawable = drawable;
/* 133:197 */     this.pixel_format = pixel_format;
/* 134:198 */     this.attribs = attribs;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void addNotify()
/* 138:    */   {
/* 139:205 */     super.addNotify();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void removeNotify()
/* 143:    */   {
/* 144:212 */     synchronized (this.SYNC_LOCK)
/* 145:    */     {
/* 146:213 */       destroy();
/* 147:214 */       super.removeNotify();
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void setSwapInterval(int swap_interval)
/* 152:    */   {
/* 153:220 */     synchronized (this.SYNC_LOCK)
/* 154:    */     {
/* 155:221 */       if (this.context == null) {
/* 156:222 */         throw new IllegalStateException("Canvas not yet displayable");
/* 157:    */       }
/* 158:223 */       ContextGL.setSwapInterval(swap_interval);
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setVSyncEnabled(boolean enabled)
/* 163:    */   {
/* 164:229 */     setSwapInterval(enabled ? 1 : 0);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void swapBuffers()
/* 168:    */     throws LWJGLException
/* 169:    */   {
/* 170:234 */     synchronized (this.SYNC_LOCK)
/* 171:    */     {
/* 172:235 */       if (this.context == null) {
/* 173:236 */         throw new IllegalStateException("Canvas not yet displayable");
/* 174:    */       }
/* 175:237 */       ContextGL.swapBuffers();
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   public boolean isCurrent()
/* 180:    */     throws LWJGLException
/* 181:    */   {
/* 182:242 */     synchronized (this.SYNC_LOCK)
/* 183:    */     {
/* 184:243 */       if (this.context == null) {
/* 185:243 */         throw new IllegalStateException("Canvas not yet displayable");
/* 186:    */       }
/* 187:245 */       return this.context.isCurrent();
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void makeCurrent()
/* 192:    */     throws LWJGLException
/* 193:    */   {
/* 194:254 */     synchronized (this.SYNC_LOCK)
/* 195:    */     {
/* 196:255 */       if (this.context == null) {
/* 197:256 */         throw new IllegalStateException("Canvas not yet displayable");
/* 198:    */       }
/* 199:257 */       this.context.makeCurrent();
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public void releaseContext()
/* 204:    */     throws LWJGLException
/* 205:    */   {
/* 206:262 */     synchronized (this.SYNC_LOCK)
/* 207:    */     {
/* 208:263 */       if (this.context == null) {
/* 209:264 */         throw new IllegalStateException("Canvas not yet displayable");
/* 210:    */       }
/* 211:265 */       if (this.context.isCurrent()) {
/* 212:266 */         this.context.releaseCurrent();
/* 213:    */       }
/* 214:    */     }
/* 215:    */   }
/* 216:    */   
/* 217:    */   public final void destroy()
/* 218:    */   {
/* 219:272 */     synchronized (this.SYNC_LOCK)
/* 220:    */     {
/* 221:    */       try
/* 222:    */       {
/* 223:274 */         if (this.context != null)
/* 224:    */         {
/* 225:275 */           this.context.forceDestroy();
/* 226:276 */           this.context = null;
/* 227:277 */           this.reentry_count = 0;
/* 228:278 */           this.peer_info.destroy();
/* 229:279 */           this.peer_info = null;
/* 230:    */         }
/* 231:    */       }
/* 232:    */       catch (LWJGLException e)
/* 233:    */       {
/* 234:282 */         throw new RuntimeException(e);
/* 235:    */       }
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */   public final void setCLSharingProperties(PointerBuffer properties)
/* 240:    */     throws LWJGLException
/* 241:    */   {
/* 242:288 */     synchronized (this.SYNC_LOCK)
/* 243:    */     {
/* 244:289 */       if (this.context == null) {
/* 245:290 */         throw new IllegalStateException("Canvas not yet displayable");
/* 246:    */       }
/* 247:291 */       this.context.setCLSharingProperties(properties);
/* 248:    */     }
/* 249:    */   }
/* 250:    */   
/* 251:    */   protected void initGL() {}
/* 252:    */   
/* 253:    */   protected void paintGL() {}
/* 254:    */   
/* 255:    */   public final void paint(Graphics g)
/* 256:    */   {
/* 257:312 */     LWJGLException exception = null;
/* 258:313 */     synchronized (this.SYNC_LOCK)
/* 259:    */     {
/* 260:314 */       if (!isDisplayable()) {
/* 261:315 */         return;
/* 262:    */       }
/* 263:    */       try
/* 264:    */       {
/* 265:317 */         if (this.peer_info == null) {
/* 266:318 */           this.peer_info = implementation.createPeerInfo(this, this.pixel_format, this.attribs);
/* 267:    */         }
/* 268:320 */         this.peer_info.lockAndGetHandle();
/* 269:    */         try
/* 270:    */         {
/* 271:322 */           if (this.context == null)
/* 272:    */           {
/* 273:323 */             this.context = new ContextGL(this.peer_info, this.attribs, this.drawable != null ? (ContextGL)((DrawableLWJGL)this.drawable).getContext() : null);
/* 274:324 */             this.first_run = true;
/* 275:    */           }
/* 276:327 */           if (this.reentry_count == 0) {
/* 277:328 */             this.context.makeCurrent();
/* 278:    */           }
/* 279:329 */           this.reentry_count += 1;
/* 280:    */           try
/* 281:    */           {
/* 282:331 */             if (this.update_context)
/* 283:    */             {
/* 284:332 */               this.context.update();
/* 285:333 */               this.update_context = false;
/* 286:    */             }
/* 287:335 */             if (this.first_run)
/* 288:    */             {
/* 289:336 */               this.first_run = false;
/* 290:337 */               initGL();
/* 291:    */             }
/* 292:339 */             paintGL();
/* 293:    */           }
/* 294:    */           finally
/* 295:    */           {
/* 296:341 */             this.reentry_count -= 1;
/* 297:342 */             if (this.reentry_count == 0) {
/* 298:343 */               this.context.releaseCurrent();
/* 299:    */             }
/* 300:    */           }
/* 301:    */         }
/* 302:    */         finally
/* 303:    */         {
/* 304:346 */           this.peer_info.unlock();
/* 305:    */         }
/* 306:    */       }
/* 307:    */       catch (LWJGLException e)
/* 308:    */       {
/* 309:349 */         exception = e;
/* 310:    */       }
/* 311:    */     }
/* 312:352 */     if (exception != null) {
/* 313:353 */       exceptionOccurred(exception);
/* 314:    */     }
/* 315:    */   }
/* 316:    */   
/* 317:    */   protected void exceptionOccurred(LWJGLException exception)
/* 318:    */   {
/* 319:363 */     LWJGLUtil.log("Unhandled exception occurred, skipping paint(): " + exception);
/* 320:    */   }
/* 321:    */   
/* 322:    */   public void update(Graphics g)
/* 323:    */   {
/* 324:368 */     paint(g);
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void componentShown(ComponentEvent e) {}
/* 328:    */   
/* 329:    */   public void componentHidden(ComponentEvent e) {}
/* 330:    */   
/* 331:    */   public void componentResized(ComponentEvent e)
/* 332:    */   {
/* 333:378 */     setUpdate();
/* 334:    */   }
/* 335:    */   
/* 336:    */   public void componentMoved(ComponentEvent e)
/* 337:    */   {
/* 338:382 */     setUpdate();
/* 339:    */   }
/* 340:    */   
/* 341:    */   public void setLocation(int x, int y)
/* 342:    */   {
/* 343:386 */     super.setLocation(x, y);
/* 344:387 */     setUpdate();
/* 345:    */   }
/* 346:    */   
/* 347:    */   public void setLocation(Point p)
/* 348:    */   {
/* 349:391 */     super.setLocation(p);
/* 350:392 */     setUpdate();
/* 351:    */   }
/* 352:    */   
/* 353:    */   public void setSize(Dimension d)
/* 354:    */   {
/* 355:396 */     super.setSize(d);
/* 356:397 */     setUpdate();
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void setSize(int width, int height)
/* 360:    */   {
/* 361:401 */     super.setSize(width, height);
/* 362:402 */     setUpdate();
/* 363:    */   }
/* 364:    */   
/* 365:    */   public void setBounds(int x, int y, int width, int height)
/* 366:    */   {
/* 367:406 */     super.setBounds(x, y, width, height);
/* 368:407 */     setUpdate();
/* 369:    */   }
/* 370:    */   
/* 371:    */   public void hierarchyChanged(HierarchyEvent e)
/* 372:    */   {
/* 373:411 */     setUpdate();
/* 374:    */   }
/* 375:    */   
/* 376:    */   static {}
/* 377:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AWTGLCanvas
 * JD-Core Version:    0.7.0.1
 */