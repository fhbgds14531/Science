/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ 
/*   5:    */ final class LinuxEvent
/*   6:    */ {
/*   7:    */   public static final int FocusIn = 9;
/*   8:    */   public static final int FocusOut = 10;
/*   9:    */   public static final int KeyPress = 2;
/*  10:    */   public static final int KeyRelease = 3;
/*  11:    */   public static final int ButtonPress = 4;
/*  12:    */   public static final int ButtonRelease = 5;
/*  13:    */   public static final int MotionNotify = 6;
/*  14:    */   public static final int EnterNotify = 7;
/*  15:    */   public static final int LeaveNotify = 8;
/*  16:    */   public static final int UnmapNotify = 18;
/*  17:    */   public static final int MapNotify = 19;
/*  18:    */   public static final int Expose = 12;
/*  19:    */   public static final int ConfigureNotify = 22;
/*  20:    */   public static final int ClientMessage = 33;
/*  21:    */   private final ByteBuffer event_buffer;
/*  22:    */   
/*  23:    */   LinuxEvent()
/*  24:    */   {
/*  25: 62 */     this.event_buffer = createEventBuffer();
/*  26:    */   }
/*  27:    */   
/*  28:    */   private static native ByteBuffer createEventBuffer();
/*  29:    */   
/*  30:    */   public void copyFrom(LinuxEvent event)
/*  31:    */   {
/*  32: 67 */     int pos = this.event_buffer.position();
/*  33: 68 */     int event_pos = event.event_buffer.position();
/*  34: 69 */     this.event_buffer.put(event.event_buffer);
/*  35: 70 */     this.event_buffer.position(pos);
/*  36: 71 */     event.event_buffer.position(event_pos);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static native int getPending(long paramLong);
/*  40:    */   
/*  41:    */   public void sendEvent(long display, long window, boolean propagate, long event_mask)
/*  42:    */   {
/*  43: 77 */     nSendEvent(this.event_buffer, display, window, propagate, event_mask);
/*  44:    */   }
/*  45:    */   
/*  46:    */   private static native void nSendEvent(ByteBuffer paramByteBuffer, long paramLong1, long paramLong2, boolean paramBoolean, long paramLong3);
/*  47:    */   
/*  48:    */   public boolean filterEvent(long window)
/*  49:    */   {
/*  50: 82 */     return nFilterEvent(this.event_buffer, window);
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static native boolean nFilterEvent(ByteBuffer paramByteBuffer, long paramLong);
/*  54:    */   
/*  55:    */   public void nextEvent(long display)
/*  56:    */   {
/*  57: 87 */     nNextEvent(display, this.event_buffer);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static native void nNextEvent(long paramLong, ByteBuffer paramByteBuffer);
/*  61:    */   
/*  62:    */   public int getType()
/*  63:    */   {
/*  64: 92 */     return nGetType(this.event_buffer);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static native int nGetType(ByteBuffer paramByteBuffer);
/*  68:    */   
/*  69:    */   public long getWindow()
/*  70:    */   {
/*  71: 97 */     return nGetWindow(this.event_buffer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static native long nGetWindow(ByteBuffer paramByteBuffer);
/*  75:    */   
/*  76:    */   public void setWindow(long window)
/*  77:    */   {
/*  78:102 */     nSetWindow(this.event_buffer, window);
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static native void nSetWindow(ByteBuffer paramByteBuffer, long paramLong);
/*  82:    */   
/*  83:    */   public int getFocusMode()
/*  84:    */   {
/*  85:109 */     return nGetFocusMode(this.event_buffer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static native int nGetFocusMode(ByteBuffer paramByteBuffer);
/*  89:    */   
/*  90:    */   public int getFocusDetail()
/*  91:    */   {
/*  92:114 */     return nGetFocusDetail(this.event_buffer);
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static native int nGetFocusDetail(ByteBuffer paramByteBuffer);
/*  96:    */   
/*  97:    */   public long getClientMessageType()
/*  98:    */   {
/*  99:121 */     return nGetClientMessageType(this.event_buffer);
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static native long nGetClientMessageType(ByteBuffer paramByteBuffer);
/* 103:    */   
/* 104:    */   public int getClientData(int index)
/* 105:    */   {
/* 106:126 */     return nGetClientData(this.event_buffer, index);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static native int nGetClientData(ByteBuffer paramByteBuffer, int paramInt);
/* 110:    */   
/* 111:    */   public int getClientFormat()
/* 112:    */   {
/* 113:131 */     return nGetClientFormat(this.event_buffer);
/* 114:    */   }
/* 115:    */   
/* 116:    */   private static native int nGetClientFormat(ByteBuffer paramByteBuffer);
/* 117:    */   
/* 118:    */   public long getButtonTime()
/* 119:    */   {
/* 120:138 */     return nGetButtonTime(this.event_buffer);
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static native long nGetButtonTime(ByteBuffer paramByteBuffer);
/* 124:    */   
/* 125:    */   public int getButtonState()
/* 126:    */   {
/* 127:143 */     return nGetButtonState(this.event_buffer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static native int nGetButtonState(ByteBuffer paramByteBuffer);
/* 131:    */   
/* 132:    */   public int getButtonType()
/* 133:    */   {
/* 134:148 */     return nGetButtonType(this.event_buffer);
/* 135:    */   }
/* 136:    */   
/* 137:    */   private static native int nGetButtonType(ByteBuffer paramByteBuffer);
/* 138:    */   
/* 139:    */   public int getButtonButton()
/* 140:    */   {
/* 141:153 */     return nGetButtonButton(this.event_buffer);
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static native int nGetButtonButton(ByteBuffer paramByteBuffer);
/* 145:    */   
/* 146:    */   public long getButtonRoot()
/* 147:    */   {
/* 148:158 */     return nGetButtonRoot(this.event_buffer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   private static native long nGetButtonRoot(ByteBuffer paramByteBuffer);
/* 152:    */   
/* 153:    */   public int getButtonXRoot()
/* 154:    */   {
/* 155:163 */     return nGetButtonXRoot(this.event_buffer);
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static native int nGetButtonXRoot(ByteBuffer paramByteBuffer);
/* 159:    */   
/* 160:    */   public int getButtonYRoot()
/* 161:    */   {
/* 162:168 */     return nGetButtonYRoot(this.event_buffer);
/* 163:    */   }
/* 164:    */   
/* 165:    */   private static native int nGetButtonYRoot(ByteBuffer paramByteBuffer);
/* 166:    */   
/* 167:    */   public int getButtonX()
/* 168:    */   {
/* 169:173 */     return nGetButtonX(this.event_buffer);
/* 170:    */   }
/* 171:    */   
/* 172:    */   private static native int nGetButtonX(ByteBuffer paramByteBuffer);
/* 173:    */   
/* 174:    */   public int getButtonY()
/* 175:    */   {
/* 176:178 */     return nGetButtonY(this.event_buffer);
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static native int nGetButtonY(ByteBuffer paramByteBuffer);
/* 180:    */   
/* 181:    */   public long getKeyAddress()
/* 182:    */   {
/* 183:185 */     return nGetKeyAddress(this.event_buffer);
/* 184:    */   }
/* 185:    */   
/* 186:    */   private static native long nGetKeyAddress(ByteBuffer paramByteBuffer);
/* 187:    */   
/* 188:    */   public long getKeyTime()
/* 189:    */   {
/* 190:190 */     return nGetKeyTime(this.event_buffer);
/* 191:    */   }
/* 192:    */   
/* 193:    */   private static native int nGetKeyTime(ByteBuffer paramByteBuffer);
/* 194:    */   
/* 195:    */   public int getKeyType()
/* 196:    */   {
/* 197:195 */     return nGetKeyType(this.event_buffer);
/* 198:    */   }
/* 199:    */   
/* 200:    */   private static native int nGetKeyType(ByteBuffer paramByteBuffer);
/* 201:    */   
/* 202:    */   public int getKeyKeyCode()
/* 203:    */   {
/* 204:200 */     return nGetKeyKeyCode(this.event_buffer);
/* 205:    */   }
/* 206:    */   
/* 207:    */   private static native int nGetKeyKeyCode(ByteBuffer paramByteBuffer);
/* 208:    */   
/* 209:    */   public int getKeyState()
/* 210:    */   {
/* 211:205 */     return nGetKeyState(this.event_buffer);
/* 212:    */   }
/* 213:    */   
/* 214:    */   private static native int nGetKeyState(ByteBuffer paramByteBuffer);
/* 215:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxEvent
 * JD-Core Version:    0.7.0.1
 */