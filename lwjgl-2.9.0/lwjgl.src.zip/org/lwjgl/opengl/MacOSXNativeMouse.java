/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferUtils;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ 
/*   8:    */ final class MacOSXNativeMouse
/*   9:    */   extends EventQueue
/*  10:    */ {
/*  11:    */   private static final int WHEEL_SCALE = 120;
/*  12:    */   private static final int NUM_BUTTONS = 3;
/*  13:    */   private ByteBuffer window_handle;
/*  14:    */   private MacOSXDisplay display;
/*  15:    */   private boolean grabbed;
/*  16:    */   private float accum_dx;
/*  17:    */   private float accum_dy;
/*  18:    */   private int accum_dz;
/*  19:    */   private float last_x;
/*  20:    */   private float last_y;
/*  21:    */   private boolean saved_control_state;
/*  22: 73 */   private final ByteBuffer event = ByteBuffer.allocate(22);
/*  23: 74 */   private IntBuffer delta_buffer = BufferUtils.createIntBuffer(2);
/*  24:    */   private int skip_event;
/*  25: 77 */   private final byte[] buttons = new byte[3];
/*  26:    */   
/*  27:    */   MacOSXNativeMouse(MacOSXDisplay display, ByteBuffer window_handle)
/*  28:    */   {
/*  29: 80 */     super(22);
/*  30: 81 */     this.display = display;
/*  31: 82 */     this.window_handle = window_handle;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private native void nSetCursorPosition(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
/*  35:    */   
/*  36:    */   public static native void nGrabMouse(boolean paramBoolean);
/*  37:    */   
/*  38:    */   private native void nRegisterMouseListener(ByteBuffer paramByteBuffer);
/*  39:    */   
/*  40:    */   private native void nUnregisterMouseListener(ByteBuffer paramByteBuffer);
/*  41:    */   
/*  42:    */   private static native long nCreateCursor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, IntBuffer paramIntBuffer1, int paramInt6, IntBuffer paramIntBuffer2, int paramInt7)
/*  43:    */     throws LWJGLException;
/*  44:    */   
/*  45:    */   private static native void nDestroyCursor(long paramLong);
/*  46:    */   
/*  47:    */   private static native void nSetCursor(long paramLong)
/*  48:    */     throws LWJGLException;
/*  49:    */   
/*  50:    */   public synchronized void register()
/*  51:    */   {
/*  52:100 */     nRegisterMouseListener(this.window_handle);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static long createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*  56:    */     throws LWJGLException
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60:105 */       return nCreateCursor(width, height, xHotspot, yHotspot, numImages, images, images.position(), delays, delays != null ? delays.position() : -1);
/*  61:    */     }
/*  62:    */     catch (LWJGLException e)
/*  63:    */     {
/*  64:107 */       throw e;
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static void destroyCursor(long cursor_handle)
/*  69:    */   {
/*  70:112 */     nDestroyCursor(cursor_handle);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static void setCursor(long cursor_handle)
/*  74:    */     throws LWJGLException
/*  75:    */   {
/*  76:    */     try
/*  77:    */     {
/*  78:117 */       nSetCursor(cursor_handle);
/*  79:    */     }
/*  80:    */     catch (LWJGLException e)
/*  81:    */     {
/*  82:119 */       throw e;
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public synchronized void setCursorPosition(int x, int y)
/*  87:    */   {
/*  88:124 */     nSetCursorPosition(this.window_handle, x, y);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public synchronized void unregister()
/*  92:    */   {
/*  93:128 */     nUnregisterMouseListener(this.window_handle);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public synchronized void setGrabbed(boolean grabbed)
/*  97:    */   {
/*  98:132 */     this.grabbed = grabbed;
/*  99:133 */     nGrabMouse(grabbed);
/* 100:134 */     this.skip_event = 1;
/* 101:135 */     this.accum_dx = (this.accum_dy = 0.0F);
/* 102:    */   }
/* 103:    */   
/* 104:    */   public synchronized boolean isGrabbed()
/* 105:    */   {
/* 106:139 */     return this.grabbed;
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected void resetCursorToCenter()
/* 110:    */   {
/* 111:143 */     clearEvents();
/* 112:144 */     this.accum_dx = (this.accum_dy = 0.0F);
/* 113:145 */     if (this.display != null)
/* 114:    */     {
/* 115:146 */       this.last_x = (this.display.getWidth() / 2);
/* 116:147 */       this.last_y = (this.display.getHeight() / 2);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   private void putMouseEvent(byte button, byte state, int dz, long nanos)
/* 121:    */   {
/* 122:152 */     if (this.grabbed) {
/* 123:153 */       putMouseEventWithCoords(button, state, 0, 0, dz, nanos);
/* 124:    */     } else {
/* 125:155 */       putMouseEventWithCoords(button, state, (int)this.last_x, (int)this.last_y, dz, nanos);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected void putMouseEventWithCoords(byte button, byte state, int coord1, int coord2, int dz, long nanos)
/* 130:    */   {
/* 131:159 */     this.event.clear();
/* 132:160 */     this.event.put(button).put(state).putInt(coord1).putInt(coord2).putInt(dz).putLong(nanos);
/* 133:161 */     this.event.flip();
/* 134:162 */     putEvent(this.event);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public synchronized void poll(IntBuffer coord_buffer, ByteBuffer buttons_buffer)
/* 138:    */   {
/* 139:166 */     if (this.grabbed)
/* 140:    */     {
/* 141:167 */       coord_buffer.put(0, (int)this.accum_dx);
/* 142:168 */       coord_buffer.put(1, (int)this.accum_dy);
/* 143:    */     }
/* 144:    */     else
/* 145:    */     {
/* 146:170 */       coord_buffer.put(0, (int)this.last_x);
/* 147:171 */       coord_buffer.put(1, (int)this.last_y);
/* 148:    */     }
/* 149:173 */     coord_buffer.put(2, this.accum_dz);
/* 150:174 */     this.accum_dx = (this.accum_dy = this.accum_dz = 0);
/* 151:175 */     int old_position = buttons_buffer.position();
/* 152:176 */     buttons_buffer.put(this.buttons, 0, this.buttons.length);
/* 153:177 */     buttons_buffer.position(old_position);
/* 154:    */   }
/* 155:    */   
/* 156:    */   private void setCursorPos(float x, float y, long nanos)
/* 157:    */   {
/* 158:181 */     if (this.grabbed) {
/* 159:182 */       return;
/* 160:    */     }
/* 161:183 */     float dx = x - this.last_x;
/* 162:184 */     float dy = y - this.last_y;
/* 163:185 */     addDelta(dx, dy);
/* 164:186 */     this.last_x = x;
/* 165:187 */     this.last_y = y;
/* 166:188 */     putMouseEventWithCoords((byte)-1, (byte)0, (int)x, (int)y, 0, nanos);
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected void addDelta(float dx, float dy)
/* 170:    */   {
/* 171:192 */     this.accum_dx += dx;
/* 172:193 */     this.accum_dy += -dy;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public synchronized void setButton(int button, int state, long nanos)
/* 176:    */   {
/* 177:197 */     this.buttons[button] = ((byte)state);
/* 178:198 */     putMouseEvent((byte)button, (byte)state, 0, nanos);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public synchronized void mouseMoved(float x, float y, float dx, float dy, float dz, long nanos)
/* 182:    */   {
/* 183:202 */     if (this.skip_event > 0)
/* 184:    */     {
/* 185:203 */       this.skip_event -= 1;
/* 186:204 */       if (this.skip_event == 0)
/* 187:    */       {
/* 188:205 */         this.last_x = x;
/* 189:206 */         this.last_y = y;
/* 190:    */       }
/* 191:208 */       return;
/* 192:    */     }
/* 193:210 */     if (this.grabbed)
/* 194:    */     {
/* 195:211 */       if ((dx != 0.0F) || (dy != 0.0F))
/* 196:    */       {
/* 197:212 */         putMouseEventWithCoords((byte)-1, (byte)0, (int)dx, (int)-dy, 0, nanos);
/* 198:213 */         addDelta(dx, dy);
/* 199:    */       }
/* 200:    */     }
/* 201:    */     else {
/* 202:216 */       setCursorPos(x, y, nanos);
/* 203:    */     }
/* 204:218 */     if (dz != 0.0F)
/* 205:    */     {
/* 206:220 */       if (dy == 0.0F) {
/* 207:220 */         dy = dx;
/* 208:    */       }
/* 209:222 */       int wheel_amount = (int)(dy * 120.0F);
/* 210:223 */       this.accum_dz += wheel_amount;
/* 211:224 */       putMouseEvent((byte)-1, (byte)0, wheel_amount, nanos);
/* 212:    */     }
/* 213:    */   }
/* 214:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXNativeMouse
 * JD-Core Version:    0.7.0.1
 */