/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.LongBuffer;
/*   9:    */ import java.nio.ShortBuffer;
/*  10:    */ 
/*  11:    */ public final class NondirectBufferWrapper
/*  12:    */ {
/*  13:    */   private static final int INITIAL_BUFFER_SIZE = 1;
/*  14: 54 */   private static final ThreadLocal<CachedBuffers> thread_buffer = new ThreadLocal()
/*  15:    */   {
/*  16:    */     protected NondirectBufferWrapper.CachedBuffers initialValue()
/*  17:    */     {
/*  18: 56 */       return new NondirectBufferWrapper.CachedBuffers(1, null);
/*  19:    */     }
/*  20:    */   };
/*  21:    */   
/*  22:    */   private static CachedBuffers getCachedBuffers(int minimum_byte_size)
/*  23:    */   {
/*  24: 61 */     CachedBuffers buffers = (CachedBuffers)thread_buffer.get();
/*  25: 62 */     int current_byte_size = buffers.byte_buffer.capacity();
/*  26: 63 */     if (minimum_byte_size > current_byte_size)
/*  27:    */     {
/*  28: 64 */       buffers = new CachedBuffers(minimum_byte_size, null);
/*  29: 65 */       thread_buffer.set(buffers);
/*  30:    */     }
/*  31: 67 */     return buffers;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static ByteBuffer wrapNoCopyBuffer(ByteBuffer buf, int size)
/*  35:    */   {
/*  36: 71 */     BufferChecks.checkBufferSize(buf, size);
/*  37: 72 */     return wrapNoCopyDirect(buf);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static ShortBuffer wrapNoCopyBuffer(ShortBuffer buf, int size)
/*  41:    */   {
/*  42: 76 */     BufferChecks.checkBufferSize(buf, size);
/*  43: 77 */     return wrapNoCopyDirect(buf);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static IntBuffer wrapNoCopyBuffer(IntBuffer buf, int size)
/*  47:    */   {
/*  48: 81 */     BufferChecks.checkBufferSize(buf, size);
/*  49: 82 */     return wrapNoCopyDirect(buf);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static LongBuffer wrapNoCopyBuffer(LongBuffer buf, int size)
/*  53:    */   {
/*  54: 86 */     BufferChecks.checkBufferSize(buf, size);
/*  55: 87 */     return wrapNoCopyDirect(buf);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static FloatBuffer wrapNoCopyBuffer(FloatBuffer buf, int size)
/*  59:    */   {
/*  60: 91 */     BufferChecks.checkBufferSize(buf, size);
/*  61: 92 */     return wrapNoCopyDirect(buf);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static DoubleBuffer wrapNoCopyBuffer(DoubleBuffer buf, int size)
/*  65:    */   {
/*  66: 96 */     BufferChecks.checkBufferSize(buf, size);
/*  67: 97 */     return wrapNoCopyDirect(buf);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static ByteBuffer wrapBuffer(ByteBuffer buf, int size)
/*  71:    */   {
/*  72:101 */     BufferChecks.checkBufferSize(buf, size);
/*  73:102 */     return wrapDirect(buf);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static ShortBuffer wrapBuffer(ShortBuffer buf, int size)
/*  77:    */   {
/*  78:106 */     BufferChecks.checkBufferSize(buf, size);
/*  79:107 */     return wrapDirect(buf);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static IntBuffer wrapBuffer(IntBuffer buf, int size)
/*  83:    */   {
/*  84:111 */     BufferChecks.checkBufferSize(buf, size);
/*  85:112 */     return wrapDirect(buf);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static LongBuffer wrapBuffer(LongBuffer buf, int size)
/*  89:    */   {
/*  90:116 */     BufferChecks.checkBufferSize(buf, size);
/*  91:117 */     return wrapDirect(buf);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static FloatBuffer wrapBuffer(FloatBuffer buf, int size)
/*  95:    */   {
/*  96:121 */     BufferChecks.checkBufferSize(buf, size);
/*  97:122 */     return wrapDirect(buf);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static DoubleBuffer wrapBuffer(DoubleBuffer buf, int size)
/* 101:    */   {
/* 102:126 */     BufferChecks.checkBufferSize(buf, size);
/* 103:127 */     return wrapDirect(buf);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static ByteBuffer wrapDirect(ByteBuffer buffer)
/* 107:    */   {
/* 108:131 */     if (!buffer.isDirect()) {
/* 109:132 */       return doWrap(buffer);
/* 110:    */     }
/* 111:133 */     return buffer;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static ShortBuffer wrapDirect(ShortBuffer buffer)
/* 115:    */   {
/* 116:137 */     if (!buffer.isDirect()) {
/* 117:138 */       return doWrap(buffer);
/* 118:    */     }
/* 119:139 */     return buffer;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static FloatBuffer wrapDirect(FloatBuffer buffer)
/* 123:    */   {
/* 124:143 */     if (!buffer.isDirect()) {
/* 125:144 */       return doWrap(buffer);
/* 126:    */     }
/* 127:145 */     return buffer;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static IntBuffer wrapDirect(IntBuffer buffer)
/* 131:    */   {
/* 132:149 */     if (!buffer.isDirect()) {
/* 133:150 */       return doWrap(buffer);
/* 134:    */     }
/* 135:151 */     return buffer;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static LongBuffer wrapDirect(LongBuffer buffer)
/* 139:    */   {
/* 140:155 */     if (!buffer.isDirect()) {
/* 141:156 */       return doWrap(buffer);
/* 142:    */     }
/* 143:157 */     return buffer;
/* 144:    */   }
/* 145:    */   
/* 146:    */   public static DoubleBuffer wrapDirect(DoubleBuffer buffer)
/* 147:    */   {
/* 148:161 */     if (!buffer.isDirect()) {
/* 149:162 */       return doWrap(buffer);
/* 150:    */     }
/* 151:163 */     return buffer;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static ByteBuffer wrapNoCopyDirect(ByteBuffer buffer)
/* 155:    */   {
/* 156:167 */     if (!buffer.isDirect()) {
/* 157:168 */       return doNoCopyWrap(buffer);
/* 158:    */     }
/* 159:169 */     return buffer;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static ShortBuffer wrapNoCopyDirect(ShortBuffer buffer)
/* 163:    */   {
/* 164:173 */     if (!buffer.isDirect()) {
/* 165:174 */       return doNoCopyWrap(buffer);
/* 166:    */     }
/* 167:175 */     return buffer;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static FloatBuffer wrapNoCopyDirect(FloatBuffer buffer)
/* 171:    */   {
/* 172:179 */     if (!buffer.isDirect()) {
/* 173:180 */       return doNoCopyWrap(buffer);
/* 174:    */     }
/* 175:181 */     return buffer;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static IntBuffer wrapNoCopyDirect(IntBuffer buffer)
/* 179:    */   {
/* 180:185 */     if (!buffer.isDirect()) {
/* 181:186 */       return doNoCopyWrap(buffer);
/* 182:    */     }
/* 183:187 */     return buffer;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static LongBuffer wrapNoCopyDirect(LongBuffer buffer)
/* 187:    */   {
/* 188:191 */     if (!buffer.isDirect()) {
/* 189:192 */       return doNoCopyWrap(buffer);
/* 190:    */     }
/* 191:193 */     return buffer;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public static DoubleBuffer wrapNoCopyDirect(DoubleBuffer buffer)
/* 195:    */   {
/* 196:197 */     if (!buffer.isDirect()) {
/* 197:198 */       return doNoCopyWrap(buffer);
/* 198:    */     }
/* 199:199 */     return buffer;
/* 200:    */   }
/* 201:    */   
/* 202:    */   public static void copy(ByteBuffer src, ByteBuffer dst)
/* 203:    */   {
/* 204:203 */     if ((dst != null) && (!dst.isDirect()))
/* 205:    */     {
/* 206:204 */       int saved_position = dst.position();
/* 207:205 */       dst.put(src);
/* 208:206 */       dst.position(saved_position);
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   public static void copy(ShortBuffer src, ShortBuffer dst)
/* 213:    */   {
/* 214:211 */     if ((dst != null) && (!dst.isDirect()))
/* 215:    */     {
/* 216:212 */       int saved_position = dst.position();
/* 217:213 */       dst.put(src);
/* 218:214 */       dst.position(saved_position);
/* 219:    */     }
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static void copy(IntBuffer src, IntBuffer dst)
/* 223:    */   {
/* 224:219 */     if ((dst != null) && (!dst.isDirect()))
/* 225:    */     {
/* 226:220 */       int saved_position = dst.position();
/* 227:221 */       dst.put(src);
/* 228:222 */       dst.position(saved_position);
/* 229:    */     }
/* 230:    */   }
/* 231:    */   
/* 232:    */   public static void copy(FloatBuffer src, FloatBuffer dst)
/* 233:    */   {
/* 234:227 */     if ((dst != null) && (!dst.isDirect()))
/* 235:    */     {
/* 236:228 */       int saved_position = dst.position();
/* 237:229 */       dst.put(src);
/* 238:230 */       dst.position(saved_position);
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   public static void copy(LongBuffer src, LongBuffer dst)
/* 243:    */   {
/* 244:235 */     if ((dst != null) && (!dst.isDirect()))
/* 245:    */     {
/* 246:236 */       int saved_position = dst.position();
/* 247:237 */       dst.put(src);
/* 248:238 */       dst.position(saved_position);
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   public static void copy(DoubleBuffer src, DoubleBuffer dst)
/* 253:    */   {
/* 254:243 */     if ((dst != null) && (!dst.isDirect()))
/* 255:    */     {
/* 256:244 */       int saved_position = dst.position();
/* 257:245 */       dst.put(src);
/* 258:246 */       dst.position(saved_position);
/* 259:    */     }
/* 260:    */   }
/* 261:    */   
/* 262:    */   private static ByteBuffer doNoCopyWrap(ByteBuffer buffer)
/* 263:    */   {
/* 264:251 */     ByteBuffer direct_buffer = lookupBuffer(buffer);
/* 265:252 */     direct_buffer.limit(buffer.limit());
/* 266:253 */     direct_buffer.position(buffer.position());
/* 267:254 */     return direct_buffer;
/* 268:    */   }
/* 269:    */   
/* 270:    */   private static ShortBuffer doNoCopyWrap(ShortBuffer buffer)
/* 271:    */   {
/* 272:258 */     ShortBuffer direct_buffer = lookupBuffer(buffer);
/* 273:259 */     direct_buffer.limit(buffer.limit());
/* 274:260 */     direct_buffer.position(buffer.position());
/* 275:261 */     return direct_buffer;
/* 276:    */   }
/* 277:    */   
/* 278:    */   private static IntBuffer doNoCopyWrap(IntBuffer buffer)
/* 279:    */   {
/* 280:265 */     IntBuffer direct_buffer = lookupBuffer(buffer);
/* 281:266 */     direct_buffer.limit(buffer.limit());
/* 282:267 */     direct_buffer.position(buffer.position());
/* 283:268 */     return direct_buffer;
/* 284:    */   }
/* 285:    */   
/* 286:    */   private static FloatBuffer doNoCopyWrap(FloatBuffer buffer)
/* 287:    */   {
/* 288:272 */     FloatBuffer direct_buffer = lookupBuffer(buffer);
/* 289:273 */     direct_buffer.limit(buffer.limit());
/* 290:274 */     direct_buffer.position(buffer.position());
/* 291:275 */     return direct_buffer;
/* 292:    */   }
/* 293:    */   
/* 294:    */   private static LongBuffer doNoCopyWrap(LongBuffer buffer)
/* 295:    */   {
/* 296:279 */     LongBuffer direct_buffer = lookupBuffer(buffer);
/* 297:280 */     direct_buffer.limit(buffer.limit());
/* 298:281 */     direct_buffer.position(buffer.position());
/* 299:282 */     return direct_buffer;
/* 300:    */   }
/* 301:    */   
/* 302:    */   private static DoubleBuffer doNoCopyWrap(DoubleBuffer buffer)
/* 303:    */   {
/* 304:286 */     DoubleBuffer direct_buffer = lookupBuffer(buffer);
/* 305:287 */     direct_buffer.limit(buffer.limit());
/* 306:288 */     direct_buffer.position(buffer.position());
/* 307:289 */     return direct_buffer;
/* 308:    */   }
/* 309:    */   
/* 310:    */   private static ByteBuffer lookupBuffer(ByteBuffer buffer)
/* 311:    */   {
/* 312:293 */     return getCachedBuffers(buffer.remaining()).byte_buffer;
/* 313:    */   }
/* 314:    */   
/* 315:    */   private static ByteBuffer doWrap(ByteBuffer buffer)
/* 316:    */   {
/* 317:297 */     ByteBuffer direct_buffer = lookupBuffer(buffer);
/* 318:298 */     direct_buffer.clear();
/* 319:299 */     int saved_position = buffer.position();
/* 320:300 */     direct_buffer.put(buffer);
/* 321:301 */     buffer.position(saved_position);
/* 322:302 */     direct_buffer.flip();
/* 323:303 */     return direct_buffer;
/* 324:    */   }
/* 325:    */   
/* 326:    */   private static ShortBuffer lookupBuffer(ShortBuffer buffer)
/* 327:    */   {
/* 328:307 */     CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 2);
/* 329:308 */     return buffer.order() == ByteOrder.LITTLE_ENDIAN ? buffers.short_buffer_little : buffers.short_buffer_big;
/* 330:    */   }
/* 331:    */   
/* 332:    */   private static ShortBuffer doWrap(ShortBuffer buffer)
/* 333:    */   {
/* 334:312 */     ShortBuffer direct_buffer = lookupBuffer(buffer);
/* 335:313 */     direct_buffer.clear();
/* 336:314 */     int saved_position = buffer.position();
/* 337:315 */     direct_buffer.put(buffer);
/* 338:316 */     buffer.position(saved_position);
/* 339:317 */     direct_buffer.flip();
/* 340:318 */     return direct_buffer;
/* 341:    */   }
/* 342:    */   
/* 343:    */   private static FloatBuffer lookupBuffer(FloatBuffer buffer)
/* 344:    */   {
/* 345:322 */     CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 4);
/* 346:323 */     return buffer.order() == ByteOrder.LITTLE_ENDIAN ? buffers.float_buffer_little : buffers.float_buffer_big;
/* 347:    */   }
/* 348:    */   
/* 349:    */   private static FloatBuffer doWrap(FloatBuffer buffer)
/* 350:    */   {
/* 351:327 */     FloatBuffer direct_buffer = lookupBuffer(buffer);
/* 352:328 */     direct_buffer.clear();
/* 353:329 */     int saved_position = buffer.position();
/* 354:330 */     direct_buffer.put(buffer);
/* 355:331 */     buffer.position(saved_position);
/* 356:332 */     direct_buffer.flip();
/* 357:333 */     return direct_buffer;
/* 358:    */   }
/* 359:    */   
/* 360:    */   private static IntBuffer lookupBuffer(IntBuffer buffer)
/* 361:    */   {
/* 362:337 */     CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 4);
/* 363:338 */     return buffer.order() == ByteOrder.LITTLE_ENDIAN ? buffers.int_buffer_little : buffers.int_buffer_big;
/* 364:    */   }
/* 365:    */   
/* 366:    */   private static IntBuffer doWrap(IntBuffer buffer)
/* 367:    */   {
/* 368:342 */     IntBuffer direct_buffer = lookupBuffer(buffer);
/* 369:343 */     direct_buffer.clear();
/* 370:344 */     int saved_position = buffer.position();
/* 371:345 */     direct_buffer.put(buffer);
/* 372:346 */     buffer.position(saved_position);
/* 373:347 */     direct_buffer.flip();
/* 374:348 */     return direct_buffer;
/* 375:    */   }
/* 376:    */   
/* 377:    */   private static LongBuffer lookupBuffer(LongBuffer buffer)
/* 378:    */   {
/* 379:352 */     CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 8);
/* 380:353 */     return buffer.order() == ByteOrder.LITTLE_ENDIAN ? buffers.long_buffer_little : buffers.long_buffer_big;
/* 381:    */   }
/* 382:    */   
/* 383:    */   private static LongBuffer doWrap(LongBuffer buffer)
/* 384:    */   {
/* 385:357 */     LongBuffer direct_buffer = lookupBuffer(buffer);
/* 386:358 */     direct_buffer.clear();
/* 387:359 */     int saved_position = buffer.position();
/* 388:360 */     direct_buffer.put(buffer);
/* 389:361 */     buffer.position(saved_position);
/* 390:362 */     direct_buffer.flip();
/* 391:363 */     return direct_buffer;
/* 392:    */   }
/* 393:    */   
/* 394:    */   private static DoubleBuffer lookupBuffer(DoubleBuffer buffer)
/* 395:    */   {
/* 396:367 */     CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 8);
/* 397:368 */     return buffer.order() == ByteOrder.LITTLE_ENDIAN ? buffers.double_buffer_little : buffers.double_buffer_big;
/* 398:    */   }
/* 399:    */   
/* 400:    */   private static DoubleBuffer doWrap(DoubleBuffer buffer)
/* 401:    */   {
/* 402:372 */     DoubleBuffer direct_buffer = lookupBuffer(buffer);
/* 403:373 */     direct_buffer.clear();
/* 404:374 */     int saved_position = buffer.position();
/* 405:375 */     direct_buffer.put(buffer);
/* 406:376 */     buffer.position(saved_position);
/* 407:377 */     direct_buffer.flip();
/* 408:378 */     return direct_buffer;
/* 409:    */   }
/* 410:    */   
/* 411:    */   private static final class CachedBuffers
/* 412:    */   {
/* 413:    */     private final ByteBuffer byte_buffer;
/* 414:    */     private final ShortBuffer short_buffer_big;
/* 415:    */     private final IntBuffer int_buffer_big;
/* 416:    */     private final FloatBuffer float_buffer_big;
/* 417:    */     private final LongBuffer long_buffer_big;
/* 418:    */     private final DoubleBuffer double_buffer_big;
/* 419:    */     private final ShortBuffer short_buffer_little;
/* 420:    */     private final IntBuffer int_buffer_little;
/* 421:    */     private final FloatBuffer float_buffer_little;
/* 422:    */     private final LongBuffer long_buffer_little;
/* 423:    */     private final DoubleBuffer double_buffer_little;
/* 424:    */     
/* 425:    */     private CachedBuffers(int size)
/* 426:    */     {
/* 427:395 */       this.byte_buffer = ByteBuffer.allocateDirect(size);
/* 428:396 */       this.short_buffer_big = this.byte_buffer.asShortBuffer();
/* 429:397 */       this.int_buffer_big = this.byte_buffer.asIntBuffer();
/* 430:398 */       this.float_buffer_big = this.byte_buffer.asFloatBuffer();
/* 431:399 */       this.long_buffer_big = this.byte_buffer.asLongBuffer();
/* 432:400 */       this.double_buffer_big = this.byte_buffer.asDoubleBuffer();
/* 433:401 */       this.byte_buffer.order(ByteOrder.LITTLE_ENDIAN);
/* 434:402 */       this.short_buffer_little = this.byte_buffer.asShortBuffer();
/* 435:403 */       this.int_buffer_little = this.byte_buffer.asIntBuffer();
/* 436:404 */       this.float_buffer_little = this.byte_buffer.asFloatBuffer();
/* 437:405 */       this.long_buffer_little = this.byte_buffer.asLongBuffer();
/* 438:406 */       this.double_buffer_little = this.byte_buffer.asDoubleBuffer();
/* 439:    */     }
/* 440:    */   }
/* 441:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.NondirectBufferWrapper
 * JD-Core Version:    0.7.0.1
 */