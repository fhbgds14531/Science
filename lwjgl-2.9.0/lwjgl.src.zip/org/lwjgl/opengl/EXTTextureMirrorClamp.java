package org.lwjgl.opengl;

public final class EXTTextureMirrorClamp
{
  public static final int GL_MIRROR_CLAMP_EXT = 34626;
  public static final int GL_MIRROR_CLAMP_TO_EDGE_EXT = 34627;
  public static final int GL_MIRROR_CLAMP_TO_BORDER_EXT = 35090;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureMirrorClamp
 * JD-Core Version:    0.7.0.1
 */