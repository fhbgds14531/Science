/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ public final class CLCapabilities
/*   4:    */ {
/*   5:  8 */   static final long clLogMessagesToSystemLogAPPLE = CL.getFunctionAddress("clLogMessagesToSystemLogAPPLE");
/*   6:  9 */   static final long clLogMessagesToStdoutAPPLE = CL.getFunctionAddress("clLogMessagesToStdoutAPPLE");
/*   7: 10 */   static final long clLogMessagesToStderrAPPLE = CL.getFunctionAddress("clLogMessagesToStderrAPPLE");
/*   8: 13 */   static final long clSetMemObjectDestructorAPPLE = CL.getFunctionAddress("clSetMemObjectDestructorAPPLE");
/*   9: 16 */   static final long clGetGLContextInfoAPPLE = CL.getFunctionAddress("clGetGLContextInfoAPPLE");
/*  10: 19 */   static final long clGetPlatformIDs = CL.getFunctionAddress("clGetPlatformIDs");
/*  11: 20 */   static final long clGetPlatformInfo = CL.getFunctionAddress("clGetPlatformInfo");
/*  12: 21 */   static final long clGetDeviceIDs = CL.getFunctionAddress("clGetDeviceIDs");
/*  13: 22 */   static final long clGetDeviceInfo = CL.getFunctionAddress("clGetDeviceInfo");
/*  14: 23 */   static final long clCreateContext = CL.getFunctionAddress("clCreateContext");
/*  15: 24 */   static final long clCreateContextFromType = CL.getFunctionAddress("clCreateContextFromType");
/*  16: 25 */   static final long clRetainContext = CL.getFunctionAddress("clRetainContext");
/*  17: 26 */   static final long clReleaseContext = CL.getFunctionAddress("clReleaseContext");
/*  18: 27 */   static final long clGetContextInfo = CL.getFunctionAddress("clGetContextInfo");
/*  19: 28 */   static final long clCreateCommandQueue = CL.getFunctionAddress("clCreateCommandQueue");
/*  20: 29 */   static final long clRetainCommandQueue = CL.getFunctionAddress("clRetainCommandQueue");
/*  21: 30 */   static final long clReleaseCommandQueue = CL.getFunctionAddress("clReleaseCommandQueue");
/*  22: 31 */   static final long clGetCommandQueueInfo = CL.getFunctionAddress("clGetCommandQueueInfo");
/*  23: 32 */   static final long clCreateBuffer = CL.getFunctionAddress("clCreateBuffer");
/*  24: 33 */   static final long clEnqueueReadBuffer = CL.getFunctionAddress("clEnqueueReadBuffer");
/*  25: 34 */   static final long clEnqueueWriteBuffer = CL.getFunctionAddress("clEnqueueWriteBuffer");
/*  26: 35 */   static final long clEnqueueCopyBuffer = CL.getFunctionAddress("clEnqueueCopyBuffer");
/*  27: 36 */   static final long clEnqueueMapBuffer = CL.getFunctionAddress("clEnqueueMapBuffer");
/*  28: 37 */   static final long clCreateImage2D = CL.getFunctionAddress("clCreateImage2D");
/*  29: 38 */   static final long clCreateImage3D = CL.getFunctionAddress("clCreateImage3D");
/*  30: 39 */   static final long clGetSupportedImageFormats = CL.getFunctionAddress("clGetSupportedImageFormats");
/*  31: 40 */   static final long clEnqueueReadImage = CL.getFunctionAddress("clEnqueueReadImage");
/*  32: 41 */   static final long clEnqueueWriteImage = CL.getFunctionAddress("clEnqueueWriteImage");
/*  33: 42 */   static final long clEnqueueCopyImage = CL.getFunctionAddress("clEnqueueCopyImage");
/*  34: 43 */   static final long clEnqueueCopyImageToBuffer = CL.getFunctionAddress("clEnqueueCopyImageToBuffer");
/*  35: 44 */   static final long clEnqueueCopyBufferToImage = CL.getFunctionAddress("clEnqueueCopyBufferToImage");
/*  36: 45 */   static final long clEnqueueMapImage = CL.getFunctionAddress("clEnqueueMapImage");
/*  37: 46 */   static final long clGetImageInfo = CL.getFunctionAddress("clGetImageInfo");
/*  38: 47 */   static final long clRetainMemObject = CL.getFunctionAddress("clRetainMemObject");
/*  39: 48 */   static final long clReleaseMemObject = CL.getFunctionAddress("clReleaseMemObject");
/*  40: 49 */   static final long clEnqueueUnmapMemObject = CL.getFunctionAddress("clEnqueueUnmapMemObject");
/*  41: 50 */   static final long clGetMemObjectInfo = CL.getFunctionAddress("clGetMemObjectInfo");
/*  42: 51 */   static final long clCreateSampler = CL.getFunctionAddress("clCreateSampler");
/*  43: 52 */   static final long clRetainSampler = CL.getFunctionAddress("clRetainSampler");
/*  44: 53 */   static final long clReleaseSampler = CL.getFunctionAddress("clReleaseSampler");
/*  45: 54 */   static final long clGetSamplerInfo = CL.getFunctionAddress("clGetSamplerInfo");
/*  46: 55 */   static final long clCreateProgramWithSource = CL.getFunctionAddress("clCreateProgramWithSource");
/*  47: 56 */   static final long clCreateProgramWithBinary = CL.getFunctionAddress("clCreateProgramWithBinary");
/*  48: 57 */   static final long clRetainProgram = CL.getFunctionAddress("clRetainProgram");
/*  49: 58 */   static final long clReleaseProgram = CL.getFunctionAddress("clReleaseProgram");
/*  50: 59 */   static final long clBuildProgram = CL.getFunctionAddress("clBuildProgram");
/*  51: 60 */   static final long clUnloadCompiler = CL.getFunctionAddress("clUnloadCompiler");
/*  52: 61 */   static final long clGetProgramInfo = CL.getFunctionAddress("clGetProgramInfo");
/*  53: 62 */   static final long clGetProgramBuildInfo = CL.getFunctionAddress("clGetProgramBuildInfo");
/*  54: 63 */   static final long clCreateKernel = CL.getFunctionAddress("clCreateKernel");
/*  55: 64 */   static final long clCreateKernelsInProgram = CL.getFunctionAddress("clCreateKernelsInProgram");
/*  56: 65 */   static final long clRetainKernel = CL.getFunctionAddress("clRetainKernel");
/*  57: 66 */   static final long clReleaseKernel = CL.getFunctionAddress("clReleaseKernel");
/*  58: 67 */   static final long clSetKernelArg = CL.getFunctionAddress("clSetKernelArg");
/*  59: 68 */   static final long clGetKernelInfo = CL.getFunctionAddress("clGetKernelInfo");
/*  60: 69 */   static final long clGetKernelWorkGroupInfo = CL.getFunctionAddress("clGetKernelWorkGroupInfo");
/*  61: 70 */   static final long clEnqueueNDRangeKernel = CL.getFunctionAddress("clEnqueueNDRangeKernel");
/*  62: 71 */   static final long clEnqueueTask = CL.getFunctionAddress("clEnqueueTask");
/*  63: 72 */   static final long clEnqueueNativeKernel = CL.getFunctionAddress("clEnqueueNativeKernel");
/*  64: 73 */   static final long clWaitForEvents = CL.getFunctionAddress("clWaitForEvents");
/*  65: 74 */   static final long clGetEventInfo = CL.getFunctionAddress("clGetEventInfo");
/*  66: 75 */   static final long clRetainEvent = CL.getFunctionAddress("clRetainEvent");
/*  67: 76 */   static final long clReleaseEvent = CL.getFunctionAddress("clReleaseEvent");
/*  68: 77 */   static final long clEnqueueMarker = CL.getFunctionAddress("clEnqueueMarker");
/*  69: 78 */   static final long clEnqueueBarrier = CL.getFunctionAddress("clEnqueueBarrier");
/*  70: 79 */   static final long clEnqueueWaitForEvents = CL.getFunctionAddress("clEnqueueWaitForEvents");
/*  71: 80 */   static final long clGetEventProfilingInfo = CL.getFunctionAddress("clGetEventProfilingInfo");
/*  72: 81 */   static final long clFlush = CL.getFunctionAddress("clFlush");
/*  73: 82 */   static final long clFinish = CL.getFunctionAddress("clFinish");
/*  74: 83 */   static final long clGetExtensionFunctionAddress = CL.getFunctionAddress("clGetExtensionFunctionAddress");
/*  75: 86 */   static final long clCreateFromGLBuffer = CL.getFunctionAddress("clCreateFromGLBuffer");
/*  76: 87 */   static final long clCreateFromGLTexture2D = CL.getFunctionAddress("clCreateFromGLTexture2D");
/*  77: 88 */   static final long clCreateFromGLTexture3D = CL.getFunctionAddress("clCreateFromGLTexture3D");
/*  78: 89 */   static final long clCreateFromGLRenderbuffer = CL.getFunctionAddress("clCreateFromGLRenderbuffer");
/*  79: 90 */   static final long clGetGLObjectInfo = CL.getFunctionAddress("clGetGLObjectInfo");
/*  80: 91 */   static final long clGetGLTextureInfo = CL.getFunctionAddress("clGetGLTextureInfo");
/*  81: 92 */   static final long clEnqueueAcquireGLObjects = CL.getFunctionAddress("clEnqueueAcquireGLObjects");
/*  82: 93 */   static final long clEnqueueReleaseGLObjects = CL.getFunctionAddress("clEnqueueReleaseGLObjects");
/*  83: 96 */   static final long clCreateSubBuffer = CL.getFunctionAddress("clCreateSubBuffer");
/*  84: 97 */   static final long clSetMemObjectDestructorCallback = CL.getFunctionAddress("clSetMemObjectDestructorCallback");
/*  85: 98 */   static final long clEnqueueReadBufferRect = CL.getFunctionAddress("clEnqueueReadBufferRect");
/*  86: 99 */   static final long clEnqueueWriteBufferRect = CL.getFunctionAddress("clEnqueueWriteBufferRect");
/*  87:100 */   static final long clEnqueueCopyBufferRect = CL.getFunctionAddress("clEnqueueCopyBufferRect");
/*  88:101 */   static final long clCreateUserEvent = CL.getFunctionAddress("clCreateUserEvent");
/*  89:102 */   static final long clSetUserEventStatus = CL.getFunctionAddress("clSetUserEventStatus");
/*  90:103 */   static final long clSetEventCallback = CL.getFunctionAddress("clSetEventCallback");
/*  91:106 */   static final long clRetainDevice = CL.getFunctionAddress("clRetainDevice");
/*  92:107 */   static final long clReleaseDevice = CL.getFunctionAddress("clReleaseDevice");
/*  93:108 */   static final long clCreateSubDevices = CL.getFunctionAddress("clCreateSubDevices");
/*  94:109 */   static final long clCreateImage = CL.getFunctionAddress("clCreateImage");
/*  95:110 */   static final long clCreateProgramWithBuiltInKernels = CL.getFunctionAddress("clCreateProgramWithBuiltInKernels");
/*  96:111 */   static final long clCompileProgram = CL.getFunctionAddress("clCompileProgram");
/*  97:112 */   static final long clLinkProgram = CL.getFunctionAddress("clLinkProgram");
/*  98:113 */   static final long clUnloadPlatformCompiler = CL.getFunctionAddress("clUnloadPlatformCompiler");
/*  99:114 */   static final long clGetKernelArgInfo = CL.getFunctionAddress("clGetKernelArgInfo");
/* 100:115 */   static final long clEnqueueFillBuffer = CL.getFunctionAddress("clEnqueueFillBuffer");
/* 101:116 */   static final long clEnqueueFillImage = CL.getFunctionAddress("clEnqueueFillImage");
/* 102:117 */   static final long clEnqueueMigrateMemObjects = CL.getFunctionAddress("clEnqueueMigrateMemObjects");
/* 103:118 */   static final long clEnqueueMarkerWithWaitList = CL.getFunctionAddress("clEnqueueMarkerWithWaitList");
/* 104:119 */   static final long clEnqueueBarrierWithWaitList = CL.getFunctionAddress("clEnqueueBarrierWithWaitList");
/* 105:120 */   static final long clSetPrintfCallback = CL.getFunctionAddress("clSetPrintfCallback");
/* 106:121 */   static final long clGetExtensionFunctionAddressForPlatform = CL.getFunctionAddress("clGetExtensionFunctionAddressForPlatform");
/* 107:124 */   static final long clCreateFromGLTexture = CL.getFunctionAddress("clCreateFromGLTexture");
/* 108:127 */   static final long clRetainDeviceEXT = CL.getFunctionAddress("clRetainDeviceEXT");
/* 109:128 */   static final long clReleaseDeviceEXT = CL.getFunctionAddress("clReleaseDeviceEXT");
/* 110:129 */   static final long clCreateSubDevicesEXT = CL.getFunctionAddress("clCreateSubDevicesEXT");
/* 111:132 */   static final long clEnqueueMigrateMemObjectEXT = CL.getFunctionAddress("clEnqueueMigrateMemObjectEXT");
/* 112:135 */   static final long clCreateEventFromGLsyncKHR = CL.getFunctionAddress("clCreateEventFromGLsyncKHR");
/* 113:138 */   static final long clGetGLContextInfoKHR = CL.getFunctionAddress("clGetGLContextInfoKHR");
/* 114:141 */   static final long clIcdGetPlatformIDsKHR = CL.getFunctionAddress("clIcdGetPlatformIDsKHR");
/* 115:144 */   static final long clTerminateContextKHR = CL.getFunctionAddress("clTerminateContextKHR");
/* 116:150 */   static final boolean CL_APPLE_ContextLoggingFunctions = isAPPLE_ContextLoggingFunctionsSupported();
/* 117:151 */   static final boolean CL_APPLE_SetMemObjectDestructor = isAPPLE_SetMemObjectDestructorSupported();
/* 118:152 */   static final boolean CL_APPLE_gl_sharing = isAPPLE_gl_sharingSupported();
/* 119:153 */   static final boolean OpenCL10 = isCL10Supported();
/* 120:154 */   static final boolean OpenCL10GL = isCL10GLSupported();
/* 121:155 */   static final boolean OpenCL11 = isCL11Supported();
/* 122:156 */   static final boolean OpenCL12 = isCL12Supported();
/* 123:157 */   static final boolean OpenCL12GL = isCL12GLSupported();
/* 124:158 */   static final boolean CL_EXT_device_fission = isEXT_device_fissionSupported();
/* 125:159 */   static final boolean CL_EXT_migrate_memobject = isEXT_migrate_memobjectSupported();
/* 126:160 */   static final boolean CL_KHR_gl_event = isKHR_gl_eventSupported();
/* 127:161 */   static final boolean CL_KHR_gl_sharing = isKHR_gl_sharingSupported();
/* 128:162 */   static final boolean CL_KHR_icd = isKHR_icdSupported();
/* 129:163 */   static final boolean CL_KHR_terminate_context = isKHR_terminate_contextSupported();
/* 130:    */   
/* 131:    */   public static CLPlatformCapabilities getPlatformCapabilities(CLPlatform platform)
/* 132:    */   {
/* 133:167 */     platform.checkValid();
/* 134:    */     
/* 135:169 */     CLPlatformCapabilities caps = (CLPlatformCapabilities)platform.getCapabilities();
/* 136:170 */     if (caps == null) {
/* 137:171 */       platform.setCapabilities(caps = new CLPlatformCapabilities(platform));
/* 138:    */     }
/* 139:173 */     return caps;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static CLDeviceCapabilities getDeviceCapabilities(CLDevice device)
/* 143:    */   {
/* 144:177 */     device.checkValid();
/* 145:    */     
/* 146:179 */     CLDeviceCapabilities caps = (CLDeviceCapabilities)device.getCapabilities();
/* 147:180 */     if (caps == null) {
/* 148:181 */       device.setCapabilities(caps = new CLDeviceCapabilities(device));
/* 149:    */     }
/* 150:183 */     return caps;
/* 151:    */   }
/* 152:    */   
/* 153:    */   private static boolean isAPPLE_ContextLoggingFunctionsSupported()
/* 154:    */   {
/* 155:187 */     return (clLogMessagesToSystemLogAPPLE != 0L ? 1 : 0) & (clLogMessagesToStdoutAPPLE != 0L ? 1 : 0) & (clLogMessagesToStderrAPPLE != 0L ? 1 : 0);
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static boolean isAPPLE_SetMemObjectDestructorSupported()
/* 159:    */   {
/* 160:194 */     return clSetMemObjectDestructorAPPLE != 0L;
/* 161:    */   }
/* 162:    */   
/* 163:    */   private static boolean isAPPLE_gl_sharingSupported()
/* 164:    */   {
/* 165:199 */     return clGetGLContextInfoAPPLE != 0L;
/* 166:    */   }
/* 167:    */   
/* 168:    */   private static boolean isCL10Supported()
/* 169:    */   {
/* 170:204 */     return (clGetPlatformIDs != 0L ? 1 : 0) & (clGetPlatformInfo != 0L ? 1 : 0) & (clGetDeviceIDs != 0L ? 1 : 0) & (clGetDeviceInfo != 0L ? 1 : 0) & (clCreateContext != 0L ? 1 : 0) & (clCreateContextFromType != 0L ? 1 : 0) & (clRetainContext != 0L ? 1 : 0) & (clReleaseContext != 0L ? 1 : 0) & (clGetContextInfo != 0L ? 1 : 0) & (clCreateCommandQueue != 0L ? 1 : 0) & (clRetainCommandQueue != 0L ? 1 : 0) & (clReleaseCommandQueue != 0L ? 1 : 0) & (clGetCommandQueueInfo != 0L ? 1 : 0) & (clCreateBuffer != 0L ? 1 : 0) & (clEnqueueReadBuffer != 0L ? 1 : 0) & (clEnqueueWriteBuffer != 0L ? 1 : 0) & (clEnqueueCopyBuffer != 0L ? 1 : 0) & (clEnqueueMapBuffer != 0L ? 1 : 0) & (clCreateImage2D != 0L ? 1 : 0) & (clCreateImage3D != 0L ? 1 : 0) & (clGetSupportedImageFormats != 0L ? 1 : 0) & (clEnqueueReadImage != 0L ? 1 : 0) & (clEnqueueWriteImage != 0L ? 1 : 0) & (clEnqueueCopyImage != 0L ? 1 : 0) & (clEnqueueCopyImageToBuffer != 0L ? 1 : 0) & (clEnqueueCopyBufferToImage != 0L ? 1 : 0) & (clEnqueueMapImage != 0L ? 1 : 0) & (clGetImageInfo != 0L ? 1 : 0) & (clRetainMemObject != 0L ? 1 : 0) & (clReleaseMemObject != 0L ? 1 : 0) & (clEnqueueUnmapMemObject != 0L ? 1 : 0) & (clGetMemObjectInfo != 0L ? 1 : 0) & (clCreateSampler != 0L ? 1 : 0) & (clRetainSampler != 0L ? 1 : 0) & (clReleaseSampler != 0L ? 1 : 0) & (clGetSamplerInfo != 0L ? 1 : 0) & (clCreateProgramWithSource != 0L ? 1 : 0) & (clCreateProgramWithBinary != 0L ? 1 : 0) & (clRetainProgram != 0L ? 1 : 0) & (clReleaseProgram != 0L ? 1 : 0) & (clBuildProgram != 0L ? 1 : 0) & (clUnloadCompiler != 0L ? 1 : 0) & (clGetProgramInfo != 0L ? 1 : 0) & (clGetProgramBuildInfo != 0L ? 1 : 0) & (clCreateKernel != 0L ? 1 : 0) & (clCreateKernelsInProgram != 0L ? 1 : 0) & (clRetainKernel != 0L ? 1 : 0) & (clReleaseKernel != 0L ? 1 : 0) & (clSetKernelArg != 0L ? 1 : 0) & (clGetKernelInfo != 0L ? 1 : 0) & (clGetKernelWorkGroupInfo != 0L ? 1 : 0) & (clEnqueueNDRangeKernel != 0L ? 1 : 0) & (clEnqueueTask != 0L ? 1 : 0) & (clEnqueueNativeKernel != 0L ? 1 : 0) & (clWaitForEvents != 0L ? 1 : 0) & (clGetEventInfo != 0L ? 1 : 0) & (clRetainEvent != 0L ? 1 : 0) & (clReleaseEvent != 0L ? 1 : 0) & (clEnqueueMarker != 0L ? 1 : 0) & (clEnqueueBarrier != 0L ? 1 : 0) & (clEnqueueWaitForEvents != 0L ? 1 : 0) & (clGetEventProfilingInfo != 0L ? 1 : 0) & (clFlush != 0L ? 1 : 0) & (clFinish != 0L ? 1 : 0) & (clGetExtensionFunctionAddress != 0L ? 1 : 0);
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static boolean isCL10GLSupported()
/* 174:    */   {
/* 175:273 */     return (clCreateFromGLBuffer != 0L ? 1 : 0) & (clCreateFromGLTexture2D != 0L ? 1 : 0) & (clCreateFromGLTexture3D != 0L ? 1 : 0) & (clCreateFromGLRenderbuffer != 0L ? 1 : 0) & (clGetGLObjectInfo != 0L ? 1 : 0) & (clGetGLTextureInfo != 0L ? 1 : 0) & (clEnqueueAcquireGLObjects != 0L ? 1 : 0) & (clEnqueueReleaseGLObjects != 0L ? 1 : 0);
/* 176:    */   }
/* 177:    */   
/* 178:    */   private static boolean isCL11Supported()
/* 179:    */   {
/* 180:285 */     return (clCreateSubBuffer != 0L ? 1 : 0) & (clSetMemObjectDestructorCallback != 0L ? 1 : 0) & (clEnqueueReadBufferRect != 0L ? 1 : 0) & (clEnqueueWriteBufferRect != 0L ? 1 : 0) & (clEnqueueCopyBufferRect != 0L ? 1 : 0) & (clCreateUserEvent != 0L ? 1 : 0) & (clSetUserEventStatus != 0L ? 1 : 0) & (clSetEventCallback != 0L ? 1 : 0);
/* 181:    */   }
/* 182:    */   
/* 183:    */   private static boolean isCL12Supported()
/* 184:    */   {
/* 185:297 */     return (clRetainDevice != 0L ? 1 : 0) & (clReleaseDevice != 0L ? 1 : 0) & (clCreateSubDevices != 0L ? 1 : 0) & (clCreateImage != 0L ? 1 : 0) & (clCreateProgramWithBuiltInKernels != 0L ? 1 : 0) & (clCompileProgram != 0L ? 1 : 0) & (clLinkProgram != 0L ? 1 : 0) & (clUnloadPlatformCompiler != 0L ? 1 : 0) & (clGetKernelArgInfo != 0L ? 1 : 0) & (clEnqueueFillBuffer != 0L ? 1 : 0) & (clEnqueueFillImage != 0L ? 1 : 0) & (clEnqueueMigrateMemObjects != 0L ? 1 : 0) & (clEnqueueMarkerWithWaitList != 0L ? 1 : 0) & (clEnqueueBarrierWithWaitList != 0L ? 1 : 0) & 0x1 & ((clSetPrintfCallback != 0L) || (clGetExtensionFunctionAddressForPlatform != 0L) ? 1 : 0);
/* 186:    */   }
/* 187:    */   
/* 188:    */   private static boolean isCL12GLSupported()
/* 189:    */   {
/* 190:317 */     return clCreateFromGLTexture != 0L;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private static boolean isEXT_device_fissionSupported()
/* 194:    */   {
/* 195:322 */     return (clRetainDeviceEXT != 0L ? 1 : 0) & (clReleaseDeviceEXT != 0L ? 1 : 0) & (clCreateSubDevicesEXT != 0L ? 1 : 0);
/* 196:    */   }
/* 197:    */   
/* 198:    */   private static boolean isEXT_migrate_memobjectSupported()
/* 199:    */   {
/* 200:329 */     return clEnqueueMigrateMemObjectEXT != 0L;
/* 201:    */   }
/* 202:    */   
/* 203:    */   private static boolean isKHR_gl_eventSupported()
/* 204:    */   {
/* 205:334 */     return clCreateEventFromGLsyncKHR != 0L;
/* 206:    */   }
/* 207:    */   
/* 208:    */   private static boolean isKHR_gl_sharingSupported()
/* 209:    */   {
/* 210:339 */     return clGetGLContextInfoKHR != 0L;
/* 211:    */   }
/* 212:    */   
/* 213:    */   private static boolean isKHR_icdSupported()
/* 214:    */   {
/* 215:344 */     if (clIcdGetPlatformIDsKHR == 0L) {}
/* 216:344 */     return true;
/* 217:    */   }
/* 218:    */   
/* 219:    */   private static boolean isKHR_terminate_contextSupported()
/* 220:    */   {
/* 221:349 */     return clTerminateContextKHR != 0L;
/* 222:    */   }
/* 223:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLCapabilities
 * JD-Core Version:    0.7.0.1
 */