package org.lwjgl.opengl;

public final class EXTTextureSRGBDecode
{
  public static final int GL_TEXTURE_SRGB_DECODE_EXT = 35400;
  public static final int GL_DECODE_EXT = 35401;
  public static final int GL_SKIP_DECODE_EXT = 35402;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureSRGBDecode
 * JD-Core Version:    0.7.0.1
 */