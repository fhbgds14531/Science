/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.DoubleBuffer;
/*  5:   */ import java.nio.FloatBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class NVFragmentProgram
/* 10:   */   extends NVProgram
/* 11:   */ {
/* 12:   */   public static final int GL_FRAGMENT_PROGRAM_NV = 34928;
/* 13:   */   public static final int GL_MAX_TEXTURE_COORDS_NV = 34929;
/* 14:   */   public static final int GL_MAX_TEXTURE_IMAGE_UNITS_NV = 34930;
/* 15:   */   public static final int GL_FRAGMENT_PROGRAM_BINDING_NV = 34931;
/* 16:   */   public static final int GL_MAX_FRAGMENT_PROGRAM_LOCAL_PARAMETERS_NV = 34920;
/* 17:   */   
/* 18:   */   public static void glProgramNamedParameter4fNV(int id, ByteBuffer name, float x, float y, float z, float w)
/* 19:   */   {
/* 20:32 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 21:33 */     long function_pointer = caps.glProgramNamedParameter4fNV;
/* 22:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 23:35 */     BufferChecks.checkDirect(name);
/* 24:36 */     nglProgramNamedParameter4fNV(id, name.remaining(), MemoryUtil.getAddress(name), x, y, z, w, function_pointer);
/* 25:   */   }
/* 26:   */   
/* 27:   */   static native void nglProgramNamedParameter4fNV(int paramInt1, int paramInt2, long paramLong1, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong2);
/* 28:   */   
/* 29:   */   public static void glProgramNamedParameter4dNV(int id, ByteBuffer name, double x, double y, double z, double w)
/* 30:   */   {
/* 31:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 32:42 */     long function_pointer = caps.glProgramNamedParameter4dNV;
/* 33:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 34:44 */     BufferChecks.checkDirect(name);
/* 35:45 */     nglProgramNamedParameter4dNV(id, name.remaining(), MemoryUtil.getAddress(name), x, y, z, w, function_pointer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   static native void nglProgramNamedParameter4dNV(int paramInt1, int paramInt2, long paramLong1, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong2);
/* 39:   */   
/* 40:   */   public static void glGetProgramNamedParameterNV(int id, ByteBuffer name, FloatBuffer params)
/* 41:   */   {
/* 42:50 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:51 */     long function_pointer = caps.glGetProgramNamedParameterfvNV;
/* 44:52 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 45:53 */     BufferChecks.checkDirect(name);
/* 46:54 */     BufferChecks.checkBuffer(params, 4);
/* 47:55 */     nglGetProgramNamedParameterfvNV(id, name.remaining(), MemoryUtil.getAddress(name), MemoryUtil.getAddress(params), function_pointer);
/* 48:   */   }
/* 49:   */   
/* 50:   */   static native void nglGetProgramNamedParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 51:   */   
/* 52:   */   public static void glGetProgramNamedParameterNV(int id, ByteBuffer name, DoubleBuffer params)
/* 53:   */   {
/* 54:60 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 55:61 */     long function_pointer = caps.glGetProgramNamedParameterdvNV;
/* 56:62 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 57:63 */     BufferChecks.checkDirect(name);
/* 58:64 */     BufferChecks.checkBuffer(params, 4);
/* 59:65 */     nglGetProgramNamedParameterdvNV(id, name.remaining(), MemoryUtil.getAddress(name), MemoryUtil.getAddress(params), function_pointer);
/* 60:   */   }
/* 61:   */   
/* 62:   */   static native void nglGetProgramNamedParameterdvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/* 63:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVFragmentProgram
 * JD-Core Version:    0.7.0.1
 */