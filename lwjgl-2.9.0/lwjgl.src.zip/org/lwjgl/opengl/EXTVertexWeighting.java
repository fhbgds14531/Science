/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.LWJGLUtil;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class EXTVertexWeighting
/*  9:   */ {
/* 10:   */   public static final int GL_MODELVIEW0_STACK_DEPTH_EXT = 2979;
/* 11:   */   public static final int GL_MODELVIEW1_STACK_DEPTH_EXT = 34050;
/* 12:   */   public static final int GL_MODELVIEW0_MATRIX_EXT = 2982;
/* 13:   */   public static final int GL_MODELVIEW1_MATRIX_EXT = 34054;
/* 14:   */   public static final int GL_VERTEX_WEIGHTING_EXT = 34057;
/* 15:   */   public static final int GL_MODELVIEW0_EXT = 5888;
/* 16:   */   public static final int GL_MODELVIEW1_EXT = 34058;
/* 17:   */   public static final int GL_CURRENT_VERTEX_WEIGHT_EXT = 34059;
/* 18:   */   public static final int GL_VERTEX_WEIGHT_ARRAY_EXT = 34060;
/* 19:   */   public static final int GL_VERTEX_WEIGHT_ARRAY_SIZE_EXT = 34061;
/* 20:   */   public static final int GL_VERTEX_WEIGHT_ARRAY_TYPE_EXT = 34062;
/* 21:   */   public static final int GL_VERTEX_WEIGHT_ARRAY_STRIDE_EXT = 34063;
/* 22:   */   public static final int GL_VERTEX_WEIGHT_ARRAY_POINTER_EXT = 34064;
/* 23:   */   
/* 24:   */   public static void glVertexWeightfEXT(float weight)
/* 25:   */   {
/* 26:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:28 */     long function_pointer = caps.glVertexWeightfEXT;
/* 28:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:30 */     nglVertexWeightfEXT(weight, function_pointer);
/* 30:   */   }
/* 31:   */   
/* 32:   */   static native void nglVertexWeightfEXT(float paramFloat, long paramLong);
/* 33:   */   
/* 34:   */   public static void glVertexWeightPointerEXT(int size, int stride, FloatBuffer pPointer)
/* 35:   */   {
/* 36:35 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 37:36 */     long function_pointer = caps.glVertexWeightPointerEXT;
/* 38:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 39:38 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 40:39 */     BufferChecks.checkDirect(pPointer);
/* 41:40 */     if (LWJGLUtil.CHECKS) {
/* 42:40 */       StateTracker.getReferences(caps).EXT_vertex_weighting_glVertexWeightPointerEXT_pPointer = pPointer;
/* 43:   */     }
/* 44:41 */     nglVertexWeightPointerEXT(size, 5126, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 45:   */   }
/* 46:   */   
/* 47:   */   static native void nglVertexWeightPointerEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 48:   */   
/* 49:   */   public static void glVertexWeightPointerEXT(int size, int type, int stride, long pPointer_buffer_offset)
/* 50:   */   {
/* 51:45 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 52:46 */     long function_pointer = caps.glVertexWeightPointerEXT;
/* 53:47 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 54:48 */     GLChecks.ensureArrayVBOenabled(caps);
/* 55:49 */     nglVertexWeightPointerEXTBO(size, type, stride, pPointer_buffer_offset, function_pointer);
/* 56:   */   }
/* 57:   */   
/* 58:   */   static native void nglVertexWeightPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 59:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTVertexWeighting
 * JD-Core Version:    0.7.0.1
 */