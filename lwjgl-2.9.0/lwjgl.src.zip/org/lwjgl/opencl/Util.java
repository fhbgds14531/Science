/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Field;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.lwjgl.LWJGLUtil;
/*  6:   */ import org.lwjgl.LWJGLUtil.TokenFilter;
/*  7:   */ 
/*  8:   */ public final class Util
/*  9:   */ {
/* 10:47 */   private static final Map<Integer, String> CL_ERROR_TOKENS = LWJGLUtil.getClassTokens(new LWJGLUtil.TokenFilter()
/* 11:   */   {
/* 12:   */     public boolean accept(Field field, int value)
/* 13:   */     {
/* 14:49 */       return value < 0;
/* 15:   */     }
/* 16:47 */   }, null, new Class[] { CL10.class, CL11.class, KHRGLSharing.class, KHRICD.class, APPLEGLSharing.class, EXTDeviceFission.class });
/* 17:   */   
/* 18:   */   public static void checkCLError(int errcode)
/* 19:   */   {
/* 20:57 */     if (errcode != 0) {
/* 21:58 */       throwCLError(errcode);
/* 22:   */     }
/* 23:   */   }
/* 24:   */   
/* 25:   */   private static void throwCLError(int errcode)
/* 26:   */   {
/* 27:62 */     String errname = (String)CL_ERROR_TOKENS.get(Integer.valueOf(errcode));
/* 28:63 */     if (errname == null) {
/* 29:64 */       errname = "UNKNOWN";
/* 30:   */     }
/* 31:65 */     throw new OpenCLException("Error Code: " + errname + " (" + LWJGLUtil.toHexString(errcode) + ")");
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.Util
 * JD-Core Version:    0.7.0.1
 */