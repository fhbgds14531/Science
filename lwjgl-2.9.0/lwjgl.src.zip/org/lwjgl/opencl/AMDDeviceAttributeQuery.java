package org.lwjgl.opencl;

public final class AMDDeviceAttributeQuery
{
  public static final int CL_DEVICE_PROFILING_TIMER_OFFSET_AMD = 16438;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.AMDDeviceAttributeQuery
 * JD-Core Version:    0.7.0.1
 */