/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class MacOSXDisplayPeerInfo
/*  7:   */   extends MacOSXCanvasPeerInfo
/*  8:   */ {
/*  9:   */   private boolean locked;
/* 10:   */   
/* 11:   */   MacOSXDisplayPeerInfo(PixelFormat pixel_format, ContextAttribs attribs, boolean support_pbuffer)
/* 12:   */     throws LWJGLException
/* 13:   */   {
/* 14:48 */     super(pixel_format, attribs, support_pbuffer);
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected void doLockAndInitHandle()
/* 18:   */     throws LWJGLException
/* 19:   */   {
/* 20:52 */     if (this.locked) {
/* 21:53 */       throw new RuntimeException("Already locked");
/* 22:   */     }
/* 23:54 */     Canvas canvas = ((MacOSXDisplay)Display.getImplementation()).getCanvas();
/* 24:55 */     if (canvas != null)
/* 25:   */     {
/* 26:56 */       initHandle(canvas);
/* 27:57 */       this.locked = true;
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected void doUnlock()
/* 32:   */     throws LWJGLException
/* 33:   */   {
/* 34:62 */     if (this.locked)
/* 35:   */     {
/* 36:63 */       super.doUnlock();
/* 37:64 */       this.locked = false;
/* 38:   */     }
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXDisplayPeerInfo
 * JD-Core Version:    0.7.0.1
 */