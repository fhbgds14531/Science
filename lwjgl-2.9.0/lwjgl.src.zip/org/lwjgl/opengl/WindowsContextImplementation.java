/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ import org.lwjgl.LWJGLUtil;
/*   7:    */ 
/*   8:    */ final class WindowsContextImplementation
/*   9:    */   implements ContextImplementation
/*  10:    */ {
/*  11:    */   public ByteBuffer create(PeerInfo peer_info, IntBuffer attribs, ByteBuffer shared_context_handle)
/*  12:    */     throws LWJGLException
/*  13:    */   {
/*  14: 48 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  15:    */     try
/*  16:    */     {
/*  17: 50 */       return nCreate(peer_handle, attribs, shared_context_handle);
/*  18:    */     }
/*  19:    */     finally
/*  20:    */     {
/*  21: 52 */       peer_info.unlock();
/*  22:    */     }
/*  23:    */   }
/*  24:    */   
/*  25:    */   private static native ByteBuffer nCreate(ByteBuffer paramByteBuffer1, IntBuffer paramIntBuffer, ByteBuffer paramByteBuffer2)
/*  26:    */     throws LWJGLException;
/*  27:    */   
/*  28:    */   native long getHGLRC(ByteBuffer paramByteBuffer);
/*  29:    */   
/*  30:    */   native long getHDC(ByteBuffer paramByteBuffer);
/*  31:    */   
/*  32:    */   public void swapBuffers()
/*  33:    */     throws LWJGLException
/*  34:    */   {
/*  35: 63 */     ContextGL current_context = ContextGL.getCurrentContext();
/*  36: 64 */     if (current_context == null) {
/*  37: 65 */       throw new IllegalStateException("No context is current");
/*  38:    */     }
/*  39: 66 */     synchronized (current_context)
/*  40:    */     {
/*  41: 67 */       PeerInfo current_peer_info = current_context.getPeerInfo();
/*  42: 68 */       ByteBuffer peer_handle = current_peer_info.lockAndGetHandle();
/*  43:    */       try
/*  44:    */       {
/*  45: 70 */         nSwapBuffers(peer_handle);
/*  46:    */       }
/*  47:    */       finally
/*  48:    */       {
/*  49: 72 */         current_peer_info.unlock();
/*  50:    */       }
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static native void nSwapBuffers(ByteBuffer paramByteBuffer)
/*  55:    */     throws LWJGLException;
/*  56:    */   
/*  57:    */   public void releaseDrawable(ByteBuffer context_handle)
/*  58:    */     throws LWJGLException
/*  59:    */   {}
/*  60:    */   
/*  61:    */   public void update(ByteBuffer context_handle) {}
/*  62:    */   
/*  63:    */   public void releaseCurrentContext()
/*  64:    */     throws LWJGLException
/*  65:    */   {}
/*  66:    */   
/*  67:    */   private static native void nReleaseCurrentContext()
/*  68:    */     throws LWJGLException;
/*  69:    */   
/*  70:    */   public void makeCurrent(PeerInfo peer_info, ByteBuffer handle)
/*  71:    */     throws LWJGLException
/*  72:    */   {
/*  73: 92 */     ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/*  74:    */     try
/*  75:    */     {
/*  76: 94 */       nMakeCurrent(peer_handle, handle);
/*  77:    */     }
/*  78:    */     finally
/*  79:    */     {
/*  80: 96 */       peer_info.unlock();
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   private static native void nMakeCurrent(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/*  85:    */     throws LWJGLException;
/*  86:    */   
/*  87:    */   public boolean isCurrent(ByteBuffer handle)
/*  88:    */     throws LWJGLException
/*  89:    */   {
/*  90:103 */     boolean result = nIsCurrent(handle);
/*  91:104 */     return result;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private static native boolean nIsCurrent(ByteBuffer paramByteBuffer)
/*  95:    */     throws LWJGLException;
/*  96:    */   
/*  97:    */   public void setSwapInterval(int value)
/*  98:    */   {
/*  99:110 */     boolean success = nSetSwapInterval(value);
/* 100:111 */     if (!success) {
/* 101:112 */       LWJGLUtil.log("Failed to set swap interval");
/* 102:    */     }
/* 103:113 */     Util.checkGLError();
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static native boolean nSetSwapInterval(int paramInt);
/* 107:    */   
/* 108:    */   public void destroy(PeerInfo peer_info, ByteBuffer handle)
/* 109:    */     throws LWJGLException
/* 110:    */   {
/* 111:119 */     nDestroy(handle);
/* 112:    */   }
/* 113:    */   
/* 114:    */   private static native void nDestroy(ByteBuffer paramByteBuffer)
/* 115:    */     throws LWJGLException;
/* 116:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsContextImplementation
 * JD-Core Version:    0.7.0.1
 */