/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBVertexAttribBinding
/*  4:   */ {
/*  5:   */   public static final int GL_VERTEX_ATTRIB_BINDING = 33492;
/*  6:   */   public static final int GL_VERTEX_ATTRIB_RELATIVE_OFFSET = 33493;
/*  7:   */   public static final int GL_VERTEX_BINDING_DIVISOR = 33494;
/*  8:   */   public static final int GL_VERTEX_BINDING_OFFSET = 33495;
/*  9:   */   public static final int GL_VERTEX_BINDING_STRIDE = 33496;
/* 10:   */   public static final int GL_MAX_VERTEX_ATTRIB_RELATIVE_OFFSET = 33497;
/* 11:   */   public static final int GL_MAX_VERTEX_ATTRIB_BINDINGS = 33498;
/* 12:   */   
/* 13:   */   public static void glBindVertexBuffer(int bindingindex, int buffer, long offset, int stride)
/* 14:   */   {
/* 15:33 */     GL43.glBindVertexBuffer(bindingindex, buffer, offset, stride);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static void glVertexAttribFormat(int attribindex, int size, int type, boolean normalized, int relativeoffset)
/* 19:   */   {
/* 20:37 */     GL43.glVertexAttribFormat(attribindex, size, type, normalized, relativeoffset);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static void glVertexAttribIFormat(int attribindex, int size, int type, int relativeoffset)
/* 24:   */   {
/* 25:41 */     GL43.glVertexAttribIFormat(attribindex, size, type, relativeoffset);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static void glVertexAttribLFormat(int attribindex, int size, int type, int relativeoffset)
/* 29:   */   {
/* 30:45 */     GL43.glVertexAttribLFormat(attribindex, size, type, relativeoffset);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static void glVertexAttribBinding(int attribindex, int bindingindex)
/* 34:   */   {
/* 35:49 */     GL43.glVertexAttribBinding(attribindex, bindingindex);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static void glVertexBindingDivisor(int bindingindex, int divisor)
/* 39:   */   {
/* 40:53 */     GL43.glVertexBindingDivisor(bindingindex, divisor);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBVertexAttribBinding
 * JD-Core Version:    0.7.0.1
 */