/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.InputStreamReader;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import java.util.regex.Matcher;
/*  12:    */ import java.util.regex.Pattern;
/*  13:    */ import org.lwjgl.LWJGLUtil;
/*  14:    */ 
/*  15:    */ public class XRandR
/*  16:    */ {
/*  17:    */   private static Screen[] current;
/*  18:    */   private static Map<String, Screen[]> screens;
/*  19:    */   
/*  20:    */   private static void populate()
/*  21:    */   {
/*  22: 56 */     if (screens == null)
/*  23:    */     {
/*  24: 58 */       screens = new HashMap();
/*  25:    */       try
/*  26:    */       {
/*  27: 65 */         Process p = Runtime.getRuntime().exec(new String[] { "xrandr", "-q" });
/*  28:    */         
/*  29: 67 */         List<Screen> currentList = new ArrayList();
/*  30: 68 */         List<Screen> possibles = new ArrayList();
/*  31: 69 */         String name = null;
/*  32:    */         
/*  33: 71 */         BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
/*  34:    */         String line;
/*  35: 73 */         while ((line = br.readLine()) != null)
/*  36:    */         {
/*  37: 75 */           line = line.trim();
/*  38: 76 */           String[] sa = line.split("\\s+");
/*  39: 78 */           if ("connected".equals(sa[1]))
/*  40:    */           {
/*  41: 81 */             if (name != null)
/*  42:    */             {
/*  43: 83 */               screens.put(name, possibles.toArray(new Screen[possibles.size()]));
/*  44: 84 */               possibles.clear();
/*  45:    */             }
/*  46: 86 */             name = sa[0];
/*  47:    */             
/*  48:    */ 
/*  49: 89 */             parseScreen(currentList, name, sa[2]);
/*  50:    */           }
/*  51: 91 */           else if (Pattern.matches("\\d*x\\d*", sa[0]))
/*  52:    */           {
/*  53: 94 */             parseScreen(possibles, name, sa[0]);
/*  54:    */           }
/*  55:    */         }
/*  56: 98 */         screens.put(name, possibles.toArray(new Screen[possibles.size()]));
/*  57:    */         
/*  58:100 */         current = (Screen[])currentList.toArray(new Screen[currentList.size()]);
/*  59:    */       }
/*  60:    */       catch (Throwable e)
/*  61:    */       {
/*  62:104 */         LWJGLUtil.log("Exception in XRandR.populate(): " + e.getMessage());
/*  63:105 */         screens.clear();
/*  64:106 */         current = new Screen[0];
/*  65:    */       }
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static Screen[] getConfiguration()
/*  70:    */   {
/*  71:117 */     populate();
/*  72:    */     
/*  73:119 */     return (Screen[])current.clone();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static void setConfiguration(Screen... screens)
/*  77:    */   {
/*  78:130 */     if (screens.length == 0) {
/*  79:131 */       throw new IllegalArgumentException("Must specify at least one screen");
/*  80:    */     }
/*  81:133 */     List<String> cmd = new ArrayList();
/*  82:134 */     cmd.add("xrandr");
/*  83:137 */     for (Screen screen : current)
/*  84:    */     {
/*  85:138 */       boolean found = false;
/*  86:139 */       for (Screen screen1 : screens) {
/*  87:140 */         if (screen1.name.equals(screen.name))
/*  88:    */         {
/*  89:141 */           found = true;
/*  90:142 */           break;
/*  91:    */         }
/*  92:    */       }
/*  93:146 */       if (!found)
/*  94:    */       {
/*  95:147 */         cmd.add("--output");
/*  96:148 */         cmd.add(screen.name);
/*  97:149 */         cmd.add("--off");
/*  98:    */       }
/*  99:    */     }
/* 100:154 */     for (Screen screen : screens) {
/* 101:155 */       screen.getArgs(cmd);
/* 102:    */     }
/* 103:    */     try
/* 104:    */     {
/* 105:162 */       Process p = Runtime.getRuntime().exec((String[])cmd.toArray(new String[cmd.size()]));
/* 106:    */       
/* 107:    */ 
/* 108:165 */       BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 109:    */       String line;
/* 110:167 */       while ((line = br.readLine()) != null) {
/* 111:169 */         LWJGLUtil.log("Unexpected output from xrandr process: " + line);
/* 112:    */       }
/* 113:171 */       current = screens;
/* 114:    */     }
/* 115:    */     catch (IOException e)
/* 116:    */     {
/* 117:175 */       LWJGLUtil.log("XRandR exception in setConfiguration(): " + e.getMessage());
/* 118:    */     }
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static String[] getScreenNames()
/* 122:    */   {
/* 123:185 */     populate();
/* 124:186 */     return (String[])screens.keySet().toArray(new String[screens.size()]);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static Screen[] getResolutions(String name)
/* 128:    */   {
/* 129:196 */     populate();
/* 130:    */     
/* 131:198 */     return (Screen[])((Screen[])screens.get(name)).clone();
/* 132:    */   }
/* 133:    */   
/* 134:201 */   private static final Pattern SCREEN_PATTERN1 = Pattern.compile("^(\\d+)x(\\d+)\\+(\\d+)\\+(\\d+)$");
/* 135:204 */   private static final Pattern SCREEN_PATTERN2 = Pattern.compile("^(\\d+)x(\\d+)$");
/* 136:    */   
/* 137:    */   private static void parseScreen(List<Screen> list, String name, String what)
/* 138:    */   {
/* 139:220 */     Matcher m = SCREEN_PATTERN1.matcher(what);
/* 140:221 */     if (!m.matches())
/* 141:    */     {
/* 142:223 */       m = SCREEN_PATTERN2.matcher(what);
/* 143:224 */       if (!m.matches())
/* 144:    */       {
/* 145:226 */         LWJGLUtil.log("Did not match: " + what);
/* 146:227 */         return;
/* 147:    */       }
/* 148:    */     }
/* 149:230 */     int width = Integer.parseInt(m.group(1));
/* 150:231 */     int height = Integer.parseInt(m.group(2));
/* 151:    */     int ypos;
/* 152:    */     int xpos;
/* 153:    */     int ypos;
/* 154:233 */     if (m.groupCount() > 3)
/* 155:    */     {
/* 156:235 */       int xpos = Integer.parseInt(m.group(3));
/* 157:236 */       ypos = Integer.parseInt(m.group(4));
/* 158:    */     }
/* 159:    */     else
/* 160:    */     {
/* 161:240 */       xpos = 0;
/* 162:241 */       ypos = 0;
/* 163:    */     }
/* 164:243 */     list.add(new Screen(name, width, height, xpos, ypos, null));
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static class Screen
/* 168:    */     implements Cloneable
/* 169:    */   {
/* 170:    */     public final String name;
/* 171:    */     public final int width;
/* 172:    */     public final int height;
/* 173:    */     public int xPos;
/* 174:    */     public int yPos;
/* 175:    */     
/* 176:    */     private Screen(String name, int width, int height, int xPos, int yPos)
/* 177:    */     {
/* 178:281 */       this.name = name;
/* 179:282 */       this.width = width;
/* 180:283 */       this.height = height;
/* 181:284 */       this.xPos = xPos;
/* 182:285 */       this.yPos = yPos;
/* 183:    */     }
/* 184:    */     
/* 185:    */     private void getArgs(List<String> argList)
/* 186:    */     {
/* 187:290 */       argList.add("--output");
/* 188:291 */       argList.add(this.name);
/* 189:292 */       argList.add("--mode");
/* 190:293 */       argList.add(this.width + "x" + this.height);
/* 191:294 */       argList.add("--pos");
/* 192:295 */       argList.add(this.xPos + "x" + this.yPos);
/* 193:    */     }
/* 194:    */     
/* 195:    */     public String toString()
/* 196:    */     {
/* 197:301 */       return this.name + " " + this.width + "x" + this.height + " @ " + this.xPos + "x" + this.yPos;
/* 198:    */     }
/* 199:    */   }
/* 200:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.XRandR
 * JD-Core Version:    0.7.0.1
 */