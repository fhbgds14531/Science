/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBProvokingVertex
/*  4:   */ {
/*  5:   */   public static final int GL_FIRST_VERTEX_CONVENTION = 36429;
/*  6:   */   public static final int GL_LAST_VERTEX_CONVENTION = 36430;
/*  7:   */   public static final int GL_PROVOKING_VERTEX = 36431;
/*  8:   */   public static final int GL_QUADS_FOLLOW_PROVOKING_VERTEX_CONVENTION = 36428;
/*  9:   */   
/* 10:   */   public static void glProvokingVertex(int mode)
/* 11:   */   {
/* 12:26 */     GL32.glProvokingVertex(mode);
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBProvokingVertex
 * JD-Core Version:    0.7.0.1
 */