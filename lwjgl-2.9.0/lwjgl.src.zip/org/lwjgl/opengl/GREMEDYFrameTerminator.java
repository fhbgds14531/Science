/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class GREMEDYFrameTerminator
/*  6:   */ {
/*  7:   */   public static void glFrameTerminatorGREMEDY()
/*  8:   */   {
/*  9:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 10:14 */     long function_pointer = caps.glFrameTerminatorGREMEDY;
/* 11:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 12:16 */     nglFrameTerminatorGREMEDY(function_pointer);
/* 13:   */   }
/* 14:   */   
/* 15:   */   static native void nglFrameTerminatorGREMEDY(long paramLong);
/* 16:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GREMEDYFrameTerminator
 * JD-Core Version:    0.7.0.1
 */