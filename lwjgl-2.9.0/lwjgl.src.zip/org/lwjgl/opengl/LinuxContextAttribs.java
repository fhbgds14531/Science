/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ final class LinuxContextAttribs
/*  4:   */   implements ContextAttribsImplementation
/*  5:   */ {
/*  6:   */   private static final int GLX_CONTEXT_MAJOR_VERSION_ARB = 8337;
/*  7:   */   private static final int GLX_CONTEXT_MINOR_VERSION_ARB = 8338;
/*  8:   */   private static final int GLX_CONTEXT_FLAGS_ARB = 8340;
/*  9:   */   private static final int GLX_CONTEXT_PROFILE_MASK_ARB = 37158;
/* 10:   */   private static final int GLX_CONTEXT_DEBUG_BIT_ARB = 1;
/* 11:   */   private static final int GLX_CONTEXT_FORWARD_COMPATIBLE_BIT_ARB = 2;
/* 12:   */   private static final int GLX_CONTEXT_CORE_PROFILE_BIT_ARB = 1;
/* 13:   */   private static final int GLX_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB = 2;
/* 14:   */   
/* 15:   */   public int getMajorVersionAttrib()
/* 16:   */   {
/* 17:56 */     return 8337;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int getMinorVersionAttrib()
/* 21:   */   {
/* 22:60 */     return 8338;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int getLayerPlaneAttrib()
/* 26:   */   {
/* 27:64 */     throw new UnsupportedOperationException();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int getFlagsAttrib()
/* 31:   */   {
/* 32:68 */     return 8340;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public int getDebugBit()
/* 36:   */   {
/* 37:72 */     return 1;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getForwardCompatibleBit()
/* 41:   */   {
/* 42:76 */     return 2;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public int getProfileMaskAttrib()
/* 46:   */   {
/* 47:80 */     return 37158;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public int getProfileCoreBit()
/* 51:   */   {
/* 52:84 */     return 1;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int getProfileCompatibilityBit()
/* 56:   */   {
/* 57:88 */     return 2;
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxContextAttribs
 * JD-Core Version:    0.7.0.1
 */