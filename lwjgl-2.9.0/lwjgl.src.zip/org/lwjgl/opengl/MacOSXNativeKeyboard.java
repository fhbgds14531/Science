/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.event.KeyEvent;
/*   4:    */ import java.io.PrintStream;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.util.HashMap;
/*   7:    */ 
/*   8:    */ final class MacOSXNativeKeyboard
/*   9:    */   extends EventQueue
/*  10:    */ {
/*  11: 49 */   private final byte[] key_states = new byte[256];
/*  12: 52 */   private final ByteBuffer event = ByteBuffer.allocate(18);
/*  13:    */   private ByteBuffer window_handle;
/*  14:    */   private boolean has_deferred_event;
/*  15:    */   private long deferred_nanos;
/*  16:    */   private int deferred_key_code;
/*  17:    */   private byte deferred_key_state;
/*  18:    */   private int deferred_character;
/*  19:    */   private HashMap<Short, Integer> nativeToLwjglMap;
/*  20:    */   
/*  21:    */   MacOSXNativeKeyboard(ByteBuffer window_handle)
/*  22:    */   {
/*  23: 65 */     super(18);
/*  24: 66 */     this.nativeToLwjglMap = new HashMap();
/*  25: 67 */     initKeyboardMappings();
/*  26: 68 */     this.window_handle = window_handle;
/*  27:    */   }
/*  28:    */   
/*  29:    */   private native void nRegisterKeyListener(ByteBuffer paramByteBuffer);
/*  30:    */   
/*  31:    */   private native void nUnregisterKeyListener(ByteBuffer paramByteBuffer);
/*  32:    */   
/*  33:    */   private void initKeyboardMappings()
/*  34:    */   {
/*  35: 77 */     this.nativeToLwjglMap.put(Short.valueOf((short)29), Integer.valueOf(11));
/*  36: 78 */     this.nativeToLwjglMap.put(Short.valueOf((short)18), Integer.valueOf(2));
/*  37: 79 */     this.nativeToLwjglMap.put(Short.valueOf((short)19), Integer.valueOf(3));
/*  38: 80 */     this.nativeToLwjglMap.put(Short.valueOf((short)20), Integer.valueOf(4));
/*  39: 81 */     this.nativeToLwjglMap.put(Short.valueOf((short)21), Integer.valueOf(5));
/*  40: 82 */     this.nativeToLwjglMap.put(Short.valueOf((short)23), Integer.valueOf(6));
/*  41: 83 */     this.nativeToLwjglMap.put(Short.valueOf((short)22), Integer.valueOf(7));
/*  42: 84 */     this.nativeToLwjglMap.put(Short.valueOf((short)26), Integer.valueOf(8));
/*  43: 85 */     this.nativeToLwjglMap.put(Short.valueOf((short)28), Integer.valueOf(9));
/*  44: 86 */     this.nativeToLwjglMap.put(Short.valueOf((short)25), Integer.valueOf(10));
/*  45: 87 */     this.nativeToLwjglMap.put(Short.valueOf((short)0), Integer.valueOf(30));
/*  46: 88 */     this.nativeToLwjglMap.put(Short.valueOf((short)11), Integer.valueOf(48));
/*  47: 89 */     this.nativeToLwjglMap.put(Short.valueOf((short)8), Integer.valueOf(46));
/*  48: 90 */     this.nativeToLwjglMap.put(Short.valueOf((short)2), Integer.valueOf(32));
/*  49: 91 */     this.nativeToLwjglMap.put(Short.valueOf((short)14), Integer.valueOf(18));
/*  50: 92 */     this.nativeToLwjglMap.put(Short.valueOf((short)3), Integer.valueOf(33));
/*  51: 93 */     this.nativeToLwjglMap.put(Short.valueOf((short)5), Integer.valueOf(34));
/*  52: 94 */     this.nativeToLwjglMap.put(Short.valueOf((short)4), Integer.valueOf(35));
/*  53: 95 */     this.nativeToLwjglMap.put(Short.valueOf((short)34), Integer.valueOf(23));
/*  54: 96 */     this.nativeToLwjglMap.put(Short.valueOf((short)38), Integer.valueOf(36));
/*  55: 97 */     this.nativeToLwjglMap.put(Short.valueOf((short)40), Integer.valueOf(37));
/*  56: 98 */     this.nativeToLwjglMap.put(Short.valueOf((short)37), Integer.valueOf(38));
/*  57: 99 */     this.nativeToLwjglMap.put(Short.valueOf((short)46), Integer.valueOf(50));
/*  58:100 */     this.nativeToLwjglMap.put(Short.valueOf((short)45), Integer.valueOf(49));
/*  59:101 */     this.nativeToLwjglMap.put(Short.valueOf((short)31), Integer.valueOf(24));
/*  60:102 */     this.nativeToLwjglMap.put(Short.valueOf((short)35), Integer.valueOf(25));
/*  61:103 */     this.nativeToLwjglMap.put(Short.valueOf((short)12), Integer.valueOf(16));
/*  62:104 */     this.nativeToLwjglMap.put(Short.valueOf((short)15), Integer.valueOf(19));
/*  63:105 */     this.nativeToLwjglMap.put(Short.valueOf((short)1), Integer.valueOf(31));
/*  64:106 */     this.nativeToLwjglMap.put(Short.valueOf((short)17), Integer.valueOf(20));
/*  65:107 */     this.nativeToLwjglMap.put(Short.valueOf((short)32), Integer.valueOf(22));
/*  66:108 */     this.nativeToLwjglMap.put(Short.valueOf((short)9), Integer.valueOf(47));
/*  67:109 */     this.nativeToLwjglMap.put(Short.valueOf((short)13), Integer.valueOf(17));
/*  68:110 */     this.nativeToLwjglMap.put(Short.valueOf((short)7), Integer.valueOf(45));
/*  69:111 */     this.nativeToLwjglMap.put(Short.valueOf((short)16), Integer.valueOf(21));
/*  70:112 */     this.nativeToLwjglMap.put(Short.valueOf((short)6), Integer.valueOf(44));
/*  71:    */     
/*  72:114 */     this.nativeToLwjglMap.put(Short.valueOf((short)42), Integer.valueOf(43));
/*  73:115 */     this.nativeToLwjglMap.put(Short.valueOf((short)43), Integer.valueOf(51));
/*  74:116 */     this.nativeToLwjglMap.put(Short.valueOf((short)24), Integer.valueOf(13));
/*  75:117 */     this.nativeToLwjglMap.put(Short.valueOf((short)33), Integer.valueOf(26));
/*  76:118 */     this.nativeToLwjglMap.put(Short.valueOf((short)27), Integer.valueOf(12));
/*  77:119 */     this.nativeToLwjglMap.put(Short.valueOf((short)39), Integer.valueOf(40));
/*  78:120 */     this.nativeToLwjglMap.put(Short.valueOf((short)30), Integer.valueOf(27));
/*  79:121 */     this.nativeToLwjglMap.put(Short.valueOf((short)41), Integer.valueOf(39));
/*  80:122 */     this.nativeToLwjglMap.put(Short.valueOf((short)44), Integer.valueOf(53));
/*  81:123 */     this.nativeToLwjglMap.put(Short.valueOf((short)47), Integer.valueOf(52));
/*  82:124 */     this.nativeToLwjglMap.put(Short.valueOf((short)50), Integer.valueOf(144));
/*  83:    */     
/*  84:126 */     this.nativeToLwjglMap.put(Short.valueOf((short)65), Integer.valueOf(83));
/*  85:127 */     this.nativeToLwjglMap.put(Short.valueOf((short)67), Integer.valueOf(55));
/*  86:128 */     this.nativeToLwjglMap.put(Short.valueOf((short)69), Integer.valueOf(78));
/*  87:129 */     this.nativeToLwjglMap.put(Short.valueOf((short)71), Integer.valueOf(218));
/*  88:130 */     this.nativeToLwjglMap.put(Short.valueOf((short)75), Integer.valueOf(181));
/*  89:131 */     this.nativeToLwjglMap.put(Short.valueOf((short)76), Integer.valueOf(156));
/*  90:132 */     this.nativeToLwjglMap.put(Short.valueOf((short)78), Integer.valueOf(74));
/*  91:133 */     this.nativeToLwjglMap.put(Short.valueOf((short)81), Integer.valueOf(141));
/*  92:    */     
/*  93:135 */     this.nativeToLwjglMap.put(Short.valueOf((short)82), Integer.valueOf(82));
/*  94:136 */     this.nativeToLwjglMap.put(Short.valueOf((short)83), Integer.valueOf(79));
/*  95:137 */     this.nativeToLwjglMap.put(Short.valueOf((short)84), Integer.valueOf(80));
/*  96:138 */     this.nativeToLwjglMap.put(Short.valueOf((short)85), Integer.valueOf(81));
/*  97:139 */     this.nativeToLwjglMap.put(Short.valueOf((short)86), Integer.valueOf(75));
/*  98:140 */     this.nativeToLwjglMap.put(Short.valueOf((short)87), Integer.valueOf(76));
/*  99:141 */     this.nativeToLwjglMap.put(Short.valueOf((short)88), Integer.valueOf(77));
/* 100:142 */     this.nativeToLwjglMap.put(Short.valueOf((short)89), Integer.valueOf(71));
/* 101:143 */     this.nativeToLwjglMap.put(Short.valueOf((short)91), Integer.valueOf(72));
/* 102:144 */     this.nativeToLwjglMap.put(Short.valueOf((short)92), Integer.valueOf(73));
/* 103:    */     
/* 104:    */ 
/* 105:147 */     this.nativeToLwjglMap.put(Short.valueOf((short)36), Integer.valueOf(28));
/* 106:148 */     this.nativeToLwjglMap.put(Short.valueOf((short)48), Integer.valueOf(15));
/* 107:149 */     this.nativeToLwjglMap.put(Short.valueOf((short)49), Integer.valueOf(57));
/* 108:150 */     this.nativeToLwjglMap.put(Short.valueOf((short)51), Integer.valueOf(14));
/* 109:151 */     this.nativeToLwjglMap.put(Short.valueOf((short)53), Integer.valueOf(1));
/* 110:152 */     this.nativeToLwjglMap.put(Short.valueOf((short)54), Integer.valueOf(220));
/* 111:153 */     this.nativeToLwjglMap.put(Short.valueOf((short)55), Integer.valueOf(219));
/* 112:154 */     this.nativeToLwjglMap.put(Short.valueOf((short)56), Integer.valueOf(42));
/* 113:155 */     this.nativeToLwjglMap.put(Short.valueOf((short)57), Integer.valueOf(58));
/* 114:156 */     this.nativeToLwjglMap.put(Short.valueOf((short)58), Integer.valueOf(56));
/* 115:157 */     this.nativeToLwjglMap.put(Short.valueOf((short)59), Integer.valueOf(29));
/* 116:158 */     this.nativeToLwjglMap.put(Short.valueOf((short)60), Integer.valueOf(54));
/* 117:159 */     this.nativeToLwjglMap.put(Short.valueOf((short)61), Integer.valueOf(184));
/* 118:160 */     this.nativeToLwjglMap.put(Short.valueOf((short)62), Integer.valueOf(157));
/* 119:    */     
/* 120:162 */     this.nativeToLwjglMap.put(Short.valueOf((short)63), Integer.valueOf(196));
/* 121:163 */     this.nativeToLwjglMap.put(Short.valueOf((short)119), Integer.valueOf(207));
/* 122:    */     
/* 123:165 */     this.nativeToLwjglMap.put(Short.valueOf((short)122), Integer.valueOf(59));
/* 124:166 */     this.nativeToLwjglMap.put(Short.valueOf((short)120), Integer.valueOf(60));
/* 125:167 */     this.nativeToLwjglMap.put(Short.valueOf((short)99), Integer.valueOf(61));
/* 126:168 */     this.nativeToLwjglMap.put(Short.valueOf((short)118), Integer.valueOf(62));
/* 127:169 */     this.nativeToLwjglMap.put(Short.valueOf((short)96), Integer.valueOf(63));
/* 128:170 */     this.nativeToLwjglMap.put(Short.valueOf((short)97), Integer.valueOf(64));
/* 129:171 */     this.nativeToLwjglMap.put(Short.valueOf((short)98), Integer.valueOf(65));
/* 130:172 */     this.nativeToLwjglMap.put(Short.valueOf((short)100), Integer.valueOf(66));
/* 131:173 */     this.nativeToLwjglMap.put(Short.valueOf((short)101), Integer.valueOf(67));
/* 132:174 */     this.nativeToLwjglMap.put(Short.valueOf((short)109), Integer.valueOf(68));
/* 133:175 */     this.nativeToLwjglMap.put(Short.valueOf((short)103), Integer.valueOf(87));
/* 134:176 */     this.nativeToLwjglMap.put(Short.valueOf((short)111), Integer.valueOf(88));
/* 135:177 */     this.nativeToLwjglMap.put(Short.valueOf((short)105), Integer.valueOf(100));
/* 136:178 */     this.nativeToLwjglMap.put(Short.valueOf((short)107), Integer.valueOf(101));
/* 137:179 */     this.nativeToLwjglMap.put(Short.valueOf((short)113), Integer.valueOf(102));
/* 138:180 */     this.nativeToLwjglMap.put(Short.valueOf((short)106), Integer.valueOf(103));
/* 139:181 */     this.nativeToLwjglMap.put(Short.valueOf((short)64), Integer.valueOf(104));
/* 140:182 */     this.nativeToLwjglMap.put(Short.valueOf((short)79), Integer.valueOf(105));
/* 141:183 */     this.nativeToLwjglMap.put(Short.valueOf((short)80), Integer.valueOf(113));
/* 142:    */     
/* 143:    */ 
/* 144:186 */     this.nativeToLwjglMap.put(Short.valueOf((short)117), Integer.valueOf(211));
/* 145:187 */     this.nativeToLwjglMap.put(Short.valueOf((short)114), Integer.valueOf(210));
/* 146:188 */     this.nativeToLwjglMap.put(Short.valueOf((short)115), Integer.valueOf(199));
/* 147:    */     
/* 148:190 */     this.nativeToLwjglMap.put(Short.valueOf((short)121), Integer.valueOf(209));
/* 149:191 */     this.nativeToLwjglMap.put(Short.valueOf((short)116), Integer.valueOf(201));
/* 150:    */     
/* 151:    */ 
/* 152:194 */     this.nativeToLwjglMap.put(Short.valueOf((short)123), Integer.valueOf(203));
/* 153:195 */     this.nativeToLwjglMap.put(Short.valueOf((short)124), Integer.valueOf(205));
/* 154:196 */     this.nativeToLwjglMap.put(Short.valueOf((short)125), Integer.valueOf(208));
/* 155:197 */     this.nativeToLwjglMap.put(Short.valueOf((short)126), Integer.valueOf(200));
/* 156:    */     
/* 157:199 */     this.nativeToLwjglMap.put(Short.valueOf((short)10), Integer.valueOf(167));
/* 158:    */     
/* 159:201 */     this.nativeToLwjglMap.put(Short.valueOf((short)110), Integer.valueOf(221));
/* 160:202 */     this.nativeToLwjglMap.put(Short.valueOf((short)297), Integer.valueOf(146));
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void register()
/* 164:    */   {
/* 165:206 */     nRegisterKeyListener(this.window_handle);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void unregister()
/* 169:    */   {
/* 170:210 */     nUnregisterKeyListener(this.window_handle);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public void putKeyboardEvent(int key_code, byte state, int character, long nanos, boolean repeat)
/* 174:    */   {
/* 175:214 */     this.event.clear();
/* 176:215 */     this.event.putInt(key_code).put(state).putInt(character).putLong(nanos).put((byte)(repeat ? 1 : 0));
/* 177:216 */     this.event.flip();
/* 178:217 */     putEvent(this.event);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public synchronized void poll(ByteBuffer key_down_buffer)
/* 182:    */   {
/* 183:221 */     flushDeferredEvent();
/* 184:222 */     int old_position = key_down_buffer.position();
/* 185:223 */     key_down_buffer.put(this.key_states);
/* 186:224 */     key_down_buffer.position(old_position);
/* 187:    */   }
/* 188:    */   
/* 189:    */   public synchronized void copyEvents(ByteBuffer dest)
/* 190:    */   {
/* 191:228 */     flushDeferredEvent();
/* 192:229 */     super.copyEvents(dest);
/* 193:    */   }
/* 194:    */   
/* 195:    */   private synchronized void handleKey(int key_code, byte state, int character, long nanos)
/* 196:    */   {
/* 197:233 */     if (character == 65535) {
/* 198:234 */       character = 0;
/* 199:    */     }
/* 200:235 */     if (state == 1)
/* 201:    */     {
/* 202:236 */       boolean repeat = false;
/* 203:237 */       if (this.has_deferred_event) {
/* 204:238 */         if ((nanos == this.deferred_nanos) && (this.deferred_key_code == key_code))
/* 205:    */         {
/* 206:239 */           this.has_deferred_event = false;
/* 207:240 */           repeat = true;
/* 208:    */         }
/* 209:    */         else
/* 210:    */         {
/* 211:242 */           flushDeferredEvent();
/* 212:    */         }
/* 213:    */       }
/* 214:244 */       putKeyEvent(key_code, state, character, nanos, repeat);
/* 215:    */     }
/* 216:    */     else
/* 217:    */     {
/* 218:246 */       flushDeferredEvent();
/* 219:247 */       this.has_deferred_event = true;
/* 220:248 */       this.deferred_nanos = nanos;
/* 221:249 */       this.deferred_key_code = key_code;
/* 222:250 */       this.deferred_key_state = state;
/* 223:251 */       this.deferred_character = character;
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   private void flushDeferredEvent()
/* 228:    */   {
/* 229:256 */     if (this.has_deferred_event)
/* 230:    */     {
/* 231:257 */       putKeyEvent(this.deferred_key_code, this.deferred_key_state, this.deferred_character, this.deferred_nanos, false);
/* 232:258 */       this.has_deferred_event = false;
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   public void putKeyEvent(int key_code, byte state, int character, long nanos, boolean repeat)
/* 237:    */   {
/* 238:264 */     int mapped_code = getMappedKeyCode((short)key_code);
/* 239:265 */     if (mapped_code < 0)
/* 240:    */     {
/* 241:266 */       System.out.println("Unrecognized keycode: " + key_code);
/* 242:    */       
/* 243:268 */       return;
/* 244:    */     }
/* 245:270 */     if (this.key_states[mapped_code] == state) {
/* 246:271 */       repeat = true;
/* 247:    */     }
/* 248:272 */     this.key_states[mapped_code] = state;
/* 249:273 */     int key_int_char = character & 0xFFFF;
/* 250:274 */     putKeyboardEvent(mapped_code, state, key_int_char, nanos, repeat);
/* 251:    */   }
/* 252:    */   
/* 253:    */   private int getMappedKeyCode(short key_code)
/* 254:    */   {
/* 255:278 */     if (this.nativeToLwjglMap.containsKey(Short.valueOf(key_code))) {
/* 256:279 */       return ((Integer)this.nativeToLwjglMap.get(Short.valueOf(key_code))).intValue();
/* 257:    */     }
/* 258:281 */     return -1;
/* 259:    */   }
/* 260:    */   
/* 261:    */   public void keyPressed(int key_code, int character, long nanos)
/* 262:    */   {
/* 263:285 */     handleKey(key_code, (byte)1, character, nanos);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public void keyReleased(int key_code, int character, long nanos)
/* 267:    */   {
/* 268:289 */     handleKey(key_code, (byte)0, character, nanos);
/* 269:    */   }
/* 270:    */   
/* 271:    */   public void keyTyped(KeyEvent e) {}
/* 272:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXNativeKeyboard
 * JD-Core Version:    0.7.0.1
 */