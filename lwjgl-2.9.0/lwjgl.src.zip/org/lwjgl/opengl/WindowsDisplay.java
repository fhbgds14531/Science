/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.awt.Canvas;
/*    4:     */ import java.awt.KeyboardFocusManager;
/*    5:     */ import java.lang.reflect.Method;
/*    6:     */ import java.nio.ByteBuffer;
/*    7:     */ import java.nio.FloatBuffer;
/*    8:     */ import java.nio.IntBuffer;
/*    9:     */ import javax.swing.SwingUtilities;
/*   10:     */ import org.lwjgl.BufferUtils;
/*   11:     */ import org.lwjgl.LWJGLException;
/*   12:     */ import org.lwjgl.LWJGLUtil;
/*   13:     */ import org.lwjgl.MemoryUtil;
/*   14:     */ import org.lwjgl.input.Mouse;
/*   15:     */ 
/*   16:     */ final class WindowsDisplay
/*   17:     */   implements DisplayImplementation
/*   18:     */ {
/*   19:     */   private static final int GAMMA_LENGTH = 256;
/*   20:     */   private static final int WM_WINDOWPOSCHANGED = 71;
/*   21:     */   private static final int WM_MOVE = 3;
/*   22:     */   private static final int WM_CANCELMODE = 31;
/*   23:     */   private static final int WM_MOUSEMOVE = 512;
/*   24:     */   private static final int WM_LBUTTONDOWN = 513;
/*   25:     */   private static final int WM_LBUTTONUP = 514;
/*   26:     */   private static final int WM_LBUTTONDBLCLK = 515;
/*   27:     */   private static final int WM_RBUTTONDOWN = 516;
/*   28:     */   private static final int WM_RBUTTONUP = 517;
/*   29:     */   private static final int WM_RBUTTONDBLCLK = 518;
/*   30:     */   private static final int WM_MBUTTONDOWN = 519;
/*   31:     */   private static final int WM_MBUTTONUP = 520;
/*   32:     */   private static final int WM_MBUTTONDBLCLK = 521;
/*   33:     */   private static final int WM_XBUTTONDOWN = 523;
/*   34:     */   private static final int WM_XBUTTONUP = 524;
/*   35:     */   private static final int WM_XBUTTONDBLCLK = 525;
/*   36:     */   private static final int WM_MOUSEWHEEL = 522;
/*   37:     */   private static final int WM_CAPTURECHANGED = 533;
/*   38:     */   private static final int WM_MOUSELEAVE = 675;
/*   39:     */   private static final int WM_ENTERSIZEMOVE = 561;
/*   40:     */   private static final int WM_EXITSIZEMOVE = 562;
/*   41:     */   private static final int WM_SIZING = 532;
/*   42:     */   private static final int WM_KEYDOWN = 256;
/*   43:     */   private static final int WM_KEYUP = 257;
/*   44:     */   private static final int WM_SYSKEYUP = 261;
/*   45:     */   private static final int WM_SYSKEYDOWN = 260;
/*   46:     */   private static final int WM_SYSCHAR = 262;
/*   47:     */   private static final int WM_CHAR = 258;
/*   48:     */   private static final int WM_GETICON = 127;
/*   49:     */   private static final int WM_SETICON = 128;
/*   50:     */   private static final int WM_SETCURSOR = 32;
/*   51:     */   private static final int WM_MOUSEACTIVATE = 33;
/*   52:     */   private static final int WM_QUIT = 18;
/*   53:     */   private static final int WM_SYSCOMMAND = 274;
/*   54:     */   private static final int WM_PAINT = 15;
/*   55:     */   private static final int WM_KILLFOCUS = 8;
/*   56:     */   private static final int WM_SETFOCUS = 7;
/*   57:     */   private static final int SC_SIZE = 61440;
/*   58:     */   private static final int SC_MOVE = 61456;
/*   59:     */   private static final int SC_MINIMIZE = 61472;
/*   60:     */   private static final int SC_MAXIMIZE = 61488;
/*   61:     */   private static final int SC_NEXTWINDOW = 61504;
/*   62:     */   private static final int SC_PREVWINDOW = 61520;
/*   63:     */   private static final int SC_CLOSE = 61536;
/*   64:     */   private static final int SC_VSCROLL = 61552;
/*   65:     */   private static final int SC_HSCROLL = 61568;
/*   66:     */   private static final int SC_MOUSEMENU = 61584;
/*   67:     */   private static final int SC_KEYMENU = 61696;
/*   68:     */   private static final int SC_ARRANGE = 61712;
/*   69:     */   private static final int SC_RESTORE = 61728;
/*   70:     */   private static final int SC_TASKLIST = 61744;
/*   71:     */   private static final int SC_SCREENSAVE = 61760;
/*   72:     */   private static final int SC_HOTKEY = 61776;
/*   73:     */   private static final int SC_DEFAULT = 61792;
/*   74:     */   private static final int SC_MONITORPOWER = 61808;
/*   75:     */   private static final int SC_CONTEXTHELP = 61824;
/*   76:     */   private static final int SC_SEPARATOR = 61455;
/*   77:     */   static final int SM_CXCURSOR = 13;
/*   78:     */   static final int SM_CYCURSOR = 14;
/*   79:     */   static final int SM_CMOUSEBUTTONS = 43;
/*   80:     */   static final int SM_MOUSEWHEELPRESENT = 75;
/*   81:     */   private static final int SIZE_RESTORED = 0;
/*   82:     */   private static final int SIZE_MINIMIZED = 1;
/*   83:     */   private static final int SIZE_MAXIMIZED = 2;
/*   84:     */   private static final int WM_SIZE = 5;
/*   85:     */   private static final int WM_ACTIVATE = 6;
/*   86:     */   private static final int WA_INACTIVE = 0;
/*   87:     */   private static final int WA_ACTIVE = 1;
/*   88:     */   private static final int WA_CLICKACTIVE = 2;
/*   89:     */   private static final int SW_NORMAL = 1;
/*   90:     */   private static final int SW_SHOWMINNOACTIVE = 7;
/*   91:     */   private static final int SW_SHOWDEFAULT = 10;
/*   92:     */   private static final int SW_RESTORE = 9;
/*   93:     */   private static final int SW_MAXIMIZE = 3;
/*   94:     */   private static final int ICON_SMALL = 0;
/*   95:     */   private static final int ICON_BIG = 1;
/*   96: 140 */   private static final IntBuffer rect_buffer = BufferUtils.createIntBuffer(4);
/*   97: 141 */   private static final Rect rect = new Rect(null);
/*   98:     */   private static final long HWND_TOP = 0L;
/*   99:     */   private static final long HWND_BOTTOM = 1L;
/*  100:     */   private static final long HWND_TOPMOST = -1L;
/*  101:     */   private static final long HWND_NOTOPMOST = -2L;
/*  102:     */   private static final int SWP_NOSIZE = 1;
/*  103:     */   private static final int SWP_NOMOVE = 2;
/*  104:     */   private static final int SWP_NOZORDER = 4;
/*  105:     */   private static final int SWP_FRAMECHANGED = 32;
/*  106:     */   private static final int GWL_STYLE = -16;
/*  107:     */   private static final int GWL_EXSTYLE = -20;
/*  108:     */   private static final int WS_THICKFRAME = 262144;
/*  109:     */   private static final int WS_MAXIMIZEBOX = 65536;
/*  110:     */   private static final int HTCLIENT = 1;
/*  111:     */   private static final int MK_XBUTTON1 = 32;
/*  112:     */   private static final int MK_XBUTTON2 = 64;
/*  113:     */   private static final int XBUTTON1 = 1;
/*  114:     */   private static final int XBUTTON2 = 2;
/*  115:     */   private static WindowsDisplay current_display;
/*  116:     */   private static boolean cursor_clipped;
/*  117:     */   private WindowsDisplayPeerInfo peer_info;
/*  118:     */   private Object current_cursor;
/*  119:     */   private Canvas parent;
/*  120:     */   private static boolean hasParent;
/*  121:     */   private WindowsKeyboard keyboard;
/*  122:     */   private WindowsMouse mouse;
/*  123:     */   private boolean close_requested;
/*  124:     */   private boolean is_dirty;
/*  125:     */   private ByteBuffer current_gamma;
/*  126:     */   private ByteBuffer saved_gamma;
/*  127:     */   private DisplayMode current_mode;
/*  128:     */   private boolean mode_set;
/*  129:     */   private boolean isMinimized;
/*  130:     */   private boolean isFocused;
/*  131:     */   private boolean redoMakeContextCurrent;
/*  132:     */   private boolean inAppActivate;
/*  133:     */   private boolean resized;
/*  134:     */   private boolean resizable;
/*  135:     */   private boolean maximized;
/*  136:     */   private int x;
/*  137:     */   private int y;
/*  138:     */   private int width;
/*  139:     */   private int height;
/*  140:     */   private long hwnd;
/*  141:     */   private long hdc;
/*  142:     */   private long small_icon;
/*  143:     */   private long large_icon;
/*  144:     */   private boolean iconsLoaded;
/*  145: 204 */   private int captureMouse = -1;
/*  146:     */   private boolean trackingMouse;
/*  147:     */   private boolean mouseInside;
/*  148:     */   
/*  149:     */   static
/*  150:     */   {
/*  151:     */     try
/*  152:     */     {
/*  153: 210 */       Method windowProc = WindowsDisplay.class.getDeclaredMethod("handleMessage", new Class[] { Long.TYPE, Integer.TYPE, Long.TYPE, Long.TYPE, Long.TYPE });
/*  154: 211 */       setWindowProc(windowProc);
/*  155:     */     }
/*  156:     */     catch (NoSuchMethodException e)
/*  157:     */     {
/*  158: 213 */       throw new RuntimeException(e);
/*  159:     */     }
/*  160:     */   }
/*  161:     */   
/*  162:     */   WindowsDisplay()
/*  163:     */   {
/*  164: 218 */     current_display = this;
/*  165:     */   }
/*  166:     */   
/*  167:     */   public void createWindow(DrawableLWJGL drawable, DisplayMode mode, Canvas parent, int x, int y)
/*  168:     */     throws LWJGLException
/*  169:     */   {
/*  170: 222 */     this.close_requested = false;
/*  171: 223 */     this.is_dirty = false;
/*  172: 224 */     this.isMinimized = false;
/*  173: 225 */     this.isFocused = false;
/*  174: 226 */     this.redoMakeContextCurrent = false;
/*  175: 227 */     this.maximized = false;
/*  176: 228 */     this.parent = parent;
/*  177: 229 */     hasParent = parent != null;
/*  178: 230 */     long parent_hwnd = parent != null ? getHwnd(parent) : 0L;
/*  179: 231 */     this.hwnd = nCreateWindow(x, y, mode.getWidth(), mode.getHeight(), (Display.isFullscreen()) || (isUndecorated()), parent != null, parent_hwnd);
/*  180: 232 */     this.resizable = false;
/*  181: 233 */     if (this.hwnd == 0L) {
/*  182: 234 */       throw new LWJGLException("Failed to create window");
/*  183:     */     }
/*  184: 236 */     this.hdc = getDC(this.hwnd);
/*  185: 237 */     if (this.hdc == 0L)
/*  186:     */     {
/*  187: 238 */       nDestroyWindow(this.hwnd);
/*  188: 239 */       throw new LWJGLException("Failed to get dc");
/*  189:     */     }
/*  190:     */     try
/*  191:     */     {
/*  192: 243 */       if ((drawable instanceof DrawableGL))
/*  193:     */       {
/*  194: 244 */         int format = WindowsPeerInfo.choosePixelFormat(getHdc(), 0, 0, (PixelFormat)drawable.getPixelFormat(), null, true, true, false, true);
/*  195: 245 */         WindowsPeerInfo.setPixelFormat(getHdc(), format);
/*  196:     */       }
/*  197:     */       else
/*  198:     */       {
/*  199: 247 */         this.peer_info = new WindowsDisplayPeerInfo(true);
/*  200: 248 */         ((DrawableGLES)drawable).initialize(this.hwnd, this.hdc, 4, (org.lwjgl.opengles.PixelFormat)drawable.getPixelFormat());
/*  201:     */       }
/*  202: 250 */       this.peer_info.initDC(getHwnd(), getHdc());
/*  203: 251 */       showWindow(getHwnd(), 10);
/*  204:     */       
/*  205: 253 */       updateWidthAndHeight();
/*  206: 255 */       if (parent == null)
/*  207:     */       {
/*  208: 256 */         if (Display.isResizable()) {
/*  209: 257 */           setResizable(true);
/*  210:     */         }
/*  211: 259 */         setForegroundWindow(getHwnd());
/*  212:     */       }
/*  213: 261 */       grabFocus();
/*  214:     */     }
/*  215:     */     catch (LWJGLException e)
/*  216:     */     {
/*  217: 263 */       nReleaseDC(this.hwnd, this.hdc);
/*  218: 264 */       nDestroyWindow(this.hwnd);
/*  219: 265 */       throw e;
/*  220:     */     }
/*  221:     */   }
/*  222:     */   
/*  223:     */   private void updateWidthAndHeight()
/*  224:     */   {
/*  225: 270 */     getClientRect(this.hwnd, rect_buffer);
/*  226: 271 */     rect.copyFromBuffer(rect_buffer);
/*  227: 272 */     this.width = (rect.right - rect.left);
/*  228: 273 */     this.height = (rect.bottom - rect.top);
/*  229:     */   }
/*  230:     */   
/*  231:     */   private static boolean isUndecorated()
/*  232:     */   {
/*  233: 279 */     return Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated");
/*  234:     */   }
/*  235:     */   
/*  236:     */   private static long getHwnd(Canvas parent)
/*  237:     */     throws LWJGLException
/*  238:     */   {
/*  239: 283 */     AWTCanvasImplementation awt_impl = AWTGLCanvas.createImplementation();
/*  240: 284 */     WindowsPeerInfo parent_peer_info = (WindowsPeerInfo)awt_impl.createPeerInfo(parent, null, null);
/*  241: 285 */     ByteBuffer parent_peer_info_handle = parent_peer_info.lockAndGetHandle();
/*  242:     */     try
/*  243:     */     {
/*  244: 287 */       return parent_peer_info.getHwnd();
/*  245:     */     }
/*  246:     */     finally
/*  247:     */     {
/*  248: 289 */       parent_peer_info.unlock();
/*  249:     */     }
/*  250:     */   }
/*  251:     */   
/*  252:     */   public void destroyWindow()
/*  253:     */   {
/*  254: 294 */     nReleaseDC(this.hwnd, this.hdc);
/*  255: 295 */     nDestroyWindow(this.hwnd);
/*  256: 296 */     freeLargeIcon();
/*  257: 297 */     freeSmallIcon();
/*  258: 298 */     resetCursorClipping();
/*  259:     */   }
/*  260:     */   
/*  261:     */   static void resetCursorClipping()
/*  262:     */   {
/*  263: 303 */     if (cursor_clipped)
/*  264:     */     {
/*  265:     */       try
/*  266:     */       {
/*  267: 305 */         clipCursor(null);
/*  268:     */       }
/*  269:     */       catch (LWJGLException e)
/*  270:     */       {
/*  271: 307 */         LWJGLUtil.log("Failed to reset cursor clipping: " + e);
/*  272:     */       }
/*  273: 309 */       cursor_clipped = false;
/*  274:     */     }
/*  275:     */   }
/*  276:     */   
/*  277:     */   private static void getGlobalClientRect(long hwnd, Rect rect)
/*  278:     */   {
/*  279: 314 */     rect_buffer.put(0, 0).put(1, 0);
/*  280: 315 */     clientToScreen(hwnd, rect_buffer);
/*  281: 316 */     int offset_x = rect_buffer.get(0);
/*  282: 317 */     int offset_y = rect_buffer.get(1);
/*  283: 318 */     getClientRect(hwnd, rect_buffer);
/*  284: 319 */     rect.copyFromBuffer(rect_buffer);
/*  285: 320 */     rect.offset(offset_x, offset_y);
/*  286:     */   }
/*  287:     */   
/*  288:     */   static void setupCursorClipping(long hwnd)
/*  289:     */     throws LWJGLException
/*  290:     */   {
/*  291: 324 */     cursor_clipped = true;
/*  292: 325 */     getGlobalClientRect(hwnd, rect);
/*  293: 326 */     rect.copyToBuffer(rect_buffer);
/*  294: 327 */     clipCursor(rect_buffer);
/*  295:     */   }
/*  296:     */   
/*  297:     */   public void switchDisplayMode(DisplayMode mode)
/*  298:     */     throws LWJGLException
/*  299:     */   {
/*  300: 332 */     nSwitchDisplayMode(mode);
/*  301: 333 */     this.current_mode = mode;
/*  302: 334 */     this.mode_set = true;
/*  303:     */   }
/*  304:     */   
/*  305:     */   private void appActivate(boolean active)
/*  306:     */   {
/*  307: 342 */     if (this.inAppActivate) {
/*  308: 343 */       return;
/*  309:     */     }
/*  310: 345 */     this.inAppActivate = true;
/*  311: 346 */     this.isFocused = active;
/*  312: 347 */     if (active)
/*  313:     */     {
/*  314: 348 */       if (Display.isFullscreen()) {
/*  315: 349 */         restoreDisplayMode();
/*  316:     */       }
/*  317: 351 */       if (this.parent == null)
/*  318:     */       {
/*  319: 352 */         if (this.maximized) {
/*  320: 353 */           showWindow(getHwnd(), 3);
/*  321:     */         } else {
/*  322: 355 */           showWindow(getHwnd(), 9);
/*  323:     */         }
/*  324: 357 */         setForegroundWindow(getHwnd());
/*  325:     */       }
/*  326: 359 */       setFocus(getHwnd());
/*  327: 360 */       this.redoMakeContextCurrent = true;
/*  328: 361 */       if (Display.isFullscreen()) {
/*  329: 362 */         updateClipping();
/*  330:     */       }
/*  331: 364 */       if (this.keyboard != null) {
/*  332: 365 */         this.keyboard.fireLostKeyEvents();
/*  333:     */       }
/*  334:     */     }
/*  335: 366 */     else if (Display.isFullscreen())
/*  336:     */     {
/*  337: 367 */       showWindow(getHwnd(), 7);
/*  338: 368 */       resetDisplayMode();
/*  339:     */     }
/*  340:     */     else
/*  341:     */     {
/*  342: 370 */       updateClipping();
/*  343:     */     }
/*  344: 371 */     updateCursor();
/*  345: 372 */     this.inAppActivate = false;
/*  346:     */   }
/*  347:     */   
/*  348:     */   private void grabFocus()
/*  349:     */   {
/*  350: 379 */     if (this.parent == null) {
/*  351: 380 */       setFocus(getHwnd());
/*  352:     */     } else {
/*  353: 382 */       SwingUtilities.invokeLater(new Runnable()
/*  354:     */       {
/*  355:     */         public void run()
/*  356:     */         {
/*  357: 384 */           WindowsDisplay.this.parent.requestFocus();
/*  358:     */         }
/*  359:     */       });
/*  360:     */     }
/*  361:     */   }
/*  362:     */   
/*  363:     */   private void restoreDisplayMode()
/*  364:     */   {
/*  365:     */     try
/*  366:     */     {
/*  367: 391 */       doSetGammaRamp(this.current_gamma);
/*  368:     */     }
/*  369:     */     catch (LWJGLException e)
/*  370:     */     {
/*  371: 393 */       LWJGLUtil.log("Failed to restore gamma: " + e.getMessage());
/*  372:     */     }
/*  373: 396 */     if (!this.mode_set)
/*  374:     */     {
/*  375: 397 */       this.mode_set = true;
/*  376:     */       try
/*  377:     */       {
/*  378: 399 */         nSwitchDisplayMode(this.current_mode);
/*  379:     */       }
/*  380:     */       catch (LWJGLException e)
/*  381:     */       {
/*  382: 401 */         LWJGLUtil.log("Failed to restore display mode: " + e.getMessage());
/*  383:     */       }
/*  384:     */     }
/*  385:     */   }
/*  386:     */   
/*  387:     */   public void resetDisplayMode()
/*  388:     */   {
/*  389:     */     try
/*  390:     */     {
/*  391: 408 */       doSetGammaRamp(this.saved_gamma);
/*  392:     */     }
/*  393:     */     catch (LWJGLException e)
/*  394:     */     {
/*  395: 410 */       LWJGLUtil.log("Failed to reset gamma ramp: " + e.getMessage());
/*  396:     */     }
/*  397: 412 */     this.current_gamma = this.saved_gamma;
/*  398: 413 */     if (this.mode_set)
/*  399:     */     {
/*  400: 414 */       this.mode_set = false;
/*  401: 415 */       nResetDisplayMode();
/*  402:     */     }
/*  403: 417 */     resetCursorClipping();
/*  404:     */   }
/*  405:     */   
/*  406:     */   public int getGammaRampLength()
/*  407:     */   {
/*  408: 422 */     return 256;
/*  409:     */   }
/*  410:     */   
/*  411:     */   public void setGammaRamp(FloatBuffer gammaRamp)
/*  412:     */     throws LWJGLException
/*  413:     */   {
/*  414: 426 */     doSetGammaRamp(convertToNativeRamp(gammaRamp));
/*  415:     */   }
/*  416:     */   
/*  417:     */   private void doSetGammaRamp(ByteBuffer native_gamma)
/*  418:     */     throws LWJGLException
/*  419:     */   {
/*  420: 432 */     nSetGammaRamp(native_gamma);
/*  421: 433 */     this.current_gamma = native_gamma;
/*  422:     */   }
/*  423:     */   
/*  424:     */   public String getAdapter()
/*  425:     */   {
/*  426:     */     try
/*  427:     */     {
/*  428: 439 */       String maxObjNo = WindowsRegistry.queryRegistrationKey(3, "HARDWARE\\DeviceMap\\Video", "MaxObjectNumber");
/*  429:     */       
/*  430:     */ 
/*  431:     */ 
/*  432: 443 */       int maxObjectNumber = maxObjNo.charAt(0);
/*  433: 444 */       String vga_driver_value = "";
/*  434: 445 */       for (int i = 0; i < maxObjectNumber; i++)
/*  435:     */       {
/*  436: 446 */         String adapter_string = WindowsRegistry.queryRegistrationKey(3, "HARDWARE\\DeviceMap\\Video", "\\Device\\Video" + i);
/*  437:     */         
/*  438:     */ 
/*  439:     */ 
/*  440: 450 */         String root_key = "\\registry\\machine\\";
/*  441: 451 */         if (adapter_string.toLowerCase().startsWith(root_key))
/*  442:     */         {
/*  443: 452 */           String driver_value = WindowsRegistry.queryRegistrationKey(3, adapter_string.substring(root_key.length()), "InstalledDisplayDrivers");
/*  444: 456 */           if (driver_value.toUpperCase().startsWith("VGA")) {
/*  445: 457 */             vga_driver_value = driver_value;
/*  446: 458 */           } else if ((!driver_value.toUpperCase().startsWith("RDP")) && (!driver_value.toUpperCase().startsWith("NMNDD"))) {
/*  447: 459 */             return driver_value;
/*  448:     */           }
/*  449:     */         }
/*  450:     */       }
/*  451: 463 */       if (!vga_driver_value.equals("")) {
/*  452: 464 */         return vga_driver_value;
/*  453:     */       }
/*  454:     */     }
/*  455:     */     catch (LWJGLException e)
/*  456:     */     {
/*  457: 467 */       LWJGLUtil.log("Exception occurred while querying registry: " + e);
/*  458:     */     }
/*  459: 469 */     return null;
/*  460:     */   }
/*  461:     */   
/*  462:     */   public String getVersion()
/*  463:     */   {
/*  464: 473 */     String driver = getAdapter();
/*  465: 474 */     if (driver != null)
/*  466:     */     {
/*  467: 475 */       String[] drivers = driver.split(",");
/*  468: 476 */       if (drivers.length > 0)
/*  469:     */       {
/*  470: 477 */         WindowsFileVersion version = nGetVersion(drivers[0] + ".dll");
/*  471: 478 */         if (version != null) {
/*  472: 479 */           return version.toString();
/*  473:     */         }
/*  474:     */       }
/*  475:     */     }
/*  476: 482 */     return null;
/*  477:     */   }
/*  478:     */   
/*  479:     */   public DisplayMode init()
/*  480:     */     throws LWJGLException
/*  481:     */   {
/*  482: 487 */     this.current_gamma = (this.saved_gamma = getCurrentGammaRamp());
/*  483: 488 */     return this.current_mode = getCurrentDisplayMode();
/*  484:     */   }
/*  485:     */   
/*  486:     */   public void setTitle(String title)
/*  487:     */   {
/*  488: 493 */     ByteBuffer buffer = MemoryUtil.encodeUTF16(title);
/*  489: 494 */     nSetTitle(this.hwnd, MemoryUtil.getAddress0(buffer));
/*  490:     */   }
/*  491:     */   
/*  492:     */   public boolean isCloseRequested()
/*  493:     */   {
/*  494: 499 */     boolean saved = this.close_requested;
/*  495: 500 */     this.close_requested = false;
/*  496: 501 */     return saved;
/*  497:     */   }
/*  498:     */   
/*  499:     */   public boolean isVisible()
/*  500:     */   {
/*  501: 505 */     return !this.isMinimized;
/*  502:     */   }
/*  503:     */   
/*  504:     */   public boolean isActive()
/*  505:     */   {
/*  506: 509 */     return this.isFocused;
/*  507:     */   }
/*  508:     */   
/*  509:     */   public boolean isDirty()
/*  510:     */   {
/*  511: 513 */     boolean saved = this.is_dirty;
/*  512: 514 */     this.is_dirty = false;
/*  513: 515 */     return saved;
/*  514:     */   }
/*  515:     */   
/*  516:     */   public PeerInfo createPeerInfo(PixelFormat pixel_format, ContextAttribs attribs)
/*  517:     */     throws LWJGLException
/*  518:     */   {
/*  519: 519 */     this.peer_info = new WindowsDisplayPeerInfo(false);
/*  520: 520 */     return this.peer_info;
/*  521:     */   }
/*  522:     */   
/*  523:     */   public void update()
/*  524:     */   {
/*  525:     */     
/*  526: 526 */     if ((!this.isFocused) && (this.parent != null) && (this.parent.isFocusOwner()))
/*  527:     */     {
/*  528: 527 */       KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwner();
/*  529: 528 */       setFocus(getHwnd());
/*  530:     */     }
/*  531: 531 */     if (this.redoMakeContextCurrent)
/*  532:     */     {
/*  533: 532 */       this.redoMakeContextCurrent = false;
/*  534:     */       try
/*  535:     */       {
/*  536: 539 */         Context context = ((DrawableLWJGL)Display.getDrawable()).getContext();
/*  537: 540 */         if ((context != null) && (context.isCurrent())) {
/*  538: 541 */           context.makeCurrent();
/*  539:     */         }
/*  540:     */       }
/*  541:     */       catch (LWJGLException e)
/*  542:     */       {
/*  543: 543 */         LWJGLUtil.log("Exception occurred while trying to make context current: " + e);
/*  544:     */       }
/*  545:     */     }
/*  546:     */   }
/*  547:     */   
/*  548:     */   public void reshape(int x, int y, int width, int height)
/*  549:     */   {
/*  550: 550 */     nReshape(getHwnd(), x, y, width, height, (Display.isFullscreen()) || (isUndecorated()), this.parent != null);
/*  551:     */   }
/*  552:     */   
/*  553:     */   public boolean hasWheel()
/*  554:     */   {
/*  555: 557 */     return this.mouse.hasWheel();
/*  556:     */   }
/*  557:     */   
/*  558:     */   public int getButtonCount()
/*  559:     */   {
/*  560: 561 */     return this.mouse.getButtonCount();
/*  561:     */   }
/*  562:     */   
/*  563:     */   public void createMouse()
/*  564:     */     throws LWJGLException
/*  565:     */   {
/*  566: 565 */     this.mouse = new WindowsMouse(getHwnd());
/*  567:     */   }
/*  568:     */   
/*  569:     */   public void destroyMouse()
/*  570:     */   {
/*  571: 569 */     if (this.mouse != null) {
/*  572: 570 */       this.mouse.destroy();
/*  573:     */     }
/*  574: 571 */     this.mouse = null;
/*  575:     */   }
/*  576:     */   
/*  577:     */   public void pollMouse(IntBuffer coord_buffer, ByteBuffer buttons)
/*  578:     */   {
/*  579: 575 */     this.mouse.poll(coord_buffer, buttons);
/*  580:     */   }
/*  581:     */   
/*  582:     */   public void readMouse(ByteBuffer buffer)
/*  583:     */   {
/*  584: 579 */     this.mouse.read(buffer);
/*  585:     */   }
/*  586:     */   
/*  587:     */   public void grabMouse(boolean grab)
/*  588:     */   {
/*  589: 583 */     this.mouse.grab(grab, shouldGrab());
/*  590: 584 */     updateCursor();
/*  591:     */   }
/*  592:     */   
/*  593:     */   public int getNativeCursorCapabilities()
/*  594:     */   {
/*  595: 588 */     return 1;
/*  596:     */   }
/*  597:     */   
/*  598:     */   public void setCursorPosition(int x, int y)
/*  599:     */   {
/*  600: 592 */     getGlobalClientRect(getHwnd(), rect);
/*  601: 593 */     int transformed_x = rect.left + x;
/*  602: 594 */     int transformed_y = rect.bottom - 1 - y;
/*  603: 595 */     nSetCursorPosition(transformed_x, transformed_y);
/*  604: 596 */     setMousePosition(x, y);
/*  605:     */   }
/*  606:     */   
/*  607:     */   public void setNativeCursor(Object handle)
/*  608:     */     throws LWJGLException
/*  609:     */   {
/*  610: 601 */     this.current_cursor = handle;
/*  611: 602 */     updateCursor();
/*  612:     */   }
/*  613:     */   
/*  614:     */   private void updateCursor()
/*  615:     */   {
/*  616:     */     try
/*  617:     */     {
/*  618: 607 */       if ((this.mouse != null) && (shouldGrab())) {
/*  619: 608 */         nSetNativeCursor(getHwnd(), this.mouse.getBlankCursor());
/*  620:     */       } else {
/*  621: 610 */         nSetNativeCursor(getHwnd(), this.current_cursor);
/*  622:     */       }
/*  623:     */     }
/*  624:     */     catch (LWJGLException e)
/*  625:     */     {
/*  626: 612 */       LWJGLUtil.log("Failed to update cursor: " + e);
/*  627:     */     }
/*  628:     */   }
/*  629:     */   
/*  630:     */   public int getMinCursorSize()
/*  631:     */   {
/*  632: 618 */     return getSystemMetrics(13);
/*  633:     */   }
/*  634:     */   
/*  635:     */   public int getMaxCursorSize()
/*  636:     */   {
/*  637: 622 */     return getSystemMetrics(13);
/*  638:     */   }
/*  639:     */   
/*  640:     */   private long getHwnd()
/*  641:     */   {
/*  642: 630 */     return this.hwnd;
/*  643:     */   }
/*  644:     */   
/*  645:     */   private long getHdc()
/*  646:     */   {
/*  647: 634 */     return this.hdc;
/*  648:     */   }
/*  649:     */   
/*  650:     */   static void centerCursor(long hwnd)
/*  651:     */   {
/*  652: 642 */     if ((getForegroundWindow() != hwnd) && (!hasParent)) {
/*  653: 643 */       return;
/*  654:     */     }
/*  655: 644 */     getGlobalClientRect(hwnd, rect);
/*  656: 645 */     int local_offset_x = rect.left;
/*  657: 646 */     int local_offset_y = rect.top;
/*  658:     */     
/*  659:     */ 
/*  660:     */ 
/*  661:     */ 
/*  662: 651 */     int center_x = (rect.left + rect.right) / 2;
/*  663: 652 */     int center_y = (rect.top + rect.bottom) / 2;
/*  664: 653 */     nSetCursorPosition(center_x, center_y);
/*  665: 654 */     int local_x = center_x - local_offset_x;
/*  666: 655 */     int local_y = center_y - local_offset_y;
/*  667: 656 */     if (current_display != null) {
/*  668: 657 */       current_display.setMousePosition(local_x, transformY(hwnd, local_y));
/*  669:     */     }
/*  670:     */   }
/*  671:     */   
/*  672:     */   private void setMousePosition(int x, int y)
/*  673:     */   {
/*  674: 661 */     if (this.mouse != null) {
/*  675: 662 */       this.mouse.setPosition(x, y);
/*  676:     */     }
/*  677:     */   }
/*  678:     */   
/*  679:     */   public void createKeyboard()
/*  680:     */     throws LWJGLException
/*  681:     */   {
/*  682: 667 */     this.keyboard = new WindowsKeyboard(getHwnd());
/*  683:     */   }
/*  684:     */   
/*  685:     */   public void destroyKeyboard()
/*  686:     */   {
/*  687: 671 */     this.keyboard.destroy();
/*  688: 672 */     this.keyboard = null;
/*  689:     */   }
/*  690:     */   
/*  691:     */   public void pollKeyboard(ByteBuffer keyDownBuffer)
/*  692:     */   {
/*  693: 676 */     this.keyboard.poll(keyDownBuffer);
/*  694:     */   }
/*  695:     */   
/*  696:     */   public void readKeyboard(ByteBuffer buffer)
/*  697:     */   {
/*  698: 680 */     this.keyboard.read(buffer);
/*  699:     */   }
/*  700:     */   
/*  701:     */   public Object createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*  702:     */     throws LWJGLException
/*  703:     */   {
/*  704: 688 */     return doCreateCursor(width, height, xHotspot, yHotspot, numImages, images, delays);
/*  705:     */   }
/*  706:     */   
/*  707:     */   static Object doCreateCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*  708:     */     throws LWJGLException
/*  709:     */   {
/*  710: 692 */     return nCreateCursor(width, height, xHotspot, yHotspot, numImages, images, images.position(), delays, delays != null ? delays.position() : -1);
/*  711:     */   }
/*  712:     */   
/*  713:     */   public void destroyCursor(Object cursorHandle)
/*  714:     */   {
/*  715: 696 */     doDestroyCursor(cursorHandle);
/*  716:     */   }
/*  717:     */   
/*  718:     */   public int getPbufferCapabilities()
/*  719:     */   {
/*  720:     */     try
/*  721:     */     {
/*  722: 703 */       return nGetPbufferCapabilities(new PixelFormat(0, 0, 0, 0, 0, 0, 0, 0, false));
/*  723:     */     }
/*  724:     */     catch (LWJGLException e)
/*  725:     */     {
/*  726: 705 */       LWJGLUtil.log("Exception occurred while determining pbuffer capabilities: " + e);
/*  727:     */     }
/*  728: 706 */     return 0;
/*  729:     */   }
/*  730:     */   
/*  731:     */   public boolean isBufferLost(PeerInfo handle)
/*  732:     */   {
/*  733: 712 */     return ((WindowsPbufferPeerInfo)handle).isBufferLost();
/*  734:     */   }
/*  735:     */   
/*  736:     */   public PeerInfo createPbuffer(int width, int height, PixelFormat pixel_format, ContextAttribs attribs, IntBuffer pixelFormatCaps, IntBuffer pBufferAttribs)
/*  737:     */     throws LWJGLException
/*  738:     */   {
/*  739: 718 */     return new WindowsPbufferPeerInfo(width, height, pixel_format, pixelFormatCaps, pBufferAttribs);
/*  740:     */   }
/*  741:     */   
/*  742:     */   public void setPbufferAttrib(PeerInfo handle, int attrib, int value)
/*  743:     */   {
/*  744: 722 */     ((WindowsPbufferPeerInfo)handle).setPbufferAttrib(attrib, value);
/*  745:     */   }
/*  746:     */   
/*  747:     */   public void bindTexImageToPbuffer(PeerInfo handle, int buffer)
/*  748:     */   {
/*  749: 726 */     ((WindowsPbufferPeerInfo)handle).bindTexImageToPbuffer(buffer);
/*  750:     */   }
/*  751:     */   
/*  752:     */   public void releaseTexImageFromPbuffer(PeerInfo handle, int buffer)
/*  753:     */   {
/*  754: 730 */     ((WindowsPbufferPeerInfo)handle).releaseTexImageFromPbuffer(buffer);
/*  755:     */   }
/*  756:     */   
/*  757:     */   private void freeSmallIcon()
/*  758:     */   {
/*  759: 734 */     if (this.small_icon != 0L)
/*  760:     */     {
/*  761: 735 */       destroyIcon(this.small_icon);
/*  762: 736 */       this.small_icon = 0L;
/*  763:     */     }
/*  764:     */   }
/*  765:     */   
/*  766:     */   private void freeLargeIcon()
/*  767:     */   {
/*  768: 741 */     if (this.large_icon != 0L)
/*  769:     */     {
/*  770: 742 */       destroyIcon(this.large_icon);
/*  771: 743 */       this.large_icon = 0L;
/*  772:     */     }
/*  773:     */   }
/*  774:     */   
/*  775:     */   public int setIcon(ByteBuffer[] icons)
/*  776:     */   {
/*  777: 760 */     boolean done_small = false;
/*  778: 761 */     boolean done_large = false;
/*  779: 762 */     int used = 0;
/*  780:     */     
/*  781: 764 */     int small_icon_size = 16;
/*  782: 765 */     int large_icon_size = 32;
/*  783: 766 */     for (ByteBuffer icon : icons)
/*  784:     */     {
/*  785: 767 */       int size = icon.limit() / 4;
/*  786: 769 */       if (((int)Math.sqrt(size) == small_icon_size) && (!done_small))
/*  787:     */       {
/*  788: 770 */         long small_new_icon = createIcon(small_icon_size, small_icon_size, icon.asIntBuffer());
/*  789: 771 */         sendMessage(this.hwnd, 128L, 0L, small_new_icon);
/*  790: 772 */         freeSmallIcon();
/*  791: 773 */         this.small_icon = small_new_icon;
/*  792: 774 */         used++;
/*  793: 775 */         done_small = true;
/*  794:     */       }
/*  795: 777 */       if (((int)Math.sqrt(size) == large_icon_size) && (!done_large))
/*  796:     */       {
/*  797: 778 */         long large_new_icon = createIcon(large_icon_size, large_icon_size, icon.asIntBuffer());
/*  798: 779 */         sendMessage(this.hwnd, 128L, 1L, large_new_icon);
/*  799: 780 */         freeLargeIcon();
/*  800: 781 */         this.large_icon = large_new_icon;
/*  801: 782 */         used++;
/*  802: 783 */         done_large = true;
/*  803:     */         
/*  804:     */ 
/*  805:     */ 
/*  806:     */ 
/*  807:     */ 
/*  808: 789 */         this.iconsLoaded = false;
/*  809:     */         
/*  810:     */ 
/*  811: 792 */         long time = System.nanoTime();
/*  812: 793 */         long MAX_WAIT = 500000000L;
/*  813:     */         for (;;)
/*  814:     */         {
/*  815: 795 */           nUpdate();
/*  816: 796 */           if ((this.iconsLoaded) || (MAX_WAIT < System.nanoTime() - time)) {
/*  817:     */             break;
/*  818:     */           }
/*  819: 799 */           Thread.yield();
/*  820:     */         }
/*  821:     */       }
/*  822:     */     }
/*  823: 804 */     return used;
/*  824:     */   }
/*  825:     */   
/*  826:     */   private void handleMouseButton(int button, int state, long millis)
/*  827:     */   {
/*  828: 814 */     if (this.mouse != null)
/*  829:     */     {
/*  830: 815 */       this.mouse.handleMouseButton((byte)button, (byte)state, millis);
/*  831: 818 */       if ((this.captureMouse == -1) && (button != -1) && (state == 1))
/*  832:     */       {
/*  833: 819 */         this.captureMouse = button;
/*  834: 820 */         nSetCapture(this.hwnd);
/*  835:     */       }
/*  836: 824 */       if ((this.captureMouse != -1) && (button == this.captureMouse) && (state == 0))
/*  837:     */       {
/*  838: 825 */         this.captureMouse = -1;
/*  839: 826 */         nReleaseCapture();
/*  840:     */       }
/*  841:     */     }
/*  842:     */   }
/*  843:     */   
/*  844:     */   private boolean shouldGrab()
/*  845:     */   {
/*  846: 832 */     return (!this.isMinimized) && (this.isFocused) && (Mouse.isGrabbed());
/*  847:     */   }
/*  848:     */   
/*  849:     */   private void handleMouseMoved(int x, int y, long millis)
/*  850:     */   {
/*  851: 836 */     if (this.mouse != null) {
/*  852: 837 */       this.mouse.handleMouseMoved(x, y, millis, shouldGrab());
/*  853:     */     }
/*  854:     */   }
/*  855:     */   
/*  856:     */   private void handleMouseScrolled(int amount, long millis)
/*  857:     */   {
/*  858: 845 */     if (this.mouse != null) {
/*  859: 846 */       this.mouse.handleMouseScrolled(amount, millis);
/*  860:     */     }
/*  861:     */   }
/*  862:     */   
/*  863:     */   private void handleChar(long wParam, long lParam, long millis)
/*  864:     */   {
/*  865: 852 */     byte previous_state = (byte)(int)(lParam >>> 30 & 1L);
/*  866: 853 */     byte state = (byte)(int)(1L - (lParam >>> 31 & 1L));
/*  867: 854 */     boolean repeat = state == previous_state;
/*  868: 855 */     if (this.keyboard != null) {
/*  869: 856 */       this.keyboard.handleChar((int)(wParam & 0xFFFF), millis, repeat);
/*  870:     */     }
/*  871:     */   }
/*  872:     */   
/*  873:     */   private void handleKeyButton(long wParam, long lParam, long millis)
/*  874:     */   {
/*  875: 860 */     byte previous_state = (byte)(int)(lParam >>> 30 & 1L);
/*  876: 861 */     byte state = (byte)(int)(1L - (lParam >>> 31 & 1L));
/*  877: 862 */     boolean repeat = state == previous_state;
/*  878: 863 */     byte extended = (byte)(int)(lParam >>> 24 & 1L);
/*  879: 864 */     int scan_code = (int)(lParam >>> 16 & 0xFF);
/*  880: 865 */     if (this.keyboard != null) {
/*  881: 866 */       this.keyboard.handleKey((int)wParam, scan_code, extended != 0, state, millis, repeat);
/*  882:     */     }
/*  883:     */   }
/*  884:     */   
/*  885:     */   private static int transformY(long hwnd, int y)
/*  886:     */   {
/*  887: 871 */     getClientRect(hwnd, rect_buffer);
/*  888: 872 */     rect.copyFromBuffer(rect_buffer);
/*  889: 873 */     return rect.bottom - rect.top - 1 - y;
/*  890:     */   }
/*  891:     */   
/*  892:     */   private static long handleMessage(long hwnd, int msg, long wParam, long lParam, long millis)
/*  893:     */   {
/*  894: 881 */     if (current_display != null) {
/*  895: 882 */       return current_display.doHandleMessage(hwnd, msg, wParam, lParam, millis);
/*  896:     */     }
/*  897: 884 */     return defWindowProc(hwnd, msg, wParam, lParam);
/*  898:     */   }
/*  899:     */   
/*  900:     */   private void checkCursorState()
/*  901:     */   {
/*  902: 890 */     updateClipping();
/*  903:     */   }
/*  904:     */   
/*  905:     */   private void updateClipping()
/*  906:     */   {
/*  907: 894 */     if (((Display.isFullscreen()) || ((this.mouse != null) && (this.mouse.isGrabbed()))) && (!this.isMinimized) && (this.isFocused) && ((getForegroundWindow() == getHwnd()) || (hasParent))) {
/*  908:     */       try
/*  909:     */       {
/*  910: 896 */         setupCursorClipping(getHwnd());
/*  911:     */       }
/*  912:     */       catch (LWJGLException e)
/*  913:     */       {
/*  914: 898 */         LWJGLUtil.log("setupCursorClipping failed: " + e.getMessage());
/*  915:     */       }
/*  916:     */     } else {
/*  917: 901 */       resetCursorClipping();
/*  918:     */     }
/*  919:     */   }
/*  920:     */   
/*  921:     */   private void setMinimized(boolean m)
/*  922:     */   {
/*  923: 906 */     this.isMinimized = m;
/*  924: 907 */     checkCursorState();
/*  925:     */   }
/*  926:     */   
/*  927:     */   private long doHandleMessage(long hwnd, int msg, long wParam, long lParam, long millis)
/*  928:     */   {
/*  929: 920 */     switch (msg)
/*  930:     */     {
/*  931:     */     case 6: 
/*  932: 932 */       return 0L;
/*  933:     */     case 5: 
/*  934: 934 */       switch ((int)wParam)
/*  935:     */       {
/*  936:     */       case 0: 
/*  937:     */       case 2: 
/*  938: 937 */         this.maximized = ((int)wParam == 2);
/*  939: 938 */         this.resized = true;
/*  940: 939 */         updateWidthAndHeight();
/*  941: 940 */         setMinimized(false);
/*  942: 941 */         break;
/*  943:     */       case 1: 
/*  944: 943 */         setMinimized(true);
/*  945:     */       }
/*  946: 946 */       break;
/*  947:     */     case 532: 
/*  948: 948 */       this.resized = true;
/*  949: 949 */       updateWidthAndHeight();
/*  950: 950 */       break;
/*  951:     */     case 32: 
/*  952: 952 */       if ((lParam & 0xFFFF) == 1L)
/*  953:     */       {
/*  954: 955 */         updateCursor();
/*  955: 956 */         return -1L;
/*  956:     */       }
/*  957: 959 */       return defWindowProc(hwnd, msg, wParam, lParam);
/*  958:     */     case 8: 
/*  959: 962 */       appActivate(false);
/*  960: 963 */       return 0L;
/*  961:     */     case 7: 
/*  962: 965 */       appActivate(true);
/*  963: 966 */       return 0L;
/*  964:     */     case 33: 
/*  965: 968 */       if (!this.isFocused) {
/*  966: 969 */         grabFocus();
/*  967:     */       }
/*  968: 971 */       return 3L;
/*  969:     */     case 512: 
/*  970: 973 */       int xPos = (short)(int)(lParam & 0xFFFF);
/*  971: 974 */       int yPos = transformY(getHwnd(), (short)(int)(lParam >> 16 & 0xFFFF));
/*  972: 975 */       handleMouseMoved(xPos, yPos, millis);
/*  973: 976 */       checkCursorState();
/*  974: 977 */       this.mouseInside = true;
/*  975: 978 */       if (!this.trackingMouse) {
/*  976: 979 */         this.trackingMouse = nTrackMouseEvent(hwnd);
/*  977:     */       }
/*  978: 981 */       return 0L;
/*  979:     */     case 522: 
/*  980: 983 */       int dwheel = (short)(int)(wParam >> 16 & 0xFFFF);
/*  981: 984 */       handleMouseScrolled(dwheel, millis);
/*  982: 985 */       return 0L;
/*  983:     */     case 513: 
/*  984: 987 */       handleMouseButton(0, 1, millis);
/*  985: 988 */       return 0L;
/*  986:     */     case 514: 
/*  987: 990 */       handleMouseButton(0, 0, millis);
/*  988: 991 */       return 0L;
/*  989:     */     case 516: 
/*  990: 993 */       handleMouseButton(1, 1, millis);
/*  991: 994 */       return 0L;
/*  992:     */     case 517: 
/*  993: 996 */       handleMouseButton(1, 0, millis);
/*  994: 997 */       return 0L;
/*  995:     */     case 519: 
/*  996: 999 */       handleMouseButton(2, 1, millis);
/*  997:1000 */       return 0L;
/*  998:     */     case 520: 
/*  999:1002 */       handleMouseButton(2, 0, millis);
/* 1000:1003 */       return 0L;
/* 1001:     */     case 524: 
/* 1002:1005 */       if (wParam >> 16 == 1L) {
/* 1003:1006 */         handleMouseButton(3, 0, millis);
/* 1004:     */       } else {
/* 1005:1008 */         handleMouseButton(4, 0, millis);
/* 1006:     */       }
/* 1007:1010 */       return 1L;
/* 1008:     */     case 523: 
/* 1009:1012 */       if ((wParam & 0xFF) == 32L) {
/* 1010:1013 */         handleMouseButton(3, 1, millis);
/* 1011:     */       } else {
/* 1012:1015 */         handleMouseButton(4, 1, millis);
/* 1013:     */       }
/* 1014:1017 */       return 1L;
/* 1015:     */     case 258: 
/* 1016:     */     case 262: 
/* 1017:1020 */       handleChar(wParam, lParam, millis);
/* 1018:1021 */       return 0L;
/* 1019:     */     case 257: 
/* 1020:     */     case 261: 
/* 1021:1026 */       if ((wParam == 44L) && (this.keyboard != null) && (!this.keyboard.isKeyDown(183)))
/* 1022:     */       {
/* 1023:1029 */         long fake_lparam = lParam & 0x7FFFFFFF;
/* 1024:     */         
/* 1025:1031 */         fake_lparam &= 0xBFFFFFFF;
/* 1026:1032 */         handleKeyButton(wParam, fake_lparam, millis);
/* 1027:     */       }
/* 1028:     */     case 256: 
/* 1029:     */     case 260: 
/* 1030:1038 */       handleKeyButton(wParam, lParam, millis);
/* 1031:1039 */       break;
/* 1032:     */     case 18: 
/* 1033:1041 */       this.close_requested = true;
/* 1034:1042 */       return 0L;
/* 1035:     */     case 274: 
/* 1036:1044 */       switch ((int)(wParam & 0xFFF0))
/* 1037:     */       {
/* 1038:     */       case 61584: 
/* 1039:     */       case 61696: 
/* 1040:     */       case 61760: 
/* 1041:     */       case 61808: 
/* 1042:1049 */         return 0L;
/* 1043:     */       case 61536: 
/* 1044:1051 */         this.close_requested = true;
/* 1045:1052 */         return 0L;
/* 1046:     */       }
/* 1047:1054 */       break;
/* 1048:     */     case 15: 
/* 1049:1058 */       this.is_dirty = true;
/* 1050:1059 */       break;
/* 1051:     */     case 675: 
/* 1052:1061 */       this.mouseInside = false;
/* 1053:1062 */       this.trackingMouse = false;
/* 1054:1063 */       break;
/* 1055:     */     case 31: 
/* 1056:1065 */       nReleaseCapture();
/* 1057:     */     case 533: 
/* 1058:1068 */       if (this.captureMouse != -1)
/* 1059:     */       {
/* 1060:1069 */         handleMouseButton(this.captureMouse, 0, millis);
/* 1061:1070 */         this.captureMouse = -1;
/* 1062:     */       }
/* 1063:1072 */       return 0L;
/* 1064:     */     case 71: 
/* 1065:1074 */       if (getWindowRect(hwnd, rect_buffer))
/* 1066:     */       {
/* 1067:1075 */         rect.copyFromBuffer(rect_buffer);
/* 1068:1076 */         this.x = rect.top;
/* 1069:1077 */         this.y = rect.bottom;
/* 1070:     */       }
/* 1071:     */       else
/* 1072:     */       {
/* 1073:1079 */         LWJGLUtil.log("WM_WINDOWPOSCHANGED: Unable to get window rect");
/* 1074:     */       }
/* 1075:1081 */       break;
/* 1076:     */     case 127: 
/* 1077:1083 */       this.iconsLoaded = true;
/* 1078:     */     }
/* 1079:1087 */     return defWindowProc(hwnd, msg, wParam, lParam);
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   public int getX()
/* 1083:     */   {
/* 1084:1093 */     return this.x;
/* 1085:     */   }
/* 1086:     */   
/* 1087:     */   public int getY()
/* 1088:     */   {
/* 1089:1097 */     return this.y;
/* 1090:     */   }
/* 1091:     */   
/* 1092:     */   public int getWidth()
/* 1093:     */   {
/* 1094:1101 */     return this.width;
/* 1095:     */   }
/* 1096:     */   
/* 1097:     */   public int getHeight()
/* 1098:     */   {
/* 1099:1105 */     return this.height;
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public boolean isInsideWindow()
/* 1103:     */   {
/* 1104:1111 */     return this.mouseInside;
/* 1105:     */   }
/* 1106:     */   
/* 1107:     */   public void setResizable(boolean resizable)
/* 1108:     */   {
/* 1109:1115 */     if (this.resizable != resizable)
/* 1110:     */     {
/* 1111:1116 */       int style = (int)getWindowLongPtr(this.hwnd, -16);
/* 1112:1117 */       int styleex = (int)getWindowLongPtr(this.hwnd, -20);
/* 1113:1120 */       if ((resizable) && (!Display.isFullscreen())) {
/* 1114:1121 */         setWindowLongPtr(this.hwnd, -16, style |= 0x50000);
/* 1115:     */       } else {
/* 1116:1123 */         setWindowLongPtr(this.hwnd, -16, style &= 0xFFFAFFFF);
/* 1117:     */       }
/* 1118:1128 */       getClientRect(this.hwnd, rect_buffer);
/* 1119:1129 */       rect.copyFromBuffer(rect_buffer);
/* 1120:1130 */       adjustWindowRectEx(rect_buffer, style, false, styleex);
/* 1121:1131 */       rect.copyFromBuffer(rect_buffer);
/* 1122:     */       
/* 1123:     */ 
/* 1124:1134 */       setWindowPos(this.hwnd, 0L, 0, 0, rect.right - rect.left, rect.bottom - rect.top, 38L);
/* 1125:     */       
/* 1126:1136 */       updateWidthAndHeight();
/* 1127:1137 */       this.resized = false;
/* 1128:     */     }
/* 1129:1139 */     this.resizable = resizable;
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   public boolean wasResized()
/* 1133:     */   {
/* 1134:1145 */     if (this.resized)
/* 1135:     */     {
/* 1136:1146 */       this.resized = false;
/* 1137:1147 */       return true;
/* 1138:     */     }
/* 1139:1149 */     return false;
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   private static native long nCreateWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, long paramLong)
/* 1143:     */     throws LWJGLException;
/* 1144:     */   
/* 1145:     */   private static native void nReleaseDC(long paramLong1, long paramLong2);
/* 1146:     */   
/* 1147:     */   private static native void nDestroyWindow(long paramLong);
/* 1148:     */   
/* 1149:     */   private static native void clipCursor(IntBuffer paramIntBuffer)
/* 1150:     */     throws LWJGLException;
/* 1151:     */   
/* 1152:     */   private static native void nSwitchDisplayMode(DisplayMode paramDisplayMode)
/* 1153:     */     throws LWJGLException;
/* 1154:     */   
/* 1155:     */   private static native void showWindow(long paramLong, int paramInt);
/* 1156:     */   
/* 1157:     */   private static native void setForegroundWindow(long paramLong);
/* 1158:     */   
/* 1159:     */   private static native void setFocus(long paramLong);
/* 1160:     */   
/* 1161:     */   private static native void nResetDisplayMode();
/* 1162:     */   
/* 1163:     */   private static native ByteBuffer convertToNativeRamp(FloatBuffer paramFloatBuffer)
/* 1164:     */     throws LWJGLException;
/* 1165:     */   
/* 1166:     */   private static native ByteBuffer getCurrentGammaRamp()
/* 1167:     */     throws LWJGLException;
/* 1168:     */   
/* 1169:     */   private static native void nSetGammaRamp(ByteBuffer paramByteBuffer)
/* 1170:     */     throws LWJGLException;
/* 1171:     */   
/* 1172:     */   private native WindowsFileVersion nGetVersion(String paramString);
/* 1173:     */   
/* 1174:     */   private static native DisplayMode getCurrentDisplayMode()
/* 1175:     */     throws LWJGLException;
/* 1176:     */   
/* 1177:     */   private static native void nSetTitle(long paramLong1, long paramLong2);
/* 1178:     */   
/* 1179:     */   private static native void nUpdate();
/* 1180:     */   
/* 1181:     */   private static native void nReshape(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2);
/* 1182:     */   
/* 1183:     */   public native DisplayMode[] getAvailableDisplayModes()
/* 1184:     */     throws LWJGLException;
/* 1185:     */   
/* 1186:     */   private static native void nSetCursorPosition(int paramInt1, int paramInt2);
/* 1187:     */   
/* 1188:     */   static native void nSetNativeCursor(long paramLong, Object paramObject)
/* 1189:     */     throws LWJGLException;
/* 1190:     */   
/* 1191:     */   static native int getSystemMetrics(int paramInt);
/* 1192:     */   
/* 1193:     */   private static native long getDllInstance();
/* 1194:     */   
/* 1195:     */   private static native long getDC(long paramLong);
/* 1196:     */   
/* 1197:     */   private static native long getDesktopWindow();
/* 1198:     */   
/* 1199:     */   private static native long getForegroundWindow();
/* 1200:     */   
/* 1201:     */   public static native ByteBuffer nCreateCursor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, IntBuffer paramIntBuffer1, int paramInt6, IntBuffer paramIntBuffer2, int paramInt7)
/* 1202:     */     throws LWJGLException;
/* 1203:     */   
/* 1204:     */   static native void doDestroyCursor(Object paramObject);
/* 1205:     */   
/* 1206:     */   private native int nGetPbufferCapabilities(PixelFormat paramPixelFormat)
/* 1207:     */     throws LWJGLException;
/* 1208:     */   
/* 1209:     */   private static native long createIcon(int paramInt1, int paramInt2, IntBuffer paramIntBuffer);
/* 1210:     */   
/* 1211:     */   private static native void destroyIcon(long paramLong);
/* 1212:     */   
/* 1213:     */   private static native long sendMessage(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 1214:     */   
/* 1215:     */   private static native long setWindowLongPtr(long paramLong1, int paramInt, long paramLong2);
/* 1216:     */   
/* 1217:     */   private static native long getWindowLongPtr(long paramLong, int paramInt);
/* 1218:     */   
/* 1219:     */   private static native boolean setWindowPos(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong3);
/* 1220:     */   
/* 1221:     */   private static native long nSetCapture(long paramLong);
/* 1222:     */   
/* 1223:     */   private static native boolean nReleaseCapture();
/* 1224:     */   
/* 1225:     */   private static native void getClientRect(long paramLong, IntBuffer paramIntBuffer);
/* 1226:     */   
/* 1227:     */   private static native void clientToScreen(long paramLong, IntBuffer paramIntBuffer);
/* 1228:     */   
/* 1229:     */   private static native void setWindowProc(Method paramMethod);
/* 1230:     */   
/* 1231:     */   private static native long defWindowProc(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/* 1232:     */   
/* 1233:     */   private native boolean getWindowRect(long paramLong, IntBuffer paramIntBuffer);
/* 1234:     */   
/* 1235:     */   private native boolean nTrackMouseEvent(long paramLong);
/* 1236:     */   
/* 1237:     */   private native boolean adjustWindowRectEx(IntBuffer paramIntBuffer, int paramInt1, boolean paramBoolean, int paramInt2);
/* 1238:     */   
/* 1239:     */   private static final class Rect
/* 1240:     */   {
/* 1241:     */     public int top;
/* 1242:     */     public int bottom;
/* 1243:     */     public int left;
/* 1244:     */     public int right;
/* 1245:     */     
/* 1246:     */     public void copyToBuffer(IntBuffer buffer)
/* 1247:     */     {
/* 1248:1159 */       buffer.put(0, this.top).put(1, this.bottom).put(2, this.left).put(3, this.right);
/* 1249:     */     }
/* 1250:     */     
/* 1251:     */     public void copyFromBuffer(IntBuffer buffer)
/* 1252:     */     {
/* 1253:1163 */       this.top = buffer.get(0);
/* 1254:1164 */       this.bottom = buffer.get(1);
/* 1255:1165 */       this.left = buffer.get(2);
/* 1256:1166 */       this.right = buffer.get(3);
/* 1257:     */     }
/* 1258:     */     
/* 1259:     */     public void offset(int offset_x, int offset_y)
/* 1260:     */     {
/* 1261:1170 */       this.left += offset_x;
/* 1262:1171 */       this.right += offset_x;
/* 1263:1172 */       this.top += offset_y;
/* 1264:1173 */       this.bottom += offset_y;
/* 1265:     */     }
/* 1266:     */     
/* 1267:     */     public static void intersect(Rect r1, Rect r2, Rect dst)
/* 1268:     */     {
/* 1269:1177 */       dst.top = Math.max(r1.top, r2.top);
/* 1270:1178 */       dst.bottom = Math.min(r1.bottom, r2.bottom);
/* 1271:1179 */       dst.left = Math.max(r1.left, r2.left);
/* 1272:1180 */       dst.right = Math.min(r1.right, r2.right);
/* 1273:     */     }
/* 1274:     */     
/* 1275:     */     public String toString()
/* 1276:     */     {
/* 1277:1184 */       return "Rect: top = " + this.top + " bottom = " + this.bottom + " left = " + this.left + " right = " + this.right + ", width: " + (this.right - this.left) + ", height: " + (this.bottom - this.top);
/* 1278:     */     }
/* 1279:     */   }
/* 1280:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsDisplay
 * JD-Core Version:    0.7.0.1
 */