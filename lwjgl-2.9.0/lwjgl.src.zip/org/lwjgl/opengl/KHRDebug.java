/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.PointerWrapper;
/*   6:    */ 
/*   7:    */ public final class KHRDebug
/*   8:    */ {
/*   9:    */   public static final int GL_DEBUG_OUTPUT = 37600;
/*  10:    */   public static final int GL_DEBUG_OUTPUT_SYNCHRONOUS = 33346;
/*  11:    */   public static final int GL_CONTEXT_FLAG_DEBUG_BIT = 2;
/*  12:    */   public static final int GL_MAX_DEBUG_MESSAGE_LENGTH = 37187;
/*  13:    */   public static final int GL_MAX_DEBUG_LOGGED_MESSAGES = 37188;
/*  14:    */   public static final int GL_DEBUG_LOGGED_MESSAGES = 37189;
/*  15:    */   public static final int GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH = 33347;
/*  16:    */   public static final int GL_MAX_DEBUG_GROUP_STACK_DEPTH = 33388;
/*  17:    */   public static final int GL_DEBUG_GROUP_STACK_DEPTH = 33389;
/*  18:    */   public static final int GL_MAX_LABEL_LENGTH = 33512;
/*  19:    */   public static final int GL_DEBUG_CALLBACK_FUNCTION = 33348;
/*  20:    */   public static final int GL_DEBUG_CALLBACK_USER_PARAM = 33349;
/*  21:    */   public static final int GL_DEBUG_SOURCE_API = 33350;
/*  22:    */   public static final int GL_DEBUG_SOURCE_WINDOW_SYSTEM = 33351;
/*  23:    */   public static final int GL_DEBUG_SOURCE_SHADER_COMPILER = 33352;
/*  24:    */   public static final int GL_DEBUG_SOURCE_THIRD_PARTY = 33353;
/*  25:    */   public static final int GL_DEBUG_SOURCE_APPLICATION = 33354;
/*  26:    */   public static final int GL_DEBUG_SOURCE_OTHER = 33355;
/*  27:    */   public static final int GL_DEBUG_TYPE_ERROR = 33356;
/*  28:    */   public static final int GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR = 33357;
/*  29:    */   public static final int GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR = 33358;
/*  30:    */   public static final int GL_DEBUG_TYPE_PORTABILITY = 33359;
/*  31:    */   public static final int GL_DEBUG_TYPE_PERFORMANCE = 33360;
/*  32:    */   public static final int GL_DEBUG_TYPE_OTHER = 33361;
/*  33:    */   public static final int GL_DEBUG_TYPE_MARKER = 33384;
/*  34:    */   public static final int GL_DEBUG_TYPE_PUSH_GROUP = 33385;
/*  35:    */   public static final int GL_DEBUG_TYPE_POP_GROUP = 33386;
/*  36:    */   public static final int GL_DEBUG_SEVERITY_HIGH = 37190;
/*  37:    */   public static final int GL_DEBUG_SEVERITY_MEDIUM = 37191;
/*  38:    */   public static final int GL_DEBUG_SEVERITY_LOW = 37192;
/*  39:    */   public static final int GL_DEBUG_SEVERITY_NOTIFICATION = 33387;
/*  40:    */   public static final int GL_STACK_UNDERFLOW = 1284;
/*  41:    */   public static final int GL_STACK_OVERFLOW = 1283;
/*  42:    */   public static final int GL_BUFFER = 33504;
/*  43:    */   public static final int GL_SHADER = 33505;
/*  44:    */   public static final int GL_PROGRAM = 33506;
/*  45:    */   public static final int GL_QUERY = 33507;
/*  46:    */   public static final int GL_PROGRAM_PIPELINE = 33508;
/*  47:    */   public static final int GL_SAMPLER = 33510;
/*  48:    */   public static final int GL_DISPLAY_LIST = 33511;
/*  49:    */   
/*  50:    */   public static void glDebugMessageControl(int source, int type, int severity, IntBuffer ids, boolean enabled)
/*  51:    */   {
/*  52:104 */     GL43.glDebugMessageControl(source, type, severity, ids, enabled);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void glDebugMessageInsert(int source, int type, int id, int severity, ByteBuffer buf)
/*  56:    */   {
/*  57:108 */     GL43.glDebugMessageInsert(source, type, id, severity, buf);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static void glDebugMessageInsert(int source, int type, int id, int severity, CharSequence buf)
/*  61:    */   {
/*  62:113 */     GL43.glDebugMessageInsert(source, type, id, severity, buf);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glDebugMessageCallback(KHRDebugCallback callback)
/*  66:    */   {
/*  67:124 */     GL43.glDebugMessageCallback(callback);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static int glGetDebugMessageLog(int count, IntBuffer sources, IntBuffer types, IntBuffer ids, IntBuffer severities, IntBuffer lengths, ByteBuffer messageLog)
/*  71:    */   {
/*  72:128 */     return GL43.glGetDebugMessageLog(count, sources, types, ids, severities, lengths, messageLog);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void glPushDebugGroup(int source, int id, ByteBuffer message)
/*  76:    */   {
/*  77:132 */     GL43.glPushDebugGroup(source, id, message);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static void glPushDebugGroup(int source, int id, CharSequence message)
/*  81:    */   {
/*  82:137 */     GL43.glPushDebugGroup(source, id, message);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void glPopDebugGroup() {}
/*  86:    */   
/*  87:    */   public static void glObjectLabel(int identifier, int name, ByteBuffer label)
/*  88:    */   {
/*  89:145 */     GL43.glObjectLabel(identifier, name, label);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static void glObjectLabel(int identifier, int name, CharSequence label)
/*  93:    */   {
/*  94:150 */     GL43.glObjectLabel(identifier, name, label);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static void glGetObjectLabel(int identifier, int name, IntBuffer length, ByteBuffer label)
/*  98:    */   {
/*  99:154 */     GL43.glGetObjectLabel(identifier, name, length, label);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static String glGetObjectLabel(int identifier, int name, int bufSize)
/* 103:    */   {
/* 104:159 */     return GL43.glGetObjectLabel(identifier, name, bufSize);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static void glObjectPtrLabel(PointerWrapper ptr, ByteBuffer label)
/* 108:    */   {
/* 109:163 */     GL43.glObjectPtrLabel(ptr, label);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void glObjectPtrLabel(PointerWrapper ptr, CharSequence label)
/* 113:    */   {
/* 114:168 */     GL43.glObjectPtrLabel(ptr, label);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static void glGetObjectPtrLabel(PointerWrapper ptr, IntBuffer length, ByteBuffer label)
/* 118:    */   {
/* 119:172 */     GL43.glGetObjectPtrLabel(ptr, length, label);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static String glGetObjectPtrLabel(PointerWrapper ptr, int bufSize)
/* 123:    */   {
/* 124:177 */     return GL43.glGetObjectPtrLabel(ptr, bufSize);
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.KHRDebug
 * JD-Core Version:    0.7.0.1
 */