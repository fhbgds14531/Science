/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class NVRegisterCombiners
/*   9:    */ {
/*  10:    */   public static final int GL_REGISTER_COMBINERS_NV = 34082;
/*  11:    */   public static final int GL_COMBINER0_NV = 34128;
/*  12:    */   public static final int GL_COMBINER1_NV = 34129;
/*  13:    */   public static final int GL_COMBINER2_NV = 34130;
/*  14:    */   public static final int GL_COMBINER3_NV = 34131;
/*  15:    */   public static final int GL_COMBINER4_NV = 34132;
/*  16:    */   public static final int GL_COMBINER5_NV = 34133;
/*  17:    */   public static final int GL_COMBINER6_NV = 34134;
/*  18:    */   public static final int GL_COMBINER7_NV = 34135;
/*  19:    */   public static final int GL_VARIABLE_A_NV = 34083;
/*  20:    */   public static final int GL_VARIABLE_B_NV = 34084;
/*  21:    */   public static final int GL_VARIABLE_C_NV = 34085;
/*  22:    */   public static final int GL_VARIABLE_D_NV = 34086;
/*  23:    */   public static final int GL_VARIABLE_E_NV = 34087;
/*  24:    */   public static final int GL_VARIABLE_F_NV = 34088;
/*  25:    */   public static final int GL_VARIABLE_G_NV = 34089;
/*  26:    */   public static final int GL_CONSTANT_COLOR0_NV = 34090;
/*  27:    */   public static final int GL_CONSTANT_COLOR1_NV = 34091;
/*  28:    */   public static final int GL_PRIMARY_COLOR_NV = 34092;
/*  29:    */   public static final int GL_SECONDARY_COLOR_NV = 34093;
/*  30:    */   public static final int GL_SPARE0_NV = 34094;
/*  31:    */   public static final int GL_SPARE1_NV = 34095;
/*  32:    */   public static final int GL_UNSIGNED_IDENTITY_NV = 34102;
/*  33:    */   public static final int GL_UNSIGNED_INVERT_NV = 34103;
/*  34:    */   public static final int GL_EXPAND_NORMAL_NV = 34104;
/*  35:    */   public static final int GL_EXPAND_NEGATE_NV = 34105;
/*  36:    */   public static final int GL_HALF_BIAS_NORMAL_NV = 34106;
/*  37:    */   public static final int GL_HALF_BIAS_NEGATE_NV = 34107;
/*  38:    */   public static final int GL_SIGNED_IDENTITY_NV = 34108;
/*  39:    */   public static final int GL_SIGNED_NEGATE_NV = 34109;
/*  40:    */   public static final int GL_E_TIMES_F_NV = 34097;
/*  41:    */   public static final int GL_SPARE0_PLUS_SECONDARY_COLOR_NV = 34098;
/*  42:    */   public static final int GL_SCALE_BY_TWO_NV = 34110;
/*  43:    */   public static final int GL_SCALE_BY_FOUR_NV = 34111;
/*  44:    */   public static final int GL_SCALE_BY_ONE_HALF_NV = 34112;
/*  45:    */   public static final int GL_BIAS_BY_NEGATIVE_ONE_HALF_NV = 34113;
/*  46:    */   public static final int GL_DISCARD_NV = 34096;
/*  47:    */   public static final int GL_COMBINER_INPUT_NV = 34114;
/*  48:    */   public static final int GL_COMBINER_MAPPING_NV = 34115;
/*  49:    */   public static final int GL_COMBINER_COMPONENT_USAGE_NV = 34116;
/*  50:    */   public static final int GL_COMBINER_AB_DOT_PRODUCT_NV = 34117;
/*  51:    */   public static final int GL_COMBINER_CD_DOT_PRODUCT_NV = 34118;
/*  52:    */   public static final int GL_COMBINER_MUX_SUM_NV = 34119;
/*  53:    */   public static final int GL_COMBINER_SCALE_NV = 34120;
/*  54:    */   public static final int GL_COMBINER_BIAS_NV = 34121;
/*  55:    */   public static final int GL_COMBINER_AB_OUTPUT_NV = 34122;
/*  56:    */   public static final int GL_COMBINER_CD_OUTPUT_NV = 34123;
/*  57:    */   public static final int GL_COMBINER_SUM_OUTPUT_NV = 34124;
/*  58:    */   public static final int GL_NUM_GENERAL_COMBINERS_NV = 34126;
/*  59:    */   public static final int GL_COLOR_SUM_CLAMP_NV = 34127;
/*  60:    */   public static final int GL_MAX_GENERAL_COMBINERS_NV = 34125;
/*  61:    */   
/*  62:    */   public static void glCombinerParameterfNV(int pname, float param)
/*  63:    */   {
/*  64: 65 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  65: 66 */     long function_pointer = caps.glCombinerParameterfNV;
/*  66: 67 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  67: 68 */     nglCombinerParameterfNV(pname, param, function_pointer);
/*  68:    */   }
/*  69:    */   
/*  70:    */   static native void nglCombinerParameterfNV(int paramInt, float paramFloat, long paramLong);
/*  71:    */   
/*  72:    */   public static void glCombinerParameterNV(int pname, FloatBuffer params)
/*  73:    */   {
/*  74: 73 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  75: 74 */     long function_pointer = caps.glCombinerParameterfvNV;
/*  76: 75 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  77: 76 */     BufferChecks.checkBuffer(params, 4);
/*  78: 77 */     nglCombinerParameterfvNV(pname, MemoryUtil.getAddress(params), function_pointer);
/*  79:    */   }
/*  80:    */   
/*  81:    */   static native void nglCombinerParameterfvNV(int paramInt, long paramLong1, long paramLong2);
/*  82:    */   
/*  83:    */   public static void glCombinerParameteriNV(int pname, int param)
/*  84:    */   {
/*  85: 82 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  86: 83 */     long function_pointer = caps.glCombinerParameteriNV;
/*  87: 84 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  88: 85 */     nglCombinerParameteriNV(pname, param, function_pointer);
/*  89:    */   }
/*  90:    */   
/*  91:    */   static native void nglCombinerParameteriNV(int paramInt1, int paramInt2, long paramLong);
/*  92:    */   
/*  93:    */   public static void glCombinerParameterNV(int pname, IntBuffer params)
/*  94:    */   {
/*  95: 90 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  96: 91 */     long function_pointer = caps.glCombinerParameterivNV;
/*  97: 92 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  98: 93 */     BufferChecks.checkBuffer(params, 4);
/*  99: 94 */     nglCombinerParameterivNV(pname, MemoryUtil.getAddress(params), function_pointer);
/* 100:    */   }
/* 101:    */   
/* 102:    */   static native void nglCombinerParameterivNV(int paramInt, long paramLong1, long paramLong2);
/* 103:    */   
/* 104:    */   public static void glCombinerInputNV(int stage, int portion, int variable, int input, int mapping, int componentUsage)
/* 105:    */   {
/* 106: 99 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 107:100 */     long function_pointer = caps.glCombinerInputNV;
/* 108:101 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 109:102 */     nglCombinerInputNV(stage, portion, variable, input, mapping, componentUsage, function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   static native void nglCombinerInputNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 113:    */   
/* 114:    */   public static void glCombinerOutputNV(int stage, int portion, int abOutput, int cdOutput, int sumOutput, int scale, int bias, boolean abDotProduct, boolean cdDotProduct, boolean muxSum)
/* 115:    */   {
/* 116:107 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 117:108 */     long function_pointer = caps.glCombinerOutputNV;
/* 118:109 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 119:110 */     nglCombinerOutputNV(stage, portion, abOutput, cdOutput, sumOutput, scale, bias, abDotProduct, cdDotProduct, muxSum, function_pointer);
/* 120:    */   }
/* 121:    */   
/* 122:    */   static native void nglCombinerOutputNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, long paramLong);
/* 123:    */   
/* 124:    */   public static void glFinalCombinerInputNV(int variable, int input, int mapping, int componentUsage)
/* 125:    */   {
/* 126:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:116 */     long function_pointer = caps.glFinalCombinerInputNV;
/* 128:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:118 */     nglFinalCombinerInputNV(variable, input, mapping, componentUsage, function_pointer);
/* 130:    */   }
/* 131:    */   
/* 132:    */   static native void nglFinalCombinerInputNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 133:    */   
/* 134:    */   public static void glGetCombinerInputParameterNV(int stage, int portion, int variable, int pname, FloatBuffer params)
/* 135:    */   {
/* 136:123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 137:124 */     long function_pointer = caps.glGetCombinerInputParameterfvNV;
/* 138:125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 139:126 */     BufferChecks.checkBuffer(params, 4);
/* 140:127 */     nglGetCombinerInputParameterfvNV(stage, portion, variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 141:    */   }
/* 142:    */   
/* 143:    */   static native void nglGetCombinerInputParameterfvNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 144:    */   
/* 145:    */   public static float glGetCombinerInputParameterfNV(int stage, int portion, int variable, int pname)
/* 146:    */   {
/* 147:133 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 148:134 */     long function_pointer = caps.glGetCombinerInputParameterfvNV;
/* 149:135 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 150:136 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 151:137 */     nglGetCombinerInputParameterfvNV(stage, portion, variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 152:138 */     return params.get(0);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public static void glGetCombinerInputParameterNV(int stage, int portion, int variable, int pname, IntBuffer params)
/* 156:    */   {
/* 157:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 158:143 */     long function_pointer = caps.glGetCombinerInputParameterivNV;
/* 159:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 160:145 */     BufferChecks.checkBuffer(params, 4);
/* 161:146 */     nglGetCombinerInputParameterivNV(stage, portion, variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 162:    */   }
/* 163:    */   
/* 164:    */   static native void nglGetCombinerInputParameterivNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 165:    */   
/* 166:    */   public static int glGetCombinerInputParameteriNV(int stage, int portion, int variable, int pname)
/* 167:    */   {
/* 168:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 169:153 */     long function_pointer = caps.glGetCombinerInputParameterivNV;
/* 170:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 171:155 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 172:156 */     nglGetCombinerInputParameterivNV(stage, portion, variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 173:157 */     return params.get(0);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static void glGetCombinerOutputParameterNV(int stage, int portion, int pname, FloatBuffer params)
/* 177:    */   {
/* 178:161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 179:162 */     long function_pointer = caps.glGetCombinerOutputParameterfvNV;
/* 180:163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 181:164 */     BufferChecks.checkBuffer(params, 4);
/* 182:165 */     nglGetCombinerOutputParameterfvNV(stage, portion, pname, MemoryUtil.getAddress(params), function_pointer);
/* 183:    */   }
/* 184:    */   
/* 185:    */   static native void nglGetCombinerOutputParameterfvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 186:    */   
/* 187:    */   public static float glGetCombinerOutputParameterfNV(int stage, int portion, int pname)
/* 188:    */   {
/* 189:171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 190:172 */     long function_pointer = caps.glGetCombinerOutputParameterfvNV;
/* 191:173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 192:174 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 193:175 */     nglGetCombinerOutputParameterfvNV(stage, portion, pname, MemoryUtil.getAddress(params), function_pointer);
/* 194:176 */     return params.get(0);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static void glGetCombinerOutputParameterNV(int stage, int portion, int pname, IntBuffer params)
/* 198:    */   {
/* 199:180 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:181 */     long function_pointer = caps.glGetCombinerOutputParameterivNV;
/* 201:182 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:183 */     BufferChecks.checkBuffer(params, 4);
/* 203:184 */     nglGetCombinerOutputParameterivNV(stage, portion, pname, MemoryUtil.getAddress(params), function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   static native void nglGetCombinerOutputParameterivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 207:    */   
/* 208:    */   public static int glGetCombinerOutputParameteriNV(int stage, int portion, int pname)
/* 209:    */   {
/* 210:190 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 211:191 */     long function_pointer = caps.glGetCombinerOutputParameterivNV;
/* 212:192 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 213:193 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 214:194 */     nglGetCombinerOutputParameterivNV(stage, portion, pname, MemoryUtil.getAddress(params), function_pointer);
/* 215:195 */     return params.get(0);
/* 216:    */   }
/* 217:    */   
/* 218:    */   public static void glGetFinalCombinerInputParameterNV(int variable, int pname, FloatBuffer params)
/* 219:    */   {
/* 220:199 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 221:200 */     long function_pointer = caps.glGetFinalCombinerInputParameterfvNV;
/* 222:201 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 223:202 */     BufferChecks.checkBuffer(params, 4);
/* 224:203 */     nglGetFinalCombinerInputParameterfvNV(variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 225:    */   }
/* 226:    */   
/* 227:    */   static native void nglGetFinalCombinerInputParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 228:    */   
/* 229:    */   public static float glGetFinalCombinerInputParameterfNV(int variable, int pname)
/* 230:    */   {
/* 231:209 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 232:210 */     long function_pointer = caps.glGetFinalCombinerInputParameterfvNV;
/* 233:211 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 234:212 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 235:213 */     nglGetFinalCombinerInputParameterfvNV(variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 236:214 */     return params.get(0);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static void glGetFinalCombinerInputParameterNV(int variable, int pname, IntBuffer params)
/* 240:    */   {
/* 241:218 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 242:219 */     long function_pointer = caps.glGetFinalCombinerInputParameterivNV;
/* 243:220 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 244:221 */     BufferChecks.checkBuffer(params, 4);
/* 245:222 */     nglGetFinalCombinerInputParameterivNV(variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 246:    */   }
/* 247:    */   
/* 248:    */   static native void nglGetFinalCombinerInputParameterivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 249:    */   
/* 250:    */   public static int glGetFinalCombinerInputParameteriNV(int variable, int pname)
/* 251:    */   {
/* 252:228 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 253:229 */     long function_pointer = caps.glGetFinalCombinerInputParameterivNV;
/* 254:230 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 255:231 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 256:232 */     nglGetFinalCombinerInputParameterivNV(variable, pname, MemoryUtil.getAddress(params), function_pointer);
/* 257:233 */     return params.get(0);
/* 258:    */   }
/* 259:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVRegisterCombiners
 * JD-Core Version:    0.7.0.1
 */