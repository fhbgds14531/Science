/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class EXTDrawInstanced
/* 10:   */ {
/* 11:   */   public static void glDrawArraysInstancedEXT(int mode, int first, int count, int primcount)
/* 12:   */   {
/* 13:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:14 */     long function_pointer = caps.glDrawArraysInstancedEXT;
/* 15:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:16 */     nglDrawArraysInstancedEXT(mode, first, count, primcount, function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nglDrawArraysInstancedEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 20:   */   
/* 21:   */   public static void glDrawElementsInstancedEXT(int mode, ByteBuffer indices, int primcount)
/* 22:   */   {
/* 23:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 24:22 */     long function_pointer = caps.glDrawElementsInstancedEXT;
/* 25:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 26:24 */     GLChecks.ensureElementVBOdisabled(caps);
/* 27:25 */     BufferChecks.checkDirect(indices);
/* 28:26 */     nglDrawElementsInstancedEXT(mode, indices.remaining(), 5121, MemoryUtil.getAddress(indices), primcount, function_pointer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void glDrawElementsInstancedEXT(int mode, IntBuffer indices, int primcount)
/* 32:   */   {
/* 33:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 34:30 */     long function_pointer = caps.glDrawElementsInstancedEXT;
/* 35:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 36:32 */     GLChecks.ensureElementVBOdisabled(caps);
/* 37:33 */     BufferChecks.checkDirect(indices);
/* 38:34 */     nglDrawElementsInstancedEXT(mode, indices.remaining(), 5125, MemoryUtil.getAddress(indices), primcount, function_pointer);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static void glDrawElementsInstancedEXT(int mode, ShortBuffer indices, int primcount)
/* 42:   */   {
/* 43:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 44:38 */     long function_pointer = caps.glDrawElementsInstancedEXT;
/* 45:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 46:40 */     GLChecks.ensureElementVBOdisabled(caps);
/* 47:41 */     BufferChecks.checkDirect(indices);
/* 48:42 */     nglDrawElementsInstancedEXT(mode, indices.remaining(), 5123, MemoryUtil.getAddress(indices), primcount, function_pointer);
/* 49:   */   }
/* 50:   */   
/* 51:   */   static native void nglDrawElementsInstancedEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 52:   */   
/* 53:   */   public static void glDrawElementsInstancedEXT(int mode, int indices_count, int type, long indices_buffer_offset, int primcount)
/* 54:   */   {
/* 55:46 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 56:47 */     long function_pointer = caps.glDrawElementsInstancedEXT;
/* 57:48 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 58:49 */     GLChecks.ensureElementVBOenabled(caps);
/* 59:50 */     nglDrawElementsInstancedEXTBO(mode, indices_count, type, indices_buffer_offset, primcount, function_pointer);
/* 60:   */   }
/* 61:   */   
/* 62:   */   static native void nglDrawElementsInstancedEXTBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, int paramInt4, long paramLong2);
/* 63:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTDrawInstanced
 * JD-Core Version:    0.7.0.1
 */