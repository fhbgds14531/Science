/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class ATIElementArray
/* 10:   */ {
/* 11:   */   public static final int GL_ELEMENT_ARRAY_ATI = 34664;
/* 12:   */   public static final int GL_ELEMENT_ARRAY_TYPE_ATI = 34665;
/* 13:   */   public static final int GL_ELEMENT_ARRAY_POINTER_ATI = 34666;
/* 14:   */   
/* 15:   */   public static void glElementPointerATI(ByteBuffer pPointer)
/* 16:   */   {
/* 17:17 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 18:18 */     long function_pointer = caps.glElementPointerATI;
/* 19:19 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 20:20 */     BufferChecks.checkDirect(pPointer);
/* 21:21 */     nglElementPointerATI(5121, MemoryUtil.getAddress(pPointer), function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glElementPointerATI(IntBuffer pPointer)
/* 25:   */   {
/* 26:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:25 */     long function_pointer = caps.glElementPointerATI;
/* 28:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:27 */     BufferChecks.checkDirect(pPointer);
/* 30:28 */     nglElementPointerATI(5125, MemoryUtil.getAddress(pPointer), function_pointer);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public static void glElementPointerATI(ShortBuffer pPointer)
/* 34:   */   {
/* 35:31 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 36:32 */     long function_pointer = caps.glElementPointerATI;
/* 37:33 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 38:34 */     BufferChecks.checkDirect(pPointer);
/* 39:35 */     nglElementPointerATI(5123, MemoryUtil.getAddress(pPointer), function_pointer);
/* 40:   */   }
/* 41:   */   
/* 42:   */   static native void nglElementPointerATI(int paramInt, long paramLong1, long paramLong2);
/* 43:   */   
/* 44:   */   public static void glDrawElementArrayATI(int mode, int count)
/* 45:   */   {
/* 46:40 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 47:41 */     long function_pointer = caps.glDrawElementArrayATI;
/* 48:42 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 49:43 */     nglDrawElementArrayATI(mode, count, function_pointer);
/* 50:   */   }
/* 51:   */   
/* 52:   */   static native void nglDrawElementArrayATI(int paramInt1, int paramInt2, long paramLong);
/* 53:   */   
/* 54:   */   public static void glDrawRangeElementArrayATI(int mode, int start, int end, int count)
/* 55:   */   {
/* 56:48 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 57:49 */     long function_pointer = caps.glDrawRangeElementArrayATI;
/* 58:50 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 59:51 */     nglDrawRangeElementArrayATI(mode, start, end, count, function_pointer);
/* 60:   */   }
/* 61:   */   
/* 62:   */   static native void nglDrawRangeElementArrayATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 63:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIElementArray
 * JD-Core Version:    0.7.0.1
 */