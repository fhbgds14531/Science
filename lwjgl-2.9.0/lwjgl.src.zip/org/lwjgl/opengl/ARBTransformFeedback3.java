/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBTransformFeedback3
/*  6:   */ {
/*  7:   */   public static final int GL_MAX_TRANSFORM_FEEDBACK_BUFFERS = 36464;
/*  8:   */   public static final int GL_MAX_VERTEX_STREAMS = 36465;
/*  9:   */   
/* 10:   */   public static void glDrawTransformFeedbackStream(int mode, int id, int stream)
/* 11:   */   {
/* 12:20 */     GL40.glDrawTransformFeedbackStream(mode, id, stream);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static void glBeginQueryIndexed(int target, int index, int id)
/* 16:   */   {
/* 17:24 */     GL40.glBeginQueryIndexed(target, index, id);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static void glEndQueryIndexed(int target, int index)
/* 21:   */   {
/* 22:28 */     GL40.glEndQueryIndexed(target, index);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static void glGetQueryIndexed(int target, int index, int pname, IntBuffer params)
/* 26:   */   {
/* 27:32 */     GL40.glGetQueryIndexed(target, index, pname, params);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static int glGetQueryIndexedi(int target, int index, int pname)
/* 31:   */   {
/* 32:37 */     return GL40.glGetQueryIndexedi(target, index, pname);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTransformFeedback3
 * JD-Core Version:    0.7.0.1
 */