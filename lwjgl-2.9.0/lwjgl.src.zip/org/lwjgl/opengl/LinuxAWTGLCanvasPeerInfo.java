/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import java.nio.ByteBuffer;
/*  5:   */ import org.lwjgl.LWJGLException;
/*  6:   */ import org.lwjgl.LWJGLUtil;
/*  7:   */ 
/*  8:   */ final class LinuxAWTGLCanvasPeerInfo
/*  9:   */   extends LinuxPeerInfo
/* 10:   */ {
/* 11:   */   private final Canvas component;
/* 12:48 */   private final AWTSurfaceLock awt_surface = new AWTSurfaceLock();
/* 13:49 */   private int screen = -1;
/* 14:   */   
/* 15:   */   LinuxAWTGLCanvasPeerInfo(Canvas component)
/* 16:   */   {
/* 17:52 */     this.component = component;
/* 18:   */   }
/* 19:   */   
/* 20:   */   protected void doLockAndInitHandle()
/* 21:   */     throws LWJGLException
/* 22:   */   {
/* 23:56 */     ByteBuffer surface_handle = this.awt_surface.lockAndGetHandle(this.component);
/* 24:57 */     if (this.screen == -1) {
/* 25:   */       try
/* 26:   */       {
/* 27:59 */         this.screen = getScreenFromSurfaceInfo(surface_handle);
/* 28:   */       }
/* 29:   */       catch (LWJGLException e)
/* 30:   */       {
/* 31:61 */         LWJGLUtil.log("Got exception while trying to determine screen: " + e);
/* 32:62 */         this.screen = 0;
/* 33:   */       }
/* 34:   */     }
/* 35:65 */     nInitHandle(this.screen, surface_handle, getHandle());
/* 36:   */   }
/* 37:   */   
/* 38:   */   private static native int getScreenFromSurfaceInfo(ByteBuffer paramByteBuffer)
/* 39:   */     throws LWJGLException;
/* 40:   */   
/* 41:   */   private static native void nInitHandle(int paramInt, ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/* 42:   */     throws LWJGLException;
/* 43:   */   
/* 44:   */   protected void doUnlock()
/* 45:   */     throws LWJGLException
/* 46:   */   {
/* 47:71 */     this.awt_surface.unlock();
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxAWTGLCanvasPeerInfo
 * JD-Core Version:    0.7.0.1
 */