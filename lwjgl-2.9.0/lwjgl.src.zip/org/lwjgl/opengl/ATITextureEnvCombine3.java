package org.lwjgl.opengl;

public final class ATITextureEnvCombine3
{
  public static final int GL_MODULATE_ADD_ATI = 34628;
  public static final int GL_MODULATE_SIGNED_ADD_ATI = 34629;
  public static final int GL_MODULATE_SUBTRACT_ATI = 34630;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATITextureEnvCombine3
 * JD-Core Version:    0.7.0.1
 */