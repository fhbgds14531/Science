package org.lwjgl.opengl;

public final class EXTFramebufferMultisampleBlitScaled
{
  public static final int GL_SCALED_RESOLVE_FASTEST_EXT = 37050;
  public static final int GL_SCALED_RESOLVE_NICEST_EXT = 37051;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTFramebufferMultisampleBlitScaled
 * JD-Core Version:    0.7.0.1
 */