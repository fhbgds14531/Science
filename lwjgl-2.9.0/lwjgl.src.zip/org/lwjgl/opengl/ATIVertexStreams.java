/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.BufferChecks;
/*   4:    */ 
/*   5:    */ public final class ATIVertexStreams
/*   6:    */ {
/*   7:    */   public static final int GL_MAX_VERTEX_STREAMS_ATI = 34667;
/*   8:    */   public static final int GL_VERTEX_SOURCE_ATI = 34668;
/*   9:    */   public static final int GL_VERTEX_STREAM0_ATI = 34669;
/*  10:    */   public static final int GL_VERTEX_STREAM1_ATI = 34670;
/*  11:    */   public static final int GL_VERTEX_STREAM2_ATI = 34671;
/*  12:    */   public static final int GL_VERTEX_STREAM3_ATI = 34672;
/*  13:    */   public static final int GL_VERTEX_STREAM4_ATI = 34673;
/*  14:    */   public static final int GL_VERTEX_STREAM5_ATI = 34674;
/*  15:    */   public static final int GL_VERTEX_STREAM6_ATI = 34675;
/*  16:    */   public static final int GL_VERTEX_STREAM7_ATI = 34676;
/*  17:    */   
/*  18:    */   public static void glVertexStream2fATI(int stream, float x, float y)
/*  19:    */   {
/*  20: 24 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  21: 25 */     long function_pointer = caps.glVertexStream2fATI;
/*  22: 26 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  23: 27 */     nglVertexStream2fATI(stream, x, y, function_pointer);
/*  24:    */   }
/*  25:    */   
/*  26:    */   static native void nglVertexStream2fATI(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*  27:    */   
/*  28:    */   public static void glVertexStream2dATI(int stream, double x, double y)
/*  29:    */   {
/*  30: 32 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  31: 33 */     long function_pointer = caps.glVertexStream2dATI;
/*  32: 34 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  33: 35 */     nglVertexStream2dATI(stream, x, y, function_pointer);
/*  34:    */   }
/*  35:    */   
/*  36:    */   static native void nglVertexStream2dATI(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/*  37:    */   
/*  38:    */   public static void glVertexStream2iATI(int stream, int x, int y)
/*  39:    */   {
/*  40: 40 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  41: 41 */     long function_pointer = caps.glVertexStream2iATI;
/*  42: 42 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  43: 43 */     nglVertexStream2iATI(stream, x, y, function_pointer);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static native void nglVertexStream2iATI(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  47:    */   
/*  48:    */   public static void glVertexStream2sATI(int stream, short x, short y)
/*  49:    */   {
/*  50: 48 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  51: 49 */     long function_pointer = caps.glVertexStream2sATI;
/*  52: 50 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  53: 51 */     nglVertexStream2sATI(stream, x, y, function_pointer);
/*  54:    */   }
/*  55:    */   
/*  56:    */   static native void nglVertexStream2sATI(int paramInt, short paramShort1, short paramShort2, long paramLong);
/*  57:    */   
/*  58:    */   public static void glVertexStream3fATI(int stream, float x, float y, float z)
/*  59:    */   {
/*  60: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  61: 57 */     long function_pointer = caps.glVertexStream3fATI;
/*  62: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  63: 59 */     nglVertexStream3fATI(stream, x, y, z, function_pointer);
/*  64:    */   }
/*  65:    */   
/*  66:    */   static native void nglVertexStream3fATI(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  67:    */   
/*  68:    */   public static void glVertexStream3dATI(int stream, double x, double y, double z)
/*  69:    */   {
/*  70: 64 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  71: 65 */     long function_pointer = caps.glVertexStream3dATI;
/*  72: 66 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  73: 67 */     nglVertexStream3dATI(stream, x, y, z, function_pointer);
/*  74:    */   }
/*  75:    */   
/*  76:    */   static native void nglVertexStream3dATI(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  77:    */   
/*  78:    */   public static void glVertexStream3iATI(int stream, int x, int y, int z)
/*  79:    */   {
/*  80: 72 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  81: 73 */     long function_pointer = caps.glVertexStream3iATI;
/*  82: 74 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  83: 75 */     nglVertexStream3iATI(stream, x, y, z, function_pointer);
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native void nglVertexStream3iATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  87:    */   
/*  88:    */   public static void glVertexStream3sATI(int stream, short x, short y, short z)
/*  89:    */   {
/*  90: 80 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91: 81 */     long function_pointer = caps.glVertexStream3sATI;
/*  92: 82 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93: 83 */     nglVertexStream3sATI(stream, x, y, z, function_pointer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   static native void nglVertexStream3sATI(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/*  97:    */   
/*  98:    */   public static void glVertexStream4fATI(int stream, float x, float y, float z, float w)
/*  99:    */   {
/* 100: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 101: 89 */     long function_pointer = caps.glVertexStream4fATI;
/* 102: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 103: 91 */     nglVertexStream4fATI(stream, x, y, z, w, function_pointer);
/* 104:    */   }
/* 105:    */   
/* 106:    */   static native void nglVertexStream4fATI(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 107:    */   
/* 108:    */   public static void glVertexStream4dATI(int stream, double x, double y, double z, double w)
/* 109:    */   {
/* 110: 96 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 111: 97 */     long function_pointer = caps.glVertexStream4dATI;
/* 112: 98 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 113: 99 */     nglVertexStream4dATI(stream, x, y, z, w, function_pointer);
/* 114:    */   }
/* 115:    */   
/* 116:    */   static native void nglVertexStream4dATI(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 117:    */   
/* 118:    */   public static void glVertexStream4iATI(int stream, int x, int y, int z, int w)
/* 119:    */   {
/* 120:104 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 121:105 */     long function_pointer = caps.glVertexStream4iATI;
/* 122:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 123:107 */     nglVertexStream4iATI(stream, x, y, z, w, function_pointer);
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native void nglVertexStream4iATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 127:    */   
/* 128:    */   public static void glVertexStream4sATI(int stream, short x, short y, short z, short w)
/* 129:    */   {
/* 130:112 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:113 */     long function_pointer = caps.glVertexStream4sATI;
/* 132:114 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:115 */     nglVertexStream4sATI(stream, x, y, z, w, function_pointer);
/* 134:    */   }
/* 135:    */   
/* 136:    */   static native void nglVertexStream4sATI(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/* 137:    */   
/* 138:    */   public static void glNormalStream3bATI(int stream, byte x, byte y, byte z)
/* 139:    */   {
/* 140:120 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 141:121 */     long function_pointer = caps.glNormalStream3bATI;
/* 142:122 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 143:123 */     nglNormalStream3bATI(stream, x, y, z, function_pointer);
/* 144:    */   }
/* 145:    */   
/* 146:    */   static native void nglNormalStream3bATI(int paramInt, byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 147:    */   
/* 148:    */   public static void glNormalStream3fATI(int stream, float x, float y, float z)
/* 149:    */   {
/* 150:128 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 151:129 */     long function_pointer = caps.glNormalStream3fATI;
/* 152:130 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 153:131 */     nglNormalStream3fATI(stream, x, y, z, function_pointer);
/* 154:    */   }
/* 155:    */   
/* 156:    */   static native void nglNormalStream3fATI(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 157:    */   
/* 158:    */   public static void glNormalStream3dATI(int stream, double x, double y, double z)
/* 159:    */   {
/* 160:136 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:137 */     long function_pointer = caps.glNormalStream3dATI;
/* 162:138 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:139 */     nglNormalStream3dATI(stream, x, y, z, function_pointer);
/* 164:    */   }
/* 165:    */   
/* 166:    */   static native void nglNormalStream3dATI(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 167:    */   
/* 168:    */   public static void glNormalStream3iATI(int stream, int x, int y, int z)
/* 169:    */   {
/* 170:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 171:145 */     long function_pointer = caps.glNormalStream3iATI;
/* 172:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 173:147 */     nglNormalStream3iATI(stream, x, y, z, function_pointer);
/* 174:    */   }
/* 175:    */   
/* 176:    */   static native void nglNormalStream3iATI(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 177:    */   
/* 178:    */   public static void glNormalStream3sATI(int stream, short x, short y, short z)
/* 179:    */   {
/* 180:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 181:153 */     long function_pointer = caps.glNormalStream3sATI;
/* 182:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 183:155 */     nglNormalStream3sATI(stream, x, y, z, function_pointer);
/* 184:    */   }
/* 185:    */   
/* 186:    */   static native void nglNormalStream3sATI(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/* 187:    */   
/* 188:    */   public static void glClientActiveVertexStreamATI(int stream)
/* 189:    */   {
/* 190:160 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 191:161 */     long function_pointer = caps.glClientActiveVertexStreamATI;
/* 192:162 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 193:163 */     nglClientActiveVertexStreamATI(stream, function_pointer);
/* 194:    */   }
/* 195:    */   
/* 196:    */   static native void nglClientActiveVertexStreamATI(int paramInt, long paramLong);
/* 197:    */   
/* 198:    */   public static void glVertexBlendEnvfATI(int pname, float param)
/* 199:    */   {
/* 200:168 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 201:169 */     long function_pointer = caps.glVertexBlendEnvfATI;
/* 202:170 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 203:171 */     nglVertexBlendEnvfATI(pname, param, function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   static native void nglVertexBlendEnvfATI(int paramInt, float paramFloat, long paramLong);
/* 207:    */   
/* 208:    */   public static void glVertexBlendEnviATI(int pname, int param)
/* 209:    */   {
/* 210:176 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 211:177 */     long function_pointer = caps.glVertexBlendEnviATI;
/* 212:178 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 213:179 */     nglVertexBlendEnviATI(pname, param, function_pointer);
/* 214:    */   }
/* 215:    */   
/* 216:    */   static native void nglVertexBlendEnviATI(int paramInt1, int paramInt2, long paramLong);
/* 217:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ATIVertexStreams
 * JD-Core Version:    0.7.0.1
 */