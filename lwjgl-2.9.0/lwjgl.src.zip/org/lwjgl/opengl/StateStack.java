/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ class StateStack
/*  4:   */ {
/*  5:   */   private int[] state_stack;
/*  6:   */   private int stack_pos;
/*  7:   */   
/*  8:   */   public int getState()
/*  9:   */   {
/* 10:39 */     return this.state_stack[this.stack_pos];
/* 11:   */   }
/* 12:   */   
/* 13:   */   public void pushState(int new_state)
/* 14:   */   {
/* 15:43 */     int pos = ++this.stack_pos;
/* 16:44 */     if (pos == this.state_stack.length) {
/* 17:45 */       growState();
/* 18:   */     }
/* 19:47 */     this.state_stack[pos] = new_state;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int popState()
/* 23:   */   {
/* 24:51 */     return this.state_stack[(this.stack_pos--)];
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void growState()
/* 28:   */   {
/* 29:55 */     int[] new_state_stack = new int[this.state_stack.length + 1];
/* 30:56 */     System.arraycopy(this.state_stack, 0, new_state_stack, 0, this.state_stack.length);
/* 31:57 */     this.state_stack = new_state_stack;
/* 32:   */   }
/* 33:   */   
/* 34:   */   StateStack(int initial_value)
/* 35:   */   {
/* 36:61 */     this.state_stack = new int[1];
/* 37:62 */     this.stack_pos = 0;
/* 38:63 */     this.state_stack[this.stack_pos] = initial_value;
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.StateStack
 * JD-Core Version:    0.7.0.1
 */