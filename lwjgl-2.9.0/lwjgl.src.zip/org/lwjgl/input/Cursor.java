/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferUtils;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ import org.lwjgl.LWJGLUtil;
/*   7:    */ import org.lwjgl.NondirectBufferWrapper;
/*   8:    */ import org.lwjgl.Sys;
/*   9:    */ import org.lwjgl.opengl.InputImplementation;
/*  10:    */ 
/*  11:    */ public class Cursor
/*  12:    */ {
/*  13:    */   public static final int CURSOR_ONE_BIT_TRANSPARENCY = 1;
/*  14:    */   public static final int CURSOR_8_BIT_ALPHA = 2;
/*  15:    */   public static final int CURSOR_ANIMATION = 4;
/*  16:    */   private final CursorElement[] cursors;
/*  17:    */   private int index;
/*  18:    */   private boolean destroyed;
/*  19:    */   
/*  20:    */   public Cursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*  21:    */     throws LWJGLException
/*  22:    */   {
/*  23: 86 */     synchronized (OpenGLPackageAccess.global_lock)
/*  24:    */     {
/*  25: 87 */       if ((getCapabilities() & 0x1) == 0) {
/*  26: 88 */         throw new LWJGLException("Native cursors not supported");
/*  27:    */       }
/*  28: 89 */       images = NondirectBufferWrapper.wrapBuffer(images, width * height * numImages);
/*  29: 90 */       if (delays != null) {
/*  30: 91 */         delays = NondirectBufferWrapper.wrapBuffer(delays, numImages);
/*  31:    */       }
/*  32: 92 */       if (!Mouse.isCreated()) {
/*  33: 93 */         throw new IllegalStateException("Mouse must be created before creating cursor objects");
/*  34:    */       }
/*  35: 94 */       if (width * height * numImages > images.remaining()) {
/*  36: 95 */         throw new IllegalArgumentException("width*height*numImages > images.remaining()");
/*  37:    */       }
/*  38: 96 */       if ((xHotspot >= width) || (xHotspot < 0)) {
/*  39: 97 */         throw new IllegalArgumentException("xHotspot > width || xHotspot < 0");
/*  40:    */       }
/*  41: 98 */       if ((yHotspot >= height) || (yHotspot < 0)) {
/*  42: 99 */         throw new IllegalArgumentException("yHotspot > height || yHotspot < 0");
/*  43:    */       }
/*  44:101 */       Sys.initialize();
/*  45:    */       
/*  46:    */ 
/*  47:104 */       yHotspot = height - 1 - yHotspot;
/*  48:    */       
/*  49:    */ 
/*  50:107 */       this.cursors = createCursors(width, height, xHotspot, yHotspot, numImages, images, delays);
/*  51:    */     }
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static int getMinCursorSize()
/*  55:    */   {
/*  56:119 */     synchronized (OpenGLPackageAccess.global_lock)
/*  57:    */     {
/*  58:120 */       if (!Mouse.isCreated()) {
/*  59:121 */         throw new IllegalStateException("Mouse must be created.");
/*  60:    */       }
/*  61:122 */       return Mouse.getImplementation().getMinCursorSize();
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static int getMaxCursorSize()
/*  66:    */   {
/*  67:134 */     synchronized (OpenGLPackageAccess.global_lock)
/*  68:    */     {
/*  69:135 */       if (!Mouse.isCreated()) {
/*  70:136 */         throw new IllegalStateException("Mouse must be created.");
/*  71:    */       }
/*  72:137 */       return Mouse.getImplementation().getMaxCursorSize();
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static int getCapabilities()
/*  77:    */   {
/*  78:150 */     synchronized (OpenGLPackageAccess.global_lock)
/*  79:    */     {
/*  80:151 */       if (Mouse.getImplementation() != null) {
/*  81:152 */         return Mouse.getImplementation().getNativeCursorCapabilities();
/*  82:    */       }
/*  83:154 */       return OpenGLPackageAccess.createImplementation().getNativeCursorCapabilities();
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static CursorElement[] createCursors(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/*  88:    */     throws LWJGLException
/*  89:    */   {
/*  90:163 */     IntBuffer images_copy = BufferUtils.createIntBuffer(images.remaining());
/*  91:164 */     flipImages(width, height, numImages, images, images_copy);
/*  92:    */     CursorElement[] cursors;
/*  93:174 */     switch (LWJGLUtil.getPlatform())
/*  94:    */     {
/*  95:    */     case 2: 
/*  96:178 */       convertARGBtoABGR(images_copy);
/*  97:    */       
/*  98:    */ 
/*  99:181 */       cursors = new CursorElement[numImages];
/* 100:182 */       for (int i = 0; i < numImages; i++)
/* 101:    */       {
/* 102:183 */         Object handle = Mouse.getImplementation().createCursor(width, height, xHotspot, yHotspot, 1, images_copy, null);
/* 103:184 */         long delay = delays != null ? delays.get(i) : 0L;
/* 104:185 */         long timeout = System.currentTimeMillis();
/* 105:186 */         cursors[i] = new CursorElement(handle, delay, timeout);
/* 106:    */         
/* 107:    */ 
/* 108:189 */         images_copy.position(width * height * (i + 1));
/* 109:    */       }
/* 110:191 */       break;
/* 111:    */     case 3: 
/* 112:194 */       cursors = new CursorElement[numImages];
/* 113:195 */       for (int i = 0; i < numImages; i++)
/* 114:    */       {
/* 115:198 */         int size = width * height;
/* 116:199 */         for (int j = 0; j < size; j++)
/* 117:    */         {
/* 118:200 */           int index = j + i * size;
/* 119:201 */           int alpha = images_copy.get(index) >> 24 & 0xFF;
/* 120:202 */           if (alpha != 255) {
/* 121:203 */             images_copy.put(index, 0);
/* 122:    */           }
/* 123:    */         }
/* 124:207 */         Object handle = Mouse.getImplementation().createCursor(width, height, xHotspot, yHotspot, 1, images_copy, null);
/* 125:208 */         long delay = delays != null ? delays.get(i) : 0L;
/* 126:209 */         long timeout = System.currentTimeMillis();
/* 127:210 */         cursors[i] = new CursorElement(handle, delay, timeout);
/* 128:    */         
/* 129:    */ 
/* 130:213 */         images_copy.position(width * height * (i + 1));
/* 131:    */       }
/* 132:215 */       break;
/* 133:    */     case 1: 
/* 134:218 */       Object handle = Mouse.getImplementation().createCursor(width, height, xHotspot, yHotspot, numImages, images_copy, delays);
/* 135:219 */       CursorElement cursor_element = new CursorElement(handle, -1L, -1L);
/* 136:220 */       cursors = new CursorElement[] { cursor_element };
/* 137:221 */       break;
/* 138:    */     default: 
/* 139:223 */       throw new RuntimeException("Unknown OS");
/* 140:    */     }
/* 141:225 */     return cursors;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static void convertARGBtoABGR(IntBuffer imageBuffer)
/* 145:    */   {
/* 146:234 */     for (int i = 0; i < imageBuffer.limit(); i++)
/* 147:    */     {
/* 148:235 */       int argbColor = imageBuffer.get(i);
/* 149:    */       
/* 150:237 */       byte alpha = (byte)(argbColor >>> 24);
/* 151:238 */       byte blue = (byte)(argbColor >>> 16);
/* 152:239 */       byte green = (byte)(argbColor >>> 8);
/* 153:240 */       byte red = (byte)argbColor;
/* 154:    */       
/* 155:242 */       int abgrColor = ((alpha & 0xFF) << 24) + ((red & 0xFF) << 16) + ((green & 0xFF) << 8) + (blue & 0xFF);
/* 156:    */       
/* 157:244 */       imageBuffer.put(i, abgrColor);
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static void flipImages(int width, int height, int numImages, IntBuffer images, IntBuffer images_copy)
/* 162:    */   {
/* 163:258 */     for (int i = 0; i < numImages; i++)
/* 164:    */     {
/* 165:259 */       int start_index = i * width * height;
/* 166:260 */       flipImage(width, height, start_index, images, images_copy);
/* 167:    */     }
/* 168:    */   }
/* 169:    */   
/* 170:    */   private static void flipImage(int width, int height, int start_index, IntBuffer images, IntBuffer images_copy)
/* 171:    */   {
/* 172:272 */     for (int y = 0; y < height >> 1; y++)
/* 173:    */     {
/* 174:273 */       int index_y_1 = y * width + start_index;
/* 175:274 */       int index_y_2 = (height - y - 1) * width + start_index;
/* 176:275 */       for (int x = 0; x < width; x++)
/* 177:    */       {
/* 178:276 */         int index1 = index_y_1 + x;
/* 179:277 */         int index2 = index_y_2 + x;
/* 180:278 */         int temp_pixel = images.get(index1 + images.position());
/* 181:279 */         images_copy.put(index1, images.get(index2 + images.position()));
/* 182:280 */         images_copy.put(index2, temp_pixel);
/* 183:    */       }
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   Object getHandle()
/* 188:    */   {
/* 189:289 */     checkValid();
/* 190:290 */     return this.cursors[this.index].cursorHandle;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private void checkValid()
/* 194:    */   {
/* 195:294 */     if (this.destroyed) {
/* 196:295 */       throw new IllegalStateException("The cursor is destroyed");
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   public void destroy()
/* 201:    */   {
/* 202:304 */     synchronized (OpenGLPackageAccess.global_lock)
/* 203:    */     {
/* 204:305 */       if (this.destroyed) {
/* 205:306 */         return;
/* 206:    */       }
/* 207:307 */       if (Mouse.getNativeCursor() == this) {
/* 208:    */         try
/* 209:    */         {
/* 210:309 */           Mouse.setNativeCursor(null);
/* 211:    */         }
/* 212:    */         catch (LWJGLException e) {}
/* 213:    */       }
/* 214:314 */       for (CursorElement cursor : this.cursors) {
/* 215:315 */         Mouse.getImplementation().destroyCursor(cursor.cursorHandle);
/* 216:    */       }
/* 217:317 */       this.destroyed = true;
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   protected void setTimeout()
/* 222:    */   {
/* 223:325 */     checkValid();
/* 224:326 */     this.cursors[this.index].timeout = (System.currentTimeMillis() + this.cursors[this.index].delay);
/* 225:    */   }
/* 226:    */   
/* 227:    */   protected boolean hasTimedOut()
/* 228:    */   {
/* 229:334 */     checkValid();
/* 230:335 */     return (this.cursors.length > 1) && (this.cursors[this.index].timeout < System.currentTimeMillis());
/* 231:    */   }
/* 232:    */   
/* 233:    */   protected void nextCursor()
/* 234:    */   {
/* 235:342 */     checkValid();
/* 236:343 */     this.index = (++this.index % this.cursors.length);
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static class CursorElement
/* 240:    */   {
/* 241:    */     final Object cursorHandle;
/* 242:    */     final long delay;
/* 243:    */     long timeout;
/* 244:    */     
/* 245:    */     CursorElement(Object cursorHandle, long delay, long timeout)
/* 246:    */     {
/* 247:360 */       this.cursorHandle = cursorHandle;
/* 248:361 */       this.delay = delay;
/* 249:362 */       this.timeout = timeout;
/* 250:    */     }
/* 251:    */   }
/* 252:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.Cursor
 * JD-Core Version:    0.7.0.1
 */