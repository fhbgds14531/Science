/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.PointerWrapperAbstract;
/*  5:   */ 
/*  6:   */ public abstract class CLContextCallback
/*  7:   */   extends PointerWrapperAbstract
/*  8:   */ {
/*  9:   */   private final boolean custom;
/* 10:   */   
/* 11:   */   protected CLContextCallback()
/* 12:   */   {
/* 13:48 */     super(CallbackUtil.getContextCallback());
/* 14:49 */     this.custom = false;
/* 15:   */   }
/* 16:   */   
/* 17:   */   protected CLContextCallback(long pointer)
/* 18:   */   {
/* 19:58 */     super(pointer);
/* 20:60 */     if (pointer == 0L) {
/* 21:61 */       throw new RuntimeException("Invalid callback function pointer specified.");
/* 22:   */     }
/* 23:63 */     this.custom = true;
/* 24:   */   }
/* 25:   */   
/* 26:   */   final boolean isCustom()
/* 27:   */   {
/* 28:67 */     return this.custom;
/* 29:   */   }
/* 30:   */   
/* 31:   */   protected abstract void handleMessage(String paramString, ByteBuffer paramByteBuffer);
/* 32:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLContextCallback
 * JD-Core Version:    0.7.0.1
 */