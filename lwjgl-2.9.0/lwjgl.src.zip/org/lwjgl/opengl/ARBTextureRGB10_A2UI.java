package org.lwjgl.opengl;

public final class ARBTextureRGB10_A2UI
{
  public static final int GL_RGB10_A2UI = 36975;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureRGB10_A2UI
 * JD-Core Version:    0.7.0.1
 */