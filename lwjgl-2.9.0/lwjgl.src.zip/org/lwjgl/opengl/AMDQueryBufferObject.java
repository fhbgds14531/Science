package org.lwjgl.opengl;

public final class AMDQueryBufferObject
{
  public static final int GL_QUERY_RESULT_NO_WAIT_AMD = 37268;
  public static final int GL_QUERY_BUFFER_AMD = 37266;
  public static final int GL_QUERY_BUFFER_BINDING_AMD = 37267;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDQueryBufferObject
 * JD-Core Version:    0.7.0.1
 */