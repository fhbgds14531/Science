package org.lwjgl.opengl;

public final class NVFragmentProgram2
{
  public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 35060;
  public static final int GL_MAX_PROGRAM_CALL_DEPTH_NV = 35061;
  public static final int GL_MAX_PROGRAM_IF_DEPTH_NV = 35062;
  public static final int GL_MAX_PROGRAM_LOOP_DEPTH_NV = 35063;
  public static final int GL_MAX_PROGRAM_LOOP_COUNT_NV = 35064;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVFragmentProgram2
 * JD-Core Version:    0.7.0.1
 */