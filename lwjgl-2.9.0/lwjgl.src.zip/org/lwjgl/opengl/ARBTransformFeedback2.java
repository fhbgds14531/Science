/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBTransformFeedback2
/*  6:   */ {
/*  7:   */   public static final int GL_TRANSFORM_FEEDBACK = 36386;
/*  8:   */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED = 36387;
/*  9:   */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE = 36388;
/* 10:   */   public static final int GL_TRANSFORM_FEEDBACK_BINDING = 36389;
/* 11:   */   
/* 12:   */   public static void glBindTransformFeedback(int target, int id)
/* 13:   */   {
/* 14:26 */     GL40.glBindTransformFeedback(target, id);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static void glDeleteTransformFeedbacks(IntBuffer ids)
/* 18:   */   {
/* 19:30 */     GL40.glDeleteTransformFeedbacks(ids);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static void glDeleteTransformFeedbacks(int id)
/* 23:   */   {
/* 24:35 */     GL40.glDeleteTransformFeedbacks(id);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static void glGenTransformFeedbacks(IntBuffer ids)
/* 28:   */   {
/* 29:39 */     GL40.glGenTransformFeedbacks(ids);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static int glGenTransformFeedbacks()
/* 33:   */   {
/* 34:44 */     return GL40.glGenTransformFeedbacks();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static boolean glIsTransformFeedback(int id)
/* 38:   */   {
/* 39:48 */     return GL40.glIsTransformFeedback(id);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static void glPauseTransformFeedback() {}
/* 43:   */   
/* 44:   */   public static void glResumeTransformFeedback() {}
/* 45:   */   
/* 46:   */   public static void glDrawTransformFeedback(int mode, int id)
/* 47:   */   {
/* 48:60 */     GL40.glDrawTransformFeedback(mode, id);
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTransformFeedback2
 * JD-Core Version:    0.7.0.1
 */