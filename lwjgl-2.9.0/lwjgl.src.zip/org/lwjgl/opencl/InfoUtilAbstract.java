/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import org.lwjgl.LWJGLUtil;
/*   5:    */ import org.lwjgl.PointerBuffer;
/*   6:    */ 
/*   7:    */ abstract class InfoUtilAbstract<T extends CLObject>
/*   8:    */   implements InfoUtil<T>
/*   9:    */ {
/*  10:    */   protected abstract int getInfo(T paramT, int paramInt, ByteBuffer paramByteBuffer, PointerBuffer paramPointerBuffer);
/*  11:    */   
/*  12:    */   protected int getInfoSizeArraySize(T object, int param_name)
/*  13:    */   {
/*  14: 56 */     throw new UnsupportedOperationException();
/*  15:    */   }
/*  16:    */   
/*  17:    */   protected PointerBuffer getSizesBuffer(T object, int param_name)
/*  18:    */   {
/*  19: 60 */     int size = getInfoSizeArraySize(object, param_name);
/*  20:    */     
/*  21: 62 */     PointerBuffer buffer = APIUtil.getBufferPointer(size);
/*  22: 63 */     buffer.limit(size);
/*  23:    */     
/*  24: 65 */     getInfo(object, param_name, buffer.getBuffer(), null);
/*  25:    */     
/*  26: 67 */     return buffer;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public int getInfoInt(T object, int param_name)
/*  30:    */   {
/*  31: 71 */     object.checkValid();
/*  32:    */     
/*  33: 73 */     ByteBuffer buffer = APIUtil.getBufferByte(4);
/*  34: 74 */     getInfo(object, param_name, buffer, null);
/*  35:    */     
/*  36: 76 */     return buffer.getInt(0);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public long getInfoSize(T object, int param_name)
/*  40:    */   {
/*  41: 80 */     object.checkValid();
/*  42:    */     
/*  43: 82 */     PointerBuffer buffer = APIUtil.getBufferPointer();
/*  44: 83 */     getInfo(object, param_name, buffer.getBuffer(), null);
/*  45:    */     
/*  46: 85 */     return buffer.get(0);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public long[] getInfoSizeArray(T object, int param_name)
/*  50:    */   {
/*  51: 89 */     object.checkValid();
/*  52:    */     
/*  53: 91 */     int size = getInfoSizeArraySize(object, param_name);
/*  54: 92 */     PointerBuffer buffer = APIUtil.getBufferPointer(size);
/*  55:    */     
/*  56: 94 */     getInfo(object, param_name, buffer.getBuffer(), null);
/*  57:    */     
/*  58: 96 */     long[] array = new long[size];
/*  59: 97 */     for (int i = 0; i < size; i++) {
/*  60: 98 */       array[i] = buffer.get(i);
/*  61:    */     }
/*  62:100 */     return array;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public long getInfoLong(T object, int param_name)
/*  66:    */   {
/*  67:104 */     object.checkValid();
/*  68:    */     
/*  69:106 */     ByteBuffer buffer = APIUtil.getBufferByte(8);
/*  70:107 */     getInfo(object, param_name, buffer, null);
/*  71:    */     
/*  72:109 */     return buffer.getLong(0);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public String getInfoString(T object, int param_name)
/*  76:    */   {
/*  77:113 */     object.checkValid();
/*  78:    */     
/*  79:115 */     int bytes = getSizeRet(object, param_name);
/*  80:116 */     if (bytes <= 1) {
/*  81:117 */       return null;
/*  82:    */     }
/*  83:119 */     ByteBuffer buffer = APIUtil.getBufferByte(bytes);
/*  84:120 */     getInfo(object, param_name, buffer, null);
/*  85:    */     
/*  86:122 */     buffer.limit(bytes - 1);
/*  87:123 */     return APIUtil.getString(buffer);
/*  88:    */   }
/*  89:    */   
/*  90:    */   protected final int getSizeRet(T object, int param_name)
/*  91:    */   {
/*  92:127 */     PointerBuffer bytes = APIUtil.getBufferPointer();
/*  93:128 */     int errcode = getInfo(object, param_name, null, bytes);
/*  94:129 */     if (errcode != 0) {
/*  95:130 */       throw new IllegalArgumentException("Invalid parameter specified: " + LWJGLUtil.toHexString(param_name));
/*  96:    */     }
/*  97:132 */     return (int)bytes.get(0);
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.InfoUtilAbstract
 * JD-Core Version:    0.7.0.1
 */