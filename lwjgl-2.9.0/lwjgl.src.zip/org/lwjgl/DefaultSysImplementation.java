/*  1:   */ 
/*  2:   */ 
/*  3:   */ DefaultSysImplementation
/*  4:   */   
/*  5:   */ 
/*  6:   */   getJNIVersion
/*  7:   */   
/*  8:   */   getPointerSize
/*  9:   */   
/* 10:   */   setDebug
/* 11:   */   
/* 12:   */   getTimerResolution
/* 13:   */   
/* 14:47 */     1000L
/* 15:   */   
/* 16:   */   
/* 17:   */   has64Bit
/* 18:   */   
/* 19:51 */     
/* 20:   */   
/* 21:   */   
/* 22:   */   getTime
/* 23:   */   
/* 24:   */   alert, 
/* 25:   */   
/* 26:   */   getClipboard
/* 27:   */ 


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.DefaultSysImplementation
 * JD-Core Version:    0.7.0.1
 */