/*  1:   */ package org.lwjgl.openal;
/*  2:   */ 
/*  3:   */ public final class Util
/*  4:   */ {
/*  5:   */   public static void checkALCError(ALCdevice device)
/*  6:   */   {
/*  7:53 */     int err = ALC10.alcGetError(device);
/*  8:54 */     if (err != 0) {
/*  9:55 */       throw new OpenALException(ALC10.alcGetString(AL.getDevice(), err));
/* 10:   */     }
/* 11:   */   }
/* 12:   */   
/* 13:   */   public static void checkALError()
/* 14:   */   {
/* 15:62 */     int err = AL10.alGetError();
/* 16:63 */     if (err != 0) {
/* 17:64 */       throw new OpenALException(err);
/* 18:   */     }
/* 19:   */   }
/* 20:   */   
/* 21:   */   public static void checkALCValidDevice(ALCdevice device)
/* 22:   */   {
/* 23:72 */     if (!device.isValid()) {
/* 24:73 */       throw new OpenALException("Invalid device: " + device);
/* 25:   */     }
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static void checkALCValidContext(ALCcontext context)
/* 29:   */   {
/* 30:82 */     if (!context.isValid()) {
/* 31:83 */       throw new OpenALException("Invalid context: " + context);
/* 32:   */     }
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.Util
 * JD-Core Version:    0.7.0.1
 */