/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.awt.Canvas;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class MacOSXAWTGLCanvasPeerInfo
/*  7:   */   extends MacOSXCanvasPeerInfo
/*  8:   */ {
/*  9:   */   private final Canvas component;
/* 10:   */   
/* 11:   */   MacOSXAWTGLCanvasPeerInfo(Canvas component, PixelFormat pixel_format, ContextAttribs attribs, boolean support_pbuffer)
/* 12:   */     throws LWJGLException
/* 13:   */   {
/* 14:48 */     super(pixel_format, attribs, support_pbuffer);
/* 15:49 */     this.component = component;
/* 16:   */   }
/* 17:   */   
/* 18:   */   protected void doLockAndInitHandle()
/* 19:   */     throws LWJGLException
/* 20:   */   {
/* 21:53 */     initHandle(this.component);
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXAWTGLCanvasPeerInfo
 * JD-Core Version:    0.7.0.1
 */