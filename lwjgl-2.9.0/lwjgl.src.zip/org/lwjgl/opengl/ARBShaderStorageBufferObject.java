/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBShaderStorageBufferObject
/*  4:   */ {
/*  5:   */   public static final int GL_SHADER_STORAGE_BUFFER = 37074;
/*  6:   */   public static final int GL_SHADER_STORAGE_BUFFER_BINDING = 37075;
/*  7:   */   public static final int GL_SHADER_STORAGE_BUFFER_START = 37076;
/*  8:   */   public static final int GL_SHADER_STORAGE_BUFFER_SIZE = 37077;
/*  9:   */   public static final int GL_MAX_VERTEX_SHADER_STORAGE_BLOCKS = 37078;
/* 10:   */   public static final int GL_MAX_GEOMETRY_SHADER_STORAGE_BLOCKS = 37079;
/* 11:   */   public static final int GL_MAX_TESS_CONTROL_SHADER_STORAGE_BLOCKS = 37080;
/* 12:   */   public static final int GL_MAX_TESS_EVALUATION_SHADER_STORAGE_BLOCKS = 37081;
/* 13:   */   public static final int GL_MAX_FRAGMENT_SHADER_STORAGE_BLOCKS = 37082;
/* 14:   */   public static final int GL_MAX_COMPUTE_SHADER_STORAGE_BLOCKS = 37083;
/* 15:   */   public static final int GL_MAX_COMBINED_SHADER_STORAGE_BLOCKS = 37084;
/* 16:   */   public static final int GL_MAX_SHADER_STORAGE_BUFFER_BINDINGS = 37085;
/* 17:   */   public static final int GL_MAX_SHADER_STORAGE_BLOCK_SIZE = 37086;
/* 18:   */   public static final int GL_SHADER_STORAGE_BUFFER_OFFSET_ALIGNMENT = 37087;
/* 19:   */   public static final int GL_SHADER_STORAGE_BARRIER_BIT = 8192;
/* 20:   */   public static final int GL_MAX_COMBINED_SHADER_OUTPUT_RESOURCES = 36665;
/* 21:   */   
/* 22:   */   public static void glShaderStorageBlockBinding(int program, int storageBlockIndex, int storageBlockBinding)
/* 23:   */   {
/* 24:60 */     GL43.glShaderStorageBlockBinding(program, storageBlockIndex, storageBlockBinding);
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShaderStorageBufferObject
 * JD-Core Version:    0.7.0.1
 */