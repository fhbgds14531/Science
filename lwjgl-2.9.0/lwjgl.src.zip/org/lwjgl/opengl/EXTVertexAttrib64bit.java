/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.DoubleBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.LWJGLUtil;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class EXTVertexAttrib64bit
/*   9:    */ {
/*  10:    */   public static final int GL_DOUBLE_VEC2_EXT = 36860;
/*  11:    */   public static final int GL_DOUBLE_VEC3_EXT = 36861;
/*  12:    */   public static final int GL_DOUBLE_VEC4_EXT = 36862;
/*  13:    */   public static final int GL_DOUBLE_MAT2_EXT = 36678;
/*  14:    */   public static final int GL_DOUBLE_MAT3_EXT = 36679;
/*  15:    */   public static final int GL_DOUBLE_MAT4_EXT = 36680;
/*  16:    */   public static final int GL_DOUBLE_MAT2x3_EXT = 36681;
/*  17:    */   public static final int GL_DOUBLE_MAT2x4_EXT = 36682;
/*  18:    */   public static final int GL_DOUBLE_MAT3x2_EXT = 36683;
/*  19:    */   public static final int GL_DOUBLE_MAT3x4_EXT = 36684;
/*  20:    */   public static final int GL_DOUBLE_MAT4x2_EXT = 36685;
/*  21:    */   public static final int GL_DOUBLE_MAT4x3_EXT = 36686;
/*  22:    */   
/*  23:    */   public static void glVertexAttribL1dEXT(int index, double x)
/*  24:    */   {
/*  25: 29 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  26: 30 */     long function_pointer = caps.glVertexAttribL1dEXT;
/*  27: 31 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  28: 32 */     nglVertexAttribL1dEXT(index, x, function_pointer);
/*  29:    */   }
/*  30:    */   
/*  31:    */   static native void nglVertexAttribL1dEXT(int paramInt, double paramDouble, long paramLong);
/*  32:    */   
/*  33:    */   public static void glVertexAttribL2dEXT(int index, double x, double y)
/*  34:    */   {
/*  35: 37 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 38 */     long function_pointer = caps.glVertexAttribL2dEXT;
/*  37: 39 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 40 */     nglVertexAttribL2dEXT(index, x, y, function_pointer);
/*  39:    */   }
/*  40:    */   
/*  41:    */   static native void nglVertexAttribL2dEXT(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/*  42:    */   
/*  43:    */   public static void glVertexAttribL3dEXT(int index, double x, double y, double z)
/*  44:    */   {
/*  45: 45 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  46: 46 */     long function_pointer = caps.glVertexAttribL3dEXT;
/*  47: 47 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  48: 48 */     nglVertexAttribL3dEXT(index, x, y, z, function_pointer);
/*  49:    */   }
/*  50:    */   
/*  51:    */   static native void nglVertexAttribL3dEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  52:    */   
/*  53:    */   public static void glVertexAttribL4dEXT(int index, double x, double y, double z, double w)
/*  54:    */   {
/*  55: 53 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  56: 54 */     long function_pointer = caps.glVertexAttribL4dEXT;
/*  57: 55 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  58: 56 */     nglVertexAttribL4dEXT(index, x, y, z, w, function_pointer);
/*  59:    */   }
/*  60:    */   
/*  61:    */   static native void nglVertexAttribL4dEXT(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  62:    */   
/*  63:    */   public static void glVertexAttribL1EXT(int index, DoubleBuffer v)
/*  64:    */   {
/*  65: 61 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  66: 62 */     long function_pointer = caps.glVertexAttribL1dvEXT;
/*  67: 63 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  68: 64 */     BufferChecks.checkBuffer(v, 1);
/*  69: 65 */     nglVertexAttribL1dvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/*  70:    */   }
/*  71:    */   
/*  72:    */   static native void nglVertexAttribL1dvEXT(int paramInt, long paramLong1, long paramLong2);
/*  73:    */   
/*  74:    */   public static void glVertexAttribL2EXT(int index, DoubleBuffer v)
/*  75:    */   {
/*  76: 70 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  77: 71 */     long function_pointer = caps.glVertexAttribL2dvEXT;
/*  78: 72 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  79: 73 */     BufferChecks.checkBuffer(v, 2);
/*  80: 74 */     nglVertexAttribL2dvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/*  81:    */   }
/*  82:    */   
/*  83:    */   static native void nglVertexAttribL2dvEXT(int paramInt, long paramLong1, long paramLong2);
/*  84:    */   
/*  85:    */   public static void glVertexAttribL3EXT(int index, DoubleBuffer v)
/*  86:    */   {
/*  87: 79 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  88: 80 */     long function_pointer = caps.glVertexAttribL3dvEXT;
/*  89: 81 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  90: 82 */     BufferChecks.checkBuffer(v, 3);
/*  91: 83 */     nglVertexAttribL3dvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/*  92:    */   }
/*  93:    */   
/*  94:    */   static native void nglVertexAttribL3dvEXT(int paramInt, long paramLong1, long paramLong2);
/*  95:    */   
/*  96:    */   public static void glVertexAttribL4EXT(int index, DoubleBuffer v)
/*  97:    */   {
/*  98: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  99: 89 */     long function_pointer = caps.glVertexAttribL4dvEXT;
/* 100: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101: 91 */     BufferChecks.checkBuffer(v, 4);
/* 102: 92 */     nglVertexAttribL4dvEXT(index, MemoryUtil.getAddress(v), function_pointer);
/* 103:    */   }
/* 104:    */   
/* 105:    */   static native void nglVertexAttribL4dvEXT(int paramInt, long paramLong1, long paramLong2);
/* 106:    */   
/* 107:    */   public static void glVertexAttribLPointerEXT(int index, int size, int stride, DoubleBuffer pointer)
/* 108:    */   {
/* 109: 97 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110: 98 */     long function_pointer = caps.glVertexAttribLPointerEXT;
/* 111: 99 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:100 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 113:101 */     BufferChecks.checkDirect(pointer);
/* 114:102 */     if (LWJGLUtil.CHECKS) {
/* 115:102 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = pointer;
/* 116:    */     }
/* 117:103 */     nglVertexAttribLPointerEXT(index, size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 118:    */   }
/* 119:    */   
/* 120:    */   static native void nglVertexAttribLPointerEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 121:    */   
/* 122:    */   public static void glVertexAttribLPointerEXT(int index, int size, int stride, long pointer_buffer_offset)
/* 123:    */   {
/* 124:107 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:108 */     long function_pointer = caps.glVertexAttribLPointerEXT;
/* 126:109 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:110 */     GLChecks.ensureArrayVBOenabled(caps);
/* 128:111 */     nglVertexAttribLPointerEXTBO(index, size, 5130, stride, pointer_buffer_offset, function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglVertexAttribLPointerEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 132:    */   
/* 133:    */   public static void glGetVertexAttribLEXT(int index, int pname, DoubleBuffer params)
/* 134:    */   {
/* 135:116 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 136:117 */     long function_pointer = caps.glGetVertexAttribLdvEXT;
/* 137:118 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 138:119 */     BufferChecks.checkBuffer(params, 4);
/* 139:120 */     nglGetVertexAttribLdvEXT(index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 140:    */   }
/* 141:    */   
/* 142:    */   static native void nglGetVertexAttribLdvEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 143:    */   
/* 144:    */   public static void glVertexArrayVertexAttribLOffsetEXT(int vaobj, int buffer, int index, int size, int type, int stride, long offset)
/* 145:    */   {
/* 146:125 */     ARBVertexAttrib64bit.glVertexArrayVertexAttribLOffsetEXT(vaobj, buffer, index, size, type, stride, offset);
/* 147:    */   }
/* 148:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTVertexAttrib64bit
 * JD-Core Version:    0.7.0.1
 */