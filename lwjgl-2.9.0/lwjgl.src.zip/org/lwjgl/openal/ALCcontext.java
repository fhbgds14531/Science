/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferUtils;
/*   5:    */ 
/*   6:    */ public final class ALCcontext
/*   7:    */ {
/*   8:    */   final long context;
/*   9:    */   private boolean valid;
/*  10:    */   
/*  11:    */   ALCcontext(long context)
/*  12:    */   {
/*  13: 66 */     this.context = context;
/*  14: 67 */     this.valid = true;
/*  15:    */   }
/*  16:    */   
/*  17:    */   public boolean equals(Object context)
/*  18:    */   {
/*  19: 74 */     if ((context instanceof ALCcontext)) {
/*  20: 75 */       return ((ALCcontext)context).context == this.context;
/*  21:    */     }
/*  22: 77 */     return super.equals(context);
/*  23:    */   }
/*  24:    */   
/*  25:    */   static IntBuffer createAttributeList(int contextFrequency, int contextRefresh, int contextSynchronized)
/*  26:    */   {
/*  27: 88 */     IntBuffer attribList = BufferUtils.createIntBuffer(7);
/*  28:    */     
/*  29: 90 */     attribList.put(4103);
/*  30: 91 */     attribList.put(contextFrequency);
/*  31: 92 */     attribList.put(4104);
/*  32: 93 */     attribList.put(contextRefresh);
/*  33: 94 */     attribList.put(4105);
/*  34: 95 */     attribList.put(contextSynchronized);
/*  35: 96 */     attribList.put(0);
/*  36:    */     
/*  37: 98 */     return attribList;
/*  38:    */   }
/*  39:    */   
/*  40:    */   void setInvalid()
/*  41:    */   {
/*  42:106 */     this.valid = false;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isValid()
/*  46:    */   {
/*  47:113 */     return this.valid;
/*  48:    */   }
/*  49:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.ALCcontext
 * JD-Core Version:    0.7.0.1
 */