/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ 
/*  5:   */ abstract class LinuxPeerInfo
/*  6:   */   extends PeerInfo
/*  7:   */ {
/*  8:   */   LinuxPeerInfo()
/*  9:   */   {
/* 10:44 */     super(createHandle());
/* 11:   */   }
/* 12:   */   
/* 13:   */   private static native ByteBuffer createHandle();
/* 14:   */   
/* 15:   */   public final long getDisplay()
/* 16:   */   {
/* 17:49 */     return nGetDisplay(getHandle());
/* 18:   */   }
/* 19:   */   
/* 20:   */   private static native long nGetDisplay(ByteBuffer paramByteBuffer);
/* 21:   */   
/* 22:   */   public final long getDrawable()
/* 23:   */   {
/* 24:54 */     return nGetDrawable(getHandle());
/* 25:   */   }
/* 26:   */   
/* 27:   */   private static native long nGetDrawable(ByteBuffer paramByteBuffer);
/* 28:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxPeerInfo
 * JD-Core Version:    0.7.0.1
 */