/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ 
/*   5:    */ final class FastIntMap<V>
/*   6:    */   implements Iterable<Entry<V>>
/*   7:    */ {
/*   8:    */   private Entry[] table;
/*   9:    */   private int size;
/*  10:    */   private int mask;
/*  11:    */   private int capacity;
/*  12:    */   private int threshold;
/*  13:    */   
/*  14:    */   FastIntMap()
/*  15:    */   {
/*  16: 32 */     this(16, 0.75F);
/*  17:    */   }
/*  18:    */   
/*  19:    */   FastIntMap(int initialCapacity)
/*  20:    */   {
/*  21: 37 */     this(initialCapacity, 0.75F);
/*  22:    */   }
/*  23:    */   
/*  24:    */   FastIntMap(int initialCapacity, float loadFactor)
/*  25:    */   {
/*  26: 41 */     if (initialCapacity > 1073741824) {
/*  27: 41 */       throw new IllegalArgumentException("initialCapacity is too large.");
/*  28:    */     }
/*  29: 42 */     if (initialCapacity < 0) {
/*  30: 42 */       throw new IllegalArgumentException("initialCapacity must be greater than zero.");
/*  31:    */     }
/*  32: 43 */     if (loadFactor <= 0.0F) {
/*  33: 43 */       throw new IllegalArgumentException("initialCapacity must be greater than zero.");
/*  34:    */     }
/*  35: 44 */     this.capacity = 1;
/*  36: 45 */     while (this.capacity < initialCapacity) {
/*  37: 46 */       this.capacity <<= 1;
/*  38:    */     }
/*  39: 47 */     this.threshold = ((int)(this.capacity * loadFactor));
/*  40: 48 */     this.table = new Entry[this.capacity];
/*  41: 49 */     this.mask = (this.capacity - 1);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private int index(int key)
/*  45:    */   {
/*  46: 53 */     return index(key, this.mask);
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static int index(int key, int mask)
/*  50:    */   {
/*  51: 57 */     return key & mask;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public V put(int key, V value)
/*  55:    */   {
/*  56: 61 */     Entry<V>[] table = this.table;
/*  57: 62 */     int index = index(key);
/*  58: 65 */     for (Entry<V> e = table[index]; e != null; e = e.next) {
/*  59: 66 */       if (e.key == key)
/*  60:    */       {
/*  61: 67 */         V oldValue = e.value;
/*  62: 68 */         e.value = value;
/*  63: 69 */         return oldValue;
/*  64:    */       }
/*  65:    */     }
/*  66: 72 */     table[index] = new Entry(key, value, table[index]);
/*  67: 74 */     if (this.size++ >= this.threshold) {
/*  68: 75 */       rehash(table);
/*  69:    */     }
/*  70: 77 */     return null;
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void rehash(Entry<V>[] table)
/*  74:    */   {
/*  75: 81 */     int newCapacity = 2 * this.capacity;
/*  76: 82 */     int newMask = newCapacity - 1;
/*  77:    */     
/*  78: 84 */     Entry<V>[] newTable = new Entry[newCapacity];
/*  79: 86 */     for (int i = 0; i < table.length; i++)
/*  80:    */     {
/*  81: 87 */       Entry<V> e = table[i];
/*  82: 88 */       if (e != null) {
/*  83:    */         do
/*  84:    */         {
/*  85: 90 */           Entry<V> next = e.next;
/*  86: 91 */           int index = index(e.key, newMask);
/*  87: 92 */           e.next = newTable[index];
/*  88: 93 */           newTable[index] = e;
/*  89: 94 */           e = next;
/*  90: 95 */         } while (e != null);
/*  91:    */       }
/*  92:    */     }
/*  93: 98 */     this.table = newTable;
/*  94: 99 */     this.capacity = newCapacity;
/*  95:100 */     this.mask = newMask;
/*  96:101 */     this.threshold *= 2;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public V get(int key)
/* 100:    */   {
/* 101:105 */     int index = index(key);
/* 102:106 */     for (Entry<V> e = this.table[index]; e != null; e = e.next) {
/* 103:107 */       if (e.key == key) {
/* 104:107 */         return e.value;
/* 105:    */       }
/* 106:    */     }
/* 107:108 */     return null;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public boolean containsValue(Object value)
/* 111:    */   {
/* 112:112 */     Entry<V>[] table = this.table;
/* 113:113 */     for (int i = table.length - 1; i >= 0; i--) {
/* 114:114 */       for (Entry<V> e = table[i]; e != null; e = e.next) {
/* 115:115 */         if (e.value.equals(value)) {
/* 116:115 */           return true;
/* 117:    */         }
/* 118:    */       }
/* 119:    */     }
/* 120:116 */     return false;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean containsKey(int key)
/* 124:    */   {
/* 125:120 */     int index = index(key);
/* 126:121 */     for (Entry<V> e = this.table[index]; e != null; e = e.next) {
/* 127:122 */       if (e.key == key) {
/* 128:122 */         return true;
/* 129:    */       }
/* 130:    */     }
/* 131:123 */     return false;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public V remove(int key)
/* 135:    */   {
/* 136:127 */     int index = index(key);
/* 137:    */     
/* 138:129 */     Entry<V> prev = this.table[index];
/* 139:130 */     Entry<V> e = prev;
/* 140:131 */     while (e != null)
/* 141:    */     {
/* 142:132 */       Entry<V> next = e.next;
/* 143:133 */       if (e.key == key)
/* 144:    */       {
/* 145:134 */         this.size -= 1;
/* 146:135 */         if (prev == e) {
/* 147:136 */           this.table[index] = next;
/* 148:    */         } else {
/* 149:138 */           prev.next = next;
/* 150:    */         }
/* 151:139 */         return e.value;
/* 152:    */       }
/* 153:141 */       prev = e;
/* 154:142 */       e = next;
/* 155:    */     }
/* 156:144 */     return null;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public int size()
/* 160:    */   {
/* 161:148 */     return this.size;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean isEmpty()
/* 165:    */   {
/* 166:152 */     return this.size == 0;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void clear()
/* 170:    */   {
/* 171:156 */     Entry<V>[] table = this.table;
/* 172:157 */     for (int index = table.length - 1; index >= 0; index--) {
/* 173:158 */       table[index] = null;
/* 174:    */     }
/* 175:159 */     this.size = 0;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public FastIntMap<V>.EntryIterator iterator()
/* 179:    */   {
/* 180:163 */     return new EntryIterator();
/* 181:    */   }
/* 182:    */   
/* 183:    */   public class EntryIterator
/* 184:    */     implements Iterator<FastIntMap.Entry<V>>
/* 185:    */   {
/* 186:    */     private int nextIndex;
/* 187:    */     private FastIntMap.Entry<V> current;
/* 188:    */     
/* 189:    */     EntryIterator()
/* 190:    */     {
/* 191:172 */       reset();
/* 192:    */     }
/* 193:    */     
/* 194:    */     public void reset()
/* 195:    */     {
/* 196:176 */       this.current = null;
/* 197:    */       
/* 198:178 */       FastIntMap.Entry<V>[] table = FastIntMap.this.table;
/* 199:180 */       for (int i = table.length - 1; i >= 0; i--) {
/* 200:181 */         if (table[i] != null) {
/* 201:    */           break;
/* 202:    */         }
/* 203:    */       }
/* 204:182 */       this.nextIndex = i;
/* 205:    */     }
/* 206:    */     
/* 207:    */     public boolean hasNext()
/* 208:    */     {
/* 209:186 */       if (this.nextIndex >= 0) {
/* 210:186 */         return true;
/* 211:    */       }
/* 212:187 */       FastIntMap.Entry e = this.current;
/* 213:188 */       return (e != null) && (e.next != null);
/* 214:    */     }
/* 215:    */     
/* 216:    */     public FastIntMap.Entry<V> next()
/* 217:    */     {
/* 218:193 */       FastIntMap.Entry<V> e = this.current;
/* 219:194 */       if (e != null)
/* 220:    */       {
/* 221:195 */         e = e.next;
/* 222:196 */         if (e != null)
/* 223:    */         {
/* 224:197 */           this.current = e;
/* 225:198 */           return e;
/* 226:    */         }
/* 227:    */       }
/* 228:202 */       FastIntMap.Entry<V>[] table = FastIntMap.this.table;
/* 229:203 */       int i = this.nextIndex;
/* 230:204 */       e = this.current = table[i];
/* 231:    */       for (;;)
/* 232:    */       {
/* 233:205 */         i--;
/* 234:205 */         if (i >= 0) {
/* 235:206 */           if (table[i] != null) {
/* 236:    */             break;
/* 237:    */           }
/* 238:    */         }
/* 239:    */       }
/* 240:207 */       this.nextIndex = i;
/* 241:208 */       return e;
/* 242:    */     }
/* 243:    */     
/* 244:    */     public void remove()
/* 245:    */     {
/* 246:212 */       FastIntMap.this.remove(this.current.key);
/* 247:    */     }
/* 248:    */   }
/* 249:    */   
/* 250:    */   static final class Entry<T>
/* 251:    */   {
/* 252:    */     final int key;
/* 253:    */     T value;
/* 254:    */     Entry<T> next;
/* 255:    */     
/* 256:    */     Entry(int key, T value, Entry<T> next)
/* 257:    */     {
/* 258:223 */       this.key = key;
/* 259:224 */       this.value = value;
/* 260:225 */       this.next = next;
/* 261:    */     }
/* 262:    */     
/* 263:    */     public int getKey()
/* 264:    */     {
/* 265:229 */       return this.key;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public T getValue()
/* 269:    */     {
/* 270:233 */       return this.value;
/* 271:    */     }
/* 272:    */   }
/* 273:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.FastIntMap
 * JD-Core Version:    0.7.0.1
 */