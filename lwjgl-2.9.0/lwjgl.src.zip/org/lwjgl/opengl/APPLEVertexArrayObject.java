/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class APPLEVertexArrayObject
/*  8:   */ {
/*  9:   */   public static final int GL_VERTEX_ARRAY_BINDING_APPLE = 34229;
/* 10:   */   
/* 11:   */   public static void glBindVertexArrayAPPLE(int array)
/* 12:   */   {
/* 13:19 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:20 */     long function_pointer = caps.glBindVertexArrayAPPLE;
/* 15:21 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:22 */     nglBindVertexArrayAPPLE(array, function_pointer);
/* 17:   */   }
/* 18:   */   
/* 19:   */   static native void nglBindVertexArrayAPPLE(int paramInt, long paramLong);
/* 20:   */   
/* 21:   */   public static void glDeleteVertexArraysAPPLE(IntBuffer arrays)
/* 22:   */   {
/* 23:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 24:28 */     long function_pointer = caps.glDeleteVertexArraysAPPLE;
/* 25:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 26:30 */     BufferChecks.checkDirect(arrays);
/* 27:31 */     nglDeleteVertexArraysAPPLE(arrays.remaining(), MemoryUtil.getAddress(arrays), function_pointer);
/* 28:   */   }
/* 29:   */   
/* 30:   */   static native void nglDeleteVertexArraysAPPLE(int paramInt, long paramLong1, long paramLong2);
/* 31:   */   
/* 32:   */   public static void glDeleteVertexArraysAPPLE(int array)
/* 33:   */   {
/* 34:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 35:38 */     long function_pointer = caps.glDeleteVertexArraysAPPLE;
/* 36:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 37:40 */     nglDeleteVertexArraysAPPLE(1, APIUtil.getInt(caps, array), function_pointer);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public static void glGenVertexArraysAPPLE(IntBuffer arrays)
/* 41:   */   {
/* 42:44 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 43:45 */     long function_pointer = caps.glGenVertexArraysAPPLE;
/* 44:46 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 45:47 */     BufferChecks.checkDirect(arrays);
/* 46:48 */     nglGenVertexArraysAPPLE(arrays.remaining(), MemoryUtil.getAddress(arrays), function_pointer);
/* 47:   */   }
/* 48:   */   
/* 49:   */   static native void nglGenVertexArraysAPPLE(int paramInt, long paramLong1, long paramLong2);
/* 50:   */   
/* 51:   */   public static int glGenVertexArraysAPPLE()
/* 52:   */   {
/* 53:54 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 54:55 */     long function_pointer = caps.glGenVertexArraysAPPLE;
/* 55:56 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 56:57 */     IntBuffer arrays = APIUtil.getBufferInt(caps);
/* 57:58 */     nglGenVertexArraysAPPLE(1, MemoryUtil.getAddress(arrays), function_pointer);
/* 58:59 */     return arrays.get(0);
/* 59:   */   }
/* 60:   */   
/* 61:   */   public static boolean glIsVertexArrayAPPLE(int array)
/* 62:   */   {
/* 63:63 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 64:64 */     long function_pointer = caps.glIsVertexArrayAPPLE;
/* 65:65 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 66:66 */     boolean __result = nglIsVertexArrayAPPLE(array, function_pointer);
/* 67:67 */     return __result;
/* 68:   */   }
/* 69:   */   
/* 70:   */   static native boolean nglIsVertexArrayAPPLE(int paramInt, long paramLong);
/* 71:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEVertexArrayObject
 * JD-Core Version:    0.7.0.1
 */