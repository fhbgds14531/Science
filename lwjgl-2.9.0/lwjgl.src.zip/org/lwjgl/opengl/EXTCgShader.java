package org.lwjgl.opengl;

public final class EXTCgShader
{
  public static final int GL_CG_VERTEX_SHADER_EXT = 35086;
  public static final int GL_CG_FRAGMENT_SHADER_EXT = 35087;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTCgShader
 * JD-Core Version:    0.7.0.1
 */