/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import org.lwjgl.LWJGLException;
/*   4:    */ import org.lwjgl.LWJGLUtil;
/*   5:    */ import org.lwjgl.PointerBuffer;
/*   6:    */ 
/*   7:    */ abstract class DrawableGL
/*   8:    */   implements DrawableLWJGL
/*   9:    */ {
/*  10:    */   protected PixelFormat pixel_format;
/*  11:    */   protected PeerInfo peer_info;
/*  12:    */   protected ContextGL context;
/*  13:    */   
/*  14:    */   public void setPixelFormat(PixelFormatLWJGL pf)
/*  15:    */     throws LWJGLException
/*  16:    */   {
/*  17: 56 */     throw new UnsupportedOperationException();
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void setPixelFormat(PixelFormatLWJGL pf, ContextAttribs attribs)
/*  21:    */     throws LWJGLException
/*  22:    */   {
/*  23: 60 */     this.pixel_format = ((PixelFormat)pf);
/*  24: 61 */     this.peer_info = Display.getImplementation().createPeerInfo(this.pixel_format, attribs);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public PixelFormatLWJGL getPixelFormat()
/*  28:    */   {
/*  29: 65 */     return this.pixel_format;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public ContextGL getContext()
/*  33:    */   {
/*  34: 69 */     synchronized (GlobalLock.lock)
/*  35:    */     {
/*  36: 70 */       return this.context;
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   public ContextGL createSharedContext()
/*  41:    */     throws LWJGLException
/*  42:    */   {
/*  43: 75 */     synchronized (GlobalLock.lock)
/*  44:    */     {
/*  45: 76 */       checkDestroyed();
/*  46: 77 */       return new ContextGL(this.peer_info, this.context.getContextAttribs(), this.context);
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void checkGLError() {}
/*  51:    */   
/*  52:    */   public void setSwapInterval(int swap_interval)
/*  53:    */   {
/*  54: 86 */     ContextGL.setSwapInterval(swap_interval);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void swapBuffers()
/*  58:    */     throws LWJGLException
/*  59:    */   {}
/*  60:    */   
/*  61:    */   public void initContext(float r, float g, float b)
/*  62:    */   {
/*  63: 95 */     GL11.glClearColor(r, g, b, 0.0F);
/*  64:    */     
/*  65: 97 */     GL11.glClear(16384);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public boolean isCurrent()
/*  69:    */     throws LWJGLException
/*  70:    */   {
/*  71:101 */     synchronized (GlobalLock.lock)
/*  72:    */     {
/*  73:102 */       checkDestroyed();
/*  74:103 */       return this.context.isCurrent();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void makeCurrent()
/*  79:    */     throws LWJGLException
/*  80:    */   {
/*  81:108 */     synchronized (GlobalLock.lock)
/*  82:    */     {
/*  83:109 */       checkDestroyed();
/*  84:110 */       this.context.makeCurrent();
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void releaseContext()
/*  89:    */     throws LWJGLException
/*  90:    */   {
/*  91:115 */     synchronized (GlobalLock.lock)
/*  92:    */     {
/*  93:116 */       checkDestroyed();
/*  94:117 */       if (this.context.isCurrent()) {
/*  95:118 */         this.context.releaseCurrent();
/*  96:    */       }
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void destroy()
/* 101:    */   {
/* 102:123 */     synchronized (GlobalLock.lock)
/* 103:    */     {
/* 104:124 */       if (this.context == null) {
/* 105:125 */         return;
/* 106:    */       }
/* 107:    */       try
/* 108:    */       {
/* 109:128 */         releaseContext();
/* 110:    */         
/* 111:130 */         this.context.forceDestroy();
/* 112:131 */         this.context = null;
/* 113:133 */         if (this.peer_info != null)
/* 114:    */         {
/* 115:134 */           this.peer_info.destroy();
/* 116:135 */           this.peer_info = null;
/* 117:    */         }
/* 118:    */       }
/* 119:    */       catch (LWJGLException e)
/* 120:    */       {
/* 121:138 */         LWJGLUtil.log("Exception occurred while destroying Drawable: " + e);
/* 122:    */       }
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void setCLSharingProperties(PointerBuffer properties)
/* 127:    */     throws LWJGLException
/* 128:    */   {
/* 129:144 */     synchronized (GlobalLock.lock)
/* 130:    */     {
/* 131:145 */       checkDestroyed();
/* 132:146 */       this.context.setCLSharingProperties(properties);
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   protected final void checkDestroyed()
/* 137:    */   {
/* 138:151 */     if (this.context == null) {
/* 139:152 */       throw new IllegalStateException("The Drawable has no context available.");
/* 140:    */     }
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.DrawableGL
 * JD-Core Version:    0.7.0.1
 */