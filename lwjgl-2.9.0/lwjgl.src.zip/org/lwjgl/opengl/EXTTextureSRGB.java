package org.lwjgl.opengl;

public final class EXTTextureSRGB
{
  public static final int GL_SRGB_EXT = 35904;
  public static final int GL_SRGB8_EXT = 35905;
  public static final int GL_SRGB_ALPHA_EXT = 35906;
  public static final int GL_SRGB8_ALPHA8_EXT = 35907;
  public static final int GL_SLUMINANCE_ALPHA_EXT = 35908;
  public static final int GL_SLUMINANCE8_ALPHA8_EXT = 35909;
  public static final int GL_SLUMINANCE_EXT = 35910;
  public static final int GL_SLUMINANCE8_EXT = 35911;
  public static final int GL_COMPRESSED_SRGB_EXT = 35912;
  public static final int GL_COMPRESSED_SRGB_ALPHA_EXT = 35913;
  public static final int GL_COMPRESSED_SLUMINANCE_EXT = 35914;
  public static final int GL_COMPRESSED_SLUMINANCE_ALPHA_EXT = 35915;
  public static final int GL_COMPRESSED_SRGB_S3TC_DXT1_EXT = 35916;
  public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 35917;
  public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 35918;
  public static final int GL_COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 35919;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTextureSRGB
 * JD-Core Version:    0.7.0.1
 */