/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.LWJGLException;
/*  6:   */ 
/*  7:   */ abstract class WindowsPeerInfo
/*  8:   */   extends PeerInfo
/*  9:   */ {
/* 10:   */   protected WindowsPeerInfo()
/* 11:   */   {
/* 12:47 */     super(createHandle());
/* 13:   */   }
/* 14:   */   
/* 15:   */   private static native ByteBuffer createHandle();
/* 16:   */   
/* 17:   */   protected static int choosePixelFormat(long hdc, int origin_x, int origin_y, PixelFormat pixel_format, IntBuffer pixel_format_caps, boolean use_hdc_bpp, boolean support_window, boolean support_pbuffer, boolean double_buffered)
/* 18:   */     throws LWJGLException
/* 19:   */   {
/* 20:52 */     return nChoosePixelFormat(hdc, origin_x, origin_y, pixel_format, pixel_format_caps, use_hdc_bpp, support_window, support_pbuffer, double_buffered);
/* 21:   */   }
/* 22:   */   
/* 23:   */   private static native int nChoosePixelFormat(long paramLong, int paramInt1, int paramInt2, PixelFormat paramPixelFormat, IntBuffer paramIntBuffer, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
/* 24:   */     throws LWJGLException;
/* 25:   */   
/* 26:   */   protected static native void setPixelFormat(long paramLong, int paramInt)
/* 27:   */     throws LWJGLException;
/* 28:   */   
/* 29:   */   public final long getHdc()
/* 30:   */   {
/* 31:58 */     return nGetHdc(getHandle());
/* 32:   */   }
/* 33:   */   
/* 34:   */   private static native long nGetHdc(ByteBuffer paramByteBuffer);
/* 35:   */   
/* 36:   */   public final long getHwnd()
/* 37:   */   {
/* 38:63 */     return nGetHwnd(getHandle());
/* 39:   */   }
/* 40:   */   
/* 41:   */   private static native long nGetHwnd(ByteBuffer paramByteBuffer);
/* 42:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsPeerInfo
 * JD-Core Version:    0.7.0.1
 */