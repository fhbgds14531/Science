/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerWrapperAbstract;
/*  4:   */ 
/*  5:   */ abstract class CLObject
/*  6:   */   extends PointerWrapperAbstract
/*  7:   */ {
/*  8:   */   protected CLObject(long pointer)
/*  9:   */   {
/* 10:44 */     super(pointer);
/* 11:   */   }
/* 12:   */   
/* 13:   */   final long getPointerUnsafe()
/* 14:   */   {
/* 15:48 */     return this.pointer;
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLObject
 * JD-Core Version:    0.7.0.1
 */