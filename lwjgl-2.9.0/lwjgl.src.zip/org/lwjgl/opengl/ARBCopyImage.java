/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public final class ARBCopyImage
/*  4:   */ {
/*  5:   */   public static void glCopyImageSubData(int srcName, int srcTarget, int srcLevel, int srcX, int srcY, int srcZ, int dstName, int dstTarget, int dstLevel, int dstX, int dstY, int dstZ, int srcWidth, int srcHeight, int srcDepth)
/*  6:   */   {
/*  7:13 */     GL43.glCopyImageSubData(srcName, srcTarget, srcLevel, srcX, srcY, srcZ, dstName, dstTarget, dstLevel, dstX, dstY, dstZ, srcWidth, srcHeight, srcDepth);
/*  8:   */   }
/*  9:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBCopyImage
 * JD-Core Version:    0.7.0.1
 */