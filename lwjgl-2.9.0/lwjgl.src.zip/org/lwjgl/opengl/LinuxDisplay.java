/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.awt.Canvas;
/*    4:     */ import java.awt.event.FocusEvent;
/*    5:     */ import java.awt.event.FocusListener;
/*    6:     */ import java.io.BufferedReader;
/*    7:     */ import java.io.IOException;
/*    8:     */ import java.io.InputStreamReader;
/*    9:     */ import java.nio.ByteBuffer;
/*   10:     */ import java.nio.FloatBuffer;
/*   11:     */ import java.nio.IntBuffer;
/*   12:     */ import java.security.AccessController;
/*   13:     */ import java.security.PrivilegedAction;
/*   14:     */ import java.util.ArrayList;
/*   15:     */ import java.util.List;
/*   16:     */ import org.lwjgl.BufferUtils;
/*   17:     */ import org.lwjgl.LWJGLException;
/*   18:     */ import org.lwjgl.LWJGLUtil;
/*   19:     */ import org.lwjgl.MemoryUtil;
/*   20:     */ 
/*   21:     */ final class LinuxDisplay
/*   22:     */   implements DisplayImplementation
/*   23:     */ {
/*   24:     */   public static final int CurrentTime = 0;
/*   25:     */   public static final int GrabSuccess = 0;
/*   26:     */   public static final int AutoRepeatModeOff = 0;
/*   27:     */   public static final int AutoRepeatModeOn = 1;
/*   28:     */   public static final int AutoRepeatModeDefault = 2;
/*   29:     */   public static final int None = 0;
/*   30:     */   private static final int KeyPressMask = 1;
/*   31:     */   private static final int KeyReleaseMask = 2;
/*   32:     */   private static final int ButtonPressMask = 4;
/*   33:     */   private static final int ButtonReleaseMask = 8;
/*   34:     */   private static final int NotifyAncestor = 0;
/*   35:     */   private static final int NotifyNonlinear = 3;
/*   36:     */   private static final int NotifyPointer = 5;
/*   37:     */   private static final int NotifyPointerRoot = 6;
/*   38:     */   private static final int NotifyDetailNone = 7;
/*   39:     */   private static final int SetModeInsert = 0;
/*   40:     */   private static final int SaveSetRoot = 1;
/*   41:     */   private static final int SaveSetUnmap = 1;
/*   42:     */   private static final int X_SetInputFocus = 42;
/*   43:     */   private static final int FULLSCREEN_LEGACY = 1;
/*   44:     */   private static final int FULLSCREEN_NETWM = 2;
/*   45:     */   private static final int WINDOWED = 3;
/*   46:  97 */   private static int current_window_mode = 3;
/*   47:     */   private static final int XRANDR = 10;
/*   48:     */   private static final int XF86VIDMODE = 11;
/*   49:     */   private static final int NONE = 12;
/*   50:     */   private static long display;
/*   51:     */   private static long current_window;
/*   52:     */   private static long saved_error_handler;
/*   53:     */   private static int display_connection_usage_count;
/*   54:     */   private final LinuxEvent event_buffer;
/*   55:     */   private final LinuxEvent tmp_event_buffer;
/*   56:     */   private int current_displaymode_extension;
/*   57:     */   private long delete_atom;
/*   58:     */   private PeerInfo peer_info;
/*   59:     */   private ByteBuffer saved_gamma;
/*   60:     */   private ByteBuffer current_gamma;
/*   61:     */   private DisplayMode saved_mode;
/*   62:     */   private DisplayMode current_mode;
/*   63:     */   private XRandR.Screen[] savedXrandrConfig;
/*   64:     */   private boolean keyboard_grabbed;
/*   65:     */   private boolean pointer_grabbed;
/*   66:     */   private boolean input_released;
/*   67:     */   private boolean grab;
/*   68:     */   private boolean focused;
/*   69:     */   private boolean minimized;
/*   70:     */   private boolean dirty;
/*   71:     */   private boolean close_requested;
/*   72:     */   private long current_cursor;
/*   73:     */   private long blank_cursor;
/*   74:     */   private boolean mouseInside;
/*   75:     */   private boolean resizable;
/*   76:     */   private boolean resized;
/*   77:     */   private int window_x;
/*   78:     */   private int window_y;
/*   79:     */   private int window_width;
/*   80:     */   private int window_height;
/*   81:     */   private Canvas parent;
/*   82:     */   private long parent_window;
/*   83:     */   private static boolean xembedded;
/*   84:     */   private long parent_proxy_focus_window;
/*   85:     */   private boolean parent_focused;
/*   86:     */   private boolean parent_focus_changed;
/*   87:     */   private long last_window_focus;
/*   88:     */   private LinuxKeyboard keyboard;
/*   89:     */   private LinuxMouse mouse;
/*   90:     */   private final FocusListener focus_listener;
/*   91:     */   
/*   92:     */   LinuxDisplay()
/*   93:     */   {
/*   94: 112 */     this.event_buffer = new LinuxEvent();
/*   95: 113 */     this.tmp_event_buffer = new LinuxEvent();
/*   96:     */     
/*   97:     */ 
/*   98: 116 */     this.current_displaymode_extension = 12;
/*   99:     */     
/*  100:     */ 
/*  101:     */ 
/*  102:     */ 
/*  103:     */ 
/*  104:     */ 
/*  105:     */ 
/*  106:     */ 
/*  107:     */ 
/*  108:     */ 
/*  109:     */ 
/*  110:     */ 
/*  111:     */ 
/*  112:     */ 
/*  113:     */ 
/*  114:     */ 
/*  115:     */ 
/*  116:     */ 
/*  117:     */ 
/*  118:     */ 
/*  119:     */ 
/*  120:     */ 
/*  121:     */ 
/*  122:     */ 
/*  123:     */ 
/*  124:     */ 
/*  125: 143 */     this.mouseInside = true;
/*  126:     */     
/*  127:     */ 
/*  128:     */ 
/*  129:     */ 
/*  130:     */ 
/*  131:     */ 
/*  132:     */ 
/*  133:     */ 
/*  134:     */ 
/*  135:     */ 
/*  136:     */ 
/*  137:     */ 
/*  138:     */ 
/*  139:     */ 
/*  140: 158 */     this.last_window_focus = 0L;
/*  141:     */     
/*  142:     */ 
/*  143:     */ 
/*  144:     */ 
/*  145: 163 */     this.focus_listener = new FocusListener()
/*  146:     */     {
/*  147:     */       public void focusGained(FocusEvent e)
/*  148:     */       {
/*  149: 165 */         synchronized (GlobalLock.lock)
/*  150:     */         {
/*  151: 166 */           LinuxDisplay.this.parent_focused = true;
/*  152: 167 */           LinuxDisplay.this.parent_focus_changed = true;
/*  153:     */         }
/*  154:     */       }
/*  155:     */       
/*  156:     */       public void focusLost(FocusEvent e)
/*  157:     */       {
/*  158: 171 */         synchronized (GlobalLock.lock)
/*  159:     */         {
/*  160: 172 */           LinuxDisplay.this.parent_focused = false;
/*  161: 173 */           LinuxDisplay.this.parent_focus_changed = true;
/*  162:     */         }
/*  163:     */       }
/*  164:     */     };
/*  165:     */   }
/*  166:     */   
/*  167:     */   /* Error */
/*  168:     */   private static ByteBuffer getCurrentGammaRamp()
/*  169:     */     throws LWJGLException
/*  170:     */   {
/*  171:     */     // Byte code:
/*  172:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  173:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  174:     */     //   6: invokestatic 17	org/lwjgl/opengl/LinuxDisplay:isXF86VidModeSupported	()Z
/*  175:     */     //   9: ifeq +21 -> 30
/*  176:     */     //   12: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  177:     */     //   15: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*  178:     */     //   18: invokestatic 20	org/lwjgl/opengl/LinuxDisplay:nGetCurrentGammaRamp	(JI)Ljava/nio/ByteBuffer;
/*  179:     */     //   21: astore_0
/*  180:     */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  181:     */     //   25: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  182:     */     //   28: aload_0
/*  183:     */     //   29: areturn
/*  184:     */     //   30: aconst_null
/*  185:     */     //   31: astore_0
/*  186:     */     //   32: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  187:     */     //   35: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  188:     */     //   38: aload_0
/*  189:     */     //   39: areturn
/*  190:     */     //   40: astore_1
/*  191:     */     //   41: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  192:     */     //   44: aload_1
/*  193:     */     //   45: athrow
/*  194:     */     //   46: astore_2
/*  195:     */     //   47: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  196:     */     //   50: aload_2
/*  197:     */     //   51: athrow
/*  198:     */     // Line number table:
/*  199:     */     //   Java source line #179	-> byte code offset #0
/*  200:     */     //   Java source line #181	-> byte code offset #3
/*  201:     */     //   Java source line #183	-> byte code offset #6
/*  202:     */     //   Java source line #184	-> byte code offset #12
/*  203:     */     //   Java source line #188	-> byte code offset #22
/*  204:     */     //   Java source line #191	-> byte code offset #25
/*  205:     */     //   Java source line #186	-> byte code offset #30
/*  206:     */     //   Java source line #188	-> byte code offset #32
/*  207:     */     //   Java source line #191	-> byte code offset #35
/*  208:     */     //   Java source line #188	-> byte code offset #40
/*  209:     */     //   Java source line #191	-> byte code offset #46
/*  210:     */     // Local variable table:
/*  211:     */     //   start	length	slot	name	signature
/*  212:     */     //   21	18	0	localByteBuffer	ByteBuffer
/*  213:     */     //   40	5	1	localObject1	Object
/*  214:     */     //   46	5	2	localObject2	Object
/*  215:     */     // Exception table:
/*  216:     */     //   from	to	target	type
/*  217:     */     //   6	22	40	finally
/*  218:     */     //   30	32	40	finally
/*  219:     */     //   40	41	40	finally
/*  220:     */     //   3	25	46	finally
/*  221:     */     //   30	35	46	finally
/*  222:     */     //   40	47	46	finally
/*  223:     */   }
/*  224:     */   
/*  225:     */   private static native ByteBuffer nGetCurrentGammaRamp(long paramLong, int paramInt)
/*  226:     */     throws LWJGLException;
/*  227:     */   
/*  228:     */   private static int getBestDisplayModeExtension()
/*  229:     */   {
/*  230:     */     int result;
/*  231:     */     int result;
/*  232: 198 */     if (isXrandrSupported())
/*  233:     */     {
/*  234: 199 */       LWJGLUtil.log("Using Xrandr for display mode switching");
/*  235: 200 */       result = 10;
/*  236:     */     }
/*  237:     */     else
/*  238:     */     {
/*  239:     */       int result;
/*  240: 201 */       if (isXF86VidModeSupported())
/*  241:     */       {
/*  242: 202 */         LWJGLUtil.log("Using XF86VidMode for display mode switching");
/*  243: 203 */         result = 11;
/*  244:     */       }
/*  245:     */       else
/*  246:     */       {
/*  247: 205 */         LWJGLUtil.log("No display mode extensions available");
/*  248: 206 */         result = 12;
/*  249:     */       }
/*  250:     */     }
/*  251: 208 */     return result;
/*  252:     */   }
/*  253:     */   
/*  254:     */   /* Error */
/*  255:     */   private static boolean isXrandrSupported()
/*  256:     */   {
/*  257:     */     // Byte code:
/*  258:     */     //   0: ldc 28
/*  259:     */     //   2: invokestatic 29	org/lwjgl/opengl/Display:getPrivilegedBoolean	(Ljava/lang/String;)Z
/*  260:     */     //   5: ifeq +5 -> 10
/*  261:     */     //   8: iconst_0
/*  262:     */     //   9: ireturn
/*  263:     */     //   10: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  264:     */     //   13: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  265:     */     //   16: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  266:     */     //   19: invokestatic 30	org/lwjgl/opengl/LinuxDisplay:nIsXrandrSupported	(J)Z
/*  267:     */     //   22: istore_0
/*  268:     */     //   23: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  269:     */     //   26: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  270:     */     //   29: iload_0
/*  271:     */     //   30: ireturn
/*  272:     */     //   31: astore_1
/*  273:     */     //   32: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  274:     */     //   35: aload_1
/*  275:     */     //   36: athrow
/*  276:     */     //   37: astore_0
/*  277:     */     //   38: new 32	java/lang/StringBuilder
/*  278:     */     //   41: dup
/*  279:     */     //   42: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*  280:     */     //   45: ldc 34
/*  281:     */     //   47: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*  282:     */     //   50: aload_0
/*  283:     */     //   51: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*  284:     */     //   54: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*  285:     */     //   57: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*  286:     */     //   60: iconst_0
/*  287:     */     //   61: istore_1
/*  288:     */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  289:     */     //   65: iload_1
/*  290:     */     //   66: ireturn
/*  291:     */     //   67: astore_2
/*  292:     */     //   68: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  293:     */     //   71: aload_2
/*  294:     */     //   72: athrow
/*  295:     */     // Line number table:
/*  296:     */     //   Java source line #212	-> byte code offset #0
/*  297:     */     //   Java source line #213	-> byte code offset #8
/*  298:     */     //   Java source line #214	-> byte code offset #10
/*  299:     */     //   Java source line #216	-> byte code offset #13
/*  300:     */     //   Java source line #218	-> byte code offset #16
/*  301:     */     //   Java source line #220	-> byte code offset #23
/*  302:     */     //   Java source line #226	-> byte code offset #26
/*  303:     */     //   Java source line #220	-> byte code offset #31
/*  304:     */     //   Java source line #222	-> byte code offset #37
/*  305:     */     //   Java source line #223	-> byte code offset #38
/*  306:     */     //   Java source line #224	-> byte code offset #60
/*  307:     */     //   Java source line #226	-> byte code offset #62
/*  308:     */     // Local variable table:
/*  309:     */     //   start	length	slot	name	signature
/*  310:     */     //   22	8	0	bool1	boolean
/*  311:     */     //   37	14	0	e	LWJGLException
/*  312:     */     //   31	5	1	localObject1	Object
/*  313:     */     //   61	5	1	bool2	boolean
/*  314:     */     //   67	5	2	localObject2	Object
/*  315:     */     // Exception table:
/*  316:     */     //   from	to	target	type
/*  317:     */     //   16	23	31	finally
/*  318:     */     //   31	32	31	finally
/*  319:     */     //   13	26	37	org/lwjgl/LWJGLException
/*  320:     */     //   31	37	37	org/lwjgl/LWJGLException
/*  321:     */     //   13	26	67	finally
/*  322:     */     //   31	62	67	finally
/*  323:     */     //   67	68	67	finally
/*  324:     */   }
/*  325:     */   
/*  326:     */   private static native boolean nIsXrandrSupported(long paramLong)
/*  327:     */     throws LWJGLException;
/*  328:     */   
/*  329:     */   /* Error */
/*  330:     */   private static boolean isXF86VidModeSupported()
/*  331:     */   {
/*  332:     */     // Byte code:
/*  333:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  334:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  335:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  336:     */     //   9: invokestatic 38	org/lwjgl/opengl/LinuxDisplay:nIsXF86VidModeSupported	(J)Z
/*  337:     */     //   12: istore_0
/*  338:     */     //   13: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  339:     */     //   16: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  340:     */     //   19: iload_0
/*  341:     */     //   20: ireturn
/*  342:     */     //   21: astore_1
/*  343:     */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  344:     */     //   25: aload_1
/*  345:     */     //   26: athrow
/*  346:     */     //   27: astore_0
/*  347:     */     //   28: new 32	java/lang/StringBuilder
/*  348:     */     //   31: dup
/*  349:     */     //   32: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*  350:     */     //   35: ldc 39
/*  351:     */     //   37: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*  352:     */     //   40: aload_0
/*  353:     */     //   41: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*  354:     */     //   44: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*  355:     */     //   47: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*  356:     */     //   50: iconst_0
/*  357:     */     //   51: istore_1
/*  358:     */     //   52: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  359:     */     //   55: iload_1
/*  360:     */     //   56: ireturn
/*  361:     */     //   57: astore_2
/*  362:     */     //   58: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  363:     */     //   61: aload_2
/*  364:     */     //   62: athrow
/*  365:     */     // Line number table:
/*  366:     */     //   Java source line #232	-> byte code offset #0
/*  367:     */     //   Java source line #234	-> byte code offset #3
/*  368:     */     //   Java source line #236	-> byte code offset #6
/*  369:     */     //   Java source line #238	-> byte code offset #13
/*  370:     */     //   Java source line #244	-> byte code offset #16
/*  371:     */     //   Java source line #238	-> byte code offset #21
/*  372:     */     //   Java source line #240	-> byte code offset #27
/*  373:     */     //   Java source line #241	-> byte code offset #28
/*  374:     */     //   Java source line #242	-> byte code offset #50
/*  375:     */     //   Java source line #244	-> byte code offset #52
/*  376:     */     // Local variable table:
/*  377:     */     //   start	length	slot	name	signature
/*  378:     */     //   12	8	0	bool1	boolean
/*  379:     */     //   27	14	0	e	LWJGLException
/*  380:     */     //   21	5	1	localObject1	Object
/*  381:     */     //   51	5	1	bool2	boolean
/*  382:     */     //   57	5	2	localObject2	Object
/*  383:     */     // Exception table:
/*  384:     */     //   from	to	target	type
/*  385:     */     //   6	13	21	finally
/*  386:     */     //   21	22	21	finally
/*  387:     */     //   3	16	27	org/lwjgl/LWJGLException
/*  388:     */     //   21	27	27	org/lwjgl/LWJGLException
/*  389:     */     //   3	16	57	finally
/*  390:     */     //   21	52	57	finally
/*  391:     */     //   57	58	57	finally
/*  392:     */   }
/*  393:     */   
/*  394:     */   private static native boolean nIsXF86VidModeSupported(long paramLong)
/*  395:     */     throws LWJGLException;
/*  396:     */   
/*  397:     */   /* Error */
/*  398:     */   private static boolean isNetWMFullscreenSupported()
/*  399:     */     throws LWJGLException
/*  400:     */   {
/*  401:     */     // Byte code:
/*  402:     */     //   0: ldc 40
/*  403:     */     //   2: invokestatic 29	org/lwjgl/opengl/Display:getPrivilegedBoolean	(Ljava/lang/String;)Z
/*  404:     */     //   5: ifeq +5 -> 10
/*  405:     */     //   8: iconst_0
/*  406:     */     //   9: ireturn
/*  407:     */     //   10: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  408:     */     //   13: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  409:     */     //   16: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  410:     */     //   19: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*  411:     */     //   22: invokestatic 41	org/lwjgl/opengl/LinuxDisplay:nIsNetWMFullscreenSupported	(JI)Z
/*  412:     */     //   25: istore_0
/*  413:     */     //   26: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  414:     */     //   29: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  415:     */     //   32: iload_0
/*  416:     */     //   33: ireturn
/*  417:     */     //   34: astore_1
/*  418:     */     //   35: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  419:     */     //   38: aload_1
/*  420:     */     //   39: athrow
/*  421:     */     //   40: astore_0
/*  422:     */     //   41: new 32	java/lang/StringBuilder
/*  423:     */     //   44: dup
/*  424:     */     //   45: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*  425:     */     //   48: ldc 42
/*  426:     */     //   50: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*  427:     */     //   53: aload_0
/*  428:     */     //   54: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*  429:     */     //   57: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*  430:     */     //   60: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*  431:     */     //   63: iconst_0
/*  432:     */     //   64: istore_1
/*  433:     */     //   65: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  434:     */     //   68: iload_1
/*  435:     */     //   69: ireturn
/*  436:     */     //   70: astore_2
/*  437:     */     //   71: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  438:     */     //   74: aload_2
/*  439:     */     //   75: athrow
/*  440:     */     // Line number table:
/*  441:     */     //   Java source line #250	-> byte code offset #0
/*  442:     */     //   Java source line #251	-> byte code offset #8
/*  443:     */     //   Java source line #252	-> byte code offset #10
/*  444:     */     //   Java source line #254	-> byte code offset #13
/*  445:     */     //   Java source line #256	-> byte code offset #16
/*  446:     */     //   Java source line #258	-> byte code offset #26
/*  447:     */     //   Java source line #264	-> byte code offset #29
/*  448:     */     //   Java source line #258	-> byte code offset #34
/*  449:     */     //   Java source line #260	-> byte code offset #40
/*  450:     */     //   Java source line #261	-> byte code offset #41
/*  451:     */     //   Java source line #262	-> byte code offset #63
/*  452:     */     //   Java source line #264	-> byte code offset #65
/*  453:     */     // Local variable table:
/*  454:     */     //   start	length	slot	name	signature
/*  455:     */     //   25	8	0	bool1	boolean
/*  456:     */     //   40	14	0	e	LWJGLException
/*  457:     */     //   34	5	1	localObject1	Object
/*  458:     */     //   64	5	1	bool2	boolean
/*  459:     */     //   70	5	2	localObject2	Object
/*  460:     */     // Exception table:
/*  461:     */     //   from	to	target	type
/*  462:     */     //   16	26	34	finally
/*  463:     */     //   34	35	34	finally
/*  464:     */     //   13	29	40	org/lwjgl/LWJGLException
/*  465:     */     //   34	40	40	org/lwjgl/LWJGLException
/*  466:     */     //   13	29	70	finally
/*  467:     */     //   34	65	70	finally
/*  468:     */     //   70	71	70	finally
/*  469:     */   }
/*  470:     */   
/*  471:     */   private static native boolean nIsNetWMFullscreenSupported(long paramLong, int paramInt)
/*  472:     */     throws LWJGLException;
/*  473:     */   
/*  474:     */   static void lockAWT()
/*  475:     */   {
/*  476:     */     try
/*  477:     */     {
/*  478:     */       
/*  479:     */     }
/*  480:     */     catch (LWJGLException e)
/*  481:     */     {
/*  482: 277 */       LWJGLUtil.log("Caught exception while locking AWT: " + e);
/*  483:     */     }
/*  484:     */   }
/*  485:     */   
/*  486:     */   private static native void nLockAWT()
/*  487:     */     throws LWJGLException;
/*  488:     */   
/*  489:     */   static void unlockAWT()
/*  490:     */   {
/*  491:     */     try
/*  492:     */     {
/*  493:     */       
/*  494:     */     }
/*  495:     */     catch (LWJGLException e)
/*  496:     */     {
/*  497: 286 */       LWJGLUtil.log("Caught exception while unlocking AWT: " + e);
/*  498:     */     }
/*  499:     */   }
/*  500:     */   
/*  501:     */   private static native void nUnlockAWT()
/*  502:     */     throws LWJGLException;
/*  503:     */   
/*  504:     */   static void incDisplay()
/*  505:     */     throws LWJGLException
/*  506:     */   {
/*  507: 295 */     if (display_connection_usage_count == 0)
/*  508:     */     {
/*  509:     */       try
/*  510:     */       {
/*  511: 298 */         GLContext.loadOpenGLLibrary();
/*  512: 299 */         org.lwjgl.opengles.GLContext.loadOpenGLLibrary();
/*  513:     */       }
/*  514:     */       catch (Throwable t) {}
/*  515: 302 */       saved_error_handler = setErrorHandler();
/*  516: 303 */       display = openDisplay();
/*  517:     */     }
/*  518: 306 */     display_connection_usage_count += 1;
/*  519:     */   }
/*  520:     */   
/*  521:     */   private static native int callErrorHandler(long paramLong1, long paramLong2, long paramLong3);
/*  522:     */   
/*  523:     */   private static native long setErrorHandler();
/*  524:     */   
/*  525:     */   private static native long resetErrorHandler(long paramLong);
/*  526:     */   
/*  527:     */   private static native void synchronize(long paramLong, boolean paramBoolean);
/*  528:     */   
/*  529:     */   private static int globalErrorHandler(long display, long event_ptr, long error_display, long serial, long error_code, long request_code, long minor_code)
/*  530:     */     throws LWJGLException
/*  531:     */   {
/*  532: 314 */     if ((xembedded) && (request_code == 42L)) {
/*  533: 314 */       return 0;
/*  534:     */     }
/*  535: 316 */     if (display == getDisplay())
/*  536:     */     {
/*  537: 317 */       String error_msg = getErrorText(display, error_code);
/*  538: 318 */       throw new LWJGLException("X Error - disp: 0x" + Long.toHexString(error_display) + " serial: " + serial + " error: " + error_msg + " request_code: " + request_code + " minor_code: " + minor_code);
/*  539:     */     }
/*  540: 319 */     if (saved_error_handler != 0L) {
/*  541: 320 */       return callErrorHandler(saved_error_handler, display, event_ptr);
/*  542:     */     }
/*  543: 321 */     return 0;
/*  544:     */   }
/*  545:     */   
/*  546:     */   private static native String getErrorText(long paramLong1, long paramLong2);
/*  547:     */   
/*  548:     */   static void decDisplay() {}
/*  549:     */   
/*  550:     */   static native long openDisplay()
/*  551:     */     throws LWJGLException;
/*  552:     */   
/*  553:     */   static native void closeDisplay(long paramLong);
/*  554:     */   
/*  555:     */   private int getWindowMode(boolean fullscreen)
/*  556:     */     throws LWJGLException
/*  557:     */   {
/*  558: 346 */     if (fullscreen)
/*  559:     */     {
/*  560: 347 */       if ((this.current_displaymode_extension == 10) && (isNetWMFullscreenSupported()))
/*  561:     */       {
/*  562: 348 */         LWJGLUtil.log("Using NetWM for fullscreen window");
/*  563: 349 */         return 2;
/*  564:     */       }
/*  565: 351 */       LWJGLUtil.log("Using legacy mode for fullscreen window");
/*  566: 352 */       return 1;
/*  567:     */     }
/*  568: 355 */     return 3;
/*  569:     */   }
/*  570:     */   
/*  571:     */   static long getDisplay()
/*  572:     */   {
/*  573: 359 */     if (display_connection_usage_count <= 0) {
/*  574: 360 */       throw new InternalError("display_connection_usage_count = " + display_connection_usage_count);
/*  575:     */     }
/*  576: 361 */     return display;
/*  577:     */   }
/*  578:     */   
/*  579:     */   static int getDefaultScreen()
/*  580:     */   {
/*  581: 365 */     return nGetDefaultScreen(getDisplay());
/*  582:     */   }
/*  583:     */   
/*  584:     */   static native int nGetDefaultScreen(long paramLong);
/*  585:     */   
/*  586:     */   static long getWindow()
/*  587:     */   {
/*  588: 370 */     return current_window;
/*  589:     */   }
/*  590:     */   
/*  591:     */   private void ungrabKeyboard()
/*  592:     */   {
/*  593: 374 */     if (this.keyboard_grabbed)
/*  594:     */     {
/*  595: 375 */       nUngrabKeyboard(getDisplay());
/*  596: 376 */       this.keyboard_grabbed = false;
/*  597:     */     }
/*  598:     */   }
/*  599:     */   
/*  600:     */   static native int nUngrabKeyboard(long paramLong);
/*  601:     */   
/*  602:     */   private void grabKeyboard()
/*  603:     */   {
/*  604: 382 */     if (!this.keyboard_grabbed)
/*  605:     */     {
/*  606: 383 */       int res = nGrabKeyboard(getDisplay(), getWindow());
/*  607: 384 */       if (res == 0) {
/*  608: 385 */         this.keyboard_grabbed = true;
/*  609:     */       }
/*  610:     */     }
/*  611:     */   }
/*  612:     */   
/*  613:     */   static native int nGrabKeyboard(long paramLong1, long paramLong2);
/*  614:     */   
/*  615:     */   private void grabPointer()
/*  616:     */   {
/*  617: 391 */     if (!this.pointer_grabbed)
/*  618:     */     {
/*  619: 392 */       int result = nGrabPointer(getDisplay(), getWindow(), 0L);
/*  620: 393 */       if (result == 0)
/*  621:     */       {
/*  622: 394 */         this.pointer_grabbed = true;
/*  623: 396 */         if (isLegacyFullscreen()) {
/*  624: 397 */           nSetViewPort(getDisplay(), getWindow(), getDefaultScreen());
/*  625:     */         }
/*  626:     */       }
/*  627:     */     }
/*  628:     */   }
/*  629:     */   
/*  630:     */   static native int nGrabPointer(long paramLong1, long paramLong2, long paramLong3);
/*  631:     */   
/*  632:     */   private static native void nSetViewPort(long paramLong1, long paramLong2, int paramInt);
/*  633:     */   
/*  634:     */   private void ungrabPointer()
/*  635:     */   {
/*  636: 406 */     if (this.pointer_grabbed)
/*  637:     */     {
/*  638: 407 */       this.pointer_grabbed = false;
/*  639: 408 */       nUngrabPointer(getDisplay());
/*  640:     */     }
/*  641:     */   }
/*  642:     */   
/*  643:     */   static native int nUngrabPointer(long paramLong);
/*  644:     */   
/*  645:     */   private static boolean isFullscreen()
/*  646:     */   {
/*  647: 414 */     return (current_window_mode == 1) || (current_window_mode == 2);
/*  648:     */   }
/*  649:     */   
/*  650:     */   private boolean shouldGrab()
/*  651:     */   {
/*  652: 418 */     return (!this.input_released) && (this.grab) && (this.mouse != null);
/*  653:     */   }
/*  654:     */   
/*  655:     */   private void updatePointerGrab()
/*  656:     */   {
/*  657: 422 */     if ((isFullscreen()) || (shouldGrab())) {
/*  658: 423 */       grabPointer();
/*  659:     */     } else {
/*  660: 425 */       ungrabPointer();
/*  661:     */     }
/*  662: 427 */     updateCursor();
/*  663:     */   }
/*  664:     */   
/*  665:     */   private void updateCursor()
/*  666:     */   {
/*  667:     */     long cursor;
/*  668:     */     long cursor;
/*  669: 432 */     if (shouldGrab()) {
/*  670: 433 */       cursor = this.blank_cursor;
/*  671:     */     } else {
/*  672: 435 */       cursor = this.current_cursor;
/*  673:     */     }
/*  674: 437 */     nDefineCursor(getDisplay(), getWindow(), cursor);
/*  675:     */   }
/*  676:     */   
/*  677:     */   private static native void nDefineCursor(long paramLong1, long paramLong2, long paramLong3);
/*  678:     */   
/*  679:     */   private static boolean isLegacyFullscreen()
/*  680:     */   {
/*  681: 442 */     return current_window_mode == 1;
/*  682:     */   }
/*  683:     */   
/*  684:     */   private void updateKeyboardGrab()
/*  685:     */   {
/*  686: 446 */     if (isLegacyFullscreen()) {
/*  687: 447 */       grabKeyboard();
/*  688:     */     } else {
/*  689: 449 */       ungrabKeyboard();
/*  690:     */     }
/*  691:     */   }
/*  692:     */   
/*  693:     */   public void createWindow(DrawableLWJGL drawable, DisplayMode mode, Canvas parent, int x, int y)
/*  694:     */     throws LWJGLException
/*  695:     */   {
/*  696:     */     
/*  697:     */     try
/*  698:     */     {
/*  699: 455 */       incDisplay();
/*  700:     */       try
/*  701:     */       {
/*  702: 457 */         if ((drawable instanceof DrawableGLES)) {
/*  703: 458 */           this.peer_info = new LinuxDisplayPeerInfo();
/*  704:     */         }
/*  705: 460 */         ByteBuffer handle = this.peer_info.lockAndGetHandle();
/*  706:     */         try
/*  707:     */         {
/*  708: 462 */           current_window_mode = getWindowMode(Display.isFullscreen());
/*  709: 465 */           if (current_window_mode != 3) {
/*  710: 466 */             Compiz.setLegacyFullscreenSupport(true);
/*  711:     */           }
/*  712: 471 */           boolean undecorated = (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated")) || ((current_window_mode != 3) && (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated_fs")));
/*  713: 472 */           this.parent = parent;
/*  714: 473 */           this.parent_window = (parent != null ? getHandle(parent) : getRootWindow(getDisplay(), getDefaultScreen()));
/*  715: 474 */           this.resizable = Display.isResizable();
/*  716: 475 */           this.resized = false;
/*  717: 476 */           this.window_x = x;
/*  718: 477 */           this.window_y = y;
/*  719: 478 */           this.window_width = mode.getWidth();
/*  720: 479 */           this.window_height = mode.getHeight();
/*  721: 480 */           current_window = nCreateWindow(getDisplay(), getDefaultScreen(), handle, mode, current_window_mode, x, y, undecorated, this.parent_window, this.resizable);
/*  722: 481 */           mapRaised(getDisplay(), current_window);
/*  723: 482 */           xembedded = (parent != null) && (isAncestorXEmbedded(this.parent_window));
/*  724: 483 */           this.blank_cursor = createBlankCursor();
/*  725: 484 */           this.current_cursor = 0L;
/*  726: 485 */           this.focused = false;
/*  727: 486 */           this.input_released = false;
/*  728: 487 */           this.pointer_grabbed = false;
/*  729: 488 */           this.keyboard_grabbed = false;
/*  730: 489 */           this.close_requested = false;
/*  731: 490 */           this.grab = false;
/*  732: 491 */           this.minimized = false;
/*  733: 492 */           this.dirty = true;
/*  734: 494 */           if ((drawable instanceof DrawableGLES)) {
/*  735: 495 */             ((DrawableGLES)drawable).initialize(current_window, getDisplay(), 4, (org.lwjgl.opengles.PixelFormat)drawable.getPixelFormat());
/*  736:     */           }
/*  737: 497 */           if (parent != null)
/*  738:     */           {
/*  739: 498 */             parent.addFocusListener(this.focus_listener);
/*  740: 499 */             this.parent_focused = parent.isFocusOwner();
/*  741: 500 */             this.parent_focus_changed = true;
/*  742:     */           }
/*  743:     */         }
/*  744:     */         finally
/*  745:     */         {
/*  746: 503 */           this.peer_info.unlock();
/*  747:     */         }
/*  748:     */       }
/*  749:     */       catch (LWJGLException e)
/*  750:     */       {
/*  751: 507 */         throw e;
/*  752:     */       }
/*  753:     */     }
/*  754:     */     finally
/*  755:     */     {
/*  756: 510 */       unlockAWT();
/*  757:     */     }
/*  758:     */   }
/*  759:     */   
/*  760:     */   private static native long nCreateWindow(long paramLong1, int paramInt1, ByteBuffer paramByteBuffer, DisplayMode paramDisplayMode, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, long paramLong2, boolean paramBoolean2)
/*  761:     */     throws LWJGLException;
/*  762:     */   
/*  763:     */   private static native long getRootWindow(long paramLong, int paramInt);
/*  764:     */   
/*  765:     */   private static native boolean hasProperty(long paramLong1, long paramLong2, long paramLong3);
/*  766:     */   
/*  767:     */   private static native long getParentWindow(long paramLong1, long paramLong2)
/*  768:     */     throws LWJGLException;
/*  769:     */   
/*  770:     */   private static native int getChildCount(long paramLong1, long paramLong2)
/*  771:     */     throws LWJGLException;
/*  772:     */   
/*  773:     */   private static native void mapRaised(long paramLong1, long paramLong2);
/*  774:     */   
/*  775:     */   private static native void reparentWindow(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2);
/*  776:     */   
/*  777:     */   private static native long nGetInputFocus(long paramLong)
/*  778:     */     throws LWJGLException;
/*  779:     */   
/*  780:     */   private static native void nSetInputFocus(long paramLong1, long paramLong2, long paramLong3);
/*  781:     */   
/*  782:     */   private static native void nSetWindowSize(long paramLong1, long paramLong2, int paramInt1, int paramInt2, boolean paramBoolean);
/*  783:     */   
/*  784:     */   private static native int nGetX(long paramLong1, long paramLong2);
/*  785:     */   
/*  786:     */   private static native int nGetY(long paramLong1, long paramLong2);
/*  787:     */   
/*  788:     */   private static native int nGetWidth(long paramLong1, long paramLong2);
/*  789:     */   
/*  790:     */   private static native int nGetHeight(long paramLong1, long paramLong2);
/*  791:     */   
/*  792:     */   private static boolean isAncestorXEmbedded(long window)
/*  793:     */     throws LWJGLException
/*  794:     */   {
/*  795: 529 */     long xembed_atom = internAtom("_XEMBED_INFO", true);
/*  796: 530 */     if (xembed_atom != 0L)
/*  797:     */     {
/*  798: 531 */       long w = window;
/*  799: 532 */       while (w != 0L)
/*  800:     */       {
/*  801: 533 */         if (hasProperty(getDisplay(), w, xembed_atom)) {
/*  802: 534 */           return true;
/*  803:     */         }
/*  804: 535 */         w = getParentWindow(getDisplay(), w);
/*  805:     */       }
/*  806:     */     }
/*  807: 538 */     return false;
/*  808:     */   }
/*  809:     */   
/*  810:     */   private static long getHandle(Canvas parent)
/*  811:     */     throws LWJGLException
/*  812:     */   {
/*  813: 542 */     AWTCanvasImplementation awt_impl = AWTGLCanvas.createImplementation();
/*  814: 543 */     LinuxPeerInfo parent_peer_info = (LinuxPeerInfo)awt_impl.createPeerInfo(parent, null, null);
/*  815: 544 */     ByteBuffer parent_peer_info_handle = parent_peer_info.lockAndGetHandle();
/*  816:     */     try
/*  817:     */     {
/*  818: 546 */       return parent_peer_info.getDrawable();
/*  819:     */     }
/*  820:     */     finally
/*  821:     */     {
/*  822: 548 */       parent_peer_info.unlock();
/*  823:     */     }
/*  824:     */   }
/*  825:     */   
/*  826:     */   private void updateInputGrab()
/*  827:     */   {
/*  828: 553 */     updatePointerGrab();
/*  829: 554 */     updateKeyboardGrab();
/*  830:     */   }
/*  831:     */   
/*  832:     */   public void destroyWindow()
/*  833:     */   {
/*  834:     */     
/*  835:     */     try
/*  836:     */     {
/*  837: 560 */       if (this.parent != null) {
/*  838: 561 */         this.parent.removeFocusListener(this.focus_listener);
/*  839:     */       }
/*  840:     */       try
/*  841:     */       {
/*  842: 564 */         setNativeCursor(null);
/*  843:     */       }
/*  844:     */       catch (LWJGLException e)
/*  845:     */       {
/*  846: 566 */         LWJGLUtil.log("Failed to reset cursor: " + e.getMessage());
/*  847:     */       }
/*  848: 568 */       nDestroyCursor(getDisplay(), this.blank_cursor);
/*  849: 569 */       this.blank_cursor = 0L;
/*  850: 570 */       ungrabKeyboard();
/*  851: 571 */       nDestroyWindow(getDisplay(), getWindow());
/*  852: 572 */       decDisplay();
/*  853: 574 */       if (current_window_mode != 3) {
/*  854: 575 */         Compiz.setLegacyFullscreenSupport(false);
/*  855:     */       }
/*  856:     */     }
/*  857:     */     finally
/*  858:     */     {
/*  859: 577 */       unlockAWT();
/*  860:     */     }
/*  861:     */   }
/*  862:     */   
/*  863:     */   static native void nDestroyWindow(long paramLong1, long paramLong2);
/*  864:     */   
/*  865:     */   public void switchDisplayMode(DisplayMode mode)
/*  866:     */     throws LWJGLException
/*  867:     */   {
/*  868:     */     
/*  869:     */     try
/*  870:     */     {
/*  871: 585 */       switchDisplayModeOnTmpDisplay(mode);
/*  872: 586 */       this.current_mode = mode;
/*  873:     */     }
/*  874:     */     finally
/*  875:     */     {
/*  876: 588 */       unlockAWT();
/*  877:     */     }
/*  878:     */   }
/*  879:     */   
/*  880:     */   private void switchDisplayModeOnTmpDisplay(DisplayMode mode)
/*  881:     */     throws LWJGLException
/*  882:     */   {
/*  883:     */     
/*  884:     */     try
/*  885:     */     {
/*  886: 595 */       nSwitchDisplayMode(getDisplay(), getDefaultScreen(), this.current_displaymode_extension, mode);
/*  887:     */     }
/*  888:     */     finally
/*  889:     */     {
/*  890: 597 */       decDisplay();
/*  891:     */     }
/*  892:     */   }
/*  893:     */   
/*  894:     */   private static native void nSwitchDisplayMode(long paramLong, int paramInt1, int paramInt2, DisplayMode paramDisplayMode)
/*  895:     */     throws LWJGLException;
/*  896:     */   
/*  897:     */   private static long internAtom(String atom_name, boolean only_if_exists)
/*  898:     */     throws LWJGLException
/*  899:     */   {
/*  900:     */     
/*  901:     */     try
/*  902:     */     {
/*  903: 605 */       return nInternAtom(getDisplay(), atom_name, only_if_exists);
/*  904:     */     }
/*  905:     */     finally
/*  906:     */     {
/*  907: 607 */       decDisplay();
/*  908:     */     }
/*  909:     */   }
/*  910:     */   
/*  911:     */   static native long nInternAtom(long paramLong, String paramString, boolean paramBoolean);
/*  912:     */   
/*  913:     */   public void resetDisplayMode()
/*  914:     */   {
/*  915:     */     
/*  916:     */     try
/*  917:     */     {
/*  918: 615 */       if ((this.current_displaymode_extension == 10) && (this.savedXrandrConfig.length > 0)) {
/*  919: 617 */         AccessController.doPrivileged(new PrivilegedAction()
/*  920:     */         {
/*  921:     */           public Object run()
/*  922:     */           {
/*  923: 619 */             XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
/*  924: 620 */             return null;
/*  925:     */           }
/*  926:     */         });
/*  927:     */       } else {
/*  928: 626 */         switchDisplayMode(this.saved_mode);
/*  929:     */       }
/*  930: 628 */       if (isXF86VidModeSupported()) {
/*  931: 629 */         doSetGamma(this.saved_gamma);
/*  932:     */       }
/*  933: 631 */       Compiz.setLegacyFullscreenSupport(false);
/*  934:     */     }
/*  935:     */     catch (LWJGLException e)
/*  936:     */     {
/*  937: 633 */       LWJGLUtil.log("Caught exception while resetting mode: " + e);
/*  938:     */     }
/*  939:     */     finally
/*  940:     */     {
/*  941: 635 */       unlockAWT();
/*  942:     */     }
/*  943:     */   }
/*  944:     */   
/*  945:     */   /* Error */
/*  946:     */   public int getGammaRampLength()
/*  947:     */   {
/*  948:     */     // Byte code:
/*  949:     */     //   0: invokestatic 17	org/lwjgl/opengl/LinuxDisplay:isXF86VidModeSupported	()Z
/*  950:     */     //   3: ifne +5 -> 8
/*  951:     */     //   6: iconst_0
/*  952:     */     //   7: ireturn
/*  953:     */     //   8: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  954:     */     //   11: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/*  955:     */     //   14: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/*  956:     */     //   17: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/*  957:     */     //   20: invokestatic 167	org/lwjgl/opengl/LinuxDisplay:nGetGammaRampLength	(JI)I
/*  958:     */     //   23: istore_1
/*  959:     */     //   24: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  960:     */     //   27: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  961:     */     //   30: iload_1
/*  962:     */     //   31: ireturn
/*  963:     */     //   32: astore_1
/*  964:     */     //   33: new 32	java/lang/StringBuilder
/*  965:     */     //   36: dup
/*  966:     */     //   37: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*  967:     */     //   40: ldc 168
/*  968:     */     //   42: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*  969:     */     //   45: aload_1
/*  970:     */     //   46: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*  971:     */     //   49: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*  972:     */     //   52: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*  973:     */     //   55: iconst_0
/*  974:     */     //   56: istore_2
/*  975:     */     //   57: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  976:     */     //   60: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  977:     */     //   63: iload_2
/*  978:     */     //   64: ireturn
/*  979:     */     //   65: astore_3
/*  980:     */     //   66: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/*  981:     */     //   69: aload_3
/*  982:     */     //   70: athrow
/*  983:     */     //   71: astore_1
/*  984:     */     //   72: new 32	java/lang/StringBuilder
/*  985:     */     //   75: dup
/*  986:     */     //   76: invokespecial 33	java/lang/StringBuilder:<init>	()V
/*  987:     */     //   79: ldc 169
/*  988:     */     //   81: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*  989:     */     //   84: aload_1
/*  990:     */     //   85: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*  991:     */     //   88: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*  992:     */     //   91: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/*  993:     */     //   94: iconst_0
/*  994:     */     //   95: istore_2
/*  995:     */     //   96: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  996:     */     //   99: iload_2
/*  997:     */     //   100: ireturn
/*  998:     */     //   101: astore 4
/*  999:     */     //   103: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1000:     */     //   106: aload 4
/* 1001:     */     //   108: athrow
/* 1002:     */     // Line number table:
/* 1003:     */     //   Java source line #640	-> byte code offset #0
/* 1004:     */     //   Java source line #641	-> byte code offset #6
/* 1005:     */     //   Java source line #642	-> byte code offset #8
/* 1006:     */     //   Java source line #645	-> byte code offset #11
/* 1007:     */     //   Java source line #647	-> byte code offset #14
/* 1008:     */     //   Java source line #652	-> byte code offset #24
/* 1009:     */     //   Java source line #659	-> byte code offset #27
/* 1010:     */     //   Java source line #648	-> byte code offset #32
/* 1011:     */     //   Java source line #649	-> byte code offset #33
/* 1012:     */     //   Java source line #650	-> byte code offset #55
/* 1013:     */     //   Java source line #652	-> byte code offset #57
/* 1014:     */     //   Java source line #659	-> byte code offset #60
/* 1015:     */     //   Java source line #652	-> byte code offset #65
/* 1016:     */     //   Java source line #654	-> byte code offset #71
/* 1017:     */     //   Java source line #655	-> byte code offset #72
/* 1018:     */     //   Java source line #656	-> byte code offset #94
/* 1019:     */     //   Java source line #659	-> byte code offset #96
/* 1020:     */     // Local variable table:
/* 1021:     */     //   start	length	slot	name	signature
/* 1022:     */     //   0	109	0	this	LinuxDisplay
/* 1023:     */     //   23	8	1	i	int
/* 1024:     */     //   32	14	1	e	LWJGLException
/* 1025:     */     //   71	14	1	e	LWJGLException
/* 1026:     */     //   56	44	2	j	int
/* 1027:     */     //   65	5	3	localObject1	Object
/* 1028:     */     //   101	6	4	localObject2	Object
/* 1029:     */     // Exception table:
/* 1030:     */     //   from	to	target	type
/* 1031:     */     //   14	24	32	org/lwjgl/LWJGLException
/* 1032:     */     //   14	24	65	finally
/* 1033:     */     //   32	57	65	finally
/* 1034:     */     //   65	66	65	finally
/* 1035:     */     //   11	27	71	org/lwjgl/LWJGLException
/* 1036:     */     //   32	60	71	org/lwjgl/LWJGLException
/* 1037:     */     //   65	71	71	org/lwjgl/LWJGLException
/* 1038:     */     //   11	27	101	finally
/* 1039:     */     //   32	60	101	finally
/* 1040:     */     //   65	96	101	finally
/* 1041:     */     //   101	103	101	finally
/* 1042:     */   }
/* 1043:     */   
/* 1044:     */   private static native int nGetGammaRampLength(long paramLong, int paramInt)
/* 1045:     */     throws LWJGLException;
/* 1046:     */   
/* 1047:     */   public void setGammaRamp(FloatBuffer gammaRamp)
/* 1048:     */     throws LWJGLException
/* 1049:     */   {
/* 1050: 665 */     if (!isXF86VidModeSupported()) {
/* 1051: 666 */       throw new LWJGLException("No gamma ramp support (Missing XF86VM extension)");
/* 1052:     */     }
/* 1053: 667 */     doSetGamma(convertToNativeRamp(gammaRamp));
/* 1054:     */   }
/* 1055:     */   
/* 1056:     */   private void doSetGamma(ByteBuffer native_gamma)
/* 1057:     */     throws LWJGLException
/* 1058:     */   {
/* 1059:     */     
/* 1060:     */     try
/* 1061:     */     {
/* 1062: 673 */       setGammaRampOnTmpDisplay(native_gamma);
/* 1063: 674 */       this.current_gamma = native_gamma;
/* 1064:     */     }
/* 1065:     */     finally
/* 1066:     */     {
/* 1067: 676 */       unlockAWT();
/* 1068:     */     }
/* 1069:     */   }
/* 1070:     */   
/* 1071:     */   private static void setGammaRampOnTmpDisplay(ByteBuffer native_gamma)
/* 1072:     */     throws LWJGLException
/* 1073:     */   {
/* 1074:     */     
/* 1075:     */     try
/* 1076:     */     {
/* 1077: 683 */       nSetGammaRamp(getDisplay(), getDefaultScreen(), native_gamma);
/* 1078:     */     }
/* 1079:     */     finally
/* 1080:     */     {
/* 1081: 685 */       decDisplay();
/* 1082:     */     }
/* 1083:     */   }
/* 1084:     */   
/* 1085:     */   private static native void nSetGammaRamp(long paramLong, int paramInt, ByteBuffer paramByteBuffer)
/* 1086:     */     throws LWJGLException;
/* 1087:     */   
/* 1088:     */   private static ByteBuffer convertToNativeRamp(FloatBuffer ramp)
/* 1089:     */     throws LWJGLException
/* 1090:     */   {
/* 1091: 691 */     return nConvertToNativeRamp(ramp, ramp.position(), ramp.remaining());
/* 1092:     */   }
/* 1093:     */   
/* 1094:     */   private static native ByteBuffer nConvertToNativeRamp(FloatBuffer paramFloatBuffer, int paramInt1, int paramInt2)
/* 1095:     */     throws LWJGLException;
/* 1096:     */   
/* 1097:     */   public String getAdapter()
/* 1098:     */   {
/* 1099: 696 */     return null;
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   public String getVersion()
/* 1103:     */   {
/* 1104: 700 */     return null;
/* 1105:     */   }
/* 1106:     */   
/* 1107:     */   public DisplayMode init()
/* 1108:     */     throws LWJGLException
/* 1109:     */   {
/* 1110:     */     
/* 1111:     */     try
/* 1112:     */     {
/* 1113: 706 */       Compiz.init();
/* 1114:     */       
/* 1115: 708 */       this.delete_atom = internAtom("WM_DELETE_WINDOW", false);
/* 1116: 709 */       this.current_displaymode_extension = getBestDisplayModeExtension();
/* 1117: 710 */       if (this.current_displaymode_extension == 12) {
/* 1118: 711 */         throw new LWJGLException("No display mode extension is available");
/* 1119:     */       }
/* 1120: 712 */       DisplayMode[] modes = getAvailableDisplayModes();
/* 1121: 713 */       if ((modes == null) || (modes.length == 0)) {
/* 1122: 714 */         throw new LWJGLException("No modes available");
/* 1123:     */       }
/* 1124: 715 */       switch (this.current_displaymode_extension)
/* 1125:     */       {
/* 1126:     */       case 10: 
/* 1127: 717 */         this.savedXrandrConfig = ((XRandR.Screen[])AccessController.doPrivileged(new PrivilegedAction()
/* 1128:     */         {
/* 1129:     */           public XRandR.Screen[] run()
/* 1130:     */           {
/* 1131: 719 */             return XRandR.getConfiguration();
/* 1132:     */           }
/* 1133: 721 */         }));
/* 1134: 722 */         this.saved_mode = getCurrentXRandrMode();
/* 1135: 723 */         break;
/* 1136:     */       case 11: 
/* 1137: 725 */         this.saved_mode = modes[0];
/* 1138: 726 */         break;
/* 1139:     */       default: 
/* 1140: 728 */         throw new LWJGLException("Unknown display mode extension: " + this.current_displaymode_extension);
/* 1141:     */       }
/* 1142: 730 */       this.current_mode = this.saved_mode;
/* 1143: 731 */       this.saved_gamma = getCurrentGammaRamp();
/* 1144: 732 */       this.current_gamma = this.saved_gamma;
/* 1145: 733 */       return this.saved_mode;
/* 1146:     */     }
/* 1147:     */     finally
/* 1148:     */     {
/* 1149: 735 */       unlockAWT();
/* 1150:     */     }
/* 1151:     */   }
/* 1152:     */   
/* 1153:     */   /* Error */
/* 1154:     */   private static DisplayMode getCurrentXRandrMode()
/* 1155:     */     throws LWJGLException
/* 1156:     */   {
/* 1157:     */     // Byte code:
/* 1158:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1159:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1160:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1161:     */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/* 1162:     */     //   12: invokestatic 191	org/lwjgl/opengl/LinuxDisplay:nGetCurrentXRandrMode	(JI)Lorg/lwjgl/opengl/DisplayMode;
/* 1163:     */     //   15: astore_0
/* 1164:     */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1165:     */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1166:     */     //   22: aload_0
/* 1167:     */     //   23: areturn
/* 1168:     */     //   24: astore_1
/* 1169:     */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1170:     */     //   28: aload_1
/* 1171:     */     //   29: athrow
/* 1172:     */     //   30: astore_2
/* 1173:     */     //   31: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1174:     */     //   34: aload_2
/* 1175:     */     //   35: athrow
/* 1176:     */     // Line number table:
/* 1177:     */     //   Java source line #740	-> byte code offset #0
/* 1178:     */     //   Java source line #742	-> byte code offset #3
/* 1179:     */     //   Java source line #744	-> byte code offset #6
/* 1180:     */     //   Java source line #746	-> byte code offset #16
/* 1181:     */     //   Java source line #749	-> byte code offset #19
/* 1182:     */     //   Java source line #746	-> byte code offset #24
/* 1183:     */     //   Java source line #749	-> byte code offset #30
/* 1184:     */     // Local variable table:
/* 1185:     */     //   start	length	slot	name	signature
/* 1186:     */     //   15	8	0	localDisplayMode	DisplayMode
/* 1187:     */     //   24	5	1	localObject1	Object
/* 1188:     */     //   30	5	2	localObject2	Object
/* 1189:     */     // Exception table:
/* 1190:     */     //   from	to	target	type
/* 1191:     */     //   6	16	24	finally
/* 1192:     */     //   24	25	24	finally
/* 1193:     */     //   3	19	30	finally
/* 1194:     */     //   24	31	30	finally
/* 1195:     */   }
/* 1196:     */   
/* 1197:     */   private static native DisplayMode nGetCurrentXRandrMode(long paramLong, int paramInt)
/* 1198:     */     throws LWJGLException;
/* 1199:     */   
/* 1200:     */   public void setTitle(String title)
/* 1201:     */   {
/* 1202:     */     
/* 1203:     */     try
/* 1204:     */     {
/* 1205: 759 */       ByteBuffer titleText = MemoryUtil.encodeUTF8(title);
/* 1206: 760 */       nSetTitle(getDisplay(), getWindow(), MemoryUtil.getAddress(titleText), titleText.remaining() - 1);
/* 1207:     */     }
/* 1208:     */     finally
/* 1209:     */     {
/* 1210: 762 */       unlockAWT();
/* 1211:     */     }
/* 1212:     */   }
/* 1213:     */   
/* 1214:     */   private static native void nSetTitle(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/* 1215:     */   
/* 1216:     */   public boolean isCloseRequested()
/* 1217:     */   {
/* 1218: 768 */     boolean result = this.close_requested;
/* 1219: 769 */     this.close_requested = false;
/* 1220: 770 */     return result;
/* 1221:     */   }
/* 1222:     */   
/* 1223:     */   public boolean isVisible()
/* 1224:     */   {
/* 1225: 774 */     return !this.minimized;
/* 1226:     */   }
/* 1227:     */   
/* 1228:     */   public boolean isActive()
/* 1229:     */   {
/* 1230: 778 */     return (this.focused) || (isLegacyFullscreen());
/* 1231:     */   }
/* 1232:     */   
/* 1233:     */   public boolean isDirty()
/* 1234:     */   {
/* 1235: 782 */     boolean result = this.dirty;
/* 1236: 783 */     this.dirty = false;
/* 1237: 784 */     return result;
/* 1238:     */   }
/* 1239:     */   
/* 1240:     */   public PeerInfo createPeerInfo(PixelFormat pixel_format, ContextAttribs attribs)
/* 1241:     */     throws LWJGLException
/* 1242:     */   {
/* 1243: 788 */     this.peer_info = new LinuxDisplayPeerInfo(pixel_format);
/* 1244: 789 */     return this.peer_info;
/* 1245:     */   }
/* 1246:     */   
/* 1247:     */   private void relayEventToParent(LinuxEvent event_buffer, int event_mask)
/* 1248:     */   {
/* 1249: 793 */     this.tmp_event_buffer.copyFrom(event_buffer);
/* 1250: 794 */     this.tmp_event_buffer.setWindow(this.parent_window);
/* 1251: 795 */     this.tmp_event_buffer.sendEvent(getDisplay(), this.parent_window, true, event_mask);
/* 1252:     */   }
/* 1253:     */   
/* 1254:     */   private void relayEventToParent(LinuxEvent event_buffer)
/* 1255:     */   {
/* 1256: 799 */     if (this.parent == null) {
/* 1257: 800 */       return;
/* 1258:     */     }
/* 1259: 801 */     switch (event_buffer.getType())
/* 1260:     */     {
/* 1261:     */     case 2: 
/* 1262: 803 */       relayEventToParent(event_buffer, 1);
/* 1263: 804 */       break;
/* 1264:     */     case 3: 
/* 1265: 806 */       relayEventToParent(event_buffer, 1);
/* 1266: 807 */       break;
/* 1267:     */     case 4: 
/* 1268: 809 */       if ((xembedded) || (!this.focused)) {
/* 1269: 809 */         relayEventToParent(event_buffer, 1);
/* 1270:     */       }
/* 1271:     */       break;
/* 1272:     */     case 5: 
/* 1273: 812 */       if ((xembedded) || (!this.focused)) {
/* 1274: 812 */         relayEventToParent(event_buffer, 1);
/* 1275:     */       }
/* 1276:     */       break;
/* 1277:     */     }
/* 1278:     */   }
/* 1279:     */   
/* 1280:     */   private void processEvents()
/* 1281:     */   {
/* 1282: 820 */     while (LinuxEvent.getPending(getDisplay()) > 0)
/* 1283:     */     {
/* 1284: 821 */       this.event_buffer.nextEvent(getDisplay());
/* 1285: 822 */       long event_window = this.event_buffer.getWindow();
/* 1286: 823 */       relayEventToParent(this.event_buffer);
/* 1287: 824 */       if ((event_window == getWindow()) && (!this.event_buffer.filterEvent(event_window)) && ((this.mouse == null) || (!this.mouse.filterEvent(this.grab, shouldWarpPointer(), this.event_buffer))) && ((this.keyboard == null) || (!this.keyboard.filterEvent(this.event_buffer)))) {
/* 1288: 828 */         switch (this.event_buffer.getType())
/* 1289:     */         {
/* 1290:     */         case 9: 
/* 1291: 830 */           setFocused(true, this.event_buffer.getFocusDetail());
/* 1292: 831 */           break;
/* 1293:     */         case 10: 
/* 1294: 833 */           setFocused(false, this.event_buffer.getFocusDetail());
/* 1295: 834 */           break;
/* 1296:     */         case 33: 
/* 1297: 836 */           if ((this.event_buffer.getClientFormat() == 32) && (this.event_buffer.getClientData(0) == this.delete_atom)) {
/* 1298: 837 */             this.close_requested = true;
/* 1299:     */           }
/* 1300:     */           break;
/* 1301:     */         case 19: 
/* 1302: 840 */           this.dirty = true;
/* 1303: 841 */           this.minimized = false;
/* 1304: 842 */           break;
/* 1305:     */         case 18: 
/* 1306: 844 */           this.dirty = true;
/* 1307: 845 */           this.minimized = true;
/* 1308: 846 */           break;
/* 1309:     */         case 12: 
/* 1310: 848 */           this.dirty = true;
/* 1311: 849 */           break;
/* 1312:     */         case 22: 
/* 1313: 851 */           int x = nGetX(getDisplay(), getWindow());
/* 1314: 852 */           int y = nGetY(getDisplay(), getWindow());
/* 1315:     */           
/* 1316: 854 */           int width = nGetWidth(getDisplay(), getWindow());
/* 1317: 855 */           int height = nGetHeight(getDisplay(), getWindow());
/* 1318:     */           
/* 1319: 857 */           this.window_x = x;
/* 1320: 858 */           this.window_y = y;
/* 1321: 860 */           if ((this.window_width != width) || (this.window_height != height))
/* 1322:     */           {
/* 1323: 861 */             this.resized = true;
/* 1324: 862 */             this.window_width = width;
/* 1325: 863 */             this.window_height = height;
/* 1326:     */           }
/* 1327:     */           break;
/* 1328:     */         case 7: 
/* 1329: 868 */           this.mouseInside = true;
/* 1330: 869 */           break;
/* 1331:     */         case 8: 
/* 1332: 871 */           this.mouseInside = false;
/* 1333:     */         }
/* 1334:     */       }
/* 1335:     */     }
/* 1336:     */   }
/* 1337:     */   
/* 1338:     */   public void update()
/* 1339:     */   {
/* 1340:     */     
/* 1341:     */     try
/* 1342:     */     {
/* 1343: 882 */       processEvents();
/* 1344: 883 */       checkInput();
/* 1345:     */     }
/* 1346:     */     finally
/* 1347:     */     {
/* 1348: 885 */       unlockAWT();
/* 1349:     */     }
/* 1350:     */   }
/* 1351:     */   
/* 1352:     */   public void reshape(int x, int y, int width, int height)
/* 1353:     */   {
/* 1354:     */     
/* 1355:     */     try
/* 1356:     */     {
/* 1357: 892 */       nReshape(getDisplay(), getWindow(), x, y, width, height);
/* 1358:     */     }
/* 1359:     */     finally
/* 1360:     */     {
/* 1361: 894 */       unlockAWT();
/* 1362:     */     }
/* 1363:     */   }
/* 1364:     */   
/* 1365:     */   private static native void nReshape(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/* 1366:     */   
/* 1367:     */   /* Error */
/* 1368:     */   public DisplayMode[] getAvailableDisplayModes()
/* 1369:     */     throws LWJGLException
/* 1370:     */   {
/* 1371:     */     // Byte code:
/* 1372:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1373:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1374:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1375:     */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/* 1376:     */     //   12: aload_0
/* 1377:     */     //   13: getfield 9	org/lwjgl/opengl/LinuxDisplay:current_displaymode_extension	I
/* 1378:     */     //   16: invokestatic 222	org/lwjgl/opengl/LinuxDisplay:nGetAvailableDisplayModes	(JII)[Lorg/lwjgl/opengl/DisplayMode;
/* 1379:     */     //   19: astore_1
/* 1380:     */     //   20: aload_1
/* 1381:     */     //   21: astore_2
/* 1382:     */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1383:     */     //   25: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1384:     */     //   28: aload_2
/* 1385:     */     //   29: areturn
/* 1386:     */     //   30: astore_3
/* 1387:     */     //   31: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1388:     */     //   34: aload_3
/* 1389:     */     //   35: athrow
/* 1390:     */     //   36: astore 4
/* 1391:     */     //   38: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1392:     */     //   41: aload 4
/* 1393:     */     //   43: athrow
/* 1394:     */     // Line number table:
/* 1395:     */     //   Java source line #900	-> byte code offset #0
/* 1396:     */     //   Java source line #902	-> byte code offset #3
/* 1397:     */     //   Java source line #904	-> byte code offset #6
/* 1398:     */     //   Java source line #905	-> byte code offset #20
/* 1399:     */     //   Java source line #907	-> byte code offset #22
/* 1400:     */     //   Java source line #910	-> byte code offset #25
/* 1401:     */     //   Java source line #907	-> byte code offset #30
/* 1402:     */     //   Java source line #910	-> byte code offset #36
/* 1403:     */     // Local variable table:
/* 1404:     */     //   start	length	slot	name	signature
/* 1405:     */     //   0	44	0	this	LinuxDisplay
/* 1406:     */     //   19	2	1	modes	DisplayMode[]
/* 1407:     */     //   21	8	2	arrayOfDisplayMode1	DisplayMode[]
/* 1408:     */     //   30	5	3	localObject1	Object
/* 1409:     */     //   36	6	4	localObject2	Object
/* 1410:     */     // Exception table:
/* 1411:     */     //   from	to	target	type
/* 1412:     */     //   6	22	30	finally
/* 1413:     */     //   30	31	30	finally
/* 1414:     */     //   3	25	36	finally
/* 1415:     */     //   30	38	36	finally
/* 1416:     */   }
/* 1417:     */   
/* 1418:     */   private static native DisplayMode[] nGetAvailableDisplayModes(long paramLong, int paramInt1, int paramInt2)
/* 1419:     */     throws LWJGLException;
/* 1420:     */   
/* 1421:     */   public boolean hasWheel()
/* 1422:     */   {
/* 1423: 917 */     return true;
/* 1424:     */   }
/* 1425:     */   
/* 1426:     */   public int getButtonCount()
/* 1427:     */   {
/* 1428: 921 */     return this.mouse.getButtonCount();
/* 1429:     */   }
/* 1430:     */   
/* 1431:     */   public void createMouse()
/* 1432:     */     throws LWJGLException
/* 1433:     */   {
/* 1434:     */     
/* 1435:     */     try
/* 1436:     */     {
/* 1437: 927 */       this.mouse = new LinuxMouse(getDisplay(), getWindow(), getWindow());
/* 1438:     */     }
/* 1439:     */     finally
/* 1440:     */     {
/* 1441: 929 */       unlockAWT();
/* 1442:     */     }
/* 1443:     */   }
/* 1444:     */   
/* 1445:     */   public void destroyMouse()
/* 1446:     */   {
/* 1447: 934 */     this.mouse = null;
/* 1448: 935 */     updateInputGrab();
/* 1449:     */   }
/* 1450:     */   
/* 1451:     */   public void pollMouse(IntBuffer coord_buffer, ByteBuffer buttons)
/* 1452:     */   {
/* 1453:     */     
/* 1454:     */     try
/* 1455:     */     {
/* 1456: 941 */       this.mouse.poll(this.grab, coord_buffer, buttons);
/* 1457:     */     }
/* 1458:     */     finally
/* 1459:     */     {
/* 1460: 943 */       unlockAWT();
/* 1461:     */     }
/* 1462:     */   }
/* 1463:     */   
/* 1464:     */   public void readMouse(ByteBuffer buffer)
/* 1465:     */   {
/* 1466:     */     
/* 1467:     */     try
/* 1468:     */     {
/* 1469: 950 */       this.mouse.read(buffer);
/* 1470:     */     }
/* 1471:     */     finally
/* 1472:     */     {
/* 1473: 952 */       unlockAWT();
/* 1474:     */     }
/* 1475:     */   }
/* 1476:     */   
/* 1477:     */   public void setCursorPosition(int x, int y)
/* 1478:     */   {
/* 1479:     */     
/* 1480:     */     try
/* 1481:     */     {
/* 1482: 959 */       this.mouse.setCursorPosition(x, y);
/* 1483:     */     }
/* 1484:     */     finally
/* 1485:     */     {
/* 1486: 961 */       unlockAWT();
/* 1487:     */     }
/* 1488:     */   }
/* 1489:     */   
/* 1490:     */   private void checkInput()
/* 1491:     */   {
/* 1492: 966 */     if (this.parent == null) {
/* 1493: 966 */       return;
/* 1494:     */     }
/* 1495: 968 */     if (xembedded)
/* 1496:     */     {
/* 1497: 969 */       long current_focus_window = 0L;
/* 1498: 971 */       if ((this.last_window_focus != current_focus_window) || (this.parent_focused != this.focused)) {
/* 1499: 972 */         if (isParentWindowActive(current_focus_window))
/* 1500:     */         {
/* 1501: 973 */           if (this.parent_focused)
/* 1502:     */           {
/* 1503: 974 */             nSetInputFocus(getDisplay(), current_window, 0L);
/* 1504: 975 */             this.last_window_focus = current_window;
/* 1505: 976 */             this.focused = true;
/* 1506:     */           }
/* 1507:     */           else
/* 1508:     */           {
/* 1509: 980 */             nSetInputFocus(getDisplay(), this.parent_proxy_focus_window, 0L);
/* 1510: 981 */             this.last_window_focus = this.parent_proxy_focus_window;
/* 1511: 982 */             this.focused = false;
/* 1512:     */           }
/* 1513:     */         }
/* 1514:     */         else
/* 1515:     */         {
/* 1516: 986 */           this.last_window_focus = current_focus_window;
/* 1517: 987 */           this.focused = false;
/* 1518:     */         }
/* 1519:     */       }
/* 1520:     */     }
/* 1521: 992 */     else if ((this.parent_focus_changed) && (this.parent_focused))
/* 1522:     */     {
/* 1523: 993 */       setInputFocusUnsafe(getWindow());
/* 1524: 994 */       this.parent_focus_changed = false;
/* 1525:     */     }
/* 1526:     */   }
/* 1527:     */   
/* 1528:     */   private void setInputFocusUnsafe(long window)
/* 1529:     */   {
/* 1530:     */     try
/* 1531:     */     {
/* 1532:1001 */       nSetInputFocus(getDisplay(), window, 0L);
/* 1533:1002 */       nSync(getDisplay(), false);
/* 1534:     */     }
/* 1535:     */     catch (LWJGLException e)
/* 1536:     */     {
/* 1537:1005 */       LWJGLUtil.log("Got exception while trying to focus: " + e);
/* 1538:     */     }
/* 1539:     */   }
/* 1540:     */   
/* 1541:     */   private static native void nSync(long paramLong, boolean paramBoolean)
/* 1542:     */     throws LWJGLException;
/* 1543:     */   
/* 1544:     */   private boolean isParentWindowActive(long window)
/* 1545:     */   {
/* 1546:     */     try
/* 1547:     */     {
/* 1548:1024 */       if (window == current_window) {
/* 1549:1024 */         return true;
/* 1550:     */       }
/* 1551:1027 */       if (getChildCount(getDisplay(), window) != 0) {
/* 1552:1027 */         return false;
/* 1553:     */       }
/* 1554:1030 */       long parent_window = getParentWindow(getDisplay(), window);
/* 1555:1033 */       if (parent_window == 0L) {
/* 1556:1033 */         return false;
/* 1557:     */       }
/* 1558:1036 */       long w = current_window;
/* 1559:1038 */       while (w != 0L)
/* 1560:     */       {
/* 1561:1039 */         w = getParentWindow(getDisplay(), w);
/* 1562:1040 */         if (w == parent_window)
/* 1563:     */         {
/* 1564:1041 */           this.parent_proxy_focus_window = window;
/* 1565:1042 */           return true;
/* 1566:     */         }
/* 1567:     */       }
/* 1568:     */     }
/* 1569:     */     catch (LWJGLException e)
/* 1570:     */     {
/* 1571:1046 */       LWJGLUtil.log("Failed to detect if parent window is active: " + e.getMessage());
/* 1572:1047 */       return true;
/* 1573:     */     }
/* 1574:1050 */     return false;
/* 1575:     */   }
/* 1576:     */   
/* 1577:     */   private void setFocused(boolean got_focus, int focus_detail)
/* 1578:     */   {
/* 1579:1054 */     if ((this.focused == got_focus) || (focus_detail == 7) || (focus_detail == 5) || (focus_detail == 6) || (xembedded)) {
/* 1580:1055 */       return;
/* 1581:     */     }
/* 1582:1056 */     this.focused = got_focus;
/* 1583:1058 */     if (this.focused) {
/* 1584:1059 */       acquireInput();
/* 1585:     */     } else {
/* 1586:1062 */       releaseInput();
/* 1587:     */     }
/* 1588:     */   }
/* 1589:     */   
/* 1590:     */   private void releaseInput()
/* 1591:     */   {
/* 1592:1067 */     if ((isLegacyFullscreen()) || (this.input_released)) {
/* 1593:1068 */       return;
/* 1594:     */     }
/* 1595:1069 */     this.input_released = true;
/* 1596:1070 */     updateInputGrab();
/* 1597:1071 */     if (current_window_mode == 2)
/* 1598:     */     {
/* 1599:1072 */       nIconifyWindow(getDisplay(), getWindow(), getDefaultScreen());
/* 1600:     */       try
/* 1601:     */       {
/* 1602:1074 */         if ((this.current_displaymode_extension == 10) && (this.savedXrandrConfig.length > 0)) {
/* 1603:1076 */           AccessController.doPrivileged(new PrivilegedAction()
/* 1604:     */           {
/* 1605:     */             public Object run()
/* 1606:     */             {
/* 1607:1078 */               XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
/* 1608:1079 */               return null;
/* 1609:     */             }
/* 1610:     */           });
/* 1611:     */         } else {
/* 1612:1085 */           switchDisplayModeOnTmpDisplay(this.saved_mode);
/* 1613:     */         }
/* 1614:1087 */         setGammaRampOnTmpDisplay(this.saved_gamma);
/* 1615:     */       }
/* 1616:     */       catch (LWJGLException e)
/* 1617:     */       {
/* 1618:1089 */         LWJGLUtil.log("Failed to restore saved mode: " + e.getMessage());
/* 1619:     */       }
/* 1620:     */     }
/* 1621:     */   }
/* 1622:     */   
/* 1623:     */   private static native void nIconifyWindow(long paramLong1, long paramLong2, int paramInt);
/* 1624:     */   
/* 1625:     */   private void acquireInput()
/* 1626:     */   {
/* 1627:1096 */     if ((isLegacyFullscreen()) || (!this.input_released)) {
/* 1628:1097 */       return;
/* 1629:     */     }
/* 1630:1098 */     this.input_released = false;
/* 1631:1099 */     updateInputGrab();
/* 1632:1100 */     if (current_window_mode == 2) {
/* 1633:     */       try
/* 1634:     */       {
/* 1635:1102 */         switchDisplayModeOnTmpDisplay(this.current_mode);
/* 1636:1103 */         setGammaRampOnTmpDisplay(this.current_gamma);
/* 1637:     */       }
/* 1638:     */       catch (LWJGLException e)
/* 1639:     */       {
/* 1640:1105 */         LWJGLUtil.log("Failed to restore mode: " + e.getMessage());
/* 1641:     */       }
/* 1642:     */     }
/* 1643:     */   }
/* 1644:     */   
/* 1645:     */   public void grabMouse(boolean new_grab)
/* 1646:     */   {
/* 1647:     */     
/* 1648:     */     try
/* 1649:     */     {
/* 1650:1113 */       if (new_grab != this.grab)
/* 1651:     */       {
/* 1652:1114 */         this.grab = new_grab;
/* 1653:1115 */         updateInputGrab();
/* 1654:1116 */         this.mouse.changeGrabbed(this.grab, shouldWarpPointer());
/* 1655:     */       }
/* 1656:     */     }
/* 1657:     */     finally
/* 1658:     */     {
/* 1659:1119 */       unlockAWT();
/* 1660:     */     }
/* 1661:     */   }
/* 1662:     */   
/* 1663:     */   private boolean shouldWarpPointer()
/* 1664:     */   {
/* 1665:1124 */     return (this.pointer_grabbed) && (shouldGrab());
/* 1666:     */   }
/* 1667:     */   
/* 1668:     */   /* Error */
/* 1669:     */   public int getNativeCursorCapabilities()
/* 1670:     */   {
/* 1671:     */     // Byte code:
/* 1672:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1673:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1674:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1675:     */     //   9: invokestatic 246	org/lwjgl/opengl/LinuxDisplay:nGetNativeCursorCapabilities	(J)I
/* 1676:     */     //   12: istore_1
/* 1677:     */     //   13: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1678:     */     //   16: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1679:     */     //   19: iload_1
/* 1680:     */     //   20: ireturn
/* 1681:     */     //   21: astore_2
/* 1682:     */     //   22: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1683:     */     //   25: aload_2
/* 1684:     */     //   26: athrow
/* 1685:     */     //   27: astore_1
/* 1686:     */     //   28: new 247	java/lang/RuntimeException
/* 1687:     */     //   31: dup
/* 1688:     */     //   32: aload_1
/* 1689:     */     //   33: invokespecial 248	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
/* 1690:     */     //   36: athrow
/* 1691:     */     //   37: astore_3
/* 1692:     */     //   38: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1693:     */     //   41: aload_3
/* 1694:     */     //   42: athrow
/* 1695:     */     // Line number table:
/* 1696:     */     //   Java source line #1128	-> byte code offset #0
/* 1697:     */     //   Java source line #1130	-> byte code offset #3
/* 1698:     */     //   Java source line #1132	-> byte code offset #6
/* 1699:     */     //   Java source line #1134	-> byte code offset #13
/* 1700:     */     //   Java source line #1139	-> byte code offset #16
/* 1701:     */     //   Java source line #1134	-> byte code offset #21
/* 1702:     */     //   Java source line #1136	-> byte code offset #27
/* 1703:     */     //   Java source line #1137	-> byte code offset #28
/* 1704:     */     //   Java source line #1139	-> byte code offset #37
/* 1705:     */     // Local variable table:
/* 1706:     */     //   start	length	slot	name	signature
/* 1707:     */     //   0	43	0	this	LinuxDisplay
/* 1708:     */     //   12	8	1	i	int
/* 1709:     */     //   27	6	1	e	LWJGLException
/* 1710:     */     //   21	5	2	localObject1	Object
/* 1711:     */     //   37	5	3	localObject2	Object
/* 1712:     */     // Exception table:
/* 1713:     */     //   from	to	target	type
/* 1714:     */     //   6	13	21	finally
/* 1715:     */     //   21	22	21	finally
/* 1716:     */     //   3	16	27	org/lwjgl/LWJGLException
/* 1717:     */     //   21	27	27	org/lwjgl/LWJGLException
/* 1718:     */     //   3	16	37	finally
/* 1719:     */     //   21	38	37	finally
/* 1720:     */   }
/* 1721:     */   
/* 1722:     */   private static native int nGetNativeCursorCapabilities(long paramLong)
/* 1723:     */     throws LWJGLException;
/* 1724:     */   
/* 1725:     */   public void setNativeCursor(Object handle)
/* 1726:     */     throws LWJGLException
/* 1727:     */   {
/* 1728:1145 */     this.current_cursor = getCursorHandle(handle);
/* 1729:1146 */     lockAWT();
/* 1730:     */     try
/* 1731:     */     {
/* 1732:1148 */       updateCursor();
/* 1733:     */     }
/* 1734:     */     finally
/* 1735:     */     {
/* 1736:1150 */       unlockAWT();
/* 1737:     */     }
/* 1738:     */   }
/* 1739:     */   
/* 1740:     */   /* Error */
/* 1741:     */   public int getMinCursorSize()
/* 1742:     */   {
/* 1743:     */     // Byte code:
/* 1744:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1745:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1746:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1747:     */     //   9: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/* 1748:     */     //   12: invokestatic 250	org/lwjgl/opengl/LinuxDisplay:nGetMinCursorSize	(JJ)I
/* 1749:     */     //   15: istore_1
/* 1750:     */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1751:     */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1752:     */     //   22: iload_1
/* 1753:     */     //   23: ireturn
/* 1754:     */     //   24: astore_2
/* 1755:     */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1756:     */     //   28: aload_2
/* 1757:     */     //   29: athrow
/* 1758:     */     //   30: astore_1
/* 1759:     */     //   31: new 32	java/lang/StringBuilder
/* 1760:     */     //   34: dup
/* 1761:     */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/* 1762:     */     //   38: ldc 251
/* 1763:     */     //   40: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/* 1764:     */     //   43: aload_1
/* 1765:     */     //   44: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/* 1766:     */     //   47: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/* 1767:     */     //   50: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/* 1768:     */     //   53: iconst_0
/* 1769:     */     //   54: istore_2
/* 1770:     */     //   55: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1771:     */     //   58: iload_2
/* 1772:     */     //   59: ireturn
/* 1773:     */     //   60: astore_3
/* 1774:     */     //   61: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1775:     */     //   64: aload_3
/* 1776:     */     //   65: athrow
/* 1777:     */     // Line number table:
/* 1778:     */     //   Java source line #1155	-> byte code offset #0
/* 1779:     */     //   Java source line #1157	-> byte code offset #3
/* 1780:     */     //   Java source line #1159	-> byte code offset #6
/* 1781:     */     //   Java source line #1161	-> byte code offset #16
/* 1782:     */     //   Java source line #1167	-> byte code offset #19
/* 1783:     */     //   Java source line #1161	-> byte code offset #24
/* 1784:     */     //   Java source line #1163	-> byte code offset #30
/* 1785:     */     //   Java source line #1164	-> byte code offset #31
/* 1786:     */     //   Java source line #1165	-> byte code offset #53
/* 1787:     */     //   Java source line #1167	-> byte code offset #55
/* 1788:     */     // Local variable table:
/* 1789:     */     //   start	length	slot	name	signature
/* 1790:     */     //   0	66	0	this	LinuxDisplay
/* 1791:     */     //   15	8	1	i	int
/* 1792:     */     //   30	14	1	e	LWJGLException
/* 1793:     */     //   24	5	2	localObject1	Object
/* 1794:     */     //   54	5	2	j	int
/* 1795:     */     //   60	5	3	localObject2	Object
/* 1796:     */     // Exception table:
/* 1797:     */     //   from	to	target	type
/* 1798:     */     //   6	16	24	finally
/* 1799:     */     //   24	25	24	finally
/* 1800:     */     //   3	19	30	org/lwjgl/LWJGLException
/* 1801:     */     //   24	30	30	org/lwjgl/LWJGLException
/* 1802:     */     //   3	19	60	finally
/* 1803:     */     //   24	55	60	finally
/* 1804:     */     //   60	61	60	finally
/* 1805:     */   }
/* 1806:     */   
/* 1807:     */   private static native int nGetMinCursorSize(long paramLong1, long paramLong2);
/* 1808:     */   
/* 1809:     */   /* Error */
/* 1810:     */   public int getMaxCursorSize()
/* 1811:     */   {
/* 1812:     */     // Byte code:
/* 1813:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1814:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1815:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1816:     */     //   9: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/* 1817:     */     //   12: invokestatic 252	org/lwjgl/opengl/LinuxDisplay:nGetMaxCursorSize	(JJ)I
/* 1818:     */     //   15: istore_1
/* 1819:     */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1820:     */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1821:     */     //   22: iload_1
/* 1822:     */     //   23: ireturn
/* 1823:     */     //   24: astore_2
/* 1824:     */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1825:     */     //   28: aload_2
/* 1826:     */     //   29: athrow
/* 1827:     */     //   30: astore_1
/* 1828:     */     //   31: new 32	java/lang/StringBuilder
/* 1829:     */     //   34: dup
/* 1830:     */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/* 1831:     */     //   38: ldc 253
/* 1832:     */     //   40: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/* 1833:     */     //   43: aload_1
/* 1834:     */     //   44: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/* 1835:     */     //   47: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/* 1836:     */     //   50: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/* 1837:     */     //   53: iconst_0
/* 1838:     */     //   54: istore_2
/* 1839:     */     //   55: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1840:     */     //   58: iload_2
/* 1841:     */     //   59: ireturn
/* 1842:     */     //   60: astore_3
/* 1843:     */     //   61: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1844:     */     //   64: aload_3
/* 1845:     */     //   65: athrow
/* 1846:     */     // Line number table:
/* 1847:     */     //   Java source line #1173	-> byte code offset #0
/* 1848:     */     //   Java source line #1175	-> byte code offset #3
/* 1849:     */     //   Java source line #1177	-> byte code offset #6
/* 1850:     */     //   Java source line #1179	-> byte code offset #16
/* 1851:     */     //   Java source line #1185	-> byte code offset #19
/* 1852:     */     //   Java source line #1179	-> byte code offset #24
/* 1853:     */     //   Java source line #1181	-> byte code offset #30
/* 1854:     */     //   Java source line #1182	-> byte code offset #31
/* 1855:     */     //   Java source line #1183	-> byte code offset #53
/* 1856:     */     //   Java source line #1185	-> byte code offset #55
/* 1857:     */     // Local variable table:
/* 1858:     */     //   start	length	slot	name	signature
/* 1859:     */     //   0	66	0	this	LinuxDisplay
/* 1860:     */     //   15	8	1	i	int
/* 1861:     */     //   30	14	1	e	LWJGLException
/* 1862:     */     //   24	5	2	localObject1	Object
/* 1863:     */     //   54	5	2	j	int
/* 1864:     */     //   60	5	3	localObject2	Object
/* 1865:     */     // Exception table:
/* 1866:     */     //   from	to	target	type
/* 1867:     */     //   6	16	24	finally
/* 1868:     */     //   24	25	24	finally
/* 1869:     */     //   3	19	30	org/lwjgl/LWJGLException
/* 1870:     */     //   24	30	30	org/lwjgl/LWJGLException
/* 1871:     */     //   3	19	60	finally
/* 1872:     */     //   24	55	60	finally
/* 1873:     */     //   60	61	60	finally
/* 1874:     */   }
/* 1875:     */   
/* 1876:     */   private static native int nGetMaxCursorSize(long paramLong1, long paramLong2);
/* 1877:     */   
/* 1878:     */   public void createKeyboard()
/* 1879:     */     throws LWJGLException
/* 1880:     */   {
/* 1881:     */     
/* 1882:     */     try
/* 1883:     */     {
/* 1884:1194 */       this.keyboard = new LinuxKeyboard(getDisplay(), getWindow());
/* 1885:     */     }
/* 1886:     */     finally
/* 1887:     */     {
/* 1888:1196 */       unlockAWT();
/* 1889:     */     }
/* 1890:     */   }
/* 1891:     */   
/* 1892:     */   public void destroyKeyboard()
/* 1893:     */   {
/* 1894:     */     
/* 1895:     */     try
/* 1896:     */     {
/* 1897:1203 */       this.keyboard.destroy(getDisplay());
/* 1898:1204 */       this.keyboard = null;
/* 1899:     */     }
/* 1900:     */     finally
/* 1901:     */     {
/* 1902:1206 */       unlockAWT();
/* 1903:     */     }
/* 1904:     */   }
/* 1905:     */   
/* 1906:     */   public void pollKeyboard(ByteBuffer keyDownBuffer)
/* 1907:     */   {
/* 1908:     */     
/* 1909:     */     try
/* 1910:     */     {
/* 1911:1213 */       this.keyboard.poll(keyDownBuffer);
/* 1912:     */     }
/* 1913:     */     finally
/* 1914:     */     {
/* 1915:1215 */       unlockAWT();
/* 1916:     */     }
/* 1917:     */   }
/* 1918:     */   
/* 1919:     */   public void readKeyboard(ByteBuffer buffer)
/* 1920:     */   {
/* 1921:     */     
/* 1922:     */     try
/* 1923:     */     {
/* 1924:1222 */       this.keyboard.read(buffer);
/* 1925:     */     }
/* 1926:     */     finally
/* 1927:     */     {
/* 1928:1224 */       unlockAWT();
/* 1929:     */     }
/* 1930:     */   }
/* 1931:     */   
/* 1932:     */   private static native long nCreateCursor(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, IntBuffer paramIntBuffer1, int paramInt6, IntBuffer paramIntBuffer2, int paramInt7)
/* 1933:     */     throws LWJGLException;
/* 1934:     */   
/* 1935:     */   private static long createBlankCursor()
/* 1936:     */   {
/* 1937:1231 */     return nCreateBlankCursor(getDisplay(), getWindow());
/* 1938:     */   }
/* 1939:     */   
/* 1940:     */   static native long nCreateBlankCursor(long paramLong1, long paramLong2);
/* 1941:     */   
/* 1942:     */   /* Error */
/* 1943:     */   public Object createCursor(int width, int height, int xHotspot, int yHotspot, int numImages, IntBuffer images, IntBuffer delays)
/* 1944:     */     throws LWJGLException
/* 1945:     */   {
/* 1946:     */     // Byte code:
/* 1947:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 1948:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 1949:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 1950:     */     //   9: iload_1
/* 1951:     */     //   10: iload_2
/* 1952:     */     //   11: iload_3
/* 1953:     */     //   12: iload 4
/* 1954:     */     //   14: iload 5
/* 1955:     */     //   16: aload 6
/* 1956:     */     //   18: aload 6
/* 1957:     */     //   20: invokevirtual 260	java/nio/IntBuffer:position	()I
/* 1958:     */     //   23: aload 7
/* 1959:     */     //   25: aload 7
/* 1960:     */     //   27: ifnull +11 -> 38
/* 1961:     */     //   30: aload 7
/* 1962:     */     //   32: invokevirtual 260	java/nio/IntBuffer:position	()I
/* 1963:     */     //   35: goto +4 -> 39
/* 1964:     */     //   38: iconst_m1
/* 1965:     */     //   39: invokestatic 261	org/lwjgl/opengl/LinuxDisplay:nCreateCursor	(JIIIIILjava/nio/IntBuffer;ILjava/nio/IntBuffer;I)J
/* 1966:     */     //   42: lstore 8
/* 1967:     */     //   44: lload 8
/* 1968:     */     //   46: invokestatic 262	java/lang/Long:valueOf	(J)Ljava/lang/Long;
/* 1969:     */     //   49: astore 10
/* 1970:     */     //   51: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1971:     */     //   54: aload 10
/* 1972:     */     //   56: areturn
/* 1973:     */     //   57: astore 8
/* 1974:     */     //   59: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 1975:     */     //   62: aload 8
/* 1976:     */     //   64: athrow
/* 1977:     */     //   65: astore 11
/* 1978:     */     //   67: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 1979:     */     //   70: aload 11
/* 1980:     */     //   72: athrow
/* 1981:     */     // Line number table:
/* 1982:     */     //   Java source line #1236	-> byte code offset #0
/* 1983:     */     //   Java source line #1238	-> byte code offset #3
/* 1984:     */     //   Java source line #1240	-> byte code offset #6
/* 1985:     */     //   Java source line #1241	-> byte code offset #44
/* 1986:     */     //   Java source line #1247	-> byte code offset #51
/* 1987:     */     //   Java source line #1242	-> byte code offset #57
/* 1988:     */     //   Java source line #1243	-> byte code offset #59
/* 1989:     */     //   Java source line #1244	-> byte code offset #62
/* 1990:     */     //   Java source line #1247	-> byte code offset #65
/* 1991:     */     // Local variable table:
/* 1992:     */     //   start	length	slot	name	signature
/* 1993:     */     //   0	73	0	this	LinuxDisplay
/* 1994:     */     //   0	73	1	width	int
/* 1995:     */     //   0	73	2	height	int
/* 1996:     */     //   0	73	3	xHotspot	int
/* 1997:     */     //   0	73	4	yHotspot	int
/* 1998:     */     //   0	73	5	numImages	int
/* 1999:     */     //   0	73	6	images	IntBuffer
/* 2000:     */     //   0	73	7	delays	IntBuffer
/* 2001:     */     //   42	3	8	cursor	long
/* 2002:     */     //   57	6	8	e	LWJGLException
/* 2003:     */     //   49	6	10	localLong	Long
/* 2004:     */     //   65	6	11	localObject	Object
/* 2005:     */     // Exception table:
/* 2006:     */     //   from	to	target	type
/* 2007:     */     //   6	51	57	org/lwjgl/LWJGLException
/* 2008:     */     //   3	51	65	finally
/* 2009:     */     //   57	67	65	finally
/* 2010:     */   }
/* 2011:     */   
/* 2012:     */   private static long getCursorHandle(Object cursor_handle)
/* 2013:     */   {
/* 2014:1252 */     return cursor_handle != null ? ((Long)cursor_handle).longValue() : 0L;
/* 2015:     */   }
/* 2016:     */   
/* 2017:     */   public void destroyCursor(Object cursorHandle)
/* 2018:     */   {
/* 2019:     */     
/* 2020:     */     try
/* 2021:     */     {
/* 2022:1258 */       nDestroyCursor(getDisplay(), getCursorHandle(cursorHandle));
/* 2023:1259 */       decDisplay();
/* 2024:     */     }
/* 2025:     */     finally
/* 2026:     */     {
/* 2027:1261 */       unlockAWT();
/* 2028:     */     }
/* 2029:     */   }
/* 2030:     */   
/* 2031:     */   static native void nDestroyCursor(long paramLong1, long paramLong2);
/* 2032:     */   
/* 2033:     */   /* Error */
/* 2034:     */   public int getPbufferCapabilities()
/* 2035:     */   {
/* 2036:     */     // Byte code:
/* 2037:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 2038:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 2039:     */     //   6: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 2040:     */     //   9: invokestatic 19	org/lwjgl/opengl/LinuxDisplay:getDefaultScreen	()I
/* 2041:     */     //   12: invokestatic 265	org/lwjgl/opengl/LinuxDisplay:nGetPbufferCapabilities	(JI)I
/* 2042:     */     //   15: istore_1
/* 2043:     */     //   16: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 2044:     */     //   19: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2045:     */     //   22: iload_1
/* 2046:     */     //   23: ireturn
/* 2047:     */     //   24: astore_2
/* 2048:     */     //   25: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 2049:     */     //   28: aload_2
/* 2050:     */     //   29: athrow
/* 2051:     */     //   30: astore_1
/* 2052:     */     //   31: new 32	java/lang/StringBuilder
/* 2053:     */     //   34: dup
/* 2054:     */     //   35: invokespecial 33	java/lang/StringBuilder:<init>	()V
/* 2055:     */     //   38: ldc_w 266
/* 2056:     */     //   41: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/* 2057:     */     //   44: aload_1
/* 2058:     */     //   45: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/* 2059:     */     //   48: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/* 2060:     */     //   51: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/* 2061:     */     //   54: iconst_0
/* 2062:     */     //   55: istore_2
/* 2063:     */     //   56: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2064:     */     //   59: iload_2
/* 2065:     */     //   60: ireturn
/* 2066:     */     //   61: astore_3
/* 2067:     */     //   62: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2068:     */     //   65: aload_3
/* 2069:     */     //   66: athrow
/* 2070:     */     // Line number table:
/* 2071:     */     //   Java source line #1267	-> byte code offset #0
/* 2072:     */     //   Java source line #1269	-> byte code offset #3
/* 2073:     */     //   Java source line #1271	-> byte code offset #6
/* 2074:     */     //   Java source line #1273	-> byte code offset #16
/* 2075:     */     //   Java source line #1279	-> byte code offset #19
/* 2076:     */     //   Java source line #1273	-> byte code offset #24
/* 2077:     */     //   Java source line #1275	-> byte code offset #30
/* 2078:     */     //   Java source line #1276	-> byte code offset #31
/* 2079:     */     //   Java source line #1277	-> byte code offset #54
/* 2080:     */     //   Java source line #1279	-> byte code offset #56
/* 2081:     */     // Local variable table:
/* 2082:     */     //   start	length	slot	name	signature
/* 2083:     */     //   0	67	0	this	LinuxDisplay
/* 2084:     */     //   15	8	1	i	int
/* 2085:     */     //   30	15	1	e	LWJGLException
/* 2086:     */     //   24	5	2	localObject1	Object
/* 2087:     */     //   55	5	2	j	int
/* 2088:     */     //   61	5	3	localObject2	Object
/* 2089:     */     // Exception table:
/* 2090:     */     //   from	to	target	type
/* 2091:     */     //   6	16	24	finally
/* 2092:     */     //   24	25	24	finally
/* 2093:     */     //   3	19	30	org/lwjgl/LWJGLException
/* 2094:     */     //   24	30	30	org/lwjgl/LWJGLException
/* 2095:     */     //   3	19	61	finally
/* 2096:     */     //   24	56	61	finally
/* 2097:     */     //   61	62	61	finally
/* 2098:     */   }
/* 2099:     */   
/* 2100:     */   private static native int nGetPbufferCapabilities(long paramLong, int paramInt);
/* 2101:     */   
/* 2102:     */   public boolean isBufferLost(PeerInfo handle)
/* 2103:     */   {
/* 2104:1285 */     return false;
/* 2105:     */   }
/* 2106:     */   
/* 2107:     */   public PeerInfo createPbuffer(int width, int height, PixelFormat pixel_format, ContextAttribs attribs, IntBuffer pixelFormatCaps, IntBuffer pBufferAttribs)
/* 2108:     */     throws LWJGLException
/* 2109:     */   {
/* 2110:1291 */     return new LinuxPbufferPeerInfo(width, height, pixel_format);
/* 2111:     */   }
/* 2112:     */   
/* 2113:     */   public void setPbufferAttrib(PeerInfo handle, int attrib, int value)
/* 2114:     */   {
/* 2115:1295 */     throw new UnsupportedOperationException();
/* 2116:     */   }
/* 2117:     */   
/* 2118:     */   public void bindTexImageToPbuffer(PeerInfo handle, int buffer)
/* 2119:     */   {
/* 2120:1299 */     throw new UnsupportedOperationException();
/* 2121:     */   }
/* 2122:     */   
/* 2123:     */   public void releaseTexImageFromPbuffer(PeerInfo handle, int buffer)
/* 2124:     */   {
/* 2125:1303 */     throw new UnsupportedOperationException();
/* 2126:     */   }
/* 2127:     */   
/* 2128:     */   private static ByteBuffer convertIcon(ByteBuffer icon, int width, int height)
/* 2129:     */   {
/* 2130:1307 */     ByteBuffer icon_rgb = BufferUtils.createByteBuffer(icon.capacity());
/* 2131:     */     
/* 2132:     */ 
/* 2133:     */ 
/* 2134:     */ 
/* 2135:1312 */     int depth = 4;
/* 2136:1314 */     for (int y = 0; y < height; y++) {
/* 2137:1315 */       for (int x = 0; x < width; x++)
/* 2138:     */       {
/* 2139:1316 */         byte r = icon.get(x * 4 + y * width * 4);
/* 2140:1317 */         byte g = icon.get(x * 4 + y * width * 4 + 1);
/* 2141:1318 */         byte b = icon.get(x * 4 + y * width * 4 + 2);
/* 2142:     */         
/* 2143:1320 */         icon_rgb.put(x * depth + y * width * depth, b);
/* 2144:1321 */         icon_rgb.put(x * depth + y * width * depth + 1, g);
/* 2145:1322 */         icon_rgb.put(x * depth + y * width * depth + 2, r);
/* 2146:     */       }
/* 2147:     */     }
/* 2148:1325 */     return icon_rgb;
/* 2149:     */   }
/* 2150:     */   
/* 2151:     */   private static ByteBuffer convertIconMask(ByteBuffer icon, int width, int height)
/* 2152:     */   {
/* 2153:1329 */     ByteBuffer icon_mask = BufferUtils.createByteBuffer(icon.capacity() / 4 / 8);
/* 2154:     */     
/* 2155:     */ 
/* 2156:     */ 
/* 2157:     */ 
/* 2158:1334 */     int depth = 4;
/* 2159:1336 */     for (int y = 0; y < height; y++) {
/* 2160:1337 */       for (int x = 0; x < width; x++)
/* 2161:     */       {
/* 2162:1338 */         byte a = icon.get(x * 4 + y * width * 4 + 3);
/* 2163:     */         
/* 2164:1340 */         int mask_index = x + y * width;
/* 2165:1341 */         int mask_byte_index = mask_index / 8;
/* 2166:1342 */         int mask_bit_index = mask_index % 8;
/* 2167:1343 */         byte bit = (a & 0xFF) >= 127 ? 1 : 0;
/* 2168:1344 */         byte new_byte = (byte)((icon_mask.get(mask_byte_index) | bit << mask_bit_index) & 0xFF);
/* 2169:1345 */         icon_mask.put(mask_byte_index, new_byte);
/* 2170:     */       }
/* 2171:     */     }
/* 2172:1348 */     return icon_mask;
/* 2173:     */   }
/* 2174:     */   
/* 2175:     */   /* Error */
/* 2176:     */   public int setIcon(ByteBuffer[] icons)
/* 2177:     */   {
/* 2178:     */     // Byte code:
/* 2179:     */     //   0: invokestatic 15	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/* 2180:     */     //   3: invokestatic 16	org/lwjgl/opengl/LinuxDisplay:incDisplay	()V
/* 2181:     */     //   6: aload_1
/* 2182:     */     //   7: astore_2
/* 2183:     */     //   8: aload_2
/* 2184:     */     //   9: arraylength
/* 2185:     */     //   10: istore_3
/* 2186:     */     //   11: iconst_0
/* 2187:     */     //   12: istore 4
/* 2188:     */     //   14: iload 4
/* 2189:     */     //   16: iload_3
/* 2190:     */     //   17: if_icmpge +99 -> 116
/* 2191:     */     //   20: aload_2
/* 2192:     */     //   21: iload 4
/* 2193:     */     //   23: aaload
/* 2194:     */     //   24: astore 5
/* 2195:     */     //   26: aload 5
/* 2196:     */     //   28: invokevirtual 275	java/nio/ByteBuffer:limit	()I
/* 2197:     */     //   31: iconst_4
/* 2198:     */     //   32: idiv
/* 2199:     */     //   33: istore 6
/* 2200:     */     //   35: iload 6
/* 2201:     */     //   37: i2d
/* 2202:     */     //   38: invokestatic 276	java/lang/Math:sqrt	(D)D
/* 2203:     */     //   41: d2i
/* 2204:     */     //   42: istore 7
/* 2205:     */     //   44: iload 7
/* 2206:     */     //   46: ifle +64 -> 110
/* 2207:     */     //   49: aload 5
/* 2208:     */     //   51: iload 7
/* 2209:     */     //   53: iload 7
/* 2210:     */     //   55: invokestatic 277	org/lwjgl/opengl/LinuxDisplay:convertIcon	(Ljava/nio/ByteBuffer;II)Ljava/nio/ByteBuffer;
/* 2211:     */     //   58: astore 8
/* 2212:     */     //   60: aload 5
/* 2213:     */     //   62: iload 7
/* 2214:     */     //   64: iload 7
/* 2215:     */     //   66: invokestatic 278	org/lwjgl/opengl/LinuxDisplay:convertIconMask	(Ljava/nio/ByteBuffer;II)Ljava/nio/ByteBuffer;
/* 2216:     */     //   69: astore 9
/* 2217:     */     //   71: invokestatic 18	org/lwjgl/opengl/LinuxDisplay:getDisplay	()J
/* 2218:     */     //   74: invokestatic 79	org/lwjgl/opengl/LinuxDisplay:getWindow	()J
/* 2219:     */     //   77: aload 8
/* 2220:     */     //   79: aload 8
/* 2221:     */     //   81: invokevirtual 271	java/nio/ByteBuffer:capacity	()I
/* 2222:     */     //   84: aload 9
/* 2223:     */     //   86: aload 9
/* 2224:     */     //   88: invokevirtual 271	java/nio/ByteBuffer:capacity	()I
/* 2225:     */     //   91: iload 7
/* 2226:     */     //   93: iload 7
/* 2227:     */     //   95: invokestatic 279	org/lwjgl/opengl/LinuxDisplay:nSetWindowIcon	(JJLjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;III)V
/* 2228:     */     //   98: iconst_1
/* 2229:     */     //   99: istore 10
/* 2230:     */     //   101: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 2231:     */     //   104: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2232:     */     //   107: iload 10
/* 2233:     */     //   109: ireturn
/* 2234:     */     //   110: iinc 4 1
/* 2235:     */     //   113: goto -99 -> 14
/* 2236:     */     //   116: iconst_0
/* 2237:     */     //   117: istore_2
/* 2238:     */     //   118: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 2239:     */     //   121: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2240:     */     //   124: iload_2
/* 2241:     */     //   125: ireturn
/* 2242:     */     //   126: astore 11
/* 2243:     */     //   128: invokestatic 21	org/lwjgl/opengl/LinuxDisplay:decDisplay	()V
/* 2244:     */     //   131: aload 11
/* 2245:     */     //   133: athrow
/* 2246:     */     //   134: astore_2
/* 2247:     */     //   135: new 32	java/lang/StringBuilder
/* 2248:     */     //   138: dup
/* 2249:     */     //   139: invokespecial 33	java/lang/StringBuilder:<init>	()V
/* 2250:     */     //   142: ldc_w 280
/* 2251:     */     //   145: invokevirtual 35	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/* 2252:     */     //   148: aload_2
/* 2253:     */     //   149: invokevirtual 36	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/* 2254:     */     //   152: invokevirtual 37	java/lang/StringBuilder:toString	()Ljava/lang/String;
/* 2255:     */     //   155: invokestatic 25	org/lwjgl/LWJGLUtil:log	(Ljava/lang/CharSequence;)V
/* 2256:     */     //   158: iconst_0
/* 2257:     */     //   159: istore_3
/* 2258:     */     //   160: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2259:     */     //   163: iload_3
/* 2260:     */     //   164: ireturn
/* 2261:     */     //   165: astore 12
/* 2262:     */     //   167: invokestatic 22	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/* 2263:     */     //   170: aload 12
/* 2264:     */     //   172: athrow
/* 2265:     */     // Line number table:
/* 2266:     */     //   Java source line #1364	-> byte code offset #0
/* 2267:     */     //   Java source line #1366	-> byte code offset #3
/* 2268:     */     //   Java source line #1368	-> byte code offset #6
/* 2269:     */     //   Java source line #1369	-> byte code offset #26
/* 2270:     */     //   Java source line #1370	-> byte code offset #35
/* 2271:     */     //   Java source line #1371	-> byte code offset #44
/* 2272:     */     //   Java source line #1372	-> byte code offset #49
/* 2273:     */     //   Java source line #1373	-> byte code offset #60
/* 2274:     */     //   Java source line #1374	-> byte code offset #71
/* 2275:     */     //   Java source line #1375	-> byte code offset #98
/* 2276:     */     //   Java source line #1380	-> byte code offset #101
/* 2277:     */     //   Java source line #1386	-> byte code offset #104
/* 2278:     */     //   Java source line #1368	-> byte code offset #110
/* 2279:     */     //   Java source line #1378	-> byte code offset #116
/* 2280:     */     //   Java source line #1380	-> byte code offset #118
/* 2281:     */     //   Java source line #1386	-> byte code offset #121
/* 2282:     */     //   Java source line #1380	-> byte code offset #126
/* 2283:     */     //   Java source line #1382	-> byte code offset #134
/* 2284:     */     //   Java source line #1383	-> byte code offset #135
/* 2285:     */     //   Java source line #1384	-> byte code offset #158
/* 2286:     */     //   Java source line #1386	-> byte code offset #160
/* 2287:     */     // Local variable table:
/* 2288:     */     //   start	length	slot	name	signature
/* 2289:     */     //   0	173	0	this	LinuxDisplay
/* 2290:     */     //   0	173	1	icons	ByteBuffer[]
/* 2291:     */     //   7	118	2	arr$	ByteBuffer[]
/* 2292:     */     //   134	15	2	e	LWJGLException
/* 2293:     */     //   10	154	3	len$	int
/* 2294:     */     //   12	99	4	i$	int
/* 2295:     */     //   24	37	5	icon	ByteBuffer
/* 2296:     */     //   33	3	6	size	int
/* 2297:     */     //   42	52	7	dimension	int
/* 2298:     */     //   58	22	8	icon_rgb	ByteBuffer
/* 2299:     */     //   69	18	9	icon_mask	ByteBuffer
/* 2300:     */     //   99	9	10	i	int
/* 2301:     */     //   126	6	11	localObject1	Object
/* 2302:     */     //   165	6	12	localObject2	Object
/* 2303:     */     // Exception table:
/* 2304:     */     //   from	to	target	type
/* 2305:     */     //   6	101	126	finally
/* 2306:     */     //   110	118	126	finally
/* 2307:     */     //   126	128	126	finally
/* 2308:     */     //   3	104	134	org/lwjgl/LWJGLException
/* 2309:     */     //   110	121	134	org/lwjgl/LWJGLException
/* 2310:     */     //   126	134	134	org/lwjgl/LWJGLException
/* 2311:     */     //   3	104	165	finally
/* 2312:     */     //   110	121	165	finally
/* 2313:     */     //   126	160	165	finally
/* 2314:     */     //   165	167	165	finally
/* 2315:     */   }
/* 2316:     */   
/* 2317:     */   private static native void nSetWindowIcon(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer1, int paramInt1, ByteBuffer paramByteBuffer2, int paramInt2, int paramInt3, int paramInt4);
/* 2318:     */   
/* 2319:     */   public int getX()
/* 2320:     */   {
/* 2321:1393 */     return this.window_x;
/* 2322:     */   }
/* 2323:     */   
/* 2324:     */   public int getY()
/* 2325:     */   {
/* 2326:1397 */     return this.window_y;
/* 2327:     */   }
/* 2328:     */   
/* 2329:     */   public int getWidth()
/* 2330:     */   {
/* 2331:1401 */     return this.window_width;
/* 2332:     */   }
/* 2333:     */   
/* 2334:     */   public int getHeight()
/* 2335:     */   {
/* 2336:1405 */     return this.window_height;
/* 2337:     */   }
/* 2338:     */   
/* 2339:     */   public boolean isInsideWindow()
/* 2340:     */   {
/* 2341:1409 */     return this.mouseInside;
/* 2342:     */   }
/* 2343:     */   
/* 2344:     */   public void setResizable(boolean resizable)
/* 2345:     */   {
/* 2346:1413 */     if (this.resizable == resizable) {
/* 2347:1414 */       return;
/* 2348:     */     }
/* 2349:1417 */     this.resizable = resizable;
/* 2350:1418 */     nSetWindowSize(getDisplay(), getWindow(), this.window_width, this.window_height, resizable);
/* 2351:     */   }
/* 2352:     */   
/* 2353:     */   public boolean wasResized()
/* 2354:     */   {
/* 2355:1422 */     if (this.resized)
/* 2356:     */     {
/* 2357:1423 */       this.resized = false;
/* 2358:1424 */       return true;
/* 2359:     */     }
/* 2360:1427 */     return false;
/* 2361:     */   }
/* 2362:     */   
/* 2363:     */   private static final class Compiz
/* 2364:     */   {
/* 2365:     */     private static boolean applyFix;
/* 2366:     */     private static Provider provider;
/* 2367:     */     
/* 2368:     */     static void init()
/* 2369:     */     {
/* 2370:1448 */       if (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.nocompiz_lfs")) {
/* 2371:1449 */         return;
/* 2372:     */       }
/* 2373:1451 */       AccessController.doPrivileged(new PrivilegedAction()
/* 2374:     */       {
/* 2375:     */         public Object run()
/* 2376:     */         {
/* 2377:     */           try
/* 2378:     */           {
/* 2379:1455 */             if (!LinuxDisplay.Compiz.isProcessActive("compiz"))
/* 2380:     */             {
/* 2381:1456 */               Object localObject1 = null;
/* 2382:     */               
/* 2383:     */ 
/* 2384:     */ 
/* 2385:     */ 
/* 2386:     */ 
/* 2387:     */ 
/* 2388:     */ 
/* 2389:     */ 
/* 2390:     */ 
/* 2391:     */ 
/* 2392:     */ 
/* 2393:     */ 
/* 2394:     */ 
/* 2395:     */ 
/* 2396:     */ 
/* 2397:     */ 
/* 2398:     */ 
/* 2399:     */ 
/* 2400:     */ 
/* 2401:     */ 
/* 2402:     */ 
/* 2403:     */ 
/* 2404:     */ 
/* 2405:     */ 
/* 2406:     */ 
/* 2407:     */ 
/* 2408:     */ 
/* 2409:     */ 
/* 2410:     */ 
/* 2411:     */ 
/* 2412:     */ 
/* 2413:     */ 
/* 2414:     */ 
/* 2415:     */ 
/* 2416:     */ 
/* 2417:     */ 
/* 2418:     */ 
/* 2419:     */ 
/* 2420:     */ 
/* 2421:     */ 
/* 2422:     */ 
/* 2423:     */ 
/* 2424:     */ 
/* 2425:     */ 
/* 2426:     */ 
/* 2427:     */ 
/* 2428:     */ 
/* 2429:     */ 
/* 2430:     */ 
/* 2431:     */ 
/* 2432:     */ 
/* 2433:     */ 
/* 2434:     */ 
/* 2435:     */ 
/* 2436:     */ 
/* 2437:     */ 
/* 2438:     */ 
/* 2439:     */ 
/* 2440:     */ 
/* 2441:     */ 
/* 2442:     */ 
/* 2443:     */ 
/* 2444:     */ 
/* 2445:     */ 
/* 2446:     */ 
/* 2447:     */ 
/* 2448:     */ 
/* 2449:     */ 
/* 2450:     */ 
/* 2451:     */ 
/* 2452:     */ 
/* 2453:     */ 
/* 2454:     */ 
/* 2455:     */ 
/* 2456:     */ 
/* 2457:     */ 
/* 2458:     */ 
/* 2459:     */ 
/* 2460:     */ 
/* 2461:     */ 
/* 2462:     */ 
/* 2463:     */ 
/* 2464:     */ 
/* 2465:     */ 
/* 2466:     */ 
/* 2467:     */ 
/* 2468:     */ 
/* 2469:     */ 
/* 2470:     */ 
/* 2471:1546 */               return null;
/* 2472:     */             }
/* 2473:1458 */             LinuxDisplay.Compiz.access$402(null);
/* 2474:     */             
/* 2475:1460 */             String providerName = null;
/* 2476:1463 */             if (LinuxDisplay.Compiz.isProcessActive("dbus-daemon"))
/* 2477:     */             {
/* 2478:1464 */               providerName = "Dbus";
/* 2479:1465 */               LinuxDisplay.Compiz.access$402(new LinuxDisplay.Compiz.Provider()
/* 2480:     */               {
/* 2481:     */                 private static final String KEY = "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen";
/* 2482:     */                 
/* 2483:     */                 public boolean hasLegacyFullscreenSupport()
/* 2484:     */                   throws LWJGLException
/* 2485:     */                 {
/* 2486:1470 */                   List output = LinuxDisplay.Compiz.run(new String[] { "dbus-send", "--print-reply", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.get" });
/* 2487:1474 */                   if ((output == null) || (output.size() < 2)) {
/* 2488:1475 */                     throw new LWJGLException("Invalid Dbus reply.");
/* 2489:     */                   }
/* 2490:1477 */                   String line = (String)output.get(0);
/* 2491:1479 */                   if (!line.startsWith("method return")) {
/* 2492:1480 */                     throw new LWJGLException("Invalid Dbus reply.");
/* 2493:     */                   }
/* 2494:1482 */                   line = ((String)output.get(1)).trim();
/* 2495:1483 */                   if ((!line.startsWith("boolean")) || (line.length() < 12)) {
/* 2496:1484 */                     throw new LWJGLException("Invalid Dbus reply.");
/* 2497:     */                   }
/* 2498:1486 */                   return "true".equalsIgnoreCase(line.substring("boolean".length() + 1));
/* 2499:     */                 }
/* 2500:     */                 
/* 2501:     */                 public void setLegacyFullscreenSupport(boolean state)
/* 2502:     */                   throws LWJGLException
/* 2503:     */                 {
/* 2504:1490 */                   if (LinuxDisplay.Compiz.run(new String[] { "dbus-send", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.set", "boolean:" + Boolean.toString(state) }) == null) {
/* 2505:1493 */                     throw new LWJGLException("Failed to apply Compiz LFS workaround.");
/* 2506:     */                   }
/* 2507:     */                 }
/* 2508:     */               });
/* 2509:     */             }
/* 2510:     */             else
/* 2511:     */             {
/* 2512:     */               try
/* 2513:     */               {
/* 2514:1499 */                 Runtime.getRuntime().exec("gconftool");
/* 2515:     */                 
/* 2516:1501 */                 providerName = "gconftool";
/* 2517:1502 */                 LinuxDisplay.Compiz.access$402(new LinuxDisplay.Compiz.Provider()
/* 2518:     */                 {
/* 2519:     */                   private static final String KEY = "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen";
/* 2520:     */                   
/* 2521:     */                   public boolean hasLegacyFullscreenSupport()
/* 2522:     */                     throws LWJGLException
/* 2523:     */                   {
/* 2524:1507 */                     List output = LinuxDisplay.Compiz.run(new String[] { "gconftool", "-g", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen" });
/* 2525:1511 */                     if ((output == null) || (output.size() == 0)) {
/* 2526:1512 */                       throw new LWJGLException("Invalid gconftool reply.");
/* 2527:     */                     }
/* 2528:1514 */                     return Boolean.parseBoolean(((String)output.get(0)).trim());
/* 2529:     */                   }
/* 2530:     */                   
/* 2531:     */                   public void setLegacyFullscreenSupport(boolean state)
/* 2532:     */                     throws LWJGLException
/* 2533:     */                   {
/* 2534:1518 */                     if (LinuxDisplay.Compiz.run(new String[] { "gconftool", "-s", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen", "-s", Boolean.toString(state), "-t", "bool" }) == null) {
/* 2535:1521 */                       throw new LWJGLException("Failed to apply Compiz LFS workaround.");
/* 2536:     */                     }
/* 2537:1523 */                     if (state) {
/* 2538:     */                       try
/* 2539:     */                       {
/* 2540:1527 */                         Thread.sleep(200L);
/* 2541:     */                       }
/* 2542:     */                       catch (InterruptedException e)
/* 2543:     */                       {
/* 2544:1529 */                         e.printStackTrace();
/* 2545:     */                       }
/* 2546:     */                     }
/* 2547:     */                   }
/* 2548:     */                 });
/* 2549:     */               }
/* 2550:     */               catch (IOException e) {}
/* 2551:     */             }
/* 2552:1539 */             if ((LinuxDisplay.Compiz.provider != null) && (!LinuxDisplay.Compiz.provider.hasLegacyFullscreenSupport()))
/* 2553:     */             {
/* 2554:1540 */               LinuxDisplay.Compiz.access$602(true);
/* 2555:1541 */               LWJGLUtil.log("Using " + providerName + " to apply Compiz LFS workaround.");
/* 2556:     */             }
/* 2557:1546 */             return null;
/* 2558:     */           }
/* 2559:     */           catch (LWJGLException e)
/* 2560:     */           {
/* 2561:1543 */             e = 
/* 2562:     */             
/* 2563:     */ 
/* 2564:1546 */               e;return null;
/* 2565:     */           }
/* 2566:     */           finally {}
/* 2567:1546 */           return null;
/* 2568:     */         }
/* 2569:     */       });
/* 2570:     */     }
/* 2571:     */     
/* 2572:     */     static void setLegacyFullscreenSupport(boolean enabled)
/* 2573:     */     {
/* 2574:1553 */       if (!applyFix) {
/* 2575:1554 */         return;
/* 2576:     */       }
/* 2577:1556 */       AccessController.doPrivileged(new PrivilegedAction()
/* 2578:     */       {
/* 2579:     */         public Object run()
/* 2580:     */         {
/* 2581:     */           try
/* 2582:     */           {
/* 2583:1559 */             LinuxDisplay.Compiz.provider.setLegacyFullscreenSupport(this.val$enabled);
/* 2584:     */           }
/* 2585:     */           catch (LWJGLException e)
/* 2586:     */           {
/* 2587:1561 */             LWJGLUtil.log("Failed to change Compiz Legacy Fullscreen Support. Reason: " + e.getMessage());
/* 2588:     */           }
/* 2589:1563 */           return null;
/* 2590:     */         }
/* 2591:     */       });
/* 2592:     */     }
/* 2593:     */     
/* 2594:     */     private static List<String> run(String... command)
/* 2595:     */       throws LWJGLException
/* 2596:     */     {
/* 2597:1569 */       List<String> output = new ArrayList();
/* 2598:     */       try
/* 2599:     */       {
/* 2600:1572 */         Process p = Runtime.getRuntime().exec(command);
/* 2601:     */         try
/* 2602:     */         {
/* 2603:1574 */           int exitValue = p.waitFor();
/* 2604:1575 */           if (exitValue != 0) {
/* 2605:1576 */             return null;
/* 2606:     */           }
/* 2607:     */         }
/* 2608:     */         catch (InterruptedException e)
/* 2609:     */         {
/* 2610:1578 */           throw new LWJGLException("Process interrupted.", e);
/* 2611:     */         }
/* 2612:1581 */         BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 2613:     */         String line;
/* 2614:1584 */         while ((line = br.readLine()) != null) {
/* 2615:1585 */           output.add(line);
/* 2616:     */         }
/* 2617:1587 */         br.close();
/* 2618:     */       }
/* 2619:     */       catch (IOException e)
/* 2620:     */       {
/* 2621:1589 */         throw new LWJGLException("Process failed.", e);
/* 2622:     */       }
/* 2623:1592 */       return output;
/* 2624:     */     }
/* 2625:     */     
/* 2626:     */     private static boolean isProcessActive(String processName)
/* 2627:     */       throws LWJGLException
/* 2628:     */     {
/* 2629:1596 */       List<String> output = run(new String[] { "ps", "-C", processName });
/* 2630:1597 */       if (output == null) {
/* 2631:1598 */         return false;
/* 2632:     */       }
/* 2633:1600 */       for (String line : output) {
/* 2634:1601 */         if (line.contains(processName)) {
/* 2635:1602 */           return true;
/* 2636:     */         }
/* 2637:     */       }
/* 2638:1605 */       return false;
/* 2639:     */     }
/* 2640:     */     
/* 2641:     */     private static abstract interface Provider
/* 2642:     */     {
/* 2643:     */       public abstract boolean hasLegacyFullscreenSupport()
/* 2644:     */         throws LWJGLException;
/* 2645:     */       
/* 2646:     */       public abstract void setLegacyFullscreenSupport(boolean paramBoolean)
/* 2647:     */         throws LWJGLException;
/* 2648:     */     }
/* 2649:     */   }
/* 2650:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxDisplay
 * JD-Core Version:    0.7.0.1
 */