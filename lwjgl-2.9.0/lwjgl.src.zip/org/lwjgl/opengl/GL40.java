/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import org.lwjgl.BufferChecks;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public final class GL40
/*  11:    */ {
/*  12:    */   public static final int GL_DRAW_INDIRECT_BUFFER = 36671;
/*  13:    */   public static final int GL_DRAW_INDIRECT_BUFFER_BINDING = 36675;
/*  14:    */   public static final int GL_GEOMETRY_SHADER_INVOCATIONS = 34943;
/*  15:    */   public static final int GL_MAX_GEOMETRY_SHADER_INVOCATIONS = 36442;
/*  16:    */   public static final int GL_MIN_FRAGMENT_INTERPOLATION_OFFSET = 36443;
/*  17:    */   public static final int GL_MAX_FRAGMENT_INTERPOLATION_OFFSET = 36444;
/*  18:    */   public static final int GL_FRAGMENT_INTERPOLATION_OFFSET_BITS = 36445;
/*  19:    */   public static final int GL_MAX_VERTEX_STREAMS = 36465;
/*  20:    */   public static final int GL_DOUBLE_VEC2 = 36860;
/*  21:    */   public static final int GL_DOUBLE_VEC3 = 36861;
/*  22:    */   public static final int GL_DOUBLE_VEC4 = 36862;
/*  23:    */   public static final int GL_DOUBLE_MAT2 = 36678;
/*  24:    */   public static final int GL_DOUBLE_MAT3 = 36679;
/*  25:    */   public static final int GL_DOUBLE_MAT4 = 36680;
/*  26:    */   public static final int GL_DOUBLE_MAT2x3 = 36681;
/*  27:    */   public static final int GL_DOUBLE_MAT2x4 = 36682;
/*  28:    */   public static final int GL_DOUBLE_MAT3x2 = 36683;
/*  29:    */   public static final int GL_DOUBLE_MAT3x4 = 36684;
/*  30:    */   public static final int GL_DOUBLE_MAT4x2 = 36685;
/*  31:    */   public static final int GL_DOUBLE_MAT4x3 = 36686;
/*  32:    */   public static final int GL_SAMPLE_SHADING = 35894;
/*  33:    */   public static final int GL_MIN_SAMPLE_SHADING_VALUE = 35895;
/*  34:    */   public static final int GL_ACTIVE_SUBROUTINES = 36325;
/*  35:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORMS = 36326;
/*  36:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_LOCATIONS = 36423;
/*  37:    */   public static final int GL_ACTIVE_SUBROUTINE_MAX_LENGTH = 36424;
/*  38:    */   public static final int GL_ACTIVE_SUBROUTINE_UNIFORM_MAX_LENGTH = 36425;
/*  39:    */   public static final int GL_MAX_SUBROUTINES = 36327;
/*  40:    */   public static final int GL_MAX_SUBROUTINE_UNIFORM_LOCATIONS = 36328;
/*  41:    */   public static final int GL_NUM_COMPATIBLE_SUBROUTINES = 36426;
/*  42:    */   public static final int GL_COMPATIBLE_SUBROUTINES = 36427;
/*  43:    */   public static final int GL_UNIFORM_SIZE = 35384;
/*  44:    */   public static final int GL_UNIFORM_NAME_LENGTH = 35385;
/*  45:    */   public static final int GL_PATCHES = 14;
/*  46:    */   public static final int GL_PATCH_VERTICES = 36466;
/*  47:    */   public static final int GL_PATCH_DEFAULT_INNER_LEVEL = 36467;
/*  48:    */   public static final int GL_PATCH_DEFAULT_OUTER_LEVEL = 36468;
/*  49:    */   public static final int GL_TESS_CONTROL_OUTPUT_VERTICES = 36469;
/*  50:    */   public static final int GL_TESS_GEN_MODE = 36470;
/*  51:    */   public static final int GL_TESS_GEN_SPACING = 36471;
/*  52:    */   public static final int GL_TESS_GEN_VERTEX_ORDER = 36472;
/*  53:    */   public static final int GL_TESS_GEN_POINT_MODE = 36473;
/*  54:    */   public static final int GL_ISOLINES = 36474;
/*  55:    */   public static final int GL_FRACTIONAL_ODD = 36475;
/*  56:    */   public static final int GL_FRACTIONAL_EVEN = 36476;
/*  57:    */   public static final int GL_MAX_PATCH_VERTICES = 36477;
/*  58:    */   public static final int GL_MAX_TESS_GEN_LEVEL = 36478;
/*  59:    */   public static final int GL_MAX_TESS_CONTROL_UNIFORM_COMPONENTS = 36479;
/*  60:    */   public static final int GL_MAX_TESS_EVALUATION_UNIFORM_COMPONENTS = 36480;
/*  61:    */   public static final int GL_MAX_TESS_CONTROL_TEXTURE_IMAGE_UNITS = 36481;
/*  62:    */   public static final int GL_MAX_TESS_EVALUATION_TEXTURE_IMAGE_UNITS = 36482;
/*  63:    */   public static final int GL_MAX_TESS_CONTROL_OUTPUT_COMPONENTS = 36483;
/*  64:    */   public static final int GL_MAX_TESS_PATCH_COMPONENTS = 36484;
/*  65:    */   public static final int GL_MAX_TESS_CONTROL_TOTAL_OUTPUT_COMPONENTS = 36485;
/*  66:    */   public static final int GL_MAX_TESS_EVALUATION_OUTPUT_COMPONENTS = 36486;
/*  67:    */   public static final int GL_MAX_TESS_CONTROL_UNIFORM_BLOCKS = 36489;
/*  68:    */   public static final int GL_MAX_TESS_EVALUATION_UNIFORM_BLOCKS = 36490;
/*  69:    */   public static final int GL_MAX_TESS_CONTROL_INPUT_COMPONENTS = 34924;
/*  70:    */   public static final int GL_MAX_TESS_EVALUATION_INPUT_COMPONENTS = 34925;
/*  71:    */   public static final int GL_MAX_COMBINED_TESS_CONTROL_UNIFORM_COMPONENTS = 36382;
/*  72:    */   public static final int GL_MAX_COMBINED_TESS_EVALUATION_UNIFORM_COMPONENTS = 36383;
/*  73:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_CONTROL_SHADER = 34032;
/*  74:    */   public static final int GL_UNIFORM_BLOCK_REFERENCED_BY_TESS_EVALUATION_SHADER = 34033;
/*  75:    */   public static final int GL_TESS_EVALUATION_SHADER = 36487;
/*  76:    */   public static final int GL_TESS_CONTROL_SHADER = 36488;
/*  77:    */   public static final int GL_TEXTURE_CUBE_MAP_ARRAY = 36873;
/*  78:    */   public static final int GL_TEXTURE_BINDING_CUBE_MAP_ARRAY = 36874;
/*  79:    */   public static final int GL_PROXY_TEXTURE_CUBE_MAP_ARRAY = 36875;
/*  80:    */   public static final int GL_SAMPLER_CUBE_MAP_ARRAY = 36876;
/*  81:    */   public static final int GL_SAMPLER_CUBE_MAP_ARRAY_SHADOW = 36877;
/*  82:    */   public static final int GL_INT_SAMPLER_CUBE_MAP_ARRAY = 36878;
/*  83:    */   public static final int GL_UNSIGNED_INT_SAMPLER_CUBE_MAP_ARRAY = 36879;
/*  84:    */   public static final int GL_MIN_PROGRAM_TEXTURE_GATHER_OFFSET_ARB = 36446;
/*  85:    */   public static final int GL_MAX_PROGRAM_TEXTURE_GATHER_OFFSET_ARB = 36447;
/*  86:    */   public static final int GL_MAX_PROGRAM_TEXTURE_GATHER_COMPONENTS_ARB = 36767;
/*  87:    */   public static final int GL_TRANSFORM_FEEDBACK = 36386;
/*  88:    */   public static final int GL_TRANSFORM_FEEDBACK_PAUSED = 36387;
/*  89:    */   public static final int GL_TRANSFORM_FEEDBACK_ACTIVE = 36388;
/*  90:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED = 36387;
/*  91:    */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE = 36388;
/*  92:    */   public static final int GL_TRANSFORM_FEEDBACK_BINDING = 36389;
/*  93:    */   public static final int GL_MAX_TRANSFORM_FEEDBACK_BUFFERS = 36464;
/*  94:    */   
/*  95:    */   public static void glBlendEquationi(int buf, int mode)
/*  96:    */   {
/*  97:230 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98:231 */     long function_pointer = caps.glBlendEquationi;
/*  99:232 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100:233 */     nglBlendEquationi(buf, mode, function_pointer);
/* 101:    */   }
/* 102:    */   
/* 103:    */   static native void nglBlendEquationi(int paramInt1, int paramInt2, long paramLong);
/* 104:    */   
/* 105:    */   public static void glBlendEquationSeparatei(int buf, int modeRGB, int modeAlpha)
/* 106:    */   {
/* 107:238 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 108:239 */     long function_pointer = caps.glBlendEquationSeparatei;
/* 109:240 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 110:241 */     nglBlendEquationSeparatei(buf, modeRGB, modeAlpha, function_pointer);
/* 111:    */   }
/* 112:    */   
/* 113:    */   static native void nglBlendEquationSeparatei(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 114:    */   
/* 115:    */   public static void glBlendFunci(int buf, int src, int dst)
/* 116:    */   {
/* 117:246 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 118:247 */     long function_pointer = caps.glBlendFunci;
/* 119:248 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 120:249 */     nglBlendFunci(buf, src, dst, function_pointer);
/* 121:    */   }
/* 122:    */   
/* 123:    */   static native void nglBlendFunci(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 124:    */   
/* 125:    */   public static void glBlendFuncSeparatei(int buf, int srcRGB, int dstRGB, int srcAlpha, int dstAlpha)
/* 126:    */   {
/* 127:254 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 128:255 */     long function_pointer = caps.glBlendFuncSeparatei;
/* 129:256 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 130:257 */     nglBlendFuncSeparatei(buf, srcRGB, dstRGB, srcAlpha, dstAlpha, function_pointer);
/* 131:    */   }
/* 132:    */   
/* 133:    */   static native void nglBlendFuncSeparatei(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 134:    */   
/* 135:    */   public static void glDrawArraysIndirect(int mode, ByteBuffer indirect)
/* 136:    */   {
/* 137:262 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 138:263 */     long function_pointer = caps.glDrawArraysIndirect;
/* 139:264 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 140:265 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 141:266 */     BufferChecks.checkBuffer(indirect, 16);
/* 142:267 */     nglDrawArraysIndirect(mode, MemoryUtil.getAddress(indirect), function_pointer);
/* 143:    */   }
/* 144:    */   
/* 145:    */   static native void nglDrawArraysIndirect(int paramInt, long paramLong1, long paramLong2);
/* 146:    */   
/* 147:    */   public static void glDrawArraysIndirect(int mode, long indirect_buffer_offset)
/* 148:    */   {
/* 149:271 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 150:272 */     long function_pointer = caps.glDrawArraysIndirect;
/* 151:273 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 152:274 */     GLChecks.ensureIndirectBOenabled(caps);
/* 153:275 */     nglDrawArraysIndirectBO(mode, indirect_buffer_offset, function_pointer);
/* 154:    */   }
/* 155:    */   
/* 156:    */   static native void nglDrawArraysIndirectBO(int paramInt, long paramLong1, long paramLong2);
/* 157:    */   
/* 158:    */   public static void glDrawArraysIndirect(int mode, IntBuffer indirect)
/* 159:    */   {
/* 160:281 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 161:282 */     long function_pointer = caps.glDrawArraysIndirect;
/* 162:283 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 163:284 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 164:285 */     BufferChecks.checkBuffer(indirect, 4);
/* 165:286 */     nglDrawArraysIndirect(mode, MemoryUtil.getAddress(indirect), function_pointer);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static void glDrawElementsIndirect(int mode, int type, ByteBuffer indirect)
/* 169:    */   {
/* 170:290 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 171:291 */     long function_pointer = caps.glDrawElementsIndirect;
/* 172:292 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 173:293 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 174:294 */     BufferChecks.checkBuffer(indirect, 20);
/* 175:295 */     nglDrawElementsIndirect(mode, type, MemoryUtil.getAddress(indirect), function_pointer);
/* 176:    */   }
/* 177:    */   
/* 178:    */   static native void nglDrawElementsIndirect(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 179:    */   
/* 180:    */   public static void glDrawElementsIndirect(int mode, int type, long indirect_buffer_offset)
/* 181:    */   {
/* 182:299 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 183:300 */     long function_pointer = caps.glDrawElementsIndirect;
/* 184:301 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 185:302 */     GLChecks.ensureIndirectBOenabled(caps);
/* 186:303 */     nglDrawElementsIndirectBO(mode, type, indirect_buffer_offset, function_pointer);
/* 187:    */   }
/* 188:    */   
/* 189:    */   static native void nglDrawElementsIndirectBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 190:    */   
/* 191:    */   public static void glDrawElementsIndirect(int mode, int type, IntBuffer indirect)
/* 192:    */   {
/* 193:309 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 194:310 */     long function_pointer = caps.glDrawElementsIndirect;
/* 195:311 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 196:312 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 197:313 */     BufferChecks.checkBuffer(indirect, 5);
/* 198:314 */     nglDrawElementsIndirect(mode, type, MemoryUtil.getAddress(indirect), function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static void glUniform1d(int location, double x)
/* 202:    */   {
/* 203:318 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 204:319 */     long function_pointer = caps.glUniform1d;
/* 205:320 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 206:321 */     nglUniform1d(location, x, function_pointer);
/* 207:    */   }
/* 208:    */   
/* 209:    */   static native void nglUniform1d(int paramInt, double paramDouble, long paramLong);
/* 210:    */   
/* 211:    */   public static void glUniform2d(int location, double x, double y)
/* 212:    */   {
/* 213:326 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 214:327 */     long function_pointer = caps.glUniform2d;
/* 215:328 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 216:329 */     nglUniform2d(location, x, y, function_pointer);
/* 217:    */   }
/* 218:    */   
/* 219:    */   static native void nglUniform2d(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 220:    */   
/* 221:    */   public static void glUniform3d(int location, double x, double y, double z)
/* 222:    */   {
/* 223:334 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 224:335 */     long function_pointer = caps.glUniform3d;
/* 225:336 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 226:337 */     nglUniform3d(location, x, y, z, function_pointer);
/* 227:    */   }
/* 228:    */   
/* 229:    */   static native void nglUniform3d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 230:    */   
/* 231:    */   public static void glUniform4d(int location, double x, double y, double z, double w)
/* 232:    */   {
/* 233:342 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 234:343 */     long function_pointer = caps.glUniform4d;
/* 235:344 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 236:345 */     nglUniform4d(location, x, y, z, w, function_pointer);
/* 237:    */   }
/* 238:    */   
/* 239:    */   static native void nglUniform4d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 240:    */   
/* 241:    */   public static void glUniform1(int location, DoubleBuffer value)
/* 242:    */   {
/* 243:350 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 244:351 */     long function_pointer = caps.glUniform1dv;
/* 245:352 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 246:353 */     BufferChecks.checkDirect(value);
/* 247:354 */     nglUniform1dv(location, value.remaining(), MemoryUtil.getAddress(value), function_pointer);
/* 248:    */   }
/* 249:    */   
/* 250:    */   static native void nglUniform1dv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 251:    */   
/* 252:    */   public static void glUniform2(int location, DoubleBuffer value)
/* 253:    */   {
/* 254:359 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 255:360 */     long function_pointer = caps.glUniform2dv;
/* 256:361 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 257:362 */     BufferChecks.checkDirect(value);
/* 258:363 */     nglUniform2dv(location, value.remaining() >> 1, MemoryUtil.getAddress(value), function_pointer);
/* 259:    */   }
/* 260:    */   
/* 261:    */   static native void nglUniform2dv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 262:    */   
/* 263:    */   public static void glUniform3(int location, DoubleBuffer value)
/* 264:    */   {
/* 265:368 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 266:369 */     long function_pointer = caps.glUniform3dv;
/* 267:370 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 268:371 */     BufferChecks.checkDirect(value);
/* 269:372 */     nglUniform3dv(location, value.remaining() / 3, MemoryUtil.getAddress(value), function_pointer);
/* 270:    */   }
/* 271:    */   
/* 272:    */   static native void nglUniform3dv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 273:    */   
/* 274:    */   public static void glUniform4(int location, DoubleBuffer value)
/* 275:    */   {
/* 276:377 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 277:378 */     long function_pointer = caps.glUniform4dv;
/* 278:379 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 279:380 */     BufferChecks.checkDirect(value);
/* 280:381 */     nglUniform4dv(location, value.remaining() >> 2, MemoryUtil.getAddress(value), function_pointer);
/* 281:    */   }
/* 282:    */   
/* 283:    */   static native void nglUniform4dv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 284:    */   
/* 285:    */   public static void glUniformMatrix2(int location, boolean transpose, DoubleBuffer value)
/* 286:    */   {
/* 287:386 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 288:387 */     long function_pointer = caps.glUniformMatrix2dv;
/* 289:388 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 290:389 */     BufferChecks.checkDirect(value);
/* 291:390 */     nglUniformMatrix2dv(location, value.remaining() >> 2, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 292:    */   }
/* 293:    */   
/* 294:    */   static native void nglUniformMatrix2dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 295:    */   
/* 296:    */   public static void glUniformMatrix3(int location, boolean transpose, DoubleBuffer value)
/* 297:    */   {
/* 298:395 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 299:396 */     long function_pointer = caps.glUniformMatrix3dv;
/* 300:397 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 301:398 */     BufferChecks.checkDirect(value);
/* 302:399 */     nglUniformMatrix3dv(location, value.remaining() / 9, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 303:    */   }
/* 304:    */   
/* 305:    */   static native void nglUniformMatrix3dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 306:    */   
/* 307:    */   public static void glUniformMatrix4(int location, boolean transpose, DoubleBuffer value)
/* 308:    */   {
/* 309:404 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 310:405 */     long function_pointer = caps.glUniformMatrix4dv;
/* 311:406 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 312:407 */     BufferChecks.checkDirect(value);
/* 313:408 */     nglUniformMatrix4dv(location, value.remaining() >> 4, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 314:    */   }
/* 315:    */   
/* 316:    */   static native void nglUniformMatrix4dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 317:    */   
/* 318:    */   public static void glUniformMatrix2x3(int location, boolean transpose, DoubleBuffer value)
/* 319:    */   {
/* 320:413 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 321:414 */     long function_pointer = caps.glUniformMatrix2x3dv;
/* 322:415 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 323:416 */     BufferChecks.checkDirect(value);
/* 324:417 */     nglUniformMatrix2x3dv(location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 325:    */   }
/* 326:    */   
/* 327:    */   static native void nglUniformMatrix2x3dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 328:    */   
/* 329:    */   public static void glUniformMatrix2x4(int location, boolean transpose, DoubleBuffer value)
/* 330:    */   {
/* 331:422 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 332:423 */     long function_pointer = caps.glUniformMatrix2x4dv;
/* 333:424 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 334:425 */     BufferChecks.checkDirect(value);
/* 335:426 */     nglUniformMatrix2x4dv(location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 336:    */   }
/* 337:    */   
/* 338:    */   static native void nglUniformMatrix2x4dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 339:    */   
/* 340:    */   public static void glUniformMatrix3x2(int location, boolean transpose, DoubleBuffer value)
/* 341:    */   {
/* 342:431 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 343:432 */     long function_pointer = caps.glUniformMatrix3x2dv;
/* 344:433 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 345:434 */     BufferChecks.checkDirect(value);
/* 346:435 */     nglUniformMatrix3x2dv(location, value.remaining() / 6, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 347:    */   }
/* 348:    */   
/* 349:    */   static native void nglUniformMatrix3x2dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 350:    */   
/* 351:    */   public static void glUniformMatrix3x4(int location, boolean transpose, DoubleBuffer value)
/* 352:    */   {
/* 353:440 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 354:441 */     long function_pointer = caps.glUniformMatrix3x4dv;
/* 355:442 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 356:443 */     BufferChecks.checkDirect(value);
/* 357:444 */     nglUniformMatrix3x4dv(location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 358:    */   }
/* 359:    */   
/* 360:    */   static native void nglUniformMatrix3x4dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 361:    */   
/* 362:    */   public static void glUniformMatrix4x2(int location, boolean transpose, DoubleBuffer value)
/* 363:    */   {
/* 364:449 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 365:450 */     long function_pointer = caps.glUniformMatrix4x2dv;
/* 366:451 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 367:452 */     BufferChecks.checkDirect(value);
/* 368:453 */     nglUniformMatrix4x2dv(location, value.remaining() >> 3, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 369:    */   }
/* 370:    */   
/* 371:    */   static native void nglUniformMatrix4x2dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 372:    */   
/* 373:    */   public static void glUniformMatrix4x3(int location, boolean transpose, DoubleBuffer value)
/* 374:    */   {
/* 375:458 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 376:459 */     long function_pointer = caps.glUniformMatrix4x3dv;
/* 377:460 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 378:461 */     BufferChecks.checkDirect(value);
/* 379:462 */     nglUniformMatrix4x3dv(location, value.remaining() / 12, transpose, MemoryUtil.getAddress(value), function_pointer);
/* 380:    */   }
/* 381:    */   
/* 382:    */   static native void nglUniformMatrix4x3dv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/* 383:    */   
/* 384:    */   public static void glGetUniform(int program, int location, DoubleBuffer params)
/* 385:    */   {
/* 386:467 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 387:468 */     long function_pointer = caps.glGetUniformdv;
/* 388:469 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 389:470 */     BufferChecks.checkDirect(params);
/* 390:471 */     nglGetUniformdv(program, location, MemoryUtil.getAddress(params), function_pointer);
/* 391:    */   }
/* 392:    */   
/* 393:    */   static native void nglGetUniformdv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 394:    */   
/* 395:    */   public static void glMinSampleShading(float value)
/* 396:    */   {
/* 397:476 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 398:477 */     long function_pointer = caps.glMinSampleShading;
/* 399:478 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 400:479 */     nglMinSampleShading(value, function_pointer);
/* 401:    */   }
/* 402:    */   
/* 403:    */   static native void nglMinSampleShading(float paramFloat, long paramLong);
/* 404:    */   
/* 405:    */   public static int glGetSubroutineUniformLocation(int program, int shadertype, ByteBuffer name)
/* 406:    */   {
/* 407:484 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 408:485 */     long function_pointer = caps.glGetSubroutineUniformLocation;
/* 409:486 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 410:487 */     BufferChecks.checkDirect(name);
/* 411:488 */     BufferChecks.checkNullTerminated(name);
/* 412:489 */     int __result = nglGetSubroutineUniformLocation(program, shadertype, MemoryUtil.getAddress(name), function_pointer);
/* 413:490 */     return __result;
/* 414:    */   }
/* 415:    */   
/* 416:    */   static native int nglGetSubroutineUniformLocation(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 417:    */   
/* 418:    */   public static int glGetSubroutineUniformLocation(int program, int shadertype, CharSequence name)
/* 419:    */   {
/* 420:496 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 421:497 */     long function_pointer = caps.glGetSubroutineUniformLocation;
/* 422:498 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 423:499 */     int __result = nglGetSubroutineUniformLocation(program, shadertype, APIUtil.getBufferNT(caps, name), function_pointer);
/* 424:500 */     return __result;
/* 425:    */   }
/* 426:    */   
/* 427:    */   public static int glGetSubroutineIndex(int program, int shadertype, ByteBuffer name)
/* 428:    */   {
/* 429:504 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 430:505 */     long function_pointer = caps.glGetSubroutineIndex;
/* 431:506 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 432:507 */     BufferChecks.checkDirect(name);
/* 433:508 */     BufferChecks.checkNullTerminated(name);
/* 434:509 */     int __result = nglGetSubroutineIndex(program, shadertype, MemoryUtil.getAddress(name), function_pointer);
/* 435:510 */     return __result;
/* 436:    */   }
/* 437:    */   
/* 438:    */   static native int nglGetSubroutineIndex(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 439:    */   
/* 440:    */   public static int glGetSubroutineIndex(int program, int shadertype, CharSequence name)
/* 441:    */   {
/* 442:516 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 443:517 */     long function_pointer = caps.glGetSubroutineIndex;
/* 444:518 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 445:519 */     int __result = nglGetSubroutineIndex(program, shadertype, APIUtil.getBufferNT(caps, name), function_pointer);
/* 446:520 */     return __result;
/* 447:    */   }
/* 448:    */   
/* 449:    */   public static void glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname, IntBuffer values)
/* 450:    */   {
/* 451:524 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 452:525 */     long function_pointer = caps.glGetActiveSubroutineUniformiv;
/* 453:526 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 454:527 */     BufferChecks.checkBuffer(values, 1);
/* 455:528 */     nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, MemoryUtil.getAddress(values), function_pointer);
/* 456:    */   }
/* 457:    */   
/* 458:    */   static native void nglGetActiveSubroutineUniformiv(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 459:    */   
/* 460:    */   @Deprecated
/* 461:    */   public static int glGetActiveSubroutineUniform(int program, int shadertype, int index, int pname)
/* 462:    */   {
/* 463:539 */     return glGetActiveSubroutineUniformi(program, shadertype, index, pname);
/* 464:    */   }
/* 465:    */   
/* 466:    */   public static int glGetActiveSubroutineUniformi(int program, int shadertype, int index, int pname)
/* 467:    */   {
/* 468:544 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 469:545 */     long function_pointer = caps.glGetActiveSubroutineUniformiv;
/* 470:546 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 471:547 */     IntBuffer values = APIUtil.getBufferInt(caps);
/* 472:548 */     nglGetActiveSubroutineUniformiv(program, shadertype, index, pname, MemoryUtil.getAddress(values), function_pointer);
/* 473:549 */     return values.get(0);
/* 474:    */   }
/* 475:    */   
/* 476:    */   public static void glGetActiveSubroutineUniformName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name)
/* 477:    */   {
/* 478:553 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 479:554 */     long function_pointer = caps.glGetActiveSubroutineUniformName;
/* 480:555 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 481:556 */     if (length != null) {
/* 482:557 */       BufferChecks.checkBuffer(length, 1);
/* 483:    */     }
/* 484:558 */     BufferChecks.checkDirect(name);
/* 485:559 */     nglGetActiveSubroutineUniformName(program, shadertype, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(name), function_pointer);
/* 486:    */   }
/* 487:    */   
/* 488:    */   static native void nglGetActiveSubroutineUniformName(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2, long paramLong3);
/* 489:    */   
/* 490:    */   public static String glGetActiveSubroutineUniformName(int program, int shadertype, int index, int bufsize)
/* 491:    */   {
/* 492:565 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 493:566 */     long function_pointer = caps.glGetActiveSubroutineUniformName;
/* 494:567 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 495:568 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 496:569 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufsize);
/* 497:570 */     nglGetActiveSubroutineUniformName(program, shadertype, index, bufsize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(name), function_pointer);
/* 498:571 */     name.limit(name_length.get(0));
/* 499:572 */     return APIUtil.getString(caps, name);
/* 500:    */   }
/* 501:    */   
/* 502:    */   public static void glGetActiveSubroutineName(int program, int shadertype, int index, IntBuffer length, ByteBuffer name)
/* 503:    */   {
/* 504:576 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 505:577 */     long function_pointer = caps.glGetActiveSubroutineName;
/* 506:578 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 507:579 */     if (length != null) {
/* 508:580 */       BufferChecks.checkBuffer(length, 1);
/* 509:    */     }
/* 510:581 */     BufferChecks.checkDirect(name);
/* 511:582 */     nglGetActiveSubroutineName(program, shadertype, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(name), function_pointer);
/* 512:    */   }
/* 513:    */   
/* 514:    */   static native void nglGetActiveSubroutineName(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2, long paramLong3);
/* 515:    */   
/* 516:    */   public static String glGetActiveSubroutineName(int program, int shadertype, int index, int bufsize)
/* 517:    */   {
/* 518:588 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 519:589 */     long function_pointer = caps.glGetActiveSubroutineName;
/* 520:590 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 521:591 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 522:592 */     ByteBuffer name = APIUtil.getBufferByte(caps, bufsize);
/* 523:593 */     nglGetActiveSubroutineName(program, shadertype, index, bufsize, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(name), function_pointer);
/* 524:594 */     name.limit(name_length.get(0));
/* 525:595 */     return APIUtil.getString(caps, name);
/* 526:    */   }
/* 527:    */   
/* 528:    */   public static void glUniformSubroutinesu(int shadertype, IntBuffer indices)
/* 529:    */   {
/* 530:599 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 531:600 */     long function_pointer = caps.glUniformSubroutinesuiv;
/* 532:601 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 533:602 */     BufferChecks.checkDirect(indices);
/* 534:603 */     nglUniformSubroutinesuiv(shadertype, indices.remaining(), MemoryUtil.getAddress(indices), function_pointer);
/* 535:    */   }
/* 536:    */   
/* 537:    */   static native void nglUniformSubroutinesuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 538:    */   
/* 539:    */   public static void glGetUniformSubroutineu(int shadertype, int location, IntBuffer params)
/* 540:    */   {
/* 541:608 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 542:609 */     long function_pointer = caps.glGetUniformSubroutineuiv;
/* 543:610 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 544:611 */     BufferChecks.checkBuffer(params, 1);
/* 545:612 */     nglGetUniformSubroutineuiv(shadertype, location, MemoryUtil.getAddress(params), function_pointer);
/* 546:    */   }
/* 547:    */   
/* 548:    */   static native void nglGetUniformSubroutineuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 549:    */   
/* 550:    */   @Deprecated
/* 551:    */   public static int glGetUniformSubroutineu(int shadertype, int location)
/* 552:    */   {
/* 553:623 */     return glGetUniformSubroutineui(shadertype, location);
/* 554:    */   }
/* 555:    */   
/* 556:    */   public static int glGetUniformSubroutineui(int shadertype, int location)
/* 557:    */   {
/* 558:628 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 559:629 */     long function_pointer = caps.glGetUniformSubroutineuiv;
/* 560:630 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 561:631 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 562:632 */     nglGetUniformSubroutineuiv(shadertype, location, MemoryUtil.getAddress(params), function_pointer);
/* 563:633 */     return params.get(0);
/* 564:    */   }
/* 565:    */   
/* 566:    */   public static void glGetProgramStage(int program, int shadertype, int pname, IntBuffer values)
/* 567:    */   {
/* 568:637 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 569:638 */     long function_pointer = caps.glGetProgramStageiv;
/* 570:639 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 571:640 */     BufferChecks.checkBuffer(values, 1);
/* 572:641 */     nglGetProgramStageiv(program, shadertype, pname, MemoryUtil.getAddress(values), function_pointer);
/* 573:    */   }
/* 574:    */   
/* 575:    */   static native void nglGetProgramStageiv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 576:    */   
/* 577:    */   @Deprecated
/* 578:    */   public static int glGetProgramStage(int program, int shadertype, int pname)
/* 579:    */   {
/* 580:652 */     return glGetProgramStagei(program, shadertype, pname);
/* 581:    */   }
/* 582:    */   
/* 583:    */   public static int glGetProgramStagei(int program, int shadertype, int pname)
/* 584:    */   {
/* 585:657 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 586:658 */     long function_pointer = caps.glGetProgramStageiv;
/* 587:659 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 588:660 */     IntBuffer values = APIUtil.getBufferInt(caps);
/* 589:661 */     nglGetProgramStageiv(program, shadertype, pname, MemoryUtil.getAddress(values), function_pointer);
/* 590:662 */     return values.get(0);
/* 591:    */   }
/* 592:    */   
/* 593:    */   public static void glPatchParameteri(int pname, int value)
/* 594:    */   {
/* 595:666 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 596:667 */     long function_pointer = caps.glPatchParameteri;
/* 597:668 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 598:669 */     nglPatchParameteri(pname, value, function_pointer);
/* 599:    */   }
/* 600:    */   
/* 601:    */   static native void nglPatchParameteri(int paramInt1, int paramInt2, long paramLong);
/* 602:    */   
/* 603:    */   public static void glPatchParameter(int pname, FloatBuffer values)
/* 604:    */   {
/* 605:674 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 606:675 */     long function_pointer = caps.glPatchParameterfv;
/* 607:676 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 608:677 */     BufferChecks.checkBuffer(values, 4);
/* 609:678 */     nglPatchParameterfv(pname, MemoryUtil.getAddress(values), function_pointer);
/* 610:    */   }
/* 611:    */   
/* 612:    */   static native void nglPatchParameterfv(int paramInt, long paramLong1, long paramLong2);
/* 613:    */   
/* 614:    */   public static void glBindTransformFeedback(int target, int id)
/* 615:    */   {
/* 616:683 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 617:684 */     long function_pointer = caps.glBindTransformFeedback;
/* 618:685 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 619:686 */     nglBindTransformFeedback(target, id, function_pointer);
/* 620:    */   }
/* 621:    */   
/* 622:    */   static native void nglBindTransformFeedback(int paramInt1, int paramInt2, long paramLong);
/* 623:    */   
/* 624:    */   public static void glDeleteTransformFeedbacks(IntBuffer ids)
/* 625:    */   {
/* 626:691 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 627:692 */     long function_pointer = caps.glDeleteTransformFeedbacks;
/* 628:693 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 629:694 */     BufferChecks.checkDirect(ids);
/* 630:695 */     nglDeleteTransformFeedbacks(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 631:    */   }
/* 632:    */   
/* 633:    */   static native void nglDeleteTransformFeedbacks(int paramInt, long paramLong1, long paramLong2);
/* 634:    */   
/* 635:    */   public static void glDeleteTransformFeedbacks(int id)
/* 636:    */   {
/* 637:701 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 638:702 */     long function_pointer = caps.glDeleteTransformFeedbacks;
/* 639:703 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 640:704 */     nglDeleteTransformFeedbacks(1, APIUtil.getInt(caps, id), function_pointer);
/* 641:    */   }
/* 642:    */   
/* 643:    */   public static void glGenTransformFeedbacks(IntBuffer ids)
/* 644:    */   {
/* 645:708 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 646:709 */     long function_pointer = caps.glGenTransformFeedbacks;
/* 647:710 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 648:711 */     BufferChecks.checkDirect(ids);
/* 649:712 */     nglGenTransformFeedbacks(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 650:    */   }
/* 651:    */   
/* 652:    */   static native void nglGenTransformFeedbacks(int paramInt, long paramLong1, long paramLong2);
/* 653:    */   
/* 654:    */   public static int glGenTransformFeedbacks()
/* 655:    */   {
/* 656:718 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 657:719 */     long function_pointer = caps.glGenTransformFeedbacks;
/* 658:720 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 659:721 */     IntBuffer ids = APIUtil.getBufferInt(caps);
/* 660:722 */     nglGenTransformFeedbacks(1, MemoryUtil.getAddress(ids), function_pointer);
/* 661:723 */     return ids.get(0);
/* 662:    */   }
/* 663:    */   
/* 664:    */   public static boolean glIsTransformFeedback(int id)
/* 665:    */   {
/* 666:727 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 667:728 */     long function_pointer = caps.glIsTransformFeedback;
/* 668:729 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 669:730 */     boolean __result = nglIsTransformFeedback(id, function_pointer);
/* 670:731 */     return __result;
/* 671:    */   }
/* 672:    */   
/* 673:    */   static native boolean nglIsTransformFeedback(int paramInt, long paramLong);
/* 674:    */   
/* 675:    */   public static void glPauseTransformFeedback()
/* 676:    */   {
/* 677:736 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 678:737 */     long function_pointer = caps.glPauseTransformFeedback;
/* 679:738 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 680:739 */     nglPauseTransformFeedback(function_pointer);
/* 681:    */   }
/* 682:    */   
/* 683:    */   static native void nglPauseTransformFeedback(long paramLong);
/* 684:    */   
/* 685:    */   public static void glResumeTransformFeedback()
/* 686:    */   {
/* 687:744 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 688:745 */     long function_pointer = caps.glResumeTransformFeedback;
/* 689:746 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 690:747 */     nglResumeTransformFeedback(function_pointer);
/* 691:    */   }
/* 692:    */   
/* 693:    */   static native void nglResumeTransformFeedback(long paramLong);
/* 694:    */   
/* 695:    */   public static void glDrawTransformFeedback(int mode, int id)
/* 696:    */   {
/* 697:752 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 698:753 */     long function_pointer = caps.glDrawTransformFeedback;
/* 699:754 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 700:755 */     nglDrawTransformFeedback(mode, id, function_pointer);
/* 701:    */   }
/* 702:    */   
/* 703:    */   static native void nglDrawTransformFeedback(int paramInt1, int paramInt2, long paramLong);
/* 704:    */   
/* 705:    */   public static void glDrawTransformFeedbackStream(int mode, int id, int stream)
/* 706:    */   {
/* 707:760 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 708:761 */     long function_pointer = caps.glDrawTransformFeedbackStream;
/* 709:762 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 710:763 */     nglDrawTransformFeedbackStream(mode, id, stream, function_pointer);
/* 711:    */   }
/* 712:    */   
/* 713:    */   static native void nglDrawTransformFeedbackStream(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 714:    */   
/* 715:    */   public static void glBeginQueryIndexed(int target, int index, int id)
/* 716:    */   {
/* 717:768 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 718:769 */     long function_pointer = caps.glBeginQueryIndexed;
/* 719:770 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 720:771 */     nglBeginQueryIndexed(target, index, id, function_pointer);
/* 721:    */   }
/* 722:    */   
/* 723:    */   static native void nglBeginQueryIndexed(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 724:    */   
/* 725:    */   public static void glEndQueryIndexed(int target, int index)
/* 726:    */   {
/* 727:776 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 728:777 */     long function_pointer = caps.glEndQueryIndexed;
/* 729:778 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 730:779 */     nglEndQueryIndexed(target, index, function_pointer);
/* 731:    */   }
/* 732:    */   
/* 733:    */   static native void nglEndQueryIndexed(int paramInt1, int paramInt2, long paramLong);
/* 734:    */   
/* 735:    */   public static void glGetQueryIndexed(int target, int index, int pname, IntBuffer params)
/* 736:    */   {
/* 737:784 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 738:785 */     long function_pointer = caps.glGetQueryIndexediv;
/* 739:786 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 740:787 */     BufferChecks.checkBuffer(params, 1);
/* 741:788 */     nglGetQueryIndexediv(target, index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 742:    */   }
/* 743:    */   
/* 744:    */   static native void nglGetQueryIndexediv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 745:    */   
/* 746:    */   @Deprecated
/* 747:    */   public static int glGetQueryIndexed(int target, int index, int pname)
/* 748:    */   {
/* 749:799 */     return glGetQueryIndexedi(target, index, pname);
/* 750:    */   }
/* 751:    */   
/* 752:    */   public static int glGetQueryIndexedi(int target, int index, int pname)
/* 753:    */   {
/* 754:804 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 755:805 */     long function_pointer = caps.glGetQueryIndexediv;
/* 756:806 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 757:807 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 758:808 */     nglGetQueryIndexediv(target, index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 759:809 */     return params.get(0);
/* 760:    */   }
/* 761:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL40
 * JD-Core Version:    0.7.0.1
 */