/*  1:   */ package org.lwjgl;
/*  2:   */ 
/*  3:   */ import java.awt.Toolkit;
/*  4:   */ import java.security.AccessController;
/*  5:   */ import java.security.PrivilegedAction;
/*  6:   */ 
/*  7:   */ final class LinuxSysImplementation
/*  8:   */   extends J2SESysImplementation
/*  9:   */ {
/* 10:   */   private static final int JNI_VERSION = 19;
/* 11:   */   
/* 12:   */   static
/* 13:   */   {
/* 14:50 */     Toolkit.getDefaultToolkit();
/* 15:   */     
/* 16:   */ 
/* 17:53 */     AccessController.doPrivileged(new PrivilegedAction()
/* 18:   */     {
/* 19:   */       public Object run()
/* 20:   */       {
/* 21:   */         try
/* 22:   */         {
/* 23:56 */           System.loadLibrary("jawt");
/* 24:   */         }
/* 25:   */         catch (UnsatisfiedLinkError e) {}
/* 26:61 */         return null;
/* 27:   */       }
/* 28:   */     });
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int getRequiredJNIVersion()
/* 32:   */   {
/* 33:67 */     return 19;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean openURL(String url)
/* 37:   */   {
/* 38:74 */     String[] browsers = { "xdg-open", "firefox", "mozilla", "opera", "konqueror", "nautilus", "galeon", "netscape" };
/* 39:76 */     for (String browser : browsers) {
/* 40:   */       try
/* 41:   */       {
/* 42:78 */         LWJGLUtil.execPrivileged(new String[] { browser, url });
/* 43:79 */         return true;
/* 44:   */       }
/* 45:   */       catch (Exception e)
/* 46:   */       {
/* 47:82 */         e.printStackTrace(System.err);
/* 48:   */       }
/* 49:   */     }
/* 50:87 */     return false;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public boolean has64Bit()
/* 54:   */   {
/* 55:91 */     return true;
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.LinuxSysImplementation
 * JD-Core Version:    0.7.0.1
 */