/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.PointerWrapperAbstract;
/*  5:   */ 
/*  6:   */ public abstract class CLNativeKernel
/*  7:   */   extends PointerWrapperAbstract
/*  8:   */ {
/*  9:   */   protected CLNativeKernel()
/* 10:   */   {
/* 11:51 */     super(CallbackUtil.getNativeKernelCallback());
/* 12:   */   }
/* 13:   */   
/* 14:   */   protected abstract void execute(ByteBuffer[] paramArrayOfByteBuffer);
/* 15:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLNativeKernel
 * JD-Core Version:    0.7.0.1
 */