package org.lwjgl.opengl;

public final class ARBMapBufferAlignment
{
  public static final int GL_MIN_MAP_BUFFER_ALIGNMENT = 37052;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBMapBufferAlignment
 * JD-Core Version:    0.7.0.1
 */