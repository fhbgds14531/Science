/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ 
/*  6:   */ public final class ARBES2Compatibility
/*  7:   */ {
/*  8:   */   public static final int GL_SHADER_COMPILER = 36346;
/*  9:   */   public static final int GL_NUM_SHADER_BINARY_FORMATS = 36345;
/* 10:   */   public static final int GL_MAX_VERTEX_UNIFORM_VECTORS = 36347;
/* 11:   */   public static final int GL_MAX_VARYING_VECTORS = 36348;
/* 12:   */   public static final int GL_MAX_FRAGMENT_UNIFORM_VECTORS = 36349;
/* 13:   */   public static final int GL_IMPLEMENTATION_COLOR_READ_TYPE = 35738;
/* 14:   */   public static final int GL_IMPLEMENTATION_COLOR_READ_FORMAT = 35739;
/* 15:   */   public static final int GL_FIXED = 5132;
/* 16:   */   public static final int GL_LOW_FLOAT = 36336;
/* 17:   */   public static final int GL_MEDIUM_FLOAT = 36337;
/* 18:   */   public static final int GL_HIGH_FLOAT = 36338;
/* 19:   */   public static final int GL_LOW_INT = 36339;
/* 20:   */   public static final int GL_MEDIUM_INT = 36340;
/* 21:   */   public static final int GL_HIGH_INT = 36341;
/* 22:   */   public static final int GL_RGB565 = 36194;
/* 23:   */   
/* 24:   */   public static void glReleaseShaderCompiler() {}
/* 25:   */   
/* 26:   */   public static void glShaderBinary(IntBuffer shaders, int binaryformat, ByteBuffer binary)
/* 27:   */   {
/* 28:50 */     GL41.glShaderBinary(shaders, binaryformat, binary);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void glGetShaderPrecisionFormat(int shadertype, int precisiontype, IntBuffer range, IntBuffer precision)
/* 32:   */   {
/* 33:54 */     GL41.glGetShaderPrecisionFormat(shadertype, precisiontype, range, precision);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static void glDepthRangef(float n, float f)
/* 37:   */   {
/* 38:58 */     GL41.glDepthRangef(n, f);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public static void glClearDepthf(float d)
/* 42:   */   {
/* 43:62 */     GL41.glClearDepthf(d);
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBES2Compatibility
 * JD-Core Version:    0.7.0.1
 */