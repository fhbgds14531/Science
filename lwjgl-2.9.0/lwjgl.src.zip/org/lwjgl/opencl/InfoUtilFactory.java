/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.Buffer;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.LongBuffer;
/*   9:    */ import java.nio.ShortBuffer;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.List;
/*  12:    */ import org.lwjgl.BufferChecks;
/*  13:    */ import org.lwjgl.BufferUtils;
/*  14:    */ import org.lwjgl.LWJGLException;
/*  15:    */ import org.lwjgl.LWJGLUtil;
/*  16:    */ import org.lwjgl.MemoryUtil;
/*  17:    */ import org.lwjgl.PointerBuffer;
/*  18:    */ import org.lwjgl.opencl.api.CLBufferRegion;
/*  19:    */ import org.lwjgl.opencl.api.CLImageFormat;
/*  20:    */ import org.lwjgl.opencl.api.Filter;
/*  21:    */ import org.lwjgl.opengl.Drawable;
/*  22:    */ 
/*  23:    */ final class InfoUtilFactory
/*  24:    */ {
/*  25: 61 */   static final InfoUtil<CLCommandQueue> CL_COMMAND_QUEUE_UTIL = new InfoUtilAbstract()
/*  26:    */   {
/*  27:    */     protected int getInfo(CLCommandQueue object, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  28:    */     {
/*  29: 63 */       return CL10.clGetCommandQueueInfo(object, param_name, param_value, null);
/*  30:    */     }
/*  31:    */   };
/*  32: 67 */   static final CLContext.CLContextUtil CL_CONTEXT_UTIL = new CLContextUtil(null);
/*  33:    */   
/*  34:    */   private static final class CLContextUtil
/*  35:    */     extends InfoUtilAbstract<CLContext>
/*  36:    */     implements CLContext.CLContextUtil
/*  37:    */   {
/*  38:    */     protected int getInfo(CLContext context, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/*  39:    */     {
/*  40: 71 */       return CL10.clGetContextInfo(context, param_name, param_value, param_value_size_ret);
/*  41:    */     }
/*  42:    */     
/*  43:    */     public List<CLDevice> getInfoDevices(CLContext context)
/*  44:    */     {
/*  45: 75 */       context.checkValid();
/*  46:    */       int num_devices;
/*  47:    */       int num_devices;
/*  48: 79 */       if (CLCapabilities.getPlatformCapabilities((CLPlatform)context.getParent()).OpenCL11)
/*  49:    */       {
/*  50: 80 */         num_devices = getInfoInt(context, 4227);
/*  51:    */       }
/*  52:    */       else
/*  53:    */       {
/*  54: 82 */         PointerBuffer size_ret = APIUtil.getBufferPointer();
/*  55: 83 */         CL10.clGetContextInfo(context, 4225, null, size_ret);
/*  56: 84 */         num_devices = (int)(size_ret.get(0) / PointerBuffer.getPointerSize());
/*  57:    */       }
/*  58: 87 */       PointerBuffer deviceIDs = APIUtil.getBufferPointer(num_devices);
/*  59: 88 */       CL10.clGetContextInfo(context, 4225, deviceIDs.getBuffer(), null);
/*  60:    */       
/*  61: 90 */       List<CLDevice> devices = new ArrayList(num_devices);
/*  62: 91 */       for (int i = 0; i < num_devices; i++) {
/*  63: 92 */         devices.add(((CLPlatform)context.getParent()).getCLDevice(deviceIDs.get(i)));
/*  64:    */       }
/*  65: 94 */       return devices.size() == 0 ? null : devices;
/*  66:    */     }
/*  67:    */     
/*  68:    */     public CLContext create(CLPlatform platform, List<CLDevice> devices, CLContextCallback pfn_notify, Drawable share_drawable, IntBuffer errcode_ret)
/*  69:    */       throws LWJGLException
/*  70:    */     {
/*  71:100 */       int propertyCount = 2 + (share_drawable == null ? 0 : 4) + 1;
/*  72:    */       
/*  73:102 */       PointerBuffer properties = APIUtil.getBufferPointer(propertyCount + devices.size());
/*  74:103 */       properties.put(4228L).put(platform);
/*  75:104 */       if (share_drawable != null) {
/*  76:105 */         share_drawable.setCLSharingProperties(properties);
/*  77:    */       }
/*  78:106 */       properties.put(0L);
/*  79:    */       
/*  80:108 */       properties.position(propertyCount);
/*  81:109 */       for (CLDevice device : devices) {
/*  82:110 */         properties.put(device);
/*  83:    */       }
/*  84:112 */       long function_pointer = CLCapabilities.clCreateContext;
/*  85:113 */       BufferChecks.checkFunctionAddress(function_pointer);
/*  86:114 */       if (errcode_ret != null) {
/*  87:115 */         BufferChecks.checkBuffer(errcode_ret, 1);
/*  88:116 */       } else if (LWJGLUtil.DEBUG) {
/*  89:117 */         errcode_ret = APIUtil.getBufferInt();
/*  90:    */       }
/*  91:118 */       long user_data = (pfn_notify == null) || (pfn_notify.isCustom()) ? 0L : CallbackUtil.createGlobalRef(pfn_notify);
/*  92:119 */       CLContext __result = null;
/*  93:    */       try
/*  94:    */       {
/*  95:121 */         __result = new CLContext(CL10.nclCreateContext(MemoryUtil.getAddress0(properties.getBuffer()), devices.size(), MemoryUtil.getAddress(properties, propertyCount), pfn_notify == null ? 0L : pfn_notify.getPointer(), user_data, MemoryUtil.getAddressSafe(errcode_ret), function_pointer), platform);
/*  96:122 */         if (LWJGLUtil.DEBUG) {
/*  97:123 */           Util.checkCLError(errcode_ret.get(0));
/*  98:    */         }
/*  99:124 */         return __result;
/* 100:    */       }
/* 101:    */       finally
/* 102:    */       {
/* 103:126 */         if (__result != null) {
/* 104:126 */           __result.setContextCallback(user_data);
/* 105:    */         }
/* 106:    */       }
/* 107:    */     }
/* 108:    */     
/* 109:    */     public CLContext createFromType(CLPlatform platform, long device_type, CLContextCallback pfn_notify, Drawable share_drawable, IntBuffer errcode_ret)
/* 110:    */       throws LWJGLException
/* 111:    */     {
/* 112:131 */       int propertyCount = 2 + (share_drawable == null ? 0 : 4) + 1;
/* 113:    */       
/* 114:133 */       PointerBuffer properties = APIUtil.getBufferPointer(propertyCount);
/* 115:134 */       properties.put(4228L).put(platform);
/* 116:135 */       if (share_drawable != null) {
/* 117:136 */         share_drawable.setCLSharingProperties(properties);
/* 118:    */       }
/* 119:137 */       properties.put(0L);
/* 120:138 */       properties.flip();
/* 121:    */       
/* 122:140 */       return CL10.clCreateContextFromType(properties, device_type, pfn_notify, errcode_ret);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public List<CLImageFormat> getSupportedImageFormats(CLContext context, long flags, int image_type, Filter<CLImageFormat> filter)
/* 126:    */     {
/* 127:144 */       IntBuffer numBuffer = APIUtil.getBufferInt();
/* 128:145 */       CL10.clGetSupportedImageFormats(context, flags, image_type, null, numBuffer);
/* 129:    */       
/* 130:147 */       int num_image_formats = numBuffer.get(0);
/* 131:148 */       if (num_image_formats == 0) {
/* 132:149 */         return null;
/* 133:    */       }
/* 134:151 */       ByteBuffer formatBuffer = BufferUtils.createByteBuffer(num_image_formats * 8);
/* 135:152 */       CL10.clGetSupportedImageFormats(context, flags, image_type, formatBuffer, null);
/* 136:    */       
/* 137:154 */       List<CLImageFormat> formats = new ArrayList(num_image_formats);
/* 138:155 */       for (int i = 0; i < num_image_formats; i++)
/* 139:    */       {
/* 140:156 */         int offset = num_image_formats * 8;
/* 141:157 */         CLImageFormat format = new CLImageFormat(formatBuffer.getInt(offset), formatBuffer.getInt(offset + 4));
/* 142:161 */         if ((filter == null) || (filter.accept(format))) {
/* 143:162 */           formats.add(format);
/* 144:    */         }
/* 145:    */       }
/* 146:165 */       return formats.size() == 0 ? null : formats;
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:170 */   static final InfoUtil<CLDevice> CL_DEVICE_UTIL = new CLDeviceUtil(null);
/* 151:    */   
/* 152:    */   private static final class CLDeviceUtil
/* 153:    */     extends InfoUtilAbstract<CLDevice>
/* 154:    */   {
/* 155:    */     protected int getInfo(CLDevice device, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 156:    */     {
/* 157:174 */       return CL10.clGetDeviceInfo(device, param_name, param_value, param_value_size_ret);
/* 158:    */     }
/* 159:    */     
/* 160:    */     protected int getInfoSizeArraySize(CLDevice device, int param_name)
/* 161:    */     {
/* 162:178 */       switch (param_name)
/* 163:    */       {
/* 164:    */       case 4101: 
/* 165:180 */         return getInfoInt(device, 4099);
/* 166:    */       }
/* 167:182 */       throw new IllegalArgumentException("Unsupported parameter: " + LWJGLUtil.toHexString(param_name));
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:188 */   static final CLEvent.CLEventUtil CL_EVENT_UTIL = new CLEventUtil(null);
/* 172:    */   
/* 173:    */   private static final class CLEventUtil
/* 174:    */     extends InfoUtilAbstract<CLEvent>
/* 175:    */     implements CLEvent.CLEventUtil
/* 176:    */   {
/* 177:    */     protected int getInfo(CLEvent event, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 178:    */     {
/* 179:192 */       return CL10.clGetEventInfo(event, param_name, param_value, param_value_size_ret);
/* 180:    */     }
/* 181:    */     
/* 182:    */     public long getProfilingInfoLong(CLEvent event, int param_name)
/* 183:    */     {
/* 184:196 */       event.checkValid();
/* 185:    */       
/* 186:198 */       ByteBuffer buffer = APIUtil.getBufferByte(8);
/* 187:199 */       CL10.clGetEventProfilingInfo(event, param_name, buffer, null);
/* 188:    */       
/* 189:201 */       return buffer.getLong(0);
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:206 */   static final CLKernel.CLKernelUtil CL_KERNEL_UTIL = new CLKernelUtil(null);
/* 194:    */   
/* 195:    */   private static final class CLKernelUtil
/* 196:    */     extends InfoUtilAbstract<CLKernel>
/* 197:    */     implements CLKernel.CLKernelUtil
/* 198:    */   {
/* 199:    */     public void setArg(CLKernel kernel, int index, byte value)
/* 200:    */     {
/* 201:210 */       CL10.clSetKernelArg(kernel, index, 1L, APIUtil.getBufferByte(1).put(0, value));
/* 202:    */     }
/* 203:    */     
/* 204:    */     public void setArg(CLKernel kernel, int index, short value)
/* 205:    */     {
/* 206:214 */       CL10.clSetKernelArg(kernel, index, 2L, APIUtil.getBufferShort().put(0, value));
/* 207:    */     }
/* 208:    */     
/* 209:    */     public void setArg(CLKernel kernel, int index, int value)
/* 210:    */     {
/* 211:218 */       CL10.clSetKernelArg(kernel, index, 4L, APIUtil.getBufferInt().put(0, value));
/* 212:    */     }
/* 213:    */     
/* 214:    */     public void setArg(CLKernel kernel, int index, long value)
/* 215:    */     {
/* 216:222 */       CL10.clSetKernelArg(kernel, index, 8L, APIUtil.getBufferLong().put(0, value));
/* 217:    */     }
/* 218:    */     
/* 219:    */     public void setArg(CLKernel kernel, int index, float value)
/* 220:    */     {
/* 221:226 */       CL10.clSetKernelArg(kernel, index, 4L, APIUtil.getBufferFloat().put(0, value));
/* 222:    */     }
/* 223:    */     
/* 224:    */     public void setArg(CLKernel kernel, int index, double value)
/* 225:    */     {
/* 226:230 */       CL10.clSetKernelArg(kernel, index, 8L, APIUtil.getBufferDouble().put(0, value));
/* 227:    */     }
/* 228:    */     
/* 229:    */     public void setArg(CLKernel kernel, int index, CLObject value)
/* 230:    */     {
/* 231:234 */       CL10.clSetKernelArg(kernel, index, value);
/* 232:    */     }
/* 233:    */     
/* 234:    */     public void setArgSize(CLKernel kernel, int index, long size)
/* 235:    */     {
/* 236:238 */       CL10.clSetKernelArg(kernel, index, size);
/* 237:    */     }
/* 238:    */     
/* 239:    */     protected int getInfo(CLKernel kernel, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 240:    */     {
/* 241:242 */       return CL10.clGetKernelInfo(kernel, param_name, param_value, param_value_size_ret);
/* 242:    */     }
/* 243:    */     
/* 244:    */     public long getWorkGroupInfoSize(CLKernel kernel, CLDevice device, int param_name)
/* 245:    */     {
/* 246:246 */       device.checkValid();
/* 247:    */       
/* 248:248 */       PointerBuffer buffer = APIUtil.getBufferPointer();
/* 249:249 */       CL10.clGetKernelWorkGroupInfo(kernel, device, param_name, buffer.getBuffer(), null);
/* 250:    */       
/* 251:251 */       return buffer.get(0);
/* 252:    */     }
/* 253:    */     
/* 254:    */     public long[] getWorkGroupInfoSizeArray(CLKernel kernel, CLDevice device, int param_name)
/* 255:    */     {
/* 256:255 */       device.checkValid();
/* 257:    */       int size;
/* 258:258 */       switch (param_name)
/* 259:    */       {
/* 260:    */       case 4529: 
/* 261:260 */         size = 3;
/* 262:261 */         break;
/* 263:    */       default: 
/* 264:263 */         throw new IllegalArgumentException("Unsupported parameter: " + LWJGLUtil.toHexString(param_name));
/* 265:    */       }
/* 266:266 */       PointerBuffer buffer = APIUtil.getBufferPointer(size);
/* 267:    */       
/* 268:268 */       CL10.clGetKernelWorkGroupInfo(kernel, device, param_name, buffer.getBuffer(), null);
/* 269:    */       
/* 270:270 */       long[] array = new long[size];
/* 271:271 */       for (int i = 0; i < size; i++) {
/* 272:272 */         array[i] = buffer.get(i);
/* 273:    */       }
/* 274:274 */       return array;
/* 275:    */     }
/* 276:    */     
/* 277:    */     public long getWorkGroupInfoLong(CLKernel kernel, CLDevice device, int param_name)
/* 278:    */     {
/* 279:278 */       device.checkValid();
/* 280:    */       
/* 281:280 */       ByteBuffer buffer = APIUtil.getBufferByte(8);
/* 282:281 */       CL10.clGetKernelWorkGroupInfo(kernel, device, param_name, buffer, null);
/* 283:    */       
/* 284:283 */       return buffer.getLong(0);
/* 285:    */     }
/* 286:    */   }
/* 287:    */   
/* 288:288 */   static final CLMem.CLMemUtil CL_MEM_UTIL = new CLMemUtil(null);
/* 289:    */   
/* 290:    */   private static final class CLMemUtil
/* 291:    */     extends InfoUtilAbstract<CLMem>
/* 292:    */     implements CLMem.CLMemUtil
/* 293:    */   {
/* 294:    */     protected int getInfo(CLMem mem, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 295:    */     {
/* 296:292 */       return CL10.clGetMemObjectInfo(mem, param_name, param_value, param_value_size_ret);
/* 297:    */     }
/* 298:    */     
/* 299:    */     public CLMem createImage2D(CLContext context, long flags, CLImageFormat image_format, long image_width, long image_height, long image_row_pitch, Buffer host_ptr, IntBuffer errcode_ret)
/* 300:    */     {
/* 301:296 */       ByteBuffer formatBuffer = APIUtil.getBufferByte(8);
/* 302:297 */       formatBuffer.putInt(0, image_format.getChannelOrder());
/* 303:298 */       formatBuffer.putInt(4, image_format.getChannelType());
/* 304:    */       
/* 305:300 */       long function_pointer = CLCapabilities.clCreateImage2D;
/* 306:301 */       BufferChecks.checkFunctionAddress(function_pointer);
/* 307:302 */       if (errcode_ret != null) {
/* 308:303 */         BufferChecks.checkBuffer(errcode_ret, 1);
/* 309:304 */       } else if (LWJGLUtil.DEBUG) {
/* 310:305 */         errcode_ret = APIUtil.getBufferInt();
/* 311:    */       }
/* 312:307 */       CLMem __result = new CLMem(CL10.nclCreateImage2D(context.getPointer(), flags, MemoryUtil.getAddress(formatBuffer, 0), image_width, image_height, image_row_pitch, MemoryUtil.getAddress0Safe(host_ptr) + (host_ptr != null ? BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage2DSize(formatBuffer, image_width, image_height, image_row_pitch)) : 0), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 313:310 */       if (LWJGLUtil.DEBUG) {
/* 314:311 */         Util.checkCLError(errcode_ret.get(0));
/* 315:    */       }
/* 316:312 */       return __result;
/* 317:    */     }
/* 318:    */     
/* 319:    */     public CLMem createImage3D(CLContext context, long flags, CLImageFormat image_format, long image_width, long image_height, long image_depth, long image_row_pitch, long image_slice_pitch, Buffer host_ptr, IntBuffer errcode_ret)
/* 320:    */     {
/* 321:316 */       ByteBuffer formatBuffer = APIUtil.getBufferByte(8);
/* 322:317 */       formatBuffer.putInt(0, image_format.getChannelOrder());
/* 323:318 */       formatBuffer.putInt(4, image_format.getChannelType());
/* 324:    */       
/* 325:320 */       long function_pointer = CLCapabilities.clCreateImage3D;
/* 326:321 */       BufferChecks.checkFunctionAddress(function_pointer);
/* 327:322 */       if (errcode_ret != null) {
/* 328:323 */         BufferChecks.checkBuffer(errcode_ret, 1);
/* 329:324 */       } else if (LWJGLUtil.DEBUG) {
/* 330:325 */         errcode_ret = APIUtil.getBufferInt();
/* 331:    */       }
/* 332:327 */       CLMem __result = new CLMem(CL10.nclCreateImage3D(context.getPointer(), flags, MemoryUtil.getAddress(formatBuffer, 0), image_width, image_height, image_depth, image_row_pitch, image_slice_pitch, MemoryUtil.getAddress0Safe(host_ptr) + (host_ptr != null ? BufferChecks.checkBuffer(host_ptr, CLChecks.calculateImage3DSize(formatBuffer, image_width, image_height, image_depth, image_row_pitch, image_slice_pitch)) : 0), MemoryUtil.getAddressSafe(errcode_ret), function_pointer), context);
/* 333:330 */       if (LWJGLUtil.DEBUG) {
/* 334:331 */         Util.checkCLError(errcode_ret.get(0));
/* 335:    */       }
/* 336:332 */       return __result;
/* 337:    */     }
/* 338:    */     
/* 339:    */     public CLMem createSubBuffer(CLMem mem, long flags, int buffer_create_type, CLBufferRegion buffer_create_info, IntBuffer errcode_ret)
/* 340:    */     {
/* 341:336 */       PointerBuffer infoBuffer = APIUtil.getBufferPointer(2);
/* 342:    */       
/* 343:338 */       infoBuffer.put(buffer_create_info.getOrigin());
/* 344:339 */       infoBuffer.put(buffer_create_info.getSize());
/* 345:    */       
/* 346:341 */       return CL11.clCreateSubBuffer(mem, flags, buffer_create_type, infoBuffer.getBuffer(), errcode_ret);
/* 347:    */     }
/* 348:    */     
/* 349:    */     public ByteBuffer getInfoHostBuffer(CLMem mem)
/* 350:    */     {
/* 351:345 */       mem.checkValid();
/* 352:347 */       if (LWJGLUtil.DEBUG)
/* 353:    */       {
/* 354:348 */         long mem_flags = getInfoLong(mem, 4353);
/* 355:349 */         if ((mem_flags & 0x8) != 8L) {
/* 356:350 */           throw new IllegalArgumentException("The specified CLMem object does not use host memory.");
/* 357:    */         }
/* 358:    */       }
/* 359:353 */       long size = getInfoSize(mem, 4354);
/* 360:354 */       if (size == 0L) {
/* 361:355 */         return null;
/* 362:    */       }
/* 363:357 */       long address = getInfoSize(mem, 4355);
/* 364:    */       
/* 365:359 */       return CL.getHostBuffer(address, (int)size);
/* 366:    */     }
/* 367:    */     
/* 368:    */     public long getImageInfoSize(CLMem mem, int param_name)
/* 369:    */     {
/* 370:363 */       mem.checkValid();
/* 371:    */       
/* 372:365 */       PointerBuffer buffer = APIUtil.getBufferPointer();
/* 373:366 */       CL10.clGetImageInfo(mem, param_name, buffer.getBuffer(), null);
/* 374:    */       
/* 375:368 */       return buffer.get(0);
/* 376:    */     }
/* 377:    */     
/* 378:    */     public CLImageFormat getImageInfoFormat(CLMem mem)
/* 379:    */     {
/* 380:372 */       mem.checkValid();
/* 381:    */       
/* 382:374 */       ByteBuffer format = APIUtil.getBufferByte(8);
/* 383:    */       
/* 384:376 */       CL10.clGetImageInfo(mem, 4368, format, null);
/* 385:    */       
/* 386:378 */       return new CLImageFormat(format.getInt(0), format.getInt(4));
/* 387:    */     }
/* 388:    */     
/* 389:    */     public int getImageInfoFormat(CLMem mem, int index)
/* 390:    */     {
/* 391:382 */       mem.checkValid();
/* 392:    */       
/* 393:384 */       ByteBuffer format = APIUtil.getBufferByte(8);
/* 394:    */       
/* 395:386 */       CL10.clGetImageInfo(mem, 4368, format, null);
/* 396:    */       
/* 397:388 */       return format.getInt(index << 2);
/* 398:    */     }
/* 399:    */     
/* 400:    */     public int getGLObjectType(CLMem mem)
/* 401:    */     {
/* 402:392 */       mem.checkValid();
/* 403:    */       
/* 404:394 */       IntBuffer buffer = APIUtil.getBufferInt();
/* 405:395 */       CL10GL.clGetGLObjectInfo(mem, buffer, null);
/* 406:    */       
/* 407:397 */       return buffer.get(0);
/* 408:    */     }
/* 409:    */     
/* 410:    */     public int getGLObjectName(CLMem mem)
/* 411:    */     {
/* 412:401 */       mem.checkValid();
/* 413:    */       
/* 414:403 */       IntBuffer buffer = APIUtil.getBufferInt();
/* 415:404 */       CL10GL.clGetGLObjectInfo(mem, null, buffer);
/* 416:    */       
/* 417:406 */       return buffer.get(0);
/* 418:    */     }
/* 419:    */     
/* 420:    */     public int getGLTextureInfoInt(CLMem mem, int param_name)
/* 421:    */     {
/* 422:410 */       mem.checkValid();
/* 423:    */       
/* 424:412 */       ByteBuffer buffer = APIUtil.getBufferByte(4);
/* 425:413 */       CL10GL.clGetGLTextureInfo(mem, param_name, buffer, null);
/* 426:    */       
/* 427:415 */       return buffer.getInt(0);
/* 428:    */     }
/* 429:    */   }
/* 430:    */   
/* 431:420 */   static final CLPlatform.CLPlatformUtil CL_PLATFORM_UTIL = new CLPlatformUtil(null);
/* 432:    */   
/* 433:    */   private static final class CLPlatformUtil
/* 434:    */     extends InfoUtilAbstract<CLPlatform>
/* 435:    */     implements CLPlatform.CLPlatformUtil
/* 436:    */   {
/* 437:    */     protected int getInfo(CLPlatform platform, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 438:    */     {
/* 439:424 */       return CL10.clGetPlatformInfo(platform, param_name, param_value, param_value_size_ret);
/* 440:    */     }
/* 441:    */     
/* 442:    */     public List<CLPlatform> getPlatforms(Filter<CLPlatform> filter)
/* 443:    */     {
/* 444:428 */       IntBuffer numBuffer = APIUtil.getBufferInt();
/* 445:429 */       CL10.clGetPlatformIDs(null, numBuffer);
/* 446:    */       
/* 447:431 */       int num_platforms = numBuffer.get(0);
/* 448:432 */       if (num_platforms == 0) {
/* 449:433 */         return null;
/* 450:    */       }
/* 451:435 */       PointerBuffer platformIDs = APIUtil.getBufferPointer(num_platforms);
/* 452:436 */       CL10.clGetPlatformIDs(platformIDs, null);
/* 453:    */       
/* 454:438 */       List<CLPlatform> platforms = new ArrayList(num_platforms);
/* 455:439 */       for (int i = 0; i < num_platforms; i++)
/* 456:    */       {
/* 457:440 */         CLPlatform platform = CLPlatform.getCLPlatform(platformIDs.get(i));
/* 458:441 */         if ((filter == null) || (filter.accept(platform))) {
/* 459:442 */           platforms.add(platform);
/* 460:    */         }
/* 461:    */       }
/* 462:445 */       return platforms.size() == 0 ? null : platforms;
/* 463:    */     }
/* 464:    */     
/* 465:    */     public List<CLDevice> getDevices(CLPlatform platform, int device_type, Filter<CLDevice> filter)
/* 466:    */     {
/* 467:449 */       platform.checkValid();
/* 468:    */       
/* 469:451 */       IntBuffer numBuffer = APIUtil.getBufferInt();
/* 470:452 */       CL10.clGetDeviceIDs(platform, device_type, null, numBuffer);
/* 471:    */       
/* 472:454 */       int num_devices = numBuffer.get(0);
/* 473:455 */       if (num_devices == 0) {
/* 474:456 */         return null;
/* 475:    */       }
/* 476:458 */       PointerBuffer deviceIDs = APIUtil.getBufferPointer(num_devices);
/* 477:459 */       CL10.clGetDeviceIDs(platform, device_type, deviceIDs, null);
/* 478:    */       
/* 479:461 */       List<CLDevice> devices = new ArrayList(num_devices);
/* 480:462 */       for (int i = 0; i < num_devices; i++)
/* 481:    */       {
/* 482:463 */         CLDevice device = platform.getCLDevice(deviceIDs.get(i));
/* 483:464 */         if ((filter == null) || (filter.accept(device))) {
/* 484:465 */           devices.add(device);
/* 485:    */         }
/* 486:    */       }
/* 487:468 */       return devices.size() == 0 ? null : devices;
/* 488:    */     }
/* 489:    */   }
/* 490:    */   
/* 491:473 */   static final CLProgram.CLProgramUtil CL_PROGRAM_UTIL = new CLProgramUtil(null);
/* 492:    */   
/* 493:    */   private static final class CLProgramUtil
/* 494:    */     extends InfoUtilAbstract<CLProgram>
/* 495:    */     implements CLProgram.CLProgramUtil
/* 496:    */   {
/* 497:    */     protected int getInfo(CLProgram program, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 498:    */     {
/* 499:477 */       return CL10.clGetProgramInfo(program, param_name, param_value, param_value_size_ret);
/* 500:    */     }
/* 501:    */     
/* 502:    */     protected int getInfoSizeArraySize(CLProgram program, int param_name)
/* 503:    */     {
/* 504:481 */       switch (param_name)
/* 505:    */       {
/* 506:    */       case 4453: 
/* 507:483 */         return getInfoInt(program, 4450);
/* 508:    */       }
/* 509:485 */       throw new IllegalArgumentException("Unsupported parameter: " + LWJGLUtil.toHexString(param_name));
/* 510:    */     }
/* 511:    */     
/* 512:    */     public CLKernel[] createKernelsInProgram(CLProgram program)
/* 513:    */     {
/* 514:490 */       IntBuffer numBuffer = APIUtil.getBufferInt();
/* 515:491 */       CL10.clCreateKernelsInProgram(program, null, numBuffer);
/* 516:    */       
/* 517:493 */       int num_kernels = numBuffer.get(0);
/* 518:494 */       if (num_kernels == 0) {
/* 519:495 */         return null;
/* 520:    */       }
/* 521:497 */       PointerBuffer kernelIDs = APIUtil.getBufferPointer(num_kernels);
/* 522:498 */       CL10.clCreateKernelsInProgram(program, kernelIDs, null);
/* 523:    */       
/* 524:500 */       CLKernel[] kernels = new CLKernel[num_kernels];
/* 525:501 */       for (int i = 0; i < num_kernels; i++) {
/* 526:502 */         kernels[i] = program.getCLKernel(kernelIDs.get(i));
/* 527:    */       }
/* 528:504 */       return kernels;
/* 529:    */     }
/* 530:    */     
/* 531:    */     public CLDevice[] getInfoDevices(CLProgram program)
/* 532:    */     {
/* 533:508 */       program.checkValid();
/* 534:    */       
/* 535:510 */       int size = getInfoInt(program, 4450);
/* 536:511 */       PointerBuffer buffer = APIUtil.getBufferPointer(size);
/* 537:    */       
/* 538:513 */       CL10.clGetProgramInfo(program, 4451, buffer.getBuffer(), null);
/* 539:    */       
/* 540:515 */       CLPlatform platform = (CLPlatform)((CLContext)program.getParent()).getParent();
/* 541:516 */       CLDevice[] array = new CLDevice[size];
/* 542:517 */       for (int i = 0; i < size; i++) {
/* 543:518 */         array[i] = platform.getCLDevice(buffer.get(i));
/* 544:    */       }
/* 545:520 */       return array;
/* 546:    */     }
/* 547:    */     
/* 548:    */     public ByteBuffer getInfoBinaries(CLProgram program, ByteBuffer target)
/* 549:    */     {
/* 550:524 */       program.checkValid();
/* 551:    */       
/* 552:526 */       PointerBuffer sizes = getSizesBuffer(program, 4453);
/* 553:    */       
/* 554:528 */       int totalSize = 0;
/* 555:529 */       for (int i = 0; i < sizes.limit(); i++) {
/* 556:530 */         totalSize = (int)(totalSize + sizes.get(i));
/* 557:    */       }
/* 558:532 */       if (target == null) {
/* 559:533 */         target = BufferUtils.createByteBuffer(totalSize);
/* 560:534 */       } else if (LWJGLUtil.DEBUG) {
/* 561:535 */         BufferChecks.checkBuffer(target, totalSize);
/* 562:    */       }
/* 563:537 */       CL10.clGetProgramInfo(program, sizes, target, null);
/* 564:    */       
/* 565:539 */       return target;
/* 566:    */     }
/* 567:    */     
/* 568:    */     public ByteBuffer[] getInfoBinaries(CLProgram program, ByteBuffer[] target)
/* 569:    */     {
/* 570:543 */       program.checkValid();
/* 571:545 */       if (target == null)
/* 572:    */       {
/* 573:546 */         PointerBuffer sizes = getSizesBuffer(program, 4453);
/* 574:    */         
/* 575:548 */         target = new ByteBuffer[sizes.remaining()];
/* 576:549 */         for (int i = 0; i < sizes.remaining(); i++) {
/* 577:550 */           target[i] = BufferUtils.createByteBuffer((int)sizes.get(0));
/* 578:    */         }
/* 579:    */       }
/* 580:551 */       else if (LWJGLUtil.DEBUG)
/* 581:    */       {
/* 582:552 */         PointerBuffer sizes = getSizesBuffer(program, 4453);
/* 583:554 */         if (target.length < sizes.remaining()) {
/* 584:555 */           throw new IllegalArgumentException("The target array is not big enough: " + sizes.remaining() + " buffers are required.");
/* 585:    */         }
/* 586:557 */         for (int i = 0; i < target.length; i++) {
/* 587:558 */           BufferChecks.checkBuffer(target[i], (int)sizes.get(i));
/* 588:    */         }
/* 589:    */       }
/* 590:561 */       CL10.clGetProgramInfo(program, target, null);
/* 591:    */       
/* 592:563 */       return target;
/* 593:    */     }
/* 594:    */     
/* 595:    */     public String getBuildInfoString(CLProgram program, CLDevice device, int param_name)
/* 596:    */     {
/* 597:567 */       program.checkValid();
/* 598:    */       
/* 599:569 */       int bytes = getBuildSizeRet(program, device, param_name);
/* 600:570 */       if (bytes <= 1) {
/* 601:571 */         return null;
/* 602:    */       }
/* 603:573 */       ByteBuffer buffer = APIUtil.getBufferByte(bytes);
/* 604:574 */       CL10.clGetProgramBuildInfo(program, device, param_name, buffer, null);
/* 605:    */       
/* 606:576 */       buffer.limit(bytes - 1);
/* 607:577 */       return APIUtil.getString(buffer);
/* 608:    */     }
/* 609:    */     
/* 610:    */     public int getBuildInfoInt(CLProgram program, CLDevice device, int param_name)
/* 611:    */     {
/* 612:581 */       program.checkValid();
/* 613:    */       
/* 614:583 */       ByteBuffer buffer = APIUtil.getBufferByte(4);
/* 615:584 */       CL10.clGetProgramBuildInfo(program, device, param_name, buffer, null);
/* 616:    */       
/* 617:586 */       return buffer.getInt(0);
/* 618:    */     }
/* 619:    */     
/* 620:    */     private static int getBuildSizeRet(CLProgram program, CLDevice device, int param_name)
/* 621:    */     {
/* 622:590 */       PointerBuffer bytes = APIUtil.getBufferPointer();
/* 623:591 */       int errcode = CL10.clGetProgramBuildInfo(program, device, param_name, null, bytes);
/* 624:592 */       if (errcode != 0) {
/* 625:593 */         throw new IllegalArgumentException("Invalid parameter specified: " + LWJGLUtil.toHexString(param_name));
/* 626:    */       }
/* 627:595 */       return (int)bytes.get(0);
/* 628:    */     }
/* 629:    */   }
/* 630:    */   
/* 631:600 */   static final InfoUtil<CLSampler> CL_SAMPLER_UTIL = new InfoUtilAbstract()
/* 632:    */   {
/* 633:    */     protected int getInfo(CLSampler sampler, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 634:    */     {
/* 635:602 */       return CL10.clGetSamplerInfo(sampler, param_name, param_value, param_value_size_ret);
/* 636:    */     }
/* 637:    */   };
/* 638:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.InfoUtilFactory
 * JD-Core Version:    0.7.0.1
 */