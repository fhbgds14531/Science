/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ import org.lwjgl.MemoryUtil;
/*  12:    */ 
/*  13:    */ public final class GL15
/*  14:    */ {
/*  15:    */   public static final int GL_ARRAY_BUFFER = 34962;
/*  16:    */   public static final int GL_ELEMENT_ARRAY_BUFFER = 34963;
/*  17:    */   public static final int GL_ARRAY_BUFFER_BINDING = 34964;
/*  18:    */   public static final int GL_ELEMENT_ARRAY_BUFFER_BINDING = 34965;
/*  19:    */   public static final int GL_VERTEX_ARRAY_BUFFER_BINDING = 34966;
/*  20:    */   public static final int GL_NORMAL_ARRAY_BUFFER_BINDING = 34967;
/*  21:    */   public static final int GL_COLOR_ARRAY_BUFFER_BINDING = 34968;
/*  22:    */   public static final int GL_INDEX_ARRAY_BUFFER_BINDING = 34969;
/*  23:    */   public static final int GL_TEXTURE_COORD_ARRAY_BUFFER_BINDING = 34970;
/*  24:    */   public static final int GL_EDGE_FLAG_ARRAY_BUFFER_BINDING = 34971;
/*  25:    */   public static final int GL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING = 34972;
/*  26:    */   public static final int GL_FOG_COORDINATE_ARRAY_BUFFER_BINDING = 34973;
/*  27:    */   public static final int GL_WEIGHT_ARRAY_BUFFER_BINDING = 34974;
/*  28:    */   public static final int GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = 34975;
/*  29:    */   public static final int GL_STREAM_DRAW = 35040;
/*  30:    */   public static final int GL_STREAM_READ = 35041;
/*  31:    */   public static final int GL_STREAM_COPY = 35042;
/*  32:    */   public static final int GL_STATIC_DRAW = 35044;
/*  33:    */   public static final int GL_STATIC_READ = 35045;
/*  34:    */   public static final int GL_STATIC_COPY = 35046;
/*  35:    */   public static final int GL_DYNAMIC_DRAW = 35048;
/*  36:    */   public static final int GL_DYNAMIC_READ = 35049;
/*  37:    */   public static final int GL_DYNAMIC_COPY = 35050;
/*  38:    */   public static final int GL_READ_ONLY = 35000;
/*  39:    */   public static final int GL_WRITE_ONLY = 35001;
/*  40:    */   public static final int GL_READ_WRITE = 35002;
/*  41:    */   public static final int GL_BUFFER_SIZE = 34660;
/*  42:    */   public static final int GL_BUFFER_USAGE = 34661;
/*  43:    */   public static final int GL_BUFFER_ACCESS = 35003;
/*  44:    */   public static final int GL_BUFFER_MAPPED = 35004;
/*  45:    */   public static final int GL_BUFFER_MAP_POINTER = 35005;
/*  46:    */   public static final int GL_FOG_COORD_SRC = 33872;
/*  47:    */   public static final int GL_FOG_COORD = 33873;
/*  48:    */   public static final int GL_CURRENT_FOG_COORD = 33875;
/*  49:    */   public static final int GL_FOG_COORD_ARRAY_TYPE = 33876;
/*  50:    */   public static final int GL_FOG_COORD_ARRAY_STRIDE = 33877;
/*  51:    */   public static final int GL_FOG_COORD_ARRAY_POINTER = 33878;
/*  52:    */   public static final int GL_FOG_COORD_ARRAY = 33879;
/*  53:    */   public static final int GL_FOG_COORD_ARRAY_BUFFER_BINDING = 34973;
/*  54:    */   public static final int GL_SRC0_RGB = 34176;
/*  55:    */   public static final int GL_SRC1_RGB = 34177;
/*  56:    */   public static final int GL_SRC2_RGB = 34178;
/*  57:    */   public static final int GL_SRC0_ALPHA = 34184;
/*  58:    */   public static final int GL_SRC1_ALPHA = 34185;
/*  59:    */   public static final int GL_SRC2_ALPHA = 34186;
/*  60:    */   public static final int GL_SAMPLES_PASSED = 35092;
/*  61:    */   public static final int GL_QUERY_COUNTER_BITS = 34916;
/*  62:    */   public static final int GL_CURRENT_QUERY = 34917;
/*  63:    */   public static final int GL_QUERY_RESULT = 34918;
/*  64:    */   public static final int GL_QUERY_RESULT_AVAILABLE = 34919;
/*  65:    */   
/*  66:    */   public static void glBindBuffer(int target, int buffer)
/*  67:    */   {
/*  68: 78 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  69: 79 */     long function_pointer = caps.glBindBuffer;
/*  70: 80 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  71: 81 */     StateTracker.bindBuffer(caps, target, buffer);
/*  72: 82 */     nglBindBuffer(target, buffer, function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   static native void nglBindBuffer(int paramInt1, int paramInt2, long paramLong);
/*  76:    */   
/*  77:    */   public static void glDeleteBuffers(IntBuffer buffers)
/*  78:    */   {
/*  79: 87 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  80: 88 */     long function_pointer = caps.glDeleteBuffers;
/*  81: 89 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  82: 90 */     BufferChecks.checkDirect(buffers);
/*  83: 91 */     nglDeleteBuffers(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/*  84:    */   }
/*  85:    */   
/*  86:    */   static native void nglDeleteBuffers(int paramInt, long paramLong1, long paramLong2);
/*  87:    */   
/*  88:    */   public static void glDeleteBuffers(int buffer)
/*  89:    */   {
/*  90: 97 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  91: 98 */     long function_pointer = caps.glDeleteBuffers;
/*  92: 99 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  93:100 */     nglDeleteBuffers(1, APIUtil.getInt(caps, buffer), function_pointer);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static void glGenBuffers(IntBuffer buffers)
/*  97:    */   {
/*  98:104 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  99:105 */     long function_pointer = caps.glGenBuffers;
/* 100:106 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 101:107 */     BufferChecks.checkDirect(buffers);
/* 102:108 */     nglGenBuffers(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/* 103:    */   }
/* 104:    */   
/* 105:    */   static native void nglGenBuffers(int paramInt, long paramLong1, long paramLong2);
/* 106:    */   
/* 107:    */   public static int glGenBuffers()
/* 108:    */   {
/* 109:114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 110:115 */     long function_pointer = caps.glGenBuffers;
/* 111:116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 112:117 */     IntBuffer buffers = APIUtil.getBufferInt(caps);
/* 113:118 */     nglGenBuffers(1, MemoryUtil.getAddress(buffers), function_pointer);
/* 114:119 */     return buffers.get(0);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public static boolean glIsBuffer(int buffer)
/* 118:    */   {
/* 119:123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 120:124 */     long function_pointer = caps.glIsBuffer;
/* 121:125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 122:126 */     boolean __result = nglIsBuffer(buffer, function_pointer);
/* 123:127 */     return __result;
/* 124:    */   }
/* 125:    */   
/* 126:    */   static native boolean nglIsBuffer(int paramInt, long paramLong);
/* 127:    */   
/* 128:    */   public static void glBufferData(int target, long data_size, int usage)
/* 129:    */   {
/* 130:132 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 131:133 */     long function_pointer = caps.glBufferData;
/* 132:134 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 133:135 */     nglBufferData(target, data_size, 0L, usage, function_pointer);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static void glBufferData(int target, ByteBuffer data, int usage)
/* 137:    */   {
/* 138:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 139:139 */     long function_pointer = caps.glBufferData;
/* 140:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 141:141 */     BufferChecks.checkDirect(data);
/* 142:142 */     nglBufferData(target, data.remaining(), MemoryUtil.getAddress(data), usage, function_pointer);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static void glBufferData(int target, DoubleBuffer data, int usage)
/* 146:    */   {
/* 147:145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 148:146 */     long function_pointer = caps.glBufferData;
/* 149:147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 150:148 */     BufferChecks.checkDirect(data);
/* 151:149 */     nglBufferData(target, data.remaining() << 3, MemoryUtil.getAddress(data), usage, function_pointer);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static void glBufferData(int target, FloatBuffer data, int usage)
/* 155:    */   {
/* 156:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 157:153 */     long function_pointer = caps.glBufferData;
/* 158:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 159:155 */     BufferChecks.checkDirect(data);
/* 160:156 */     nglBufferData(target, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public static void glBufferData(int target, IntBuffer data, int usage)
/* 164:    */   {
/* 165:159 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 166:160 */     long function_pointer = caps.glBufferData;
/* 167:161 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 168:162 */     BufferChecks.checkDirect(data);
/* 169:163 */     nglBufferData(target, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static void glBufferData(int target, ShortBuffer data, int usage)
/* 173:    */   {
/* 174:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 175:167 */     long function_pointer = caps.glBufferData;
/* 176:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 177:169 */     BufferChecks.checkDirect(data);
/* 178:170 */     nglBufferData(target, data.remaining() << 1, MemoryUtil.getAddress(data), usage, function_pointer);
/* 179:    */   }
/* 180:    */   
/* 181:    */   static native void nglBufferData(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 182:    */   
/* 183:    */   public static void glBufferSubData(int target, long offset, ByteBuffer data)
/* 184:    */   {
/* 185:175 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 186:176 */     long function_pointer = caps.glBufferSubData;
/* 187:177 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 188:178 */     BufferChecks.checkDirect(data);
/* 189:179 */     nglBufferSubData(target, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static void glBufferSubData(int target, long offset, DoubleBuffer data)
/* 193:    */   {
/* 194:182 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 195:183 */     long function_pointer = caps.glBufferSubData;
/* 196:184 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 197:185 */     BufferChecks.checkDirect(data);
/* 198:186 */     nglBufferSubData(target, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static void glBufferSubData(int target, long offset, FloatBuffer data)
/* 202:    */   {
/* 203:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 204:190 */     long function_pointer = caps.glBufferSubData;
/* 205:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 206:192 */     BufferChecks.checkDirect(data);
/* 207:193 */     nglBufferSubData(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static void glBufferSubData(int target, long offset, IntBuffer data)
/* 211:    */   {
/* 212:196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 213:197 */     long function_pointer = caps.glBufferSubData;
/* 214:198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 215:199 */     BufferChecks.checkDirect(data);
/* 216:200 */     nglBufferSubData(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static void glBufferSubData(int target, long offset, ShortBuffer data)
/* 220:    */   {
/* 221:203 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 222:204 */     long function_pointer = caps.glBufferSubData;
/* 223:205 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 224:206 */     BufferChecks.checkDirect(data);
/* 225:207 */     nglBufferSubData(target, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 226:    */   }
/* 227:    */   
/* 228:    */   static native void nglBufferSubData(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 229:    */   
/* 230:    */   public static void glGetBufferSubData(int target, long offset, ByteBuffer data)
/* 231:    */   {
/* 232:212 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 233:213 */     long function_pointer = caps.glGetBufferSubData;
/* 234:214 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 235:215 */     BufferChecks.checkDirect(data);
/* 236:216 */     nglGetBufferSubData(target, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static void glGetBufferSubData(int target, long offset, DoubleBuffer data)
/* 240:    */   {
/* 241:219 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 242:220 */     long function_pointer = caps.glGetBufferSubData;
/* 243:221 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 244:222 */     BufferChecks.checkDirect(data);
/* 245:223 */     nglGetBufferSubData(target, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 246:    */   }
/* 247:    */   
/* 248:    */   public static void glGetBufferSubData(int target, long offset, FloatBuffer data)
/* 249:    */   {
/* 250:226 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 251:227 */     long function_pointer = caps.glGetBufferSubData;
/* 252:228 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 253:229 */     BufferChecks.checkDirect(data);
/* 254:230 */     nglGetBufferSubData(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 255:    */   }
/* 256:    */   
/* 257:    */   public static void glGetBufferSubData(int target, long offset, IntBuffer data)
/* 258:    */   {
/* 259:233 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 260:234 */     long function_pointer = caps.glGetBufferSubData;
/* 261:235 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 262:236 */     BufferChecks.checkDirect(data);
/* 263:237 */     nglGetBufferSubData(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static void glGetBufferSubData(int target, long offset, ShortBuffer data)
/* 267:    */   {
/* 268:240 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 269:241 */     long function_pointer = caps.glGetBufferSubData;
/* 270:242 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 271:243 */     BufferChecks.checkDirect(data);
/* 272:244 */     nglGetBufferSubData(target, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 273:    */   }
/* 274:    */   
/* 275:    */   static native void nglGetBufferSubData(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 276:    */   
/* 277:    */   public static ByteBuffer glMapBuffer(int target, int access, ByteBuffer old_buffer)
/* 278:    */   {
/* 279:271 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 280:272 */     long function_pointer = caps.glMapBuffer;
/* 281:273 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 282:274 */     if (old_buffer != null) {
/* 283:275 */       BufferChecks.checkDirect(old_buffer);
/* 284:    */     }
/* 285:276 */     ByteBuffer __result = nglMapBuffer(target, access, GLChecks.getBufferObjectSize(caps, target), old_buffer, function_pointer);
/* 286:277 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 287:    */   }
/* 288:    */   
/* 289:    */   public static ByteBuffer glMapBuffer(int target, int access, long length, ByteBuffer old_buffer)
/* 290:    */   {
/* 291:302 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 292:303 */     long function_pointer = caps.glMapBuffer;
/* 293:304 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 294:305 */     if (old_buffer != null) {
/* 295:306 */       BufferChecks.checkDirect(old_buffer);
/* 296:    */     }
/* 297:307 */     ByteBuffer __result = nglMapBuffer(target, access, length, old_buffer, function_pointer);
/* 298:308 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 299:    */   }
/* 300:    */   
/* 301:    */   static native ByteBuffer nglMapBuffer(int paramInt1, int paramInt2, long paramLong1, ByteBuffer paramByteBuffer, long paramLong2);
/* 302:    */   
/* 303:    */   public static boolean glUnmapBuffer(int target)
/* 304:    */   {
/* 305:313 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 306:314 */     long function_pointer = caps.glUnmapBuffer;
/* 307:315 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 308:316 */     boolean __result = nglUnmapBuffer(target, function_pointer);
/* 309:317 */     return __result;
/* 310:    */   }
/* 311:    */   
/* 312:    */   static native boolean nglUnmapBuffer(int paramInt, long paramLong);
/* 313:    */   
/* 314:    */   public static void glGetBufferParameter(int target, int pname, IntBuffer params)
/* 315:    */   {
/* 316:322 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 317:323 */     long function_pointer = caps.glGetBufferParameteriv;
/* 318:324 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 319:325 */     BufferChecks.checkBuffer(params, 4);
/* 320:326 */     nglGetBufferParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 321:    */   }
/* 322:    */   
/* 323:    */   static native void nglGetBufferParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 324:    */   
/* 325:    */   @Deprecated
/* 326:    */   public static int glGetBufferParameter(int target, int pname)
/* 327:    */   {
/* 328:337 */     return glGetBufferParameteri(target, pname);
/* 329:    */   }
/* 330:    */   
/* 331:    */   public static int glGetBufferParameteri(int target, int pname)
/* 332:    */   {
/* 333:342 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 334:343 */     long function_pointer = caps.glGetBufferParameteriv;
/* 335:344 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 336:345 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 337:346 */     nglGetBufferParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 338:347 */     return params.get(0);
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static ByteBuffer glGetBufferPointer(int target, int pname)
/* 342:    */   {
/* 343:351 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 344:352 */     long function_pointer = caps.glGetBufferPointerv;
/* 345:353 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 346:354 */     ByteBuffer __result = nglGetBufferPointerv(target, pname, GLChecks.getBufferObjectSize(caps, target), function_pointer);
/* 347:355 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 348:    */   }
/* 349:    */   
/* 350:    */   static native ByteBuffer nglGetBufferPointerv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 351:    */   
/* 352:    */   public static void glGenQueries(IntBuffer ids)
/* 353:    */   {
/* 354:360 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 355:361 */     long function_pointer = caps.glGenQueries;
/* 356:362 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 357:363 */     BufferChecks.checkDirect(ids);
/* 358:364 */     nglGenQueries(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 359:    */   }
/* 360:    */   
/* 361:    */   static native void nglGenQueries(int paramInt, long paramLong1, long paramLong2);
/* 362:    */   
/* 363:    */   public static int glGenQueries()
/* 364:    */   {
/* 365:370 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 366:371 */     long function_pointer = caps.glGenQueries;
/* 367:372 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 368:373 */     IntBuffer ids = APIUtil.getBufferInt(caps);
/* 369:374 */     nglGenQueries(1, MemoryUtil.getAddress(ids), function_pointer);
/* 370:375 */     return ids.get(0);
/* 371:    */   }
/* 372:    */   
/* 373:    */   public static void glDeleteQueries(IntBuffer ids)
/* 374:    */   {
/* 375:379 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 376:380 */     long function_pointer = caps.glDeleteQueries;
/* 377:381 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 378:382 */     BufferChecks.checkDirect(ids);
/* 379:383 */     nglDeleteQueries(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 380:    */   }
/* 381:    */   
/* 382:    */   static native void nglDeleteQueries(int paramInt, long paramLong1, long paramLong2);
/* 383:    */   
/* 384:    */   public static void glDeleteQueries(int id)
/* 385:    */   {
/* 386:389 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 387:390 */     long function_pointer = caps.glDeleteQueries;
/* 388:391 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 389:392 */     nglDeleteQueries(1, APIUtil.getInt(caps, id), function_pointer);
/* 390:    */   }
/* 391:    */   
/* 392:    */   public static boolean glIsQuery(int id)
/* 393:    */   {
/* 394:396 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 395:397 */     long function_pointer = caps.glIsQuery;
/* 396:398 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 397:399 */     boolean __result = nglIsQuery(id, function_pointer);
/* 398:400 */     return __result;
/* 399:    */   }
/* 400:    */   
/* 401:    */   static native boolean nglIsQuery(int paramInt, long paramLong);
/* 402:    */   
/* 403:    */   public static void glBeginQuery(int target, int id)
/* 404:    */   {
/* 405:405 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 406:406 */     long function_pointer = caps.glBeginQuery;
/* 407:407 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 408:408 */     nglBeginQuery(target, id, function_pointer);
/* 409:    */   }
/* 410:    */   
/* 411:    */   static native void nglBeginQuery(int paramInt1, int paramInt2, long paramLong);
/* 412:    */   
/* 413:    */   public static void glEndQuery(int target)
/* 414:    */   {
/* 415:413 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 416:414 */     long function_pointer = caps.glEndQuery;
/* 417:415 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 418:416 */     nglEndQuery(target, function_pointer);
/* 419:    */   }
/* 420:    */   
/* 421:    */   static native void nglEndQuery(int paramInt, long paramLong);
/* 422:    */   
/* 423:    */   public static void glGetQuery(int target, int pname, IntBuffer params)
/* 424:    */   {
/* 425:421 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 426:422 */     long function_pointer = caps.glGetQueryiv;
/* 427:423 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 428:424 */     BufferChecks.checkBuffer(params, 1);
/* 429:425 */     nglGetQueryiv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 430:    */   }
/* 431:    */   
/* 432:    */   static native void nglGetQueryiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 433:    */   
/* 434:    */   @Deprecated
/* 435:    */   public static int glGetQuery(int target, int pname)
/* 436:    */   {
/* 437:436 */     return glGetQueryi(target, pname);
/* 438:    */   }
/* 439:    */   
/* 440:    */   public static int glGetQueryi(int target, int pname)
/* 441:    */   {
/* 442:441 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 443:442 */     long function_pointer = caps.glGetQueryiv;
/* 444:443 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 445:444 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 446:445 */     nglGetQueryiv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 447:446 */     return params.get(0);
/* 448:    */   }
/* 449:    */   
/* 450:    */   public static void glGetQueryObject(int id, int pname, IntBuffer params)
/* 451:    */   {
/* 452:450 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 453:451 */     long function_pointer = caps.glGetQueryObjectiv;
/* 454:452 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 455:453 */     BufferChecks.checkBuffer(params, 1);
/* 456:454 */     nglGetQueryObjectiv(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 457:    */   }
/* 458:    */   
/* 459:    */   static native void nglGetQueryObjectiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 460:    */   
/* 461:    */   public static int glGetQueryObjecti(int id, int pname)
/* 462:    */   {
/* 463:460 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 464:461 */     long function_pointer = caps.glGetQueryObjectiv;
/* 465:462 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 466:463 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 467:464 */     nglGetQueryObjectiv(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 468:465 */     return params.get(0);
/* 469:    */   }
/* 470:    */   
/* 471:    */   public static void glGetQueryObjectu(int id, int pname, IntBuffer params)
/* 472:    */   {
/* 473:469 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 474:470 */     long function_pointer = caps.glGetQueryObjectuiv;
/* 475:471 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 476:472 */     BufferChecks.checkBuffer(params, 1);
/* 477:473 */     nglGetQueryObjectuiv(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 478:    */   }
/* 479:    */   
/* 480:    */   static native void nglGetQueryObjectuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 481:    */   
/* 482:    */   public static int glGetQueryObjectui(int id, int pname)
/* 483:    */   {
/* 484:479 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 485:480 */     long function_pointer = caps.glGetQueryObjectuiv;
/* 486:481 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 487:482 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 488:483 */     nglGetQueryObjectuiv(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 489:484 */     return params.get(0);
/* 490:    */   }
/* 491:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL15
 * JD-Core Version:    0.7.0.1
 */