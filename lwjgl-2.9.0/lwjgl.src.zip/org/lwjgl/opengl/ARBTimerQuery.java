/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.LongBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBTimerQuery
/*  6:   */ {
/*  7:   */   public static final int GL_TIME_ELAPSED = 35007;
/*  8:   */   public static final int GL_TIMESTAMP = 36392;
/*  9:   */   
/* 10:   */   public static void glQueryCounter(int id, int target)
/* 11:   */   {
/* 12:26 */     GL33.glQueryCounter(id, target);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public static void glGetQueryObject(int id, int pname, LongBuffer params)
/* 16:   */   {
/* 17:30 */     GL33.glGetQueryObject(id, pname, params);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static long glGetQueryObjecti64(int id, int pname)
/* 21:   */   {
/* 22:35 */     return GL33.glGetQueryObjecti64(id, pname);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static void glGetQueryObjectu(int id, int pname, LongBuffer params)
/* 26:   */   {
/* 27:39 */     GL33.glGetQueryObjectu(id, pname, params);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static long glGetQueryObjectui64(int id, int pname)
/* 31:   */   {
/* 32:44 */     return GL33.glGetQueryObjectui64(id, pname);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTimerQuery
 * JD-Core Version:    0.7.0.1
 */