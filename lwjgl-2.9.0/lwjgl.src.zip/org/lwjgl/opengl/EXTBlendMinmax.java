/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTBlendMinmax
/*  6:   */ {
/*  7:   */   public static final int GL_FUNC_ADD_EXT = 32774;
/*  8:   */   public static final int GL_MIN_EXT = 32775;
/*  9:   */   public static final int GL_MAX_EXT = 32776;
/* 10:   */   public static final int GL_BLEND_EQUATION_EXT = 32777;
/* 11:   */   
/* 12:   */   public static void glBlendEquationEXT(int mode)
/* 13:   */   {
/* 14:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:27 */     long function_pointer = caps.glBlendEquationEXT;
/* 16:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:29 */     nglBlendEquationEXT(mode, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglBlendEquationEXT(int paramInt, long paramLong);
/* 21:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBlendMinmax
 * JD-Core Version:    0.7.0.1
 */