/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class EXTFramebufferObject
/*   8:    */ {
/*   9:    */   public static final int GL_FRAMEBUFFER_EXT = 36160;
/*  10:    */   public static final int GL_RENDERBUFFER_EXT = 36161;
/*  11:    */   public static final int GL_STENCIL_INDEX1_EXT = 36166;
/*  12:    */   public static final int GL_STENCIL_INDEX4_EXT = 36167;
/*  13:    */   public static final int GL_STENCIL_INDEX8_EXT = 36168;
/*  14:    */   public static final int GL_STENCIL_INDEX16_EXT = 36169;
/*  15:    */   public static final int GL_RENDERBUFFER_WIDTH_EXT = 36162;
/*  16:    */   public static final int GL_RENDERBUFFER_HEIGHT_EXT = 36163;
/*  17:    */   public static final int GL_RENDERBUFFER_INTERNAL_FORMAT_EXT = 36164;
/*  18:    */   public static final int GL_RENDERBUFFER_RED_SIZE_EXT = 36176;
/*  19:    */   public static final int GL_RENDERBUFFER_GREEN_SIZE_EXT = 36177;
/*  20:    */   public static final int GL_RENDERBUFFER_BLUE_SIZE_EXT = 36178;
/*  21:    */   public static final int GL_RENDERBUFFER_ALPHA_SIZE_EXT = 36179;
/*  22:    */   public static final int GL_RENDERBUFFER_DEPTH_SIZE_EXT = 36180;
/*  23:    */   public static final int GL_RENDERBUFFER_STENCIL_SIZE_EXT = 36181;
/*  24:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE_EXT = 36048;
/*  25:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME_EXT = 36049;
/*  26:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL_EXT = 36050;
/*  27:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE_EXT = 36051;
/*  28:    */   public static final int GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_3D_ZOFFSET_EXT = 36052;
/*  29:    */   public static final int GL_COLOR_ATTACHMENT0_EXT = 36064;
/*  30:    */   public static final int GL_COLOR_ATTACHMENT1_EXT = 36065;
/*  31:    */   public static final int GL_COLOR_ATTACHMENT2_EXT = 36066;
/*  32:    */   public static final int GL_COLOR_ATTACHMENT3_EXT = 36067;
/*  33:    */   public static final int GL_COLOR_ATTACHMENT4_EXT = 36068;
/*  34:    */   public static final int GL_COLOR_ATTACHMENT5_EXT = 36069;
/*  35:    */   public static final int GL_COLOR_ATTACHMENT6_EXT = 36070;
/*  36:    */   public static final int GL_COLOR_ATTACHMENT7_EXT = 36071;
/*  37:    */   public static final int GL_COLOR_ATTACHMENT8_EXT = 36072;
/*  38:    */   public static final int GL_COLOR_ATTACHMENT9_EXT = 36073;
/*  39:    */   public static final int GL_COLOR_ATTACHMENT10_EXT = 36074;
/*  40:    */   public static final int GL_COLOR_ATTACHMENT11_EXT = 36075;
/*  41:    */   public static final int GL_COLOR_ATTACHMENT12_EXT = 36076;
/*  42:    */   public static final int GL_COLOR_ATTACHMENT13_EXT = 36077;
/*  43:    */   public static final int GL_COLOR_ATTACHMENT14_EXT = 36078;
/*  44:    */   public static final int GL_COLOR_ATTACHMENT15_EXT = 36079;
/*  45:    */   public static final int GL_DEPTH_ATTACHMENT_EXT = 36096;
/*  46:    */   public static final int GL_STENCIL_ATTACHMENT_EXT = 36128;
/*  47:    */   public static final int GL_FRAMEBUFFER_COMPLETE_EXT = 36053;
/*  48:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT = 36054;
/*  49:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT = 36055;
/*  50:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT = 36057;
/*  51:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT = 36058;
/*  52:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT = 36059;
/*  53:    */   public static final int GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT = 36060;
/*  54:    */   public static final int GL_FRAMEBUFFER_UNSUPPORTED_EXT = 36061;
/*  55:    */   public static final int GL_FRAMEBUFFER_BINDING_EXT = 36006;
/*  56:    */   public static final int GL_RENDERBUFFER_BINDING_EXT = 36007;
/*  57:    */   public static final int GL_MAX_COLOR_ATTACHMENTS_EXT = 36063;
/*  58:    */   public static final int GL_MAX_RENDERBUFFER_SIZE_EXT = 34024;
/*  59:    */   public static final int GL_INVALID_FRAMEBUFFER_OPERATION_EXT = 1286;
/*  60:    */   
/*  61:    */   public static boolean glIsRenderbufferEXT(int renderbuffer)
/*  62:    */   {
/*  63:108 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  64:109 */     long function_pointer = caps.glIsRenderbufferEXT;
/*  65:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  66:111 */     boolean __result = nglIsRenderbufferEXT(renderbuffer, function_pointer);
/*  67:112 */     return __result;
/*  68:    */   }
/*  69:    */   
/*  70:    */   static native boolean nglIsRenderbufferEXT(int paramInt, long paramLong);
/*  71:    */   
/*  72:    */   public static void glBindRenderbufferEXT(int target, int renderbuffer)
/*  73:    */   {
/*  74:117 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  75:118 */     long function_pointer = caps.glBindRenderbufferEXT;
/*  76:119 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  77:120 */     nglBindRenderbufferEXT(target, renderbuffer, function_pointer);
/*  78:    */   }
/*  79:    */   
/*  80:    */   static native void nglBindRenderbufferEXT(int paramInt1, int paramInt2, long paramLong);
/*  81:    */   
/*  82:    */   public static void glDeleteRenderbuffersEXT(IntBuffer renderbuffers)
/*  83:    */   {
/*  84:125 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  85:126 */     long function_pointer = caps.glDeleteRenderbuffersEXT;
/*  86:127 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  87:128 */     BufferChecks.checkDirect(renderbuffers);
/*  88:129 */     nglDeleteRenderbuffersEXT(renderbuffers.remaining(), MemoryUtil.getAddress(renderbuffers), function_pointer);
/*  89:    */   }
/*  90:    */   
/*  91:    */   static native void nglDeleteRenderbuffersEXT(int paramInt, long paramLong1, long paramLong2);
/*  92:    */   
/*  93:    */   public static void glDeleteRenderbuffersEXT(int renderbuffer)
/*  94:    */   {
/*  95:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  96:136 */     long function_pointer = caps.glDeleteRenderbuffersEXT;
/*  97:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  98:138 */     nglDeleteRenderbuffersEXT(1, APIUtil.getInt(caps, renderbuffer), function_pointer);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static void glGenRenderbuffersEXT(IntBuffer renderbuffers)
/* 102:    */   {
/* 103:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104:143 */     long function_pointer = caps.glGenRenderbuffersEXT;
/* 105:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106:145 */     BufferChecks.checkDirect(renderbuffers);
/* 107:146 */     nglGenRenderbuffersEXT(renderbuffers.remaining(), MemoryUtil.getAddress(renderbuffers), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglGenRenderbuffersEXT(int paramInt, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static int glGenRenderbuffersEXT()
/* 113:    */   {
/* 114:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:153 */     long function_pointer = caps.glGenRenderbuffersEXT;
/* 116:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:155 */     IntBuffer renderbuffers = APIUtil.getBufferInt(caps);
/* 118:156 */     nglGenRenderbuffersEXT(1, MemoryUtil.getAddress(renderbuffers), function_pointer);
/* 119:157 */     return renderbuffers.get(0);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static void glRenderbufferStorageEXT(int target, int internalformat, int width, int height)
/* 123:    */   {
/* 124:161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 125:162 */     long function_pointer = caps.glRenderbufferStorageEXT;
/* 126:163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 127:164 */     nglRenderbufferStorageEXT(target, internalformat, width, height, function_pointer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   static native void nglRenderbufferStorageEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 131:    */   
/* 132:    */   public static void glGetRenderbufferParameterEXT(int target, int pname, IntBuffer params)
/* 133:    */   {
/* 134:169 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 135:170 */     long function_pointer = caps.glGetRenderbufferParameterivEXT;
/* 136:171 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 137:172 */     BufferChecks.checkBuffer(params, 4);
/* 138:173 */     nglGetRenderbufferParameterivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglGetRenderbufferParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 142:    */   
/* 143:    */   @Deprecated
/* 144:    */   public static int glGetRenderbufferParameterEXT(int target, int pname)
/* 145:    */   {
/* 146:184 */     return glGetRenderbufferParameteriEXT(target, pname);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static int glGetRenderbufferParameteriEXT(int target, int pname)
/* 150:    */   {
/* 151:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 152:190 */     long function_pointer = caps.glGetRenderbufferParameterivEXT;
/* 153:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 154:192 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 155:193 */     nglGetRenderbufferParameterivEXT(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 156:194 */     return params.get(0);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static boolean glIsFramebufferEXT(int framebuffer)
/* 160:    */   {
/* 161:198 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 162:199 */     long function_pointer = caps.glIsFramebufferEXT;
/* 163:200 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 164:201 */     boolean __result = nglIsFramebufferEXT(framebuffer, function_pointer);
/* 165:202 */     return __result;
/* 166:    */   }
/* 167:    */   
/* 168:    */   static native boolean nglIsFramebufferEXT(int paramInt, long paramLong);
/* 169:    */   
/* 170:    */   public static void glBindFramebufferEXT(int target, int framebuffer)
/* 171:    */   {
/* 172:207 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 173:208 */     long function_pointer = caps.glBindFramebufferEXT;
/* 174:209 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 175:210 */     nglBindFramebufferEXT(target, framebuffer, function_pointer);
/* 176:    */   }
/* 177:    */   
/* 178:    */   static native void nglBindFramebufferEXT(int paramInt1, int paramInt2, long paramLong);
/* 179:    */   
/* 180:    */   public static void glDeleteFramebuffersEXT(IntBuffer framebuffers)
/* 181:    */   {
/* 182:215 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 183:216 */     long function_pointer = caps.glDeleteFramebuffersEXT;
/* 184:217 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 185:218 */     BufferChecks.checkDirect(framebuffers);
/* 186:219 */     nglDeleteFramebuffersEXT(framebuffers.remaining(), MemoryUtil.getAddress(framebuffers), function_pointer);
/* 187:    */   }
/* 188:    */   
/* 189:    */   static native void nglDeleteFramebuffersEXT(int paramInt, long paramLong1, long paramLong2);
/* 190:    */   
/* 191:    */   public static void glDeleteFramebuffersEXT(int framebuffer)
/* 192:    */   {
/* 193:225 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 194:226 */     long function_pointer = caps.glDeleteFramebuffersEXT;
/* 195:227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 196:228 */     nglDeleteFramebuffersEXT(1, APIUtil.getInt(caps, framebuffer), function_pointer);
/* 197:    */   }
/* 198:    */   
/* 199:    */   public static void glGenFramebuffersEXT(IntBuffer framebuffers)
/* 200:    */   {
/* 201:232 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 202:233 */     long function_pointer = caps.glGenFramebuffersEXT;
/* 203:234 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 204:235 */     BufferChecks.checkDirect(framebuffers);
/* 205:236 */     nglGenFramebuffersEXT(framebuffers.remaining(), MemoryUtil.getAddress(framebuffers), function_pointer);
/* 206:    */   }
/* 207:    */   
/* 208:    */   static native void nglGenFramebuffersEXT(int paramInt, long paramLong1, long paramLong2);
/* 209:    */   
/* 210:    */   public static int glGenFramebuffersEXT()
/* 211:    */   {
/* 212:242 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 213:243 */     long function_pointer = caps.glGenFramebuffersEXT;
/* 214:244 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 215:245 */     IntBuffer framebuffers = APIUtil.getBufferInt(caps);
/* 216:246 */     nglGenFramebuffersEXT(1, MemoryUtil.getAddress(framebuffers), function_pointer);
/* 217:247 */     return framebuffers.get(0);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public static int glCheckFramebufferStatusEXT(int target)
/* 221:    */   {
/* 222:251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 223:252 */     long function_pointer = caps.glCheckFramebufferStatusEXT;
/* 224:253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 225:254 */     int __result = nglCheckFramebufferStatusEXT(target, function_pointer);
/* 226:255 */     return __result;
/* 227:    */   }
/* 228:    */   
/* 229:    */   static native int nglCheckFramebufferStatusEXT(int paramInt, long paramLong);
/* 230:    */   
/* 231:    */   public static void glFramebufferTexture1DEXT(int target, int attachment, int textarget, int texture, int level)
/* 232:    */   {
/* 233:260 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 234:261 */     long function_pointer = caps.glFramebufferTexture1DEXT;
/* 235:262 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 236:263 */     nglFramebufferTexture1DEXT(target, attachment, textarget, texture, level, function_pointer);
/* 237:    */   }
/* 238:    */   
/* 239:    */   static native void nglFramebufferTexture1DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 240:    */   
/* 241:    */   public static void glFramebufferTexture2DEXT(int target, int attachment, int textarget, int texture, int level)
/* 242:    */   {
/* 243:268 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 244:269 */     long function_pointer = caps.glFramebufferTexture2DEXT;
/* 245:270 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 246:271 */     nglFramebufferTexture2DEXT(target, attachment, textarget, texture, level, function_pointer);
/* 247:    */   }
/* 248:    */   
/* 249:    */   static native void nglFramebufferTexture2DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 250:    */   
/* 251:    */   public static void glFramebufferTexture3DEXT(int target, int attachment, int textarget, int texture, int level, int zoffset)
/* 252:    */   {
/* 253:276 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 254:277 */     long function_pointer = caps.glFramebufferTexture3DEXT;
/* 255:278 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 256:279 */     nglFramebufferTexture3DEXT(target, attachment, textarget, texture, level, zoffset, function_pointer);
/* 257:    */   }
/* 258:    */   
/* 259:    */   static native void nglFramebufferTexture3DEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/* 260:    */   
/* 261:    */   public static void glFramebufferRenderbufferEXT(int target, int attachment, int renderbuffertarget, int renderbuffer)
/* 262:    */   {
/* 263:284 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 264:285 */     long function_pointer = caps.glFramebufferRenderbufferEXT;
/* 265:286 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 266:287 */     nglFramebufferRenderbufferEXT(target, attachment, renderbuffertarget, renderbuffer, function_pointer);
/* 267:    */   }
/* 268:    */   
/* 269:    */   static native void nglFramebufferRenderbufferEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 270:    */   
/* 271:    */   public static void glGetFramebufferAttachmentParameterEXT(int target, int attachment, int pname, IntBuffer params)
/* 272:    */   {
/* 273:292 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 274:293 */     long function_pointer = caps.glGetFramebufferAttachmentParameterivEXT;
/* 275:294 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 276:295 */     BufferChecks.checkBuffer(params, 4);
/* 277:296 */     nglGetFramebufferAttachmentParameterivEXT(target, attachment, pname, MemoryUtil.getAddress(params), function_pointer);
/* 278:    */   }
/* 279:    */   
/* 280:    */   static native void nglGetFramebufferAttachmentParameterivEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 281:    */   
/* 282:    */   @Deprecated
/* 283:    */   public static int glGetFramebufferAttachmentParameterEXT(int target, int attachment, int pname)
/* 284:    */   {
/* 285:307 */     return glGetFramebufferAttachmentParameteriEXT(target, attachment, pname);
/* 286:    */   }
/* 287:    */   
/* 288:    */   public static int glGetFramebufferAttachmentParameteriEXT(int target, int attachment, int pname)
/* 289:    */   {
/* 290:312 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 291:313 */     long function_pointer = caps.glGetFramebufferAttachmentParameterivEXT;
/* 292:314 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 293:315 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 294:316 */     nglGetFramebufferAttachmentParameterivEXT(target, attachment, pname, MemoryUtil.getAddress(params), function_pointer);
/* 295:317 */     return params.get(0);
/* 296:    */   }
/* 297:    */   
/* 298:    */   public static void glGenerateMipmapEXT(int target)
/* 299:    */   {
/* 300:321 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 301:322 */     long function_pointer = caps.glGenerateMipmapEXT;
/* 302:323 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 303:324 */     nglGenerateMipmapEXT(target, function_pointer);
/* 304:    */   }
/* 305:    */   
/* 306:    */   static native void nglGenerateMipmapEXT(int paramInt, long paramLong);
/* 307:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTFramebufferObject
 * JD-Core Version:    0.7.0.1
 */