/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import java.nio.LongBuffer;
/*   5:    */ 
/*   6:    */ public final class ARBSync
/*   7:    */ {
/*   8:    */   public static final int GL_MAX_SERVER_WAIT_TIMEOUT = 37137;
/*   9:    */   public static final int GL_OBJECT_TYPE = 37138;
/*  10:    */   public static final int GL_SYNC_CONDITION = 37139;
/*  11:    */   public static final int GL_SYNC_STATUS = 37140;
/*  12:    */   public static final int GL_SYNC_FLAGS = 37141;
/*  13:    */   public static final int GL_SYNC_FENCE = 37142;
/*  14:    */   public static final int GL_SYNC_GPU_COMMANDS_COMPLETE = 37143;
/*  15:    */   public static final int GL_UNSIGNALED = 37144;
/*  16:    */   public static final int GL_SIGNALED = 37145;
/*  17:    */   public static final int GL_SYNC_FLUSH_COMMANDS_BIT = 1;
/*  18:    */   public static final long GL_TIMEOUT_IGNORED = -1L;
/*  19:    */   public static final int GL_ALREADY_SIGNALED = 37146;
/*  20:    */   public static final int GL_TIMEOUT_EXPIRED = 37147;
/*  21:    */   public static final int GL_CONDITION_SATISFIED = 37148;
/*  22:    */   public static final int GL_WAIT_FAILED = 37149;
/*  23:    */   
/*  24:    */   public static GLSync glFenceSync(int condition, int flags)
/*  25:    */   {
/*  26: 60 */     return GL32.glFenceSync(condition, flags);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static boolean glIsSync(GLSync sync)
/*  30:    */   {
/*  31: 64 */     return GL32.glIsSync(sync);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static void glDeleteSync(GLSync sync)
/*  35:    */   {
/*  36: 68 */     GL32.glDeleteSync(sync);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static int glClientWaitSync(GLSync sync, int flags, long timeout)
/*  40:    */   {
/*  41: 72 */     return GL32.glClientWaitSync(sync, flags, timeout);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void glWaitSync(GLSync sync, int flags, long timeout)
/*  45:    */   {
/*  46: 76 */     GL32.glWaitSync(sync, flags, timeout);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static void glGetInteger64(int pname, LongBuffer params)
/*  50:    */   {
/*  51: 80 */     GL32.glGetInteger64(pname, params);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static long glGetInteger64(int pname)
/*  55:    */   {
/*  56: 85 */     return GL32.glGetInteger64(pname);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static void glGetSync(GLSync sync, int pname, IntBuffer length, IntBuffer values)
/*  60:    */   {
/*  61: 89 */     GL32.glGetSync(sync, pname, length, values);
/*  62:    */   }
/*  63:    */   
/*  64:    */   @Deprecated
/*  65:    */   public static int glGetSync(GLSync sync, int pname)
/*  66:    */   {
/*  67: 99 */     return GL32.glGetSynci(sync, pname);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static int glGetSynci(GLSync sync, int pname)
/*  71:    */   {
/*  72:104 */     return GL32.glGetSynci(sync, pname);
/*  73:    */   }
/*  74:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBSync
 * JD-Core Version:    0.7.0.1
 */