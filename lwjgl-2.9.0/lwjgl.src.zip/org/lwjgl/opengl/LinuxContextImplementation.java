/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.LWJGLException;
/*   6:    */ 
/*   7:    */ final class LinuxContextImplementation
/*   8:    */   implements ContextImplementation
/*   9:    */ {
/*  10:    */   /* Error */
/*  11:    */   public ByteBuffer create(PeerInfo peer_info, IntBuffer attribs, ByteBuffer shared_context_handle)
/*  12:    */     throws LWJGLException
/*  13:    */   {
/*  14:    */     // Byte code:
/*  15:    */     //   0: invokestatic 2	org/lwjgl/opengl/LinuxDisplay:lockAWT	()V
/*  16:    */     //   3: aload_1
/*  17:    */     //   4: invokevirtual 3	org/lwjgl/opengl/PeerInfo:lockAndGetHandle	()Ljava/nio/ByteBuffer;
/*  18:    */     //   7: astore 4
/*  19:    */     //   9: aload 4
/*  20:    */     //   11: aload_2
/*  21:    */     //   12: aload_3
/*  22:    */     //   13: invokestatic 4	org/lwjgl/opengl/LinuxContextImplementation:nCreate	(Ljava/nio/ByteBuffer;Ljava/nio/IntBuffer;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
/*  23:    */     //   16: astore 5
/*  24:    */     //   18: aload_1
/*  25:    */     //   19: invokevirtual 5	org/lwjgl/opengl/PeerInfo:unlock	()V
/*  26:    */     //   22: invokestatic 6	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  27:    */     //   25: aload 5
/*  28:    */     //   27: areturn
/*  29:    */     //   28: astore 6
/*  30:    */     //   30: aload_1
/*  31:    */     //   31: invokevirtual 5	org/lwjgl/opengl/PeerInfo:unlock	()V
/*  32:    */     //   34: aload 6
/*  33:    */     //   36: athrow
/*  34:    */     //   37: astore 7
/*  35:    */     //   39: invokestatic 6	org/lwjgl/opengl/LinuxDisplay:unlockAWT	()V
/*  36:    */     //   42: aload 7
/*  37:    */     //   44: athrow
/*  38:    */     // Line number table:
/*  39:    */     //   Java source line #47	-> byte code offset #0
/*  40:    */     //   Java source line #49	-> byte code offset #3
/*  41:    */     //   Java source line #51	-> byte code offset #9
/*  42:    */     //   Java source line #53	-> byte code offset #18
/*  43:    */     //   Java source line #56	-> byte code offset #22
/*  44:    */     //   Java source line #53	-> byte code offset #28
/*  45:    */     //   Java source line #56	-> byte code offset #37
/*  46:    */     // Local variable table:
/*  47:    */     //   start	length	slot	name	signature
/*  48:    */     //   0	45	0	this	LinuxContextImplementation
/*  49:    */     //   0	45	1	peer_info	PeerInfo
/*  50:    */     //   0	45	2	attribs	IntBuffer
/*  51:    */     //   0	45	3	shared_context_handle	ByteBuffer
/*  52:    */     //   7	3	4	peer_handle	ByteBuffer
/*  53:    */     //   16	10	5	localByteBuffer1	ByteBuffer
/*  54:    */     //   28	7	6	localObject1	Object
/*  55:    */     //   37	6	7	localObject2	Object
/*  56:    */     // Exception table:
/*  57:    */     //   from	to	target	type
/*  58:    */     //   9	18	28	finally
/*  59:    */     //   28	30	28	finally
/*  60:    */     //   3	22	37	finally
/*  61:    */     //   28	39	37	finally
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static native ByteBuffer nCreate(ByteBuffer paramByteBuffer1, IntBuffer paramIntBuffer, ByteBuffer paramByteBuffer2)
/*  65:    */     throws LWJGLException;
/*  66:    */   
/*  67:    */   native long getGLXContext(ByteBuffer paramByteBuffer);
/*  68:    */   
/*  69:    */   native long getDisplay(ByteBuffer paramByteBuffer);
/*  70:    */   
/*  71:    */   public void releaseDrawable(ByteBuffer context_handle)
/*  72:    */     throws LWJGLException
/*  73:    */   {}
/*  74:    */   
/*  75:    */   public void swapBuffers()
/*  76:    */     throws LWJGLException
/*  77:    */   {
/*  78: 70 */     ContextGL current_context = ContextGL.getCurrentContext();
/*  79: 71 */     if (current_context == null) {
/*  80: 72 */       throw new IllegalStateException("No context is current");
/*  81:    */     }
/*  82: 73 */     synchronized (current_context)
/*  83:    */     {
/*  84: 74 */       PeerInfo current_peer_info = current_context.getPeerInfo();
/*  85: 75 */       LinuxDisplay.lockAWT();
/*  86:    */       try
/*  87:    */       {
/*  88: 77 */         ByteBuffer peer_handle = current_peer_info.lockAndGetHandle();
/*  89:    */         try
/*  90:    */         {
/*  91: 79 */           nSwapBuffers(peer_handle);
/*  92:    */         }
/*  93:    */         finally
/*  94:    */         {
/*  95: 81 */           current_peer_info.unlock();
/*  96:    */         }
/*  97:    */       }
/*  98:    */       finally
/*  99:    */       {
/* 100: 84 */         LinuxDisplay.unlockAWT();
/* 101:    */       }
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   private static native void nSwapBuffers(ByteBuffer paramByteBuffer)
/* 106:    */     throws LWJGLException;
/* 107:    */   
/* 108:    */   public void releaseCurrentContext()
/* 109:    */     throws LWJGLException
/* 110:    */   {
/* 111: 92 */     ContextGL current_context = ContextGL.getCurrentContext();
/* 112: 93 */     if (current_context == null) {
/* 113: 94 */       throw new IllegalStateException("No context is current");
/* 114:    */     }
/* 115: 95 */     synchronized (current_context)
/* 116:    */     {
/* 117: 96 */       PeerInfo current_peer_info = current_context.getPeerInfo();
/* 118: 97 */       LinuxDisplay.lockAWT();
/* 119:    */       try
/* 120:    */       {
/* 121: 99 */         ByteBuffer peer_handle = current_peer_info.lockAndGetHandle();
/* 122:    */         try
/* 123:    */         {
/* 124:101 */           nReleaseCurrentContext(peer_handle);
/* 125:    */         }
/* 126:    */         finally
/* 127:    */         {
/* 128:103 */           current_peer_info.unlock();
/* 129:    */         }
/* 130:    */       }
/* 131:    */       finally
/* 132:    */       {
/* 133:106 */         LinuxDisplay.unlockAWT();
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static native void nReleaseCurrentContext(ByteBuffer paramByteBuffer)
/* 139:    */     throws LWJGLException;
/* 140:    */   
/* 141:    */   public void update(ByteBuffer context_handle) {}
/* 142:    */   
/* 143:    */   public void makeCurrent(PeerInfo peer_info, ByteBuffer handle)
/* 144:    */     throws LWJGLException
/* 145:    */   {
/* 146:    */     
/* 147:    */     try
/* 148:    */     {
/* 149:119 */       ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/* 150:    */       try
/* 151:    */       {
/* 152:121 */         nMakeCurrent(peer_handle, handle);
/* 153:    */       }
/* 154:    */       finally
/* 155:    */       {
/* 156:123 */         peer_info.unlock();
/* 157:    */       }
/* 158:    */     }
/* 159:    */     finally
/* 160:    */     {
/* 161:126 */       LinuxDisplay.unlockAWT();
/* 162:    */     }
/* 163:    */   }
/* 164:    */   
/* 165:    */   private static native void nMakeCurrent(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/* 166:    */     throws LWJGLException;
/* 167:    */   
/* 168:    */   public boolean isCurrent(ByteBuffer handle)
/* 169:    */     throws LWJGLException
/* 170:    */   {
/* 171:    */     
/* 172:    */     try
/* 173:    */     {
/* 174:135 */       boolean result = nIsCurrent(handle);
/* 175:136 */       return result;
/* 176:    */     }
/* 177:    */     finally
/* 178:    */     {
/* 179:138 */       LinuxDisplay.unlockAWT();
/* 180:    */     }
/* 181:    */   }
/* 182:    */   
/* 183:    */   private static native boolean nIsCurrent(ByteBuffer paramByteBuffer)
/* 184:    */     throws LWJGLException;
/* 185:    */   
/* 186:    */   public void setSwapInterval(int value)
/* 187:    */   {
/* 188:145 */     ContextGL current_context = ContextGL.getCurrentContext();
/* 189:146 */     PeerInfo peer_info = current_context.getPeerInfo();
/* 190:148 */     if (current_context == null) {
/* 191:149 */       throw new IllegalStateException("No context is current");
/* 192:    */     }
/* 193:150 */     synchronized (current_context)
/* 194:    */     {
/* 195:151 */       LinuxDisplay.lockAWT();
/* 196:    */       try
/* 197:    */       {
/* 198:153 */         ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/* 199:    */         try
/* 200:    */         {
/* 201:155 */           nSetSwapInterval(peer_handle, current_context.getHandle(), value);
/* 202:    */         }
/* 203:    */         finally
/* 204:    */         {
/* 205:157 */           peer_info.unlock();
/* 206:    */         }
/* 207:    */       }
/* 208:    */       catch (LWJGLException e)
/* 209:    */       {
/* 210:161 */         e.printStackTrace();
/* 211:    */       }
/* 212:    */       finally
/* 213:    */       {
/* 214:163 */         LinuxDisplay.unlockAWT();
/* 215:    */       }
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   private static native void nSetSwapInterval(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, int paramInt);
/* 220:    */   
/* 221:    */   public void destroy(PeerInfo peer_info, ByteBuffer handle)
/* 222:    */     throws LWJGLException
/* 223:    */   {
/* 224:    */     
/* 225:    */     try
/* 226:    */     {
/* 227:173 */       ByteBuffer peer_handle = peer_info.lockAndGetHandle();
/* 228:    */       try
/* 229:    */       {
/* 230:175 */         nDestroy(peer_handle, handle);
/* 231:    */       }
/* 232:    */       finally
/* 233:    */       {
/* 234:177 */         peer_info.unlock();
/* 235:    */       }
/* 236:    */     }
/* 237:    */     finally
/* 238:    */     {
/* 239:180 */       LinuxDisplay.unlockAWT();
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static native void nDestroy(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2)
/* 244:    */     throws LWJGLException;
/* 245:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxContextImplementation
 * JD-Core Version:    0.7.0.1
 */