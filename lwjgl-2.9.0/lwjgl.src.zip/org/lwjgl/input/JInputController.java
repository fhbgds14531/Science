/*   1:    */ package org.lwjgl.input;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import net.java.games.input.Component;
/*   5:    */ import net.java.games.input.Component.Identifier.Axis;
/*   6:    */ import net.java.games.input.Component.Identifier.Button;
/*   7:    */ import net.java.games.input.Event;
/*   8:    */ import net.java.games.input.EventQueue;
/*   9:    */ import net.java.games.input.Rumbler;
/*  10:    */ 
/*  11:    */ class JInputController
/*  12:    */   implements Controller
/*  13:    */ {
/*  14:    */   private net.java.games.input.Controller target;
/*  15:    */   private int index;
/*  16: 55 */   private ArrayList<Component> buttons = new ArrayList();
/*  17: 57 */   private ArrayList<Component> axes = new ArrayList();
/*  18: 59 */   private ArrayList<Component> pov = new ArrayList();
/*  19:    */   private Rumbler[] rumblers;
/*  20:    */   private boolean[] buttonState;
/*  21:    */   private float[] povValues;
/*  22:    */   private float[] axesValue;
/*  23:    */   private float[] axesMax;
/*  24:    */   private float[] deadZones;
/*  25: 73 */   private int xaxis = -1;
/*  26: 75 */   private int yaxis = -1;
/*  27: 77 */   private int zaxis = -1;
/*  28: 79 */   private int rxaxis = -1;
/*  29: 81 */   private int ryaxis = -1;
/*  30: 83 */   private int rzaxis = -1;
/*  31:    */   
/*  32:    */   JInputController(int index, net.java.games.input.Controller target)
/*  33:    */   {
/*  34: 93 */     this.target = target;
/*  35: 94 */     this.index = index;
/*  36:    */     
/*  37: 96 */     Component[] sourceAxes = target.getComponents();
/*  38: 98 */     for (Component sourceAxis : sourceAxes) {
/*  39: 99 */       if ((sourceAxis.getIdentifier() instanceof Component.Identifier.Button)) {
/*  40:100 */         this.buttons.add(sourceAxis);
/*  41:101 */       } else if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.POV)) {
/*  42:102 */         this.pov.add(sourceAxis);
/*  43:    */       } else {
/*  44:104 */         this.axes.add(sourceAxis);
/*  45:    */       }
/*  46:    */     }
/*  47:108 */     this.buttonState = new boolean[this.buttons.size()];
/*  48:109 */     this.povValues = new float[this.pov.size()];
/*  49:110 */     this.axesValue = new float[this.axes.size()];
/*  50:111 */     int buttonsCount = 0;
/*  51:112 */     int axesCount = 0;
/*  52:115 */     for (Component sourceAxis : sourceAxes) {
/*  53:116 */       if ((sourceAxis.getIdentifier() instanceof Component.Identifier.Button))
/*  54:    */       {
/*  55:117 */         this.buttonState[buttonsCount] = (sourceAxis.getPollData() != 0.0F ? 1 : false);
/*  56:118 */         buttonsCount++;
/*  57:    */       }
/*  58:119 */       else if (!sourceAxis.getIdentifier().equals(Component.Identifier.Axis.POV))
/*  59:    */       {
/*  60:123 */         this.axesValue[axesCount] = sourceAxis.getPollData();
/*  61:124 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.X)) {
/*  62:125 */           this.xaxis = axesCount;
/*  63:    */         }
/*  64:127 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.Y)) {
/*  65:128 */           this.yaxis = axesCount;
/*  66:    */         }
/*  67:130 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.Z)) {
/*  68:131 */           this.zaxis = axesCount;
/*  69:    */         }
/*  70:133 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.RX)) {
/*  71:134 */           this.rxaxis = axesCount;
/*  72:    */         }
/*  73:136 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.RY)) {
/*  74:137 */           this.ryaxis = axesCount;
/*  75:    */         }
/*  76:139 */         if (sourceAxis.getIdentifier().equals(Component.Identifier.Axis.RZ)) {
/*  77:140 */           this.rzaxis = axesCount;
/*  78:    */         }
/*  79:143 */         axesCount++;
/*  80:    */       }
/*  81:    */     }
/*  82:147 */     this.axesMax = new float[this.axes.size()];
/*  83:148 */     this.deadZones = new float[this.axes.size()];
/*  84:150 */     for (int i = 0; i < this.axesMax.length; i++)
/*  85:    */     {
/*  86:151 */       this.axesMax[i] = 1.0F;
/*  87:152 */       this.deadZones[i] = 0.05F;
/*  88:    */     }
/*  89:155 */     this.rumblers = target.getRumblers();
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String getName()
/*  93:    */   {
/*  94:162 */     String name = this.target.getName();
/*  95:163 */     return name;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public int getIndex()
/*  99:    */   {
/* 100:170 */     return this.index;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public int getButtonCount()
/* 104:    */   {
/* 105:177 */     return this.buttons.size();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public String getButtonName(int index)
/* 109:    */   {
/* 110:184 */     return ((Component)this.buttons.get(index)).getName();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public boolean isButtonPressed(int index)
/* 114:    */   {
/* 115:191 */     return this.buttonState[index];
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void poll()
/* 119:    */   {
/* 120:198 */     this.target.poll();
/* 121:    */     
/* 122:200 */     Event event = new Event();
/* 123:201 */     EventQueue queue = this.target.getEventQueue();
/* 124:203 */     while (queue.getNextEvent(event))
/* 125:    */     {
/* 126:205 */       if (this.buttons.contains(event.getComponent()))
/* 127:    */       {
/* 128:206 */         Component button = event.getComponent();
/* 129:207 */         int buttonIndex = this.buttons.indexOf(button);
/* 130:208 */         this.buttonState[buttonIndex] = (event.getValue() != 0.0F ? 1 : false);
/* 131:    */         
/* 132:    */ 
/* 133:211 */         Controllers.addEvent(new ControllerEvent(this, event.getNanos(), 1, buttonIndex, false, false));
/* 134:    */       }
/* 135:215 */       if (this.pov.contains(event.getComponent()))
/* 136:    */       {
/* 137:216 */         Component povComponent = event.getComponent();
/* 138:217 */         int povIndex = this.pov.indexOf(povComponent);
/* 139:218 */         float prevX = getPovX();
/* 140:219 */         float prevY = getPovY();
/* 141:220 */         this.povValues[povIndex] = event.getValue();
/* 142:222 */         if (prevX != getPovX()) {
/* 143:223 */           Controllers.addEvent(new ControllerEvent(this, event.getNanos(), 3, 0, false, false));
/* 144:    */         }
/* 145:225 */         if (prevY != getPovY()) {
/* 146:226 */           Controllers.addEvent(new ControllerEvent(this, event.getNanos(), 4, 0, false, false));
/* 147:    */         }
/* 148:    */       }
/* 149:231 */       if (this.axes.contains(event.getComponent()))
/* 150:    */       {
/* 151:232 */         Component axis = event.getComponent();
/* 152:233 */         int axisIndex = this.axes.indexOf(axis);
/* 153:234 */         float value = axis.getPollData();
/* 154:237 */         if (Math.abs(value) < this.deadZones[axisIndex]) {
/* 155:238 */           value = 0.0F;
/* 156:    */         }
/* 157:240 */         if (Math.abs(value) < axis.getDeadZone()) {
/* 158:241 */           value = 0.0F;
/* 159:    */         }
/* 160:243 */         if (Math.abs(value) > this.axesMax[axisIndex]) {
/* 161:244 */           this.axesMax[axisIndex] = Math.abs(value);
/* 162:    */         }
/* 163:248 */         value /= this.axesMax[axisIndex];
/* 164:    */         
/* 165:250 */         Controllers.addEvent(new ControllerEvent(this, event.getNanos(), 2, axisIndex, axisIndex == this.xaxis, axisIndex == this.yaxis));
/* 166:    */         
/* 167:252 */         this.axesValue[axisIndex] = value;
/* 168:    */       }
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   public int getAxisCount()
/* 173:    */   {
/* 174:261 */     return this.axes.size();
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String getAxisName(int index)
/* 178:    */   {
/* 179:268 */     return ((Component)this.axes.get(index)).getName();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public float getAxisValue(int index)
/* 183:    */   {
/* 184:275 */     return this.axesValue[index];
/* 185:    */   }
/* 186:    */   
/* 187:    */   public float getXAxisValue()
/* 188:    */   {
/* 189:282 */     if (this.xaxis == -1) {
/* 190:283 */       return 0.0F;
/* 191:    */     }
/* 192:286 */     return getAxisValue(this.xaxis);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public float getYAxisValue()
/* 196:    */   {
/* 197:293 */     if (this.yaxis == -1) {
/* 198:294 */       return 0.0F;
/* 199:    */     }
/* 200:297 */     return getAxisValue(this.yaxis);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public float getXAxisDeadZone()
/* 204:    */   {
/* 205:304 */     if (this.xaxis == -1) {
/* 206:305 */       return 0.0F;
/* 207:    */     }
/* 208:308 */     return getDeadZone(this.xaxis);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public float getYAxisDeadZone()
/* 212:    */   {
/* 213:315 */     if (this.yaxis == -1) {
/* 214:316 */       return 0.0F;
/* 215:    */     }
/* 216:319 */     return getDeadZone(this.yaxis);
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setXAxisDeadZone(float zone)
/* 220:    */   {
/* 221:326 */     setDeadZone(this.xaxis, zone);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public void setYAxisDeadZone(float zone)
/* 225:    */   {
/* 226:333 */     setDeadZone(this.yaxis, zone);
/* 227:    */   }
/* 228:    */   
/* 229:    */   public float getDeadZone(int index)
/* 230:    */   {
/* 231:340 */     return this.deadZones[index];
/* 232:    */   }
/* 233:    */   
/* 234:    */   public void setDeadZone(int index, float zone)
/* 235:    */   {
/* 236:347 */     this.deadZones[index] = zone;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public float getZAxisValue()
/* 240:    */   {
/* 241:354 */     if (this.zaxis == -1) {
/* 242:355 */       return 0.0F;
/* 243:    */     }
/* 244:358 */     return getAxisValue(this.zaxis);
/* 245:    */   }
/* 246:    */   
/* 247:    */   public float getZAxisDeadZone()
/* 248:    */   {
/* 249:365 */     if (this.zaxis == -1) {
/* 250:366 */       return 0.0F;
/* 251:    */     }
/* 252:369 */     return getDeadZone(this.zaxis);
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void setZAxisDeadZone(float zone)
/* 256:    */   {
/* 257:376 */     setDeadZone(this.zaxis, zone);
/* 258:    */   }
/* 259:    */   
/* 260:    */   public float getRXAxisValue()
/* 261:    */   {
/* 262:383 */     if (this.rxaxis == -1) {
/* 263:384 */       return 0.0F;
/* 264:    */     }
/* 265:387 */     return getAxisValue(this.rxaxis);
/* 266:    */   }
/* 267:    */   
/* 268:    */   public float getRXAxisDeadZone()
/* 269:    */   {
/* 270:394 */     if (this.rxaxis == -1) {
/* 271:395 */       return 0.0F;
/* 272:    */     }
/* 273:398 */     return getDeadZone(this.rxaxis);
/* 274:    */   }
/* 275:    */   
/* 276:    */   public void setRXAxisDeadZone(float zone)
/* 277:    */   {
/* 278:405 */     setDeadZone(this.rxaxis, zone);
/* 279:    */   }
/* 280:    */   
/* 281:    */   public float getRYAxisValue()
/* 282:    */   {
/* 283:412 */     if (this.ryaxis == -1) {
/* 284:413 */       return 0.0F;
/* 285:    */     }
/* 286:416 */     return getAxisValue(this.ryaxis);
/* 287:    */   }
/* 288:    */   
/* 289:    */   public float getRYAxisDeadZone()
/* 290:    */   {
/* 291:423 */     if (this.ryaxis == -1) {
/* 292:424 */       return 0.0F;
/* 293:    */     }
/* 294:427 */     return getDeadZone(this.ryaxis);
/* 295:    */   }
/* 296:    */   
/* 297:    */   public void setRYAxisDeadZone(float zone)
/* 298:    */   {
/* 299:434 */     setDeadZone(this.ryaxis, zone);
/* 300:    */   }
/* 301:    */   
/* 302:    */   public float getRZAxisValue()
/* 303:    */   {
/* 304:441 */     if (this.rzaxis == -1) {
/* 305:442 */       return 0.0F;
/* 306:    */     }
/* 307:445 */     return getAxisValue(this.rzaxis);
/* 308:    */   }
/* 309:    */   
/* 310:    */   public float getRZAxisDeadZone()
/* 311:    */   {
/* 312:452 */     if (this.rzaxis == -1) {
/* 313:453 */       return 0.0F;
/* 314:    */     }
/* 315:456 */     return getDeadZone(this.rzaxis);
/* 316:    */   }
/* 317:    */   
/* 318:    */   public void setRZAxisDeadZone(float zone)
/* 319:    */   {
/* 320:463 */     setDeadZone(this.rzaxis, zone);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public float getPovX()
/* 324:    */   {
/* 325:470 */     if (this.pov.size() == 0) {
/* 326:471 */       return 0.0F;
/* 327:    */     }
/* 328:474 */     float value = this.povValues[0];
/* 329:476 */     if ((value == 0.875F) || (value == 0.125F) || (value == 1.0F)) {
/* 330:479 */       return -1.0F;
/* 331:    */     }
/* 332:481 */     if ((value == 0.625F) || (value == 0.375F) || (value == 0.5F)) {
/* 333:484 */       return 1.0F;
/* 334:    */     }
/* 335:487 */     return 0.0F;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public float getPovY()
/* 339:    */   {
/* 340:494 */     if (this.pov.size() == 0) {
/* 341:495 */       return 0.0F;
/* 342:    */     }
/* 343:498 */     float value = this.povValues[0];
/* 344:500 */     if ((value == 0.875F) || (value == 0.625F) || (value == 0.75F)) {
/* 345:503 */       return 1.0F;
/* 346:    */     }
/* 347:505 */     if ((value == 0.125F) || (value == 0.375F) || (value == 0.25F)) {
/* 348:508 */       return -1.0F;
/* 349:    */     }
/* 350:511 */     return 0.0F;
/* 351:    */   }
/* 352:    */   
/* 353:    */   public int getRumblerCount()
/* 354:    */   {
/* 355:515 */     return this.rumblers.length;
/* 356:    */   }
/* 357:    */   
/* 358:    */   public String getRumblerName(int index)
/* 359:    */   {
/* 360:519 */     return this.rumblers[index].getAxisName();
/* 361:    */   }
/* 362:    */   
/* 363:    */   public void setRumblerStrength(int index, float strength)
/* 364:    */   {
/* 365:523 */     this.rumblers[index].rumble(strength);
/* 366:    */   }
/* 367:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.input.JInputController
 * JD-Core Version:    0.7.0.1
 */