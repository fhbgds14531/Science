/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.LWJGLUtil;
/*  4:   */ 
/*  5:   */ abstract class CLObjectChild<P extends CLObject>
/*  6:   */   extends CLObjectRetainable
/*  7:   */ {
/*  8:   */   private final P parent;
/*  9:   */   
/* 10:   */   protected CLObjectChild(long pointer, P parent)
/* 11:   */   {
/* 12:46 */     super(pointer);
/* 13:48 */     if ((LWJGLUtil.DEBUG) && (parent != null) && (!parent.isValid())) {
/* 14:49 */       throw new IllegalStateException("The parent specified is not a valid CL object.");
/* 15:   */     }
/* 16:51 */     this.parent = parent;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public P getParent()
/* 20:   */   {
/* 21:55 */     return this.parent;
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLObjectChild
 * JD-Core Version:    0.7.0.1
 */