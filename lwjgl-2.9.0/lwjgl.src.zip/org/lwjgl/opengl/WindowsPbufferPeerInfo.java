/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.LWJGLException;
/*  6:   */ 
/*  7:   */ final class WindowsPbufferPeerInfo
/*  8:   */   extends WindowsPeerInfo
/*  9:   */ {
/* 10:   */   WindowsPbufferPeerInfo(int width, int height, PixelFormat pixel_format, IntBuffer pixelFormatCaps, IntBuffer pBufferAttribs)
/* 11:   */     throws LWJGLException
/* 12:   */   {
/* 13:47 */     nCreate(getHandle(), width, height, pixel_format, pixelFormatCaps, pBufferAttribs);
/* 14:   */   }
/* 15:   */   
/* 16:   */   private static native void nCreate(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, PixelFormat paramPixelFormat, IntBuffer paramIntBuffer1, IntBuffer paramIntBuffer2)
/* 17:   */     throws LWJGLException;
/* 18:   */   
/* 19:   */   public boolean isBufferLost()
/* 20:   */   {
/* 21:52 */     return nIsBufferLost(getHandle());
/* 22:   */   }
/* 23:   */   
/* 24:   */   private static native boolean nIsBufferLost(ByteBuffer paramByteBuffer);
/* 25:   */   
/* 26:   */   public void setPbufferAttrib(int attrib, int value)
/* 27:   */   {
/* 28:57 */     nSetPbufferAttrib(getHandle(), attrib, value);
/* 29:   */   }
/* 30:   */   
/* 31:   */   private static native void nSetPbufferAttrib(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
/* 32:   */   
/* 33:   */   public void bindTexImageToPbuffer(int buffer)
/* 34:   */   {
/* 35:62 */     nBindTexImageToPbuffer(getHandle(), buffer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   private static native void nBindTexImageToPbuffer(ByteBuffer paramByteBuffer, int paramInt);
/* 39:   */   
/* 40:   */   public void releaseTexImageFromPbuffer(int buffer)
/* 41:   */   {
/* 42:67 */     nReleaseTexImageFromPbuffer(getHandle(), buffer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   private static native void nReleaseTexImageFromPbuffer(ByteBuffer paramByteBuffer, int paramInt);
/* 46:   */   
/* 47:   */   public void destroy()
/* 48:   */   {
/* 49:72 */     nDestroy(getHandle());
/* 50:   */   }
/* 51:   */   
/* 52:   */   private static native void nDestroy(ByteBuffer paramByteBuffer);
/* 53:   */   
/* 54:   */   protected void doLockAndInitHandle()
/* 55:   */     throws LWJGLException
/* 56:   */   {}
/* 57:   */   
/* 58:   */   protected void doUnlock()
/* 59:   */     throws LWJGLException
/* 60:   */   {}
/* 61:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.WindowsPbufferPeerInfo
 * JD-Core Version:    0.7.0.1
 */