package org.lwjgl.opengl;

public final class APPLEClientStorage
{
  public static final int GL_UNPACK_CLIENT_STORAGE_APPLE = 34226;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.APPLEClientStorage
 * JD-Core Version:    0.7.0.1
 */