/*   1:    */ package org.lwjgl.openal;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ import org.lwjgl.MemoryUtil;
/*   8:    */ 
/*   9:    */ public final class AL11
/*  10:    */ {
/*  11:    */   public static final int AL_SEC_OFFSET = 4132;
/*  12:    */   public static final int AL_SAMPLE_OFFSET = 4133;
/*  13:    */   public static final int AL_BYTE_OFFSET = 4134;
/*  14:    */   public static final int AL_STATIC = 4136;
/*  15:    */   public static final int AL_STREAMING = 4137;
/*  16:    */   public static final int AL_UNDETERMINED = 4144;
/*  17:    */   public static final int AL_ILLEGAL_COMMAND = 40964;
/*  18:    */   public static final int AL_SPEED_OF_SOUND = 49155;
/*  19:    */   public static final int AL_LINEAR_DISTANCE = 53251;
/*  20:    */   public static final int AL_LINEAR_DISTANCE_CLAMPED = 53252;
/*  21:    */   public static final int AL_EXPONENT_DISTANCE = 53253;
/*  22:    */   public static final int AL_EXPONENT_DISTANCE_CLAMPED = 53254;
/*  23:    */   
/*  24:    */   static native void initNativeStubs()
/*  25:    */     throws LWJGLException;
/*  26:    */   
/*  27:    */   public static void alListener3i(int pname, int v1, int v2, int v3)
/*  28:    */   {
/*  29: 76 */     nalListener3i(pname, v1, v2, v3);
/*  30:    */   }
/*  31:    */   
/*  32:    */   static native void nalListener3i(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*  33:    */   
/*  34:    */   public static void alGetListeneri(int pname, FloatBuffer intdata)
/*  35:    */   {
/*  36: 88 */     BufferChecks.checkBuffer(intdata, 1);
/*  37: 89 */     nalGetListeneriv(pname, MemoryUtil.getAddress(intdata));
/*  38:    */   }
/*  39:    */   
/*  40:    */   static native void nalGetListeneriv(int paramInt, long paramLong);
/*  41:    */   
/*  42:    */   public static void alSource3i(int source, int pname, int v1, int v2, int v3)
/*  43:    */   {
/*  44:104 */     nalSource3i(source, pname, v1, v2, v3);
/*  45:    */   }
/*  46:    */   
/*  47:    */   static native void nalSource3i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*  48:    */   
/*  49:    */   public static void alSource(int source, int pname, IntBuffer value)
/*  50:    */   {
/*  51:117 */     BufferChecks.checkBuffer(value, 1);
/*  52:118 */     nalSourceiv(source, pname, MemoryUtil.getAddress(value));
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native void nalSourceiv(int paramInt1, int paramInt2, long paramLong);
/*  56:    */   
/*  57:    */   public static void alBufferf(int buffer, int pname, float value)
/*  58:    */   {
/*  59:132 */     nalBufferf(buffer, pname, value);
/*  60:    */   }
/*  61:    */   
/*  62:    */   static native void nalBufferf(int paramInt1, int paramInt2, float paramFloat);
/*  63:    */   
/*  64:    */   public static void alBuffer3f(int buffer, int pname, float v1, float v2, float v3)
/*  65:    */   {
/*  66:148 */     nalBuffer3f(buffer, pname, v1, v2, v3);
/*  67:    */   }
/*  68:    */   
/*  69:    */   static native void nalBuffer3f(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3);
/*  70:    */   
/*  71:    */   public static void alBuffer(int buffer, int pname, FloatBuffer value)
/*  72:    */   {
/*  73:162 */     BufferChecks.checkBuffer(value, 1);
/*  74:163 */     nalBufferfv(buffer, pname, MemoryUtil.getAddress(value));
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native void nalBufferfv(int paramInt1, int paramInt2, long paramLong);
/*  78:    */   
/*  79:    */   public static void alBufferi(int buffer, int pname, int value)
/*  80:    */   {
/*  81:177 */     nalBufferi(buffer, pname, value);
/*  82:    */   }
/*  83:    */   
/*  84:    */   static native void nalBufferi(int paramInt1, int paramInt2, int paramInt3);
/*  85:    */   
/*  86:    */   public static void alBuffer3i(int buffer, int pname, int v1, int v2, int v3)
/*  87:    */   {
/*  88:193 */     nalBuffer3i(buffer, pname, v1, v2, v3);
/*  89:    */   }
/*  90:    */   
/*  91:    */   static native void nalBuffer3i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*  92:    */   
/*  93:    */   public static void alBuffer(int buffer, int pname, IntBuffer value)
/*  94:    */   {
/*  95:207 */     BufferChecks.checkBuffer(value, 1);
/*  96:208 */     nalBufferiv(buffer, pname, MemoryUtil.getAddress(value));
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nalBufferiv(int paramInt1, int paramInt2, long paramLong);
/* 100:    */   
/* 101:    */   public static int alGetBufferi(int buffer, int pname)
/* 102:    */   {
/* 103:222 */     int __result = nalGetBufferi(buffer, pname);
/* 104:223 */     return __result;
/* 105:    */   }
/* 106:    */   
/* 107:    */   static native int nalGetBufferi(int paramInt1, int paramInt2);
/* 108:    */   
/* 109:    */   public static void alGetBuffer(int buffer, int pname, IntBuffer values)
/* 110:    */   {
/* 111:234 */     BufferChecks.checkBuffer(values, 1);
/* 112:235 */     nalGetBufferiv(buffer, pname, MemoryUtil.getAddress(values));
/* 113:    */   }
/* 114:    */   
/* 115:    */   static native void nalGetBufferiv(int paramInt1, int paramInt2, long paramLong);
/* 116:    */   
/* 117:    */   public static float alGetBufferf(int buffer, int pname)
/* 118:    */   {
/* 119:249 */     float __result = nalGetBufferf(buffer, pname);
/* 120:250 */     return __result;
/* 121:    */   }
/* 122:    */   
/* 123:    */   static native float nalGetBufferf(int paramInt1, int paramInt2);
/* 124:    */   
/* 125:    */   public static void alGetBuffer(int buffer, int pname, FloatBuffer values)
/* 126:    */   {
/* 127:263 */     BufferChecks.checkBuffer(values, 1);
/* 128:264 */     nalGetBufferfv(buffer, pname, MemoryUtil.getAddress(values));
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nalGetBufferfv(int paramInt1, int paramInt2, long paramLong);
/* 132:    */   
/* 133:    */   public static void alSpeedOfSound(float value)
/* 134:    */   {
/* 135:286 */     nalSpeedOfSound(value);
/* 136:    */   }
/* 137:    */   
/* 138:    */   static native void nalSpeedOfSound(float paramFloat);
/* 139:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.openal.AL11
 * JD-Core Version:    0.7.0.1
 */