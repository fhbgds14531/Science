/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.awt.EventQueue;
/*   5:    */ import java.awt.event.ComponentEvent;
/*   6:    */ import java.awt.event.ComponentListener;
/*   7:    */ import java.awt.event.HierarchyEvent;
/*   8:    */ import java.awt.event.HierarchyListener;
/*   9:    */ 
/*  10:    */ final class MacOSXCanvasListener
/*  11:    */   implements ComponentListener, HierarchyListener
/*  12:    */ {
/*  13:    */   private final Canvas canvas;
/*  14:    */   private int width;
/*  15:    */   private int height;
/*  16:    */   private boolean context_update;
/*  17:    */   private boolean resized;
/*  18:    */   
/*  19:    */   MacOSXCanvasListener(Canvas canvas)
/*  20:    */   {
/*  21: 53 */     this.canvas = canvas;
/*  22: 54 */     canvas.addComponentListener(this);
/*  23: 55 */     canvas.addHierarchyListener(this);
/*  24: 56 */     setUpdate();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void disableListeners()
/*  28:    */   {
/*  29: 61 */     EventQueue.invokeLater(new Runnable()
/*  30:    */     {
/*  31:    */       public void run()
/*  32:    */       {
/*  33: 63 */         MacOSXCanvasListener.this.canvas.removeComponentListener(MacOSXCanvasListener.this);
/*  34: 64 */         MacOSXCanvasListener.this.canvas.removeHierarchyListener(MacOSXCanvasListener.this);
/*  35:    */       }
/*  36:    */     });
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean syncShouldUpdateContext()
/*  40:    */   {
/*  41:    */     boolean should_update;
/*  42: 71 */     synchronized (this)
/*  43:    */     {
/*  44: 72 */       should_update = this.context_update;
/*  45: 73 */       this.context_update = false;
/*  46:    */     }
/*  47: 75 */     return should_update;
/*  48:    */   }
/*  49:    */   
/*  50:    */   private synchronized void setUpdate()
/*  51:    */   {
/*  52: 79 */     synchronized (this)
/*  53:    */     {
/*  54: 80 */       this.width = this.canvas.getWidth();
/*  55: 81 */       this.height = this.canvas.getHeight();
/*  56: 82 */       this.context_update = true;
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public int syncGetWidth()
/*  61:    */   {
/*  62: 87 */     synchronized (this)
/*  63:    */     {
/*  64: 88 */       return this.width;
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   public int syncGetHeight()
/*  69:    */   {
/*  70: 93 */     synchronized (this)
/*  71:    */     {
/*  72: 94 */       return this.height;
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public void componentShown(ComponentEvent e) {}
/*  77:    */   
/*  78:    */   public void componentHidden(ComponentEvent e) {}
/*  79:    */   
/*  80:    */   public void componentResized(ComponentEvent e)
/*  81:    */   {
/*  82:105 */     setUpdate();
/*  83:106 */     this.resized = true;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void componentMoved(ComponentEvent e)
/*  87:    */   {
/*  88:110 */     setUpdate();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void hierarchyChanged(HierarchyEvent e)
/*  92:    */   {
/*  93:114 */     setUpdate();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public boolean wasResized()
/*  97:    */   {
/*  98:118 */     if (this.resized)
/*  99:    */     {
/* 100:119 */       this.resized = false;
/* 101:120 */       return true;
/* 102:    */     }
/* 103:123 */     return false;
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXCanvasListener
 * JD-Core Version:    0.7.0.1
 */