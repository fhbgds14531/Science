/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBBlendFuncExtended
/*  6:   */ {
/*  7:   */   public static final int GL_SRC1_COLOR = 35065;
/*  8:   */   public static final int GL_SRC1_ALPHA = 34185;
/*  9:   */   public static final int GL_ONE_MINUS_SRC1_COLOR = 35066;
/* 10:   */   public static final int GL_ONE_MINUS_SRC1_ALPHA = 35067;
/* 11:   */   public static final int GL_MAX_DUAL_SOURCE_DRAW_BUFFERS = 35068;
/* 12:   */   
/* 13:   */   public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, ByteBuffer name)
/* 14:   */   {
/* 15:29 */     GL33.glBindFragDataLocationIndexed(program, colorNumber, index, name);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public static void glBindFragDataLocationIndexed(int program, int colorNumber, int index, CharSequence name)
/* 19:   */   {
/* 20:34 */     GL33.glBindFragDataLocationIndexed(program, colorNumber, index, name);
/* 21:   */   }
/* 22:   */   
/* 23:   */   public static int glGetFragDataIndex(int program, ByteBuffer name)
/* 24:   */   {
/* 25:38 */     return GL33.glGetFragDataIndex(program, name);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public static int glGetFragDataIndex(int program, CharSequence name)
/* 29:   */   {
/* 30:43 */     return GL33.glGetFragDataIndex(program, name);
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBBlendFuncExtended
 * JD-Core Version:    0.7.0.1
 */