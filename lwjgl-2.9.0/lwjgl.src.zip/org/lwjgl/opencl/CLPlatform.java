/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ import java.util.List;
/*   7:    */ import org.lwjgl.PointerBuffer;
/*   8:    */ import org.lwjgl.opencl.api.Filter;
/*   9:    */ 
/*  10:    */ public final class CLPlatform
/*  11:    */   extends CLObject
/*  12:    */ {
/*  13: 50 */   private static final CLPlatformUtil util = (CLPlatformUtil)getInfoUtilInstance(CLPlatform.class, "CL_PLATFORM_UTIL");
/*  14: 52 */   private static final FastLongMap<CLPlatform> clPlatforms = new FastLongMap();
/*  15:    */   private final CLObjectRegistry<CLDevice> clDevices;
/*  16:    */   private Object caps;
/*  17:    */   
/*  18:    */   CLPlatform(long pointer)
/*  19:    */   {
/*  20: 59 */     super(pointer);
/*  21: 61 */     if (isValid())
/*  22:    */     {
/*  23: 62 */       clPlatforms.put(pointer, this);
/*  24: 63 */       this.clDevices = new CLObjectRegistry();
/*  25:    */     }
/*  26:    */     else
/*  27:    */     {
/*  28: 65 */       this.clDevices = null;
/*  29:    */     }
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static CLPlatform getCLPlatform(long id)
/*  33:    */   {
/*  34: 75 */     return (CLPlatform)clPlatforms.get(id);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public CLDevice getCLDevice(long id)
/*  38:    */   {
/*  39: 84 */     return (CLDevice)this.clDevices.getObject(id);
/*  40:    */   }
/*  41:    */   
/*  42:    */   static <T extends CLObject> InfoUtil<T> getInfoUtilInstance(Class<T> clazz, String fieldName)
/*  43:    */   {
/*  44: 90 */     InfoUtil<T> instance = null;
/*  45:    */     try
/*  46:    */     {
/*  47: 92 */       Class<?> infoUtil = Class.forName("org.lwjgl.opencl.InfoUtilFactory");
/*  48: 93 */       instance = (InfoUtil)infoUtil.getDeclaredField(fieldName).get(null);
/*  49:    */     }
/*  50:    */     catch (Exception e) {}
/*  51: 97 */     return instance;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static List<CLPlatform> getPlatforms()
/*  55:    */   {
/*  56:106 */     return getPlatforms(null);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static List<CLPlatform> getPlatforms(Filter<CLPlatform> filter)
/*  60:    */   {
/*  61:117 */     return util.getPlatforms(filter);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getInfoString(int param_name)
/*  65:    */   {
/*  66:128 */     return util.getInfoString(this, param_name);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public List<CLDevice> getDevices(int device_type)
/*  70:    */   {
/*  71:140 */     return getDevices(device_type, null);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public List<CLDevice> getDevices(int device_type, Filter<CLDevice> filter)
/*  75:    */   {
/*  76:153 */     return util.getDevices(this, device_type, filter);
/*  77:    */   }
/*  78:    */   
/*  79:    */   void setCapabilities(Object caps)
/*  80:    */   {
/*  81:168 */     this.caps = caps;
/*  82:    */   }
/*  83:    */   
/*  84:    */   Object getCapabilities()
/*  85:    */   {
/*  86:172 */     return this.caps;
/*  87:    */   }
/*  88:    */   
/*  89:    */   static void registerCLPlatforms(PointerBuffer platforms, IntBuffer num_platforms)
/*  90:    */   {
/*  91:181 */     if (platforms == null) {
/*  92:182 */       return;
/*  93:    */     }
/*  94:184 */     int pos = platforms.position();
/*  95:185 */     int count = Math.min(num_platforms.get(0), platforms.remaining());
/*  96:186 */     for (int i = 0; i < count; i++)
/*  97:    */     {
/*  98:187 */       long id = platforms.get(pos + i);
/*  99:188 */       if (!clPlatforms.containsKey(id)) {
/* 100:189 */         new CLPlatform(id);
/* 101:    */       }
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   CLObjectRegistry<CLDevice> getCLDeviceRegistry()
/* 106:    */   {
/* 107:193 */     return this.clDevices;
/* 108:    */   }
/* 109:    */   
/* 110:    */   void registerCLDevices(PointerBuffer devices, IntBuffer num_devices)
/* 111:    */   {
/* 112:201 */     int pos = devices.position();
/* 113:202 */     int count = Math.min(num_devices.get(num_devices.position()), devices.remaining());
/* 114:203 */     for (int i = 0; i < count; i++)
/* 115:    */     {
/* 116:204 */       long id = devices.get(pos + i);
/* 117:205 */       if (!this.clDevices.hasObject(id)) {
/* 118:206 */         new CLDevice(id, this);
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */   
/* 123:    */   void registerCLDevices(ByteBuffer devices, PointerBuffer num_devices)
/* 124:    */   {
/* 125:216 */     int pos = devices.position();
/* 126:217 */     int count = Math.min((int)num_devices.get(num_devices.position()), devices.remaining()) / PointerBuffer.getPointerSize();
/* 127:218 */     for (int i = 0; i < count; i++)
/* 128:    */     {
/* 129:219 */       int offset = pos + i * PointerBuffer.getPointerSize();
/* 130:220 */       long id = PointerBuffer.is64Bit() ? devices.getLong(offset) : devices.getInt(offset);
/* 131:221 */       if (!this.clDevices.hasObject(id)) {
/* 132:222 */         new CLDevice(id, this);
/* 133:    */       }
/* 134:    */     }
/* 135:    */   }
/* 136:    */   
/* 137:    */   static abstract interface CLPlatformUtil
/* 138:    */     extends InfoUtil<CLPlatform>
/* 139:    */   {
/* 140:    */     public abstract List<CLPlatform> getPlatforms(Filter<CLPlatform> paramFilter);
/* 141:    */     
/* 142:    */     public abstract List<CLDevice> getDevices(CLPlatform paramCLPlatform, int paramInt, Filter<CLDevice> paramFilter);
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLPlatform
 * JD-Core Version:    0.7.0.1
 */