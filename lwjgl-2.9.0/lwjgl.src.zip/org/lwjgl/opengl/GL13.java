/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.ShortBuffer;
/*   8:    */ import org.lwjgl.BufferChecks;
/*   9:    */ import org.lwjgl.MemoryUtil;
/*  10:    */ 
/*  11:    */ public final class GL13
/*  12:    */ {
/*  13:    */   public static final int GL_TEXTURE0 = 33984;
/*  14:    */   public static final int GL_TEXTURE1 = 33985;
/*  15:    */   public static final int GL_TEXTURE2 = 33986;
/*  16:    */   public static final int GL_TEXTURE3 = 33987;
/*  17:    */   public static final int GL_TEXTURE4 = 33988;
/*  18:    */   public static final int GL_TEXTURE5 = 33989;
/*  19:    */   public static final int GL_TEXTURE6 = 33990;
/*  20:    */   public static final int GL_TEXTURE7 = 33991;
/*  21:    */   public static final int GL_TEXTURE8 = 33992;
/*  22:    */   public static final int GL_TEXTURE9 = 33993;
/*  23:    */   public static final int GL_TEXTURE10 = 33994;
/*  24:    */   public static final int GL_TEXTURE11 = 33995;
/*  25:    */   public static final int GL_TEXTURE12 = 33996;
/*  26:    */   public static final int GL_TEXTURE13 = 33997;
/*  27:    */   public static final int GL_TEXTURE14 = 33998;
/*  28:    */   public static final int GL_TEXTURE15 = 33999;
/*  29:    */   public static final int GL_TEXTURE16 = 34000;
/*  30:    */   public static final int GL_TEXTURE17 = 34001;
/*  31:    */   public static final int GL_TEXTURE18 = 34002;
/*  32:    */   public static final int GL_TEXTURE19 = 34003;
/*  33:    */   public static final int GL_TEXTURE20 = 34004;
/*  34:    */   public static final int GL_TEXTURE21 = 34005;
/*  35:    */   public static final int GL_TEXTURE22 = 34006;
/*  36:    */   public static final int GL_TEXTURE23 = 34007;
/*  37:    */   public static final int GL_TEXTURE24 = 34008;
/*  38:    */   public static final int GL_TEXTURE25 = 34009;
/*  39:    */   public static final int GL_TEXTURE26 = 34010;
/*  40:    */   public static final int GL_TEXTURE27 = 34011;
/*  41:    */   public static final int GL_TEXTURE28 = 34012;
/*  42:    */   public static final int GL_TEXTURE29 = 34013;
/*  43:    */   public static final int GL_TEXTURE30 = 34014;
/*  44:    */   public static final int GL_TEXTURE31 = 34015;
/*  45:    */   public static final int GL_ACTIVE_TEXTURE = 34016;
/*  46:    */   public static final int GL_CLIENT_ACTIVE_TEXTURE = 34017;
/*  47:    */   public static final int GL_MAX_TEXTURE_UNITS = 34018;
/*  48:    */   public static final int GL_NORMAL_MAP = 34065;
/*  49:    */   public static final int GL_REFLECTION_MAP = 34066;
/*  50:    */   public static final int GL_TEXTURE_CUBE_MAP = 34067;
/*  51:    */   public static final int GL_TEXTURE_BINDING_CUBE_MAP = 34068;
/*  52:    */   public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069;
/*  53:    */   public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_X = 34070;
/*  54:    */   public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_Y = 34071;
/*  55:    */   public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072;
/*  56:    */   public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_Z = 34073;
/*  57:    */   public static final int GL_TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074;
/*  58:    */   public static final int GL_PROXY_TEXTURE_CUBE_MAP = 34075;
/*  59:    */   public static final int GL_MAX_CUBE_MAP_TEXTURE_SIZE = 34076;
/*  60:    */   public static final int GL_COMPRESSED_ALPHA = 34025;
/*  61:    */   public static final int GL_COMPRESSED_LUMINANCE = 34026;
/*  62:    */   public static final int GL_COMPRESSED_LUMINANCE_ALPHA = 34027;
/*  63:    */   public static final int GL_COMPRESSED_INTENSITY = 34028;
/*  64:    */   public static final int GL_COMPRESSED_RGB = 34029;
/*  65:    */   public static final int GL_COMPRESSED_RGBA = 34030;
/*  66:    */   public static final int GL_TEXTURE_COMPRESSION_HINT = 34031;
/*  67:    */   public static final int GL_TEXTURE_COMPRESSED_IMAGE_SIZE = 34464;
/*  68:    */   public static final int GL_TEXTURE_COMPRESSED = 34465;
/*  69:    */   public static final int GL_NUM_COMPRESSED_TEXTURE_FORMATS = 34466;
/*  70:    */   public static final int GL_COMPRESSED_TEXTURE_FORMATS = 34467;
/*  71:    */   public static final int GL_MULTISAMPLE = 32925;
/*  72:    */   public static final int GL_SAMPLE_ALPHA_TO_COVERAGE = 32926;
/*  73:    */   public static final int GL_SAMPLE_ALPHA_TO_ONE = 32927;
/*  74:    */   public static final int GL_SAMPLE_COVERAGE = 32928;
/*  75:    */   public static final int GL_SAMPLE_BUFFERS = 32936;
/*  76:    */   public static final int GL_SAMPLES = 32937;
/*  77:    */   public static final int GL_SAMPLE_COVERAGE_VALUE = 32938;
/*  78:    */   public static final int GL_SAMPLE_COVERAGE_INVERT = 32939;
/*  79:    */   public static final int GL_MULTISAMPLE_BIT = 536870912;
/*  80:    */   public static final int GL_TRANSPOSE_MODELVIEW_MATRIX = 34019;
/*  81:    */   public static final int GL_TRANSPOSE_PROJECTION_MATRIX = 34020;
/*  82:    */   public static final int GL_TRANSPOSE_TEXTURE_MATRIX = 34021;
/*  83:    */   public static final int GL_TRANSPOSE_COLOR_MATRIX = 34022;
/*  84:    */   public static final int GL_COMBINE = 34160;
/*  85:    */   public static final int GL_COMBINE_RGB = 34161;
/*  86:    */   public static final int GL_COMBINE_ALPHA = 34162;
/*  87:    */   public static final int GL_SOURCE0_RGB = 34176;
/*  88:    */   public static final int GL_SOURCE1_RGB = 34177;
/*  89:    */   public static final int GL_SOURCE2_RGB = 34178;
/*  90:    */   public static final int GL_SOURCE0_ALPHA = 34184;
/*  91:    */   public static final int GL_SOURCE1_ALPHA = 34185;
/*  92:    */   public static final int GL_SOURCE2_ALPHA = 34186;
/*  93:    */   public static final int GL_OPERAND0_RGB = 34192;
/*  94:    */   public static final int GL_OPERAND1_RGB = 34193;
/*  95:    */   public static final int GL_OPERAND2_RGB = 34194;
/*  96:    */   public static final int GL_OPERAND0_ALPHA = 34200;
/*  97:    */   public static final int GL_OPERAND1_ALPHA = 34201;
/*  98:    */   public static final int GL_OPERAND2_ALPHA = 34202;
/*  99:    */   public static final int GL_RGB_SCALE = 34163;
/* 100:    */   public static final int GL_ADD_SIGNED = 34164;
/* 101:    */   public static final int GL_INTERPOLATE = 34165;
/* 102:    */   public static final int GL_SUBTRACT = 34023;
/* 103:    */   public static final int GL_CONSTANT = 34166;
/* 104:    */   public static final int GL_PRIMARY_COLOR = 34167;
/* 105:    */   public static final int GL_PREVIOUS = 34168;
/* 106:    */   public static final int GL_DOT3_RGB = 34478;
/* 107:    */   public static final int GL_DOT3_RGBA = 34479;
/* 108:    */   public static final int GL_CLAMP_TO_BORDER = 33069;
/* 109:    */   
/* 110:    */   public static void glActiveTexture(int texture)
/* 111:    */   {
/* 112:118 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 113:119 */     long function_pointer = caps.glActiveTexture;
/* 114:120 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 115:121 */     nglActiveTexture(texture, function_pointer);
/* 116:    */   }
/* 117:    */   
/* 118:    */   static native void nglActiveTexture(int paramInt, long paramLong);
/* 119:    */   
/* 120:    */   public static void glClientActiveTexture(int texture)
/* 121:    */   {
/* 122:126 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 123:127 */     long function_pointer = caps.glClientActiveTexture;
/* 124:128 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 125:129 */     StateTracker.getReferences(caps).glClientActiveTexture = (texture - 33984);
/* 126:130 */     nglClientActiveTexture(texture, function_pointer);
/* 127:    */   }
/* 128:    */   
/* 129:    */   static native void nglClientActiveTexture(int paramInt, long paramLong);
/* 130:    */   
/* 131:    */   public static void glCompressedTexImage1D(int target, int level, int internalformat, int width, int border, ByteBuffer data)
/* 132:    */   {
/* 133:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 134:136 */     long function_pointer = caps.glCompressedTexImage1D;
/* 135:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 136:138 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 137:139 */     BufferChecks.checkDirect(data);
/* 138:140 */     nglCompressedTexImage1D(target, level, internalformat, width, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 139:    */   }
/* 140:    */   
/* 141:    */   static native void nglCompressedTexImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 142:    */   
/* 143:    */   public static void glCompressedTexImage1D(int target, int level, int internalformat, int width, int border, int data_imageSize, long data_buffer_offset)
/* 144:    */   {
/* 145:144 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 146:145 */     long function_pointer = caps.glCompressedTexImage1D;
/* 147:146 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 148:147 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 149:148 */     nglCompressedTexImage1DBO(target, level, internalformat, width, border, data_imageSize, data_buffer_offset, function_pointer);
/* 150:    */   }
/* 151:    */   
/* 152:    */   static native void nglCompressedTexImage1DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 153:    */   
/* 154:    */   public static void glCompressedTexImage2D(int target, int level, int internalformat, int width, int height, int border, ByteBuffer data)
/* 155:    */   {
/* 156:153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 157:154 */     long function_pointer = caps.glCompressedTexImage2D;
/* 158:155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 159:156 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 160:157 */     BufferChecks.checkDirect(data);
/* 161:158 */     nglCompressedTexImage2D(target, level, internalformat, width, height, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 162:    */   }
/* 163:    */   
/* 164:    */   static native void nglCompressedTexImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 165:    */   
/* 166:    */   public static void glCompressedTexImage2D(int target, int level, int internalformat, int width, int height, int border, int data_imageSize, long data_buffer_offset)
/* 167:    */   {
/* 168:162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 169:163 */     long function_pointer = caps.glCompressedTexImage2D;
/* 170:164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 171:165 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 172:166 */     nglCompressedTexImage2DBO(target, level, internalformat, width, height, border, data_imageSize, data_buffer_offset, function_pointer);
/* 173:    */   }
/* 174:    */   
/* 175:    */   static native void nglCompressedTexImage2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 176:    */   
/* 177:    */   public static void glCompressedTexImage3D(int target, int level, int internalformat, int width, int height, int depth, int border, ByteBuffer data)
/* 178:    */   {
/* 179:171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 180:172 */     long function_pointer = caps.glCompressedTexImage3D;
/* 181:173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 182:174 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 183:175 */     BufferChecks.checkDirect(data);
/* 184:176 */     nglCompressedTexImage3D(target, level, internalformat, width, height, depth, border, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 185:    */   }
/* 186:    */   
/* 187:    */   static native void nglCompressedTexImage3D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 188:    */   
/* 189:    */   public static void glCompressedTexImage3D(int target, int level, int internalformat, int width, int height, int depth, int border, int data_imageSize, long data_buffer_offset)
/* 190:    */   {
/* 191:180 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 192:181 */     long function_pointer = caps.glCompressedTexImage3D;
/* 193:182 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 194:183 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 195:184 */     nglCompressedTexImage3DBO(target, level, internalformat, width, height, depth, border, data_imageSize, data_buffer_offset, function_pointer);
/* 196:    */   }
/* 197:    */   
/* 198:    */   static native void nglCompressedTexImage3DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 199:    */   
/* 200:    */   public static void glCompressedTexSubImage1D(int target, int level, int xoffset, int width, int format, ByteBuffer data)
/* 201:    */   {
/* 202:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 203:190 */     long function_pointer = caps.glCompressedTexSubImage1D;
/* 204:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 205:192 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 206:193 */     BufferChecks.checkDirect(data);
/* 207:194 */     nglCompressedTexSubImage1D(target, level, xoffset, width, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 208:    */   }
/* 209:    */   
/* 210:    */   static native void nglCompressedTexSubImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 211:    */   
/* 212:    */   public static void glCompressedTexSubImage1D(int target, int level, int xoffset, int width, int format, int data_imageSize, long data_buffer_offset)
/* 213:    */   {
/* 214:198 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 215:199 */     long function_pointer = caps.glCompressedTexSubImage1D;
/* 216:200 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 217:201 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 218:202 */     nglCompressedTexSubImage1DBO(target, level, xoffset, width, format, data_imageSize, data_buffer_offset, function_pointer);
/* 219:    */   }
/* 220:    */   
/* 221:    */   static native void nglCompressedTexSubImage1DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 222:    */   
/* 223:    */   public static void glCompressedTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, ByteBuffer data)
/* 224:    */   {
/* 225:207 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 226:208 */     long function_pointer = caps.glCompressedTexSubImage2D;
/* 227:209 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 228:210 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 229:211 */     BufferChecks.checkDirect(data);
/* 230:212 */     nglCompressedTexSubImage2D(target, level, xoffset, yoffset, width, height, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 231:    */   }
/* 232:    */   
/* 233:    */   static native void nglCompressedTexSubImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 234:    */   
/* 235:    */   public static void glCompressedTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int data_imageSize, long data_buffer_offset)
/* 236:    */   {
/* 237:216 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 238:217 */     long function_pointer = caps.glCompressedTexSubImage2D;
/* 239:218 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 240:219 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 241:220 */     nglCompressedTexSubImage2DBO(target, level, xoffset, yoffset, width, height, format, data_imageSize, data_buffer_offset, function_pointer);
/* 242:    */   }
/* 243:    */   
/* 244:    */   static native void nglCompressedTexSubImage2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 245:    */   
/* 246:    */   public static void glCompressedTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, ByteBuffer data)
/* 247:    */   {
/* 248:225 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 249:226 */     long function_pointer = caps.glCompressedTexSubImage3D;
/* 250:227 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 251:228 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 252:229 */     BufferChecks.checkDirect(data);
/* 253:230 */     nglCompressedTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 254:    */   }
/* 255:    */   
/* 256:    */   static native void nglCompressedTexSubImage3D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 257:    */   
/* 258:    */   public static void glCompressedTexSubImage3D(int target, int level, int xoffset, int yoffset, int zoffset, int width, int height, int depth, int format, int data_imageSize, long data_buffer_offset)
/* 259:    */   {
/* 260:234 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 261:235 */     long function_pointer = caps.glCompressedTexSubImage3D;
/* 262:236 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 263:237 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 264:238 */     nglCompressedTexSubImage3DBO(target, level, xoffset, yoffset, zoffset, width, height, depth, format, data_imageSize, data_buffer_offset, function_pointer);
/* 265:    */   }
/* 266:    */   
/* 267:    */   static native void nglCompressedTexSubImage3DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong1, long paramLong2);
/* 268:    */   
/* 269:    */   public static void glGetCompressedTexImage(int target, int lod, ByteBuffer img)
/* 270:    */   {
/* 271:243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 272:244 */     long function_pointer = caps.glGetCompressedTexImage;
/* 273:245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 274:246 */     GLChecks.ensurePackPBOdisabled(caps);
/* 275:247 */     BufferChecks.checkDirect(img);
/* 276:248 */     nglGetCompressedTexImage(target, lod, MemoryUtil.getAddress(img), function_pointer);
/* 277:    */   }
/* 278:    */   
/* 279:    */   public static void glGetCompressedTexImage(int target, int lod, IntBuffer img)
/* 280:    */   {
/* 281:251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 282:252 */     long function_pointer = caps.glGetCompressedTexImage;
/* 283:253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 284:254 */     GLChecks.ensurePackPBOdisabled(caps);
/* 285:255 */     BufferChecks.checkDirect(img);
/* 286:256 */     nglGetCompressedTexImage(target, lod, MemoryUtil.getAddress(img), function_pointer);
/* 287:    */   }
/* 288:    */   
/* 289:    */   public static void glGetCompressedTexImage(int target, int lod, ShortBuffer img)
/* 290:    */   {
/* 291:259 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 292:260 */     long function_pointer = caps.glGetCompressedTexImage;
/* 293:261 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 294:262 */     GLChecks.ensurePackPBOdisabled(caps);
/* 295:263 */     BufferChecks.checkDirect(img);
/* 296:264 */     nglGetCompressedTexImage(target, lod, MemoryUtil.getAddress(img), function_pointer);
/* 297:    */   }
/* 298:    */   
/* 299:    */   static native void nglGetCompressedTexImage(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 300:    */   
/* 301:    */   public static void glGetCompressedTexImage(int target, int lod, long img_buffer_offset)
/* 302:    */   {
/* 303:268 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 304:269 */     long function_pointer = caps.glGetCompressedTexImage;
/* 305:270 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 306:271 */     GLChecks.ensurePackPBOenabled(caps);
/* 307:272 */     nglGetCompressedTexImageBO(target, lod, img_buffer_offset, function_pointer);
/* 308:    */   }
/* 309:    */   
/* 310:    */   static native void nglGetCompressedTexImageBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 311:    */   
/* 312:    */   public static void glMultiTexCoord1f(int target, float s)
/* 313:    */   {
/* 314:277 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 315:278 */     long function_pointer = caps.glMultiTexCoord1f;
/* 316:279 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 317:280 */     nglMultiTexCoord1f(target, s, function_pointer);
/* 318:    */   }
/* 319:    */   
/* 320:    */   static native void nglMultiTexCoord1f(int paramInt, float paramFloat, long paramLong);
/* 321:    */   
/* 322:    */   public static void glMultiTexCoord1d(int target, double s)
/* 323:    */   {
/* 324:285 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 325:286 */     long function_pointer = caps.glMultiTexCoord1d;
/* 326:287 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 327:288 */     nglMultiTexCoord1d(target, s, function_pointer);
/* 328:    */   }
/* 329:    */   
/* 330:    */   static native void nglMultiTexCoord1d(int paramInt, double paramDouble, long paramLong);
/* 331:    */   
/* 332:    */   public static void glMultiTexCoord2f(int target, float s, float t)
/* 333:    */   {
/* 334:293 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 335:294 */     long function_pointer = caps.glMultiTexCoord2f;
/* 336:295 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 337:296 */     nglMultiTexCoord2f(target, s, t, function_pointer);
/* 338:    */   }
/* 339:    */   
/* 340:    */   static native void nglMultiTexCoord2f(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/* 341:    */   
/* 342:    */   public static void glMultiTexCoord2d(int target, double s, double t)
/* 343:    */   {
/* 344:301 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 345:302 */     long function_pointer = caps.glMultiTexCoord2d;
/* 346:303 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 347:304 */     nglMultiTexCoord2d(target, s, t, function_pointer);
/* 348:    */   }
/* 349:    */   
/* 350:    */   static native void nglMultiTexCoord2d(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 351:    */   
/* 352:    */   public static void glMultiTexCoord3f(int target, float s, float t, float r)
/* 353:    */   {
/* 354:309 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 355:310 */     long function_pointer = caps.glMultiTexCoord3f;
/* 356:311 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 357:312 */     nglMultiTexCoord3f(target, s, t, r, function_pointer);
/* 358:    */   }
/* 359:    */   
/* 360:    */   static native void nglMultiTexCoord3f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 361:    */   
/* 362:    */   public static void glMultiTexCoord3d(int target, double s, double t, double r)
/* 363:    */   {
/* 364:317 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 365:318 */     long function_pointer = caps.glMultiTexCoord3d;
/* 366:319 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 367:320 */     nglMultiTexCoord3d(target, s, t, r, function_pointer);
/* 368:    */   }
/* 369:    */   
/* 370:    */   static native void nglMultiTexCoord3d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 371:    */   
/* 372:    */   public static void glMultiTexCoord4f(int target, float s, float t, float r, float q)
/* 373:    */   {
/* 374:325 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 375:326 */     long function_pointer = caps.glMultiTexCoord4f;
/* 376:327 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 377:328 */     nglMultiTexCoord4f(target, s, t, r, q, function_pointer);
/* 378:    */   }
/* 379:    */   
/* 380:    */   static native void nglMultiTexCoord4f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 381:    */   
/* 382:    */   public static void glMultiTexCoord4d(int target, double s, double t, double r, double q)
/* 383:    */   {
/* 384:333 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 385:334 */     long function_pointer = caps.glMultiTexCoord4d;
/* 386:335 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 387:336 */     nglMultiTexCoord4d(target, s, t, r, q, function_pointer);
/* 388:    */   }
/* 389:    */   
/* 390:    */   static native void nglMultiTexCoord4d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 391:    */   
/* 392:    */   public static void glLoadTransposeMatrix(FloatBuffer m)
/* 393:    */   {
/* 394:341 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 395:342 */     long function_pointer = caps.glLoadTransposeMatrixf;
/* 396:343 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 397:344 */     BufferChecks.checkBuffer(m, 16);
/* 398:345 */     nglLoadTransposeMatrixf(MemoryUtil.getAddress(m), function_pointer);
/* 399:    */   }
/* 400:    */   
/* 401:    */   static native void nglLoadTransposeMatrixf(long paramLong1, long paramLong2);
/* 402:    */   
/* 403:    */   public static void glLoadTransposeMatrix(DoubleBuffer m)
/* 404:    */   {
/* 405:350 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 406:351 */     long function_pointer = caps.glLoadTransposeMatrixd;
/* 407:352 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 408:353 */     BufferChecks.checkBuffer(m, 16);
/* 409:354 */     nglLoadTransposeMatrixd(MemoryUtil.getAddress(m), function_pointer);
/* 410:    */   }
/* 411:    */   
/* 412:    */   static native void nglLoadTransposeMatrixd(long paramLong1, long paramLong2);
/* 413:    */   
/* 414:    */   public static void glMultTransposeMatrix(FloatBuffer m)
/* 415:    */   {
/* 416:359 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 417:360 */     long function_pointer = caps.glMultTransposeMatrixf;
/* 418:361 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 419:362 */     BufferChecks.checkBuffer(m, 16);
/* 420:363 */     nglMultTransposeMatrixf(MemoryUtil.getAddress(m), function_pointer);
/* 421:    */   }
/* 422:    */   
/* 423:    */   static native void nglMultTransposeMatrixf(long paramLong1, long paramLong2);
/* 424:    */   
/* 425:    */   public static void glMultTransposeMatrix(DoubleBuffer m)
/* 426:    */   {
/* 427:368 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 428:369 */     long function_pointer = caps.glMultTransposeMatrixd;
/* 429:370 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 430:371 */     BufferChecks.checkBuffer(m, 16);
/* 431:372 */     nglMultTransposeMatrixd(MemoryUtil.getAddress(m), function_pointer);
/* 432:    */   }
/* 433:    */   
/* 434:    */   static native void nglMultTransposeMatrixd(long paramLong1, long paramLong2);
/* 435:    */   
/* 436:    */   public static void glSampleCoverage(float value, boolean invert)
/* 437:    */   {
/* 438:377 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 439:378 */     long function_pointer = caps.glSampleCoverage;
/* 440:379 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 441:380 */     nglSampleCoverage(value, invert, function_pointer);
/* 442:    */   }
/* 443:    */   
/* 444:    */   static native void nglSampleCoverage(float paramFloat, boolean paramBoolean, long paramLong);
/* 445:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL13
 * JD-Core Version:    0.7.0.1
 */