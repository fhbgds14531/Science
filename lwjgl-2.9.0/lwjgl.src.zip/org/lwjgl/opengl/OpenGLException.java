/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ public class OpenGLException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public OpenGLException(int gl_error_code)
/*  9:   */   {
/* 10:48 */     this(createErrorMessage(gl_error_code));
/* 11:   */   }
/* 12:   */   
/* 13:   */   private static String createErrorMessage(int gl_error_code)
/* 14:   */   {
/* 15:52 */     String error_string = Util.translateGLErrorString(gl_error_code);
/* 16:53 */     return error_string + " (" + gl_error_code + ")";
/* 17:   */   }
/* 18:   */   
/* 19:   */   public OpenGLException() {}
/* 20:   */   
/* 21:   */   public OpenGLException(String message)
/* 22:   */   {
/* 23:67 */     super(message);
/* 24:   */   }
/* 25:   */   
/* 26:   */   public OpenGLException(String message, Throwable cause)
/* 27:   */   {
/* 28:77 */     super(message, cause);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public OpenGLException(Throwable cause)
/* 32:   */   {
/* 33:86 */     super(cause);
/* 34:   */   }
/* 35:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.OpenGLException
 * JD-Core Version:    0.7.0.1
 */