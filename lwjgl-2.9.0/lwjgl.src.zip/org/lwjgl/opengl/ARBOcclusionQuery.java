/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferChecks;
/*   5:    */ import org.lwjgl.MemoryUtil;
/*   6:    */ 
/*   7:    */ public final class ARBOcclusionQuery
/*   8:    */ {
/*   9:    */   public static final int GL_SAMPLES_PASSED_ARB = 35092;
/*  10:    */   public static final int GL_QUERY_COUNTER_BITS_ARB = 34916;
/*  11:    */   public static final int GL_CURRENT_QUERY_ARB = 34917;
/*  12:    */   public static final int GL_QUERY_RESULT_ARB = 34918;
/*  13:    */   public static final int GL_QUERY_RESULT_AVAILABLE_ARB = 34919;
/*  14:    */   
/*  15:    */   public static void glGenQueriesARB(IntBuffer ids)
/*  16:    */   {
/*  17: 32 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  18: 33 */     long function_pointer = caps.glGenQueriesARB;
/*  19: 34 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  20: 35 */     BufferChecks.checkDirect(ids);
/*  21: 36 */     nglGenQueriesARB(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/*  22:    */   }
/*  23:    */   
/*  24:    */   static native void nglGenQueriesARB(int paramInt, long paramLong1, long paramLong2);
/*  25:    */   
/*  26:    */   public static int glGenQueriesARB()
/*  27:    */   {
/*  28: 42 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  29: 43 */     long function_pointer = caps.glGenQueriesARB;
/*  30: 44 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  31: 45 */     IntBuffer ids = APIUtil.getBufferInt(caps);
/*  32: 46 */     nglGenQueriesARB(1, MemoryUtil.getAddress(ids), function_pointer);
/*  33: 47 */     return ids.get(0);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static void glDeleteQueriesARB(IntBuffer ids)
/*  37:    */   {
/*  38: 51 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  39: 52 */     long function_pointer = caps.glDeleteQueriesARB;
/*  40: 53 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  41: 54 */     BufferChecks.checkDirect(ids);
/*  42: 55 */     nglDeleteQueriesARB(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/*  43:    */   }
/*  44:    */   
/*  45:    */   static native void nglDeleteQueriesARB(int paramInt, long paramLong1, long paramLong2);
/*  46:    */   
/*  47:    */   public static void glDeleteQueriesARB(int id)
/*  48:    */   {
/*  49: 61 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  50: 62 */     long function_pointer = caps.glDeleteQueriesARB;
/*  51: 63 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  52: 64 */     nglDeleteQueriesARB(1, APIUtil.getInt(caps, id), function_pointer);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static boolean glIsQueryARB(int id)
/*  56:    */   {
/*  57: 68 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  58: 69 */     long function_pointer = caps.glIsQueryARB;
/*  59: 70 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  60: 71 */     boolean __result = nglIsQueryARB(id, function_pointer);
/*  61: 72 */     return __result;
/*  62:    */   }
/*  63:    */   
/*  64:    */   static native boolean nglIsQueryARB(int paramInt, long paramLong);
/*  65:    */   
/*  66:    */   public static void glBeginQueryARB(int target, int id)
/*  67:    */   {
/*  68: 77 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  69: 78 */     long function_pointer = caps.glBeginQueryARB;
/*  70: 79 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  71: 80 */     nglBeginQueryARB(target, id, function_pointer);
/*  72:    */   }
/*  73:    */   
/*  74:    */   static native void nglBeginQueryARB(int paramInt1, int paramInt2, long paramLong);
/*  75:    */   
/*  76:    */   public static void glEndQueryARB(int target)
/*  77:    */   {
/*  78: 85 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79: 86 */     long function_pointer = caps.glEndQueryARB;
/*  80: 87 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81: 88 */     nglEndQueryARB(target, function_pointer);
/*  82:    */   }
/*  83:    */   
/*  84:    */   static native void nglEndQueryARB(int paramInt, long paramLong);
/*  85:    */   
/*  86:    */   public static void glGetQueryARB(int target, int pname, IntBuffer params)
/*  87:    */   {
/*  88: 93 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  89: 94 */     long function_pointer = caps.glGetQueryivARB;
/*  90: 95 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  91: 96 */     BufferChecks.checkBuffer(params, 1);
/*  92: 97 */     nglGetQueryivARB(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  93:    */   }
/*  94:    */   
/*  95:    */   static native void nglGetQueryivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  96:    */   
/*  97:    */   @Deprecated
/*  98:    */   public static int glGetQueryARB(int target, int pname)
/*  99:    */   {
/* 100:108 */     return glGetQueryiARB(target, pname);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static int glGetQueryiARB(int target, int pname)
/* 104:    */   {
/* 105:113 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106:114 */     long function_pointer = caps.glGetQueryivARB;
/* 107:115 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108:116 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 109:117 */     nglGetQueryivARB(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 110:118 */     return params.get(0);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static void glGetQueryObjectARB(int id, int pname, IntBuffer params)
/* 114:    */   {
/* 115:122 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 116:123 */     long function_pointer = caps.glGetQueryObjectivARB;
/* 117:124 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 118:125 */     BufferChecks.checkBuffer(params, 1);
/* 119:126 */     nglGetQueryObjectivARB(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 120:    */   }
/* 121:    */   
/* 122:    */   static native void nglGetQueryObjectivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 123:    */   
/* 124:    */   public static int glGetQueryObjectiARB(int id, int pname)
/* 125:    */   {
/* 126:132 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:133 */     long function_pointer = caps.glGetQueryObjectivARB;
/* 128:134 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:135 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 130:136 */     nglGetQueryObjectivARB(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 131:137 */     return params.get(0);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static void glGetQueryObjectuARB(int id, int pname, IntBuffer params)
/* 135:    */   {
/* 136:141 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 137:142 */     long function_pointer = caps.glGetQueryObjectuivARB;
/* 138:143 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 139:144 */     BufferChecks.checkBuffer(params, 1);
/* 140:145 */     nglGetQueryObjectuivARB(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 141:    */   }
/* 142:    */   
/* 143:    */   static native void nglGetQueryObjectuivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 144:    */   
/* 145:    */   public static int glGetQueryObjectuiARB(int id, int pname)
/* 146:    */   {
/* 147:151 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 148:152 */     long function_pointer = caps.glGetQueryObjectuivARB;
/* 149:153 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 150:154 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 151:155 */     nglGetQueryObjectuivARB(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 152:156 */     return params.get(0);
/* 153:    */   }
/* 154:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBOcclusionQuery
 * JD-Core Version:    0.7.0.1
 */