/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ final class LinuxKeycodes
/*   4:    */ {
/*   5:    */   public static final int XK_Kanji = 65313;
/*   6:    */   public static final int XK_ISO_Left_Tab = 65056;
/*   7:    */   public static final int XK_dead_grave = 65104;
/*   8:    */   public static final int XK_dead_acute = 65105;
/*   9:    */   public static final int XK_dead_circumflex = 65106;
/*  10:    */   public static final int XK_dead_tilde = 65107;
/*  11:    */   public static final int XK_dead_macron = 65108;
/*  12:    */   public static final int XK_dead_breve = 65109;
/*  13:    */   public static final int XK_dead_abovedot = 65110;
/*  14:    */   public static final int XK_dead_diaeresis = 65111;
/*  15:    */   public static final int XK_dead_abovering = 65112;
/*  16:    */   public static final int XK_dead_doubleacute = 65113;
/*  17:    */   public static final int XK_dead_caron = 65114;
/*  18:    */   public static final int XK_dead_cedilla = 65115;
/*  19:    */   public static final int XK_dead_ogonek = 65116;
/*  20:    */   public static final int XK_dead_iota = 65117;
/*  21:    */   public static final int XK_dead_voiced_sound = 65118;
/*  22:    */   public static final int XK_dead_semivoiced_sound = 65119;
/*  23:    */   public static final int XK_dead_belowdot = 65120;
/*  24:    */   public static final int XK_dead_hook = 65121;
/*  25:    */   public static final int XK_dead_horn = 65122;
/*  26:    */   public static final int XK_BackSpace = 65288;
/*  27:    */   public static final int XK_Tab = 65289;
/*  28:    */   public static final int XK_Linefeed = 65290;
/*  29:    */   public static final int XK_Clear = 65291;
/*  30:    */   public static final int XK_Return = 65293;
/*  31:    */   public static final int XK_Pause = 65299;
/*  32:    */   public static final int XK_Scroll_Lock = 65300;
/*  33:    */   public static final int XK_Sys_Req = 65301;
/*  34:    */   public static final int XK_Escape = 65307;
/*  35:    */   public static final int XK_Delete = 65535;
/*  36:    */   public static final int XK_Home = 65360;
/*  37:    */   public static final int XK_Left = 65361;
/*  38:    */   public static final int XK_Up = 65362;
/*  39:    */   public static final int XK_Right = 65363;
/*  40:    */   public static final int XK_Down = 65364;
/*  41:    */   public static final int XK_Prior = 65365;
/*  42:    */   public static final int XK_Page_Up = 65365;
/*  43:    */   public static final int XK_Next = 65366;
/*  44:    */   public static final int XK_Page_Down = 65366;
/*  45:    */   public static final int XK_End = 65367;
/*  46:    */   public static final int XK_Begin = 65368;
/*  47:    */   public static final int XK_Select = 65376;
/*  48:    */   public static final int XK_Print = 65377;
/*  49:    */   public static final int XK_Execute = 65378;
/*  50:    */   public static final int XK_Insert = 65379;
/*  51:    */   public static final int XK_Undo = 65381;
/*  52:    */   public static final int XK_Redo = 65382;
/*  53:    */   public static final int XK_Menu = 65383;
/*  54:    */   public static final int XK_Find = 65384;
/*  55:    */   public static final int XK_Cancel = 65385;
/*  56:    */   public static final int XK_Help = 65386;
/*  57:    */   public static final int XK_Break = 65387;
/*  58:    */   public static final int XK_Mode_switch = 65406;
/*  59:    */   public static final int XK_script_switch = 65406;
/*  60:    */   public static final int XK_Num_Lock = 65407;
/*  61:    */   public static final int XK_KP_Space = 65408;
/*  62:    */   public static final int XK_KP_Tab = 65417;
/*  63:    */   public static final int XK_KP_Enter = 65421;
/*  64:    */   public static final int XK_KP_F1 = 65425;
/*  65:    */   public static final int XK_KP_F2 = 65426;
/*  66:    */   public static final int XK_KP_F3 = 65427;
/*  67:    */   public static final int XK_KP_F4 = 65428;
/*  68:    */   public static final int XK_KP_Home = 65429;
/*  69:    */   public static final int XK_KP_Left = 65430;
/*  70:    */   public static final int XK_KP_Up = 65431;
/*  71:    */   public static final int XK_KP_Right = 65432;
/*  72:    */   public static final int XK_KP_Down = 65433;
/*  73:    */   public static final int XK_KP_Prior = 65434;
/*  74:    */   public static final int XK_KP_Page_Up = 65434;
/*  75:    */   public static final int XK_KP_Next = 65435;
/*  76:    */   public static final int XK_KP_Page_Down = 65435;
/*  77:    */   public static final int XK_KP_End = 65436;
/*  78:    */   public static final int XK_KP_Begin = 65437;
/*  79:    */   public static final int XK_KP_Insert = 65438;
/*  80:    */   public static final int XK_KP_Delete = 65439;
/*  81:    */   public static final int XK_KP_Equal = 65469;
/*  82:    */   public static final int XK_KP_Multiply = 65450;
/*  83:    */   public static final int XK_KP_Add = 65451;
/*  84:    */   public static final int XK_KP_Separator = 65452;
/*  85:    */   public static final int XK_KP_Subtract = 65453;
/*  86:    */   public static final int XK_KP_Decimal = 65454;
/*  87:    */   public static final int XK_KP_Divide = 65455;
/*  88:    */   public static final int XK_KP_0 = 65456;
/*  89:    */   public static final int XK_KP_1 = 65457;
/*  90:    */   public static final int XK_KP_2 = 65458;
/*  91:    */   public static final int XK_KP_3 = 65459;
/*  92:    */   public static final int XK_KP_4 = 65460;
/*  93:    */   public static final int XK_KP_5 = 65461;
/*  94:    */   public static final int XK_KP_6 = 65462;
/*  95:    */   public static final int XK_KP_7 = 65463;
/*  96:    */   public static final int XK_KP_8 = 65464;
/*  97:    */   public static final int XK_KP_9 = 65465;
/*  98:    */   public static final int XK_F1 = 65470;
/*  99:    */   public static final int XK_F2 = 65471;
/* 100:    */   public static final int XK_F3 = 65472;
/* 101:    */   public static final int XK_F4 = 65473;
/* 102:    */   public static final int XK_F5 = 65474;
/* 103:    */   public static final int XK_F6 = 65475;
/* 104:    */   public static final int XK_F7 = 65476;
/* 105:    */   public static final int XK_F8 = 65477;
/* 106:    */   public static final int XK_F9 = 65478;
/* 107:    */   public static final int XK_F10 = 65479;
/* 108:    */   public static final int XK_F11 = 65480;
/* 109:    */   public static final int XK_L1 = 65480;
/* 110:    */   public static final int XK_F12 = 65481;
/* 111:    */   public static final int XK_L2 = 65481;
/* 112:    */   public static final int XK_F13 = 65482;
/* 113:    */   public static final int XK_L3 = 65482;
/* 114:    */   public static final int XK_F14 = 65483;
/* 115:    */   public static final int XK_L4 = 65483;
/* 116:    */   public static final int XK_F15 = 65484;
/* 117:    */   public static final int XK_L5 = 65484;
/* 118:    */   public static final int XK_F16 = 65485;
/* 119:    */   public static final int XK_L6 = 65485;
/* 120:    */   public static final int XK_F17 = 65486;
/* 121:    */   public static final int XK_L7 = 65486;
/* 122:    */   public static final int XK_F18 = 65487;
/* 123:    */   public static final int XK_L8 = 65487;
/* 124:    */   public static final int XK_F19 = 65488;
/* 125:    */   public static final int XK_L9 = 65488;
/* 126:    */   public static final int XK_F20 = 65489;
/* 127:    */   public static final int XK_L10 = 65489;
/* 128:    */   public static final int XK_F21 = 65490;
/* 129:    */   public static final int XK_R1 = 65490;
/* 130:    */   public static final int XK_F22 = 65491;
/* 131:    */   public static final int XK_R2 = 65491;
/* 132:    */   public static final int XK_F23 = 65492;
/* 133:    */   public static final int XK_R3 = 65492;
/* 134:    */   public static final int XK_F24 = 65493;
/* 135:    */   public static final int XK_R4 = 65493;
/* 136:    */   public static final int XK_F25 = 65494;
/* 137:    */   public static final int XK_R5 = 65494;
/* 138:    */   public static final int XK_F26 = 65495;
/* 139:    */   public static final int XK_R6 = 65495;
/* 140:    */   public static final int XK_F27 = 65496;
/* 141:    */   public static final int XK_R7 = 65496;
/* 142:    */   public static final int XK_F28 = 65497;
/* 143:    */   public static final int XK_R8 = 65497;
/* 144:    */   public static final int XK_F29 = 65498;
/* 145:    */   public static final int XK_R9 = 65498;
/* 146:    */   public static final int XK_F30 = 65499;
/* 147:    */   public static final int XK_R10 = 65499;
/* 148:    */   public static final int XK_F31 = 65500;
/* 149:    */   public static final int XK_R11 = 65500;
/* 150:    */   public static final int XK_F32 = 65501;
/* 151:    */   public static final int XK_R12 = 65501;
/* 152:    */   public static final int XK_F33 = 65502;
/* 153:    */   public static final int XK_R13 = 65502;
/* 154:    */   public static final int XK_F34 = 65503;
/* 155:    */   public static final int XK_R14 = 65503;
/* 156:    */   public static final int XK_F35 = 65504;
/* 157:    */   public static final int XK_R15 = 65504;
/* 158:    */   public static final int XK_Shift_L = 65505;
/* 159:    */   public static final int XK_Shift_R = 65506;
/* 160:    */   public static final int XK_Control_L = 65507;
/* 161:    */   public static final int XK_Control_R = 65508;
/* 162:    */   public static final int XK_Caps_Lock = 65509;
/* 163:    */   public static final int XK_Shift_Lock = 65510;
/* 164:    */   public static final int XK_Meta_L = 65511;
/* 165:    */   public static final int XK_Meta_R = 65512;
/* 166:    */   public static final int XK_Alt_L = 65513;
/* 167:    */   public static final int XK_Alt_R = 65514;
/* 168:    */   public static final int XK_Super_L = 65515;
/* 169:    */   public static final int XK_Super_R = 65516;
/* 170:    */   public static final int XK_Hyper_L = 65517;
/* 171:    */   public static final int XK_Hyper_R = 65518;
/* 172:    */   public static final int XK_space = 32;
/* 173:    */   public static final int XK_exclam = 33;
/* 174:    */   public static final int XK_quotedbl = 34;
/* 175:    */   public static final int XK_numbersign = 35;
/* 176:    */   public static final int XK_dollar = 36;
/* 177:    */   public static final int XK_percent = 37;
/* 178:    */   public static final int XK_ampersand = 38;
/* 179:    */   public static final int XK_apostrophe = 39;
/* 180:    */   public static final int XK_quoteright = 39;
/* 181:    */   public static final int XK_parenleft = 40;
/* 182:    */   public static final int XK_parenright = 41;
/* 183:    */   public static final int XK_asterisk = 42;
/* 184:    */   public static final int XK_plus = 43;
/* 185:    */   public static final int XK_comma = 44;
/* 186:    */   public static final int XK_minus = 45;
/* 187:    */   public static final int XK_period = 46;
/* 188:    */   public static final int XK_slash = 47;
/* 189:    */   public static final int XK_0 = 48;
/* 190:    */   public static final int XK_1 = 49;
/* 191:    */   public static final int XK_2 = 50;
/* 192:    */   public static final int XK_3 = 51;
/* 193:    */   public static final int XK_4 = 52;
/* 194:    */   public static final int XK_5 = 53;
/* 195:    */   public static final int XK_6 = 54;
/* 196:    */   public static final int XK_7 = 55;
/* 197:    */   public static final int XK_8 = 56;
/* 198:    */   public static final int XK_9 = 57;
/* 199:    */   public static final int XK_colon = 58;
/* 200:    */   public static final int XK_semicolon = 59;
/* 201:    */   public static final int XK_less = 60;
/* 202:    */   public static final int XK_equal = 61;
/* 203:    */   public static final int XK_greater = 62;
/* 204:    */   public static final int XK_question = 63;
/* 205:    */   public static final int XK_at = 64;
/* 206:    */   public static final int XK_A = 65;
/* 207:    */   public static final int XK_B = 66;
/* 208:    */   public static final int XK_C = 67;
/* 209:    */   public static final int XK_D = 68;
/* 210:    */   public static final int XK_E = 69;
/* 211:    */   public static final int XK_F = 70;
/* 212:    */   public static final int XK_G = 71;
/* 213:    */   public static final int XK_H = 72;
/* 214:    */   public static final int XK_I = 73;
/* 215:    */   public static final int XK_J = 74;
/* 216:    */   public static final int XK_K = 75;
/* 217:    */   public static final int XK_L = 76;
/* 218:    */   public static final int XK_M = 77;
/* 219:    */   public static final int XK_N = 78;
/* 220:    */   public static final int XK_O = 79;
/* 221:    */   public static final int XK_P = 80;
/* 222:    */   public static final int XK_Q = 81;
/* 223:    */   public static final int XK_R = 82;
/* 224:    */   public static final int XK_S = 83;
/* 225:    */   public static final int XK_T = 84;
/* 226:    */   public static final int XK_U = 85;
/* 227:    */   public static final int XK_V = 86;
/* 228:    */   public static final int XK_W = 87;
/* 229:    */   public static final int XK_X = 88;
/* 230:    */   public static final int XK_Y = 89;
/* 231:    */   public static final int XK_Z = 90;
/* 232:    */   public static final int XK_bracketleft = 91;
/* 233:    */   public static final int XK_backslash = 92;
/* 234:    */   public static final int XK_bracketright = 93;
/* 235:    */   public static final int XK_asciicircum = 94;
/* 236:    */   public static final int XK_underscore = 95;
/* 237:    */   public static final int XK_grave = 96;
/* 238:    */   public static final int XK_quoteleft = 96;
/* 239:    */   public static final int XK_a = 97;
/* 240:    */   public static final int XK_b = 98;
/* 241:    */   public static final int XK_c = 99;
/* 242:    */   public static final int XK_d = 100;
/* 243:    */   public static final int XK_e = 101;
/* 244:    */   public static final int XK_f = 102;
/* 245:    */   public static final int XK_g = 103;
/* 246:    */   public static final int XK_h = 104;
/* 247:    */   public static final int XK_i = 105;
/* 248:    */   public static final int XK_j = 106;
/* 249:    */   public static final int XK_k = 107;
/* 250:    */   public static final int XK_l = 108;
/* 251:    */   public static final int XK_m = 109;
/* 252:    */   public static final int XK_n = 110;
/* 253:    */   public static final int XK_o = 111;
/* 254:    */   public static final int XK_p = 112;
/* 255:    */   public static final int XK_q = 113;
/* 256:    */   public static final int XK_r = 114;
/* 257:    */   public static final int XK_s = 115;
/* 258:    */   public static final int XK_t = 116;
/* 259:    */   public static final int XK_u = 117;
/* 260:    */   public static final int XK_v = 118;
/* 261:    */   public static final int XK_w = 119;
/* 262:    */   public static final int XK_x = 120;
/* 263:    */   public static final int XK_y = 121;
/* 264:    */   public static final int XK_z = 122;
/* 265:    */   public static final int XK_braceleft = 123;
/* 266:    */   public static final int XK_bar = 124;
/* 267:    */   public static final int XK_braceright = 125;
/* 268:    */   public static final int XK_asciitilde = 126;
/* 269:    */   public static final int XK_nobreakspace = 160;
/* 270:    */   public static final int XK_exclamdown = 161;
/* 271:    */   public static final int XK_cent = 162;
/* 272:    */   public static final int XK_sterling = 163;
/* 273:    */   public static final int XK_currency = 164;
/* 274:    */   public static final int XK_yen = 165;
/* 275:    */   public static final int XK_brokenbar = 166;
/* 276:    */   public static final int XK_section = 167;
/* 277:    */   public static final int XK_diaeresis = 168;
/* 278:    */   public static final int XK_copyright = 169;
/* 279:    */   public static final int XK_ordfeminine = 170;
/* 280:    */   public static final int XK_guillemotleft = 171;
/* 281:    */   public static final int XK_notsign = 172;
/* 282:    */   public static final int XK_hyphen = 173;
/* 283:    */   public static final int XK_registered = 174;
/* 284:    */   public static final int XK_macron = 175;
/* 285:    */   public static final int XK_degree = 176;
/* 286:    */   public static final int XK_plusminus = 177;
/* 287:    */   public static final int XK_twosuperior = 178;
/* 288:    */   public static final int XK_threesuperior = 179;
/* 289:    */   public static final int XK_acute = 180;
/* 290:    */   public static final int XK_mu = 181;
/* 291:    */   public static final int XK_paragraph = 182;
/* 292:    */   public static final int XK_periodcentered = 183;
/* 293:    */   public static final int XK_cedilla = 184;
/* 294:    */   public static final int XK_onesuperior = 185;
/* 295:    */   public static final int XK_masculine = 186;
/* 296:    */   public static final int XK_guillemotright = 187;
/* 297:    */   public static final int XK_onequarter = 188;
/* 298:    */   public static final int XK_onehalf = 189;
/* 299:    */   public static final int XK_threequarters = 190;
/* 300:    */   public static final int XK_questiondown = 191;
/* 301:    */   public static final int XK_Agrave = 192;
/* 302:    */   public static final int XK_Aacute = 193;
/* 303:    */   public static final int XK_Acircumflex = 194;
/* 304:    */   public static final int XK_Atilde = 195;
/* 305:    */   public static final int XK_Adiaeresis = 196;
/* 306:    */   public static final int XK_Aring = 197;
/* 307:    */   public static final int XK_AE = 198;
/* 308:    */   public static final int XK_Ccedilla = 199;
/* 309:    */   public static final int XK_Egrave = 200;
/* 310:    */   public static final int XK_Eacute = 201;
/* 311:    */   public static final int XK_Ecircumflex = 202;
/* 312:    */   public static final int XK_Ediaeresis = 203;
/* 313:    */   public static final int XK_Igrave = 204;
/* 314:    */   public static final int XK_Iacute = 205;
/* 315:    */   public static final int XK_Icircumflex = 206;
/* 316:    */   public static final int XK_Idiaeresis = 207;
/* 317:    */   public static final int XK_ETH = 208;
/* 318:    */   public static final int XK_Eth = 208;
/* 319:    */   public static final int XK_Ntilde = 209;
/* 320:    */   public static final int XK_Ograve = 210;
/* 321:    */   public static final int XK_Oacute = 211;
/* 322:    */   public static final int XK_Ocircumflex = 212;
/* 323:    */   public static final int XK_Otilde = 213;
/* 324:    */   public static final int XK_Odiaeresis = 214;
/* 325:    */   public static final int XK_multiply = 215;
/* 326:    */   public static final int XK_Oslash = 216;
/* 327:    */   public static final int XK_Ooblique = 216;
/* 328:    */   public static final int XK_Ugrave = 217;
/* 329:    */   public static final int XK_Uacute = 218;
/* 330:    */   public static final int XK_Ucircumflex = 219;
/* 331:    */   public static final int XK_Udiaeresis = 220;
/* 332:    */   public static final int XK_Yacute = 221;
/* 333:    */   public static final int XK_THORN = 222;
/* 334:    */   public static final int XK_Thorn = 222;
/* 335:    */   public static final int XK_ssharp = 223;
/* 336:    */   public static final int XK_agrave = 224;
/* 337:    */   public static final int XK_aacute = 225;
/* 338:    */   public static final int XK_acircumflex = 226;
/* 339:    */   public static final int XK_atilde = 227;
/* 340:    */   public static final int XK_adiaeresis = 228;
/* 341:    */   public static final int XK_aring = 229;
/* 342:    */   public static final int XK_ae = 230;
/* 343:    */   public static final int XK_ccedilla = 231;
/* 344:    */   public static final int XK_egrave = 232;
/* 345:    */   public static final int XK_eacute = 233;
/* 346:    */   public static final int XK_ecircumflex = 234;
/* 347:    */   public static final int XK_ediaeresis = 235;
/* 348:    */   public static final int XK_igrave = 236;
/* 349:    */   public static final int XK_iacute = 237;
/* 350:    */   public static final int XK_icircumflex = 238;
/* 351:    */   public static final int XK_idiaeresis = 239;
/* 352:    */   public static final int XK_eth = 240;
/* 353:    */   public static final int XK_ntilde = 241;
/* 354:    */   public static final int XK_ograve = 242;
/* 355:    */   public static final int XK_oacute = 243;
/* 356:    */   public static final int XK_ocircumflex = 244;
/* 357:    */   public static final int XK_otilde = 245;
/* 358:    */   public static final int XK_odiaeresis = 246;
/* 359:    */   public static final int XK_division = 247;
/* 360:    */   public static final int XK_oslash = 248;
/* 361:    */   public static final int XK_ooblique = 248;
/* 362:    */   public static final int XK_ugrave = 249;
/* 363:    */   public static final int XK_uacute = 250;
/* 364:    */   public static final int XK_ucircumflex = 251;
/* 365:    */   public static final int XK_udiaeresis = 252;
/* 366:    */   public static final int XK_yacute = 253;
/* 367:    */   public static final int XK_thorn = 254;
/* 368:    */   public static final int XK_ydiaeresis = 255;
/* 369:    */   public static final int XK_ISO_Level3_Shift = 65027;
/* 370:    */   
/* 371:    */   public static int mapKeySymToLWJGLKeyCode(long keysym)
/* 372:    */   {
/* 373:437 */     switch ((int)keysym)
/* 374:    */     {
/* 375:    */     case 65288: 
/* 376:439 */       return 14;
/* 377:    */     case 65056: 
/* 378:    */     case 65289: 
/* 379:442 */       return 15;
/* 380:    */     case 65293: 
/* 381:444 */       return 28;
/* 382:    */     case 65299: 
/* 383:446 */       return 197;
/* 384:    */     case 65300: 
/* 385:448 */       return 70;
/* 386:    */     case 65301: 
/* 387:450 */       return 183;
/* 388:    */     case 65307: 
/* 389:452 */       return 1;
/* 390:    */     case 65535: 
/* 391:454 */       return 211;
/* 392:    */     case 65313: 
/* 393:459 */       return 148;
/* 394:    */     case 65360: 
/* 395:464 */       return 199;
/* 396:    */     case 65361: 
/* 397:466 */       return 203;
/* 398:    */     case 65362: 
/* 399:468 */       return 200;
/* 400:    */     case 65363: 
/* 401:470 */       return 205;
/* 402:    */     case 65364: 
/* 403:472 */       return 208;
/* 404:    */     case 65365: 
/* 405:474 */       return 201;
/* 406:    */     case 65366: 
/* 407:476 */       return 209;
/* 408:    */     case 65367: 
/* 409:478 */       return 207;
/* 410:    */     case 65387: 
/* 411:484 */       return 197;
/* 412:    */     case 65379: 
/* 413:486 */       return 210;
/* 414:    */     case 65407: 
/* 415:488 */       return 69;
/* 416:    */     case 65408: 
/* 417:493 */       return 57;
/* 418:    */     case 65417: 
/* 419:495 */       return 15;
/* 420:    */     case 65421: 
/* 421:497 */       return 156;
/* 422:    */     case 65425: 
/* 423:499 */       return 59;
/* 424:    */     case 65426: 
/* 425:501 */       return 60;
/* 426:    */     case 65427: 
/* 427:503 */       return 61;
/* 428:    */     case 65428: 
/* 429:505 */       return 62;
/* 430:    */     case 65429: 
/* 431:507 */       return 199;
/* 432:    */     case 65430: 
/* 433:509 */       return 203;
/* 434:    */     case 65431: 
/* 435:511 */       return 200;
/* 436:    */     case 65432: 
/* 437:513 */       return 205;
/* 438:    */     case 65433: 
/* 439:515 */       return 208;
/* 440:    */     case 65434: 
/* 441:517 */       return 201;
/* 442:    */     case 65435: 
/* 443:519 */       return 209;
/* 444:    */     case 65436: 
/* 445:521 */       return 207;
/* 446:    */     case 65438: 
/* 447:523 */       return 210;
/* 448:    */     case 65439: 
/* 449:525 */       return 211;
/* 450:    */     case 65469: 
/* 451:527 */       return 141;
/* 452:    */     case 65450: 
/* 453:529 */       return 55;
/* 454:    */     case 65451: 
/* 455:531 */       return 78;
/* 456:    */     case 65453: 
/* 457:533 */       return 74;
/* 458:    */     case 65454: 
/* 459:535 */       return 83;
/* 460:    */     case 65455: 
/* 461:537 */       return 181;
/* 462:    */     case 65456: 
/* 463:540 */       return 82;
/* 464:    */     case 65457: 
/* 465:542 */       return 79;
/* 466:    */     case 65458: 
/* 467:544 */       return 80;
/* 468:    */     case 65459: 
/* 469:546 */       return 81;
/* 470:    */     case 65460: 
/* 471:548 */       return 75;
/* 472:    */     case 65461: 
/* 473:550 */       return 76;
/* 474:    */     case 65462: 
/* 475:552 */       return 77;
/* 476:    */     case 65463: 
/* 477:554 */       return 71;
/* 478:    */     case 65464: 
/* 479:556 */       return 72;
/* 480:    */     case 65465: 
/* 481:558 */       return 73;
/* 482:    */     case 65470: 
/* 483:568 */       return 59;
/* 484:    */     case 65471: 
/* 485:570 */       return 60;
/* 486:    */     case 65472: 
/* 487:572 */       return 61;
/* 488:    */     case 65473: 
/* 489:574 */       return 62;
/* 490:    */     case 65474: 
/* 491:576 */       return 63;
/* 492:    */     case 65475: 
/* 493:578 */       return 64;
/* 494:    */     case 65476: 
/* 495:580 */       return 65;
/* 496:    */     case 65477: 
/* 497:582 */       return 66;
/* 498:    */     case 65478: 
/* 499:584 */       return 67;
/* 500:    */     case 65479: 
/* 501:586 */       return 68;
/* 502:    */     case 65480: 
/* 503:588 */       return 87;
/* 504:    */     case 65481: 
/* 505:590 */       return 88;
/* 506:    */     case 65482: 
/* 507:592 */       return 100;
/* 508:    */     case 65483: 
/* 509:594 */       return 101;
/* 510:    */     case 65484: 
/* 511:596 */       return 102;
/* 512:    */     case 65505: 
/* 513:601 */       return 42;
/* 514:    */     case 65506: 
/* 515:603 */       return 54;
/* 516:    */     case 65507: 
/* 517:605 */       return 29;
/* 518:    */     case 65508: 
/* 519:607 */       return 157;
/* 520:    */     case 65509: 
/* 521:609 */       return 58;
/* 522:    */     case 65511: 
/* 523:612 */       return 56;
/* 524:    */     case 65027: 
/* 525:    */     case 65512: 
/* 526:615 */       return 184;
/* 527:    */     case 65513: 
/* 528:617 */       return 56;
/* 529:    */     case 65514: 
/* 530:619 */       return 184;
/* 531:    */     case 65104: 
/* 532:622 */       return 41;
/* 533:    */     case 65106: 
/* 534:624 */       return 144;
/* 535:    */     case 32: 
/* 536:631 */       return 57;
/* 537:    */     case 39: 
/* 538:633 */       return 40;
/* 539:    */     case 44: 
/* 540:635 */       return 51;
/* 541:    */     case 45: 
/* 542:637 */       return 12;
/* 543:    */     case 46: 
/* 544:639 */       return 52;
/* 545:    */     case 47: 
/* 546:641 */       return 53;
/* 547:    */     case 48: 
/* 548:643 */       return 11;
/* 549:    */     case 49: 
/* 550:645 */       return 2;
/* 551:    */     case 50: 
/* 552:647 */       return 3;
/* 553:    */     case 51: 
/* 554:649 */       return 4;
/* 555:    */     case 52: 
/* 556:651 */       return 5;
/* 557:    */     case 53: 
/* 558:653 */       return 6;
/* 559:    */     case 54: 
/* 560:655 */       return 7;
/* 561:    */     case 55: 
/* 562:657 */       return 8;
/* 563:    */     case 56: 
/* 564:659 */       return 9;
/* 565:    */     case 57: 
/* 566:661 */       return 10;
/* 567:    */     case 58: 
/* 568:663 */       return 146;
/* 569:    */     case 59: 
/* 570:665 */       return 39;
/* 571:    */     case 61: 
/* 572:667 */       return 13;
/* 573:    */     case 64: 
/* 574:669 */       return 145;
/* 575:    */     case 91: 
/* 576:671 */       return 26;
/* 577:    */     case 93: 
/* 578:673 */       return 27;
/* 579:    */     case 94: 
/* 580:675 */       return 144;
/* 581:    */     case 95: 
/* 582:677 */       return 147;
/* 583:    */     case 96: 
/* 584:679 */       return 41;
/* 585:    */     case 65: 
/* 586:    */     case 97: 
/* 587:682 */       return 30;
/* 588:    */     case 66: 
/* 589:    */     case 98: 
/* 590:685 */       return 48;
/* 591:    */     case 67: 
/* 592:    */     case 99: 
/* 593:688 */       return 46;
/* 594:    */     case 68: 
/* 595:    */     case 100: 
/* 596:691 */       return 32;
/* 597:    */     case 69: 
/* 598:    */     case 101: 
/* 599:694 */       return 18;
/* 600:    */     case 70: 
/* 601:    */     case 102: 
/* 602:697 */       return 33;
/* 603:    */     case 71: 
/* 604:    */     case 103: 
/* 605:700 */       return 34;
/* 606:    */     case 72: 
/* 607:    */     case 104: 
/* 608:703 */       return 35;
/* 609:    */     case 73: 
/* 610:    */     case 105: 
/* 611:706 */       return 23;
/* 612:    */     case 74: 
/* 613:    */     case 106: 
/* 614:709 */       return 36;
/* 615:    */     case 75: 
/* 616:    */     case 107: 
/* 617:712 */       return 37;
/* 618:    */     case 76: 
/* 619:    */     case 108: 
/* 620:715 */       return 38;
/* 621:    */     case 77: 
/* 622:    */     case 109: 
/* 623:718 */       return 50;
/* 624:    */     case 78: 
/* 625:    */     case 110: 
/* 626:721 */       return 49;
/* 627:    */     case 79: 
/* 628:    */     case 111: 
/* 629:724 */       return 24;
/* 630:    */     case 80: 
/* 631:    */     case 112: 
/* 632:727 */       return 25;
/* 633:    */     case 81: 
/* 634:    */     case 113: 
/* 635:730 */       return 16;
/* 636:    */     case 82: 
/* 637:    */     case 114: 
/* 638:733 */       return 19;
/* 639:    */     case 83: 
/* 640:    */     case 115: 
/* 641:736 */       return 31;
/* 642:    */     case 84: 
/* 643:    */     case 116: 
/* 644:739 */       return 20;
/* 645:    */     case 85: 
/* 646:    */     case 117: 
/* 647:742 */       return 22;
/* 648:    */     case 86: 
/* 649:    */     case 118: 
/* 650:745 */       return 47;
/* 651:    */     case 87: 
/* 652:    */     case 119: 
/* 653:748 */       return 17;
/* 654:    */     case 88: 
/* 655:    */     case 120: 
/* 656:751 */       return 45;
/* 657:    */     case 89: 
/* 658:    */     case 121: 
/* 659:754 */       return 21;
/* 660:    */     case 90: 
/* 661:    */     case 122: 
/* 662:757 */       return 44;
/* 663:    */     }
/* 664:759 */     return 0;
/* 665:    */   }
/* 666:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxKeycodes
 * JD-Core Version:    0.7.0.1
 */