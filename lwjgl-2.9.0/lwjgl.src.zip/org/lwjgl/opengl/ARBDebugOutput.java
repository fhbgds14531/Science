/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class ARBDebugOutput
/*   9:    */ {
/*  10:    */   public static final int GL_DEBUG_OUTPUT_SYNCHRONOUS_ARB = 33346;
/*  11:    */   public static final int GL_MAX_DEBUG_MESSAGE_LENGTH_ARB = 37187;
/*  12:    */   public static final int GL_MAX_DEBUG_LOGGED_MESSAGES_ARB = 37188;
/*  13:    */   public static final int GL_DEBUG_LOGGED_MESSAGES_ARB = 37189;
/*  14:    */   public static final int GL_DEBUG_NEXT_LOGGED_MESSAGE_LENGTH_ARB = 33347;
/*  15:    */   public static final int GL_DEBUG_CALLBACK_FUNCTION_ARB = 33348;
/*  16:    */   public static final int GL_DEBUG_CALLBACK_USER_PARAM_ARB = 33349;
/*  17:    */   public static final int GL_DEBUG_SOURCE_API_ARB = 33350;
/*  18:    */   public static final int GL_DEBUG_SOURCE_WINDOW_SYSTEM_ARB = 33351;
/*  19:    */   public static final int GL_DEBUG_SOURCE_SHADER_COMPILER_ARB = 33352;
/*  20:    */   public static final int GL_DEBUG_SOURCE_THIRD_PARTY_ARB = 33353;
/*  21:    */   public static final int GL_DEBUG_SOURCE_APPLICATION_ARB = 33354;
/*  22:    */   public static final int GL_DEBUG_SOURCE_OTHER_ARB = 33355;
/*  23:    */   public static final int GL_DEBUG_TYPE_ERROR_ARB = 33356;
/*  24:    */   public static final int GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR_ARB = 33357;
/*  25:    */   public static final int GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR_ARB = 33358;
/*  26:    */   public static final int GL_DEBUG_TYPE_PORTABILITY_ARB = 33359;
/*  27:    */   public static final int GL_DEBUG_TYPE_PERFORMANCE_ARB = 33360;
/*  28:    */   public static final int GL_DEBUG_TYPE_OTHER_ARB = 33361;
/*  29:    */   public static final int GL_DEBUG_SEVERITY_HIGH_ARB = 37190;
/*  30:    */   public static final int GL_DEBUG_SEVERITY_MEDIUM_ARB = 37191;
/*  31:    */   public static final int GL_DEBUG_SEVERITY_LOW_ARB = 37192;
/*  32:    */   
/*  33:    */   public static void glDebugMessageControlARB(int source, int type, int severity, IntBuffer ids, boolean enabled)
/*  34:    */   {
/*  35: 68 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 69 */     long function_pointer = caps.glDebugMessageControlARB;
/*  37: 70 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 71 */     if (ids != null) {
/*  39: 72 */       BufferChecks.checkDirect(ids);
/*  40:    */     }
/*  41: 73 */     nglDebugMessageControlARB(source, type, severity, ids == null ? 0 : ids.remaining(), MemoryUtil.getAddressSafe(ids), enabled, function_pointer);
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native void nglDebugMessageControlARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, boolean paramBoolean, long paramLong2);
/*  45:    */   
/*  46:    */   public static void glDebugMessageInsertARB(int source, int type, int id, int severity, ByteBuffer buf)
/*  47:    */   {
/*  48: 78 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  49: 79 */     long function_pointer = caps.glDebugMessageInsertARB;
/*  50: 80 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  51: 81 */     BufferChecks.checkDirect(buf);
/*  52: 82 */     nglDebugMessageInsertARB(source, type, id, severity, buf.remaining(), MemoryUtil.getAddress(buf), function_pointer);
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native void nglDebugMessageInsertARB(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/*  56:    */   
/*  57:    */   public static void glDebugMessageInsertARB(int source, int type, int id, int severity, CharSequence buf)
/*  58:    */   {
/*  59: 88 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 89 */     long function_pointer = caps.glDebugMessageInsertARB;
/*  61: 90 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 91 */     nglDebugMessageInsertARB(source, type, id, severity, buf.length(), APIUtil.getBuffer(caps, buf), function_pointer);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static void glDebugMessageCallbackARB(ARBDebugOutputCallback callback)
/*  66:    */   {
/*  67:102 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  68:103 */     long function_pointer = caps.glDebugMessageCallbackARB;
/*  69:104 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  70:105 */     long userParam = callback == null ? 0L : CallbackUtil.createGlobalRef(callback.getHandler());
/*  71:106 */     CallbackUtil.registerContextCallbackARB(userParam);
/*  72:107 */     nglDebugMessageCallbackARB(callback == null ? 0L : callback.getPointer(), userParam, function_pointer);
/*  73:    */   }
/*  74:    */   
/*  75:    */   static native void nglDebugMessageCallbackARB(long paramLong1, long paramLong2, long paramLong3);
/*  76:    */   
/*  77:    */   public static int glGetDebugMessageLogARB(int count, IntBuffer sources, IntBuffer types, IntBuffer ids, IntBuffer severities, IntBuffer lengths, ByteBuffer messageLog)
/*  78:    */   {
/*  79:112 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  80:113 */     long function_pointer = caps.glGetDebugMessageLogARB;
/*  81:114 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  82:115 */     if (sources != null) {
/*  83:116 */       BufferChecks.checkBuffer(sources, count);
/*  84:    */     }
/*  85:117 */     if (types != null) {
/*  86:118 */       BufferChecks.checkBuffer(types, count);
/*  87:    */     }
/*  88:119 */     if (ids != null) {
/*  89:120 */       BufferChecks.checkBuffer(ids, count);
/*  90:    */     }
/*  91:121 */     if (severities != null) {
/*  92:122 */       BufferChecks.checkBuffer(severities, count);
/*  93:    */     }
/*  94:123 */     if (lengths != null) {
/*  95:124 */       BufferChecks.checkBuffer(lengths, count);
/*  96:    */     }
/*  97:125 */     if (messageLog != null) {
/*  98:126 */       BufferChecks.checkDirect(messageLog);
/*  99:    */     }
/* 100:127 */     int __result = nglGetDebugMessageLogARB(count, messageLog == null ? 0 : messageLog.remaining(), MemoryUtil.getAddressSafe(sources), MemoryUtil.getAddressSafe(types), MemoryUtil.getAddressSafe(ids), MemoryUtil.getAddressSafe(severities), MemoryUtil.getAddressSafe(lengths), MemoryUtil.getAddressSafe(messageLog), function_pointer);
/* 101:128 */     return __result;
/* 102:    */   }
/* 103:    */   
/* 104:    */   static native int nglGetDebugMessageLogARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/* 105:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDebugOutput
 * JD-Core Version:    0.7.0.1
 */