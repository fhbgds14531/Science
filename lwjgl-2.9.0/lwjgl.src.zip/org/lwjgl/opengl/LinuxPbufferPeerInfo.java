/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class LinuxPbufferPeerInfo
/*  7:   */   extends LinuxPeerInfo
/*  8:   */ {
/*  9:   */   LinuxPbufferPeerInfo(int width, int height, PixelFormat pixel_format)
/* 10:   */     throws LWJGLException
/* 11:   */   {
/* 12:46 */     LinuxDisplay.lockAWT();
/* 13:   */     try
/* 14:   */     {
/* 15:48 */       GLContext.loadOpenGLLibrary();
/* 16:   */       try
/* 17:   */       {
/* 18:50 */         LinuxDisplay.incDisplay();
/* 19:   */         try
/* 20:   */         {
/* 21:52 */           nInitHandle(LinuxDisplay.getDisplay(), LinuxDisplay.getDefaultScreen(), getHandle(), width, height, pixel_format);
/* 22:   */         }
/* 23:   */         catch (LWJGLException e)
/* 24:   */         {
/* 25:55 */           throw e;
/* 26:   */         }
/* 27:   */       }
/* 28:   */       catch (LWJGLException e)
/* 29:   */       {
/* 30:59 */         throw e;
/* 31:   */       }
/* 32:   */     }
/* 33:   */     finally
/* 34:   */     {
/* 35:62 */       LinuxDisplay.unlockAWT();
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   private static native void nInitHandle(long paramLong, int paramInt1, ByteBuffer paramByteBuffer, int paramInt2, int paramInt3, PixelFormat paramPixelFormat)
/* 40:   */     throws LWJGLException;
/* 41:   */   
/* 42:   */   public void destroy()
/* 43:   */   {
/* 44:68 */     LinuxDisplay.lockAWT();
/* 45:69 */     nDestroy(getHandle());
/* 46:70 */     LinuxDisplay.decDisplay();
/* 47:71 */     GLContext.unloadOpenGLLibrary();
/* 48:72 */     LinuxDisplay.unlockAWT();
/* 49:   */   }
/* 50:   */   
/* 51:   */   private static native void nDestroy(ByteBuffer paramByteBuffer);
/* 52:   */   
/* 53:   */   protected void doLockAndInitHandle()
/* 54:   */     throws LWJGLException
/* 55:   */   {}
/* 56:   */   
/* 57:   */   protected void doUnlock()
/* 58:   */     throws LWJGLException
/* 59:   */   {}
/* 60:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxPbufferPeerInfo
 * JD-Core Version:    0.7.0.1
 */