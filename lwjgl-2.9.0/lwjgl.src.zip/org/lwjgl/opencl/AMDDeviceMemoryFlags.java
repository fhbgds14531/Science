package org.lwjgl.opencl;

public final class AMDDeviceMemoryFlags
{
  public static final int CL_MEM_USE_PERSISTENT_MEM_AMD = 64;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.AMDDeviceMemoryFlags
 * JD-Core Version:    0.7.0.1
 */