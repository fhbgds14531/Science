/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class NVPointSprite
/*  8:   */ {
/*  9:   */   public static final int GL_POINT_SPRITE_NV = 34913;
/* 10:   */   public static final int GL_COORD_REPLACE_NV = 34914;
/* 11:   */   public static final int GL_POINT_SPRITE_R_MODE_NV = 34915;
/* 12:   */   
/* 13:   */   public static void glPointParameteriNV(int pname, int param)
/* 14:   */   {
/* 15:17 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 16:18 */     long function_pointer = caps.glPointParameteriNV;
/* 17:19 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 18:20 */     nglPointParameteriNV(pname, param, function_pointer);
/* 19:   */   }
/* 20:   */   
/* 21:   */   static native void nglPointParameteriNV(int paramInt1, int paramInt2, long paramLong);
/* 22:   */   
/* 23:   */   public static void glPointParameterNV(int pname, IntBuffer params)
/* 24:   */   {
/* 25:25 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 26:26 */     long function_pointer = caps.glPointParameterivNV;
/* 27:27 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 28:28 */     BufferChecks.checkBuffer(params, 4);
/* 29:29 */     nglPointParameterivNV(pname, MemoryUtil.getAddress(params), function_pointer);
/* 30:   */   }
/* 31:   */   
/* 32:   */   static native void nglPointParameterivNV(int paramInt, long paramLong1, long paramLong2);
/* 33:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPointSprite
 * JD-Core Version:    0.7.0.1
 */