/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferUtils;
/*   6:    */ import org.lwjgl.LWJGLException;
/*   7:    */ 
/*   8:    */ final class LinuxMouse
/*   9:    */ {
/*  10:    */   private static final int POINTER_WARP_BORDER = 10;
/*  11:    */   private static final int WHEEL_SCALE = 120;
/*  12:    */   private int button_count;
/*  13:    */   private static final int Button1 = 1;
/*  14:    */   private static final int Button2 = 2;
/*  15:    */   private static final int Button3 = 3;
/*  16:    */   private static final int Button4 = 4;
/*  17:    */   private static final int Button5 = 5;
/*  18:    */   private static final int Button6 = 6;
/*  19:    */   private static final int Button7 = 7;
/*  20:    */   private static final int Button8 = 8;
/*  21:    */   private static final int Button9 = 9;
/*  22:    */   private static final int ButtonPress = 4;
/*  23:    */   private static final int ButtonRelease = 5;
/*  24:    */   private final long display;
/*  25:    */   private final long window;
/*  26:    */   private final long input_window;
/*  27:    */   private final long warp_atom;
/*  28: 71 */   private final IntBuffer query_pointer_buffer = BufferUtils.createIntBuffer(4);
/*  29: 72 */   private final ByteBuffer event_buffer = ByteBuffer.allocate(22);
/*  30:    */   private int last_x;
/*  31:    */   private int last_y;
/*  32:    */   private int accum_dx;
/*  33:    */   private int accum_dy;
/*  34:    */   private int accum_dz;
/*  35:    */   private byte[] buttons;
/*  36:    */   private EventQueue event_queue;
/*  37:    */   private long last_event_nanos;
/*  38:    */   
/*  39:    */   LinuxMouse(long display, long window, long input_window)
/*  40:    */     throws LWJGLException
/*  41:    */   {
/*  42: 84 */     this.display = display;
/*  43: 85 */     this.window = window;
/*  44: 86 */     this.input_window = input_window;
/*  45: 87 */     this.warp_atom = LinuxDisplay.nInternAtom(display, "_LWJGL", false);
/*  46: 88 */     this.button_count = nGetButtonCount(display);
/*  47: 89 */     this.buttons = new byte[this.button_count];
/*  48: 90 */     reset(false, false);
/*  49:    */   }
/*  50:    */   
/*  51:    */   private void reset(boolean grab, boolean warp_pointer)
/*  52:    */   {
/*  53: 94 */     this.event_queue = new EventQueue(this.event_buffer.capacity());
/*  54: 95 */     this.accum_dx = (this.accum_dy = 0);
/*  55: 96 */     long root_window = nQueryPointer(this.display, this.window, this.query_pointer_buffer);
/*  56:    */     
/*  57: 98 */     int root_x = this.query_pointer_buffer.get(0);
/*  58: 99 */     int root_y = this.query_pointer_buffer.get(1);
/*  59:100 */     int win_x = this.query_pointer_buffer.get(2);
/*  60:101 */     int win_y = this.query_pointer_buffer.get(3);
/*  61:    */     
/*  62:103 */     this.last_x = win_x;
/*  63:104 */     this.last_y = transformY(win_y);
/*  64:105 */     doHandlePointerMotion(grab, warp_pointer, root_window, root_x, root_y, win_x, win_y, this.last_event_nanos);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void read(ByteBuffer buffer)
/*  68:    */   {
/*  69:109 */     this.event_queue.copyEvents(buffer);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void poll(boolean grab, IntBuffer coord_buffer, ByteBuffer buttons_buffer)
/*  73:    */   {
/*  74:113 */     if (grab)
/*  75:    */     {
/*  76:114 */       coord_buffer.put(0, this.accum_dx);
/*  77:115 */       coord_buffer.put(1, this.accum_dy);
/*  78:    */     }
/*  79:    */     else
/*  80:    */     {
/*  81:117 */       coord_buffer.put(0, this.last_x);
/*  82:118 */       coord_buffer.put(1, this.last_y);
/*  83:    */     }
/*  84:120 */     coord_buffer.put(2, this.accum_dz);
/*  85:121 */     this.accum_dx = (this.accum_dy = this.accum_dz = 0);
/*  86:122 */     for (int i = 0; i < this.buttons.length; i++) {
/*  87:123 */       buttons_buffer.put(i, this.buttons[i]);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   private void putMouseEventWithCoords(byte button, byte state, int coord1, int coord2, int dz, long nanos)
/*  92:    */   {
/*  93:127 */     this.event_buffer.clear();
/*  94:128 */     this.event_buffer.put(button).put(state).putInt(coord1).putInt(coord2).putInt(dz).putLong(nanos);
/*  95:129 */     this.event_buffer.flip();
/*  96:130 */     this.event_queue.putEvent(this.event_buffer);
/*  97:131 */     this.last_event_nanos = nanos;
/*  98:    */   }
/*  99:    */   
/* 100:    */   private void setCursorPos(boolean grab, int x, int y, long nanos)
/* 101:    */   {
/* 102:135 */     y = transformY(y);
/* 103:136 */     int dx = x - this.last_x;
/* 104:137 */     int dy = y - this.last_y;
/* 105:138 */     if ((dx != 0) || (dy != 0))
/* 106:    */     {
/* 107:139 */       this.accum_dx += dx;
/* 108:140 */       this.accum_dy += dy;
/* 109:141 */       this.last_x = x;
/* 110:142 */       this.last_y = y;
/* 111:143 */       if (grab) {
/* 112:144 */         putMouseEventWithCoords((byte)-1, (byte)0, dx, dy, 0, nanos);
/* 113:    */       } else {
/* 114:146 */         putMouseEventWithCoords((byte)-1, (byte)0, x, y, 0, nanos);
/* 115:    */       }
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   private void doWarpPointer(int center_x, int center_y)
/* 120:    */   {
/* 121:152 */     nSendWarpEvent(this.display, this.input_window, this.warp_atom, center_x, center_y);
/* 122:153 */     nWarpCursor(this.display, this.window, center_x, center_y);
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static native void nSendWarpEvent(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2);
/* 126:    */   
/* 127:    */   private void doHandlePointerMotion(boolean grab, boolean warp_pointer, long root_window, int root_x, int root_y, int win_x, int win_y, long nanos)
/* 128:    */   {
/* 129:158 */     setCursorPos(grab, win_x, win_y, nanos);
/* 130:159 */     if (!warp_pointer) {
/* 131:160 */       return;
/* 132:    */     }
/* 133:161 */     int root_window_height = nGetWindowHeight(this.display, root_window);
/* 134:162 */     int root_window_width = nGetWindowWidth(this.display, root_window);
/* 135:163 */     int window_height = nGetWindowHeight(this.display, this.window);
/* 136:164 */     int window_width = nGetWindowWidth(this.display, this.window);
/* 137:    */     
/* 138:    */ 
/* 139:167 */     int win_left = root_x - win_x;
/* 140:168 */     int win_top = root_y - win_y;
/* 141:169 */     int win_right = win_left + window_width;
/* 142:170 */     int win_bottom = win_top + window_height;
/* 143:    */     
/* 144:172 */     int border_left = Math.max(0, win_left);
/* 145:173 */     int border_top = Math.max(0, win_top);
/* 146:174 */     int border_right = Math.min(root_window_width, win_right);
/* 147:175 */     int border_bottom = Math.min(root_window_height, win_bottom);
/* 148:    */     
/* 149:177 */     boolean outside_limits = (root_x < border_left + 10) || (root_y < border_top + 10) || (root_x > border_right - 10) || (root_y > border_bottom - 10);
/* 150:179 */     if (outside_limits)
/* 151:    */     {
/* 152:181 */       int center_x = (border_right - border_left) / 2;
/* 153:182 */       int center_y = (border_bottom - border_top) / 2;
/* 154:183 */       doWarpPointer(center_x, center_y);
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void changeGrabbed(boolean grab, boolean warp_pointer)
/* 159:    */   {
/* 160:188 */     reset(grab, warp_pointer);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public int getButtonCount()
/* 164:    */   {
/* 165:192 */     return this.buttons.length;
/* 166:    */   }
/* 167:    */   
/* 168:    */   private int transformY(int y)
/* 169:    */   {
/* 170:196 */     return nGetWindowHeight(this.display, this.window) - 1 - y;
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static native int nGetWindowHeight(long paramLong1, long paramLong2);
/* 174:    */   
/* 175:    */   private static native int nGetWindowWidth(long paramLong1, long paramLong2);
/* 176:    */   
/* 177:    */   private static native int nGetButtonCount(long paramLong);
/* 178:    */   
/* 179:    */   private static native long nQueryPointer(long paramLong1, long paramLong2, IntBuffer paramIntBuffer);
/* 180:    */   
/* 181:    */   public void setCursorPosition(int x, int y)
/* 182:    */   {
/* 183:206 */     nWarpCursor(this.display, this.window, x, transformY(y));
/* 184:    */   }
/* 185:    */   
/* 186:    */   private static native void nWarpCursor(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/* 187:    */   
/* 188:    */   private void handlePointerMotion(boolean grab, boolean warp_pointer, long millis, long root_window, int x_root, int y_root, int x, int y)
/* 189:    */   {
/* 190:211 */     doHandlePointerMotion(grab, warp_pointer, root_window, x_root, y_root, x, y, millis * 1000000L);
/* 191:    */   }
/* 192:    */   
/* 193:    */   private void handleButton(boolean grab, int button, byte state, long nanos)
/* 194:    */   {
/* 195:    */     byte button_num;
/* 196:216 */     switch (button)
/* 197:    */     {
/* 198:    */     case 1: 
/* 199:218 */       button_num = 0;
/* 200:219 */       break;
/* 201:    */     case 2: 
/* 202:221 */       button_num = 2;
/* 203:222 */       break;
/* 204:    */     case 3: 
/* 205:224 */       button_num = 1;
/* 206:225 */       break;
/* 207:    */     case 6: 
/* 208:227 */       button_num = 5;
/* 209:228 */       break;
/* 210:    */     case 7: 
/* 211:230 */       button_num = 6;
/* 212:231 */       break;
/* 213:    */     case 8: 
/* 214:233 */       button_num = 3;
/* 215:234 */       break;
/* 216:    */     case 9: 
/* 217:236 */       button_num = 4;
/* 218:237 */       break;
/* 219:    */     case 4: 
/* 220:    */     case 5: 
/* 221:    */     default: 
/* 222:239 */       if ((button > 9) && (button <= this.button_count)) {
/* 223:240 */         button_num = (byte)(button - 1);
/* 224:    */       } else {
/* 225:    */         return;
/* 226:    */       }
/* 227:    */       break;
/* 228:    */     }
/* 229:    */     byte button_num;
/* 230:245 */     this.buttons[button_num] = state;
/* 231:246 */     putMouseEvent(grab, button_num, state, 0, nanos);
/* 232:    */   }
/* 233:    */   
/* 234:    */   private void putMouseEvent(boolean grab, byte button, byte state, int dz, long nanos)
/* 235:    */   {
/* 236:250 */     if (grab) {
/* 237:251 */       putMouseEventWithCoords(button, state, 0, 0, dz, nanos);
/* 238:    */     } else {
/* 239:253 */       putMouseEventWithCoords(button, state, this.last_x, this.last_y, dz, nanos);
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   private void handleButtonPress(boolean grab, byte button, long nanos)
/* 244:    */   {
/* 245:257 */     int delta = 0;
/* 246:258 */     switch (button)
/* 247:    */     {
/* 248:    */     case 4: 
/* 249:260 */       delta = 120;
/* 250:261 */       putMouseEvent(grab, (byte)-1, (byte)0, delta, nanos);
/* 251:262 */       this.accum_dz += delta;
/* 252:263 */       break;
/* 253:    */     case 5: 
/* 254:265 */       delta = -120;
/* 255:266 */       putMouseEvent(grab, (byte)-1, (byte)0, delta, nanos);
/* 256:267 */       this.accum_dz += delta;
/* 257:268 */       break;
/* 258:    */     default: 
/* 259:270 */       handleButton(grab, button, (byte)1, nanos);
/* 260:    */     }
/* 261:    */   }
/* 262:    */   
/* 263:    */   private void handleButtonEvent(boolean grab, long millis, int type, byte button)
/* 264:    */   {
/* 265:276 */     long nanos = millis * 1000000L;
/* 266:277 */     switch (type)
/* 267:    */     {
/* 268:    */     case 5: 
/* 269:279 */       handleButton(grab, button, (byte)0, nanos);
/* 270:280 */       break;
/* 271:    */     case 4: 
/* 272:282 */       handleButtonPress(grab, button, nanos);
/* 273:283 */       break;
/* 274:    */     }
/* 275:    */   }
/* 276:    */   
/* 277:    */   private void resetCursor(int x, int y)
/* 278:    */   {
/* 279:290 */     this.last_x = x;
/* 280:291 */     this.last_y = transformY(y);
/* 281:    */   }
/* 282:    */   
/* 283:    */   private void handleWarpEvent(int x, int y)
/* 284:    */   {
/* 285:295 */     resetCursor(x, y);
/* 286:    */   }
/* 287:    */   
/* 288:    */   public boolean filterEvent(boolean grab, boolean warp_pointer, LinuxEvent event)
/* 289:    */   {
/* 290:299 */     switch (event.getType())
/* 291:    */     {
/* 292:    */     case 33: 
/* 293:301 */       if (event.getClientMessageType() == this.warp_atom)
/* 294:    */       {
/* 295:302 */         handleWarpEvent(event.getClientData(0), event.getClientData(1));
/* 296:303 */         return true;
/* 297:    */       }
/* 298:    */       break;
/* 299:    */     case 4: 
/* 300:    */     case 5: 
/* 301:308 */       handleButtonEvent(grab, event.getButtonTime(), event.getButtonType(), (byte)event.getButtonButton());
/* 302:309 */       return true;
/* 303:    */     case 6: 
/* 304:311 */       handlePointerMotion(grab, warp_pointer, event.getButtonTime(), event.getButtonRoot(), event.getButtonXRoot(), event.getButtonYRoot(), event.getButtonX(), event.getButtonY());
/* 305:312 */       return true;
/* 306:    */     }
/* 307:316 */     return false;
/* 308:    */   }
/* 309:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxMouse
 * JD-Core Version:    0.7.0.1
 */