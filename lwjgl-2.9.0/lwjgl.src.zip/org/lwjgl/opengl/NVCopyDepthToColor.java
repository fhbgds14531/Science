package org.lwjgl.opengl;

public final class NVCopyDepthToColor
{
  public static final int GL_DEPTH_STENCIL_TO_RGBA_NV = 34926;
  public static final int GL_DEPTH_STENCIL_TO_BGRA_NV = 34927;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVCopyDepthToColor
 * JD-Core Version:    0.7.0.1
 */