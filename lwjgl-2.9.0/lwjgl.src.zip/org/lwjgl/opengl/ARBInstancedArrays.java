/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBInstancedArrays
/*  6:   */ {
/*  7:   */   public static final int GL_VERTEX_ATTRIB_ARRAY_DIVISOR_ARB = 35070;
/*  8:   */   
/*  9:   */   public static void glVertexAttribDivisorARB(int index, int divisor)
/* 10:   */   {
/* 11:19 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 12:20 */     long function_pointer = caps.glVertexAttribDivisorARB;
/* 13:21 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 14:22 */     nglVertexAttribDivisorARB(index, divisor, function_pointer);
/* 15:   */   }
/* 16:   */   
/* 17:   */   static native void nglVertexAttribDivisorARB(int paramInt1, int paramInt2, long paramLong);
/* 18:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBInstancedArrays
 * JD-Core Version:    0.7.0.1
 */