package org.lwjgl.opengl;

public final class ARBTextureCompressionBPTC
{
  public static final int GL_COMPRESSED_RGBA_BPTC_UNORM_ARB = 36492;
  public static final int GL_COMPRESSED_SRGB_ALPHA_BPTC_UNORM_ARB = 36493;
  public static final int GL_COMPRESSED_RGB_BPTC_SIGNED_FLOAT_ARB = 36494;
  public static final int GL_COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_ARB = 36495;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureCompressionBPTC
 * JD-Core Version:    0.7.0.1
 */