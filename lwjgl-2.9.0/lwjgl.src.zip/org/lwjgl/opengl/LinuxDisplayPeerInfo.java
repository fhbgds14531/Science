/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.LWJGLException;
/*  5:   */ 
/*  6:   */ final class LinuxDisplayPeerInfo
/*  7:   */   extends LinuxPeerInfo
/*  8:   */ {
/*  9:   */   final boolean egl;
/* 10:   */   
/* 11:   */   LinuxDisplayPeerInfo()
/* 12:   */     throws LWJGLException
/* 13:   */   {
/* 14:49 */     this.egl = true;
/* 15:50 */     org.lwjgl.opengles.GLContext.loadOpenGLLibrary();
/* 16:   */   }
/* 17:   */   
/* 18:   */   LinuxDisplayPeerInfo(PixelFormat pixel_format)
/* 19:   */     throws LWJGLException
/* 20:   */   {
/* 21:54 */     this.egl = false;
/* 22:55 */     LinuxDisplay.lockAWT();
/* 23:   */     try
/* 24:   */     {
/* 25:57 */       GLContext.loadOpenGLLibrary();
/* 26:   */       try
/* 27:   */       {
/* 28:59 */         LinuxDisplay.incDisplay();
/* 29:   */         try
/* 30:   */         {
/* 31:61 */           initDefaultPeerInfo(LinuxDisplay.getDisplay(), LinuxDisplay.getDefaultScreen(), getHandle(), pixel_format);
/* 32:   */         }
/* 33:   */         catch (LWJGLException e)
/* 34:   */         {
/* 35:64 */           throw e;
/* 36:   */         }
/* 37:   */       }
/* 38:   */       catch (LWJGLException e)
/* 39:   */       {
/* 40:68 */         throw e;
/* 41:   */       }
/* 42:   */     }
/* 43:   */     finally
/* 44:   */     {
/* 45:71 */       LinuxDisplay.unlockAWT();
/* 46:   */     }
/* 47:   */   }
/* 48:   */   
/* 49:   */   private static native void initDefaultPeerInfo(long paramLong, int paramInt, ByteBuffer paramByteBuffer, PixelFormat paramPixelFormat)
/* 50:   */     throws LWJGLException;
/* 51:   */   
/* 52:   */   protected void doLockAndInitHandle()
/* 53:   */     throws LWJGLException
/* 54:   */   {
/* 55:   */     
/* 56:   */     try
/* 57:   */     {
/* 58:79 */       initDrawable(LinuxDisplay.getWindow(), getHandle());
/* 59:   */     }
/* 60:   */     finally
/* 61:   */     {
/* 62:81 */       LinuxDisplay.unlockAWT();
/* 63:   */     }
/* 64:   */   }
/* 65:   */   
/* 66:   */   private static native void initDrawable(long paramLong, ByteBuffer paramByteBuffer);
/* 67:   */   
/* 68:   */   protected void doUnlock()
/* 69:   */     throws LWJGLException
/* 70:   */   {}
/* 71:   */   
/* 72:   */   public void destroy()
/* 73:   */   {
/* 74:91 */     super.destroy();
/* 75:93 */     if (this.egl)
/* 76:   */     {
/* 77:94 */       org.lwjgl.opengles.GLContext.unloadOpenGLLibrary();
/* 78:   */     }
/* 79:   */     else
/* 80:   */     {
/* 81:96 */       LinuxDisplay.lockAWT();
/* 82:97 */       LinuxDisplay.decDisplay();
/* 83:98 */       GLContext.unloadOpenGLLibrary();
/* 84:99 */       LinuxDisplay.unlockAWT();
/* 85:   */     }
/* 86:   */   }
/* 87:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxDisplayPeerInfo
 * JD-Core Version:    0.7.0.1
 */