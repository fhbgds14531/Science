/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.LWJGLUtil;
/*  8:   */ import org.lwjgl.MemoryUtil;
/*  9:   */ 
/* 10:   */ public final class ARBMatrixPalette
/* 11:   */ {
/* 12:   */   public static final int GL_MATRIX_PALETTE_ARB = 34880;
/* 13:   */   public static final int GL_MAX_MATRIX_PALETTE_STACK_DEPTH_ARB = 34881;
/* 14:   */   public static final int GL_MAX_PALETTE_MATRICES_ARB = 34882;
/* 15:   */   public static final int GL_CURRENT_PALETTE_MATRIX_ARB = 34883;
/* 16:   */   public static final int GL_MATRIX_INDEX_ARRAY_ARB = 34884;
/* 17:   */   public static final int GL_CURRENT_MATRIX_INDEX_ARB = 34885;
/* 18:   */   public static final int GL_MATRIX_INDEX_ARRAY_SIZE_ARB = 34886;
/* 19:   */   public static final int GL_MATRIX_INDEX_ARRAY_TYPE_ARB = 34887;
/* 20:   */   public static final int GL_MATRIX_INDEX_ARRAY_STRIDE_ARB = 34888;
/* 21:   */   public static final int GL_MATRIX_INDEX_ARRAY_POINTER_ARB = 34889;
/* 22:   */   
/* 23:   */   public static void glCurrentPaletteMatrixARB(int index)
/* 24:   */   {
/* 25:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 26:25 */     long function_pointer = caps.glCurrentPaletteMatrixARB;
/* 27:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 28:27 */     nglCurrentPaletteMatrixARB(index, function_pointer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   static native void nglCurrentPaletteMatrixARB(int paramInt, long paramLong);
/* 32:   */   
/* 33:   */   public static void glMatrixIndexPointerARB(int size, int stride, ByteBuffer pPointer)
/* 34:   */   {
/* 35:32 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 36:33 */     long function_pointer = caps.glMatrixIndexPointerARB;
/* 37:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 38:35 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 39:36 */     BufferChecks.checkDirect(pPointer);
/* 40:37 */     if (LWJGLUtil.CHECKS) {
/* 41:37 */       StateTracker.getReferences(caps).ARB_matrix_palette_glMatrixIndexPointerARB_pPointer = pPointer;
/* 42:   */     }
/* 43:38 */     nglMatrixIndexPointerARB(size, 5121, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 44:   */   }
/* 45:   */   
/* 46:   */   public static void glMatrixIndexPointerARB(int size, int stride, IntBuffer pPointer)
/* 47:   */   {
/* 48:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 49:42 */     long function_pointer = caps.glMatrixIndexPointerARB;
/* 50:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 51:44 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 52:45 */     BufferChecks.checkDirect(pPointer);
/* 53:46 */     if (LWJGLUtil.CHECKS) {
/* 54:46 */       StateTracker.getReferences(caps).ARB_matrix_palette_glMatrixIndexPointerARB_pPointer = pPointer;
/* 55:   */     }
/* 56:47 */     nglMatrixIndexPointerARB(size, 5125, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 57:   */   }
/* 58:   */   
/* 59:   */   public static void glMatrixIndexPointerARB(int size, int stride, ShortBuffer pPointer)
/* 60:   */   {
/* 61:50 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 62:51 */     long function_pointer = caps.glMatrixIndexPointerARB;
/* 63:52 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 64:53 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 65:54 */     BufferChecks.checkDirect(pPointer);
/* 66:55 */     if (LWJGLUtil.CHECKS) {
/* 67:55 */       StateTracker.getReferences(caps).ARB_matrix_palette_glMatrixIndexPointerARB_pPointer = pPointer;
/* 68:   */     }
/* 69:56 */     nglMatrixIndexPointerARB(size, 5123, stride, MemoryUtil.getAddress(pPointer), function_pointer);
/* 70:   */   }
/* 71:   */   
/* 72:   */   static native void nglMatrixIndexPointerARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 73:   */   
/* 74:   */   public static void glMatrixIndexPointerARB(int size, int type, int stride, long pPointer_buffer_offset)
/* 75:   */   {
/* 76:60 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 77:61 */     long function_pointer = caps.glMatrixIndexPointerARB;
/* 78:62 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 79:63 */     GLChecks.ensureArrayVBOenabled(caps);
/* 80:64 */     nglMatrixIndexPointerARBBO(size, type, stride, pPointer_buffer_offset, function_pointer);
/* 81:   */   }
/* 82:   */   
/* 83:   */   static native void nglMatrixIndexPointerARBBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 84:   */   
/* 85:   */   public static void glMatrixIndexuARB(ByteBuffer pIndices)
/* 86:   */   {
/* 87:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 88:70 */     long function_pointer = caps.glMatrixIndexubvARB;
/* 89:71 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 90:72 */     BufferChecks.checkDirect(pIndices);
/* 91:73 */     nglMatrixIndexubvARB(pIndices.remaining(), MemoryUtil.getAddress(pIndices), function_pointer);
/* 92:   */   }
/* 93:   */   
/* 94:   */   static native void nglMatrixIndexubvARB(int paramInt, long paramLong1, long paramLong2);
/* 95:   */   
/* 96:   */   public static void glMatrixIndexuARB(ShortBuffer pIndices)
/* 97:   */   {
/* 98:78 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 99:79 */     long function_pointer = caps.glMatrixIndexusvARB;
/* :0:80 */     BufferChecks.checkFunctionAddress(function_pointer);
/* :1:81 */     BufferChecks.checkDirect(pIndices);
/* :2:82 */     nglMatrixIndexusvARB(pIndices.remaining(), MemoryUtil.getAddress(pIndices), function_pointer);
/* :3:   */   }
/* :4:   */   
/* :5:   */   static native void nglMatrixIndexusvARB(int paramInt, long paramLong1, long paramLong2);
/* :6:   */   
/* :7:   */   public static void glMatrixIndexuARB(IntBuffer pIndices)
/* :8:   */   {
/* :9:87 */     ContextCapabilities caps = GLContext.getCapabilities();
/* ;0:88 */     long function_pointer = caps.glMatrixIndexuivARB;
/* ;1:89 */     BufferChecks.checkFunctionAddress(function_pointer);
/* ;2:90 */     BufferChecks.checkDirect(pIndices);
/* ;3:91 */     nglMatrixIndexuivARB(pIndices.remaining(), MemoryUtil.getAddress(pIndices), function_pointer);
/* ;4:   */   }
/* ;5:   */   
/* ;6:   */   static native void nglMatrixIndexuivARB(int paramInt, long paramLong1, long paramLong2);
/* ;7:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBMatrixPalette
 * JD-Core Version:    0.7.0.1
 */