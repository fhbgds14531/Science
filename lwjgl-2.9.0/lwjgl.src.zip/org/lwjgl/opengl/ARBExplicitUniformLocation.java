package org.lwjgl.opengl;

public final class ARBExplicitUniformLocation
{
  public static final int GL_MAX_UNIFORM_LOCATIONS = 33390;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBExplicitUniformLocation
 * JD-Core Version:    0.7.0.1
 */