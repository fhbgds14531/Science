/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class NVFence
/*  8:   */ {
/*  9:   */   public static final int GL_ALL_COMPLETED_NV = 34034;
/* 10:   */   public static final int GL_FENCE_STATUS_NV = 34035;
/* 11:   */   public static final int GL_FENCE_CONDITION_NV = 34036;
/* 12:   */   
/* 13:   */   public static void glGenFencesNV(IntBuffer piFences)
/* 14:   */   {
/* 15:17 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 16:18 */     long function_pointer = caps.glGenFencesNV;
/* 17:19 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 18:20 */     BufferChecks.checkDirect(piFences);
/* 19:21 */     nglGenFencesNV(piFences.remaining(), MemoryUtil.getAddress(piFences), function_pointer);
/* 20:   */   }
/* 21:   */   
/* 22:   */   static native void nglGenFencesNV(int paramInt, long paramLong1, long paramLong2);
/* 23:   */   
/* 24:   */   public static int glGenFencesNV()
/* 25:   */   {
/* 26:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:28 */     long function_pointer = caps.glGenFencesNV;
/* 28:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:30 */     IntBuffer piFences = APIUtil.getBufferInt(caps);
/* 30:31 */     nglGenFencesNV(1, MemoryUtil.getAddress(piFences), function_pointer);
/* 31:32 */     return piFences.get(0);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static void glDeleteFencesNV(IntBuffer piFences)
/* 35:   */   {
/* 36:36 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 37:37 */     long function_pointer = caps.glDeleteFencesNV;
/* 38:38 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 39:39 */     BufferChecks.checkDirect(piFences);
/* 40:40 */     nglDeleteFencesNV(piFences.remaining(), MemoryUtil.getAddress(piFences), function_pointer);
/* 41:   */   }
/* 42:   */   
/* 43:   */   static native void nglDeleteFencesNV(int paramInt, long paramLong1, long paramLong2);
/* 44:   */   
/* 45:   */   public static void glDeleteFencesNV(int fence)
/* 46:   */   {
/* 47:46 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 48:47 */     long function_pointer = caps.glDeleteFencesNV;
/* 49:48 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 50:49 */     nglDeleteFencesNV(1, APIUtil.getInt(caps, fence), function_pointer);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public static void glSetFenceNV(int fence, int condition)
/* 54:   */   {
/* 55:53 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 56:54 */     long function_pointer = caps.glSetFenceNV;
/* 57:55 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 58:56 */     nglSetFenceNV(fence, condition, function_pointer);
/* 59:   */   }
/* 60:   */   
/* 61:   */   static native void nglSetFenceNV(int paramInt1, int paramInt2, long paramLong);
/* 62:   */   
/* 63:   */   public static boolean glTestFenceNV(int fence)
/* 64:   */   {
/* 65:61 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 66:62 */     long function_pointer = caps.glTestFenceNV;
/* 67:63 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 68:64 */     boolean __result = nglTestFenceNV(fence, function_pointer);
/* 69:65 */     return __result;
/* 70:   */   }
/* 71:   */   
/* 72:   */   static native boolean nglTestFenceNV(int paramInt, long paramLong);
/* 73:   */   
/* 74:   */   public static void glFinishFenceNV(int fence)
/* 75:   */   {
/* 76:70 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 77:71 */     long function_pointer = caps.glFinishFenceNV;
/* 78:72 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 79:73 */     nglFinishFenceNV(fence, function_pointer);
/* 80:   */   }
/* 81:   */   
/* 82:   */   static native void nglFinishFenceNV(int paramInt, long paramLong);
/* 83:   */   
/* 84:   */   public static boolean glIsFenceNV(int fence)
/* 85:   */   {
/* 86:78 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 87:79 */     long function_pointer = caps.glIsFenceNV;
/* 88:80 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 89:81 */     boolean __result = nglIsFenceNV(fence, function_pointer);
/* 90:82 */     return __result;
/* 91:   */   }
/* 92:   */   
/* 93:   */   static native boolean nglIsFenceNV(int paramInt, long paramLong);
/* 94:   */   
/* 95:   */   public static void glGetFenceivNV(int fence, int pname, IntBuffer piParams)
/* 96:   */   {
/* 97:87 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 98:88 */     long function_pointer = caps.glGetFenceivNV;
/* 99:89 */     BufferChecks.checkFunctionAddress(function_pointer);
/* :0:90 */     BufferChecks.checkBuffer(piParams, 4);
/* :1:91 */     nglGetFenceivNV(fence, pname, MemoryUtil.getAddress(piParams), function_pointer);
/* :2:   */   }
/* :3:   */   
/* :4:   */   static native void nglGetFenceivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* :5:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVFence
 * JD-Core Version:    0.7.0.1
 */