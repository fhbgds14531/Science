/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.ByteOrder;
/*    5:     */ import java.nio.DoubleBuffer;
/*    6:     */ import java.nio.FloatBuffer;
/*    7:     */ import java.nio.IntBuffer;
/*    8:     */ import java.nio.ShortBuffer;
/*    9:     */ import org.lwjgl.BufferChecks;
/*   10:     */ import org.lwjgl.LWJGLUtil;
/*   11:     */ import org.lwjgl.MemoryUtil;
/*   12:     */ 
/*   13:     */ public final class GL20
/*   14:     */ {
/*   15:     */   public static final int GL_SHADING_LANGUAGE_VERSION = 35724;
/*   16:     */   public static final int GL_CURRENT_PROGRAM = 35725;
/*   17:     */   public static final int GL_SHADER_TYPE = 35663;
/*   18:     */   public static final int GL_DELETE_STATUS = 35712;
/*   19:     */   public static final int GL_COMPILE_STATUS = 35713;
/*   20:     */   public static final int GL_LINK_STATUS = 35714;
/*   21:     */   public static final int GL_VALIDATE_STATUS = 35715;
/*   22:     */   public static final int GL_INFO_LOG_LENGTH = 35716;
/*   23:     */   public static final int GL_ATTACHED_SHADERS = 35717;
/*   24:     */   public static final int GL_ACTIVE_UNIFORMS = 35718;
/*   25:     */   public static final int GL_ACTIVE_UNIFORM_MAX_LENGTH = 35719;
/*   26:     */   public static final int GL_ACTIVE_ATTRIBUTES = 35721;
/*   27:     */   public static final int GL_ACTIVE_ATTRIBUTE_MAX_LENGTH = 35722;
/*   28:     */   public static final int GL_SHADER_SOURCE_LENGTH = 35720;
/*   29:     */   public static final int GL_SHADER_OBJECT = 35656;
/*   30:     */   public static final int GL_FLOAT_VEC2 = 35664;
/*   31:     */   public static final int GL_FLOAT_VEC3 = 35665;
/*   32:     */   public static final int GL_FLOAT_VEC4 = 35666;
/*   33:     */   public static final int GL_INT_VEC2 = 35667;
/*   34:     */   public static final int GL_INT_VEC3 = 35668;
/*   35:     */   public static final int GL_INT_VEC4 = 35669;
/*   36:     */   public static final int GL_BOOL = 35670;
/*   37:     */   public static final int GL_BOOL_VEC2 = 35671;
/*   38:     */   public static final int GL_BOOL_VEC3 = 35672;
/*   39:     */   public static final int GL_BOOL_VEC4 = 35673;
/*   40:     */   public static final int GL_FLOAT_MAT2 = 35674;
/*   41:     */   public static final int GL_FLOAT_MAT3 = 35675;
/*   42:     */   public static final int GL_FLOAT_MAT4 = 35676;
/*   43:     */   public static final int GL_SAMPLER_1D = 35677;
/*   44:     */   public static final int GL_SAMPLER_2D = 35678;
/*   45:     */   public static final int GL_SAMPLER_3D = 35679;
/*   46:     */   public static final int GL_SAMPLER_CUBE = 35680;
/*   47:     */   public static final int GL_SAMPLER_1D_SHADOW = 35681;
/*   48:     */   public static final int GL_SAMPLER_2D_SHADOW = 35682;
/*   49:     */   public static final int GL_VERTEX_SHADER = 35633;
/*   50:     */   public static final int GL_MAX_VERTEX_UNIFORM_COMPONENTS = 35658;
/*   51:     */   public static final int GL_MAX_VARYING_FLOATS = 35659;
/*   52:     */   public static final int GL_MAX_VERTEX_ATTRIBS = 34921;
/*   53:     */   public static final int GL_MAX_TEXTURE_IMAGE_UNITS = 34930;
/*   54:     */   public static final int GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS = 35660;
/*   55:     */   public static final int GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS = 35661;
/*   56:     */   public static final int GL_MAX_TEXTURE_COORDS = 34929;
/*   57:     */   public static final int GL_VERTEX_PROGRAM_POINT_SIZE = 34370;
/*   58:     */   public static final int GL_VERTEX_PROGRAM_TWO_SIDE = 34371;
/*   59:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_ENABLED = 34338;
/*   60:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_SIZE = 34339;
/*   61:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_STRIDE = 34340;
/*   62:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_TYPE = 34341;
/*   63:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_NORMALIZED = 34922;
/*   64:     */   public static final int GL_CURRENT_VERTEX_ATTRIB = 34342;
/*   65:     */   public static final int GL_VERTEX_ATTRIB_ARRAY_POINTER = 34373;
/*   66:     */   public static final int GL_FRAGMENT_SHADER = 35632;
/*   67:     */   public static final int GL_MAX_FRAGMENT_UNIFORM_COMPONENTS = 35657;
/*   68:     */   public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT = 35723;
/*   69:     */   public static final int GL_MAX_DRAW_BUFFERS = 34852;
/*   70:     */   public static final int GL_DRAW_BUFFER0 = 34853;
/*   71:     */   public static final int GL_DRAW_BUFFER1 = 34854;
/*   72:     */   public static final int GL_DRAW_BUFFER2 = 34855;
/*   73:     */   public static final int GL_DRAW_BUFFER3 = 34856;
/*   74:     */   public static final int GL_DRAW_BUFFER4 = 34857;
/*   75:     */   public static final int GL_DRAW_BUFFER5 = 34858;
/*   76:     */   public static final int GL_DRAW_BUFFER6 = 34859;
/*   77:     */   public static final int GL_DRAW_BUFFER7 = 34860;
/*   78:     */   public static final int GL_DRAW_BUFFER8 = 34861;
/*   79:     */   public static final int GL_DRAW_BUFFER9 = 34862;
/*   80:     */   public static final int GL_DRAW_BUFFER10 = 34863;
/*   81:     */   public static final int GL_DRAW_BUFFER11 = 34864;
/*   82:     */   public static final int GL_DRAW_BUFFER12 = 34865;
/*   83:     */   public static final int GL_DRAW_BUFFER13 = 34866;
/*   84:     */   public static final int GL_DRAW_BUFFER14 = 34867;
/*   85:     */   public static final int GL_DRAW_BUFFER15 = 34868;
/*   86:     */   public static final int GL_POINT_SPRITE = 34913;
/*   87:     */   public static final int GL_COORD_REPLACE = 34914;
/*   88:     */   public static final int GL_POINT_SPRITE_COORD_ORIGIN = 36000;
/*   89:     */   public static final int GL_LOWER_LEFT = 36001;
/*   90:     */   public static final int GL_UPPER_LEFT = 36002;
/*   91:     */   public static final int GL_STENCIL_BACK_FUNC = 34816;
/*   92:     */   public static final int GL_STENCIL_BACK_FAIL = 34817;
/*   93:     */   public static final int GL_STENCIL_BACK_PASS_DEPTH_FAIL = 34818;
/*   94:     */   public static final int GL_STENCIL_BACK_PASS_DEPTH_PASS = 34819;
/*   95:     */   public static final int GL_STENCIL_BACK_REF = 36003;
/*   96:     */   public static final int GL_STENCIL_BACK_VALUE_MASK = 36004;
/*   97:     */   public static final int GL_STENCIL_BACK_WRITEMASK = 36005;
/*   98:     */   public static final int GL_BLEND_EQUATION_RGB = 32777;
/*   99:     */   public static final int GL_BLEND_EQUATION_ALPHA = 34877;
/*  100:     */   
/*  101:     */   public static void glShaderSource(int shader, ByteBuffer string)
/*  102:     */   {
/*  103: 192 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  104: 193 */     long function_pointer = caps.glShaderSource;
/*  105: 194 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  106: 195 */     BufferChecks.checkDirect(string);
/*  107: 196 */     nglShaderSource(shader, 1, MemoryUtil.getAddress(string), string.remaining(), function_pointer);
/*  108:     */   }
/*  109:     */   
/*  110:     */   static native void nglShaderSource(int paramInt1, int paramInt2, long paramLong1, int paramInt3, long paramLong2);
/*  111:     */   
/*  112:     */   public static void glShaderSource(int shader, CharSequence string)
/*  113:     */   {
/*  114: 202 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  115: 203 */     long function_pointer = caps.glShaderSource;
/*  116: 204 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  117: 205 */     nglShaderSource(shader, 1, APIUtil.getBuffer(caps, string), string.length(), function_pointer);
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static void glShaderSource(int shader, CharSequence[] strings)
/*  121:     */   {
/*  122: 210 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  123: 211 */     long function_pointer = caps.glShaderSource;
/*  124: 212 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  125: 213 */     BufferChecks.checkArray(strings);
/*  126: 214 */     nglShaderSource3(shader, strings.length, APIUtil.getBuffer(caps, strings), APIUtil.getLengths(caps, strings), function_pointer);
/*  127:     */   }
/*  128:     */   
/*  129:     */   static native void nglShaderSource3(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  130:     */   
/*  131:     */   public static int glCreateShader(int type)
/*  132:     */   {
/*  133: 219 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  134: 220 */     long function_pointer = caps.glCreateShader;
/*  135: 221 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  136: 222 */     int __result = nglCreateShader(type, function_pointer);
/*  137: 223 */     return __result;
/*  138:     */   }
/*  139:     */   
/*  140:     */   static native int nglCreateShader(int paramInt, long paramLong);
/*  141:     */   
/*  142:     */   public static boolean glIsShader(int shader)
/*  143:     */   {
/*  144: 228 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  145: 229 */     long function_pointer = caps.glIsShader;
/*  146: 230 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  147: 231 */     boolean __result = nglIsShader(shader, function_pointer);
/*  148: 232 */     return __result;
/*  149:     */   }
/*  150:     */   
/*  151:     */   static native boolean nglIsShader(int paramInt, long paramLong);
/*  152:     */   
/*  153:     */   public static void glCompileShader(int shader)
/*  154:     */   {
/*  155: 237 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  156: 238 */     long function_pointer = caps.glCompileShader;
/*  157: 239 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  158: 240 */     nglCompileShader(shader, function_pointer);
/*  159:     */   }
/*  160:     */   
/*  161:     */   static native void nglCompileShader(int paramInt, long paramLong);
/*  162:     */   
/*  163:     */   public static void glDeleteShader(int shader)
/*  164:     */   {
/*  165: 245 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  166: 246 */     long function_pointer = caps.glDeleteShader;
/*  167: 247 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  168: 248 */     nglDeleteShader(shader, function_pointer);
/*  169:     */   }
/*  170:     */   
/*  171:     */   static native void nglDeleteShader(int paramInt, long paramLong);
/*  172:     */   
/*  173:     */   public static int glCreateProgram()
/*  174:     */   {
/*  175: 253 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  176: 254 */     long function_pointer = caps.glCreateProgram;
/*  177: 255 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  178: 256 */     int __result = nglCreateProgram(function_pointer);
/*  179: 257 */     return __result;
/*  180:     */   }
/*  181:     */   
/*  182:     */   static native int nglCreateProgram(long paramLong);
/*  183:     */   
/*  184:     */   public static boolean glIsProgram(int program)
/*  185:     */   {
/*  186: 262 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  187: 263 */     long function_pointer = caps.glIsProgram;
/*  188: 264 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  189: 265 */     boolean __result = nglIsProgram(program, function_pointer);
/*  190: 266 */     return __result;
/*  191:     */   }
/*  192:     */   
/*  193:     */   static native boolean nglIsProgram(int paramInt, long paramLong);
/*  194:     */   
/*  195:     */   public static void glAttachShader(int program, int shader)
/*  196:     */   {
/*  197: 271 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  198: 272 */     long function_pointer = caps.glAttachShader;
/*  199: 273 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  200: 274 */     nglAttachShader(program, shader, function_pointer);
/*  201:     */   }
/*  202:     */   
/*  203:     */   static native void nglAttachShader(int paramInt1, int paramInt2, long paramLong);
/*  204:     */   
/*  205:     */   public static void glDetachShader(int program, int shader)
/*  206:     */   {
/*  207: 279 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  208: 280 */     long function_pointer = caps.glDetachShader;
/*  209: 281 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  210: 282 */     nglDetachShader(program, shader, function_pointer);
/*  211:     */   }
/*  212:     */   
/*  213:     */   static native void nglDetachShader(int paramInt1, int paramInt2, long paramLong);
/*  214:     */   
/*  215:     */   public static void glLinkProgram(int program)
/*  216:     */   {
/*  217: 287 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  218: 288 */     long function_pointer = caps.glLinkProgram;
/*  219: 289 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  220: 290 */     nglLinkProgram(program, function_pointer);
/*  221:     */   }
/*  222:     */   
/*  223:     */   static native void nglLinkProgram(int paramInt, long paramLong);
/*  224:     */   
/*  225:     */   public static void glUseProgram(int program)
/*  226:     */   {
/*  227: 295 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  228: 296 */     long function_pointer = caps.glUseProgram;
/*  229: 297 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  230: 298 */     nglUseProgram(program, function_pointer);
/*  231:     */   }
/*  232:     */   
/*  233:     */   static native void nglUseProgram(int paramInt, long paramLong);
/*  234:     */   
/*  235:     */   public static void glValidateProgram(int program)
/*  236:     */   {
/*  237: 303 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  238: 304 */     long function_pointer = caps.glValidateProgram;
/*  239: 305 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  240: 306 */     nglValidateProgram(program, function_pointer);
/*  241:     */   }
/*  242:     */   
/*  243:     */   static native void nglValidateProgram(int paramInt, long paramLong);
/*  244:     */   
/*  245:     */   public static void glDeleteProgram(int program)
/*  246:     */   {
/*  247: 311 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  248: 312 */     long function_pointer = caps.glDeleteProgram;
/*  249: 313 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  250: 314 */     nglDeleteProgram(program, function_pointer);
/*  251:     */   }
/*  252:     */   
/*  253:     */   static native void nglDeleteProgram(int paramInt, long paramLong);
/*  254:     */   
/*  255:     */   public static void glUniform1f(int location, float v0)
/*  256:     */   {
/*  257: 319 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  258: 320 */     long function_pointer = caps.glUniform1f;
/*  259: 321 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  260: 322 */     nglUniform1f(location, v0, function_pointer);
/*  261:     */   }
/*  262:     */   
/*  263:     */   static native void nglUniform1f(int paramInt, float paramFloat, long paramLong);
/*  264:     */   
/*  265:     */   public static void glUniform2f(int location, float v0, float v1)
/*  266:     */   {
/*  267: 327 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  268: 328 */     long function_pointer = caps.glUniform2f;
/*  269: 329 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  270: 330 */     nglUniform2f(location, v0, v1, function_pointer);
/*  271:     */   }
/*  272:     */   
/*  273:     */   static native void nglUniform2f(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*  274:     */   
/*  275:     */   public static void glUniform3f(int location, float v0, float v1, float v2)
/*  276:     */   {
/*  277: 335 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  278: 336 */     long function_pointer = caps.glUniform3f;
/*  279: 337 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  280: 338 */     nglUniform3f(location, v0, v1, v2, function_pointer);
/*  281:     */   }
/*  282:     */   
/*  283:     */   static native void nglUniform3f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  284:     */   
/*  285:     */   public static void glUniform4f(int location, float v0, float v1, float v2, float v3)
/*  286:     */   {
/*  287: 343 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  288: 344 */     long function_pointer = caps.glUniform4f;
/*  289: 345 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  290: 346 */     nglUniform4f(location, v0, v1, v2, v3, function_pointer);
/*  291:     */   }
/*  292:     */   
/*  293:     */   static native void nglUniform4f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  294:     */   
/*  295:     */   public static void glUniform1i(int location, int v0)
/*  296:     */   {
/*  297: 351 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  298: 352 */     long function_pointer = caps.glUniform1i;
/*  299: 353 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  300: 354 */     nglUniform1i(location, v0, function_pointer);
/*  301:     */   }
/*  302:     */   
/*  303:     */   static native void nglUniform1i(int paramInt1, int paramInt2, long paramLong);
/*  304:     */   
/*  305:     */   public static void glUniform2i(int location, int v0, int v1)
/*  306:     */   {
/*  307: 359 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  308: 360 */     long function_pointer = caps.glUniform2i;
/*  309: 361 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  310: 362 */     nglUniform2i(location, v0, v1, function_pointer);
/*  311:     */   }
/*  312:     */   
/*  313:     */   static native void nglUniform2i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/*  314:     */   
/*  315:     */   public static void glUniform3i(int location, int v0, int v1, int v2)
/*  316:     */   {
/*  317: 367 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  318: 368 */     long function_pointer = caps.glUniform3i;
/*  319: 369 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  320: 370 */     nglUniform3i(location, v0, v1, v2, function_pointer);
/*  321:     */   }
/*  322:     */   
/*  323:     */   static native void nglUniform3i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/*  324:     */   
/*  325:     */   public static void glUniform4i(int location, int v0, int v1, int v2, int v3)
/*  326:     */   {
/*  327: 375 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  328: 376 */     long function_pointer = caps.glUniform4i;
/*  329: 377 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  330: 378 */     nglUniform4i(location, v0, v1, v2, v3, function_pointer);
/*  331:     */   }
/*  332:     */   
/*  333:     */   static native void nglUniform4i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  334:     */   
/*  335:     */   public static void glUniform1(int location, FloatBuffer values)
/*  336:     */   {
/*  337: 383 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  338: 384 */     long function_pointer = caps.glUniform1fv;
/*  339: 385 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  340: 386 */     BufferChecks.checkDirect(values);
/*  341: 387 */     nglUniform1fv(location, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/*  342:     */   }
/*  343:     */   
/*  344:     */   static native void nglUniform1fv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  345:     */   
/*  346:     */   public static void glUniform2(int location, FloatBuffer values)
/*  347:     */   {
/*  348: 392 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  349: 393 */     long function_pointer = caps.glUniform2fv;
/*  350: 394 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  351: 395 */     BufferChecks.checkDirect(values);
/*  352: 396 */     nglUniform2fv(location, values.remaining() >> 1, MemoryUtil.getAddress(values), function_pointer);
/*  353:     */   }
/*  354:     */   
/*  355:     */   static native void nglUniform2fv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  356:     */   
/*  357:     */   public static void glUniform3(int location, FloatBuffer values)
/*  358:     */   {
/*  359: 401 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  360: 402 */     long function_pointer = caps.glUniform3fv;
/*  361: 403 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  362: 404 */     BufferChecks.checkDirect(values);
/*  363: 405 */     nglUniform3fv(location, values.remaining() / 3, MemoryUtil.getAddress(values), function_pointer);
/*  364:     */   }
/*  365:     */   
/*  366:     */   static native void nglUniform3fv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  367:     */   
/*  368:     */   public static void glUniform4(int location, FloatBuffer values)
/*  369:     */   {
/*  370: 410 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  371: 411 */     long function_pointer = caps.glUniform4fv;
/*  372: 412 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  373: 413 */     BufferChecks.checkDirect(values);
/*  374: 414 */     nglUniform4fv(location, values.remaining() >> 2, MemoryUtil.getAddress(values), function_pointer);
/*  375:     */   }
/*  376:     */   
/*  377:     */   static native void nglUniform4fv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  378:     */   
/*  379:     */   public static void glUniform1(int location, IntBuffer values)
/*  380:     */   {
/*  381: 419 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  382: 420 */     long function_pointer = caps.glUniform1iv;
/*  383: 421 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  384: 422 */     BufferChecks.checkDirect(values);
/*  385: 423 */     nglUniform1iv(location, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/*  386:     */   }
/*  387:     */   
/*  388:     */   static native void nglUniform1iv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  389:     */   
/*  390:     */   public static void glUniform2(int location, IntBuffer values)
/*  391:     */   {
/*  392: 428 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  393: 429 */     long function_pointer = caps.glUniform2iv;
/*  394: 430 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  395: 431 */     BufferChecks.checkDirect(values);
/*  396: 432 */     nglUniform2iv(location, values.remaining() >> 1, MemoryUtil.getAddress(values), function_pointer);
/*  397:     */   }
/*  398:     */   
/*  399:     */   static native void nglUniform2iv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  400:     */   
/*  401:     */   public static void glUniform3(int location, IntBuffer values)
/*  402:     */   {
/*  403: 437 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  404: 438 */     long function_pointer = caps.glUniform3iv;
/*  405: 439 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  406: 440 */     BufferChecks.checkDirect(values);
/*  407: 441 */     nglUniform3iv(location, values.remaining() / 3, MemoryUtil.getAddress(values), function_pointer);
/*  408:     */   }
/*  409:     */   
/*  410:     */   static native void nglUniform3iv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  411:     */   
/*  412:     */   public static void glUniform4(int location, IntBuffer values)
/*  413:     */   {
/*  414: 446 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  415: 447 */     long function_pointer = caps.glUniform4iv;
/*  416: 448 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  417: 449 */     BufferChecks.checkDirect(values);
/*  418: 450 */     nglUniform4iv(location, values.remaining() >> 2, MemoryUtil.getAddress(values), function_pointer);
/*  419:     */   }
/*  420:     */   
/*  421:     */   static native void nglUniform4iv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  422:     */   
/*  423:     */   public static void glUniformMatrix2(int location, boolean transpose, FloatBuffer matrices)
/*  424:     */   {
/*  425: 455 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  426: 456 */     long function_pointer = caps.glUniformMatrix2fv;
/*  427: 457 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  428: 458 */     BufferChecks.checkDirect(matrices);
/*  429: 459 */     nglUniformMatrix2fv(location, matrices.remaining() >> 2, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/*  430:     */   }
/*  431:     */   
/*  432:     */   static native void nglUniformMatrix2fv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/*  433:     */   
/*  434:     */   public static void glUniformMatrix3(int location, boolean transpose, FloatBuffer matrices)
/*  435:     */   {
/*  436: 464 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  437: 465 */     long function_pointer = caps.glUniformMatrix3fv;
/*  438: 466 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  439: 467 */     BufferChecks.checkDirect(matrices);
/*  440: 468 */     nglUniformMatrix3fv(location, matrices.remaining() / 9, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/*  441:     */   }
/*  442:     */   
/*  443:     */   static native void nglUniformMatrix3fv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/*  444:     */   
/*  445:     */   public static void glUniformMatrix4(int location, boolean transpose, FloatBuffer matrices)
/*  446:     */   {
/*  447: 473 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  448: 474 */     long function_pointer = caps.glUniformMatrix4fv;
/*  449: 475 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  450: 476 */     BufferChecks.checkDirect(matrices);
/*  451: 477 */     nglUniformMatrix4fv(location, matrices.remaining() >> 4, transpose, MemoryUtil.getAddress(matrices), function_pointer);
/*  452:     */   }
/*  453:     */   
/*  454:     */   static native void nglUniformMatrix4fv(int paramInt1, int paramInt2, boolean paramBoolean, long paramLong1, long paramLong2);
/*  455:     */   
/*  456:     */   public static void glGetShader(int shader, int pname, IntBuffer params)
/*  457:     */   {
/*  458: 482 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  459: 483 */     long function_pointer = caps.glGetShaderiv;
/*  460: 484 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  461: 485 */     BufferChecks.checkDirect(params);
/*  462: 486 */     nglGetShaderiv(shader, pname, MemoryUtil.getAddress(params), function_pointer);
/*  463:     */   }
/*  464:     */   
/*  465:     */   static native void nglGetShaderiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  466:     */   
/*  467:     */   @Deprecated
/*  468:     */   public static int glGetShader(int shader, int pname)
/*  469:     */   {
/*  470: 497 */     return glGetShaderi(shader, pname);
/*  471:     */   }
/*  472:     */   
/*  473:     */   public static int glGetShaderi(int shader, int pname)
/*  474:     */   {
/*  475: 502 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  476: 503 */     long function_pointer = caps.glGetShaderiv;
/*  477: 504 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  478: 505 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  479: 506 */     nglGetShaderiv(shader, pname, MemoryUtil.getAddress(params), function_pointer);
/*  480: 507 */     return params.get(0);
/*  481:     */   }
/*  482:     */   
/*  483:     */   public static void glGetProgram(int program, int pname, IntBuffer params)
/*  484:     */   {
/*  485: 511 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  486: 512 */     long function_pointer = caps.glGetProgramiv;
/*  487: 513 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  488: 514 */     BufferChecks.checkDirect(params);
/*  489: 515 */     nglGetProgramiv(program, pname, MemoryUtil.getAddress(params), function_pointer);
/*  490:     */   }
/*  491:     */   
/*  492:     */   static native void nglGetProgramiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  493:     */   
/*  494:     */   @Deprecated
/*  495:     */   public static int glGetProgram(int program, int pname)
/*  496:     */   {
/*  497: 526 */     return glGetProgrami(program, pname);
/*  498:     */   }
/*  499:     */   
/*  500:     */   public static int glGetProgrami(int program, int pname)
/*  501:     */   {
/*  502: 531 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  503: 532 */     long function_pointer = caps.glGetProgramiv;
/*  504: 533 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  505: 534 */     IntBuffer params = APIUtil.getBufferInt(caps);
/*  506: 535 */     nglGetProgramiv(program, pname, MemoryUtil.getAddress(params), function_pointer);
/*  507: 536 */     return params.get(0);
/*  508:     */   }
/*  509:     */   
/*  510:     */   public static void glGetShaderInfoLog(int shader, IntBuffer length, ByteBuffer infoLog)
/*  511:     */   {
/*  512: 540 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  513: 541 */     long function_pointer = caps.glGetShaderInfoLog;
/*  514: 542 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  515: 543 */     if (length != null) {
/*  516: 544 */       BufferChecks.checkBuffer(length, 1);
/*  517:     */     }
/*  518: 545 */     BufferChecks.checkDirect(infoLog);
/*  519: 546 */     nglGetShaderInfoLog(shader, infoLog.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  520:     */   }
/*  521:     */   
/*  522:     */   static native void nglGetShaderInfoLog(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  523:     */   
/*  524:     */   public static String glGetShaderInfoLog(int shader, int maxLength)
/*  525:     */   {
/*  526: 552 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  527: 553 */     long function_pointer = caps.glGetShaderInfoLog;
/*  528: 554 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  529: 555 */     IntBuffer infoLog_length = APIUtil.getLengths(caps);
/*  530: 556 */     ByteBuffer infoLog = APIUtil.getBufferByte(caps, maxLength);
/*  531: 557 */     nglGetShaderInfoLog(shader, maxLength, MemoryUtil.getAddress0(infoLog_length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  532: 558 */     infoLog.limit(infoLog_length.get(0));
/*  533: 559 */     return APIUtil.getString(caps, infoLog);
/*  534:     */   }
/*  535:     */   
/*  536:     */   public static void glGetProgramInfoLog(int program, IntBuffer length, ByteBuffer infoLog)
/*  537:     */   {
/*  538: 563 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  539: 564 */     long function_pointer = caps.glGetProgramInfoLog;
/*  540: 565 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  541: 566 */     if (length != null) {
/*  542: 567 */       BufferChecks.checkBuffer(length, 1);
/*  543:     */     }
/*  544: 568 */     BufferChecks.checkDirect(infoLog);
/*  545: 569 */     nglGetProgramInfoLog(program, infoLog.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  546:     */   }
/*  547:     */   
/*  548:     */   static native void nglGetProgramInfoLog(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  549:     */   
/*  550:     */   public static String glGetProgramInfoLog(int program, int maxLength)
/*  551:     */   {
/*  552: 575 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  553: 576 */     long function_pointer = caps.glGetProgramInfoLog;
/*  554: 577 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  555: 578 */     IntBuffer infoLog_length = APIUtil.getLengths(caps);
/*  556: 579 */     ByteBuffer infoLog = APIUtil.getBufferByte(caps, maxLength);
/*  557: 580 */     nglGetProgramInfoLog(program, maxLength, MemoryUtil.getAddress0(infoLog_length), MemoryUtil.getAddress(infoLog), function_pointer);
/*  558: 581 */     infoLog.limit(infoLog_length.get(0));
/*  559: 582 */     return APIUtil.getString(caps, infoLog);
/*  560:     */   }
/*  561:     */   
/*  562:     */   public static void glGetAttachedShaders(int program, IntBuffer count, IntBuffer shaders)
/*  563:     */   {
/*  564: 586 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  565: 587 */     long function_pointer = caps.glGetAttachedShaders;
/*  566: 588 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  567: 589 */     if (count != null) {
/*  568: 590 */       BufferChecks.checkBuffer(count, 1);
/*  569:     */     }
/*  570: 591 */     BufferChecks.checkDirect(shaders);
/*  571: 592 */     nglGetAttachedShaders(program, shaders.remaining(), MemoryUtil.getAddressSafe(count), MemoryUtil.getAddress(shaders), function_pointer);
/*  572:     */   }
/*  573:     */   
/*  574:     */   static native void nglGetAttachedShaders(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  575:     */   
/*  576:     */   public static int glGetUniformLocation(int program, ByteBuffer name)
/*  577:     */   {
/*  578: 604 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  579: 605 */     long function_pointer = caps.glGetUniformLocation;
/*  580: 606 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  581: 607 */     BufferChecks.checkBuffer(name, 1);
/*  582: 608 */     BufferChecks.checkNullTerminated(name);
/*  583: 609 */     int __result = nglGetUniformLocation(program, MemoryUtil.getAddress(name), function_pointer);
/*  584: 610 */     return __result;
/*  585:     */   }
/*  586:     */   
/*  587:     */   static native int nglGetUniformLocation(int paramInt, long paramLong1, long paramLong2);
/*  588:     */   
/*  589:     */   public static int glGetUniformLocation(int program, CharSequence name)
/*  590:     */   {
/*  591: 616 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  592: 617 */     long function_pointer = caps.glGetUniformLocation;
/*  593: 618 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  594: 619 */     int __result = nglGetUniformLocation(program, APIUtil.getBufferNT(caps, name), function_pointer);
/*  595: 620 */     return __result;
/*  596:     */   }
/*  597:     */   
/*  598:     */   public static void glGetActiveUniform(int program, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/*  599:     */   {
/*  600: 624 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  601: 625 */     long function_pointer = caps.glGetActiveUniform;
/*  602: 626 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  603: 627 */     if (length != null) {
/*  604: 628 */       BufferChecks.checkBuffer(length, 1);
/*  605:     */     }
/*  606: 629 */     BufferChecks.checkBuffer(size, 1);
/*  607: 630 */     BufferChecks.checkBuffer(type, 1);
/*  608: 631 */     BufferChecks.checkDirect(name);
/*  609: 632 */     nglGetActiveUniform(program, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/*  610:     */   }
/*  611:     */   
/*  612:     */   static native void nglGetActiveUniform(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*  613:     */   
/*  614:     */   public static String glGetActiveUniform(int program, int index, int maxLength, IntBuffer sizeType)
/*  615:     */   {
/*  616: 642 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  617: 643 */     long function_pointer = caps.glGetActiveUniform;
/*  618: 644 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  619: 645 */     BufferChecks.checkBuffer(sizeType, 2);
/*  620: 646 */     IntBuffer name_length = APIUtil.getLengths(caps);
/*  621: 647 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/*  622: 648 */     nglGetActiveUniform(program, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(sizeType), MemoryUtil.getAddress(sizeType, sizeType.position() + 1), MemoryUtil.getAddress(name), function_pointer);
/*  623: 649 */     name.limit(name_length.get(0));
/*  624: 650 */     return APIUtil.getString(caps, name);
/*  625:     */   }
/*  626:     */   
/*  627:     */   public static String glGetActiveUniform(int program, int index, int maxLength)
/*  628:     */   {
/*  629: 659 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  630: 660 */     long function_pointer = caps.glGetActiveUniform;
/*  631: 661 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  632: 662 */     IntBuffer name_length = APIUtil.getLengths(caps);
/*  633: 663 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/*  634: 664 */     nglGetActiveUniform(program, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress0(APIUtil.getBufferInt(caps)), MemoryUtil.getAddress(APIUtil.getBufferInt(caps), 1), MemoryUtil.getAddress(name), function_pointer);
/*  635: 665 */     name.limit(name_length.get(0));
/*  636: 666 */     return APIUtil.getString(caps, name);
/*  637:     */   }
/*  638:     */   
/*  639:     */   public static int glGetActiveUniformSize(int program, int index)
/*  640:     */   {
/*  641: 675 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  642: 676 */     long function_pointer = caps.glGetActiveUniform;
/*  643: 677 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  644: 678 */     IntBuffer size = APIUtil.getBufferInt(caps);
/*  645: 679 */     nglGetActiveUniform(program, index, 0, 0L, MemoryUtil.getAddress(size), MemoryUtil.getAddress(size, 1), APIUtil.getBufferByte0(caps), function_pointer);
/*  646: 680 */     return size.get(0);
/*  647:     */   }
/*  648:     */   
/*  649:     */   public static int glGetActiveUniformType(int program, int index)
/*  650:     */   {
/*  651: 689 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  652: 690 */     long function_pointer = caps.glGetActiveUniform;
/*  653: 691 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  654: 692 */     IntBuffer type = APIUtil.getBufferInt(caps);
/*  655: 693 */     nglGetActiveUniform(program, index, 0, 0L, MemoryUtil.getAddress(type, 1), MemoryUtil.getAddress(type), APIUtil.getBufferByte0(caps), function_pointer);
/*  656: 694 */     return type.get(0);
/*  657:     */   }
/*  658:     */   
/*  659:     */   public static void glGetUniform(int program, int location, FloatBuffer params)
/*  660:     */   {
/*  661: 698 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  662: 699 */     long function_pointer = caps.glGetUniformfv;
/*  663: 700 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  664: 701 */     BufferChecks.checkDirect(params);
/*  665: 702 */     nglGetUniformfv(program, location, MemoryUtil.getAddress(params), function_pointer);
/*  666:     */   }
/*  667:     */   
/*  668:     */   static native void nglGetUniformfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  669:     */   
/*  670:     */   public static void glGetUniform(int program, int location, IntBuffer params)
/*  671:     */   {
/*  672: 707 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  673: 708 */     long function_pointer = caps.glGetUniformiv;
/*  674: 709 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  675: 710 */     BufferChecks.checkDirect(params);
/*  676: 711 */     nglGetUniformiv(program, location, MemoryUtil.getAddress(params), function_pointer);
/*  677:     */   }
/*  678:     */   
/*  679:     */   static native void nglGetUniformiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  680:     */   
/*  681:     */   public static void glGetShaderSource(int shader, IntBuffer length, ByteBuffer source)
/*  682:     */   {
/*  683: 716 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  684: 717 */     long function_pointer = caps.glGetShaderSource;
/*  685: 718 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  686: 719 */     if (length != null) {
/*  687: 720 */       BufferChecks.checkBuffer(length, 1);
/*  688:     */     }
/*  689: 721 */     BufferChecks.checkDirect(source);
/*  690: 722 */     nglGetShaderSource(shader, source.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(source), function_pointer);
/*  691:     */   }
/*  692:     */   
/*  693:     */   static native void nglGetShaderSource(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*  694:     */   
/*  695:     */   public static String glGetShaderSource(int shader, int maxLength)
/*  696:     */   {
/*  697: 728 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  698: 729 */     long function_pointer = caps.glGetShaderSource;
/*  699: 730 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  700: 731 */     IntBuffer source_length = APIUtil.getLengths(caps);
/*  701: 732 */     ByteBuffer source = APIUtil.getBufferByte(caps, maxLength);
/*  702: 733 */     nglGetShaderSource(shader, maxLength, MemoryUtil.getAddress0(source_length), MemoryUtil.getAddress(source), function_pointer);
/*  703: 734 */     source.limit(source_length.get(0));
/*  704: 735 */     return APIUtil.getString(caps, source);
/*  705:     */   }
/*  706:     */   
/*  707:     */   public static void glVertexAttrib1s(int index, short x)
/*  708:     */   {
/*  709: 739 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  710: 740 */     long function_pointer = caps.glVertexAttrib1s;
/*  711: 741 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  712: 742 */     nglVertexAttrib1s(index, x, function_pointer);
/*  713:     */   }
/*  714:     */   
/*  715:     */   static native void nglVertexAttrib1s(int paramInt, short paramShort, long paramLong);
/*  716:     */   
/*  717:     */   public static void glVertexAttrib1f(int index, float x)
/*  718:     */   {
/*  719: 747 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  720: 748 */     long function_pointer = caps.glVertexAttrib1f;
/*  721: 749 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  722: 750 */     nglVertexAttrib1f(index, x, function_pointer);
/*  723:     */   }
/*  724:     */   
/*  725:     */   static native void nglVertexAttrib1f(int paramInt, float paramFloat, long paramLong);
/*  726:     */   
/*  727:     */   public static void glVertexAttrib1d(int index, double x)
/*  728:     */   {
/*  729: 755 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  730: 756 */     long function_pointer = caps.glVertexAttrib1d;
/*  731: 757 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  732: 758 */     nglVertexAttrib1d(index, x, function_pointer);
/*  733:     */   }
/*  734:     */   
/*  735:     */   static native void nglVertexAttrib1d(int paramInt, double paramDouble, long paramLong);
/*  736:     */   
/*  737:     */   public static void glVertexAttrib2s(int index, short x, short y)
/*  738:     */   {
/*  739: 763 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  740: 764 */     long function_pointer = caps.glVertexAttrib2s;
/*  741: 765 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  742: 766 */     nglVertexAttrib2s(index, x, y, function_pointer);
/*  743:     */   }
/*  744:     */   
/*  745:     */   static native void nglVertexAttrib2s(int paramInt, short paramShort1, short paramShort2, long paramLong);
/*  746:     */   
/*  747:     */   public static void glVertexAttrib2f(int index, float x, float y)
/*  748:     */   {
/*  749: 771 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  750: 772 */     long function_pointer = caps.glVertexAttrib2f;
/*  751: 773 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  752: 774 */     nglVertexAttrib2f(index, x, y, function_pointer);
/*  753:     */   }
/*  754:     */   
/*  755:     */   static native void nglVertexAttrib2f(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/*  756:     */   
/*  757:     */   public static void glVertexAttrib2d(int index, double x, double y)
/*  758:     */   {
/*  759: 779 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  760: 780 */     long function_pointer = caps.glVertexAttrib2d;
/*  761: 781 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  762: 782 */     nglVertexAttrib2d(index, x, y, function_pointer);
/*  763:     */   }
/*  764:     */   
/*  765:     */   static native void nglVertexAttrib2d(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/*  766:     */   
/*  767:     */   public static void glVertexAttrib3s(int index, short x, short y, short z)
/*  768:     */   {
/*  769: 787 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  770: 788 */     long function_pointer = caps.glVertexAttrib3s;
/*  771: 789 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  772: 790 */     nglVertexAttrib3s(index, x, y, z, function_pointer);
/*  773:     */   }
/*  774:     */   
/*  775:     */   static native void nglVertexAttrib3s(int paramInt, short paramShort1, short paramShort2, short paramShort3, long paramLong);
/*  776:     */   
/*  777:     */   public static void glVertexAttrib3f(int index, float x, float y, float z)
/*  778:     */   {
/*  779: 795 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  780: 796 */     long function_pointer = caps.glVertexAttrib3f;
/*  781: 797 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  782: 798 */     nglVertexAttrib3f(index, x, y, z, function_pointer);
/*  783:     */   }
/*  784:     */   
/*  785:     */   static native void nglVertexAttrib3f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  786:     */   
/*  787:     */   public static void glVertexAttrib3d(int index, double x, double y, double z)
/*  788:     */   {
/*  789: 803 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  790: 804 */     long function_pointer = caps.glVertexAttrib3d;
/*  791: 805 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  792: 806 */     nglVertexAttrib3d(index, x, y, z, function_pointer);
/*  793:     */   }
/*  794:     */   
/*  795:     */   static native void nglVertexAttrib3d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  796:     */   
/*  797:     */   public static void glVertexAttrib4s(int index, short x, short y, short z, short w)
/*  798:     */   {
/*  799: 811 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  800: 812 */     long function_pointer = caps.glVertexAttrib4s;
/*  801: 813 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  802: 814 */     nglVertexAttrib4s(index, x, y, z, w, function_pointer);
/*  803:     */   }
/*  804:     */   
/*  805:     */   static native void nglVertexAttrib4s(int paramInt, short paramShort1, short paramShort2, short paramShort3, short paramShort4, long paramLong);
/*  806:     */   
/*  807:     */   public static void glVertexAttrib4f(int index, float x, float y, float z, float w)
/*  808:     */   {
/*  809: 819 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  810: 820 */     long function_pointer = caps.glVertexAttrib4f;
/*  811: 821 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  812: 822 */     nglVertexAttrib4f(index, x, y, z, w, function_pointer);
/*  813:     */   }
/*  814:     */   
/*  815:     */   static native void nglVertexAttrib4f(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  816:     */   
/*  817:     */   public static void glVertexAttrib4d(int index, double x, double y, double z, double w)
/*  818:     */   {
/*  819: 827 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  820: 828 */     long function_pointer = caps.glVertexAttrib4d;
/*  821: 829 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  822: 830 */     nglVertexAttrib4d(index, x, y, z, w, function_pointer);
/*  823:     */   }
/*  824:     */   
/*  825:     */   static native void nglVertexAttrib4d(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  826:     */   
/*  827:     */   public static void glVertexAttrib4Nub(int index, byte x, byte y, byte z, byte w)
/*  828:     */   {
/*  829: 835 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  830: 836 */     long function_pointer = caps.glVertexAttrib4Nub;
/*  831: 837 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  832: 838 */     nglVertexAttrib4Nub(index, x, y, z, w, function_pointer);
/*  833:     */   }
/*  834:     */   
/*  835:     */   static native void nglVertexAttrib4Nub(int paramInt, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, long paramLong);
/*  836:     */   
/*  837:     */   public static void glVertexAttribPointer(int index, int size, boolean normalized, int stride, DoubleBuffer buffer)
/*  838:     */   {
/*  839: 843 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  840: 844 */     long function_pointer = caps.glVertexAttribPointer;
/*  841: 845 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  842: 846 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  843: 847 */     BufferChecks.checkDirect(buffer);
/*  844: 848 */     if (LWJGLUtil.CHECKS) {
/*  845: 848 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  846:     */     }
/*  847: 849 */     nglVertexAttribPointer(index, size, 5130, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  848:     */   }
/*  849:     */   
/*  850:     */   public static void glVertexAttribPointer(int index, int size, boolean normalized, int stride, FloatBuffer buffer)
/*  851:     */   {
/*  852: 852 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  853: 853 */     long function_pointer = caps.glVertexAttribPointer;
/*  854: 854 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  855: 855 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  856: 856 */     BufferChecks.checkDirect(buffer);
/*  857: 857 */     if (LWJGLUtil.CHECKS) {
/*  858: 857 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  859:     */     }
/*  860: 858 */     nglVertexAttribPointer(index, size, 5126, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  861:     */   }
/*  862:     */   
/*  863:     */   public static void glVertexAttribPointer(int index, int size, boolean unsigned, boolean normalized, int stride, ByteBuffer buffer)
/*  864:     */   {
/*  865: 861 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  866: 862 */     long function_pointer = caps.glVertexAttribPointer;
/*  867: 863 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  868: 864 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  869: 865 */     BufferChecks.checkDirect(buffer);
/*  870: 866 */     if (LWJGLUtil.CHECKS) {
/*  871: 866 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  872:     */     }
/*  873: 867 */     nglVertexAttribPointer(index, size, unsigned ? 5121 : 5120, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  874:     */   }
/*  875:     */   
/*  876:     */   public static void glVertexAttribPointer(int index, int size, boolean unsigned, boolean normalized, int stride, IntBuffer buffer)
/*  877:     */   {
/*  878: 870 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  879: 871 */     long function_pointer = caps.glVertexAttribPointer;
/*  880: 872 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  881: 873 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  882: 874 */     BufferChecks.checkDirect(buffer);
/*  883: 875 */     if (LWJGLUtil.CHECKS) {
/*  884: 875 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  885:     */     }
/*  886: 876 */     nglVertexAttribPointer(index, size, unsigned ? 5125 : 5124, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  887:     */   }
/*  888:     */   
/*  889:     */   public static void glVertexAttribPointer(int index, int size, boolean unsigned, boolean normalized, int stride, ShortBuffer buffer)
/*  890:     */   {
/*  891: 879 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  892: 880 */     long function_pointer = caps.glVertexAttribPointer;
/*  893: 881 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  894: 882 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  895: 883 */     BufferChecks.checkDirect(buffer);
/*  896: 884 */     if (LWJGLUtil.CHECKS) {
/*  897: 884 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  898:     */     }
/*  899: 885 */     nglVertexAttribPointer(index, size, unsigned ? 5123 : 5122, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  900:     */   }
/*  901:     */   
/*  902:     */   static native void nglVertexAttribPointer(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong1, long paramLong2);
/*  903:     */   
/*  904:     */   public static void glVertexAttribPointer(int index, int size, int type, boolean normalized, int stride, long buffer_buffer_offset)
/*  905:     */   {
/*  906: 889 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  907: 890 */     long function_pointer = caps.glVertexAttribPointer;
/*  908: 891 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  909: 892 */     GLChecks.ensureArrayVBOenabled(caps);
/*  910: 893 */     nglVertexAttribPointerBO(index, size, type, normalized, stride, buffer_buffer_offset, function_pointer);
/*  911:     */   }
/*  912:     */   
/*  913:     */   static native void nglVertexAttribPointerBO(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, long paramLong1, long paramLong2);
/*  914:     */   
/*  915:     */   public static void glVertexAttribPointer(int index, int size, int type, boolean normalized, int stride, ByteBuffer buffer)
/*  916:     */   {
/*  917: 899 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  918: 900 */     long function_pointer = caps.glVertexAttribPointer;
/*  919: 901 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  920: 902 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  921: 903 */     BufferChecks.checkDirect(buffer);
/*  922: 904 */     if (LWJGLUtil.CHECKS) {
/*  923: 904 */       StateTracker.getReferences(caps).glVertexAttribPointer_buffer[index] = buffer;
/*  924:     */     }
/*  925: 905 */     nglVertexAttribPointer(index, size, type, normalized, stride, MemoryUtil.getAddress(buffer), function_pointer);
/*  926:     */   }
/*  927:     */   
/*  928:     */   public static void glEnableVertexAttribArray(int index)
/*  929:     */   {
/*  930: 909 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  931: 910 */     long function_pointer = caps.glEnableVertexAttribArray;
/*  932: 911 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  933: 912 */     nglEnableVertexAttribArray(index, function_pointer);
/*  934:     */   }
/*  935:     */   
/*  936:     */   static native void nglEnableVertexAttribArray(int paramInt, long paramLong);
/*  937:     */   
/*  938:     */   public static void glDisableVertexAttribArray(int index)
/*  939:     */   {
/*  940: 917 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  941: 918 */     long function_pointer = caps.glDisableVertexAttribArray;
/*  942: 919 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  943: 920 */     nglDisableVertexAttribArray(index, function_pointer);
/*  944:     */   }
/*  945:     */   
/*  946:     */   static native void nglDisableVertexAttribArray(int paramInt, long paramLong);
/*  947:     */   
/*  948:     */   public static void glGetVertexAttrib(int index, int pname, FloatBuffer params)
/*  949:     */   {
/*  950: 925 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  951: 926 */     long function_pointer = caps.glGetVertexAttribfv;
/*  952: 927 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  953: 928 */     BufferChecks.checkBuffer(params, 4);
/*  954: 929 */     nglGetVertexAttribfv(index, pname, MemoryUtil.getAddress(params), function_pointer);
/*  955:     */   }
/*  956:     */   
/*  957:     */   static native void nglGetVertexAttribfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  958:     */   
/*  959:     */   public static void glGetVertexAttrib(int index, int pname, DoubleBuffer params)
/*  960:     */   {
/*  961: 934 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  962: 935 */     long function_pointer = caps.glGetVertexAttribdv;
/*  963: 936 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  964: 937 */     BufferChecks.checkBuffer(params, 4);
/*  965: 938 */     nglGetVertexAttribdv(index, pname, MemoryUtil.getAddress(params), function_pointer);
/*  966:     */   }
/*  967:     */   
/*  968:     */   static native void nglGetVertexAttribdv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  969:     */   
/*  970:     */   public static void glGetVertexAttrib(int index, int pname, IntBuffer params)
/*  971:     */   {
/*  972: 943 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  973: 944 */     long function_pointer = caps.glGetVertexAttribiv;
/*  974: 945 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  975: 946 */     BufferChecks.checkBuffer(params, 4);
/*  976: 947 */     nglGetVertexAttribiv(index, pname, MemoryUtil.getAddress(params), function_pointer);
/*  977:     */   }
/*  978:     */   
/*  979:     */   static native void nglGetVertexAttribiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  980:     */   
/*  981:     */   public static ByteBuffer glGetVertexAttribPointer(int index, int pname, long result_size)
/*  982:     */   {
/*  983: 952 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  984: 953 */     long function_pointer = caps.glGetVertexAttribPointerv;
/*  985: 954 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  986: 955 */     ByteBuffer __result = nglGetVertexAttribPointerv(index, pname, result_size, function_pointer);
/*  987: 956 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/*  988:     */   }
/*  989:     */   
/*  990:     */   static native ByteBuffer nglGetVertexAttribPointerv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  991:     */   
/*  992:     */   public static void glBindAttribLocation(int program, int index, ByteBuffer name)
/*  993:     */   {
/*  994: 961 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  995: 962 */     long function_pointer = caps.glBindAttribLocation;
/*  996: 963 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  997: 964 */     BufferChecks.checkDirect(name);
/*  998: 965 */     BufferChecks.checkNullTerminated(name);
/*  999: 966 */     nglBindAttribLocation(program, index, MemoryUtil.getAddress(name), function_pointer);
/* 1000:     */   }
/* 1001:     */   
/* 1002:     */   static native void nglBindAttribLocation(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1003:     */   
/* 1004:     */   public static void glBindAttribLocation(int program, int index, CharSequence name)
/* 1005:     */   {
/* 1006: 972 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1007: 973 */     long function_pointer = caps.glBindAttribLocation;
/* 1008: 974 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1009: 975 */     nglBindAttribLocation(program, index, APIUtil.getBufferNT(caps, name), function_pointer);
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   public static void glGetActiveAttrib(int program, int index, IntBuffer length, IntBuffer size, IntBuffer type, ByteBuffer name)
/* 1013:     */   {
/* 1014: 979 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1015: 980 */     long function_pointer = caps.glGetActiveAttrib;
/* 1016: 981 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1017: 982 */     if (length != null) {
/* 1018: 983 */       BufferChecks.checkBuffer(length, 1);
/* 1019:     */     }
/* 1020: 984 */     BufferChecks.checkBuffer(size, 1);
/* 1021: 985 */     BufferChecks.checkBuffer(type, 1);
/* 1022: 986 */     BufferChecks.checkDirect(name);
/* 1023: 987 */     nglGetActiveAttrib(program, index, name.remaining(), MemoryUtil.getAddressSafe(length), MemoryUtil.getAddress(size), MemoryUtil.getAddress(type), MemoryUtil.getAddress(name), function_pointer);
/* 1024:     */   }
/* 1025:     */   
/* 1026:     */   static native void nglGetActiveAttrib(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 1027:     */   
/* 1028:     */   public static String glGetActiveAttrib(int program, int index, int maxLength, IntBuffer sizeType)
/* 1029:     */   {
/* 1030: 997 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1031: 998 */     long function_pointer = caps.glGetActiveAttrib;
/* 1032: 999 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1033:1000 */     BufferChecks.checkBuffer(sizeType, 2);
/* 1034:1001 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 1035:1002 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 1036:1003 */     nglGetActiveAttrib(program, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress(sizeType), MemoryUtil.getAddress(sizeType, sizeType.position() + 1), MemoryUtil.getAddress(name), function_pointer);
/* 1037:1004 */     name.limit(name_length.get(0));
/* 1038:1005 */     return APIUtil.getString(caps, name);
/* 1039:     */   }
/* 1040:     */   
/* 1041:     */   public static String glGetActiveAttrib(int program, int index, int maxLength)
/* 1042:     */   {
/* 1043:1014 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1044:1015 */     long function_pointer = caps.glGetActiveAttrib;
/* 1045:1016 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1046:1017 */     IntBuffer name_length = APIUtil.getLengths(caps);
/* 1047:1018 */     ByteBuffer name = APIUtil.getBufferByte(caps, maxLength);
/* 1048:1019 */     nglGetActiveAttrib(program, index, maxLength, MemoryUtil.getAddress0(name_length), MemoryUtil.getAddress0(APIUtil.getBufferInt(caps)), MemoryUtil.getAddress(APIUtil.getBufferInt(caps), 1), MemoryUtil.getAddress(name), function_pointer);
/* 1049:1020 */     name.limit(name_length.get(0));
/* 1050:1021 */     return APIUtil.getString(caps, name);
/* 1051:     */   }
/* 1052:     */   
/* 1053:     */   public static int glGetActiveAttribSize(int program, int index)
/* 1054:     */   {
/* 1055:1030 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1056:1031 */     long function_pointer = caps.glGetActiveAttrib;
/* 1057:1032 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1058:1033 */     IntBuffer size = APIUtil.getBufferInt(caps);
/* 1059:1034 */     nglGetActiveAttrib(program, index, 0, 0L, MemoryUtil.getAddress(size), MemoryUtil.getAddress(size, 1), APIUtil.getBufferByte0(caps), function_pointer);
/* 1060:1035 */     return size.get(0);
/* 1061:     */   }
/* 1062:     */   
/* 1063:     */   public static int glGetActiveAttribType(int program, int index)
/* 1064:     */   {
/* 1065:1044 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1066:1045 */     long function_pointer = caps.glGetActiveAttrib;
/* 1067:1046 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1068:1047 */     IntBuffer type = APIUtil.getBufferInt(caps);
/* 1069:1048 */     nglGetActiveAttrib(program, index, 0, 0L, MemoryUtil.getAddress(type, 1), MemoryUtil.getAddress(type), APIUtil.getBufferByte0(caps), function_pointer);
/* 1070:1049 */     return type.get(0);
/* 1071:     */   }
/* 1072:     */   
/* 1073:     */   public static int glGetAttribLocation(int program, ByteBuffer name)
/* 1074:     */   {
/* 1075:1053 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1076:1054 */     long function_pointer = caps.glGetAttribLocation;
/* 1077:1055 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1078:1056 */     BufferChecks.checkDirect(name);
/* 1079:1057 */     BufferChecks.checkNullTerminated(name);
/* 1080:1058 */     int __result = nglGetAttribLocation(program, MemoryUtil.getAddress(name), function_pointer);
/* 1081:1059 */     return __result;
/* 1082:     */   }
/* 1083:     */   
/* 1084:     */   static native int nglGetAttribLocation(int paramInt, long paramLong1, long paramLong2);
/* 1085:     */   
/* 1086:     */   public static int glGetAttribLocation(int program, CharSequence name)
/* 1087:     */   {
/* 1088:1065 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1089:1066 */     long function_pointer = caps.glGetAttribLocation;
/* 1090:1067 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1091:1068 */     int __result = nglGetAttribLocation(program, APIUtil.getBufferNT(caps, name), function_pointer);
/* 1092:1069 */     return __result;
/* 1093:     */   }
/* 1094:     */   
/* 1095:     */   public static void glDrawBuffers(IntBuffer buffers)
/* 1096:     */   {
/* 1097:1073 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1098:1074 */     long function_pointer = caps.glDrawBuffers;
/* 1099:1075 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1100:1076 */     BufferChecks.checkDirect(buffers);
/* 1101:1077 */     nglDrawBuffers(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/* 1102:     */   }
/* 1103:     */   
/* 1104:     */   static native void nglDrawBuffers(int paramInt, long paramLong1, long paramLong2);
/* 1105:     */   
/* 1106:     */   public static void glDrawBuffers(int buffer)
/* 1107:     */   {
/* 1108:1083 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1109:1084 */     long function_pointer = caps.glDrawBuffers;
/* 1110:1085 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1111:1086 */     nglDrawBuffers(1, APIUtil.getInt(caps, buffer), function_pointer);
/* 1112:     */   }
/* 1113:     */   
/* 1114:     */   public static void glStencilOpSeparate(int face, int sfail, int dpfail, int dppass)
/* 1115:     */   {
/* 1116:1090 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1117:1091 */     long function_pointer = caps.glStencilOpSeparate;
/* 1118:1092 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1119:1093 */     nglStencilOpSeparate(face, sfail, dpfail, dppass, function_pointer);
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static native void nglStencilOpSeparate(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 1123:     */   
/* 1124:     */   public static void glStencilFuncSeparate(int face, int func, int ref, int mask)
/* 1125:     */   {
/* 1126:1098 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1127:1099 */     long function_pointer = caps.glStencilFuncSeparate;
/* 1128:1100 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1129:1101 */     nglStencilFuncSeparate(face, func, ref, mask, function_pointer);
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   static native void nglStencilFuncSeparate(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 1133:     */   
/* 1134:     */   public static void glStencilMaskSeparate(int face, int mask)
/* 1135:     */   {
/* 1136:1106 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1137:1107 */     long function_pointer = caps.glStencilMaskSeparate;
/* 1138:1108 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1139:1109 */     nglStencilMaskSeparate(face, mask, function_pointer);
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   static native void nglStencilMaskSeparate(int paramInt1, int paramInt2, long paramLong);
/* 1143:     */   
/* 1144:     */   public static void glBlendEquationSeparate(int modeRGB, int modeAlpha)
/* 1145:     */   {
/* 1146:1114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1147:1115 */     long function_pointer = caps.glBlendEquationSeparate;
/* 1148:1116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1149:1117 */     nglBlendEquationSeparate(modeRGB, modeAlpha, function_pointer);
/* 1150:     */   }
/* 1151:     */   
/* 1152:     */   static native void nglBlendEquationSeparate(int paramInt1, int paramInt2, long paramLong);
/* 1153:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL20
 * JD-Core Version:    0.7.0.1
 */