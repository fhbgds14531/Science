/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBColorBufferFloat
/*  6:   */ {
/*  7:   */   public static final int GL_RGBA_FLOAT_MODE_ARB = 34848;
/*  8:   */   public static final int GL_CLAMP_VERTEX_COLOR_ARB = 35098;
/*  9:   */   public static final int GL_CLAMP_FRAGMENT_COLOR_ARB = 35099;
/* 10:   */   public static final int GL_CLAMP_READ_COLOR_ARB = 35100;
/* 11:   */   public static final int GL_FIXED_ONLY_ARB = 35101;
/* 12:   */   public static final int WGL_TYPE_RGBA_FLOAT_ARB = 8608;
/* 13:   */   public static final int GLX_RGBA_FLOAT_TYPE = 8377;
/* 14:   */   public static final int GLX_RGBA_FLOAT_BIT = 4;
/* 15:   */   
/* 16:   */   public static void glClampColorARB(int target, int clamp)
/* 17:   */   {
/* 18:51 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 19:52 */     long function_pointer = caps.glClampColorARB;
/* 20:53 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 21:54 */     nglClampColorARB(target, clamp, function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   static native void nglClampColorARB(int paramInt1, int paramInt2, long paramLong);
/* 25:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBColorBufferFloat
 * JD-Core Version:    0.7.0.1
 */