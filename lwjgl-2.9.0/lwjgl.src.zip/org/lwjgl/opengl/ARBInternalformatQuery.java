/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBInternalformatQuery
/*  6:   */ {
/*  7:   */   public static final int GL_NUM_SAMPLE_COUNTS = 37760;
/*  8:   */   
/*  9:   */   public static void glGetInternalformat(int target, int internalformat, int pname, IntBuffer params)
/* 10:   */   {
/* 11:18 */     GL42.glGetInternalformat(target, internalformat, pname, params);
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static int glGetInternalformat(int target, int internalformat, int pname)
/* 15:   */   {
/* 16:23 */     return GL42.glGetInternalformat(target, internalformat, pname);
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBInternalformatQuery
 * JD-Core Version:    0.7.0.1
 */