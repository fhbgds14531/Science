/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class ARBTextureBufferObject
/*  6:   */ {
/*  7:   */   public static final int GL_TEXTURE_BUFFER_ARB = 35882;
/*  8:   */   public static final int GL_MAX_TEXTURE_BUFFER_SIZE_ARB = 35883;
/*  9:   */   public static final int GL_TEXTURE_BINDING_BUFFER_ARB = 35884;
/* 10:   */   public static final int GL_TEXTURE_BUFFER_DATA_STORE_BINDING_ARB = 35885;
/* 11:   */   public static final int GL_TEXTURE_BUFFER_FORMAT_ARB = 35886;
/* 12:   */   
/* 13:   */   public static void glTexBufferARB(int target, int internalformat, int buffer)
/* 14:   */   {
/* 15:31 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 16:32 */     long function_pointer = caps.glTexBufferARB;
/* 17:33 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 18:34 */     nglTexBufferARB(target, internalformat, buffer, function_pointer);
/* 19:   */   }
/* 20:   */   
/* 21:   */   static native void nglTexBufferARB(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 22:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureBufferObject
 * JD-Core Version:    0.7.0.1
 */