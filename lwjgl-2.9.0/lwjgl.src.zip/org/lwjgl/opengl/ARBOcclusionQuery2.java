package org.lwjgl.opengl;

public final class ARBOcclusionQuery2
{
  public static final int GL_ANY_SAMPLES_PASSED = 35887;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBOcclusionQuery2
 * JD-Core Version:    0.7.0.1
 */