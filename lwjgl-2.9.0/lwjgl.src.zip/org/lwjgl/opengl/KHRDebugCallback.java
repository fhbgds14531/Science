/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.io.PrintStream;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import org.lwjgl.PointerWrapperAbstract;
/*   6:    */ 
/*   7:    */ public final class KHRDebugCallback
/*   8:    */   extends PointerWrapperAbstract
/*   9:    */ {
/*  10:    */   private static final int GL_DEBUG_SEVERITY_HIGH = 37190;
/*  11:    */   private static final int GL_DEBUG_SEVERITY_MEDIUM = 37191;
/*  12:    */   private static final int GL_DEBUG_SEVERITY_LOW = 37192;
/*  13:    */   private static final int GL_DEBUG_SEVERITY_NOTIFICATION = 33387;
/*  14:    */   private static final int GL_DEBUG_SOURCE_API = 33350;
/*  15:    */   private static final int GL_DEBUG_SOURCE_WINDOW_SYSTEM = 33351;
/*  16:    */   private static final int GL_DEBUG_SOURCE_SHADER_COMPILER = 33352;
/*  17:    */   private static final int GL_DEBUG_SOURCE_THIRD_PARTY = 33353;
/*  18:    */   private static final int GL_DEBUG_SOURCE_APPLICATION = 33354;
/*  19:    */   private static final int GL_DEBUG_SOURCE_OTHER = 33355;
/*  20:    */   private static final int GL_DEBUG_TYPE_ERROR = 33356;
/*  21:    */   private static final int GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR = 33357;
/*  22:    */   private static final int GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR = 33358;
/*  23:    */   private static final int GL_DEBUG_TYPE_PORTABILITY = 33359;
/*  24:    */   private static final int GL_DEBUG_TYPE_PERFORMANCE = 33360;
/*  25:    */   private static final int GL_DEBUG_TYPE_OTHER = 33361;
/*  26:    */   private static final int GL_DEBUG_TYPE_MARKER = 33384;
/*  27:    */   private static final long CALLBACK_POINTER;
/*  28:    */   private final Handler handler;
/*  29:    */   
/*  30:    */   static
/*  31:    */   {
/*  32: 75 */     long pointer = 0L;
/*  33:    */     try
/*  34:    */     {
/*  35: 78 */       pointer = ((Long)Class.forName("org.lwjgl.opengl.CallbackUtil").getDeclaredMethod("getDebugCallbackKHR", new Class[0]).invoke(null, new Object[0])).longValue();
/*  36:    */     }
/*  37:    */     catch (Exception e) {}
/*  38: 82 */     CALLBACK_POINTER = pointer;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public KHRDebugCallback()
/*  42:    */   {
/*  43: 92 */     this(new Handler()
/*  44:    */     {
/*  45:    */       public void handleMessage(int source, int type, int id, int severity, String message)
/*  46:    */       {
/*  47: 94 */         System.err.println("[LWJGL] KHR_debug message");
/*  48: 95 */         System.err.println("\tID: " + id);
/*  49:    */         String description;
/*  50: 98 */         switch (source)
/*  51:    */         {
/*  52:    */         case 33350: 
/*  53:100 */           description = "API";
/*  54:101 */           break;
/*  55:    */         case 33351: 
/*  56:103 */           description = "WINDOW SYSTEM";
/*  57:104 */           break;
/*  58:    */         case 33352: 
/*  59:106 */           description = "SHADER COMPILER";
/*  60:107 */           break;
/*  61:    */         case 33353: 
/*  62:109 */           description = "THIRD PARTY";
/*  63:110 */           break;
/*  64:    */         case 33354: 
/*  65:112 */           description = "APPLICATION";
/*  66:113 */           break;
/*  67:    */         case 33355: 
/*  68:115 */           description = "OTHER";
/*  69:116 */           break;
/*  70:    */         default: 
/*  71:118 */           description = printUnknownToken(source);
/*  72:    */         }
/*  73:120 */         System.err.println("\tSource: " + description);
/*  74:122 */         switch (type)
/*  75:    */         {
/*  76:    */         case 33356: 
/*  77:124 */           description = "ERROR";
/*  78:125 */           break;
/*  79:    */         case 33357: 
/*  80:127 */           description = "DEPRECATED BEHAVIOR";
/*  81:128 */           break;
/*  82:    */         case 33358: 
/*  83:130 */           description = "UNDEFINED BEHAVIOR";
/*  84:131 */           break;
/*  85:    */         case 33359: 
/*  86:133 */           description = "PORTABILITY";
/*  87:134 */           break;
/*  88:    */         case 33360: 
/*  89:136 */           description = "PERFORMANCE";
/*  90:137 */           break;
/*  91:    */         case 33361: 
/*  92:139 */           description = "OTHER";
/*  93:140 */           break;
/*  94:    */         case 33384: 
/*  95:142 */           description = "MARKER";
/*  96:143 */           break;
/*  97:    */         default: 
/*  98:145 */           description = printUnknownToken(type);
/*  99:    */         }
/* 100:147 */         System.err.println("\tType: " + description);
/* 101:149 */         switch (severity)
/* 102:    */         {
/* 103:    */         case 37190: 
/* 104:151 */           description = "HIGH";
/* 105:152 */           break;
/* 106:    */         case 37191: 
/* 107:154 */           description = "MEDIUM";
/* 108:155 */           break;
/* 109:    */         case 37192: 
/* 110:157 */           description = "LOW";
/* 111:158 */           break;
/* 112:    */         case 33387: 
/* 113:160 */           description = "NOTIFICATION";
/* 114:161 */           break;
/* 115:    */         default: 
/* 116:163 */           description = printUnknownToken(severity);
/* 117:    */         }
/* 118:165 */         System.err.println("\tSeverity: " + description);
/* 119:    */         
/* 120:167 */         System.err.println("\tMessage: " + message);
/* 121:    */       }
/* 122:    */       
/* 123:    */       private String printUnknownToken(int token)
/* 124:    */       {
/* 125:171 */         return "Unknown (0x" + Integer.toHexString(token).toUpperCase() + ")";
/* 126:    */       }
/* 127:    */     });
/* 128:    */   }
/* 129:    */   
/* 130:    */   public KHRDebugCallback(Handler handler)
/* 131:    */   {
/* 132:184 */     super(CALLBACK_POINTER);
/* 133:    */     
/* 134:186 */     this.handler = handler;
/* 135:    */   }
/* 136:    */   
/* 137:    */   Handler getHandler()
/* 138:    */   {
/* 139:190 */     return this.handler;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public static abstract interface Handler
/* 143:    */   {
/* 144:    */     public abstract void handleMessage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString);
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.KHRDebugCallback
 * JD-Core Version:    0.7.0.1
 */