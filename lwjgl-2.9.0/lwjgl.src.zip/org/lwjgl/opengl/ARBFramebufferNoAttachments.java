/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class ARBFramebufferNoAttachments
/*  8:   */ {
/*  9:   */   public static final int GL_FRAMEBUFFER_DEFAULT_WIDTH = 37648;
/* 10:   */   public static final int GL_FRAMEBUFFER_DEFAULT_HEIGHT = 37649;
/* 11:   */   public static final int GL_FRAMEBUFFER_DEFAULT_LAYERS = 37650;
/* 12:   */   public static final int GL_FRAMEBUFFER_DEFAULT_SAMPLES = 37651;
/* 13:   */   public static final int GL_FRAMEBUFFER_DEFAULT_FIXED_SAMPLE_LOCATIONS = 37652;
/* 14:   */   public static final int GL_MAX_FRAMEBUFFER_WIDTH = 37653;
/* 15:   */   public static final int GL_MAX_FRAMEBUFFER_HEIGHT = 37654;
/* 16:   */   public static final int GL_MAX_FRAMEBUFFER_LAYERS = 37655;
/* 17:   */   public static final int GL_MAX_FRAMEBUFFER_SAMPLES = 37656;
/* 18:   */   
/* 19:   */   public static void glFramebufferParameteri(int target, int pname, int param)
/* 20:   */   {
/* 21:33 */     GL43.glFramebufferParameteri(target, pname, param);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glGetFramebufferParameter(int target, int pname, IntBuffer params)
/* 25:   */   {
/* 26:37 */     GL43.glGetFramebufferParameter(target, pname, params);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static int glGetFramebufferParameteri(int target, int pname)
/* 30:   */   {
/* 31:42 */     return GL43.glGetFramebufferParameteri(target, pname);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static void glNamedFramebufferParameteriEXT(int framebuffer, int pname, int param)
/* 35:   */   {
/* 36:46 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 37:47 */     long function_pointer = caps.glNamedFramebufferParameteriEXT;
/* 38:48 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 39:49 */     nglNamedFramebufferParameteriEXT(framebuffer, pname, param, function_pointer);
/* 40:   */   }
/* 41:   */   
/* 42:   */   static native void nglNamedFramebufferParameteriEXT(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 43:   */   
/* 44:   */   public static void glGetNamedFramebufferParameterEXT(int framebuffer, int pname, IntBuffer params)
/* 45:   */   {
/* 46:54 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 47:55 */     long function_pointer = caps.glGetNamedFramebufferParameterivEXT;
/* 48:56 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 49:57 */     BufferChecks.checkBuffer(params, 1);
/* 50:58 */     nglGetNamedFramebufferParameterivEXT(framebuffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 51:   */   }
/* 52:   */   
/* 53:   */   static native void nglGetNamedFramebufferParameterivEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 54:   */   
/* 55:   */   public static int glGetNamedFramebufferParameterEXT(int framebuffer, int pname)
/* 56:   */   {
/* 57:64 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 58:65 */     long function_pointer = caps.glGetNamedFramebufferParameterivEXT;
/* 59:66 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 60:67 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 61:68 */     nglGetNamedFramebufferParameterivEXT(framebuffer, pname, MemoryUtil.getAddress(params), function_pointer);
/* 62:69 */     return params.get(0);
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBFramebufferNoAttachments
 * JD-Core Version:    0.7.0.1
 */