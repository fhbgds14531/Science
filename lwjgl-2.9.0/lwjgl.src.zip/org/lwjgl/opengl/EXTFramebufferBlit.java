/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTFramebufferBlit
/*  6:   */ {
/*  7:   */   public static final int GL_READ_FRAMEBUFFER_EXT = 36008;
/*  8:   */   public static final int GL_DRAW_FRAMEBUFFER_EXT = 36009;
/*  9:   */   public static final int GL_DRAW_FRAMEBUFFER_BINDING_EXT = 36006;
/* 10:   */   public static final int GL_READ_FRAMEBUFFER_BINDING_EXT = 36010;
/* 11:   */   
/* 12:   */   public static void glBlitFramebufferEXT(int srcX0, int srcY0, int srcX1, int srcY1, int dstX0, int dstY0, int dstX1, int dstY1, int mask, int filter)
/* 13:   */   {
/* 14:45 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 15:46 */     long function_pointer = caps.glBlitFramebufferEXT;
/* 16:47 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 17:48 */     nglBlitFramebufferEXT(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglBlitFramebufferEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, long paramLong);
/* 21:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTFramebufferBlit
 * JD-Core Version:    0.7.0.1
 */