/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.FloatBuffer;
/*   4:    */ import java.nio.IntBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ 
/*   8:    */ public final class NVEvaluators
/*   9:    */ {
/*  10:    */   public static final int GL_EVAL_2D_NV = 34496;
/*  11:    */   public static final int GL_EVAL_TRIANGULAR_2D_NV = 34497;
/*  12:    */   public static final int GL_MAP_TESSELLATION_NV = 34498;
/*  13:    */   public static final int GL_MAP_ATTRIB_U_ORDER_NV = 34499;
/*  14:    */   public static final int GL_MAP_ATTRIB_V_ORDER_NV = 34500;
/*  15:    */   public static final int GL_EVAL_FRACTIONAL_TESSELLATION_NV = 34501;
/*  16:    */   public static final int GL_EVAL_VERTEX_ATTRIB0_NV = 34502;
/*  17:    */   public static final int GL_EVAL_VERTEX_ATTRIB1_NV = 34503;
/*  18:    */   public static final int GL_EVAL_VERTEX_ATTRIB2_NV = 34504;
/*  19:    */   public static final int GL_EVAL_VERTEX_ATTRIB3_NV = 34505;
/*  20:    */   public static final int GL_EVAL_VERTEX_ATTRIB4_NV = 34506;
/*  21:    */   public static final int GL_EVAL_VERTEX_ATTRIB5_NV = 34507;
/*  22:    */   public static final int GL_EVAL_VERTEX_ATTRIB6_NV = 34508;
/*  23:    */   public static final int GL_EVAL_VERTEX_ATTRIB7_NV = 34509;
/*  24:    */   public static final int GL_EVAL_VERTEX_ATTRIB8_NV = 34510;
/*  25:    */   public static final int GL_EVAL_VERTEX_ATTRIB9_NV = 34511;
/*  26:    */   public static final int GL_EVAL_VERTEX_ATTRIB10_NV = 34512;
/*  27:    */   public static final int GL_EVAL_VERTEX_ATTRIB11_NV = 34513;
/*  28:    */   public static final int GL_EVAL_VERTEX_ATTRIB12_NV = 34514;
/*  29:    */   public static final int GL_EVAL_VERTEX_ATTRIB13_NV = 34515;
/*  30:    */   public static final int GL_EVAL_VERTEX_ATTRIB14_NV = 34516;
/*  31:    */   public static final int GL_EVAL_VERTEX_ATTRIB15_NV = 34517;
/*  32:    */   public static final int GL_MAX_MAP_TESSELLATION_NV = 34518;
/*  33:    */   public static final int GL_MAX_RATIONAL_EVAL_ORDER_NV = 34519;
/*  34:    */   
/*  35:    */   public static void glGetMapControlPointsNV(int target, int index, int type, int ustride, int vstride, boolean packed, FloatBuffer pPoints)
/*  36:    */   {
/*  37: 38 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  38: 39 */     long function_pointer = caps.glGetMapControlPointsNV;
/*  39: 40 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  40: 41 */     BufferChecks.checkDirect(pPoints);
/*  41: 42 */     nglGetMapControlPointsNV(target, index, type, ustride, vstride, packed, MemoryUtil.getAddress(pPoints), function_pointer);
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native void nglGetMapControlPointsNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, long paramLong1, long paramLong2);
/*  45:    */   
/*  46:    */   public static void glMapControlPointsNV(int target, int index, int type, int ustride, int vstride, int uorder, int vorder, boolean packed, FloatBuffer pPoints)
/*  47:    */   {
/*  48: 47 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  49: 48 */     long function_pointer = caps.glMapControlPointsNV;
/*  50: 49 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  51: 50 */     BufferChecks.checkDirect(pPoints);
/*  52: 51 */     nglMapControlPointsNV(target, index, type, ustride, vstride, uorder, vorder, packed, MemoryUtil.getAddress(pPoints), function_pointer);
/*  53:    */   }
/*  54:    */   
/*  55:    */   static native void nglMapControlPointsNV(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, long paramLong1, long paramLong2);
/*  56:    */   
/*  57:    */   public static void glMapParameterNV(int target, int pname, FloatBuffer params)
/*  58:    */   {
/*  59: 56 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  60: 57 */     long function_pointer = caps.glMapParameterfvNV;
/*  61: 58 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  62: 59 */     BufferChecks.checkBuffer(params, 4);
/*  63: 60 */     nglMapParameterfvNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  64:    */   }
/*  65:    */   
/*  66:    */   static native void nglMapParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  67:    */   
/*  68:    */   public static void glMapParameterNV(int target, int pname, IntBuffer params)
/*  69:    */   {
/*  70: 65 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  71: 66 */     long function_pointer = caps.glMapParameterivNV;
/*  72: 67 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  73: 68 */     BufferChecks.checkBuffer(params, 4);
/*  74: 69 */     nglMapParameterivNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  75:    */   }
/*  76:    */   
/*  77:    */   static native void nglMapParameterivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  78:    */   
/*  79:    */   public static void glGetMapParameterNV(int target, int pname, FloatBuffer params)
/*  80:    */   {
/*  81: 74 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  82: 75 */     long function_pointer = caps.glGetMapParameterfvNV;
/*  83: 76 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  84: 77 */     BufferChecks.checkBuffer(params, 4);
/*  85: 78 */     nglGetMapParameterfvNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  86:    */   }
/*  87:    */   
/*  88:    */   static native void nglGetMapParameterfvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  89:    */   
/*  90:    */   public static void glGetMapParameterNV(int target, int pname, IntBuffer params)
/*  91:    */   {
/*  92: 83 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  93: 84 */     long function_pointer = caps.glGetMapParameterivNV;
/*  94: 85 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  95: 86 */     BufferChecks.checkBuffer(params, 4);
/*  96: 87 */     nglGetMapParameterivNV(target, pname, MemoryUtil.getAddress(params), function_pointer);
/*  97:    */   }
/*  98:    */   
/*  99:    */   static native void nglGetMapParameterivNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 100:    */   
/* 101:    */   public static void glGetMapAttribParameterNV(int target, int index, int pname, FloatBuffer params)
/* 102:    */   {
/* 103: 92 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 104: 93 */     long function_pointer = caps.glGetMapAttribParameterfvNV;
/* 105: 94 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 106: 95 */     BufferChecks.checkBuffer(params, 4);
/* 107: 96 */     nglGetMapAttribParameterfvNV(target, index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 108:    */   }
/* 109:    */   
/* 110:    */   static native void nglGetMapAttribParameterfvNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 111:    */   
/* 112:    */   public static void glGetMapAttribParameterNV(int target, int index, int pname, IntBuffer params)
/* 113:    */   {
/* 114:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:102 */     long function_pointer = caps.glGetMapAttribParameterivNV;
/* 116:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:104 */     BufferChecks.checkBuffer(params, 4);
/* 118:105 */     nglGetMapAttribParameterivNV(target, index, pname, MemoryUtil.getAddress(params), function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   static native void nglGetMapAttribParameterivNV(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 122:    */   
/* 123:    */   public static void glEvalMapsNV(int target, int mode)
/* 124:    */   {
/* 125:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 126:111 */     long function_pointer = caps.glEvalMapsNV;
/* 127:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 128:113 */     nglEvalMapsNV(target, mode, function_pointer);
/* 129:    */   }
/* 130:    */   
/* 131:    */   static native void nglEvalMapsNV(int paramInt1, int paramInt2, long paramLong);
/* 132:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVEvaluators
 * JD-Core Version:    0.7.0.1
 */