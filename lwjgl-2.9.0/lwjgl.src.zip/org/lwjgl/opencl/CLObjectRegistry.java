/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.LWJGLUtil;
/*  4:   */ 
/*  5:   */ class CLObjectRegistry<T extends CLObjectChild>
/*  6:   */ {
/*  7:   */   private FastLongMap<T> registry;
/*  8:   */   
/*  9:   */   final boolean isEmpty()
/* 10:   */   {
/* 11:18 */     return (this.registry == null) || (this.registry.isEmpty());
/* 12:   */   }
/* 13:   */   
/* 14:   */   final T getObject(long id)
/* 15:   */   {
/* 16:22 */     return this.registry == null ? null : (CLObjectChild)this.registry.get(id);
/* 17:   */   }
/* 18:   */   
/* 19:   */   final boolean hasObject(long id)
/* 20:   */   {
/* 21:26 */     return (this.registry != null) && (this.registry.containsKey(id));
/* 22:   */   }
/* 23:   */   
/* 24:   */   final Iterable<FastLongMap.Entry<T>> getAll()
/* 25:   */   {
/* 26:30 */     return this.registry;
/* 27:   */   }
/* 28:   */   
/* 29:   */   void registerObject(T object)
/* 30:   */   {
/* 31:34 */     FastLongMap<T> map = getMap();
/* 32:35 */     Long key = Long.valueOf(object.getPointer());
/* 33:37 */     if ((LWJGLUtil.DEBUG) && (map.containsKey(key.longValue()))) {
/* 34:38 */       throw new IllegalStateException("Duplicate object found: " + object.getClass() + " - " + key);
/* 35:   */     }
/* 36:40 */     getMap().put(object.getPointer(), object);
/* 37:   */   }
/* 38:   */   
/* 39:   */   void unregisterObject(T object)
/* 40:   */   {
/* 41:44 */     getMap().remove(object.getPointerUnsafe());
/* 42:   */   }
/* 43:   */   
/* 44:   */   private FastLongMap<T> getMap()
/* 45:   */   {
/* 46:48 */     if (this.registry == null) {
/* 47:49 */       this.registry = new FastLongMap();
/* 48:   */     }
/* 49:51 */     return this.registry;
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLObjectRegistry
 * JD-Core Version:    0.7.0.1
 */