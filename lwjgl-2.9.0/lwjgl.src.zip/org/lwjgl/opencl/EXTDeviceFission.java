/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import java.nio.LongBuffer;
/*   5:    */ import org.lwjgl.BufferChecks;
/*   6:    */ import org.lwjgl.MemoryUtil;
/*   7:    */ import org.lwjgl.PointerBuffer;
/*   8:    */ 
/*   9:    */ public final class EXTDeviceFission
/*  10:    */ {
/*  11:    */   public static final int CL_DEVICE_PARTITION_EQUALLY_EXT = 16464;
/*  12:    */   public static final int CL_DEVICE_PARTITION_BY_COUNTS_EXT = 16465;
/*  13:    */   public static final int CL_DEVICE_PARTITION_BY_NAMES_EXT = 16466;
/*  14:    */   public static final int CL_DEVICE_PARTITION_BY_AFFINITY_DOMAIN_EXT = 16467;
/*  15:    */   public static final int CL_AFFINITY_DOMAIN_L1_CACHE_EXT = 1;
/*  16:    */   public static final int CL_AFFINITY_DOMAIN_L2_CACHE_EXT = 2;
/*  17:    */   public static final int CL_AFFINITY_DOMAIN_L3_CACHE_EXT = 3;
/*  18:    */   public static final int CL_AFFINITY_DOMAIN_L4_CACHE_EXT = 4;
/*  19:    */   public static final int CL_AFFINITY_DOMAIN_NUMA_EXT = 16;
/*  20:    */   public static final int CL_AFFINITY_DOMAIN_NEXT_FISSIONABLE_EXT = 256;
/*  21:    */   public static final int CL_DEVICE_PARENT_DEVICE_EXT = 16468;
/*  22:    */   public static final int CL_DEVICE_PARITION_TYPES_EXT = 16469;
/*  23:    */   public static final int CL_DEVICE_AFFINITY_DOMAINS_EXT = 16470;
/*  24:    */   public static final int CL_DEVICE_REFERENCE_COUNT_EXT = 16471;
/*  25:    */   public static final int CL_DEVICE_PARTITION_STYLE_EXT = 16472;
/*  26:    */   public static final int CL_PROPERTIES_LIST_END_EXT = 0;
/*  27:    */   public static final int CL_PARTITION_BY_COUNTS_LIST_END_EXT = 0;
/*  28:    */   public static final int CL_PARTITION_BY_NAMES_LIST_END_EXT = -1;
/*  29:    */   public static final int CL_DEVICE_PARTITION_FAILED_EXT = -1057;
/*  30:    */   public static final int CL_INVALID_PARTITION_COUNT_EXT = -1058;
/*  31:    */   public static final int CL_INVALID_PARTITION_NAME_EXT = -1059;
/*  32:    */   
/*  33:    */   public static int clRetainDeviceEXT(CLDevice device)
/*  34:    */   {
/*  35: 82 */     long function_pointer = CLCapabilities.clRetainDeviceEXT;
/*  36: 83 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  37: 84 */     int __result = nclRetainDeviceEXT(device.getPointer(), function_pointer);
/*  38: 85 */     if (__result == 0) {
/*  39: 85 */       device.retain();
/*  40:    */     }
/*  41: 86 */     return __result;
/*  42:    */   }
/*  43:    */   
/*  44:    */   static native int nclRetainDeviceEXT(long paramLong1, long paramLong2);
/*  45:    */   
/*  46:    */   public static int clReleaseDeviceEXT(CLDevice device)
/*  47:    */   {
/*  48: 99 */     long function_pointer = CLCapabilities.clReleaseDeviceEXT;
/*  49:100 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  50:101 */     APIUtil.releaseObjects(device);
/*  51:102 */     int __result = nclReleaseDeviceEXT(device.getPointer(), function_pointer);
/*  52:103 */     if (__result == 0) {
/*  53:103 */       device.release();
/*  54:    */     }
/*  55:104 */     return __result;
/*  56:    */   }
/*  57:    */   
/*  58:    */   static native int nclReleaseDeviceEXT(long paramLong1, long paramLong2);
/*  59:    */   
/*  60:    */   public static int clCreateSubDevicesEXT(CLDevice in_device, LongBuffer properties, PointerBuffer out_devices, IntBuffer num_devices)
/*  61:    */   {
/*  62:109 */     long function_pointer = CLCapabilities.clCreateSubDevicesEXT;
/*  63:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  64:111 */     BufferChecks.checkDirect(properties);
/*  65:112 */     BufferChecks.checkNullTerminated(properties);
/*  66:113 */     if (out_devices != null) {
/*  67:114 */       BufferChecks.checkDirect(out_devices);
/*  68:    */     }
/*  69:115 */     if (num_devices != null) {
/*  70:116 */       BufferChecks.checkBuffer(num_devices, 1);
/*  71:    */     }
/*  72:117 */     int __result = nclCreateSubDevicesEXT(in_device.getPointer(), MemoryUtil.getAddress(properties), out_devices == null ? 0 : out_devices.remaining(), MemoryUtil.getAddressSafe(out_devices), MemoryUtil.getAddressSafe(num_devices), function_pointer);
/*  73:118 */     if ((__result == 0) && (out_devices != null)) {
/*  74:118 */       in_device.registerSubCLDevices(out_devices);
/*  75:    */     }
/*  76:119 */     return __result;
/*  77:    */   }
/*  78:    */   
/*  79:    */   static native int nclCreateSubDevicesEXT(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/*  80:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.EXTDeviceFission
 * JD-Core Version:    0.7.0.1
 */