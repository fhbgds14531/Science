/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTCompiledVertexArray
/*  6:   */ {
/*  7:   */   public static final int GL_ARRAY_ELEMENT_LOCK_FIRST_EXT = 33192;
/*  8:   */   public static final int GL_ARRAY_ELEMENT_LOCK_COUNT_EXT = 33193;
/*  9:   */   
/* 10:   */   public static void glLockArraysEXT(int first, int count)
/* 11:   */   {
/* 12:16 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:17 */     long function_pointer = caps.glLockArraysEXT;
/* 14:18 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:19 */     nglLockArraysEXT(first, count, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglLockArraysEXT(int paramInt1, int paramInt2, long paramLong);
/* 19:   */   
/* 20:   */   public static void glUnlockArraysEXT()
/* 21:   */   {
/* 22:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:25 */     long function_pointer = caps.glUnlockArraysEXT;
/* 24:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:27 */     nglUnlockArraysEXT(function_pointer);
/* 26:   */   }
/* 27:   */   
/* 28:   */   static native void nglUnlockArraysEXT(long paramLong);
/* 29:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTCompiledVertexArray
 * JD-Core Version:    0.7.0.1
 */