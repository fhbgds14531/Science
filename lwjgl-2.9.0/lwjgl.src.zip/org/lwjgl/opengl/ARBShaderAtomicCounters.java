/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ 
/*  5:   */ public final class ARBShaderAtomicCounters
/*  6:   */ {
/*  7:   */   public static final int GL_ATOMIC_COUNTER_BUFFER = 37568;
/*  8:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_BINDING = 37569;
/*  9:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_START = 37570;
/* 10:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_SIZE = 37571;
/* 11:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_DATA_SIZE = 37572;
/* 12:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_ACTIVE_ATOMIC_COUNTERS = 37573;
/* 13:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_ACTIVE_ATOMIC_COUNTER_INDICES = 37574;
/* 14:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_VERTEX_SHADER = 37575;
/* 15:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TESS_CONTROL_SHADER = 37576;
/* 16:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_TESS_EVALUATION_SHADER = 37577;
/* 17:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_GEOMETRY_SHADER = 37578;
/* 18:   */   public static final int GL_ATOMIC_COUNTER_BUFFER_REFERENCED_BY_FRAGMENT_SHADER = 37579;
/* 19:   */   public static final int GL_MAX_VERTEX_ATOMIC_COUNTER_BUFFERS = 37580;
/* 20:   */   public static final int GL_MAX_TESS_CONTROL_ATOMIC_COUNTER_BUFFERS = 37581;
/* 21:   */   public static final int GL_MAX_TESS_EVALUATION_ATOMIC_COUNTER_BUFFERS = 37582;
/* 22:   */   public static final int GL_MAX_GEOMETRY_ATOMIC_COUNTER_BUFFERS = 37583;
/* 23:   */   public static final int GL_MAX_FRAGMENT_ATOMIC_COUNTER_BUFFERS = 37584;
/* 24:   */   public static final int GL_MAX_COMBINED_ATOMIC_COUNTER_BUFFERS = 37585;
/* 25:   */   public static final int GL_MAX_VERTEX_ATOMIC_COUNTERS = 37586;
/* 26:   */   public static final int GL_MAX_TESS_CONTROL_ATOMIC_COUNTERS = 37587;
/* 27:   */   public static final int GL_MAX_TESS_EVALUATION_ATOMIC_COUNTERS = 37588;
/* 28:   */   public static final int GL_MAX_GEOMETRY_ATOMIC_COUNTERS = 37589;
/* 29:   */   public static final int GL_MAX_FRAGMENT_ATOMIC_COUNTERS = 37590;
/* 30:   */   public static final int GL_MAX_COMBINED_ATOMIC_COUNTERS = 37591;
/* 31:   */   public static final int GL_MAX_ATOMIC_COUNTER_BUFFER_SIZE = 37592;
/* 32:   */   public static final int GL_MAX_ATOMIC_COUNTER_BUFFER_BINDINGS = 37596;
/* 33:   */   public static final int GL_ACTIVE_ATOMIC_COUNTER_BUFFERS = 37593;
/* 34:   */   public static final int GL_UNIFORM_ATOMIC_COUNTER_BUFFER_INDEX = 37594;
/* 35:   */   public static final int GL_UNSIGNED_INT_ATOMIC_COUNTER = 37595;
/* 36:   */   
/* 37:   */   public static void glGetActiveAtomicCounterBuffer(int program, int bufferIndex, int pname, IntBuffer params)
/* 38:   */   {
/* 39:77 */     GL42.glGetActiveAtomicCounterBuffer(program, bufferIndex, pname, params);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static int glGetActiveAtomicCounterBuffer(int program, int bufferIndex, int pname)
/* 43:   */   {
/* 44:82 */     return GL42.glGetActiveAtomicCounterBuffer(program, bufferIndex, pname);
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBShaderAtomicCounters
 * JD-Core Version:    0.7.0.1
 */