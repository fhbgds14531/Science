/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerWrapperAbstract;
/*  4:   */ 
/*  5:   */ public abstract class CLPrintfCallback
/*  6:   */   extends PointerWrapperAbstract
/*  7:   */ {
/*  8:   */   protected CLPrintfCallback()
/*  9:   */   {
/* 10:45 */     super(CallbackUtil.getPrintfCallback());
/* 11:   */   }
/* 12:   */   
/* 13:   */   protected abstract void handleMessage(String paramString);
/* 14:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.CLPrintfCallback
 * JD-Core Version:    0.7.0.1
 */