/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.DoubleBuffer;
/*  5:   */ import java.nio.FloatBuffer;
/*  6:   */ import java.nio.IntBuffer;
/*  7:   */ import java.nio.ShortBuffer;
/*  8:   */ import org.lwjgl.BufferChecks;
/*  9:   */ import org.lwjgl.MemoryUtil;
/* 10:   */ 
/* 11:   */ public final class NVPixelDataRange
/* 12:   */ {
/* 13:   */   public static final int GL_WRITE_PIXEL_DATA_RANGE_NV = 34936;
/* 14:   */   public static final int GL_READ_PIXEL_DATA_RANGE_NV = 34937;
/* 15:   */   public static final int GL_WRITE_PIXEL_DATA_RANGE_LENGTH_NV = 34938;
/* 16:   */   public static final int GL_READ_PIXEL_DATA_RANGE_LENGTH_NV = 34939;
/* 17:   */   public static final int GL_WRITE_PIXEL_DATA_RANGE_POINTER_NV = 34940;
/* 18:   */   public static final int GL_READ_PIXEL_DATA_RANGE_POINTER_NV = 34941;
/* 19:   */   
/* 20:   */   public static void glPixelDataRangeNV(int target, ByteBuffer data)
/* 21:   */   {
/* 22:34 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 23:35 */     long function_pointer = caps.glPixelDataRangeNV;
/* 24:36 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 25:37 */     BufferChecks.checkDirect(data);
/* 26:38 */     nglPixelDataRangeNV(target, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public static void glPixelDataRangeNV(int target, DoubleBuffer data)
/* 30:   */   {
/* 31:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 32:42 */     long function_pointer = caps.glPixelDataRangeNV;
/* 33:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 34:44 */     BufferChecks.checkDirect(data);
/* 35:45 */     nglPixelDataRangeNV(target, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static void glPixelDataRangeNV(int target, FloatBuffer data)
/* 39:   */   {
/* 40:48 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 41:49 */     long function_pointer = caps.glPixelDataRangeNV;
/* 42:50 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 43:51 */     BufferChecks.checkDirect(data);
/* 44:52 */     nglPixelDataRangeNV(target, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public static void glPixelDataRangeNV(int target, IntBuffer data)
/* 48:   */   {
/* 49:55 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 50:56 */     long function_pointer = caps.glPixelDataRangeNV;
/* 51:57 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 52:58 */     BufferChecks.checkDirect(data);
/* 53:59 */     nglPixelDataRangeNV(target, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 54:   */   }
/* 55:   */   
/* 56:   */   public static void glPixelDataRangeNV(int target, ShortBuffer data)
/* 57:   */   {
/* 58:62 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 59:63 */     long function_pointer = caps.glPixelDataRangeNV;
/* 60:64 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 61:65 */     BufferChecks.checkDirect(data);
/* 62:66 */     nglPixelDataRangeNV(target, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 63:   */   }
/* 64:   */   
/* 65:   */   static native void nglPixelDataRangeNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 66:   */   
/* 67:   */   public static void glFlushPixelDataRangeNV(int target)
/* 68:   */   {
/* 69:71 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 70:72 */     long function_pointer = caps.glFlushPixelDataRangeNV;
/* 71:73 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 72:74 */     nglFlushPixelDataRangeNV(target, function_pointer);
/* 73:   */   }
/* 74:   */   
/* 75:   */   static native void nglFlushPixelDataRangeNV(int paramInt, long paramLong);
/* 76:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVPixelDataRange
 * JD-Core Version:    0.7.0.1
 */