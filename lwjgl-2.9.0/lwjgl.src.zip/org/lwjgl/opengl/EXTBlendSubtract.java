package org.lwjgl.opengl;

public final class EXTBlendSubtract
{
  public static final int GL_FUNC_SUBTRACT_EXT = 32778;
  public static final int GL_FUNC_REVERSE_SUBTRACT_EXT = 32779;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTBlendSubtract
 * JD-Core Version:    0.7.0.1
 */