/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class NVTextureBarrier
/*  6:   */ {
/*  7:   */   public static void glTextureBarrierNV()
/*  8:   */   {
/*  9:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 10:14 */     long function_pointer = caps.glTextureBarrierNV;
/* 11:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 12:16 */     nglTextureBarrierNV(function_pointer);
/* 13:   */   }
/* 14:   */   
/* 15:   */   static native void nglTextureBarrierNV(long paramLong);
/* 16:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTextureBarrier
 * JD-Core Version:    0.7.0.1
 */