/*   1:    */ package org.lwjgl.opencl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import java.nio.LongBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import java.util.HashSet;
/*  10:    */ import java.util.Set;
/*  11:    */ import java.util.StringTokenizer;
/*  12:    */ import org.lwjgl.BufferUtils;
/*  13:    */ import org.lwjgl.LWJGLUtil;
/*  14:    */ import org.lwjgl.MemoryUtil;
/*  15:    */ import org.lwjgl.PointerBuffer;
/*  16:    */ import org.lwjgl.PointerWrapper;
/*  17:    */ 
/*  18:    */ final class APIUtil
/*  19:    */ {
/*  20:    */   private static final int INITIAL_BUFFER_SIZE = 256;
/*  21:    */   private static final int INITIAL_LENGTHS_SIZE = 4;
/*  22:    */   private static final int BUFFERS_SIZE = 32;
/*  23: 59 */   private static final ThreadLocal<char[]> arrayTL = new ThreadLocal()
/*  24:    */   {
/*  25:    */     protected char[] initialValue()
/*  26:    */     {
/*  27: 60 */       return new char[256];
/*  28:    */     }
/*  29:    */   };
/*  30: 63 */   private static final ThreadLocal<ByteBuffer> bufferByteTL = new ThreadLocal()
/*  31:    */   {
/*  32:    */     protected ByteBuffer initialValue()
/*  33:    */     {
/*  34: 64 */       return BufferUtils.createByteBuffer(256);
/*  35:    */     }
/*  36:    */   };
/*  37: 67 */   private static final ThreadLocal<PointerBuffer> bufferPointerTL = new ThreadLocal()
/*  38:    */   {
/*  39:    */     protected PointerBuffer initialValue()
/*  40:    */     {
/*  41: 68 */       return BufferUtils.createPointerBuffer(256);
/*  42:    */     }
/*  43:    */   };
/*  44: 71 */   private static final ThreadLocal<PointerBuffer> lengthsTL = new ThreadLocal()
/*  45:    */   {
/*  46:    */     protected PointerBuffer initialValue()
/*  47:    */     {
/*  48: 72 */       return BufferUtils.createPointerBuffer(4);
/*  49:    */     }
/*  50:    */   };
/*  51: 75 */   private static final ThreadLocal<Buffers> buffersTL = new ThreadLocal()
/*  52:    */   {
/*  53:    */     protected APIUtil.Buffers initialValue()
/*  54:    */     {
/*  55: 76 */       return new APIUtil.Buffers();
/*  56:    */     }
/*  57:    */   };
/*  58:    */   
/*  59:    */   private static char[] getArray(int size)
/*  60:    */   {
/*  61: 83 */     char[] array = (char[])arrayTL.get();
/*  62: 85 */     if (array.length < size)
/*  63:    */     {
/*  64: 86 */       int sizeNew = array.length << 1;
/*  65: 87 */       while (sizeNew < size) {
/*  66: 88 */         sizeNew <<= 1;
/*  67:    */       }
/*  68: 90 */       array = new char[size];
/*  69: 91 */       arrayTL.set(array);
/*  70:    */     }
/*  71: 94 */     return array;
/*  72:    */   }
/*  73:    */   
/*  74:    */   static ByteBuffer getBufferByte(int size)
/*  75:    */   {
/*  76: 98 */     ByteBuffer buffer = (ByteBuffer)bufferByteTL.get();
/*  77:100 */     if (buffer.capacity() < size)
/*  78:    */     {
/*  79:101 */       int sizeNew = buffer.capacity() << 1;
/*  80:102 */       while (sizeNew < size) {
/*  81:103 */         sizeNew <<= 1;
/*  82:    */       }
/*  83:105 */       buffer = BufferUtils.createByteBuffer(size);
/*  84:106 */       bufferByteTL.set(buffer);
/*  85:    */     }
/*  86:    */     else
/*  87:    */     {
/*  88:108 */       buffer.clear();
/*  89:    */     }
/*  90:110 */     return buffer;
/*  91:    */   }
/*  92:    */   
/*  93:    */   private static ByteBuffer getBufferByteOffset(int size)
/*  94:    */   {
/*  95:114 */     ByteBuffer buffer = (ByteBuffer)bufferByteTL.get();
/*  96:116 */     if (buffer.capacity() < size)
/*  97:    */     {
/*  98:117 */       int sizeNew = buffer.capacity() << 1;
/*  99:118 */       while (sizeNew < size) {
/* 100:119 */         sizeNew <<= 1;
/* 101:    */       }
/* 102:121 */       ByteBuffer bufferNew = BufferUtils.createByteBuffer(size);
/* 103:122 */       bufferNew.put(buffer);
/* 104:123 */       bufferByteTL.set(buffer = bufferNew);
/* 105:    */     }
/* 106:    */     else
/* 107:    */     {
/* 108:125 */       buffer.position(buffer.limit());
/* 109:126 */       buffer.limit(buffer.capacity());
/* 110:    */     }
/* 111:129 */     return buffer;
/* 112:    */   }
/* 113:    */   
/* 114:    */   static PointerBuffer getBufferPointer(int size)
/* 115:    */   {
/* 116:133 */     PointerBuffer buffer = (PointerBuffer)bufferPointerTL.get();
/* 117:135 */     if (buffer.capacity() < size)
/* 118:    */     {
/* 119:136 */       int sizeNew = buffer.capacity() << 1;
/* 120:137 */       while (sizeNew < size) {
/* 121:138 */         sizeNew <<= 1;
/* 122:    */       }
/* 123:140 */       buffer = BufferUtils.createPointerBuffer(size);
/* 124:141 */       bufferPointerTL.set(buffer);
/* 125:    */     }
/* 126:    */     else
/* 127:    */     {
/* 128:143 */       buffer.clear();
/* 129:    */     }
/* 130:145 */     return buffer;
/* 131:    */   }
/* 132:    */   
/* 133:    */   static ShortBuffer getBufferShort()
/* 134:    */   {
/* 135:148 */     return ((Buffers)buffersTL.get()).shorts;
/* 136:    */   }
/* 137:    */   
/* 138:    */   static IntBuffer getBufferInt()
/* 139:    */   {
/* 140:150 */     return ((Buffers)buffersTL.get()).ints;
/* 141:    */   }
/* 142:    */   
/* 143:    */   static IntBuffer getBufferIntDebug()
/* 144:    */   {
/* 145:152 */     return ((Buffers)buffersTL.get()).intsDebug;
/* 146:    */   }
/* 147:    */   
/* 148:    */   static LongBuffer getBufferLong()
/* 149:    */   {
/* 150:154 */     return ((Buffers)buffersTL.get()).longs;
/* 151:    */   }
/* 152:    */   
/* 153:    */   static FloatBuffer getBufferFloat()
/* 154:    */   {
/* 155:156 */     return ((Buffers)buffersTL.get()).floats;
/* 156:    */   }
/* 157:    */   
/* 158:    */   static DoubleBuffer getBufferDouble()
/* 159:    */   {
/* 160:158 */     return ((Buffers)buffersTL.get()).doubles;
/* 161:    */   }
/* 162:    */   
/* 163:    */   static PointerBuffer getBufferPointer()
/* 164:    */   {
/* 165:160 */     return ((Buffers)buffersTL.get()).pointers;
/* 166:    */   }
/* 167:    */   
/* 168:    */   static PointerBuffer getLengths()
/* 169:    */   {
/* 170:163 */     return getLengths(1);
/* 171:    */   }
/* 172:    */   
/* 173:    */   static PointerBuffer getLengths(int size)
/* 174:    */   {
/* 175:167 */     PointerBuffer lengths = (PointerBuffer)lengthsTL.get();
/* 176:169 */     if (lengths.capacity() < size)
/* 177:    */     {
/* 178:170 */       int sizeNew = lengths.capacity();
/* 179:171 */       while (sizeNew < size) {
/* 180:172 */         sizeNew <<= 1;
/* 181:    */       }
/* 182:174 */       lengths = BufferUtils.createPointerBuffer(size);
/* 183:175 */       lengthsTL.set(lengths);
/* 184:    */     }
/* 185:    */     else
/* 186:    */     {
/* 187:177 */       lengths.clear();
/* 188:    */     }
/* 189:179 */     return lengths;
/* 190:    */   }
/* 191:    */   
/* 192:    */   private static ByteBuffer encode(ByteBuffer buffer, CharSequence string)
/* 193:    */   {
/* 194:189 */     for (int i = 0; i < string.length(); i++)
/* 195:    */     {
/* 196:190 */       char c = string.charAt(i);
/* 197:191 */       if ((LWJGLUtil.DEBUG) && ('' <= c)) {
/* 198:192 */         buffer.put((byte)26);
/* 199:    */       } else {
/* 200:194 */         buffer.put((byte)c);
/* 201:    */       }
/* 202:    */     }
/* 203:197 */     return buffer;
/* 204:    */   }
/* 205:    */   
/* 206:    */   static String getString(ByteBuffer buffer)
/* 207:    */   {
/* 208:208 */     int length = buffer.remaining();
/* 209:209 */     char[] charArray = getArray(length);
/* 210:211 */     for (int i = buffer.position(); i < buffer.limit(); i++) {
/* 211:212 */       charArray[(i - buffer.position())] = ((char)buffer.get(i));
/* 212:    */     }
/* 213:214 */     return new String(charArray, 0, length);
/* 214:    */   }
/* 215:    */   
/* 216:    */   static long getBuffer(CharSequence string)
/* 217:    */   {
/* 218:225 */     ByteBuffer buffer = encode(getBufferByte(string.length()), string);
/* 219:226 */     buffer.flip();
/* 220:227 */     return MemoryUtil.getAddress0(buffer);
/* 221:    */   }
/* 222:    */   
/* 223:    */   static long getBuffer(CharSequence string, int offset)
/* 224:    */   {
/* 225:238 */     ByteBuffer buffer = encode(getBufferByteOffset(offset + string.length()), string);
/* 226:239 */     buffer.flip();
/* 227:240 */     return MemoryUtil.getAddress(buffer);
/* 228:    */   }
/* 229:    */   
/* 230:    */   static long getBufferNT(CharSequence string)
/* 231:    */   {
/* 232:251 */     ByteBuffer buffer = encode(getBufferByte(string.length() + 1), string);
/* 233:252 */     buffer.put((byte)0);
/* 234:253 */     buffer.flip();
/* 235:254 */     return MemoryUtil.getAddress0(buffer);
/* 236:    */   }
/* 237:    */   
/* 238:    */   static int getTotalLength(CharSequence[] strings)
/* 239:    */   {
/* 240:258 */     int length = 0;
/* 241:259 */     for (CharSequence string : strings) {
/* 242:260 */       length += string.length();
/* 243:    */     }
/* 244:262 */     return length;
/* 245:    */   }
/* 246:    */   
/* 247:    */   static long getBuffer(CharSequence[] strings)
/* 248:    */   {
/* 249:273 */     ByteBuffer buffer = getBufferByte(getTotalLength(strings));
/* 250:275 */     for (CharSequence string : strings) {
/* 251:276 */       encode(buffer, string);
/* 252:    */     }
/* 253:278 */     buffer.flip();
/* 254:279 */     return MemoryUtil.getAddress0(buffer);
/* 255:    */   }
/* 256:    */   
/* 257:    */   static long getBufferNT(CharSequence[] strings)
/* 258:    */   {
/* 259:290 */     ByteBuffer buffer = getBufferByte(getTotalLength(strings) + strings.length);
/* 260:292 */     for (CharSequence string : strings)
/* 261:    */     {
/* 262:293 */       encode(buffer, string);
/* 263:294 */       buffer.put((byte)0);
/* 264:    */     }
/* 265:297 */     buffer.flip();
/* 266:298 */     return MemoryUtil.getAddress0(buffer);
/* 267:    */   }
/* 268:    */   
/* 269:    */   static long getLengths(CharSequence[] strings)
/* 270:    */   {
/* 271:309 */     PointerBuffer buffer = getLengths(strings.length);
/* 272:311 */     for (CharSequence string : strings) {
/* 273:312 */       buffer.put(string.length());
/* 274:    */     }
/* 275:314 */     buffer.flip();
/* 276:315 */     return MemoryUtil.getAddress0(buffer);
/* 277:    */   }
/* 278:    */   
/* 279:    */   static long getLengths(ByteBuffer[] buffers)
/* 280:    */   {
/* 281:326 */     PointerBuffer lengths = getLengths(buffers.length);
/* 282:328 */     for (ByteBuffer buffer : buffers) {
/* 283:329 */       lengths.put(buffer.remaining());
/* 284:    */     }
/* 285:331 */     lengths.flip();
/* 286:332 */     return MemoryUtil.getAddress0(lengths);
/* 287:    */   }
/* 288:    */   
/* 289:    */   static int getSize(PointerBuffer lengths)
/* 290:    */   {
/* 291:336 */     long size = 0L;
/* 292:337 */     for (int i = lengths.position(); i < lengths.limit(); i++) {
/* 293:338 */       size += lengths.get(i);
/* 294:    */     }
/* 295:340 */     return (int)size;
/* 296:    */   }
/* 297:    */   
/* 298:    */   static long getPointer(PointerWrapper pointer)
/* 299:    */   {
/* 300:344 */     return MemoryUtil.getAddress0(getBufferPointer().put(0, pointer));
/* 301:    */   }
/* 302:    */   
/* 303:    */   static long getPointerSafe(PointerWrapper pointer)
/* 304:    */   {
/* 305:348 */     return MemoryUtil.getAddress0(getBufferPointer().put(0, pointer == null ? 0L : pointer.getPointer()));
/* 306:    */   }
/* 307:    */   
/* 308:    */   private static abstract interface ObjectDestructor<T extends CLObjectChild>
/* 309:    */   {
/* 310:    */     public abstract void release(T paramT);
/* 311:    */   }
/* 312:    */   
/* 313:    */   private static class Buffers
/* 314:    */   {
/* 315:    */     final ShortBuffer shorts;
/* 316:    */     final IntBuffer ints;
/* 317:    */     final IntBuffer intsDebug;
/* 318:    */     final LongBuffer longs;
/* 319:    */     final FloatBuffer floats;
/* 320:    */     final DoubleBuffer doubles;
/* 321:    */     final PointerBuffer pointers;
/* 322:    */     
/* 323:    */     Buffers()
/* 324:    */     {
/* 325:364 */       this.shorts = BufferUtils.createShortBuffer(32);
/* 326:365 */       this.ints = BufferUtils.createIntBuffer(32);
/* 327:366 */       this.intsDebug = BufferUtils.createIntBuffer(1);
/* 328:367 */       this.longs = BufferUtils.createLongBuffer(32);
/* 329:    */       
/* 330:369 */       this.floats = BufferUtils.createFloatBuffer(32);
/* 331:370 */       this.doubles = BufferUtils.createDoubleBuffer(32);
/* 332:    */       
/* 333:372 */       this.pointers = BufferUtils.createPointerBuffer(32);
/* 334:    */     }
/* 335:    */   }
/* 336:    */   
/* 337:    */   static Set<String> getExtensions(String extensionList)
/* 338:    */   {
/* 339:384 */     Set<String> extensions = new HashSet();
/* 340:386 */     if (extensionList != null)
/* 341:    */     {
/* 342:387 */       StringTokenizer tokenizer = new StringTokenizer(extensionList);
/* 343:388 */       while (tokenizer.hasMoreTokens()) {
/* 344:389 */         extensions.add(tokenizer.nextToken());
/* 345:    */       }
/* 346:    */     }
/* 347:392 */     return extensions;
/* 348:    */   }
/* 349:    */   
/* 350:    */   static boolean isDevicesParam(int param_name)
/* 351:    */   {
/* 352:396 */     switch (param_name)
/* 353:    */     {
/* 354:    */     case 4225: 
/* 355:    */     case 8198: 
/* 356:    */     case 8199: 
/* 357:    */     case 268435458: 
/* 358:    */     case 268435459: 
/* 359:402 */       return true;
/* 360:    */     }
/* 361:405 */     return false;
/* 362:    */   }
/* 363:    */   
/* 364:    */   static CLPlatform getCLPlatform(PointerBuffer properties)
/* 365:    */   {
/* 366:409 */     long platformID = 0L;
/* 367:    */     
/* 368:411 */     int keys = properties.remaining() / 2;
/* 369:412 */     for (int k = 0; k < keys; k++)
/* 370:    */     {
/* 371:413 */       long key = properties.get(k << 1);
/* 372:414 */       if (key == 0L) {
/* 373:    */         break;
/* 374:    */       }
/* 375:417 */       if (key == 4228L)
/* 376:    */       {
/* 377:418 */         platformID = properties.get((k << 1) + 1);
/* 378:419 */         break;
/* 379:    */       }
/* 380:    */     }
/* 381:423 */     if (platformID == 0L) {
/* 382:424 */       throw new IllegalArgumentException("Could not find CL_CONTEXT_PLATFORM in cl_context_properties.");
/* 383:    */     }
/* 384:426 */     CLPlatform platform = CLPlatform.getCLPlatform(platformID);
/* 385:427 */     if (platform == null) {
/* 386:428 */       throw new IllegalStateException("Could not find a valid CLPlatform. Make sure clGetPlatformIDs has been used before.");
/* 387:    */     }
/* 388:430 */     return platform;
/* 389:    */   }
/* 390:    */   
/* 391:    */   static ByteBuffer getNativeKernelArgs(long user_func_ref, CLMem[] clMems, long[] sizes)
/* 392:    */   {
/* 393:434 */     ByteBuffer args = getBufferByte(12 + (clMems == null ? 0 : clMems.length * (4 + PointerBuffer.getPointerSize())));
/* 394:    */     
/* 395:436 */     args.putLong(0, user_func_ref);
/* 396:437 */     if (clMems == null)
/* 397:    */     {
/* 398:438 */       args.putInt(8, 0);
/* 399:    */     }
/* 400:    */     else
/* 401:    */     {
/* 402:440 */       args.putInt(8, clMems.length);
/* 403:441 */       int byteIndex = 12;
/* 404:442 */       for (int i = 0; i < clMems.length; i++)
/* 405:    */       {
/* 406:443 */         if ((LWJGLUtil.DEBUG) && (!clMems[i].isValid())) {
/* 407:444 */           throw new IllegalArgumentException("An invalid CLMem object was specified.");
/* 408:    */         }
/* 409:445 */         args.putInt(byteIndex, (int)sizes[i]);
/* 410:446 */         byteIndex += 4 + PointerBuffer.getPointerSize();
/* 411:    */       }
/* 412:    */     }
/* 413:450 */     return args;
/* 414:    */   }
/* 415:    */   
/* 416:    */   static void releaseObjects(CLDevice device)
/* 417:    */   {
/* 418:462 */     if ((!device.isValid()) || (device.getReferenceCount() > 1)) {
/* 419:463 */       return;
/* 420:    */     }
/* 421:465 */     releaseObjects(device.getSubCLDeviceRegistry(), DESTRUCTOR_CLSubDevice);
/* 422:    */   }
/* 423:    */   
/* 424:    */   static void releaseObjects(CLContext context)
/* 425:    */   {
/* 426:475 */     if ((!context.isValid()) || (context.getReferenceCount() > 1)) {
/* 427:476 */       return;
/* 428:    */     }
/* 429:478 */     releaseObjects(context.getCLEventRegistry(), DESTRUCTOR_CLEvent);
/* 430:479 */     releaseObjects(context.getCLProgramRegistry(), DESTRUCTOR_CLProgram);
/* 431:480 */     releaseObjects(context.getCLSamplerRegistry(), DESTRUCTOR_CLSampler);
/* 432:481 */     releaseObjects(context.getCLMemRegistry(), DESTRUCTOR_CLMem);
/* 433:482 */     releaseObjects(context.getCLCommandQueueRegistry(), DESTRUCTOR_CLCommandQueue);
/* 434:    */   }
/* 435:    */   
/* 436:    */   static void releaseObjects(CLProgram program)
/* 437:    */   {
/* 438:492 */     if ((!program.isValid()) || (program.getReferenceCount() > 1)) {
/* 439:493 */       return;
/* 440:    */     }
/* 441:495 */     releaseObjects(program.getCLKernelRegistry(), DESTRUCTOR_CLKernel);
/* 442:    */   }
/* 443:    */   
/* 444:    */   static void releaseObjects(CLCommandQueue queue)
/* 445:    */   {
/* 446:505 */     if ((!queue.isValid()) || (queue.getReferenceCount() > 1)) {
/* 447:506 */       return;
/* 448:    */     }
/* 449:508 */     releaseObjects(queue.getCLEventRegistry(), DESTRUCTOR_CLEvent);
/* 450:    */   }
/* 451:    */   
/* 452:    */   private static <T extends CLObjectChild> void releaseObjects(CLObjectRegistry<T> registry, ObjectDestructor<T> destructor)
/* 453:    */   {
/* 454:512 */     if (registry.isEmpty()) {
/* 455:513 */       return;
/* 456:    */     }
/* 457:515 */     for (FastLongMap.Entry<T> entry : registry.getAll())
/* 458:    */     {
/* 459:516 */       T object = (CLObjectChild)entry.value;
/* 460:517 */       while (object.isValid()) {
/* 461:518 */         destructor.release(object);
/* 462:    */       }
/* 463:    */     }
/* 464:    */   }
/* 465:    */   
/* 466:522 */   private static final ObjectDestructor<CLDevice> DESTRUCTOR_CLSubDevice = new ObjectDestructor()
/* 467:    */   {
/* 468:    */     public void release(CLDevice object)
/* 469:    */     {
/* 470:523 */       EXTDeviceFission.clReleaseDeviceEXT(object);
/* 471:    */     }
/* 472:    */   };
/* 473:525 */   private static final ObjectDestructor<CLMem> DESTRUCTOR_CLMem = new ObjectDestructor()
/* 474:    */   {
/* 475:    */     public void release(CLMem object)
/* 476:    */     {
/* 477:526 */       CL10.clReleaseMemObject(object);
/* 478:    */     }
/* 479:    */   };
/* 480:528 */   private static final ObjectDestructor<CLCommandQueue> DESTRUCTOR_CLCommandQueue = new ObjectDestructor()
/* 481:    */   {
/* 482:    */     public void release(CLCommandQueue object)
/* 483:    */     {
/* 484:529 */       CL10.clReleaseCommandQueue(object);
/* 485:    */     }
/* 486:    */   };
/* 487:531 */   private static final ObjectDestructor<CLSampler> DESTRUCTOR_CLSampler = new ObjectDestructor()
/* 488:    */   {
/* 489:    */     public void release(CLSampler object)
/* 490:    */     {
/* 491:532 */       CL10.clReleaseSampler(object);
/* 492:    */     }
/* 493:    */   };
/* 494:534 */   private static final ObjectDestructor<CLProgram> DESTRUCTOR_CLProgram = new ObjectDestructor()
/* 495:    */   {
/* 496:    */     public void release(CLProgram object)
/* 497:    */     {
/* 498:535 */       CL10.clReleaseProgram(object);
/* 499:    */     }
/* 500:    */   };
/* 501:537 */   private static final ObjectDestructor<CLKernel> DESTRUCTOR_CLKernel = new ObjectDestructor()
/* 502:    */   {
/* 503:    */     public void release(CLKernel object)
/* 504:    */     {
/* 505:538 */       CL10.clReleaseKernel(object);
/* 506:    */     }
/* 507:    */   };
/* 508:540 */   private static final ObjectDestructor<CLEvent> DESTRUCTOR_CLEvent = new ObjectDestructor()
/* 509:    */   {
/* 510:    */     public void release(CLEvent object)
/* 511:    */     {
/* 512:541 */       CL10.clReleaseEvent(object);
/* 513:    */     }
/* 514:    */   };
/* 515:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.APIUtil
 * JD-Core Version:    0.7.0.1
 */