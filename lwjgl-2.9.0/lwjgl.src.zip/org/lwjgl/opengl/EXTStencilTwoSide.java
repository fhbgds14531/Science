/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTStencilTwoSide
/*  6:   */ {
/*  7:   */   public static final int GL_STENCIL_TEST_TWO_SIDE_EXT = 35088;
/*  8:   */   public static final int GL_ACTIVE_STENCIL_FACE_EXT = 35089;
/*  9:   */   
/* 10:   */   public static void glActiveStencilFaceEXT(int face)
/* 11:   */   {
/* 12:16 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:17 */     long function_pointer = caps.glActiveStencilFaceEXT;
/* 14:18 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:19 */     nglActiveStencilFaceEXT(face, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglActiveStencilFaceEXT(int paramInt, long paramLong);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTStencilTwoSide
 * JD-Core Version:    0.7.0.1
 */