/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.ByteOrder;
/*   5:    */ import java.nio.DoubleBuffer;
/*   6:    */ import java.nio.FloatBuffer;
/*   7:    */ import java.nio.IntBuffer;
/*   8:    */ import java.nio.ShortBuffer;
/*   9:    */ import org.lwjgl.BufferChecks;
/*  10:    */ import org.lwjgl.LWJGLUtil;
/*  11:    */ import org.lwjgl.MemoryUtil;
/*  12:    */ 
/*  13:    */ public class ARBBufferObject
/*  14:    */ {
/*  15:    */   public static final int GL_STREAM_DRAW_ARB = 35040;
/*  16:    */   public static final int GL_STREAM_READ_ARB = 35041;
/*  17:    */   public static final int GL_STREAM_COPY_ARB = 35042;
/*  18:    */   public static final int GL_STATIC_DRAW_ARB = 35044;
/*  19:    */   public static final int GL_STATIC_READ_ARB = 35045;
/*  20:    */   public static final int GL_STATIC_COPY_ARB = 35046;
/*  21:    */   public static final int GL_DYNAMIC_DRAW_ARB = 35048;
/*  22:    */   public static final int GL_DYNAMIC_READ_ARB = 35049;
/*  23:    */   public static final int GL_DYNAMIC_COPY_ARB = 35050;
/*  24:    */   public static final int GL_READ_ONLY_ARB = 35000;
/*  25:    */   public static final int GL_WRITE_ONLY_ARB = 35001;
/*  26:    */   public static final int GL_READ_WRITE_ARB = 35002;
/*  27:    */   public static final int GL_BUFFER_SIZE_ARB = 34660;
/*  28:    */   public static final int GL_BUFFER_USAGE_ARB = 34661;
/*  29:    */   public static final int GL_BUFFER_ACCESS_ARB = 35003;
/*  30:    */   public static final int GL_BUFFER_MAPPED_ARB = 35004;
/*  31:    */   public static final int GL_BUFFER_MAP_POINTER_ARB = 35005;
/*  32:    */   
/*  33:    */   public static void glBindBufferARB(int target, int buffer)
/*  34:    */   {
/*  35: 41 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  36: 42 */     long function_pointer = caps.glBindBufferARB;
/*  37: 43 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  38: 44 */     StateTracker.bindBuffer(caps, target, buffer);
/*  39: 45 */     nglBindBufferARB(target, buffer, function_pointer);
/*  40:    */   }
/*  41:    */   
/*  42:    */   static native void nglBindBufferARB(int paramInt1, int paramInt2, long paramLong);
/*  43:    */   
/*  44:    */   public static void glDeleteBuffersARB(IntBuffer buffers)
/*  45:    */   {
/*  46: 50 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  47: 51 */     long function_pointer = caps.glDeleteBuffersARB;
/*  48: 52 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  49: 53 */     BufferChecks.checkDirect(buffers);
/*  50: 54 */     nglDeleteBuffersARB(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/*  51:    */   }
/*  52:    */   
/*  53:    */   static native void nglDeleteBuffersARB(int paramInt, long paramLong1, long paramLong2);
/*  54:    */   
/*  55:    */   public static void glDeleteBuffersARB(int buffer)
/*  56:    */   {
/*  57: 60 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  58: 61 */     long function_pointer = caps.glDeleteBuffersARB;
/*  59: 62 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  60: 63 */     nglDeleteBuffersARB(1, APIUtil.getInt(caps, buffer), function_pointer);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void glGenBuffersARB(IntBuffer buffers)
/*  64:    */   {
/*  65: 67 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  66: 68 */     long function_pointer = caps.glGenBuffersARB;
/*  67: 69 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  68: 70 */     BufferChecks.checkDirect(buffers);
/*  69: 71 */     nglGenBuffersARB(buffers.remaining(), MemoryUtil.getAddress(buffers), function_pointer);
/*  70:    */   }
/*  71:    */   
/*  72:    */   static native void nglGenBuffersARB(int paramInt, long paramLong1, long paramLong2);
/*  73:    */   
/*  74:    */   public static int glGenBuffersARB()
/*  75:    */   {
/*  76: 77 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  77: 78 */     long function_pointer = caps.glGenBuffersARB;
/*  78: 79 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  79: 80 */     IntBuffer buffers = APIUtil.getBufferInt(caps);
/*  80: 81 */     nglGenBuffersARB(1, MemoryUtil.getAddress(buffers), function_pointer);
/*  81: 82 */     return buffers.get(0);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static boolean glIsBufferARB(int buffer)
/*  85:    */   {
/*  86: 86 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  87: 87 */     long function_pointer = caps.glIsBufferARB;
/*  88: 88 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  89: 89 */     boolean __result = nglIsBufferARB(buffer, function_pointer);
/*  90: 90 */     return __result;
/*  91:    */   }
/*  92:    */   
/*  93:    */   static native boolean nglIsBufferARB(int paramInt, long paramLong);
/*  94:    */   
/*  95:    */   public static void glBufferDataARB(int target, long data_size, int usage)
/*  96:    */   {
/*  97: 95 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98: 96 */     long function_pointer = caps.glBufferDataARB;
/*  99: 97 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100: 98 */     nglBufferDataARB(target, data_size, 0L, usage, function_pointer);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static void glBufferDataARB(int target, ByteBuffer data, int usage)
/* 104:    */   {
/* 105:101 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 106:102 */     long function_pointer = caps.glBufferDataARB;
/* 107:103 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 108:104 */     BufferChecks.checkDirect(data);
/* 109:105 */     nglBufferDataARB(target, data.remaining(), MemoryUtil.getAddress(data), usage, function_pointer);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void glBufferDataARB(int target, DoubleBuffer data, int usage)
/* 113:    */   {
/* 114:108 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 115:109 */     long function_pointer = caps.glBufferDataARB;
/* 116:110 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 117:111 */     BufferChecks.checkDirect(data);
/* 118:112 */     nglBufferDataARB(target, data.remaining() << 3, MemoryUtil.getAddress(data), usage, function_pointer);
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static void glBufferDataARB(int target, FloatBuffer data, int usage)
/* 122:    */   {
/* 123:115 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 124:116 */     long function_pointer = caps.glBufferDataARB;
/* 125:117 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 126:118 */     BufferChecks.checkDirect(data);
/* 127:119 */     nglBufferDataARB(target, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static void glBufferDataARB(int target, IntBuffer data, int usage)
/* 131:    */   {
/* 132:122 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 133:123 */     long function_pointer = caps.glBufferDataARB;
/* 134:124 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 135:125 */     BufferChecks.checkDirect(data);
/* 136:126 */     nglBufferDataARB(target, data.remaining() << 2, MemoryUtil.getAddress(data), usage, function_pointer);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static void glBufferDataARB(int target, ShortBuffer data, int usage)
/* 140:    */   {
/* 141:129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 142:130 */     long function_pointer = caps.glBufferDataARB;
/* 143:131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 144:132 */     BufferChecks.checkDirect(data);
/* 145:133 */     nglBufferDataARB(target, data.remaining() << 1, MemoryUtil.getAddress(data), usage, function_pointer);
/* 146:    */   }
/* 147:    */   
/* 148:    */   static native void nglBufferDataARB(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3);
/* 149:    */   
/* 150:    */   public static void glBufferSubDataARB(int target, long offset, ByteBuffer data)
/* 151:    */   {
/* 152:138 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 153:139 */     long function_pointer = caps.glBufferSubDataARB;
/* 154:140 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 155:141 */     BufferChecks.checkDirect(data);
/* 156:142 */     nglBufferSubDataARB(target, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static void glBufferSubDataARB(int target, long offset, DoubleBuffer data)
/* 160:    */   {
/* 161:145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 162:146 */     long function_pointer = caps.glBufferSubDataARB;
/* 163:147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 164:148 */     BufferChecks.checkDirect(data);
/* 165:149 */     nglBufferSubDataARB(target, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static void glBufferSubDataARB(int target, long offset, FloatBuffer data)
/* 169:    */   {
/* 170:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 171:153 */     long function_pointer = caps.glBufferSubDataARB;
/* 172:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 173:155 */     BufferChecks.checkDirect(data);
/* 174:156 */     nglBufferSubDataARB(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static void glBufferSubDataARB(int target, long offset, IntBuffer data)
/* 178:    */   {
/* 179:159 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 180:160 */     long function_pointer = caps.glBufferSubDataARB;
/* 181:161 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 182:162 */     BufferChecks.checkDirect(data);
/* 183:163 */     nglBufferSubDataARB(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static void glBufferSubDataARB(int target, long offset, ShortBuffer data)
/* 187:    */   {
/* 188:166 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 189:167 */     long function_pointer = caps.glBufferSubDataARB;
/* 190:168 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 191:169 */     BufferChecks.checkDirect(data);
/* 192:170 */     nglBufferSubDataARB(target, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   static native void nglBufferSubDataARB(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 196:    */   
/* 197:    */   public static void glGetBufferSubDataARB(int target, long offset, ByteBuffer data)
/* 198:    */   {
/* 199:175 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:176 */     long function_pointer = caps.glGetBufferSubDataARB;
/* 201:177 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:178 */     BufferChecks.checkDirect(data);
/* 203:179 */     nglGetBufferSubDataARB(target, offset, data.remaining(), MemoryUtil.getAddress(data), function_pointer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static void glGetBufferSubDataARB(int target, long offset, DoubleBuffer data)
/* 207:    */   {
/* 208:182 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 209:183 */     long function_pointer = caps.glGetBufferSubDataARB;
/* 210:184 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 211:185 */     BufferChecks.checkDirect(data);
/* 212:186 */     nglGetBufferSubDataARB(target, offset, data.remaining() << 3, MemoryUtil.getAddress(data), function_pointer);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static void glGetBufferSubDataARB(int target, long offset, FloatBuffer data)
/* 216:    */   {
/* 217:189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 218:190 */     long function_pointer = caps.glGetBufferSubDataARB;
/* 219:191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 220:192 */     BufferChecks.checkDirect(data);
/* 221:193 */     nglGetBufferSubDataARB(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static void glGetBufferSubDataARB(int target, long offset, IntBuffer data)
/* 225:    */   {
/* 226:196 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 227:197 */     long function_pointer = caps.glGetBufferSubDataARB;
/* 228:198 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 229:199 */     BufferChecks.checkDirect(data);
/* 230:200 */     nglGetBufferSubDataARB(target, offset, data.remaining() << 2, MemoryUtil.getAddress(data), function_pointer);
/* 231:    */   }
/* 232:    */   
/* 233:    */   public static void glGetBufferSubDataARB(int target, long offset, ShortBuffer data)
/* 234:    */   {
/* 235:203 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 236:204 */     long function_pointer = caps.glGetBufferSubDataARB;
/* 237:205 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 238:206 */     BufferChecks.checkDirect(data);
/* 239:207 */     nglGetBufferSubDataARB(target, offset, data.remaining() << 1, MemoryUtil.getAddress(data), function_pointer);
/* 240:    */   }
/* 241:    */   
/* 242:    */   static native void nglGetBufferSubDataARB(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/* 243:    */   
/* 244:    */   public static ByteBuffer glMapBufferARB(int target, int access, ByteBuffer old_buffer)
/* 245:    */   {
/* 246:235 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 247:236 */     long function_pointer = caps.glMapBufferARB;
/* 248:237 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 249:238 */     if (old_buffer != null) {
/* 250:239 */       BufferChecks.checkDirect(old_buffer);
/* 251:    */     }
/* 252:240 */     ByteBuffer __result = nglMapBufferARB(target, access, GLChecks.getBufferObjectSizeARB(caps, target), old_buffer, function_pointer);
/* 253:241 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 254:    */   }
/* 255:    */   
/* 256:    */   public static ByteBuffer glMapBufferARB(int target, int access, long length, ByteBuffer old_buffer)
/* 257:    */   {
/* 258:267 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 259:268 */     long function_pointer = caps.glMapBufferARB;
/* 260:269 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 261:270 */     if (old_buffer != null) {
/* 262:271 */       BufferChecks.checkDirect(old_buffer);
/* 263:    */     }
/* 264:272 */     ByteBuffer __result = nglMapBufferARB(target, access, length, old_buffer, function_pointer);
/* 265:273 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 266:    */   }
/* 267:    */   
/* 268:    */   static native ByteBuffer nglMapBufferARB(int paramInt1, int paramInt2, long paramLong1, ByteBuffer paramByteBuffer, long paramLong2);
/* 269:    */   
/* 270:    */   public static boolean glUnmapBufferARB(int target)
/* 271:    */   {
/* 272:278 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 273:279 */     long function_pointer = caps.glUnmapBufferARB;
/* 274:280 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 275:281 */     boolean __result = nglUnmapBufferARB(target, function_pointer);
/* 276:282 */     return __result;
/* 277:    */   }
/* 278:    */   
/* 279:    */   static native boolean nglUnmapBufferARB(int paramInt, long paramLong);
/* 280:    */   
/* 281:    */   public static void glGetBufferParameterARB(int target, int pname, IntBuffer params)
/* 282:    */   {
/* 283:287 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 284:288 */     long function_pointer = caps.glGetBufferParameterivARB;
/* 285:289 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 286:290 */     BufferChecks.checkBuffer(params, 4);
/* 287:291 */     nglGetBufferParameterivARB(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 288:    */   }
/* 289:    */   
/* 290:    */   static native void nglGetBufferParameterivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 291:    */   
/* 292:    */   @Deprecated
/* 293:    */   public static int glGetBufferParameterARB(int target, int pname)
/* 294:    */   {
/* 295:302 */     return glGetBufferParameteriARB(target, pname);
/* 296:    */   }
/* 297:    */   
/* 298:    */   public static int glGetBufferParameteriARB(int target, int pname)
/* 299:    */   {
/* 300:307 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 301:308 */     long function_pointer = caps.glGetBufferParameterivARB;
/* 302:309 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 303:310 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 304:311 */     nglGetBufferParameterivARB(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 305:312 */     return params.get(0);
/* 306:    */   }
/* 307:    */   
/* 308:    */   public static ByteBuffer glGetBufferPointerARB(int target, int pname)
/* 309:    */   {
/* 310:316 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 311:317 */     long function_pointer = caps.glGetBufferPointervARB;
/* 312:318 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 313:319 */     ByteBuffer __result = nglGetBufferPointervARB(target, pname, GLChecks.getBufferObjectSizeARB(caps, target), function_pointer);
/* 314:320 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 315:    */   }
/* 316:    */   
/* 317:    */   static native ByteBuffer nglGetBufferPointervARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 318:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBBufferObject
 * JD-Core Version:    0.7.0.1
 */