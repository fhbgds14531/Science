/*   1:    */ package org.lwjgl;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.net.MalformedURLException;
/*   6:    */ import java.net.URL;
/*   7:    */ import java.security.AccessController;
/*   8:    */ import java.security.PrivilegedAction;
/*   9:    */ import java.security.PrivilegedExceptionAction;
/*  10:    */ import org.lwjgl.input.Mouse;
/*  11:    */ 
/*  12:    */ public final class Sys
/*  13:    */ {
/*  14:    */   private static final String JNI_LIBRARY_NAME = "lwjgl";
/*  15:    */   private static final String VERSION = "2.9.0";
/*  16:    */   private static final String POSTFIX64BIT = "64";
/*  17:    */   
/*  18:    */   private static void doLoadLibrary(String lib_name)
/*  19:    */   {
/*  20: 66 */     AccessController.doPrivileged(new PrivilegedAction()
/*  21:    */     {
/*  22:    */       public Object run()
/*  23:    */       {
/*  24: 68 */         String library_path = System.getProperty("org.lwjgl.librarypath");
/*  25: 69 */         if (library_path != null) {
/*  26: 70 */           System.load(library_path + File.separator + System.mapLibraryName(this.val$lib_name));
/*  27:    */         } else {
/*  28: 73 */           System.loadLibrary(this.val$lib_name);
/*  29:    */         }
/*  30: 75 */         return null;
/*  31:    */       }
/*  32:    */     });
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static void loadLibrary(String lib_name)
/*  36:    */   {
/*  37: 82 */     String osArch = System.getProperty("os.arch");
/*  38: 83 */     boolean is64bit = ("amd64".equals(osArch)) || ("x86_64".equals(osArch));
/*  39: 84 */     if (is64bit) {
/*  40:    */       try
/*  41:    */       {
/*  42: 86 */         doLoadLibrary(lib_name + "64");
/*  43: 87 */         return;
/*  44:    */       }
/*  45:    */       catch (UnsatisfiedLinkError e)
/*  46:    */       {
/*  47: 89 */         LWJGLUtil.log("Failed to load 64 bit library: " + e.getMessage());
/*  48:    */       }
/*  49:    */     }
/*  50:    */     try
/*  51:    */     {
/*  52: 95 */       doLoadLibrary(lib_name);
/*  53:    */     }
/*  54:    */     catch (UnsatisfiedLinkError e)
/*  55:    */     {
/*  56: 97 */       if (implementation.has64Bit()) {
/*  57:    */         try
/*  58:    */         {
/*  59: 99 */           doLoadLibrary(lib_name + "64");
/*  60:100 */           return;
/*  61:    */         }
/*  62:    */         catch (UnsatisfiedLinkError e2)
/*  63:    */         {
/*  64:102 */           LWJGLUtil.log("Failed to load 64 bit library: " + e2.getMessage());
/*  65:    */         }
/*  66:    */       }
/*  67:106 */       throw e;
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:111 */   private static final SysImplementation implementation = ;
/*  72:    */   private static final boolean is64Bit;
/*  73:    */   
/*  74:    */   static
/*  75:    */   {
/*  76:112 */     loadLibrary("lwjgl");
/*  77:113 */     is64Bit = implementation.getPointerSize() == 8;
/*  78:    */     
/*  79:115 */     int native_jni_version = implementation.getJNIVersion();
/*  80:116 */     int required_version = implementation.getRequiredJNIVersion();
/*  81:117 */     if (native_jni_version != required_version) {
/*  82:118 */       throw new LinkageError("Version mismatch: jar version is '" + required_version + "', native library version is '" + native_jni_version + "'");
/*  83:    */     }
/*  84:120 */     implementation.setDebug(LWJGLUtil.DEBUG);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static SysImplementation createImplementation()
/*  88:    */   {
/*  89:124 */     switch ()
/*  90:    */     {
/*  91:    */     case 1: 
/*  92:126 */       return new LinuxSysImplementation();
/*  93:    */     case 3: 
/*  94:128 */       return new WindowsSysImplementation();
/*  95:    */     case 2: 
/*  96:130 */       return new MacOSXSysImplementation();
/*  97:    */     }
/*  98:132 */     throw new IllegalStateException("Unsupported platform");
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static String getVersion()
/* 102:    */   {
/* 103:146 */     return "2.9.0";
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static boolean is64Bit()
/* 107:    */   {
/* 108:157 */     return is64Bit;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public static long getTimerResolution()
/* 112:    */   {
/* 113:167 */     return implementation.getTimerResolution();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static long getTime()
/* 117:    */   {
/* 118:178 */     return implementation.getTime() & 0xFFFFFFFF;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public static void alert(String title, String message)
/* 122:    */   {
/* 123:200 */     boolean grabbed = Mouse.isGrabbed();
/* 124:201 */     if (grabbed) {
/* 125:202 */       Mouse.setGrabbed(false);
/* 126:    */     }
/* 127:204 */     if (title == null) {
/* 128:205 */       title = "";
/* 129:    */     }
/* 130:206 */     if (message == null) {
/* 131:207 */       message = "";
/* 132:    */     }
/* 133:208 */     implementation.alert(title, message);
/* 134:209 */     if (grabbed) {
/* 135:210 */       Mouse.setGrabbed(true);
/* 136:    */     }
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static boolean openURL(String url)
/* 140:    */   {
/* 141:    */     try
/* 142:    */     {
/* 143:231 */       Class<?> serviceManagerClass = Class.forName("javax.jnlp.ServiceManager");
/* 144:232 */       Method lookupMethod = (Method)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 145:    */       {
/* 146:    */         public Method run()
/* 147:    */           throws Exception
/* 148:    */         {
/* 149:234 */           return this.val$serviceManagerClass.getMethod("lookup", new Class[] { String.class });
/* 150:    */         }
/* 151:236 */       });
/* 152:237 */       Object basicService = lookupMethod.invoke(serviceManagerClass, new Object[] { "javax.jnlp.BasicService" });
/* 153:238 */       Class<?> basicServiceClass = Class.forName("javax.jnlp.BasicService");
/* 154:239 */       Method showDocumentMethod = (Method)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 155:    */       {
/* 156:    */         public Method run()
/* 157:    */           throws Exception
/* 158:    */         {
/* 159:241 */           return this.val$basicServiceClass.getMethod("showDocument", new Class[] { URL.class });
/* 160:    */         }
/* 161:    */       });
/* 162:    */       try
/* 163:    */       {
/* 164:245 */         Boolean ret = (Boolean)showDocumentMethod.invoke(basicService, new Object[] { new URL(url) });
/* 165:246 */         return ret.booleanValue();
/* 166:    */       }
/* 167:    */       catch (MalformedURLException e)
/* 168:    */       {
/* 169:248 */         e.printStackTrace(System.err);
/* 170:249 */         return false;
/* 171:    */       }
/* 172:252 */       return implementation.openURL(url);
/* 173:    */     }
/* 174:    */     catch (Exception ue) {}
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static String getClipboard()
/* 178:    */   {
/* 179:265 */     return implementation.getClipboard();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static void initialize() {}
/* 183:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.Sys
 * JD-Core Version:    0.7.0.1
 */