/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import java.nio.ShortBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class EXTDrawRangeElements
/* 10:   */ {
/* 11:   */   public static final int GL_MAX_ELEMENTS_VERTICES_EXT = 33000;
/* 12:   */   public static final int GL_MAX_ELEMENTS_INDICES_EXT = 33001;
/* 13:   */   
/* 14:   */   public static void glDrawRangeElementsEXT(int mode, int start, int end, ByteBuffer pIndices)
/* 15:   */   {
/* 16:16 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 17:17 */     long function_pointer = caps.glDrawRangeElementsEXT;
/* 18:18 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 19:19 */     GLChecks.ensureElementVBOdisabled(caps);
/* 20:20 */     BufferChecks.checkDirect(pIndices);
/* 21:21 */     nglDrawRangeElementsEXT(mode, start, end, pIndices.remaining(), 5121, MemoryUtil.getAddress(pIndices), function_pointer);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void glDrawRangeElementsEXT(int mode, int start, int end, IntBuffer pIndices)
/* 25:   */   {
/* 26:24 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:25 */     long function_pointer = caps.glDrawRangeElementsEXT;
/* 28:26 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:27 */     GLChecks.ensureElementVBOdisabled(caps);
/* 30:28 */     BufferChecks.checkDirect(pIndices);
/* 31:29 */     nglDrawRangeElementsEXT(mode, start, end, pIndices.remaining(), 5125, MemoryUtil.getAddress(pIndices), function_pointer);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public static void glDrawRangeElementsEXT(int mode, int start, int end, ShortBuffer pIndices)
/* 35:   */   {
/* 36:32 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 37:33 */     long function_pointer = caps.glDrawRangeElementsEXT;
/* 38:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 39:35 */     GLChecks.ensureElementVBOdisabled(caps);
/* 40:36 */     BufferChecks.checkDirect(pIndices);
/* 41:37 */     nglDrawRangeElementsEXT(mode, start, end, pIndices.remaining(), 5123, MemoryUtil.getAddress(pIndices), function_pointer);
/* 42:   */   }
/* 43:   */   
/* 44:   */   static native void nglDrawRangeElementsEXT(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 45:   */   
/* 46:   */   public static void glDrawRangeElementsEXT(int mode, int start, int end, int pIndices_count, int type, long pIndices_buffer_offset)
/* 47:   */   {
/* 48:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 49:42 */     long function_pointer = caps.glDrawRangeElementsEXT;
/* 50:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 51:44 */     GLChecks.ensureElementVBOenabled(caps);
/* 52:45 */     nglDrawRangeElementsEXTBO(mode, start, end, pIndices_count, type, pIndices_buffer_offset, function_pointer);
/* 53:   */   }
/* 54:   */   
/* 55:   */   static native void nglDrawRangeElementsEXTBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 56:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTDrawRangeElements
 * JD-Core Version:    0.7.0.1
 */