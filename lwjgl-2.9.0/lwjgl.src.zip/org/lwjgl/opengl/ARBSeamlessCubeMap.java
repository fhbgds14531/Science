package org.lwjgl.opengl;

public final class ARBSeamlessCubeMap
{
  public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 34895;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBSeamlessCubeMap
 * JD-Core Version:    0.7.0.1
 */