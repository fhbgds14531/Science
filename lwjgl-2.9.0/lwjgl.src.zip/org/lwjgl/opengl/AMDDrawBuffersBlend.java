/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class AMDDrawBuffersBlend
/*  6:   */ {
/*  7:   */   public static void glBlendFuncIndexedAMD(int buf, int src, int dst)
/*  8:   */   {
/*  9:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 10:14 */     long function_pointer = caps.glBlendFuncIndexedAMD;
/* 11:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 12:16 */     nglBlendFuncIndexedAMD(buf, src, dst, function_pointer);
/* 13:   */   }
/* 14:   */   
/* 15:   */   static native void nglBlendFuncIndexedAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 16:   */   
/* 17:   */   public static void glBlendFuncSeparateIndexedAMD(int buf, int srcRGB, int dstRGB, int srcAlpha, int dstAlpha)
/* 18:   */   {
/* 19:21 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 20:22 */     long function_pointer = caps.glBlendFuncSeparateIndexedAMD;
/* 21:23 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 22:24 */     nglBlendFuncSeparateIndexedAMD(buf, srcRGB, dstRGB, srcAlpha, dstAlpha, function_pointer);
/* 23:   */   }
/* 24:   */   
/* 25:   */   static native void nglBlendFuncSeparateIndexedAMD(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 26:   */   
/* 27:   */   public static void glBlendEquationIndexedAMD(int buf, int mode)
/* 28:   */   {
/* 29:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 30:30 */     long function_pointer = caps.glBlendEquationIndexedAMD;
/* 31:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 32:32 */     nglBlendEquationIndexedAMD(buf, mode, function_pointer);
/* 33:   */   }
/* 34:   */   
/* 35:   */   static native void nglBlendEquationIndexedAMD(int paramInt1, int paramInt2, long paramLong);
/* 36:   */   
/* 37:   */   public static void glBlendEquationSeparateIndexedAMD(int buf, int modeRGB, int modeAlpha)
/* 38:   */   {
/* 39:37 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 40:38 */     long function_pointer = caps.glBlendEquationSeparateIndexedAMD;
/* 41:39 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 42:40 */     nglBlendEquationSeparateIndexedAMD(buf, modeRGB, modeAlpha, function_pointer);
/* 43:   */   }
/* 44:   */   
/* 45:   */   static native void nglBlendEquationSeparateIndexedAMD(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 46:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDDrawBuffersBlend
 * JD-Core Version:    0.7.0.1
 */