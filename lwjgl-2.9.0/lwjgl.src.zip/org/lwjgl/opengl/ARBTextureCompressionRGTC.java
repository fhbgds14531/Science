package org.lwjgl.opengl;

public final class ARBTextureCompressionRGTC
{
  public static final int GL_COMPRESSED_RED_RGTC1 = 36283;
  public static final int GL_COMPRESSED_SIGNED_RED_RGTC1 = 36284;
  public static final int GL_COMPRESSED_RG_RGTC2 = 36285;
  public static final int GL_COMPRESSED_SIGNED_RG_RGTC2 = 36286;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTextureCompressionRGTC
 * JD-Core Version:    0.7.0.1
 */