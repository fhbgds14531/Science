/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.IntBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class NVTransformFeedback2
/*  8:   */ {
/*  9:   */   public static final int GL_TRANSFORM_FEEDBACK_NV = 36386;
/* 10:   */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_PAUSED_NV = 36387;
/* 11:   */   public static final int GL_TRANSFORM_FEEDBACK_BUFFER_ACTIVE_NV = 36388;
/* 12:   */   public static final int GL_TRANSFORM_FEEDBACK_BINDING_NV = 36389;
/* 13:   */   
/* 14:   */   public static void glBindTransformFeedbackNV(int target, int id)
/* 15:   */   {
/* 16:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 17:27 */     long function_pointer = caps.glBindTransformFeedbackNV;
/* 18:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 19:29 */     nglBindTransformFeedbackNV(target, id, function_pointer);
/* 20:   */   }
/* 21:   */   
/* 22:   */   static native void nglBindTransformFeedbackNV(int paramInt1, int paramInt2, long paramLong);
/* 23:   */   
/* 24:   */   public static void glDeleteTransformFeedbacksNV(IntBuffer ids)
/* 25:   */   {
/* 26:34 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 27:35 */     long function_pointer = caps.glDeleteTransformFeedbacksNV;
/* 28:36 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 29:37 */     BufferChecks.checkDirect(ids);
/* 30:38 */     nglDeleteTransformFeedbacksNV(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 31:   */   }
/* 32:   */   
/* 33:   */   static native void nglDeleteTransformFeedbacksNV(int paramInt, long paramLong1, long paramLong2);
/* 34:   */   
/* 35:   */   public static void glDeleteTransformFeedbacksNV(int id)
/* 36:   */   {
/* 37:44 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 38:45 */     long function_pointer = caps.glDeleteTransformFeedbacksNV;
/* 39:46 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 40:47 */     nglDeleteTransformFeedbacksNV(1, APIUtil.getInt(caps, id), function_pointer);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static void glGenTransformFeedbacksNV(IntBuffer ids)
/* 44:   */   {
/* 45:51 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 46:52 */     long function_pointer = caps.glGenTransformFeedbacksNV;
/* 47:53 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 48:54 */     BufferChecks.checkDirect(ids);
/* 49:55 */     nglGenTransformFeedbacksNV(ids.remaining(), MemoryUtil.getAddress(ids), function_pointer);
/* 50:   */   }
/* 51:   */   
/* 52:   */   static native void nglGenTransformFeedbacksNV(int paramInt, long paramLong1, long paramLong2);
/* 53:   */   
/* 54:   */   public static int glGenTransformFeedbacksNV()
/* 55:   */   {
/* 56:61 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 57:62 */     long function_pointer = caps.glGenTransformFeedbacksNV;
/* 58:63 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 59:64 */     IntBuffer ids = APIUtil.getBufferInt(caps);
/* 60:65 */     nglGenTransformFeedbacksNV(1, MemoryUtil.getAddress(ids), function_pointer);
/* 61:66 */     return ids.get(0);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public static boolean glIsTransformFeedbackNV(int id)
/* 65:   */   {
/* 66:70 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 67:71 */     long function_pointer = caps.glIsTransformFeedbackNV;
/* 68:72 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 69:73 */     boolean __result = nglIsTransformFeedbackNV(id, function_pointer);
/* 70:74 */     return __result;
/* 71:   */   }
/* 72:   */   
/* 73:   */   static native boolean nglIsTransformFeedbackNV(int paramInt, long paramLong);
/* 74:   */   
/* 75:   */   public static void glPauseTransformFeedbackNV()
/* 76:   */   {
/* 77:79 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 78:80 */     long function_pointer = caps.glPauseTransformFeedbackNV;
/* 79:81 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 80:82 */     nglPauseTransformFeedbackNV(function_pointer);
/* 81:   */   }
/* 82:   */   
/* 83:   */   static native void nglPauseTransformFeedbackNV(long paramLong);
/* 84:   */   
/* 85:   */   public static void glResumeTransformFeedbackNV()
/* 86:   */   {
/* 87:87 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 88:88 */     long function_pointer = caps.glResumeTransformFeedbackNV;
/* 89:89 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 90:90 */     nglResumeTransformFeedbackNV(function_pointer);
/* 91:   */   }
/* 92:   */   
/* 93:   */   static native void nglResumeTransformFeedbackNV(long paramLong);
/* 94:   */   
/* 95:   */   public static void glDrawTransformFeedbackNV(int mode, int id)
/* 96:   */   {
/* 97:95 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 98:96 */     long function_pointer = caps.glDrawTransformFeedbackNV;
/* 99:97 */     BufferChecks.checkFunctionAddress(function_pointer);
/* :0:98 */     nglDrawTransformFeedbackNV(mode, id, function_pointer);
/* :1:   */   }
/* :2:   */   
/* :3:   */   static native void nglDrawTransformFeedbackNV(int paramInt1, int paramInt2, long paramLong);
/* :4:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVTransformFeedback2
 * JD-Core Version:    0.7.0.1
 */