/*    1:     */ package org.lwjgl.opengl;
/*    2:     */ 
/*    3:     */ import java.nio.ByteBuffer;
/*    4:     */ import java.nio.ByteOrder;
/*    5:     */ import java.nio.DoubleBuffer;
/*    6:     */ import java.nio.FloatBuffer;
/*    7:     */ import java.nio.IntBuffer;
/*    8:     */ import java.nio.ShortBuffer;
/*    9:     */ import org.lwjgl.BufferChecks;
/*   10:     */ import org.lwjgl.LWJGLUtil;
/*   11:     */ import org.lwjgl.MemoryUtil;
/*   12:     */ 
/*   13:     */ public final class GL11
/*   14:     */ {
/*   15:     */   public static final int GL_ACCUM = 256;
/*   16:     */   public static final int GL_LOAD = 257;
/*   17:     */   public static final int GL_RETURN = 258;
/*   18:     */   public static final int GL_MULT = 259;
/*   19:     */   public static final int GL_ADD = 260;
/*   20:     */   public static final int GL_NEVER = 512;
/*   21:     */   public static final int GL_LESS = 513;
/*   22:     */   public static final int GL_EQUAL = 514;
/*   23:     */   public static final int GL_LEQUAL = 515;
/*   24:     */   public static final int GL_GREATER = 516;
/*   25:     */   public static final int GL_NOTEQUAL = 517;
/*   26:     */   public static final int GL_GEQUAL = 518;
/*   27:     */   public static final int GL_ALWAYS = 519;
/*   28:     */   public static final int GL_CURRENT_BIT = 1;
/*   29:     */   public static final int GL_POINT_BIT = 2;
/*   30:     */   public static final int GL_LINE_BIT = 4;
/*   31:     */   public static final int GL_POLYGON_BIT = 8;
/*   32:     */   public static final int GL_POLYGON_STIPPLE_BIT = 16;
/*   33:     */   public static final int GL_PIXEL_MODE_BIT = 32;
/*   34:     */   public static final int GL_LIGHTING_BIT = 64;
/*   35:     */   public static final int GL_FOG_BIT = 128;
/*   36:     */   public static final int GL_DEPTH_BUFFER_BIT = 256;
/*   37:     */   public static final int GL_ACCUM_BUFFER_BIT = 512;
/*   38:     */   public static final int GL_STENCIL_BUFFER_BIT = 1024;
/*   39:     */   public static final int GL_VIEWPORT_BIT = 2048;
/*   40:     */   public static final int GL_TRANSFORM_BIT = 4096;
/*   41:     */   public static final int GL_ENABLE_BIT = 8192;
/*   42:     */   public static final int GL_COLOR_BUFFER_BIT = 16384;
/*   43:     */   public static final int GL_HINT_BIT = 32768;
/*   44:     */   public static final int GL_EVAL_BIT = 65536;
/*   45:     */   public static final int GL_LIST_BIT = 131072;
/*   46:     */   public static final int GL_TEXTURE_BIT = 262144;
/*   47:     */   public static final int GL_SCISSOR_BIT = 524288;
/*   48:     */   public static final int GL_ALL_ATTRIB_BITS = 1048575;
/*   49:     */   public static final int GL_POINTS = 0;
/*   50:     */   public static final int GL_LINES = 1;
/*   51:     */   public static final int GL_LINE_LOOP = 2;
/*   52:     */   public static final int GL_LINE_STRIP = 3;
/*   53:     */   public static final int GL_TRIANGLES = 4;
/*   54:     */   public static final int GL_TRIANGLE_STRIP = 5;
/*   55:     */   public static final int GL_TRIANGLE_FAN = 6;
/*   56:     */   public static final int GL_QUADS = 7;
/*   57:     */   public static final int GL_QUAD_STRIP = 8;
/*   58:     */   public static final int GL_POLYGON = 9;
/*   59:     */   public static final int GL_ZERO = 0;
/*   60:     */   public static final int GL_ONE = 1;
/*   61:     */   public static final int GL_SRC_COLOR = 768;
/*   62:     */   public static final int GL_ONE_MINUS_SRC_COLOR = 769;
/*   63:     */   public static final int GL_SRC_ALPHA = 770;
/*   64:     */   public static final int GL_ONE_MINUS_SRC_ALPHA = 771;
/*   65:     */   public static final int GL_DST_ALPHA = 772;
/*   66:     */   public static final int GL_ONE_MINUS_DST_ALPHA = 773;
/*   67:     */   public static final int GL_DST_COLOR = 774;
/*   68:     */   public static final int GL_ONE_MINUS_DST_COLOR = 775;
/*   69:     */   public static final int GL_SRC_ALPHA_SATURATE = 776;
/*   70:     */   public static final int GL_CONSTANT_COLOR = 32769;
/*   71:     */   public static final int GL_ONE_MINUS_CONSTANT_COLOR = 32770;
/*   72:     */   public static final int GL_CONSTANT_ALPHA = 32771;
/*   73:     */   public static final int GL_ONE_MINUS_CONSTANT_ALPHA = 32772;
/*   74:     */   public static final int GL_TRUE = 1;
/*   75:     */   public static final int GL_FALSE = 0;
/*   76:     */   public static final int GL_CLIP_PLANE0 = 12288;
/*   77:     */   public static final int GL_CLIP_PLANE1 = 12289;
/*   78:     */   public static final int GL_CLIP_PLANE2 = 12290;
/*   79:     */   public static final int GL_CLIP_PLANE3 = 12291;
/*   80:     */   public static final int GL_CLIP_PLANE4 = 12292;
/*   81:     */   public static final int GL_CLIP_PLANE5 = 12293;
/*   82:     */   public static final int GL_BYTE = 5120;
/*   83:     */   public static final int GL_UNSIGNED_BYTE = 5121;
/*   84:     */   public static final int GL_SHORT = 5122;
/*   85:     */   public static final int GL_UNSIGNED_SHORT = 5123;
/*   86:     */   public static final int GL_INT = 5124;
/*   87:     */   public static final int GL_UNSIGNED_INT = 5125;
/*   88:     */   public static final int GL_FLOAT = 5126;
/*   89:     */   public static final int GL_2_BYTES = 5127;
/*   90:     */   public static final int GL_3_BYTES = 5128;
/*   91:     */   public static final int GL_4_BYTES = 5129;
/*   92:     */   public static final int GL_DOUBLE = 5130;
/*   93:     */   public static final int GL_NONE = 0;
/*   94:     */   public static final int GL_FRONT_LEFT = 1024;
/*   95:     */   public static final int GL_FRONT_RIGHT = 1025;
/*   96:     */   public static final int GL_BACK_LEFT = 1026;
/*   97:     */   public static final int GL_BACK_RIGHT = 1027;
/*   98:     */   public static final int GL_FRONT = 1028;
/*   99:     */   public static final int GL_BACK = 1029;
/*  100:     */   public static final int GL_LEFT = 1030;
/*  101:     */   public static final int GL_RIGHT = 1031;
/*  102:     */   public static final int GL_FRONT_AND_BACK = 1032;
/*  103:     */   public static final int GL_AUX0 = 1033;
/*  104:     */   public static final int GL_AUX1 = 1034;
/*  105:     */   public static final int GL_AUX2 = 1035;
/*  106:     */   public static final int GL_AUX3 = 1036;
/*  107:     */   public static final int GL_NO_ERROR = 0;
/*  108:     */   public static final int GL_INVALID_ENUM = 1280;
/*  109:     */   public static final int GL_INVALID_VALUE = 1281;
/*  110:     */   public static final int GL_INVALID_OPERATION = 1282;
/*  111:     */   public static final int GL_STACK_OVERFLOW = 1283;
/*  112:     */   public static final int GL_STACK_UNDERFLOW = 1284;
/*  113:     */   public static final int GL_OUT_OF_MEMORY = 1285;
/*  114:     */   public static final int GL_2D = 1536;
/*  115:     */   public static final int GL_3D = 1537;
/*  116:     */   public static final int GL_3D_COLOR = 1538;
/*  117:     */   public static final int GL_3D_COLOR_TEXTURE = 1539;
/*  118:     */   public static final int GL_4D_COLOR_TEXTURE = 1540;
/*  119:     */   public static final int GL_PASS_THROUGH_TOKEN = 1792;
/*  120:     */   public static final int GL_POINT_TOKEN = 1793;
/*  121:     */   public static final int GL_LINE_TOKEN = 1794;
/*  122:     */   public static final int GL_POLYGON_TOKEN = 1795;
/*  123:     */   public static final int GL_BITMAP_TOKEN = 1796;
/*  124:     */   public static final int GL_DRAW_PIXEL_TOKEN = 1797;
/*  125:     */   public static final int GL_COPY_PIXEL_TOKEN = 1798;
/*  126:     */   public static final int GL_LINE_RESET_TOKEN = 1799;
/*  127:     */   public static final int GL_EXP = 2048;
/*  128:     */   public static final int GL_EXP2 = 2049;
/*  129:     */   public static final int GL_CW = 2304;
/*  130:     */   public static final int GL_CCW = 2305;
/*  131:     */   public static final int GL_COEFF = 2560;
/*  132:     */   public static final int GL_ORDER = 2561;
/*  133:     */   public static final int GL_DOMAIN = 2562;
/*  134:     */   public static final int GL_CURRENT_COLOR = 2816;
/*  135:     */   public static final int GL_CURRENT_INDEX = 2817;
/*  136:     */   public static final int GL_CURRENT_NORMAL = 2818;
/*  137:     */   public static final int GL_CURRENT_TEXTURE_COORDS = 2819;
/*  138:     */   public static final int GL_CURRENT_RASTER_COLOR = 2820;
/*  139:     */   public static final int GL_CURRENT_RASTER_INDEX = 2821;
/*  140:     */   public static final int GL_CURRENT_RASTER_TEXTURE_COORDS = 2822;
/*  141:     */   public static final int GL_CURRENT_RASTER_POSITION = 2823;
/*  142:     */   public static final int GL_CURRENT_RASTER_POSITION_VALID = 2824;
/*  143:     */   public static final int GL_CURRENT_RASTER_DISTANCE = 2825;
/*  144:     */   public static final int GL_POINT_SMOOTH = 2832;
/*  145:     */   public static final int GL_POINT_SIZE = 2833;
/*  146:     */   public static final int GL_POINT_SIZE_RANGE = 2834;
/*  147:     */   public static final int GL_POINT_SIZE_GRANULARITY = 2835;
/*  148:     */   public static final int GL_LINE_SMOOTH = 2848;
/*  149:     */   public static final int GL_LINE_WIDTH = 2849;
/*  150:     */   public static final int GL_LINE_WIDTH_RANGE = 2850;
/*  151:     */   public static final int GL_LINE_WIDTH_GRANULARITY = 2851;
/*  152:     */   public static final int GL_LINE_STIPPLE = 2852;
/*  153:     */   public static final int GL_LINE_STIPPLE_PATTERN = 2853;
/*  154:     */   public static final int GL_LINE_STIPPLE_REPEAT = 2854;
/*  155:     */   public static final int GL_LIST_MODE = 2864;
/*  156:     */   public static final int GL_MAX_LIST_NESTING = 2865;
/*  157:     */   public static final int GL_LIST_BASE = 2866;
/*  158:     */   public static final int GL_LIST_INDEX = 2867;
/*  159:     */   public static final int GL_POLYGON_MODE = 2880;
/*  160:     */   public static final int GL_POLYGON_SMOOTH = 2881;
/*  161:     */   public static final int GL_POLYGON_STIPPLE = 2882;
/*  162:     */   public static final int GL_EDGE_FLAG = 2883;
/*  163:     */   public static final int GL_CULL_FACE = 2884;
/*  164:     */   public static final int GL_CULL_FACE_MODE = 2885;
/*  165:     */   public static final int GL_FRONT_FACE = 2886;
/*  166:     */   public static final int GL_LIGHTING = 2896;
/*  167:     */   public static final int GL_LIGHT_MODEL_LOCAL_VIEWER = 2897;
/*  168:     */   public static final int GL_LIGHT_MODEL_TWO_SIDE = 2898;
/*  169:     */   public static final int GL_LIGHT_MODEL_AMBIENT = 2899;
/*  170:     */   public static final int GL_SHADE_MODEL = 2900;
/*  171:     */   public static final int GL_COLOR_MATERIAL_FACE = 2901;
/*  172:     */   public static final int GL_COLOR_MATERIAL_PARAMETER = 2902;
/*  173:     */   public static final int GL_COLOR_MATERIAL = 2903;
/*  174:     */   public static final int GL_FOG = 2912;
/*  175:     */   public static final int GL_FOG_INDEX = 2913;
/*  176:     */   public static final int GL_FOG_DENSITY = 2914;
/*  177:     */   public static final int GL_FOG_START = 2915;
/*  178:     */   public static final int GL_FOG_END = 2916;
/*  179:     */   public static final int GL_FOG_MODE = 2917;
/*  180:     */   public static final int GL_FOG_COLOR = 2918;
/*  181:     */   public static final int GL_DEPTH_RANGE = 2928;
/*  182:     */   public static final int GL_DEPTH_TEST = 2929;
/*  183:     */   public static final int GL_DEPTH_WRITEMASK = 2930;
/*  184:     */   public static final int GL_DEPTH_CLEAR_VALUE = 2931;
/*  185:     */   public static final int GL_DEPTH_FUNC = 2932;
/*  186:     */   public static final int GL_ACCUM_CLEAR_VALUE = 2944;
/*  187:     */   public static final int GL_STENCIL_TEST = 2960;
/*  188:     */   public static final int GL_STENCIL_CLEAR_VALUE = 2961;
/*  189:     */   public static final int GL_STENCIL_FUNC = 2962;
/*  190:     */   public static final int GL_STENCIL_VALUE_MASK = 2963;
/*  191:     */   public static final int GL_STENCIL_FAIL = 2964;
/*  192:     */   public static final int GL_STENCIL_PASS_DEPTH_FAIL = 2965;
/*  193:     */   public static final int GL_STENCIL_PASS_DEPTH_PASS = 2966;
/*  194:     */   public static final int GL_STENCIL_REF = 2967;
/*  195:     */   public static final int GL_STENCIL_WRITEMASK = 2968;
/*  196:     */   public static final int GL_MATRIX_MODE = 2976;
/*  197:     */   public static final int GL_NORMALIZE = 2977;
/*  198:     */   public static final int GL_VIEWPORT = 2978;
/*  199:     */   public static final int GL_MODELVIEW_STACK_DEPTH = 2979;
/*  200:     */   public static final int GL_PROJECTION_STACK_DEPTH = 2980;
/*  201:     */   public static final int GL_TEXTURE_STACK_DEPTH = 2981;
/*  202:     */   public static final int GL_MODELVIEW_MATRIX = 2982;
/*  203:     */   public static final int GL_PROJECTION_MATRIX = 2983;
/*  204:     */   public static final int GL_TEXTURE_MATRIX = 2984;
/*  205:     */   public static final int GL_ATTRIB_STACK_DEPTH = 2992;
/*  206:     */   public static final int GL_CLIENT_ATTRIB_STACK_DEPTH = 2993;
/*  207:     */   public static final int GL_ALPHA_TEST = 3008;
/*  208:     */   public static final int GL_ALPHA_TEST_FUNC = 3009;
/*  209:     */   public static final int GL_ALPHA_TEST_REF = 3010;
/*  210:     */   public static final int GL_DITHER = 3024;
/*  211:     */   public static final int GL_BLEND_DST = 3040;
/*  212:     */   public static final int GL_BLEND_SRC = 3041;
/*  213:     */   public static final int GL_BLEND = 3042;
/*  214:     */   public static final int GL_LOGIC_OP_MODE = 3056;
/*  215:     */   public static final int GL_INDEX_LOGIC_OP = 3057;
/*  216:     */   public static final int GL_COLOR_LOGIC_OP = 3058;
/*  217:     */   public static final int GL_AUX_BUFFERS = 3072;
/*  218:     */   public static final int GL_DRAW_BUFFER = 3073;
/*  219:     */   public static final int GL_READ_BUFFER = 3074;
/*  220:     */   public static final int GL_SCISSOR_BOX = 3088;
/*  221:     */   public static final int GL_SCISSOR_TEST = 3089;
/*  222:     */   public static final int GL_INDEX_CLEAR_VALUE = 3104;
/*  223:     */   public static final int GL_INDEX_WRITEMASK = 3105;
/*  224:     */   public static final int GL_COLOR_CLEAR_VALUE = 3106;
/*  225:     */   public static final int GL_COLOR_WRITEMASK = 3107;
/*  226:     */   public static final int GL_INDEX_MODE = 3120;
/*  227:     */   public static final int GL_RGBA_MODE = 3121;
/*  228:     */   public static final int GL_DOUBLEBUFFER = 3122;
/*  229:     */   public static final int GL_STEREO = 3123;
/*  230:     */   public static final int GL_RENDER_MODE = 3136;
/*  231:     */   public static final int GL_PERSPECTIVE_CORRECTION_HINT = 3152;
/*  232:     */   public static final int GL_POINT_SMOOTH_HINT = 3153;
/*  233:     */   public static final int GL_LINE_SMOOTH_HINT = 3154;
/*  234:     */   public static final int GL_POLYGON_SMOOTH_HINT = 3155;
/*  235:     */   public static final int GL_FOG_HINT = 3156;
/*  236:     */   public static final int GL_TEXTURE_GEN_S = 3168;
/*  237:     */   public static final int GL_TEXTURE_GEN_T = 3169;
/*  238:     */   public static final int GL_TEXTURE_GEN_R = 3170;
/*  239:     */   public static final int GL_TEXTURE_GEN_Q = 3171;
/*  240:     */   public static final int GL_PIXEL_MAP_I_TO_I = 3184;
/*  241:     */   public static final int GL_PIXEL_MAP_S_TO_S = 3185;
/*  242:     */   public static final int GL_PIXEL_MAP_I_TO_R = 3186;
/*  243:     */   public static final int GL_PIXEL_MAP_I_TO_G = 3187;
/*  244:     */   public static final int GL_PIXEL_MAP_I_TO_B = 3188;
/*  245:     */   public static final int GL_PIXEL_MAP_I_TO_A = 3189;
/*  246:     */   public static final int GL_PIXEL_MAP_R_TO_R = 3190;
/*  247:     */   public static final int GL_PIXEL_MAP_G_TO_G = 3191;
/*  248:     */   public static final int GL_PIXEL_MAP_B_TO_B = 3192;
/*  249:     */   public static final int GL_PIXEL_MAP_A_TO_A = 3193;
/*  250:     */   public static final int GL_PIXEL_MAP_I_TO_I_SIZE = 3248;
/*  251:     */   public static final int GL_PIXEL_MAP_S_TO_S_SIZE = 3249;
/*  252:     */   public static final int GL_PIXEL_MAP_I_TO_R_SIZE = 3250;
/*  253:     */   public static final int GL_PIXEL_MAP_I_TO_G_SIZE = 3251;
/*  254:     */   public static final int GL_PIXEL_MAP_I_TO_B_SIZE = 3252;
/*  255:     */   public static final int GL_PIXEL_MAP_I_TO_A_SIZE = 3253;
/*  256:     */   public static final int GL_PIXEL_MAP_R_TO_R_SIZE = 3254;
/*  257:     */   public static final int GL_PIXEL_MAP_G_TO_G_SIZE = 3255;
/*  258:     */   public static final int GL_PIXEL_MAP_B_TO_B_SIZE = 3256;
/*  259:     */   public static final int GL_PIXEL_MAP_A_TO_A_SIZE = 3257;
/*  260:     */   public static final int GL_UNPACK_SWAP_BYTES = 3312;
/*  261:     */   public static final int GL_UNPACK_LSB_FIRST = 3313;
/*  262:     */   public static final int GL_UNPACK_ROW_LENGTH = 3314;
/*  263:     */   public static final int GL_UNPACK_SKIP_ROWS = 3315;
/*  264:     */   public static final int GL_UNPACK_SKIP_PIXELS = 3316;
/*  265:     */   public static final int GL_UNPACK_ALIGNMENT = 3317;
/*  266:     */   public static final int GL_PACK_SWAP_BYTES = 3328;
/*  267:     */   public static final int GL_PACK_LSB_FIRST = 3329;
/*  268:     */   public static final int GL_PACK_ROW_LENGTH = 3330;
/*  269:     */   public static final int GL_PACK_SKIP_ROWS = 3331;
/*  270:     */   public static final int GL_PACK_SKIP_PIXELS = 3332;
/*  271:     */   public static final int GL_PACK_ALIGNMENT = 3333;
/*  272:     */   public static final int GL_MAP_COLOR = 3344;
/*  273:     */   public static final int GL_MAP_STENCIL = 3345;
/*  274:     */   public static final int GL_INDEX_SHIFT = 3346;
/*  275:     */   public static final int GL_INDEX_OFFSET = 3347;
/*  276:     */   public static final int GL_RED_SCALE = 3348;
/*  277:     */   public static final int GL_RED_BIAS = 3349;
/*  278:     */   public static final int GL_ZOOM_X = 3350;
/*  279:     */   public static final int GL_ZOOM_Y = 3351;
/*  280:     */   public static final int GL_GREEN_SCALE = 3352;
/*  281:     */   public static final int GL_GREEN_BIAS = 3353;
/*  282:     */   public static final int GL_BLUE_SCALE = 3354;
/*  283:     */   public static final int GL_BLUE_BIAS = 3355;
/*  284:     */   public static final int GL_ALPHA_SCALE = 3356;
/*  285:     */   public static final int GL_ALPHA_BIAS = 3357;
/*  286:     */   public static final int GL_DEPTH_SCALE = 3358;
/*  287:     */   public static final int GL_DEPTH_BIAS = 3359;
/*  288:     */   public static final int GL_MAX_EVAL_ORDER = 3376;
/*  289:     */   public static final int GL_MAX_LIGHTS = 3377;
/*  290:     */   public static final int GL_MAX_CLIP_PLANES = 3378;
/*  291:     */   public static final int GL_MAX_TEXTURE_SIZE = 3379;
/*  292:     */   public static final int GL_MAX_PIXEL_MAP_TABLE = 3380;
/*  293:     */   public static final int GL_MAX_ATTRIB_STACK_DEPTH = 3381;
/*  294:     */   public static final int GL_MAX_MODELVIEW_STACK_DEPTH = 3382;
/*  295:     */   public static final int GL_MAX_NAME_STACK_DEPTH = 3383;
/*  296:     */   public static final int GL_MAX_PROJECTION_STACK_DEPTH = 3384;
/*  297:     */   public static final int GL_MAX_TEXTURE_STACK_DEPTH = 3385;
/*  298:     */   public static final int GL_MAX_VIEWPORT_DIMS = 3386;
/*  299:     */   public static final int GL_MAX_CLIENT_ATTRIB_STACK_DEPTH = 3387;
/*  300:     */   public static final int GL_SUBPIXEL_BITS = 3408;
/*  301:     */   public static final int GL_INDEX_BITS = 3409;
/*  302:     */   public static final int GL_RED_BITS = 3410;
/*  303:     */   public static final int GL_GREEN_BITS = 3411;
/*  304:     */   public static final int GL_BLUE_BITS = 3412;
/*  305:     */   public static final int GL_ALPHA_BITS = 3413;
/*  306:     */   public static final int GL_DEPTH_BITS = 3414;
/*  307:     */   public static final int GL_STENCIL_BITS = 3415;
/*  308:     */   public static final int GL_ACCUM_RED_BITS = 3416;
/*  309:     */   public static final int GL_ACCUM_GREEN_BITS = 3417;
/*  310:     */   public static final int GL_ACCUM_BLUE_BITS = 3418;
/*  311:     */   public static final int GL_ACCUM_ALPHA_BITS = 3419;
/*  312:     */   public static final int GL_NAME_STACK_DEPTH = 3440;
/*  313:     */   public static final int GL_AUTO_NORMAL = 3456;
/*  314:     */   public static final int GL_MAP1_COLOR_4 = 3472;
/*  315:     */   public static final int GL_MAP1_INDEX = 3473;
/*  316:     */   public static final int GL_MAP1_NORMAL = 3474;
/*  317:     */   public static final int GL_MAP1_TEXTURE_COORD_1 = 3475;
/*  318:     */   public static final int GL_MAP1_TEXTURE_COORD_2 = 3476;
/*  319:     */   public static final int GL_MAP1_TEXTURE_COORD_3 = 3477;
/*  320:     */   public static final int GL_MAP1_TEXTURE_COORD_4 = 3478;
/*  321:     */   public static final int GL_MAP1_VERTEX_3 = 3479;
/*  322:     */   public static final int GL_MAP1_VERTEX_4 = 3480;
/*  323:     */   public static final int GL_MAP2_COLOR_4 = 3504;
/*  324:     */   public static final int GL_MAP2_INDEX = 3505;
/*  325:     */   public static final int GL_MAP2_NORMAL = 3506;
/*  326:     */   public static final int GL_MAP2_TEXTURE_COORD_1 = 3507;
/*  327:     */   public static final int GL_MAP2_TEXTURE_COORD_2 = 3508;
/*  328:     */   public static final int GL_MAP2_TEXTURE_COORD_3 = 3509;
/*  329:     */   public static final int GL_MAP2_TEXTURE_COORD_4 = 3510;
/*  330:     */   public static final int GL_MAP2_VERTEX_3 = 3511;
/*  331:     */   public static final int GL_MAP2_VERTEX_4 = 3512;
/*  332:     */   public static final int GL_MAP1_GRID_DOMAIN = 3536;
/*  333:     */   public static final int GL_MAP1_GRID_SEGMENTS = 3537;
/*  334:     */   public static final int GL_MAP2_GRID_DOMAIN = 3538;
/*  335:     */   public static final int GL_MAP2_GRID_SEGMENTS = 3539;
/*  336:     */   public static final int GL_TEXTURE_1D = 3552;
/*  337:     */   public static final int GL_TEXTURE_2D = 3553;
/*  338:     */   public static final int GL_FEEDBACK_BUFFER_POINTER = 3568;
/*  339:     */   public static final int GL_FEEDBACK_BUFFER_SIZE = 3569;
/*  340:     */   public static final int GL_FEEDBACK_BUFFER_TYPE = 3570;
/*  341:     */   public static final int GL_SELECTION_BUFFER_POINTER = 3571;
/*  342:     */   public static final int GL_SELECTION_BUFFER_SIZE = 3572;
/*  343:     */   public static final int GL_TEXTURE_WIDTH = 4096;
/*  344:     */   public static final int GL_TEXTURE_HEIGHT = 4097;
/*  345:     */   public static final int GL_TEXTURE_INTERNAL_FORMAT = 4099;
/*  346:     */   public static final int GL_TEXTURE_BORDER_COLOR = 4100;
/*  347:     */   public static final int GL_TEXTURE_BORDER = 4101;
/*  348:     */   public static final int GL_DONT_CARE = 4352;
/*  349:     */   public static final int GL_FASTEST = 4353;
/*  350:     */   public static final int GL_NICEST = 4354;
/*  351:     */   public static final int GL_LIGHT0 = 16384;
/*  352:     */   public static final int GL_LIGHT1 = 16385;
/*  353:     */   public static final int GL_LIGHT2 = 16386;
/*  354:     */   public static final int GL_LIGHT3 = 16387;
/*  355:     */   public static final int GL_LIGHT4 = 16388;
/*  356:     */   public static final int GL_LIGHT5 = 16389;
/*  357:     */   public static final int GL_LIGHT6 = 16390;
/*  358:     */   public static final int GL_LIGHT7 = 16391;
/*  359:     */   public static final int GL_AMBIENT = 4608;
/*  360:     */   public static final int GL_DIFFUSE = 4609;
/*  361:     */   public static final int GL_SPECULAR = 4610;
/*  362:     */   public static final int GL_POSITION = 4611;
/*  363:     */   public static final int GL_SPOT_DIRECTION = 4612;
/*  364:     */   public static final int GL_SPOT_EXPONENT = 4613;
/*  365:     */   public static final int GL_SPOT_CUTOFF = 4614;
/*  366:     */   public static final int GL_CONSTANT_ATTENUATION = 4615;
/*  367:     */   public static final int GL_LINEAR_ATTENUATION = 4616;
/*  368:     */   public static final int GL_QUADRATIC_ATTENUATION = 4617;
/*  369:     */   public static final int GL_COMPILE = 4864;
/*  370:     */   public static final int GL_COMPILE_AND_EXECUTE = 4865;
/*  371:     */   public static final int GL_CLEAR = 5376;
/*  372:     */   public static final int GL_AND = 5377;
/*  373:     */   public static final int GL_AND_REVERSE = 5378;
/*  374:     */   public static final int GL_COPY = 5379;
/*  375:     */   public static final int GL_AND_INVERTED = 5380;
/*  376:     */   public static final int GL_NOOP = 5381;
/*  377:     */   public static final int GL_XOR = 5382;
/*  378:     */   public static final int GL_OR = 5383;
/*  379:     */   public static final int GL_NOR = 5384;
/*  380:     */   public static final int GL_EQUIV = 5385;
/*  381:     */   public static final int GL_INVERT = 5386;
/*  382:     */   public static final int GL_OR_REVERSE = 5387;
/*  383:     */   public static final int GL_COPY_INVERTED = 5388;
/*  384:     */   public static final int GL_OR_INVERTED = 5389;
/*  385:     */   public static final int GL_NAND = 5390;
/*  386:     */   public static final int GL_SET = 5391;
/*  387:     */   public static final int GL_EMISSION = 5632;
/*  388:     */   public static final int GL_SHININESS = 5633;
/*  389:     */   public static final int GL_AMBIENT_AND_DIFFUSE = 5634;
/*  390:     */   public static final int GL_COLOR_INDEXES = 5635;
/*  391:     */   public static final int GL_MODELVIEW = 5888;
/*  392:     */   public static final int GL_PROJECTION = 5889;
/*  393:     */   public static final int GL_TEXTURE = 5890;
/*  394:     */   public static final int GL_COLOR = 6144;
/*  395:     */   public static final int GL_DEPTH = 6145;
/*  396:     */   public static final int GL_STENCIL = 6146;
/*  397:     */   public static final int GL_COLOR_INDEX = 6400;
/*  398:     */   public static final int GL_STENCIL_INDEX = 6401;
/*  399:     */   public static final int GL_DEPTH_COMPONENT = 6402;
/*  400:     */   public static final int GL_RED = 6403;
/*  401:     */   public static final int GL_GREEN = 6404;
/*  402:     */   public static final int GL_BLUE = 6405;
/*  403:     */   public static final int GL_ALPHA = 6406;
/*  404:     */   public static final int GL_RGB = 6407;
/*  405:     */   public static final int GL_RGBA = 6408;
/*  406:     */   public static final int GL_LUMINANCE = 6409;
/*  407:     */   public static final int GL_LUMINANCE_ALPHA = 6410;
/*  408:     */   public static final int GL_BITMAP = 6656;
/*  409:     */   public static final int GL_POINT = 6912;
/*  410:     */   public static final int GL_LINE = 6913;
/*  411:     */   public static final int GL_FILL = 6914;
/*  412:     */   public static final int GL_RENDER = 7168;
/*  413:     */   public static final int GL_FEEDBACK = 7169;
/*  414:     */   public static final int GL_SELECT = 7170;
/*  415:     */   public static final int GL_FLAT = 7424;
/*  416:     */   public static final int GL_SMOOTH = 7425;
/*  417:     */   public static final int GL_KEEP = 7680;
/*  418:     */   public static final int GL_REPLACE = 7681;
/*  419:     */   public static final int GL_INCR = 7682;
/*  420:     */   public static final int GL_DECR = 7683;
/*  421:     */   public static final int GL_VENDOR = 7936;
/*  422:     */   public static final int GL_RENDERER = 7937;
/*  423:     */   public static final int GL_VERSION = 7938;
/*  424:     */   public static final int GL_EXTENSIONS = 7939;
/*  425:     */   public static final int GL_S = 8192;
/*  426:     */   public static final int GL_T = 8193;
/*  427:     */   public static final int GL_R = 8194;
/*  428:     */   public static final int GL_Q = 8195;
/*  429:     */   public static final int GL_MODULATE = 8448;
/*  430:     */   public static final int GL_DECAL = 8449;
/*  431:     */   public static final int GL_TEXTURE_ENV_MODE = 8704;
/*  432:     */   public static final int GL_TEXTURE_ENV_COLOR = 8705;
/*  433:     */   public static final int GL_TEXTURE_ENV = 8960;
/*  434:     */   public static final int GL_EYE_LINEAR = 9216;
/*  435:     */   public static final int GL_OBJECT_LINEAR = 9217;
/*  436:     */   public static final int GL_SPHERE_MAP = 9218;
/*  437:     */   public static final int GL_TEXTURE_GEN_MODE = 9472;
/*  438:     */   public static final int GL_OBJECT_PLANE = 9473;
/*  439:     */   public static final int GL_EYE_PLANE = 9474;
/*  440:     */   public static final int GL_NEAREST = 9728;
/*  441:     */   public static final int GL_LINEAR = 9729;
/*  442:     */   public static final int GL_NEAREST_MIPMAP_NEAREST = 9984;
/*  443:     */   public static final int GL_LINEAR_MIPMAP_NEAREST = 9985;
/*  444:     */   public static final int GL_NEAREST_MIPMAP_LINEAR = 9986;
/*  445:     */   public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
/*  446:     */   public static final int GL_TEXTURE_MAG_FILTER = 10240;
/*  447:     */   public static final int GL_TEXTURE_MIN_FILTER = 10241;
/*  448:     */   public static final int GL_TEXTURE_WRAP_S = 10242;
/*  449:     */   public static final int GL_TEXTURE_WRAP_T = 10243;
/*  450:     */   public static final int GL_CLAMP = 10496;
/*  451:     */   public static final int GL_REPEAT = 10497;
/*  452:     */   public static final int GL_CLIENT_PIXEL_STORE_BIT = 1;
/*  453:     */   public static final int GL_CLIENT_VERTEX_ARRAY_BIT = 2;
/*  454:     */   public static final int GL_ALL_CLIENT_ATTRIB_BITS = -1;
/*  455:     */   public static final int GL_POLYGON_OFFSET_FACTOR = 32824;
/*  456:     */   public static final int GL_POLYGON_OFFSET_UNITS = 10752;
/*  457:     */   public static final int GL_POLYGON_OFFSET_POINT = 10753;
/*  458:     */   public static final int GL_POLYGON_OFFSET_LINE = 10754;
/*  459:     */   public static final int GL_POLYGON_OFFSET_FILL = 32823;
/*  460:     */   public static final int GL_ALPHA4 = 32827;
/*  461:     */   public static final int GL_ALPHA8 = 32828;
/*  462:     */   public static final int GL_ALPHA12 = 32829;
/*  463:     */   public static final int GL_ALPHA16 = 32830;
/*  464:     */   public static final int GL_LUMINANCE4 = 32831;
/*  465:     */   public static final int GL_LUMINANCE8 = 32832;
/*  466:     */   public static final int GL_LUMINANCE12 = 32833;
/*  467:     */   public static final int GL_LUMINANCE16 = 32834;
/*  468:     */   public static final int GL_LUMINANCE4_ALPHA4 = 32835;
/*  469:     */   public static final int GL_LUMINANCE6_ALPHA2 = 32836;
/*  470:     */   public static final int GL_LUMINANCE8_ALPHA8 = 32837;
/*  471:     */   public static final int GL_LUMINANCE12_ALPHA4 = 32838;
/*  472:     */   public static final int GL_LUMINANCE12_ALPHA12 = 32839;
/*  473:     */   public static final int GL_LUMINANCE16_ALPHA16 = 32840;
/*  474:     */   public static final int GL_INTENSITY = 32841;
/*  475:     */   public static final int GL_INTENSITY4 = 32842;
/*  476:     */   public static final int GL_INTENSITY8 = 32843;
/*  477:     */   public static final int GL_INTENSITY12 = 32844;
/*  478:     */   public static final int GL_INTENSITY16 = 32845;
/*  479:     */   public static final int GL_R3_G3_B2 = 10768;
/*  480:     */   public static final int GL_RGB4 = 32847;
/*  481:     */   public static final int GL_RGB5 = 32848;
/*  482:     */   public static final int GL_RGB8 = 32849;
/*  483:     */   public static final int GL_RGB10 = 32850;
/*  484:     */   public static final int GL_RGB12 = 32851;
/*  485:     */   public static final int GL_RGB16 = 32852;
/*  486:     */   public static final int GL_RGBA2 = 32853;
/*  487:     */   public static final int GL_RGBA4 = 32854;
/*  488:     */   public static final int GL_RGB5_A1 = 32855;
/*  489:     */   public static final int GL_RGBA8 = 32856;
/*  490:     */   public static final int GL_RGB10_A2 = 32857;
/*  491:     */   public static final int GL_RGBA12 = 32858;
/*  492:     */   public static final int GL_RGBA16 = 32859;
/*  493:     */   public static final int GL_TEXTURE_RED_SIZE = 32860;
/*  494:     */   public static final int GL_TEXTURE_GREEN_SIZE = 32861;
/*  495:     */   public static final int GL_TEXTURE_BLUE_SIZE = 32862;
/*  496:     */   public static final int GL_TEXTURE_ALPHA_SIZE = 32863;
/*  497:     */   public static final int GL_TEXTURE_LUMINANCE_SIZE = 32864;
/*  498:     */   public static final int GL_TEXTURE_INTENSITY_SIZE = 32865;
/*  499:     */   public static final int GL_PROXY_TEXTURE_1D = 32867;
/*  500:     */   public static final int GL_PROXY_TEXTURE_2D = 32868;
/*  501:     */   public static final int GL_TEXTURE_PRIORITY = 32870;
/*  502:     */   public static final int GL_TEXTURE_RESIDENT = 32871;
/*  503:     */   public static final int GL_TEXTURE_BINDING_1D = 32872;
/*  504:     */   public static final int GL_TEXTURE_BINDING_2D = 32873;
/*  505:     */   public static final int GL_VERTEX_ARRAY = 32884;
/*  506:     */   public static final int GL_NORMAL_ARRAY = 32885;
/*  507:     */   public static final int GL_COLOR_ARRAY = 32886;
/*  508:     */   public static final int GL_INDEX_ARRAY = 32887;
/*  509:     */   public static final int GL_TEXTURE_COORD_ARRAY = 32888;
/*  510:     */   public static final int GL_EDGE_FLAG_ARRAY = 32889;
/*  511:     */   public static final int GL_VERTEX_ARRAY_SIZE = 32890;
/*  512:     */   public static final int GL_VERTEX_ARRAY_TYPE = 32891;
/*  513:     */   public static final int GL_VERTEX_ARRAY_STRIDE = 32892;
/*  514:     */   public static final int GL_NORMAL_ARRAY_TYPE = 32894;
/*  515:     */   public static final int GL_NORMAL_ARRAY_STRIDE = 32895;
/*  516:     */   public static final int GL_COLOR_ARRAY_SIZE = 32897;
/*  517:     */   public static final int GL_COLOR_ARRAY_TYPE = 32898;
/*  518:     */   public static final int GL_COLOR_ARRAY_STRIDE = 32899;
/*  519:     */   public static final int GL_INDEX_ARRAY_TYPE = 32901;
/*  520:     */   public static final int GL_INDEX_ARRAY_STRIDE = 32902;
/*  521:     */   public static final int GL_TEXTURE_COORD_ARRAY_SIZE = 32904;
/*  522:     */   public static final int GL_TEXTURE_COORD_ARRAY_TYPE = 32905;
/*  523:     */   public static final int GL_TEXTURE_COORD_ARRAY_STRIDE = 32906;
/*  524:     */   public static final int GL_EDGE_FLAG_ARRAY_STRIDE = 32908;
/*  525:     */   public static final int GL_VERTEX_ARRAY_POINTER = 32910;
/*  526:     */   public static final int GL_NORMAL_ARRAY_POINTER = 32911;
/*  527:     */   public static final int GL_COLOR_ARRAY_POINTER = 32912;
/*  528:     */   public static final int GL_INDEX_ARRAY_POINTER = 32913;
/*  529:     */   public static final int GL_TEXTURE_COORD_ARRAY_POINTER = 32914;
/*  530:     */   public static final int GL_EDGE_FLAG_ARRAY_POINTER = 32915;
/*  531:     */   public static final int GL_V2F = 10784;
/*  532:     */   public static final int GL_V3F = 10785;
/*  533:     */   public static final int GL_C4UB_V2F = 10786;
/*  534:     */   public static final int GL_C4UB_V3F = 10787;
/*  535:     */   public static final int GL_C3F_V3F = 10788;
/*  536:     */   public static final int GL_N3F_V3F = 10789;
/*  537:     */   public static final int GL_C4F_N3F_V3F = 10790;
/*  538:     */   public static final int GL_T2F_V3F = 10791;
/*  539:     */   public static final int GL_T4F_V4F = 10792;
/*  540:     */   public static final int GL_T2F_C4UB_V3F = 10793;
/*  541:     */   public static final int GL_T2F_C3F_V3F = 10794;
/*  542:     */   public static final int GL_T2F_N3F_V3F = 10795;
/*  543:     */   public static final int GL_T2F_C4F_N3F_V3F = 10796;
/*  544:     */   public static final int GL_T4F_C4F_N3F_V4F = 10797;
/*  545:     */   public static final int GL_LOGIC_OP = 3057;
/*  546:     */   public static final int GL_TEXTURE_COMPONENTS = 4099;
/*  547:     */   
/*  548:     */   public static void glAccum(int op, float value)
/*  549:     */   {
/*  550: 553 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  551: 554 */     long function_pointer = caps.glAccum;
/*  552: 555 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  553: 556 */     nglAccum(op, value, function_pointer);
/*  554:     */   }
/*  555:     */   
/*  556:     */   static native void nglAccum(int paramInt, float paramFloat, long paramLong);
/*  557:     */   
/*  558:     */   public static void glAlphaFunc(int func, float ref)
/*  559:     */   {
/*  560: 561 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  561: 562 */     long function_pointer = caps.glAlphaFunc;
/*  562: 563 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  563: 564 */     nglAlphaFunc(func, ref, function_pointer);
/*  564:     */   }
/*  565:     */   
/*  566:     */   static native void nglAlphaFunc(int paramInt, float paramFloat, long paramLong);
/*  567:     */   
/*  568:     */   public static void glClearColor(float red, float green, float blue, float alpha)
/*  569:     */   {
/*  570: 569 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  571: 570 */     long function_pointer = caps.glClearColor;
/*  572: 571 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  573: 572 */     nglClearColor(red, green, blue, alpha, function_pointer);
/*  574:     */   }
/*  575:     */   
/*  576:     */   static native void nglClearColor(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  577:     */   
/*  578:     */   public static void glClearAccum(float red, float green, float blue, float alpha)
/*  579:     */   {
/*  580: 577 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  581: 578 */     long function_pointer = caps.glClearAccum;
/*  582: 579 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  583: 580 */     nglClearAccum(red, green, blue, alpha, function_pointer);
/*  584:     */   }
/*  585:     */   
/*  586:     */   static native void nglClearAccum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  587:     */   
/*  588:     */   public static void glClear(int mask)
/*  589:     */   {
/*  590: 585 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  591: 586 */     long function_pointer = caps.glClear;
/*  592: 587 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  593: 588 */     nglClear(mask, function_pointer);
/*  594:     */   }
/*  595:     */   
/*  596:     */   static native void nglClear(int paramInt, long paramLong);
/*  597:     */   
/*  598:     */   public static void glCallLists(ByteBuffer lists)
/*  599:     */   {
/*  600: 593 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  601: 594 */     long function_pointer = caps.glCallLists;
/*  602: 595 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  603: 596 */     BufferChecks.checkDirect(lists);
/*  604: 597 */     nglCallLists(lists.remaining(), 5121, MemoryUtil.getAddress(lists), function_pointer);
/*  605:     */   }
/*  606:     */   
/*  607:     */   public static void glCallLists(IntBuffer lists)
/*  608:     */   {
/*  609: 600 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  610: 601 */     long function_pointer = caps.glCallLists;
/*  611: 602 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  612: 603 */     BufferChecks.checkDirect(lists);
/*  613: 604 */     nglCallLists(lists.remaining(), 5125, MemoryUtil.getAddress(lists), function_pointer);
/*  614:     */   }
/*  615:     */   
/*  616:     */   public static void glCallLists(ShortBuffer lists)
/*  617:     */   {
/*  618: 607 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  619: 608 */     long function_pointer = caps.glCallLists;
/*  620: 609 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  621: 610 */     BufferChecks.checkDirect(lists);
/*  622: 611 */     nglCallLists(lists.remaining(), 5123, MemoryUtil.getAddress(lists), function_pointer);
/*  623:     */   }
/*  624:     */   
/*  625:     */   static native void nglCallLists(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/*  626:     */   
/*  627:     */   public static void glCallList(int list)
/*  628:     */   {
/*  629: 616 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  630: 617 */     long function_pointer = caps.glCallList;
/*  631: 618 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  632: 619 */     nglCallList(list, function_pointer);
/*  633:     */   }
/*  634:     */   
/*  635:     */   static native void nglCallList(int paramInt, long paramLong);
/*  636:     */   
/*  637:     */   public static void glBlendFunc(int sfactor, int dfactor)
/*  638:     */   {
/*  639: 624 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  640: 625 */     long function_pointer = caps.glBlendFunc;
/*  641: 626 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  642: 627 */     nglBlendFunc(sfactor, dfactor, function_pointer);
/*  643:     */   }
/*  644:     */   
/*  645:     */   static native void nglBlendFunc(int paramInt1, int paramInt2, long paramLong);
/*  646:     */   
/*  647:     */   public static void glBitmap(int width, int height, float xorig, float yorig, float xmove, float ymove, ByteBuffer bitmap)
/*  648:     */   {
/*  649: 632 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  650: 633 */     long function_pointer = caps.glBitmap;
/*  651: 634 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  652: 635 */     GLChecks.ensureUnpackPBOdisabled(caps);
/*  653: 636 */     if (bitmap != null) {
/*  654: 637 */       BufferChecks.checkBuffer(bitmap, (width + 7) / 8 * height);
/*  655:     */     }
/*  656: 638 */     nglBitmap(width, height, xorig, yorig, xmove, ymove, MemoryUtil.getAddressSafe(bitmap), function_pointer);
/*  657:     */   }
/*  658:     */   
/*  659:     */   static native void nglBitmap(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong1, long paramLong2);
/*  660:     */   
/*  661:     */   public static void glBitmap(int width, int height, float xorig, float yorig, float xmove, float ymove, long bitmap_buffer_offset)
/*  662:     */   {
/*  663: 642 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  664: 643 */     long function_pointer = caps.glBitmap;
/*  665: 644 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  666: 645 */     GLChecks.ensureUnpackPBOenabled(caps);
/*  667: 646 */     nglBitmapBO(width, height, xorig, yorig, xmove, ymove, bitmap_buffer_offset, function_pointer);
/*  668:     */   }
/*  669:     */   
/*  670:     */   static native void nglBitmapBO(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong1, long paramLong2);
/*  671:     */   
/*  672:     */   public static void glBindTexture(int target, int texture)
/*  673:     */   {
/*  674: 651 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  675: 652 */     long function_pointer = caps.glBindTexture;
/*  676: 653 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  677: 654 */     nglBindTexture(target, texture, function_pointer);
/*  678:     */   }
/*  679:     */   
/*  680:     */   static native void nglBindTexture(int paramInt1, int paramInt2, long paramLong);
/*  681:     */   
/*  682:     */   public static void glPrioritizeTextures(IntBuffer textures, FloatBuffer priorities)
/*  683:     */   {
/*  684: 659 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  685: 660 */     long function_pointer = caps.glPrioritizeTextures;
/*  686: 661 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  687: 662 */     BufferChecks.checkDirect(textures);
/*  688: 663 */     BufferChecks.checkBuffer(priorities, textures.remaining());
/*  689: 664 */     nglPrioritizeTextures(textures.remaining(), MemoryUtil.getAddress(textures), MemoryUtil.getAddress(priorities), function_pointer);
/*  690:     */   }
/*  691:     */   
/*  692:     */   static native void nglPrioritizeTextures(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  693:     */   
/*  694:     */   public static boolean glAreTexturesResident(IntBuffer textures, ByteBuffer residences)
/*  695:     */   {
/*  696: 669 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  697: 670 */     long function_pointer = caps.glAreTexturesResident;
/*  698: 671 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  699: 672 */     BufferChecks.checkDirect(textures);
/*  700: 673 */     BufferChecks.checkBuffer(residences, textures.remaining());
/*  701: 674 */     boolean __result = nglAreTexturesResident(textures.remaining(), MemoryUtil.getAddress(textures), MemoryUtil.getAddress(residences), function_pointer);
/*  702: 675 */     return __result;
/*  703:     */   }
/*  704:     */   
/*  705:     */   static native boolean nglAreTexturesResident(int paramInt, long paramLong1, long paramLong2, long paramLong3);
/*  706:     */   
/*  707:     */   public static void glBegin(int mode)
/*  708:     */   {
/*  709: 680 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  710: 681 */     long function_pointer = caps.glBegin;
/*  711: 682 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  712:     */     
/*  713: 684 */     nglBegin(mode, function_pointer);
/*  714:     */   }
/*  715:     */   
/*  716:     */   static native void nglBegin(int paramInt, long paramLong);
/*  717:     */   
/*  718:     */   public static void glEnd()
/*  719:     */   {
/*  720: 689 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  721: 690 */     long function_pointer = caps.glEnd;
/*  722: 691 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  723:     */     
/*  724: 693 */     nglEnd(function_pointer);
/*  725:     */   }
/*  726:     */   
/*  727:     */   static native void nglEnd(long paramLong);
/*  728:     */   
/*  729:     */   public static void glArrayElement(int i)
/*  730:     */   {
/*  731: 698 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  732: 699 */     long function_pointer = caps.glArrayElement;
/*  733: 700 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  734: 701 */     nglArrayElement(i, function_pointer);
/*  735:     */   }
/*  736:     */   
/*  737:     */   static native void nglArrayElement(int paramInt, long paramLong);
/*  738:     */   
/*  739:     */   public static void glClearDepth(double depth)
/*  740:     */   {
/*  741: 706 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  742: 707 */     long function_pointer = caps.glClearDepth;
/*  743: 708 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  744: 709 */     nglClearDepth(depth, function_pointer);
/*  745:     */   }
/*  746:     */   
/*  747:     */   static native void nglClearDepth(double paramDouble, long paramLong);
/*  748:     */   
/*  749:     */   public static void glDeleteLists(int list, int range)
/*  750:     */   {
/*  751: 714 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  752: 715 */     long function_pointer = caps.glDeleteLists;
/*  753: 716 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  754: 717 */     nglDeleteLists(list, range, function_pointer);
/*  755:     */   }
/*  756:     */   
/*  757:     */   static native void nglDeleteLists(int paramInt1, int paramInt2, long paramLong);
/*  758:     */   
/*  759:     */   public static void glDeleteTextures(IntBuffer textures)
/*  760:     */   {
/*  761: 722 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  762: 723 */     long function_pointer = caps.glDeleteTextures;
/*  763: 724 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  764: 725 */     BufferChecks.checkDirect(textures);
/*  765: 726 */     nglDeleteTextures(textures.remaining(), MemoryUtil.getAddress(textures), function_pointer);
/*  766:     */   }
/*  767:     */   
/*  768:     */   static native void nglDeleteTextures(int paramInt, long paramLong1, long paramLong2);
/*  769:     */   
/*  770:     */   public static void glDeleteTextures(int texture)
/*  771:     */   {
/*  772: 732 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  773: 733 */     long function_pointer = caps.glDeleteTextures;
/*  774: 734 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  775: 735 */     nglDeleteTextures(1, APIUtil.getInt(caps, texture), function_pointer);
/*  776:     */   }
/*  777:     */   
/*  778:     */   public static void glCullFace(int mode)
/*  779:     */   {
/*  780: 739 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  781: 740 */     long function_pointer = caps.glCullFace;
/*  782: 741 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  783: 742 */     nglCullFace(mode, function_pointer);
/*  784:     */   }
/*  785:     */   
/*  786:     */   static native void nglCullFace(int paramInt, long paramLong);
/*  787:     */   
/*  788:     */   public static void glCopyTexSubImage2D(int target, int level, int xoffset, int yoffset, int x, int y, int width, int height)
/*  789:     */   {
/*  790: 747 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  791: 748 */     long function_pointer = caps.glCopyTexSubImage2D;
/*  792: 749 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  793: 750 */     nglCopyTexSubImage2D(target, level, xoffset, yoffset, x, y, width, height, function_pointer);
/*  794:     */   }
/*  795:     */   
/*  796:     */   static native void nglCopyTexSubImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/*  797:     */   
/*  798:     */   public static void glCopyTexSubImage1D(int target, int level, int xoffset, int x, int y, int width)
/*  799:     */   {
/*  800: 755 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  801: 756 */     long function_pointer = caps.glCopyTexSubImage1D;
/*  802: 757 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  803: 758 */     nglCopyTexSubImage1D(target, level, xoffset, x, y, width, function_pointer);
/*  804:     */   }
/*  805:     */   
/*  806:     */   static native void nglCopyTexSubImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong);
/*  807:     */   
/*  808:     */   public static void glCopyTexImage2D(int target, int level, int internalFormat, int x, int y, int width, int height, int border)
/*  809:     */   {
/*  810: 763 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  811: 764 */     long function_pointer = caps.glCopyTexImage2D;
/*  812: 765 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  813: 766 */     nglCopyTexImage2D(target, level, internalFormat, x, y, width, height, border, function_pointer);
/*  814:     */   }
/*  815:     */   
/*  816:     */   static native void nglCopyTexImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong);
/*  817:     */   
/*  818:     */   public static void glCopyTexImage1D(int target, int level, int internalFormat, int x, int y, int width, int border)
/*  819:     */   {
/*  820: 771 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  821: 772 */     long function_pointer = caps.glCopyTexImage1D;
/*  822: 773 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  823: 774 */     nglCopyTexImage1D(target, level, internalFormat, x, y, width, border, function_pointer);
/*  824:     */   }
/*  825:     */   
/*  826:     */   static native void nglCopyTexImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong);
/*  827:     */   
/*  828:     */   public static void glCopyPixels(int x, int y, int width, int height, int type)
/*  829:     */   {
/*  830: 779 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  831: 780 */     long function_pointer = caps.glCopyPixels;
/*  832: 781 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  833: 782 */     nglCopyPixels(x, y, width, height, type, function_pointer);
/*  834:     */   }
/*  835:     */   
/*  836:     */   static native void nglCopyPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/*  837:     */   
/*  838:     */   public static void glColorPointer(int size, int stride, DoubleBuffer pointer)
/*  839:     */   {
/*  840: 787 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  841: 788 */     long function_pointer = caps.glColorPointer;
/*  842: 789 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  843: 790 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  844: 791 */     BufferChecks.checkDirect(pointer);
/*  845: 792 */     if (LWJGLUtil.CHECKS) {
/*  846: 792 */       StateTracker.getReferences(caps).GL11_glColorPointer_pointer = pointer;
/*  847:     */     }
/*  848: 793 */     nglColorPointer(size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  849:     */   }
/*  850:     */   
/*  851:     */   public static void glColorPointer(int size, int stride, FloatBuffer pointer)
/*  852:     */   {
/*  853: 796 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  854: 797 */     long function_pointer = caps.glColorPointer;
/*  855: 798 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  856: 799 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  857: 800 */     BufferChecks.checkDirect(pointer);
/*  858: 801 */     if (LWJGLUtil.CHECKS) {
/*  859: 801 */       StateTracker.getReferences(caps).GL11_glColorPointer_pointer = pointer;
/*  860:     */     }
/*  861: 802 */     nglColorPointer(size, 5126, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  862:     */   }
/*  863:     */   
/*  864:     */   public static void glColorPointer(int size, boolean unsigned, int stride, ByteBuffer pointer)
/*  865:     */   {
/*  866: 805 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  867: 806 */     long function_pointer = caps.glColorPointer;
/*  868: 807 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  869: 808 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  870: 809 */     BufferChecks.checkDirect(pointer);
/*  871: 810 */     if (LWJGLUtil.CHECKS) {
/*  872: 810 */       StateTracker.getReferences(caps).GL11_glColorPointer_pointer = pointer;
/*  873:     */     }
/*  874: 811 */     nglColorPointer(size, unsigned ? 5121 : 5120, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  875:     */   }
/*  876:     */   
/*  877:     */   static native void nglColorPointer(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  878:     */   
/*  879:     */   public static void glColorPointer(int size, int type, int stride, long pointer_buffer_offset)
/*  880:     */   {
/*  881: 815 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  882: 816 */     long function_pointer = caps.glColorPointer;
/*  883: 817 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  884: 818 */     GLChecks.ensureArrayVBOenabled(caps);
/*  885: 819 */     nglColorPointerBO(size, type, stride, pointer_buffer_offset, function_pointer);
/*  886:     */   }
/*  887:     */   
/*  888:     */   static native void nglColorPointerBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  889:     */   
/*  890:     */   public static void glColorPointer(int size, int type, int stride, ByteBuffer pointer)
/*  891:     */   {
/*  892: 825 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  893: 826 */     long function_pointer = caps.glColorPointer;
/*  894: 827 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  895: 828 */     GLChecks.ensureArrayVBOdisabled(caps);
/*  896: 829 */     BufferChecks.checkDirect(pointer);
/*  897: 830 */     if (LWJGLUtil.CHECKS) {
/*  898: 830 */       StateTracker.getReferences(caps).GL11_glColorPointer_pointer = pointer;
/*  899:     */     }
/*  900: 831 */     nglColorPointer(size, type, stride, MemoryUtil.getAddress(pointer), function_pointer);
/*  901:     */   }
/*  902:     */   
/*  903:     */   public static void glColorMaterial(int face, int mode)
/*  904:     */   {
/*  905: 835 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  906: 836 */     long function_pointer = caps.glColorMaterial;
/*  907: 837 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  908: 838 */     nglColorMaterial(face, mode, function_pointer);
/*  909:     */   }
/*  910:     */   
/*  911:     */   static native void nglColorMaterial(int paramInt1, int paramInt2, long paramLong);
/*  912:     */   
/*  913:     */   public static void glColorMask(boolean red, boolean green, boolean blue, boolean alpha)
/*  914:     */   {
/*  915: 843 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  916: 844 */     long function_pointer = caps.glColorMask;
/*  917: 845 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  918: 846 */     nglColorMask(red, green, blue, alpha, function_pointer);
/*  919:     */   }
/*  920:     */   
/*  921:     */   static native void nglColorMask(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong);
/*  922:     */   
/*  923:     */   public static void glColor3b(byte red, byte green, byte blue)
/*  924:     */   {
/*  925: 851 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  926: 852 */     long function_pointer = caps.glColor3b;
/*  927: 853 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  928: 854 */     nglColor3b(red, green, blue, function_pointer);
/*  929:     */   }
/*  930:     */   
/*  931:     */   static native void nglColor3b(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/*  932:     */   
/*  933:     */   public static void glColor3f(float red, float green, float blue)
/*  934:     */   {
/*  935: 859 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  936: 860 */     long function_pointer = caps.glColor3f;
/*  937: 861 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  938: 862 */     nglColor3f(red, green, blue, function_pointer);
/*  939:     */   }
/*  940:     */   
/*  941:     */   static native void nglColor3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/*  942:     */   
/*  943:     */   public static void glColor3d(double red, double green, double blue)
/*  944:     */   {
/*  945: 867 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  946: 868 */     long function_pointer = caps.glColor3d;
/*  947: 869 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  948: 870 */     nglColor3d(red, green, blue, function_pointer);
/*  949:     */   }
/*  950:     */   
/*  951:     */   static native void nglColor3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/*  952:     */   
/*  953:     */   public static void glColor3ub(byte red, byte green, byte blue)
/*  954:     */   {
/*  955: 875 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  956: 876 */     long function_pointer = caps.glColor3ub;
/*  957: 877 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  958: 878 */     nglColor3ub(red, green, blue, function_pointer);
/*  959:     */   }
/*  960:     */   
/*  961:     */   static native void nglColor3ub(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/*  962:     */   
/*  963:     */   public static void glColor4b(byte red, byte green, byte blue, byte alpha)
/*  964:     */   {
/*  965: 883 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  966: 884 */     long function_pointer = caps.glColor4b;
/*  967: 885 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  968: 886 */     nglColor4b(red, green, blue, alpha, function_pointer);
/*  969:     */   }
/*  970:     */   
/*  971:     */   static native void nglColor4b(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, long paramLong);
/*  972:     */   
/*  973:     */   public static void glColor4f(float red, float green, float blue, float alpha)
/*  974:     */   {
/*  975: 891 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  976: 892 */     long function_pointer = caps.glColor4f;
/*  977: 893 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  978: 894 */     nglColor4f(red, green, blue, alpha, function_pointer);
/*  979:     */   }
/*  980:     */   
/*  981:     */   static native void nglColor4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/*  982:     */   
/*  983:     */   public static void glColor4d(double red, double green, double blue, double alpha)
/*  984:     */   {
/*  985: 899 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  986: 900 */     long function_pointer = caps.glColor4d;
/*  987: 901 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  988: 902 */     nglColor4d(red, green, blue, alpha, function_pointer);
/*  989:     */   }
/*  990:     */   
/*  991:     */   static native void nglColor4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/*  992:     */   
/*  993:     */   public static void glColor4ub(byte red, byte green, byte blue, byte alpha)
/*  994:     */   {
/*  995: 907 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  996: 908 */     long function_pointer = caps.glColor4ub;
/*  997: 909 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  998: 910 */     nglColor4ub(red, green, blue, alpha, function_pointer);
/*  999:     */   }
/* 1000:     */   
/* 1001:     */   static native void nglColor4ub(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, long paramLong);
/* 1002:     */   
/* 1003:     */   public static void glClipPlane(int plane, DoubleBuffer equation)
/* 1004:     */   {
/* 1005: 915 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1006: 916 */     long function_pointer = caps.glClipPlane;
/* 1007: 917 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1008: 918 */     BufferChecks.checkBuffer(equation, 4);
/* 1009: 919 */     nglClipPlane(plane, MemoryUtil.getAddress(equation), function_pointer);
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   static native void nglClipPlane(int paramInt, long paramLong1, long paramLong2);
/* 1013:     */   
/* 1014:     */   public static void glClearStencil(int s)
/* 1015:     */   {
/* 1016: 924 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1017: 925 */     long function_pointer = caps.glClearStencil;
/* 1018: 926 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1019: 927 */     nglClearStencil(s, function_pointer);
/* 1020:     */   }
/* 1021:     */   
/* 1022:     */   static native void nglClearStencil(int paramInt, long paramLong);
/* 1023:     */   
/* 1024:     */   public static void glEvalPoint1(int i)
/* 1025:     */   {
/* 1026: 932 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1027: 933 */     long function_pointer = caps.glEvalPoint1;
/* 1028: 934 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1029: 935 */     nglEvalPoint1(i, function_pointer);
/* 1030:     */   }
/* 1031:     */   
/* 1032:     */   static native void nglEvalPoint1(int paramInt, long paramLong);
/* 1033:     */   
/* 1034:     */   public static void glEvalPoint2(int i, int j)
/* 1035:     */   {
/* 1036: 940 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1037: 941 */     long function_pointer = caps.glEvalPoint2;
/* 1038: 942 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1039: 943 */     nglEvalPoint2(i, j, function_pointer);
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   static native void nglEvalPoint2(int paramInt1, int paramInt2, long paramLong);
/* 1043:     */   
/* 1044:     */   public static void glEvalMesh1(int mode, int i1, int i2)
/* 1045:     */   {
/* 1046: 948 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1047: 949 */     long function_pointer = caps.glEvalMesh1;
/* 1048: 950 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1049: 951 */     nglEvalMesh1(mode, i1, i2, function_pointer);
/* 1050:     */   }
/* 1051:     */   
/* 1052:     */   static native void nglEvalMesh1(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 1053:     */   
/* 1054:     */   public static void glEvalMesh2(int mode, int i1, int i2, int j1, int j2)
/* 1055:     */   {
/* 1056: 956 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1057: 957 */     long function_pointer = caps.glEvalMesh2;
/* 1058: 958 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1059: 959 */     nglEvalMesh2(mode, i1, i2, j1, j2, function_pointer);
/* 1060:     */   }
/* 1061:     */   
/* 1062:     */   static native void nglEvalMesh2(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong);
/* 1063:     */   
/* 1064:     */   public static void glEvalCoord1f(float u)
/* 1065:     */   {
/* 1066: 964 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1067: 965 */     long function_pointer = caps.glEvalCoord1f;
/* 1068: 966 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1069: 967 */     nglEvalCoord1f(u, function_pointer);
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   static native void nglEvalCoord1f(float paramFloat, long paramLong);
/* 1073:     */   
/* 1074:     */   public static void glEvalCoord1d(double u)
/* 1075:     */   {
/* 1076: 972 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1077: 973 */     long function_pointer = caps.glEvalCoord1d;
/* 1078: 974 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1079: 975 */     nglEvalCoord1d(u, function_pointer);
/* 1080:     */   }
/* 1081:     */   
/* 1082:     */   static native void nglEvalCoord1d(double paramDouble, long paramLong);
/* 1083:     */   
/* 1084:     */   public static void glEvalCoord2f(float u, float v)
/* 1085:     */   {
/* 1086: 980 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1087: 981 */     long function_pointer = caps.glEvalCoord2f;
/* 1088: 982 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1089: 983 */     nglEvalCoord2f(u, v, function_pointer);
/* 1090:     */   }
/* 1091:     */   
/* 1092:     */   static native void nglEvalCoord2f(float paramFloat1, float paramFloat2, long paramLong);
/* 1093:     */   
/* 1094:     */   public static void glEvalCoord2d(double u, double v)
/* 1095:     */   {
/* 1096: 988 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1097: 989 */     long function_pointer = caps.glEvalCoord2d;
/* 1098: 990 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1099: 991 */     nglEvalCoord2d(u, v, function_pointer);
/* 1100:     */   }
/* 1101:     */   
/* 1102:     */   static native void nglEvalCoord2d(double paramDouble1, double paramDouble2, long paramLong);
/* 1103:     */   
/* 1104:     */   public static void glEnableClientState(int cap)
/* 1105:     */   {
/* 1106: 996 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1107: 997 */     long function_pointer = caps.glEnableClientState;
/* 1108: 998 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1109: 999 */     nglEnableClientState(cap, function_pointer);
/* 1110:     */   }
/* 1111:     */   
/* 1112:     */   static native void nglEnableClientState(int paramInt, long paramLong);
/* 1113:     */   
/* 1114:     */   public static void glDisableClientState(int cap)
/* 1115:     */   {
/* 1116:1004 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1117:1005 */     long function_pointer = caps.glDisableClientState;
/* 1118:1006 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1119:1007 */     nglDisableClientState(cap, function_pointer);
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static native void nglDisableClientState(int paramInt, long paramLong);
/* 1123:     */   
/* 1124:     */   public static void glEnable(int cap)
/* 1125:     */   {
/* 1126:1012 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1127:1013 */     long function_pointer = caps.glEnable;
/* 1128:1014 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1129:1015 */     nglEnable(cap, function_pointer);
/* 1130:     */   }
/* 1131:     */   
/* 1132:     */   static native void nglEnable(int paramInt, long paramLong);
/* 1133:     */   
/* 1134:     */   public static void glDisable(int cap)
/* 1135:     */   {
/* 1136:1020 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1137:1021 */     long function_pointer = caps.glDisable;
/* 1138:1022 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1139:1023 */     nglDisable(cap, function_pointer);
/* 1140:     */   }
/* 1141:     */   
/* 1142:     */   static native void nglDisable(int paramInt, long paramLong);
/* 1143:     */   
/* 1144:     */   public static void glEdgeFlagPointer(int stride, ByteBuffer pointer)
/* 1145:     */   {
/* 1146:1028 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1147:1029 */     long function_pointer = caps.glEdgeFlagPointer;
/* 1148:1030 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1149:1031 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1150:1032 */     BufferChecks.checkDirect(pointer);
/* 1151:1033 */     if (LWJGLUtil.CHECKS) {
/* 1152:1033 */       StateTracker.getReferences(caps).GL11_glEdgeFlagPointer_pointer = pointer;
/* 1153:     */     }
/* 1154:1034 */     nglEdgeFlagPointer(stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1155:     */   }
/* 1156:     */   
/* 1157:     */   static native void nglEdgeFlagPointer(int paramInt, long paramLong1, long paramLong2);
/* 1158:     */   
/* 1159:     */   public static void glEdgeFlagPointer(int stride, long pointer_buffer_offset)
/* 1160:     */   {
/* 1161:1038 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1162:1039 */     long function_pointer = caps.glEdgeFlagPointer;
/* 1163:1040 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1164:1041 */     GLChecks.ensureArrayVBOenabled(caps);
/* 1165:1042 */     nglEdgeFlagPointerBO(stride, pointer_buffer_offset, function_pointer);
/* 1166:     */   }
/* 1167:     */   
/* 1168:     */   static native void nglEdgeFlagPointerBO(int paramInt, long paramLong1, long paramLong2);
/* 1169:     */   
/* 1170:     */   public static void glEdgeFlag(boolean flag)
/* 1171:     */   {
/* 1172:1047 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1173:1048 */     long function_pointer = caps.glEdgeFlag;
/* 1174:1049 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1175:1050 */     nglEdgeFlag(flag, function_pointer);
/* 1176:     */   }
/* 1177:     */   
/* 1178:     */   static native void nglEdgeFlag(boolean paramBoolean, long paramLong);
/* 1179:     */   
/* 1180:     */   public static void glDrawPixels(int width, int height, int format, int type, ByteBuffer pixels)
/* 1181:     */   {
/* 1182:1055 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1183:1056 */     long function_pointer = caps.glDrawPixels;
/* 1184:1057 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1185:1058 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1186:1059 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1187:1060 */     nglDrawPixels(width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1188:     */   }
/* 1189:     */   
/* 1190:     */   public static void glDrawPixels(int width, int height, int format, int type, IntBuffer pixels)
/* 1191:     */   {
/* 1192:1063 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1193:1064 */     long function_pointer = caps.glDrawPixels;
/* 1194:1065 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1195:1066 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1196:1067 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1197:1068 */     nglDrawPixels(width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1198:     */   }
/* 1199:     */   
/* 1200:     */   public static void glDrawPixels(int width, int height, int format, int type, ShortBuffer pixels)
/* 1201:     */   {
/* 1202:1071 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1203:1072 */     long function_pointer = caps.glDrawPixels;
/* 1204:1073 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1205:1074 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 1206:1075 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 1207:1076 */     nglDrawPixels(width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1208:     */   }
/* 1209:     */   
/* 1210:     */   static native void nglDrawPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1211:     */   
/* 1212:     */   public static void glDrawPixels(int width, int height, int format, int type, long pixels_buffer_offset)
/* 1213:     */   {
/* 1214:1080 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1215:1081 */     long function_pointer = caps.glDrawPixels;
/* 1216:1082 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1217:1083 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 1218:1084 */     nglDrawPixelsBO(width, height, format, type, pixels_buffer_offset, function_pointer);
/* 1219:     */   }
/* 1220:     */   
/* 1221:     */   static native void nglDrawPixelsBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1222:     */   
/* 1223:     */   public static void glDrawElements(int mode, ByteBuffer indices)
/* 1224:     */   {
/* 1225:1089 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1226:1090 */     long function_pointer = caps.glDrawElements;
/* 1227:1091 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1228:1092 */     GLChecks.ensureElementVBOdisabled(caps);
/* 1229:1093 */     BufferChecks.checkDirect(indices);
/* 1230:1094 */     nglDrawElements(mode, indices.remaining(), 5121, MemoryUtil.getAddress(indices), function_pointer);
/* 1231:     */   }
/* 1232:     */   
/* 1233:     */   public static void glDrawElements(int mode, IntBuffer indices)
/* 1234:     */   {
/* 1235:1097 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1236:1098 */     long function_pointer = caps.glDrawElements;
/* 1237:1099 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1238:1100 */     GLChecks.ensureElementVBOdisabled(caps);
/* 1239:1101 */     BufferChecks.checkDirect(indices);
/* 1240:1102 */     nglDrawElements(mode, indices.remaining(), 5125, MemoryUtil.getAddress(indices), function_pointer);
/* 1241:     */   }
/* 1242:     */   
/* 1243:     */   public static void glDrawElements(int mode, ShortBuffer indices)
/* 1244:     */   {
/* 1245:1105 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1246:1106 */     long function_pointer = caps.glDrawElements;
/* 1247:1107 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1248:1108 */     GLChecks.ensureElementVBOdisabled(caps);
/* 1249:1109 */     BufferChecks.checkDirect(indices);
/* 1250:1110 */     nglDrawElements(mode, indices.remaining(), 5123, MemoryUtil.getAddress(indices), function_pointer);
/* 1251:     */   }
/* 1252:     */   
/* 1253:     */   static native void nglDrawElements(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1254:     */   
/* 1255:     */   public static void glDrawElements(int mode, int indices_count, int type, long indices_buffer_offset)
/* 1256:     */   {
/* 1257:1114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1258:1115 */     long function_pointer = caps.glDrawElements;
/* 1259:1116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1260:1117 */     GLChecks.ensureElementVBOenabled(caps);
/* 1261:1118 */     nglDrawElementsBO(mode, indices_count, type, indices_buffer_offset, function_pointer);
/* 1262:     */   }
/* 1263:     */   
/* 1264:     */   static native void nglDrawElementsBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1265:     */   
/* 1266:     */   public static void glDrawBuffer(int mode)
/* 1267:     */   {
/* 1268:1123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1269:1124 */     long function_pointer = caps.glDrawBuffer;
/* 1270:1125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1271:1126 */     nglDrawBuffer(mode, function_pointer);
/* 1272:     */   }
/* 1273:     */   
/* 1274:     */   static native void nglDrawBuffer(int paramInt, long paramLong);
/* 1275:     */   
/* 1276:     */   public static void glDrawArrays(int mode, int first, int count)
/* 1277:     */   {
/* 1278:1131 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1279:1132 */     long function_pointer = caps.glDrawArrays;
/* 1280:1133 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1281:1134 */     nglDrawArrays(mode, first, count, function_pointer);
/* 1282:     */   }
/* 1283:     */   
/* 1284:     */   static native void nglDrawArrays(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 1285:     */   
/* 1286:     */   public static void glDepthRange(double zNear, double zFar)
/* 1287:     */   {
/* 1288:1139 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1289:1140 */     long function_pointer = caps.glDepthRange;
/* 1290:1141 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1291:1142 */     nglDepthRange(zNear, zFar, function_pointer);
/* 1292:     */   }
/* 1293:     */   
/* 1294:     */   static native void nglDepthRange(double paramDouble1, double paramDouble2, long paramLong);
/* 1295:     */   
/* 1296:     */   public static void glDepthMask(boolean flag)
/* 1297:     */   {
/* 1298:1147 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1299:1148 */     long function_pointer = caps.glDepthMask;
/* 1300:1149 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1301:1150 */     nglDepthMask(flag, function_pointer);
/* 1302:     */   }
/* 1303:     */   
/* 1304:     */   static native void nglDepthMask(boolean paramBoolean, long paramLong);
/* 1305:     */   
/* 1306:     */   public static void glDepthFunc(int func)
/* 1307:     */   {
/* 1308:1155 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1309:1156 */     long function_pointer = caps.glDepthFunc;
/* 1310:1157 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1311:1158 */     nglDepthFunc(func, function_pointer);
/* 1312:     */   }
/* 1313:     */   
/* 1314:     */   static native void nglDepthFunc(int paramInt, long paramLong);
/* 1315:     */   
/* 1316:     */   public static void glFeedbackBuffer(int type, FloatBuffer buffer)
/* 1317:     */   {
/* 1318:1163 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1319:1164 */     long function_pointer = caps.glFeedbackBuffer;
/* 1320:1165 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1321:1166 */     BufferChecks.checkDirect(buffer);
/* 1322:1167 */     nglFeedbackBuffer(buffer.remaining(), type, MemoryUtil.getAddress(buffer), function_pointer);
/* 1323:     */   }
/* 1324:     */   
/* 1325:     */   static native void nglFeedbackBuffer(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1326:     */   
/* 1327:     */   public static void glGetPixelMap(int map, FloatBuffer values)
/* 1328:     */   {
/* 1329:1172 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1330:1173 */     long function_pointer = caps.glGetPixelMapfv;
/* 1331:1174 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1332:1175 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1333:1176 */     BufferChecks.checkBuffer(values, 256);
/* 1334:1177 */     nglGetPixelMapfv(map, MemoryUtil.getAddress(values), function_pointer);
/* 1335:     */   }
/* 1336:     */   
/* 1337:     */   static native void nglGetPixelMapfv(int paramInt, long paramLong1, long paramLong2);
/* 1338:     */   
/* 1339:     */   public static void glGetPixelMapfv(int map, long values_buffer_offset)
/* 1340:     */   {
/* 1341:1181 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1342:1182 */     long function_pointer = caps.glGetPixelMapfv;
/* 1343:1183 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1344:1184 */     GLChecks.ensurePackPBOenabled(caps);
/* 1345:1185 */     nglGetPixelMapfvBO(map, values_buffer_offset, function_pointer);
/* 1346:     */   }
/* 1347:     */   
/* 1348:     */   static native void nglGetPixelMapfvBO(int paramInt, long paramLong1, long paramLong2);
/* 1349:     */   
/* 1350:     */   public static void glGetPixelMapu(int map, IntBuffer values)
/* 1351:     */   {
/* 1352:1190 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1353:1191 */     long function_pointer = caps.glGetPixelMapuiv;
/* 1354:1192 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1355:1193 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1356:1194 */     BufferChecks.checkBuffer(values, 256);
/* 1357:1195 */     nglGetPixelMapuiv(map, MemoryUtil.getAddress(values), function_pointer);
/* 1358:     */   }
/* 1359:     */   
/* 1360:     */   static native void nglGetPixelMapuiv(int paramInt, long paramLong1, long paramLong2);
/* 1361:     */   
/* 1362:     */   public static void glGetPixelMapuiv(int map, long values_buffer_offset)
/* 1363:     */   {
/* 1364:1199 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1365:1200 */     long function_pointer = caps.glGetPixelMapuiv;
/* 1366:1201 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1367:1202 */     GLChecks.ensurePackPBOenabled(caps);
/* 1368:1203 */     nglGetPixelMapuivBO(map, values_buffer_offset, function_pointer);
/* 1369:     */   }
/* 1370:     */   
/* 1371:     */   static native void nglGetPixelMapuivBO(int paramInt, long paramLong1, long paramLong2);
/* 1372:     */   
/* 1373:     */   public static void glGetPixelMapu(int map, ShortBuffer values)
/* 1374:     */   {
/* 1375:1208 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1376:1209 */     long function_pointer = caps.glGetPixelMapusv;
/* 1377:1210 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1378:1211 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1379:1212 */     BufferChecks.checkBuffer(values, 256);
/* 1380:1213 */     nglGetPixelMapusv(map, MemoryUtil.getAddress(values), function_pointer);
/* 1381:     */   }
/* 1382:     */   
/* 1383:     */   static native void nglGetPixelMapusv(int paramInt, long paramLong1, long paramLong2);
/* 1384:     */   
/* 1385:     */   public static void glGetPixelMapusv(int map, long values_buffer_offset)
/* 1386:     */   {
/* 1387:1217 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1388:1218 */     long function_pointer = caps.glGetPixelMapusv;
/* 1389:1219 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1390:1220 */     GLChecks.ensurePackPBOenabled(caps);
/* 1391:1221 */     nglGetPixelMapusvBO(map, values_buffer_offset, function_pointer);
/* 1392:     */   }
/* 1393:     */   
/* 1394:     */   static native void nglGetPixelMapusvBO(int paramInt, long paramLong1, long paramLong2);
/* 1395:     */   
/* 1396:     */   public static void glGetMaterial(int face, int pname, FloatBuffer params)
/* 1397:     */   {
/* 1398:1226 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1399:1227 */     long function_pointer = caps.glGetMaterialfv;
/* 1400:1228 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1401:1229 */     BufferChecks.checkBuffer(params, 4);
/* 1402:1230 */     nglGetMaterialfv(face, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1403:     */   }
/* 1404:     */   
/* 1405:     */   static native void nglGetMaterialfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1406:     */   
/* 1407:     */   public static void glGetMaterial(int face, int pname, IntBuffer params)
/* 1408:     */   {
/* 1409:1235 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1410:1236 */     long function_pointer = caps.glGetMaterialiv;
/* 1411:1237 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1412:1238 */     BufferChecks.checkBuffer(params, 4);
/* 1413:1239 */     nglGetMaterialiv(face, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1414:     */   }
/* 1415:     */   
/* 1416:     */   static native void nglGetMaterialiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1417:     */   
/* 1418:     */   public static void glGetMap(int target, int query, FloatBuffer v)
/* 1419:     */   {
/* 1420:1244 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1421:1245 */     long function_pointer = caps.glGetMapfv;
/* 1422:1246 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1423:1247 */     BufferChecks.checkBuffer(v, 256);
/* 1424:1248 */     nglGetMapfv(target, query, MemoryUtil.getAddress(v), function_pointer);
/* 1425:     */   }
/* 1426:     */   
/* 1427:     */   static native void nglGetMapfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1428:     */   
/* 1429:     */   public static void glGetMap(int target, int query, DoubleBuffer v)
/* 1430:     */   {
/* 1431:1253 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1432:1254 */     long function_pointer = caps.glGetMapdv;
/* 1433:1255 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1434:1256 */     BufferChecks.checkBuffer(v, 256);
/* 1435:1257 */     nglGetMapdv(target, query, MemoryUtil.getAddress(v), function_pointer);
/* 1436:     */   }
/* 1437:     */   
/* 1438:     */   static native void nglGetMapdv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1439:     */   
/* 1440:     */   public static void glGetMap(int target, int query, IntBuffer v)
/* 1441:     */   {
/* 1442:1262 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1443:1263 */     long function_pointer = caps.glGetMapiv;
/* 1444:1264 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1445:1265 */     BufferChecks.checkBuffer(v, 256);
/* 1446:1266 */     nglGetMapiv(target, query, MemoryUtil.getAddress(v), function_pointer);
/* 1447:     */   }
/* 1448:     */   
/* 1449:     */   static native void nglGetMapiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1450:     */   
/* 1451:     */   public static void glGetLight(int light, int pname, FloatBuffer params)
/* 1452:     */   {
/* 1453:1271 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1454:1272 */     long function_pointer = caps.glGetLightfv;
/* 1455:1273 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1456:1274 */     BufferChecks.checkBuffer(params, 4);
/* 1457:1275 */     nglGetLightfv(light, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1458:     */   }
/* 1459:     */   
/* 1460:     */   static native void nglGetLightfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1461:     */   
/* 1462:     */   public static void glGetLight(int light, int pname, IntBuffer params)
/* 1463:     */   {
/* 1464:1280 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1465:1281 */     long function_pointer = caps.glGetLightiv;
/* 1466:1282 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1467:1283 */     BufferChecks.checkBuffer(params, 4);
/* 1468:1284 */     nglGetLightiv(light, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1469:     */   }
/* 1470:     */   
/* 1471:     */   static native void nglGetLightiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1472:     */   
/* 1473:     */   public static int glGetError()
/* 1474:     */   {
/* 1475:1289 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1476:1290 */     long function_pointer = caps.glGetError;
/* 1477:1291 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1478:1292 */     int __result = nglGetError(function_pointer);
/* 1479:1293 */     return __result;
/* 1480:     */   }
/* 1481:     */   
/* 1482:     */   static native int nglGetError(long paramLong);
/* 1483:     */   
/* 1484:     */   public static void glGetClipPlane(int plane, DoubleBuffer equation)
/* 1485:     */   {
/* 1486:1298 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1487:1299 */     long function_pointer = caps.glGetClipPlane;
/* 1488:1300 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1489:1301 */     BufferChecks.checkBuffer(equation, 4);
/* 1490:1302 */     nglGetClipPlane(plane, MemoryUtil.getAddress(equation), function_pointer);
/* 1491:     */   }
/* 1492:     */   
/* 1493:     */   static native void nglGetClipPlane(int paramInt, long paramLong1, long paramLong2);
/* 1494:     */   
/* 1495:     */   public static void glGetBoolean(int pname, ByteBuffer params)
/* 1496:     */   {
/* 1497:1307 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1498:1308 */     long function_pointer = caps.glGetBooleanv;
/* 1499:1309 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1500:1310 */     BufferChecks.checkBuffer(params, 16);
/* 1501:1311 */     nglGetBooleanv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1502:     */   }
/* 1503:     */   
/* 1504:     */   static native void nglGetBooleanv(int paramInt, long paramLong1, long paramLong2);
/* 1505:     */   
/* 1506:     */   public static boolean glGetBoolean(int pname)
/* 1507:     */   {
/* 1508:1317 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1509:1318 */     long function_pointer = caps.glGetBooleanv;
/* 1510:1319 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1511:1320 */     ByteBuffer params = APIUtil.getBufferByte(caps, 1);
/* 1512:1321 */     nglGetBooleanv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1513:1322 */     return params.get(0) == 1;
/* 1514:     */   }
/* 1515:     */   
/* 1516:     */   public static void glGetDouble(int pname, DoubleBuffer params)
/* 1517:     */   {
/* 1518:1326 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1519:1327 */     long function_pointer = caps.glGetDoublev;
/* 1520:1328 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1521:1329 */     BufferChecks.checkBuffer(params, 16);
/* 1522:1330 */     nglGetDoublev(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1523:     */   }
/* 1524:     */   
/* 1525:     */   static native void nglGetDoublev(int paramInt, long paramLong1, long paramLong2);
/* 1526:     */   
/* 1527:     */   public static double glGetDouble(int pname)
/* 1528:     */   {
/* 1529:1336 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1530:1337 */     long function_pointer = caps.glGetDoublev;
/* 1531:1338 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1532:1339 */     DoubleBuffer params = APIUtil.getBufferDouble(caps);
/* 1533:1340 */     nglGetDoublev(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1534:1341 */     return params.get(0);
/* 1535:     */   }
/* 1536:     */   
/* 1537:     */   public static void glGetFloat(int pname, FloatBuffer params)
/* 1538:     */   {
/* 1539:1345 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1540:1346 */     long function_pointer = caps.glGetFloatv;
/* 1541:1347 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1542:1348 */     BufferChecks.checkBuffer(params, 16);
/* 1543:1349 */     nglGetFloatv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1544:     */   }
/* 1545:     */   
/* 1546:     */   static native void nglGetFloatv(int paramInt, long paramLong1, long paramLong2);
/* 1547:     */   
/* 1548:     */   public static float glGetFloat(int pname)
/* 1549:     */   {
/* 1550:1355 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1551:1356 */     long function_pointer = caps.glGetFloatv;
/* 1552:1357 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1553:1358 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1554:1359 */     nglGetFloatv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1555:1360 */     return params.get(0);
/* 1556:     */   }
/* 1557:     */   
/* 1558:     */   public static void glGetInteger(int pname, IntBuffer params)
/* 1559:     */   {
/* 1560:1364 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1561:1365 */     long function_pointer = caps.glGetIntegerv;
/* 1562:1366 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1563:1367 */     BufferChecks.checkBuffer(params, 16);
/* 1564:1368 */     nglGetIntegerv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1565:     */   }
/* 1566:     */   
/* 1567:     */   static native void nglGetIntegerv(int paramInt, long paramLong1, long paramLong2);
/* 1568:     */   
/* 1569:     */   public static int glGetInteger(int pname)
/* 1570:     */   {
/* 1571:1374 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1572:1375 */     long function_pointer = caps.glGetIntegerv;
/* 1573:1376 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1574:1377 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1575:1378 */     nglGetIntegerv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1576:1379 */     return params.get(0);
/* 1577:     */   }
/* 1578:     */   
/* 1579:     */   public static void glGenTextures(IntBuffer textures)
/* 1580:     */   {
/* 1581:1383 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1582:1384 */     long function_pointer = caps.glGenTextures;
/* 1583:1385 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1584:1386 */     BufferChecks.checkDirect(textures);
/* 1585:1387 */     nglGenTextures(textures.remaining(), MemoryUtil.getAddress(textures), function_pointer);
/* 1586:     */   }
/* 1587:     */   
/* 1588:     */   static native void nglGenTextures(int paramInt, long paramLong1, long paramLong2);
/* 1589:     */   
/* 1590:     */   public static int glGenTextures()
/* 1591:     */   {
/* 1592:1393 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1593:1394 */     long function_pointer = caps.glGenTextures;
/* 1594:1395 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1595:1396 */     IntBuffer textures = APIUtil.getBufferInt(caps);
/* 1596:1397 */     nglGenTextures(1, MemoryUtil.getAddress(textures), function_pointer);
/* 1597:1398 */     return textures.get(0);
/* 1598:     */   }
/* 1599:     */   
/* 1600:     */   public static int glGenLists(int range)
/* 1601:     */   {
/* 1602:1402 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1603:1403 */     long function_pointer = caps.glGenLists;
/* 1604:1404 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1605:1405 */     int __result = nglGenLists(range, function_pointer);
/* 1606:1406 */     return __result;
/* 1607:     */   }
/* 1608:     */   
/* 1609:     */   static native int nglGenLists(int paramInt, long paramLong);
/* 1610:     */   
/* 1611:     */   public static void glFrustum(double left, double right, double bottom, double top, double zNear, double zFar)
/* 1612:     */   {
/* 1613:1411 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1614:1412 */     long function_pointer = caps.glFrustum;
/* 1615:1413 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1616:1414 */     nglFrustum(left, right, bottom, top, zNear, zFar, function_pointer);
/* 1617:     */   }
/* 1618:     */   
/* 1619:     */   static native void nglFrustum(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, long paramLong);
/* 1620:     */   
/* 1621:     */   public static void glFrontFace(int mode)
/* 1622:     */   {
/* 1623:1419 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1624:1420 */     long function_pointer = caps.glFrontFace;
/* 1625:1421 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1626:1422 */     nglFrontFace(mode, function_pointer);
/* 1627:     */   }
/* 1628:     */   
/* 1629:     */   static native void nglFrontFace(int paramInt, long paramLong);
/* 1630:     */   
/* 1631:     */   public static void glFogf(int pname, float param)
/* 1632:     */   {
/* 1633:1427 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1634:1428 */     long function_pointer = caps.glFogf;
/* 1635:1429 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1636:1430 */     nglFogf(pname, param, function_pointer);
/* 1637:     */   }
/* 1638:     */   
/* 1639:     */   static native void nglFogf(int paramInt, float paramFloat, long paramLong);
/* 1640:     */   
/* 1641:     */   public static void glFogi(int pname, int param)
/* 1642:     */   {
/* 1643:1435 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1644:1436 */     long function_pointer = caps.glFogi;
/* 1645:1437 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1646:1438 */     nglFogi(pname, param, function_pointer);
/* 1647:     */   }
/* 1648:     */   
/* 1649:     */   static native void nglFogi(int paramInt1, int paramInt2, long paramLong);
/* 1650:     */   
/* 1651:     */   public static void glFog(int pname, FloatBuffer params)
/* 1652:     */   {
/* 1653:1443 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1654:1444 */     long function_pointer = caps.glFogfv;
/* 1655:1445 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1656:1446 */     BufferChecks.checkBuffer(params, 4);
/* 1657:1447 */     nglFogfv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1658:     */   }
/* 1659:     */   
/* 1660:     */   static native void nglFogfv(int paramInt, long paramLong1, long paramLong2);
/* 1661:     */   
/* 1662:     */   public static void glFog(int pname, IntBuffer params)
/* 1663:     */   {
/* 1664:1452 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1665:1453 */     long function_pointer = caps.glFogiv;
/* 1666:1454 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1667:1455 */     BufferChecks.checkBuffer(params, 4);
/* 1668:1456 */     nglFogiv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 1669:     */   }
/* 1670:     */   
/* 1671:     */   static native void nglFogiv(int paramInt, long paramLong1, long paramLong2);
/* 1672:     */   
/* 1673:     */   public static void glFlush()
/* 1674:     */   {
/* 1675:1461 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1676:1462 */     long function_pointer = caps.glFlush;
/* 1677:1463 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1678:1464 */     nglFlush(function_pointer);
/* 1679:     */   }
/* 1680:     */   
/* 1681:     */   static native void nglFlush(long paramLong);
/* 1682:     */   
/* 1683:     */   public static void glFinish()
/* 1684:     */   {
/* 1685:1469 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1686:1470 */     long function_pointer = caps.glFinish;
/* 1687:1471 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1688:1472 */     nglFinish(function_pointer);
/* 1689:     */   }
/* 1690:     */   
/* 1691:     */   static native void nglFinish(long paramLong);
/* 1692:     */   
/* 1693:     */   public static ByteBuffer glGetPointer(int pname, long result_size)
/* 1694:     */   {
/* 1695:1477 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1696:1478 */     long function_pointer = caps.glGetPointerv;
/* 1697:1479 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1698:1480 */     ByteBuffer __result = nglGetPointerv(pname, result_size, function_pointer);
/* 1699:1481 */     return (LWJGLUtil.CHECKS) && (__result == null) ? null : __result.order(ByteOrder.nativeOrder());
/* 1700:     */   }
/* 1701:     */   
/* 1702:     */   static native ByteBuffer nglGetPointerv(int paramInt, long paramLong1, long paramLong2);
/* 1703:     */   
/* 1704:     */   public static boolean glIsEnabled(int cap)
/* 1705:     */   {
/* 1706:1486 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1707:1487 */     long function_pointer = caps.glIsEnabled;
/* 1708:1488 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1709:1489 */     boolean __result = nglIsEnabled(cap, function_pointer);
/* 1710:1490 */     return __result;
/* 1711:     */   }
/* 1712:     */   
/* 1713:     */   static native boolean nglIsEnabled(int paramInt, long paramLong);
/* 1714:     */   
/* 1715:     */   public static void glInterleavedArrays(int format, int stride, ByteBuffer pointer)
/* 1716:     */   {
/* 1717:1495 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1718:1496 */     long function_pointer = caps.glInterleavedArrays;
/* 1719:1497 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1720:1498 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1721:1499 */     BufferChecks.checkDirect(pointer);
/* 1722:1500 */     nglInterleavedArrays(format, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1723:     */   }
/* 1724:     */   
/* 1725:     */   public static void glInterleavedArrays(int format, int stride, DoubleBuffer pointer)
/* 1726:     */   {
/* 1727:1503 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1728:1504 */     long function_pointer = caps.glInterleavedArrays;
/* 1729:1505 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1730:1506 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1731:1507 */     BufferChecks.checkDirect(pointer);
/* 1732:1508 */     nglInterleavedArrays(format, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1733:     */   }
/* 1734:     */   
/* 1735:     */   public static void glInterleavedArrays(int format, int stride, FloatBuffer pointer)
/* 1736:     */   {
/* 1737:1511 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1738:1512 */     long function_pointer = caps.glInterleavedArrays;
/* 1739:1513 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1740:1514 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1741:1515 */     BufferChecks.checkDirect(pointer);
/* 1742:1516 */     nglInterleavedArrays(format, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1743:     */   }
/* 1744:     */   
/* 1745:     */   public static void glInterleavedArrays(int format, int stride, IntBuffer pointer)
/* 1746:     */   {
/* 1747:1519 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1748:1520 */     long function_pointer = caps.glInterleavedArrays;
/* 1749:1521 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1750:1522 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1751:1523 */     BufferChecks.checkDirect(pointer);
/* 1752:1524 */     nglInterleavedArrays(format, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1753:     */   }
/* 1754:     */   
/* 1755:     */   public static void glInterleavedArrays(int format, int stride, ShortBuffer pointer)
/* 1756:     */   {
/* 1757:1527 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1758:1528 */     long function_pointer = caps.glInterleavedArrays;
/* 1759:1529 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1760:1530 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 1761:1531 */     BufferChecks.checkDirect(pointer);
/* 1762:1532 */     nglInterleavedArrays(format, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 1763:     */   }
/* 1764:     */   
/* 1765:     */   static native void nglInterleavedArrays(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1766:     */   
/* 1767:     */   public static void glInterleavedArrays(int format, int stride, long pointer_buffer_offset)
/* 1768:     */   {
/* 1769:1536 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1770:1537 */     long function_pointer = caps.glInterleavedArrays;
/* 1771:1538 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1772:1539 */     GLChecks.ensureArrayVBOenabled(caps);
/* 1773:1540 */     nglInterleavedArraysBO(format, stride, pointer_buffer_offset, function_pointer);
/* 1774:     */   }
/* 1775:     */   
/* 1776:     */   static native void nglInterleavedArraysBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1777:     */   
/* 1778:     */   public static void glInitNames()
/* 1779:     */   {
/* 1780:1545 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1781:1546 */     long function_pointer = caps.glInitNames;
/* 1782:1547 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1783:1548 */     nglInitNames(function_pointer);
/* 1784:     */   }
/* 1785:     */   
/* 1786:     */   static native void nglInitNames(long paramLong);
/* 1787:     */   
/* 1788:     */   public static void glHint(int target, int mode)
/* 1789:     */   {
/* 1790:1553 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1791:1554 */     long function_pointer = caps.glHint;
/* 1792:1555 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1793:1556 */     nglHint(target, mode, function_pointer);
/* 1794:     */   }
/* 1795:     */   
/* 1796:     */   static native void nglHint(int paramInt1, int paramInt2, long paramLong);
/* 1797:     */   
/* 1798:     */   public static void glGetTexParameter(int target, int pname, FloatBuffer params)
/* 1799:     */   {
/* 1800:1561 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1801:1562 */     long function_pointer = caps.glGetTexParameterfv;
/* 1802:1563 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1803:1564 */     BufferChecks.checkBuffer(params, 4);
/* 1804:1565 */     nglGetTexParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1805:     */   }
/* 1806:     */   
/* 1807:     */   static native void nglGetTexParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1808:     */   
/* 1809:     */   public static float glGetTexParameterf(int target, int pname)
/* 1810:     */   {
/* 1811:1571 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1812:1572 */     long function_pointer = caps.glGetTexParameterfv;
/* 1813:1573 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1814:1574 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1815:1575 */     nglGetTexParameterfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1816:1576 */     return params.get(0);
/* 1817:     */   }
/* 1818:     */   
/* 1819:     */   public static void glGetTexParameter(int target, int pname, IntBuffer params)
/* 1820:     */   {
/* 1821:1580 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1822:1581 */     long function_pointer = caps.glGetTexParameteriv;
/* 1823:1582 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1824:1583 */     BufferChecks.checkBuffer(params, 4);
/* 1825:1584 */     nglGetTexParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1826:     */   }
/* 1827:     */   
/* 1828:     */   static native void nglGetTexParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1829:     */   
/* 1830:     */   public static int glGetTexParameteri(int target, int pname)
/* 1831:     */   {
/* 1832:1590 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1833:1591 */     long function_pointer = caps.glGetTexParameteriv;
/* 1834:1592 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1835:1593 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1836:1594 */     nglGetTexParameteriv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1837:1595 */     return params.get(0);
/* 1838:     */   }
/* 1839:     */   
/* 1840:     */   public static void glGetTexLevelParameter(int target, int level, int pname, FloatBuffer params)
/* 1841:     */   {
/* 1842:1599 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1843:1600 */     long function_pointer = caps.glGetTexLevelParameterfv;
/* 1844:1601 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1845:1602 */     BufferChecks.checkBuffer(params, 4);
/* 1846:1603 */     nglGetTexLevelParameterfv(target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1847:     */   }
/* 1848:     */   
/* 1849:     */   static native void nglGetTexLevelParameterfv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1850:     */   
/* 1851:     */   public static float glGetTexLevelParameterf(int target, int level, int pname)
/* 1852:     */   {
/* 1853:1609 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1854:1610 */     long function_pointer = caps.glGetTexLevelParameterfv;
/* 1855:1611 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1856:1612 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1857:1613 */     nglGetTexLevelParameterfv(target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1858:1614 */     return params.get(0);
/* 1859:     */   }
/* 1860:     */   
/* 1861:     */   public static void glGetTexLevelParameter(int target, int level, int pname, IntBuffer params)
/* 1862:     */   {
/* 1863:1618 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1864:1619 */     long function_pointer = caps.glGetTexLevelParameteriv;
/* 1865:1620 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1866:1621 */     BufferChecks.checkBuffer(params, 4);
/* 1867:1622 */     nglGetTexLevelParameteriv(target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1868:     */   }
/* 1869:     */   
/* 1870:     */   static native void nglGetTexLevelParameteriv(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 1871:     */   
/* 1872:     */   public static int glGetTexLevelParameteri(int target, int level, int pname)
/* 1873:     */   {
/* 1874:1628 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1875:1629 */     long function_pointer = caps.glGetTexLevelParameteriv;
/* 1876:1630 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1877:1631 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1878:1632 */     nglGetTexLevelParameteriv(target, level, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1879:1633 */     return params.get(0);
/* 1880:     */   }
/* 1881:     */   
/* 1882:     */   public static void glGetTexImage(int target, int level, int format, int type, ByteBuffer pixels)
/* 1883:     */   {
/* 1884:1637 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1885:1638 */     long function_pointer = caps.glGetTexImage;
/* 1886:1639 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1887:1640 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1888:1641 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1889:1642 */     nglGetTexImage(target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1890:     */   }
/* 1891:     */   
/* 1892:     */   public static void glGetTexImage(int target, int level, int format, int type, DoubleBuffer pixels)
/* 1893:     */   {
/* 1894:1645 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1895:1646 */     long function_pointer = caps.glGetTexImage;
/* 1896:1647 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1897:1648 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1898:1649 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1899:1650 */     nglGetTexImage(target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1900:     */   }
/* 1901:     */   
/* 1902:     */   public static void glGetTexImage(int target, int level, int format, int type, FloatBuffer pixels)
/* 1903:     */   {
/* 1904:1653 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1905:1654 */     long function_pointer = caps.glGetTexImage;
/* 1906:1655 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1907:1656 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1908:1657 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1909:1658 */     nglGetTexImage(target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1910:     */   }
/* 1911:     */   
/* 1912:     */   public static void glGetTexImage(int target, int level, int format, int type, IntBuffer pixels)
/* 1913:     */   {
/* 1914:1661 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1915:1662 */     long function_pointer = caps.glGetTexImage;
/* 1916:1663 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1917:1664 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1918:1665 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1919:1666 */     nglGetTexImage(target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1920:     */   }
/* 1921:     */   
/* 1922:     */   public static void glGetTexImage(int target, int level, int format, int type, ShortBuffer pixels)
/* 1923:     */   {
/* 1924:1669 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1925:1670 */     long function_pointer = caps.glGetTexImage;
/* 1926:1671 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1927:1672 */     GLChecks.ensurePackPBOdisabled(caps);
/* 1928:1673 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, 1, 1, 1));
/* 1929:1674 */     nglGetTexImage(target, level, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 1930:     */   }
/* 1931:     */   
/* 1932:     */   static native void nglGetTexImage(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1933:     */   
/* 1934:     */   public static void glGetTexImage(int target, int level, int format, int type, long pixels_buffer_offset)
/* 1935:     */   {
/* 1936:1678 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1937:1679 */     long function_pointer = caps.glGetTexImage;
/* 1938:1680 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1939:1681 */     GLChecks.ensurePackPBOenabled(caps);
/* 1940:1682 */     nglGetTexImageBO(target, level, format, type, pixels_buffer_offset, function_pointer);
/* 1941:     */   }
/* 1942:     */   
/* 1943:     */   static native void nglGetTexImageBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong1, long paramLong2);
/* 1944:     */   
/* 1945:     */   public static void glGetTexGen(int coord, int pname, IntBuffer params)
/* 1946:     */   {
/* 1947:1687 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1948:1688 */     long function_pointer = caps.glGetTexGeniv;
/* 1949:1689 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1950:1690 */     BufferChecks.checkBuffer(params, 4);
/* 1951:1691 */     nglGetTexGeniv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1952:     */   }
/* 1953:     */   
/* 1954:     */   static native void nglGetTexGeniv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1955:     */   
/* 1956:     */   public static int glGetTexGeni(int coord, int pname)
/* 1957:     */   {
/* 1958:1697 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1959:1698 */     long function_pointer = caps.glGetTexGeniv;
/* 1960:1699 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1961:1700 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 1962:1701 */     nglGetTexGeniv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1963:1702 */     return params.get(0);
/* 1964:     */   }
/* 1965:     */   
/* 1966:     */   public static void glGetTexGen(int coord, int pname, FloatBuffer params)
/* 1967:     */   {
/* 1968:1706 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1969:1707 */     long function_pointer = caps.glGetTexGenfv;
/* 1970:1708 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1971:1709 */     BufferChecks.checkBuffer(params, 4);
/* 1972:1710 */     nglGetTexGenfv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1973:     */   }
/* 1974:     */   
/* 1975:     */   static native void nglGetTexGenfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1976:     */   
/* 1977:     */   public static float glGetTexGenf(int coord, int pname)
/* 1978:     */   {
/* 1979:1716 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1980:1717 */     long function_pointer = caps.glGetTexGenfv;
/* 1981:1718 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1982:1719 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 1983:1720 */     nglGetTexGenfv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1984:1721 */     return params.get(0);
/* 1985:     */   }
/* 1986:     */   
/* 1987:     */   public static void glGetTexGen(int coord, int pname, DoubleBuffer params)
/* 1988:     */   {
/* 1989:1725 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 1990:1726 */     long function_pointer = caps.glGetTexGendv;
/* 1991:1727 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 1992:1728 */     BufferChecks.checkBuffer(params, 4);
/* 1993:1729 */     nglGetTexGendv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 1994:     */   }
/* 1995:     */   
/* 1996:     */   static native void nglGetTexGendv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 1997:     */   
/* 1998:     */   public static double glGetTexGend(int coord, int pname)
/* 1999:     */   {
/* 2000:1735 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2001:1736 */     long function_pointer = caps.glGetTexGendv;
/* 2002:1737 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2003:1738 */     DoubleBuffer params = APIUtil.getBufferDouble(caps);
/* 2004:1739 */     nglGetTexGendv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2005:1740 */     return params.get(0);
/* 2006:     */   }
/* 2007:     */   
/* 2008:     */   public static void glGetTexEnv(int coord, int pname, IntBuffer params)
/* 2009:     */   {
/* 2010:1744 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2011:1745 */     long function_pointer = caps.glGetTexEnviv;
/* 2012:1746 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2013:1747 */     BufferChecks.checkBuffer(params, 4);
/* 2014:1748 */     nglGetTexEnviv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2015:     */   }
/* 2016:     */   
/* 2017:     */   static native void nglGetTexEnviv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2018:     */   
/* 2019:     */   public static int glGetTexEnvi(int coord, int pname)
/* 2020:     */   {
/* 2021:1754 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2022:1755 */     long function_pointer = caps.glGetTexEnviv;
/* 2023:1756 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2024:1757 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 2025:1758 */     nglGetTexEnviv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2026:1759 */     return params.get(0);
/* 2027:     */   }
/* 2028:     */   
/* 2029:     */   public static void glGetTexEnv(int coord, int pname, FloatBuffer params)
/* 2030:     */   {
/* 2031:1763 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2032:1764 */     long function_pointer = caps.glGetTexEnvfv;
/* 2033:1765 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2034:1766 */     BufferChecks.checkBuffer(params, 4);
/* 2035:1767 */     nglGetTexEnvfv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2036:     */   }
/* 2037:     */   
/* 2038:     */   static native void nglGetTexEnvfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2039:     */   
/* 2040:     */   public static float glGetTexEnvf(int coord, int pname)
/* 2041:     */   {
/* 2042:1773 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2043:1774 */     long function_pointer = caps.glGetTexEnvfv;
/* 2044:1775 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2045:1776 */     FloatBuffer params = APIUtil.getBufferFloat(caps);
/* 2046:1777 */     nglGetTexEnvfv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2047:1778 */     return params.get(0);
/* 2048:     */   }
/* 2049:     */   
/* 2050:     */   public static String glGetString(int name)
/* 2051:     */   {
/* 2052:1782 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2053:1783 */     long function_pointer = caps.glGetString;
/* 2054:1784 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2055:1785 */     String __result = nglGetString(name, function_pointer);
/* 2056:1786 */     return __result;
/* 2057:     */   }
/* 2058:     */   
/* 2059:     */   static native String nglGetString(int paramInt, long paramLong);
/* 2060:     */   
/* 2061:     */   public static void glGetPolygonStipple(ByteBuffer mask)
/* 2062:     */   {
/* 2063:1791 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2064:1792 */     long function_pointer = caps.glGetPolygonStipple;
/* 2065:1793 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2066:1794 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2067:1795 */     BufferChecks.checkBuffer(mask, 128);
/* 2068:1796 */     nglGetPolygonStipple(MemoryUtil.getAddress(mask), function_pointer);
/* 2069:     */   }
/* 2070:     */   
/* 2071:     */   static native void nglGetPolygonStipple(long paramLong1, long paramLong2);
/* 2072:     */   
/* 2073:     */   public static void glGetPolygonStipple(long mask_buffer_offset)
/* 2074:     */   {
/* 2075:1800 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2076:1801 */     long function_pointer = caps.glGetPolygonStipple;
/* 2077:1802 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2078:1803 */     GLChecks.ensurePackPBOenabled(caps);
/* 2079:1804 */     nglGetPolygonStippleBO(mask_buffer_offset, function_pointer);
/* 2080:     */   }
/* 2081:     */   
/* 2082:     */   static native void nglGetPolygonStippleBO(long paramLong1, long paramLong2);
/* 2083:     */   
/* 2084:     */   public static boolean glIsList(int list)
/* 2085:     */   {
/* 2086:1809 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2087:1810 */     long function_pointer = caps.glIsList;
/* 2088:1811 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2089:1812 */     boolean __result = nglIsList(list, function_pointer);
/* 2090:1813 */     return __result;
/* 2091:     */   }
/* 2092:     */   
/* 2093:     */   static native boolean nglIsList(int paramInt, long paramLong);
/* 2094:     */   
/* 2095:     */   public static void glMaterialf(int face, int pname, float param)
/* 2096:     */   {
/* 2097:1818 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2098:1819 */     long function_pointer = caps.glMaterialf;
/* 2099:1820 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2100:1821 */     nglMaterialf(face, pname, param, function_pointer);
/* 2101:     */   }
/* 2102:     */   
/* 2103:     */   static native void nglMaterialf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 2104:     */   
/* 2105:     */   public static void glMateriali(int face, int pname, int param)
/* 2106:     */   {
/* 2107:1826 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2108:1827 */     long function_pointer = caps.glMateriali;
/* 2109:1828 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2110:1829 */     nglMateriali(face, pname, param, function_pointer);
/* 2111:     */   }
/* 2112:     */   
/* 2113:     */   static native void nglMateriali(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 2114:     */   
/* 2115:     */   public static void glMaterial(int face, int pname, FloatBuffer params)
/* 2116:     */   {
/* 2117:1834 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2118:1835 */     long function_pointer = caps.glMaterialfv;
/* 2119:1836 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2120:1837 */     BufferChecks.checkBuffer(params, 4);
/* 2121:1838 */     nglMaterialfv(face, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2122:     */   }
/* 2123:     */   
/* 2124:     */   static native void nglMaterialfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2125:     */   
/* 2126:     */   public static void glMaterial(int face, int pname, IntBuffer params)
/* 2127:     */   {
/* 2128:1843 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2129:1844 */     long function_pointer = caps.glMaterialiv;
/* 2130:1845 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2131:1846 */     BufferChecks.checkBuffer(params, 4);
/* 2132:1847 */     nglMaterialiv(face, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2133:     */   }
/* 2134:     */   
/* 2135:     */   static native void nglMaterialiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2136:     */   
/* 2137:     */   public static void glMapGrid1f(int un, float u1, float u2)
/* 2138:     */   {
/* 2139:1852 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2140:1853 */     long function_pointer = caps.glMapGrid1f;
/* 2141:1854 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2142:1855 */     nglMapGrid1f(un, u1, u2, function_pointer);
/* 2143:     */   }
/* 2144:     */   
/* 2145:     */   static native void nglMapGrid1f(int paramInt, float paramFloat1, float paramFloat2, long paramLong);
/* 2146:     */   
/* 2147:     */   public static void glMapGrid1d(int un, double u1, double u2)
/* 2148:     */   {
/* 2149:1860 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2150:1861 */     long function_pointer = caps.glMapGrid1d;
/* 2151:1862 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2152:1863 */     nglMapGrid1d(un, u1, u2, function_pointer);
/* 2153:     */   }
/* 2154:     */   
/* 2155:     */   static native void nglMapGrid1d(int paramInt, double paramDouble1, double paramDouble2, long paramLong);
/* 2156:     */   
/* 2157:     */   public static void glMapGrid2f(int un, float u1, float u2, int vn, float v1, float v2)
/* 2158:     */   {
/* 2159:1868 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2160:1869 */     long function_pointer = caps.glMapGrid2f;
/* 2161:1870 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2162:1871 */     nglMapGrid2f(un, u1, u2, vn, v1, v2, function_pointer);
/* 2163:     */   }
/* 2164:     */   
/* 2165:     */   static native void nglMapGrid2f(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, float paramFloat3, float paramFloat4, long paramLong);
/* 2166:     */   
/* 2167:     */   public static void glMapGrid2d(int un, double u1, double u2, int vn, double v1, double v2)
/* 2168:     */   {
/* 2169:1876 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2170:1877 */     long function_pointer = caps.glMapGrid2d;
/* 2171:1878 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2172:1879 */     nglMapGrid2d(un, u1, u2, vn, v1, v2, function_pointer);
/* 2173:     */   }
/* 2174:     */   
/* 2175:     */   static native void nglMapGrid2d(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, double paramDouble3, double paramDouble4, long paramLong);
/* 2176:     */   
/* 2177:     */   public static void glMap2f(int target, float u1, float u2, int ustride, int uorder, float v1, float v2, int vstride, int vorder, FloatBuffer points)
/* 2178:     */   {
/* 2179:1884 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2180:1885 */     long function_pointer = caps.glMap2f;
/* 2181:1886 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2182:1887 */     BufferChecks.checkDirect(points);
/* 2183:1888 */     nglMap2f(target, u1, u2, ustride, uorder, v1, v2, vstride, vorder, MemoryUtil.getAddress(points), function_pointer);
/* 2184:     */   }
/* 2185:     */   
/* 2186:     */   static native void nglMap2f(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, int paramInt3, float paramFloat3, float paramFloat4, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 2187:     */   
/* 2188:     */   public static void glMap2d(int target, double u1, double u2, int ustride, int uorder, double v1, double v2, int vstride, int vorder, DoubleBuffer points)
/* 2189:     */   {
/* 2190:1893 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2191:1894 */     long function_pointer = caps.glMap2d;
/* 2192:1895 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2193:1896 */     BufferChecks.checkDirect(points);
/* 2194:1897 */     nglMap2d(target, u1, u2, ustride, uorder, v1, v2, vstride, vorder, MemoryUtil.getAddress(points), function_pointer);
/* 2195:     */   }
/* 2196:     */   
/* 2197:     */   static native void nglMap2d(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, double paramDouble3, double paramDouble4, int paramInt4, int paramInt5, long paramLong1, long paramLong2);
/* 2198:     */   
/* 2199:     */   public static void glMap1f(int target, float u1, float u2, int stride, int order, FloatBuffer points)
/* 2200:     */   {
/* 2201:1902 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2202:1903 */     long function_pointer = caps.glMap1f;
/* 2203:1904 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2204:1905 */     BufferChecks.checkDirect(points);
/* 2205:1906 */     nglMap1f(target, u1, u2, stride, order, MemoryUtil.getAddress(points), function_pointer);
/* 2206:     */   }
/* 2207:     */   
/* 2208:     */   static native void nglMap1f(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2209:     */   
/* 2210:     */   public static void glMap1d(int target, double u1, double u2, int stride, int order, DoubleBuffer points)
/* 2211:     */   {
/* 2212:1911 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2213:1912 */     long function_pointer = caps.glMap1d;
/* 2214:1913 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2215:1914 */     BufferChecks.checkDirect(points);
/* 2216:1915 */     nglMap1d(target, u1, u2, stride, order, MemoryUtil.getAddress(points), function_pointer);
/* 2217:     */   }
/* 2218:     */   
/* 2219:     */   static native void nglMap1d(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 2220:     */   
/* 2221:     */   public static void glLogicOp(int opcode)
/* 2222:     */   {
/* 2223:1920 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2224:1921 */     long function_pointer = caps.glLogicOp;
/* 2225:1922 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2226:1923 */     nglLogicOp(opcode, function_pointer);
/* 2227:     */   }
/* 2228:     */   
/* 2229:     */   static native void nglLogicOp(int paramInt, long paramLong);
/* 2230:     */   
/* 2231:     */   public static void glLoadName(int name)
/* 2232:     */   {
/* 2233:1928 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2234:1929 */     long function_pointer = caps.glLoadName;
/* 2235:1930 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2236:1931 */     nglLoadName(name, function_pointer);
/* 2237:     */   }
/* 2238:     */   
/* 2239:     */   static native void nglLoadName(int paramInt, long paramLong);
/* 2240:     */   
/* 2241:     */   public static void glLoadMatrix(FloatBuffer m)
/* 2242:     */   {
/* 2243:1936 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2244:1937 */     long function_pointer = caps.glLoadMatrixf;
/* 2245:1938 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2246:1939 */     BufferChecks.checkBuffer(m, 16);
/* 2247:1940 */     nglLoadMatrixf(MemoryUtil.getAddress(m), function_pointer);
/* 2248:     */   }
/* 2249:     */   
/* 2250:     */   static native void nglLoadMatrixf(long paramLong1, long paramLong2);
/* 2251:     */   
/* 2252:     */   public static void glLoadMatrix(DoubleBuffer m)
/* 2253:     */   {
/* 2254:1945 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2255:1946 */     long function_pointer = caps.glLoadMatrixd;
/* 2256:1947 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2257:1948 */     BufferChecks.checkBuffer(m, 16);
/* 2258:1949 */     nglLoadMatrixd(MemoryUtil.getAddress(m), function_pointer);
/* 2259:     */   }
/* 2260:     */   
/* 2261:     */   static native void nglLoadMatrixd(long paramLong1, long paramLong2);
/* 2262:     */   
/* 2263:     */   public static void glLoadIdentity()
/* 2264:     */   {
/* 2265:1954 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2266:1955 */     long function_pointer = caps.glLoadIdentity;
/* 2267:1956 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2268:1957 */     nglLoadIdentity(function_pointer);
/* 2269:     */   }
/* 2270:     */   
/* 2271:     */   static native void nglLoadIdentity(long paramLong);
/* 2272:     */   
/* 2273:     */   public static void glListBase(int base)
/* 2274:     */   {
/* 2275:1962 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2276:1963 */     long function_pointer = caps.glListBase;
/* 2277:1964 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2278:1965 */     nglListBase(base, function_pointer);
/* 2279:     */   }
/* 2280:     */   
/* 2281:     */   static native void nglListBase(int paramInt, long paramLong);
/* 2282:     */   
/* 2283:     */   public static void glLineWidth(float width)
/* 2284:     */   {
/* 2285:1970 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2286:1971 */     long function_pointer = caps.glLineWidth;
/* 2287:1972 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2288:1973 */     nglLineWidth(width, function_pointer);
/* 2289:     */   }
/* 2290:     */   
/* 2291:     */   static native void nglLineWidth(float paramFloat, long paramLong);
/* 2292:     */   
/* 2293:     */   public static void glLineStipple(int factor, short pattern)
/* 2294:     */   {
/* 2295:1978 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2296:1979 */     long function_pointer = caps.glLineStipple;
/* 2297:1980 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2298:1981 */     nglLineStipple(factor, pattern, function_pointer);
/* 2299:     */   }
/* 2300:     */   
/* 2301:     */   static native void nglLineStipple(int paramInt, short paramShort, long paramLong);
/* 2302:     */   
/* 2303:     */   public static void glLightModelf(int pname, float param)
/* 2304:     */   {
/* 2305:1986 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2306:1987 */     long function_pointer = caps.glLightModelf;
/* 2307:1988 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2308:1989 */     nglLightModelf(pname, param, function_pointer);
/* 2309:     */   }
/* 2310:     */   
/* 2311:     */   static native void nglLightModelf(int paramInt, float paramFloat, long paramLong);
/* 2312:     */   
/* 2313:     */   public static void glLightModeli(int pname, int param)
/* 2314:     */   {
/* 2315:1994 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2316:1995 */     long function_pointer = caps.glLightModeli;
/* 2317:1996 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2318:1997 */     nglLightModeli(pname, param, function_pointer);
/* 2319:     */   }
/* 2320:     */   
/* 2321:     */   static native void nglLightModeli(int paramInt1, int paramInt2, long paramLong);
/* 2322:     */   
/* 2323:     */   public static void glLightModel(int pname, FloatBuffer params)
/* 2324:     */   {
/* 2325:2002 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2326:2003 */     long function_pointer = caps.glLightModelfv;
/* 2327:2004 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2328:2005 */     BufferChecks.checkBuffer(params, 4);
/* 2329:2006 */     nglLightModelfv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 2330:     */   }
/* 2331:     */   
/* 2332:     */   static native void nglLightModelfv(int paramInt, long paramLong1, long paramLong2);
/* 2333:     */   
/* 2334:     */   public static void glLightModel(int pname, IntBuffer params)
/* 2335:     */   {
/* 2336:2011 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2337:2012 */     long function_pointer = caps.glLightModeliv;
/* 2338:2013 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2339:2014 */     BufferChecks.checkBuffer(params, 4);
/* 2340:2015 */     nglLightModeliv(pname, MemoryUtil.getAddress(params), function_pointer);
/* 2341:     */   }
/* 2342:     */   
/* 2343:     */   static native void nglLightModeliv(int paramInt, long paramLong1, long paramLong2);
/* 2344:     */   
/* 2345:     */   public static void glLightf(int light, int pname, float param)
/* 2346:     */   {
/* 2347:2020 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2348:2021 */     long function_pointer = caps.glLightf;
/* 2349:2022 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2350:2023 */     nglLightf(light, pname, param, function_pointer);
/* 2351:     */   }
/* 2352:     */   
/* 2353:     */   static native void nglLightf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 2354:     */   
/* 2355:     */   public static void glLighti(int light, int pname, int param)
/* 2356:     */   {
/* 2357:2028 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2358:2029 */     long function_pointer = caps.glLighti;
/* 2359:2030 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2360:2031 */     nglLighti(light, pname, param, function_pointer);
/* 2361:     */   }
/* 2362:     */   
/* 2363:     */   static native void nglLighti(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 2364:     */   
/* 2365:     */   public static void glLight(int light, int pname, FloatBuffer params)
/* 2366:     */   {
/* 2367:2036 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2368:2037 */     long function_pointer = caps.glLightfv;
/* 2369:2038 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2370:2039 */     BufferChecks.checkBuffer(params, 4);
/* 2371:2040 */     nglLightfv(light, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2372:     */   }
/* 2373:     */   
/* 2374:     */   static native void nglLightfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2375:     */   
/* 2376:     */   public static void glLight(int light, int pname, IntBuffer params)
/* 2377:     */   {
/* 2378:2045 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2379:2046 */     long function_pointer = caps.glLightiv;
/* 2380:2047 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2381:2048 */     BufferChecks.checkBuffer(params, 4);
/* 2382:2049 */     nglLightiv(light, pname, MemoryUtil.getAddress(params), function_pointer);
/* 2383:     */   }
/* 2384:     */   
/* 2385:     */   static native void nglLightiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2386:     */   
/* 2387:     */   public static boolean glIsTexture(int texture)
/* 2388:     */   {
/* 2389:2054 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2390:2055 */     long function_pointer = caps.glIsTexture;
/* 2391:2056 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2392:2057 */     boolean __result = nglIsTexture(texture, function_pointer);
/* 2393:2058 */     return __result;
/* 2394:     */   }
/* 2395:     */   
/* 2396:     */   static native boolean nglIsTexture(int paramInt, long paramLong);
/* 2397:     */   
/* 2398:     */   public static void glMatrixMode(int mode)
/* 2399:     */   {
/* 2400:2063 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2401:2064 */     long function_pointer = caps.glMatrixMode;
/* 2402:2065 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2403:2066 */     nglMatrixMode(mode, function_pointer);
/* 2404:     */   }
/* 2405:     */   
/* 2406:     */   static native void nglMatrixMode(int paramInt, long paramLong);
/* 2407:     */   
/* 2408:     */   public static void glPolygonStipple(ByteBuffer mask)
/* 2409:     */   {
/* 2410:2071 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2411:2072 */     long function_pointer = caps.glPolygonStipple;
/* 2412:2073 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2413:2074 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2414:2075 */     BufferChecks.checkBuffer(mask, 128);
/* 2415:2076 */     nglPolygonStipple(MemoryUtil.getAddress(mask), function_pointer);
/* 2416:     */   }
/* 2417:     */   
/* 2418:     */   static native void nglPolygonStipple(long paramLong1, long paramLong2);
/* 2419:     */   
/* 2420:     */   public static void glPolygonStipple(long mask_buffer_offset)
/* 2421:     */   {
/* 2422:2080 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2423:2081 */     long function_pointer = caps.glPolygonStipple;
/* 2424:2082 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2425:2083 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2426:2084 */     nglPolygonStippleBO(mask_buffer_offset, function_pointer);
/* 2427:     */   }
/* 2428:     */   
/* 2429:     */   static native void nglPolygonStippleBO(long paramLong1, long paramLong2);
/* 2430:     */   
/* 2431:     */   public static void glPolygonOffset(float factor, float units)
/* 2432:     */   {
/* 2433:2089 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2434:2090 */     long function_pointer = caps.glPolygonOffset;
/* 2435:2091 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2436:2092 */     nglPolygonOffset(factor, units, function_pointer);
/* 2437:     */   }
/* 2438:     */   
/* 2439:     */   static native void nglPolygonOffset(float paramFloat1, float paramFloat2, long paramLong);
/* 2440:     */   
/* 2441:     */   public static void glPolygonMode(int face, int mode)
/* 2442:     */   {
/* 2443:2097 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2444:2098 */     long function_pointer = caps.glPolygonMode;
/* 2445:2099 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2446:2100 */     nglPolygonMode(face, mode, function_pointer);
/* 2447:     */   }
/* 2448:     */   
/* 2449:     */   static native void nglPolygonMode(int paramInt1, int paramInt2, long paramLong);
/* 2450:     */   
/* 2451:     */   public static void glPointSize(float size)
/* 2452:     */   {
/* 2453:2105 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2454:2106 */     long function_pointer = caps.glPointSize;
/* 2455:2107 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2456:2108 */     nglPointSize(size, function_pointer);
/* 2457:     */   }
/* 2458:     */   
/* 2459:     */   static native void nglPointSize(float paramFloat, long paramLong);
/* 2460:     */   
/* 2461:     */   public static void glPixelZoom(float xfactor, float yfactor)
/* 2462:     */   {
/* 2463:2113 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2464:2114 */     long function_pointer = caps.glPixelZoom;
/* 2465:2115 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2466:2116 */     nglPixelZoom(xfactor, yfactor, function_pointer);
/* 2467:     */   }
/* 2468:     */   
/* 2469:     */   static native void nglPixelZoom(float paramFloat1, float paramFloat2, long paramLong);
/* 2470:     */   
/* 2471:     */   public static void glPixelTransferf(int pname, float param)
/* 2472:     */   {
/* 2473:2121 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2474:2122 */     long function_pointer = caps.glPixelTransferf;
/* 2475:2123 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2476:2124 */     nglPixelTransferf(pname, param, function_pointer);
/* 2477:     */   }
/* 2478:     */   
/* 2479:     */   static native void nglPixelTransferf(int paramInt, float paramFloat, long paramLong);
/* 2480:     */   
/* 2481:     */   public static void glPixelTransferi(int pname, int param)
/* 2482:     */   {
/* 2483:2129 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2484:2130 */     long function_pointer = caps.glPixelTransferi;
/* 2485:2131 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2486:2132 */     nglPixelTransferi(pname, param, function_pointer);
/* 2487:     */   }
/* 2488:     */   
/* 2489:     */   static native void nglPixelTransferi(int paramInt1, int paramInt2, long paramLong);
/* 2490:     */   
/* 2491:     */   public static void glPixelStoref(int pname, float param)
/* 2492:     */   {
/* 2493:2137 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2494:2138 */     long function_pointer = caps.glPixelStoref;
/* 2495:2139 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2496:2140 */     nglPixelStoref(pname, param, function_pointer);
/* 2497:     */   }
/* 2498:     */   
/* 2499:     */   static native void nglPixelStoref(int paramInt, float paramFloat, long paramLong);
/* 2500:     */   
/* 2501:     */   public static void glPixelStorei(int pname, int param)
/* 2502:     */   {
/* 2503:2145 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2504:2146 */     long function_pointer = caps.glPixelStorei;
/* 2505:2147 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2506:2148 */     nglPixelStorei(pname, param, function_pointer);
/* 2507:     */   }
/* 2508:     */   
/* 2509:     */   static native void nglPixelStorei(int paramInt1, int paramInt2, long paramLong);
/* 2510:     */   
/* 2511:     */   public static void glPixelMap(int map, FloatBuffer values)
/* 2512:     */   {
/* 2513:2153 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2514:2154 */     long function_pointer = caps.glPixelMapfv;
/* 2515:2155 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2516:2156 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2517:2157 */     BufferChecks.checkDirect(values);
/* 2518:2158 */     nglPixelMapfv(map, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 2519:     */   }
/* 2520:     */   
/* 2521:     */   static native void nglPixelMapfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2522:     */   
/* 2523:     */   public static void glPixelMapfv(int map, int values_mapsize, long values_buffer_offset)
/* 2524:     */   {
/* 2525:2162 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2526:2163 */     long function_pointer = caps.glPixelMapfv;
/* 2527:2164 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2528:2165 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2529:2166 */     nglPixelMapfvBO(map, values_mapsize, values_buffer_offset, function_pointer);
/* 2530:     */   }
/* 2531:     */   
/* 2532:     */   static native void nglPixelMapfvBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2533:     */   
/* 2534:     */   public static void glPixelMapu(int map, IntBuffer values)
/* 2535:     */   {
/* 2536:2171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2537:2172 */     long function_pointer = caps.glPixelMapuiv;
/* 2538:2173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2539:2174 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2540:2175 */     BufferChecks.checkDirect(values);
/* 2541:2176 */     nglPixelMapuiv(map, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 2542:     */   }
/* 2543:     */   
/* 2544:     */   static native void nglPixelMapuiv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2545:     */   
/* 2546:     */   public static void glPixelMapuiv(int map, int values_mapsize, long values_buffer_offset)
/* 2547:     */   {
/* 2548:2180 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2549:2181 */     long function_pointer = caps.glPixelMapuiv;
/* 2550:2182 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2551:2183 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2552:2184 */     nglPixelMapuivBO(map, values_mapsize, values_buffer_offset, function_pointer);
/* 2553:     */   }
/* 2554:     */   
/* 2555:     */   static native void nglPixelMapuivBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2556:     */   
/* 2557:     */   public static void glPixelMapu(int map, ShortBuffer values)
/* 2558:     */   {
/* 2559:2189 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2560:2190 */     long function_pointer = caps.glPixelMapusv;
/* 2561:2191 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2562:2192 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 2563:2193 */     BufferChecks.checkDirect(values);
/* 2564:2194 */     nglPixelMapusv(map, values.remaining(), MemoryUtil.getAddress(values), function_pointer);
/* 2565:     */   }
/* 2566:     */   
/* 2567:     */   static native void nglPixelMapusv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2568:     */   
/* 2569:     */   public static void glPixelMapusv(int map, int values_mapsize, long values_buffer_offset)
/* 2570:     */   {
/* 2571:2198 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2572:2199 */     long function_pointer = caps.glPixelMapusv;
/* 2573:2200 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2574:2201 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 2575:2202 */     nglPixelMapusvBO(map, values_mapsize, values_buffer_offset, function_pointer);
/* 2576:     */   }
/* 2577:     */   
/* 2578:     */   static native void nglPixelMapusvBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2579:     */   
/* 2580:     */   public static void glPassThrough(float token)
/* 2581:     */   {
/* 2582:2207 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2583:2208 */     long function_pointer = caps.glPassThrough;
/* 2584:2209 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2585:2210 */     nglPassThrough(token, function_pointer);
/* 2586:     */   }
/* 2587:     */   
/* 2588:     */   static native void nglPassThrough(float paramFloat, long paramLong);
/* 2589:     */   
/* 2590:     */   public static void glOrtho(double left, double right, double bottom, double top, double zNear, double zFar)
/* 2591:     */   {
/* 2592:2215 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2593:2216 */     long function_pointer = caps.glOrtho;
/* 2594:2217 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2595:2218 */     nglOrtho(left, right, bottom, top, zNear, zFar, function_pointer);
/* 2596:     */   }
/* 2597:     */   
/* 2598:     */   static native void nglOrtho(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, long paramLong);
/* 2599:     */   
/* 2600:     */   public static void glNormalPointer(int stride, ByteBuffer pointer)
/* 2601:     */   {
/* 2602:2223 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2603:2224 */     long function_pointer = caps.glNormalPointer;
/* 2604:2225 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2605:2226 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 2606:2227 */     BufferChecks.checkDirect(pointer);
/* 2607:2228 */     if (LWJGLUtil.CHECKS) {
/* 2608:2228 */       StateTracker.getReferences(caps).GL11_glNormalPointer_pointer = pointer;
/* 2609:     */     }
/* 2610:2229 */     nglNormalPointer(5120, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 2611:     */   }
/* 2612:     */   
/* 2613:     */   public static void glNormalPointer(int stride, DoubleBuffer pointer)
/* 2614:     */   {
/* 2615:2232 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2616:2233 */     long function_pointer = caps.glNormalPointer;
/* 2617:2234 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2618:2235 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 2619:2236 */     BufferChecks.checkDirect(pointer);
/* 2620:2237 */     if (LWJGLUtil.CHECKS) {
/* 2621:2237 */       StateTracker.getReferences(caps).GL11_glNormalPointer_pointer = pointer;
/* 2622:     */     }
/* 2623:2238 */     nglNormalPointer(5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 2624:     */   }
/* 2625:     */   
/* 2626:     */   public static void glNormalPointer(int stride, FloatBuffer pointer)
/* 2627:     */   {
/* 2628:2241 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2629:2242 */     long function_pointer = caps.glNormalPointer;
/* 2630:2243 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2631:2244 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 2632:2245 */     BufferChecks.checkDirect(pointer);
/* 2633:2246 */     if (LWJGLUtil.CHECKS) {
/* 2634:2246 */       StateTracker.getReferences(caps).GL11_glNormalPointer_pointer = pointer;
/* 2635:     */     }
/* 2636:2247 */     nglNormalPointer(5126, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 2637:     */   }
/* 2638:     */   
/* 2639:     */   public static void glNormalPointer(int stride, IntBuffer pointer)
/* 2640:     */   {
/* 2641:2250 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2642:2251 */     long function_pointer = caps.glNormalPointer;
/* 2643:2252 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2644:2253 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 2645:2254 */     BufferChecks.checkDirect(pointer);
/* 2646:2255 */     if (LWJGLUtil.CHECKS) {
/* 2647:2255 */       StateTracker.getReferences(caps).GL11_glNormalPointer_pointer = pointer;
/* 2648:     */     }
/* 2649:2256 */     nglNormalPointer(5124, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 2650:     */   }
/* 2651:     */   
/* 2652:     */   static native void nglNormalPointer(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2653:     */   
/* 2654:     */   public static void glNormalPointer(int type, int stride, long pointer_buffer_offset)
/* 2655:     */   {
/* 2656:2260 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2657:2261 */     long function_pointer = caps.glNormalPointer;
/* 2658:2262 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2659:2263 */     GLChecks.ensureArrayVBOenabled(caps);
/* 2660:2264 */     nglNormalPointerBO(type, stride, pointer_buffer_offset, function_pointer);
/* 2661:     */   }
/* 2662:     */   
/* 2663:     */   static native void nglNormalPointerBO(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 2664:     */   
/* 2665:     */   public static void glNormalPointer(int type, int stride, ByteBuffer pointer)
/* 2666:     */   {
/* 2667:2270 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2668:2271 */     long function_pointer = caps.glNormalPointer;
/* 2669:2272 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2670:2273 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 2671:2274 */     BufferChecks.checkDirect(pointer);
/* 2672:2275 */     if (LWJGLUtil.CHECKS) {
/* 2673:2275 */       StateTracker.getReferences(caps).GL11_glNormalPointer_pointer = pointer;
/* 2674:     */     }
/* 2675:2276 */     nglNormalPointer(type, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 2676:     */   }
/* 2677:     */   
/* 2678:     */   public static void glNormal3b(byte nx, byte ny, byte nz)
/* 2679:     */   {
/* 2680:2280 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2681:2281 */     long function_pointer = caps.glNormal3b;
/* 2682:2282 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2683:2283 */     nglNormal3b(nx, ny, nz, function_pointer);
/* 2684:     */   }
/* 2685:     */   
/* 2686:     */   static native void nglNormal3b(byte paramByte1, byte paramByte2, byte paramByte3, long paramLong);
/* 2687:     */   
/* 2688:     */   public static void glNormal3f(float nx, float ny, float nz)
/* 2689:     */   {
/* 2690:2288 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2691:2289 */     long function_pointer = caps.glNormal3f;
/* 2692:2290 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2693:2291 */     nglNormal3f(nx, ny, nz, function_pointer);
/* 2694:     */   }
/* 2695:     */   
/* 2696:     */   static native void nglNormal3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 2697:     */   
/* 2698:     */   public static void glNormal3d(double nx, double ny, double nz)
/* 2699:     */   {
/* 2700:2296 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2701:2297 */     long function_pointer = caps.glNormal3d;
/* 2702:2298 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2703:2299 */     nglNormal3d(nx, ny, nz, function_pointer);
/* 2704:     */   }
/* 2705:     */   
/* 2706:     */   static native void nglNormal3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 2707:     */   
/* 2708:     */   public static void glNormal3i(int nx, int ny, int nz)
/* 2709:     */   {
/* 2710:2304 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2711:2305 */     long function_pointer = caps.glNormal3i;
/* 2712:2306 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2713:2307 */     nglNormal3i(nx, ny, nz, function_pointer);
/* 2714:     */   }
/* 2715:     */   
/* 2716:     */   static native void nglNormal3i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 2717:     */   
/* 2718:     */   public static void glNewList(int list, int mode)
/* 2719:     */   {
/* 2720:2312 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2721:2313 */     long function_pointer = caps.glNewList;
/* 2722:2314 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2723:2315 */     nglNewList(list, mode, function_pointer);
/* 2724:     */   }
/* 2725:     */   
/* 2726:     */   static native void nglNewList(int paramInt1, int paramInt2, long paramLong);
/* 2727:     */   
/* 2728:     */   public static void glEndList()
/* 2729:     */   {
/* 2730:2320 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2731:2321 */     long function_pointer = caps.glEndList;
/* 2732:2322 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2733:2323 */     nglEndList(function_pointer);
/* 2734:     */   }
/* 2735:     */   
/* 2736:     */   static native void nglEndList(long paramLong);
/* 2737:     */   
/* 2738:     */   public static void glMultMatrix(FloatBuffer m)
/* 2739:     */   {
/* 2740:2328 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2741:2329 */     long function_pointer = caps.glMultMatrixf;
/* 2742:2330 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2743:2331 */     BufferChecks.checkBuffer(m, 16);
/* 2744:2332 */     nglMultMatrixf(MemoryUtil.getAddress(m), function_pointer);
/* 2745:     */   }
/* 2746:     */   
/* 2747:     */   static native void nglMultMatrixf(long paramLong1, long paramLong2);
/* 2748:     */   
/* 2749:     */   public static void glMultMatrix(DoubleBuffer m)
/* 2750:     */   {
/* 2751:2337 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2752:2338 */     long function_pointer = caps.glMultMatrixd;
/* 2753:2339 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2754:2340 */     BufferChecks.checkBuffer(m, 16);
/* 2755:2341 */     nglMultMatrixd(MemoryUtil.getAddress(m), function_pointer);
/* 2756:     */   }
/* 2757:     */   
/* 2758:     */   static native void nglMultMatrixd(long paramLong1, long paramLong2);
/* 2759:     */   
/* 2760:     */   public static void glShadeModel(int mode)
/* 2761:     */   {
/* 2762:2346 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2763:2347 */     long function_pointer = caps.glShadeModel;
/* 2764:2348 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2765:2349 */     nglShadeModel(mode, function_pointer);
/* 2766:     */   }
/* 2767:     */   
/* 2768:     */   static native void nglShadeModel(int paramInt, long paramLong);
/* 2769:     */   
/* 2770:     */   public static void glSelectBuffer(IntBuffer buffer)
/* 2771:     */   {
/* 2772:2354 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2773:2355 */     long function_pointer = caps.glSelectBuffer;
/* 2774:2356 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2775:2357 */     BufferChecks.checkDirect(buffer);
/* 2776:2358 */     nglSelectBuffer(buffer.remaining(), MemoryUtil.getAddress(buffer), function_pointer);
/* 2777:     */   }
/* 2778:     */   
/* 2779:     */   static native void nglSelectBuffer(int paramInt, long paramLong1, long paramLong2);
/* 2780:     */   
/* 2781:     */   public static void glScissor(int x, int y, int width, int height)
/* 2782:     */   {
/* 2783:2363 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2784:2364 */     long function_pointer = caps.glScissor;
/* 2785:2365 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2786:2366 */     nglScissor(x, y, width, height, function_pointer);
/* 2787:     */   }
/* 2788:     */   
/* 2789:     */   static native void nglScissor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 2790:     */   
/* 2791:     */   public static void glScalef(float x, float y, float z)
/* 2792:     */   {
/* 2793:2371 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2794:2372 */     long function_pointer = caps.glScalef;
/* 2795:2373 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2796:2374 */     nglScalef(x, y, z, function_pointer);
/* 2797:     */   }
/* 2798:     */   
/* 2799:     */   static native void nglScalef(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 2800:     */   
/* 2801:     */   public static void glScaled(double x, double y, double z)
/* 2802:     */   {
/* 2803:2379 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2804:2380 */     long function_pointer = caps.glScaled;
/* 2805:2381 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2806:2382 */     nglScaled(x, y, z, function_pointer);
/* 2807:     */   }
/* 2808:     */   
/* 2809:     */   static native void nglScaled(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 2810:     */   
/* 2811:     */   public static void glRotatef(float angle, float x, float y, float z)
/* 2812:     */   {
/* 2813:2387 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2814:2388 */     long function_pointer = caps.glRotatef;
/* 2815:2389 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2816:2390 */     nglRotatef(angle, x, y, z, function_pointer);
/* 2817:     */   }
/* 2818:     */   
/* 2819:     */   static native void nglRotatef(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 2820:     */   
/* 2821:     */   public static void glRotated(double angle, double x, double y, double z)
/* 2822:     */   {
/* 2823:2395 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2824:2396 */     long function_pointer = caps.glRotated;
/* 2825:2397 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2826:2398 */     nglRotated(angle, x, y, z, function_pointer);
/* 2827:     */   }
/* 2828:     */   
/* 2829:     */   static native void nglRotated(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 2830:     */   
/* 2831:     */   public static int glRenderMode(int mode)
/* 2832:     */   {
/* 2833:2403 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2834:2404 */     long function_pointer = caps.glRenderMode;
/* 2835:2405 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2836:2406 */     int __result = nglRenderMode(mode, function_pointer);
/* 2837:2407 */     return __result;
/* 2838:     */   }
/* 2839:     */   
/* 2840:     */   static native int nglRenderMode(int paramInt, long paramLong);
/* 2841:     */   
/* 2842:     */   public static void glRectf(float x1, float y1, float x2, float y2)
/* 2843:     */   {
/* 2844:2412 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2845:2413 */     long function_pointer = caps.glRectf;
/* 2846:2414 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2847:2415 */     nglRectf(x1, y1, x2, y2, function_pointer);
/* 2848:     */   }
/* 2849:     */   
/* 2850:     */   static native void nglRectf(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 2851:     */   
/* 2852:     */   public static void glRectd(double x1, double y1, double x2, double y2)
/* 2853:     */   {
/* 2854:2420 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2855:2421 */     long function_pointer = caps.glRectd;
/* 2856:2422 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2857:2423 */     nglRectd(x1, y1, x2, y2, function_pointer);
/* 2858:     */   }
/* 2859:     */   
/* 2860:     */   static native void nglRectd(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 2861:     */   
/* 2862:     */   public static void glRecti(int x1, int y1, int x2, int y2)
/* 2863:     */   {
/* 2864:2428 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2865:2429 */     long function_pointer = caps.glRecti;
/* 2866:2430 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2867:2431 */     nglRecti(x1, y1, x2, y2, function_pointer);
/* 2868:     */   }
/* 2869:     */   
/* 2870:     */   static native void nglRecti(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 2871:     */   
/* 2872:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, ByteBuffer pixels)
/* 2873:     */   {
/* 2874:2436 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2875:2437 */     long function_pointer = caps.glReadPixels;
/* 2876:2438 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2877:2439 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2878:2440 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 2879:2441 */     nglReadPixels(x, y, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 2880:     */   }
/* 2881:     */   
/* 2882:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, DoubleBuffer pixels)
/* 2883:     */   {
/* 2884:2444 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2885:2445 */     long function_pointer = caps.glReadPixels;
/* 2886:2446 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2887:2447 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2888:2448 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 2889:2449 */     nglReadPixels(x, y, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 2890:     */   }
/* 2891:     */   
/* 2892:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, FloatBuffer pixels)
/* 2893:     */   {
/* 2894:2452 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2895:2453 */     long function_pointer = caps.glReadPixels;
/* 2896:2454 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2897:2455 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2898:2456 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 2899:2457 */     nglReadPixels(x, y, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 2900:     */   }
/* 2901:     */   
/* 2902:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, IntBuffer pixels)
/* 2903:     */   {
/* 2904:2460 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2905:2461 */     long function_pointer = caps.glReadPixels;
/* 2906:2462 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2907:2463 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2908:2464 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 2909:2465 */     nglReadPixels(x, y, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 2910:     */   }
/* 2911:     */   
/* 2912:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, ShortBuffer pixels)
/* 2913:     */   {
/* 2914:2468 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2915:2469 */     long function_pointer = caps.glReadPixels;
/* 2916:2470 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2917:2471 */     GLChecks.ensurePackPBOdisabled(caps);
/* 2918:2472 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 2919:2473 */     nglReadPixels(x, y, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 2920:     */   }
/* 2921:     */   
/* 2922:     */   static native void nglReadPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 2923:     */   
/* 2924:     */   public static void glReadPixels(int x, int y, int width, int height, int format, int type, long pixels_buffer_offset)
/* 2925:     */   {
/* 2926:2477 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2927:2478 */     long function_pointer = caps.glReadPixels;
/* 2928:2479 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2929:2480 */     GLChecks.ensurePackPBOenabled(caps);
/* 2930:2481 */     nglReadPixelsBO(x, y, width, height, format, type, pixels_buffer_offset, function_pointer);
/* 2931:     */   }
/* 2932:     */   
/* 2933:     */   static native void nglReadPixelsBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 2934:     */   
/* 2935:     */   public static void glReadBuffer(int mode)
/* 2936:     */   {
/* 2937:2486 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2938:2487 */     long function_pointer = caps.glReadBuffer;
/* 2939:2488 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2940:2489 */     nglReadBuffer(mode, function_pointer);
/* 2941:     */   }
/* 2942:     */   
/* 2943:     */   static native void nglReadBuffer(int paramInt, long paramLong);
/* 2944:     */   
/* 2945:     */   public static void glRasterPos2f(float x, float y)
/* 2946:     */   {
/* 2947:2494 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2948:2495 */     long function_pointer = caps.glRasterPos2f;
/* 2949:2496 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2950:2497 */     nglRasterPos2f(x, y, function_pointer);
/* 2951:     */   }
/* 2952:     */   
/* 2953:     */   static native void nglRasterPos2f(float paramFloat1, float paramFloat2, long paramLong);
/* 2954:     */   
/* 2955:     */   public static void glRasterPos2d(double x, double y)
/* 2956:     */   {
/* 2957:2502 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2958:2503 */     long function_pointer = caps.glRasterPos2d;
/* 2959:2504 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2960:2505 */     nglRasterPos2d(x, y, function_pointer);
/* 2961:     */   }
/* 2962:     */   
/* 2963:     */   static native void nglRasterPos2d(double paramDouble1, double paramDouble2, long paramLong);
/* 2964:     */   
/* 2965:     */   public static void glRasterPos2i(int x, int y)
/* 2966:     */   {
/* 2967:2510 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2968:2511 */     long function_pointer = caps.glRasterPos2i;
/* 2969:2512 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2970:2513 */     nglRasterPos2i(x, y, function_pointer);
/* 2971:     */   }
/* 2972:     */   
/* 2973:     */   static native void nglRasterPos2i(int paramInt1, int paramInt2, long paramLong);
/* 2974:     */   
/* 2975:     */   public static void glRasterPos3f(float x, float y, float z)
/* 2976:     */   {
/* 2977:2518 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2978:2519 */     long function_pointer = caps.glRasterPos3f;
/* 2979:2520 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2980:2521 */     nglRasterPos3f(x, y, z, function_pointer);
/* 2981:     */   }
/* 2982:     */   
/* 2983:     */   static native void nglRasterPos3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 2984:     */   
/* 2985:     */   public static void glRasterPos3d(double x, double y, double z)
/* 2986:     */   {
/* 2987:2526 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2988:2527 */     long function_pointer = caps.glRasterPos3d;
/* 2989:2528 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 2990:2529 */     nglRasterPos3d(x, y, z, function_pointer);
/* 2991:     */   }
/* 2992:     */   
/* 2993:     */   static native void nglRasterPos3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 2994:     */   
/* 2995:     */   public static void glRasterPos3i(int x, int y, int z)
/* 2996:     */   {
/* 2997:2534 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 2998:2535 */     long function_pointer = caps.glRasterPos3i;
/* 2999:2536 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3000:2537 */     nglRasterPos3i(x, y, z, function_pointer);
/* 3001:     */   }
/* 3002:     */   
/* 3003:     */   static native void nglRasterPos3i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3004:     */   
/* 3005:     */   public static void glRasterPos4f(float x, float y, float z, float w)
/* 3006:     */   {
/* 3007:2542 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3008:2543 */     long function_pointer = caps.glRasterPos4f;
/* 3009:2544 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3010:2545 */     nglRasterPos4f(x, y, z, w, function_pointer);
/* 3011:     */   }
/* 3012:     */   
/* 3013:     */   static native void nglRasterPos4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 3014:     */   
/* 3015:     */   public static void glRasterPos4d(double x, double y, double z, double w)
/* 3016:     */   {
/* 3017:2550 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3018:2551 */     long function_pointer = caps.glRasterPos4d;
/* 3019:2552 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3020:2553 */     nglRasterPos4d(x, y, z, w, function_pointer);
/* 3021:     */   }
/* 3022:     */   
/* 3023:     */   static native void nglRasterPos4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 3024:     */   
/* 3025:     */   public static void glRasterPos4i(int x, int y, int z, int w)
/* 3026:     */   {
/* 3027:2558 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3028:2559 */     long function_pointer = caps.glRasterPos4i;
/* 3029:2560 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3030:2561 */     nglRasterPos4i(x, y, z, w, function_pointer);
/* 3031:     */   }
/* 3032:     */   
/* 3033:     */   static native void nglRasterPos4i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3034:     */   
/* 3035:     */   public static void glPushName(int name)
/* 3036:     */   {
/* 3037:2566 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3038:2567 */     long function_pointer = caps.glPushName;
/* 3039:2568 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3040:2569 */     nglPushName(name, function_pointer);
/* 3041:     */   }
/* 3042:     */   
/* 3043:     */   static native void nglPushName(int paramInt, long paramLong);
/* 3044:     */   
/* 3045:     */   public static void glPopName()
/* 3046:     */   {
/* 3047:2574 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3048:2575 */     long function_pointer = caps.glPopName;
/* 3049:2576 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3050:2577 */     nglPopName(function_pointer);
/* 3051:     */   }
/* 3052:     */   
/* 3053:     */   static native void nglPopName(long paramLong);
/* 3054:     */   
/* 3055:     */   public static void glPushMatrix()
/* 3056:     */   {
/* 3057:2582 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3058:2583 */     long function_pointer = caps.glPushMatrix;
/* 3059:2584 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3060:2585 */     nglPushMatrix(function_pointer);
/* 3061:     */   }
/* 3062:     */   
/* 3063:     */   static native void nglPushMatrix(long paramLong);
/* 3064:     */   
/* 3065:     */   public static void glPopMatrix()
/* 3066:     */   {
/* 3067:2590 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3068:2591 */     long function_pointer = caps.glPopMatrix;
/* 3069:2592 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3070:2593 */     nglPopMatrix(function_pointer);
/* 3071:     */   }
/* 3072:     */   
/* 3073:     */   static native void nglPopMatrix(long paramLong);
/* 3074:     */   
/* 3075:     */   public static void glPushClientAttrib(int mask)
/* 3076:     */   {
/* 3077:2598 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3078:2599 */     long function_pointer = caps.glPushClientAttrib;
/* 3079:2600 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3080:2601 */     StateTracker.pushAttrib(caps, mask);
/* 3081:2602 */     nglPushClientAttrib(mask, function_pointer);
/* 3082:     */   }
/* 3083:     */   
/* 3084:     */   static native void nglPushClientAttrib(int paramInt, long paramLong);
/* 3085:     */   
/* 3086:     */   public static void glPopClientAttrib()
/* 3087:     */   {
/* 3088:2607 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3089:2608 */     long function_pointer = caps.glPopClientAttrib;
/* 3090:2609 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3091:2610 */     StateTracker.popAttrib(caps);
/* 3092:2611 */     nglPopClientAttrib(function_pointer);
/* 3093:     */   }
/* 3094:     */   
/* 3095:     */   static native void nglPopClientAttrib(long paramLong);
/* 3096:     */   
/* 3097:     */   public static void glPushAttrib(int mask)
/* 3098:     */   {
/* 3099:2616 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3100:2617 */     long function_pointer = caps.glPushAttrib;
/* 3101:2618 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3102:2619 */     nglPushAttrib(mask, function_pointer);
/* 3103:     */   }
/* 3104:     */   
/* 3105:     */   static native void nglPushAttrib(int paramInt, long paramLong);
/* 3106:     */   
/* 3107:     */   public static void glPopAttrib()
/* 3108:     */   {
/* 3109:2624 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3110:2625 */     long function_pointer = caps.glPopAttrib;
/* 3111:2626 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3112:2627 */     nglPopAttrib(function_pointer);
/* 3113:     */   }
/* 3114:     */   
/* 3115:     */   static native void nglPopAttrib(long paramLong);
/* 3116:     */   
/* 3117:     */   public static void glStencilFunc(int func, int ref, int mask)
/* 3118:     */   {
/* 3119:2632 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3120:2633 */     long function_pointer = caps.glStencilFunc;
/* 3121:2634 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3122:2635 */     nglStencilFunc(func, ref, mask, function_pointer);
/* 3123:     */   }
/* 3124:     */   
/* 3125:     */   static native void nglStencilFunc(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3126:     */   
/* 3127:     */   public static void glVertexPointer(int size, int stride, DoubleBuffer pointer)
/* 3128:     */   {
/* 3129:2640 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3130:2641 */     long function_pointer = caps.glVertexPointer;
/* 3131:2642 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3132:2643 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3133:2644 */     BufferChecks.checkDirect(pointer);
/* 3134:2645 */     if (LWJGLUtil.CHECKS) {
/* 3135:2645 */       StateTracker.getReferences(caps).GL11_glVertexPointer_pointer = pointer;
/* 3136:     */     }
/* 3137:2646 */     nglVertexPointer(size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3138:     */   }
/* 3139:     */   
/* 3140:     */   public static void glVertexPointer(int size, int stride, FloatBuffer pointer)
/* 3141:     */   {
/* 3142:2649 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3143:2650 */     long function_pointer = caps.glVertexPointer;
/* 3144:2651 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3145:2652 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3146:2653 */     BufferChecks.checkDirect(pointer);
/* 3147:2654 */     if (LWJGLUtil.CHECKS) {
/* 3148:2654 */       StateTracker.getReferences(caps).GL11_glVertexPointer_pointer = pointer;
/* 3149:     */     }
/* 3150:2655 */     nglVertexPointer(size, 5126, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3151:     */   }
/* 3152:     */   
/* 3153:     */   public static void glVertexPointer(int size, int stride, IntBuffer pointer)
/* 3154:     */   {
/* 3155:2658 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3156:2659 */     long function_pointer = caps.glVertexPointer;
/* 3157:2660 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3158:2661 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3159:2662 */     BufferChecks.checkDirect(pointer);
/* 3160:2663 */     if (LWJGLUtil.CHECKS) {
/* 3161:2663 */       StateTracker.getReferences(caps).GL11_glVertexPointer_pointer = pointer;
/* 3162:     */     }
/* 3163:2664 */     nglVertexPointer(size, 5124, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3164:     */   }
/* 3165:     */   
/* 3166:     */   public static void glVertexPointer(int size, int stride, ShortBuffer pointer)
/* 3167:     */   {
/* 3168:2667 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3169:2668 */     long function_pointer = caps.glVertexPointer;
/* 3170:2669 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3171:2670 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3172:2671 */     BufferChecks.checkDirect(pointer);
/* 3173:2672 */     if (LWJGLUtil.CHECKS) {
/* 3174:2672 */       StateTracker.getReferences(caps).GL11_glVertexPointer_pointer = pointer;
/* 3175:     */     }
/* 3176:2673 */     nglVertexPointer(size, 5122, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3177:     */   }
/* 3178:     */   
/* 3179:     */   static native void nglVertexPointer(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3180:     */   
/* 3181:     */   public static void glVertexPointer(int size, int type, int stride, long pointer_buffer_offset)
/* 3182:     */   {
/* 3183:2677 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3184:2678 */     long function_pointer = caps.glVertexPointer;
/* 3185:2679 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3186:2680 */     GLChecks.ensureArrayVBOenabled(caps);
/* 3187:2681 */     nglVertexPointerBO(size, type, stride, pointer_buffer_offset, function_pointer);
/* 3188:     */   }
/* 3189:     */   
/* 3190:     */   static native void nglVertexPointerBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3191:     */   
/* 3192:     */   public static void glVertexPointer(int size, int type, int stride, ByteBuffer pointer)
/* 3193:     */   {
/* 3194:2687 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3195:2688 */     long function_pointer = caps.glVertexPointer;
/* 3196:2689 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3197:2690 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3198:2691 */     BufferChecks.checkDirect(pointer);
/* 3199:2692 */     if (LWJGLUtil.CHECKS) {
/* 3200:2692 */       StateTracker.getReferences(caps).GL11_glVertexPointer_pointer = pointer;
/* 3201:     */     }
/* 3202:2693 */     nglVertexPointer(size, type, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3203:     */   }
/* 3204:     */   
/* 3205:     */   public static void glVertex2f(float x, float y)
/* 3206:     */   {
/* 3207:2697 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3208:2698 */     long function_pointer = caps.glVertex2f;
/* 3209:2699 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3210:2700 */     nglVertex2f(x, y, function_pointer);
/* 3211:     */   }
/* 3212:     */   
/* 3213:     */   static native void nglVertex2f(float paramFloat1, float paramFloat2, long paramLong);
/* 3214:     */   
/* 3215:     */   public static void glVertex2d(double x, double y)
/* 3216:     */   {
/* 3217:2705 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3218:2706 */     long function_pointer = caps.glVertex2d;
/* 3219:2707 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3220:2708 */     nglVertex2d(x, y, function_pointer);
/* 3221:     */   }
/* 3222:     */   
/* 3223:     */   static native void nglVertex2d(double paramDouble1, double paramDouble2, long paramLong);
/* 3224:     */   
/* 3225:     */   public static void glVertex2i(int x, int y)
/* 3226:     */   {
/* 3227:2713 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3228:2714 */     long function_pointer = caps.glVertex2i;
/* 3229:2715 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3230:2716 */     nglVertex2i(x, y, function_pointer);
/* 3231:     */   }
/* 3232:     */   
/* 3233:     */   static native void nglVertex2i(int paramInt1, int paramInt2, long paramLong);
/* 3234:     */   
/* 3235:     */   public static void glVertex3f(float x, float y, float z)
/* 3236:     */   {
/* 3237:2721 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3238:2722 */     long function_pointer = caps.glVertex3f;
/* 3239:2723 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3240:2724 */     nglVertex3f(x, y, z, function_pointer);
/* 3241:     */   }
/* 3242:     */   
/* 3243:     */   static native void nglVertex3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 3244:     */   
/* 3245:     */   public static void glVertex3d(double x, double y, double z)
/* 3246:     */   {
/* 3247:2729 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3248:2730 */     long function_pointer = caps.glVertex3d;
/* 3249:2731 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3250:2732 */     nglVertex3d(x, y, z, function_pointer);
/* 3251:     */   }
/* 3252:     */   
/* 3253:     */   static native void nglVertex3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 3254:     */   
/* 3255:     */   public static void glVertex3i(int x, int y, int z)
/* 3256:     */   {
/* 3257:2737 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3258:2738 */     long function_pointer = caps.glVertex3i;
/* 3259:2739 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3260:2740 */     nglVertex3i(x, y, z, function_pointer);
/* 3261:     */   }
/* 3262:     */   
/* 3263:     */   static native void nglVertex3i(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3264:     */   
/* 3265:     */   public static void glVertex4f(float x, float y, float z, float w)
/* 3266:     */   {
/* 3267:2745 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3268:2746 */     long function_pointer = caps.glVertex4f;
/* 3269:2747 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3270:2748 */     nglVertex4f(x, y, z, w, function_pointer);
/* 3271:     */   }
/* 3272:     */   
/* 3273:     */   static native void nglVertex4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 3274:     */   
/* 3275:     */   public static void glVertex4d(double x, double y, double z, double w)
/* 3276:     */   {
/* 3277:2753 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3278:2754 */     long function_pointer = caps.glVertex4d;
/* 3279:2755 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3280:2756 */     nglVertex4d(x, y, z, w, function_pointer);
/* 3281:     */   }
/* 3282:     */   
/* 3283:     */   static native void nglVertex4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 3284:     */   
/* 3285:     */   public static void glVertex4i(int x, int y, int z, int w)
/* 3286:     */   {
/* 3287:2761 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3288:2762 */     long function_pointer = caps.glVertex4i;
/* 3289:2763 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3290:2764 */     nglVertex4i(x, y, z, w, function_pointer);
/* 3291:     */   }
/* 3292:     */   
/* 3293:     */   static native void nglVertex4i(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3294:     */   
/* 3295:     */   public static void glTranslatef(float x, float y, float z)
/* 3296:     */   {
/* 3297:2769 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3298:2770 */     long function_pointer = caps.glTranslatef;
/* 3299:2771 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3300:2772 */     nglTranslatef(x, y, z, function_pointer);
/* 3301:     */   }
/* 3302:     */   
/* 3303:     */   static native void nglTranslatef(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 3304:     */   
/* 3305:     */   public static void glTranslated(double x, double y, double z)
/* 3306:     */   {
/* 3307:2777 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3308:2778 */     long function_pointer = caps.glTranslated;
/* 3309:2779 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3310:2780 */     nglTranslated(x, y, z, function_pointer);
/* 3311:     */   }
/* 3312:     */   
/* 3313:     */   static native void nglTranslated(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 3314:     */   
/* 3315:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, ByteBuffer pixels)
/* 3316:     */   {
/* 3317:2785 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3318:2786 */     long function_pointer = caps.glTexImage1D;
/* 3319:2787 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3320:2788 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3321:2789 */     if (pixels != null) {
/* 3322:2790 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 3323:     */     }
/* 3324:2791 */     nglTexImage1D(target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3325:     */   }
/* 3326:     */   
/* 3327:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, DoubleBuffer pixels)
/* 3328:     */   {
/* 3329:2794 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3330:2795 */     long function_pointer = caps.glTexImage1D;
/* 3331:2796 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3332:2797 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3333:2798 */     if (pixels != null) {
/* 3334:2799 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 3335:     */     }
/* 3336:2800 */     nglTexImage1D(target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3337:     */   }
/* 3338:     */   
/* 3339:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, FloatBuffer pixels)
/* 3340:     */   {
/* 3341:2803 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3342:2804 */     long function_pointer = caps.glTexImage1D;
/* 3343:2805 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3344:2806 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3345:2807 */     if (pixels != null) {
/* 3346:2808 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 3347:     */     }
/* 3348:2809 */     nglTexImage1D(target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3349:     */   }
/* 3350:     */   
/* 3351:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, IntBuffer pixels)
/* 3352:     */   {
/* 3353:2812 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3354:2813 */     long function_pointer = caps.glTexImage1D;
/* 3355:2814 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3356:2815 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3357:2816 */     if (pixels != null) {
/* 3358:2817 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 3359:     */     }
/* 3360:2818 */     nglTexImage1D(target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3361:     */   }
/* 3362:     */   
/* 3363:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, ShortBuffer pixels)
/* 3364:     */   {
/* 3365:2821 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3366:2822 */     long function_pointer = caps.glTexImage1D;
/* 3367:2823 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3368:2824 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3369:2825 */     if (pixels != null) {
/* 3370:2826 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage1DStorage(pixels, format, type, width));
/* 3371:     */     }
/* 3372:2827 */     nglTexImage1D(target, level, internalformat, width, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3373:     */   }
/* 3374:     */   
/* 3375:     */   static native void nglTexImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 3376:     */   
/* 3377:     */   public static void glTexImage1D(int target, int level, int internalformat, int width, int border, int format, int type, long pixels_buffer_offset)
/* 3378:     */   {
/* 3379:2831 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3380:2832 */     long function_pointer = caps.glTexImage1D;
/* 3381:2833 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3382:2834 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 3383:2835 */     nglTexImage1DBO(target, level, internalformat, width, border, format, type, pixels_buffer_offset, function_pointer);
/* 3384:     */   }
/* 3385:     */   
/* 3386:     */   static native void nglTexImage1DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong1, long paramLong2);
/* 3387:     */   
/* 3388:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, ByteBuffer pixels)
/* 3389:     */   {
/* 3390:2840 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3391:2841 */     long function_pointer = caps.glTexImage2D;
/* 3392:2842 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3393:2843 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3394:2844 */     if (pixels != null) {
/* 3395:2845 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 3396:     */     }
/* 3397:2846 */     nglTexImage2D(target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3398:     */   }
/* 3399:     */   
/* 3400:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, DoubleBuffer pixels)
/* 3401:     */   {
/* 3402:2849 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3403:2850 */     long function_pointer = caps.glTexImage2D;
/* 3404:2851 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3405:2852 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3406:2853 */     if (pixels != null) {
/* 3407:2854 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 3408:     */     }
/* 3409:2855 */     nglTexImage2D(target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3410:     */   }
/* 3411:     */   
/* 3412:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, FloatBuffer pixels)
/* 3413:     */   {
/* 3414:2858 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3415:2859 */     long function_pointer = caps.glTexImage2D;
/* 3416:2860 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3417:2861 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3418:2862 */     if (pixels != null) {
/* 3419:2863 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 3420:     */     }
/* 3421:2864 */     nglTexImage2D(target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3422:     */   }
/* 3423:     */   
/* 3424:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, IntBuffer pixels)
/* 3425:     */   {
/* 3426:2867 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3427:2868 */     long function_pointer = caps.glTexImage2D;
/* 3428:2869 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3429:2870 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3430:2871 */     if (pixels != null) {
/* 3431:2872 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 3432:     */     }
/* 3433:2873 */     nglTexImage2D(target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3434:     */   }
/* 3435:     */   
/* 3436:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, ShortBuffer pixels)
/* 3437:     */   {
/* 3438:2876 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3439:2877 */     long function_pointer = caps.glTexImage2D;
/* 3440:2878 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3441:2879 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3442:2880 */     if (pixels != null) {
/* 3443:2881 */       BufferChecks.checkBuffer(pixels, GLChecks.calculateTexImage2DStorage(pixels, format, type, width, height));
/* 3444:     */     }
/* 3445:2882 */     nglTexImage2D(target, level, internalformat, width, height, border, format, type, MemoryUtil.getAddressSafe(pixels), function_pointer);
/* 3446:     */   }
/* 3447:     */   
/* 3448:     */   static native void nglTexImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 3449:     */   
/* 3450:     */   public static void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, long pixels_buffer_offset)
/* 3451:     */   {
/* 3452:2886 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3453:2887 */     long function_pointer = caps.glTexImage2D;
/* 3454:2888 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3455:2889 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 3456:2890 */     nglTexImage2DBO(target, level, internalformat, width, height, border, format, type, pixels_buffer_offset, function_pointer);
/* 3457:     */   }
/* 3458:     */   
/* 3459:     */   static native void nglTexImage2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 3460:     */   
/* 3461:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, ByteBuffer pixels)
/* 3462:     */   {
/* 3463:2895 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3464:2896 */     long function_pointer = caps.glTexSubImage1D;
/* 3465:2897 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3466:2898 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3467:2899 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 3468:2900 */     nglTexSubImage1D(target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3469:     */   }
/* 3470:     */   
/* 3471:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, DoubleBuffer pixels)
/* 3472:     */   {
/* 3473:2903 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3474:2904 */     long function_pointer = caps.glTexSubImage1D;
/* 3475:2905 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3476:2906 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3477:2907 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 3478:2908 */     nglTexSubImage1D(target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3479:     */   }
/* 3480:     */   
/* 3481:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, FloatBuffer pixels)
/* 3482:     */   {
/* 3483:2911 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3484:2912 */     long function_pointer = caps.glTexSubImage1D;
/* 3485:2913 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3486:2914 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3487:2915 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 3488:2916 */     nglTexSubImage1D(target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3489:     */   }
/* 3490:     */   
/* 3491:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, IntBuffer pixels)
/* 3492:     */   {
/* 3493:2919 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3494:2920 */     long function_pointer = caps.glTexSubImage1D;
/* 3495:2921 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3496:2922 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3497:2923 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 3498:2924 */     nglTexSubImage1D(target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3499:     */   }
/* 3500:     */   
/* 3501:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, ShortBuffer pixels)
/* 3502:     */   {
/* 3503:2927 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3504:2928 */     long function_pointer = caps.glTexSubImage1D;
/* 3505:2929 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3506:2930 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3507:2931 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, 1, 1));
/* 3508:2932 */     nglTexSubImage1D(target, level, xoffset, width, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3509:     */   }
/* 3510:     */   
/* 3511:     */   static native void nglTexSubImage1D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 3512:     */   
/* 3513:     */   public static void glTexSubImage1D(int target, int level, int xoffset, int width, int format, int type, long pixels_buffer_offset)
/* 3514:     */   {
/* 3515:2936 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3516:2937 */     long function_pointer = caps.glTexSubImage1D;
/* 3517:2938 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3518:2939 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 3519:2940 */     nglTexSubImage1DBO(target, level, xoffset, width, format, type, pixels_buffer_offset, function_pointer);
/* 3520:     */   }
/* 3521:     */   
/* 3522:     */   static native void nglTexSubImage1DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, long paramLong1, long paramLong2);
/* 3523:     */   
/* 3524:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ByteBuffer pixels)
/* 3525:     */   {
/* 3526:2945 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3527:2946 */     long function_pointer = caps.glTexSubImage2D;
/* 3528:2947 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3529:2948 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3530:2949 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 3531:2950 */     nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3532:     */   }
/* 3533:     */   
/* 3534:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, DoubleBuffer pixels)
/* 3535:     */   {
/* 3536:2953 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3537:2954 */     long function_pointer = caps.glTexSubImage2D;
/* 3538:2955 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3539:2956 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3540:2957 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 3541:2958 */     nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3542:     */   }
/* 3543:     */   
/* 3544:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, FloatBuffer pixels)
/* 3545:     */   {
/* 3546:2961 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3547:2962 */     long function_pointer = caps.glTexSubImage2D;
/* 3548:2963 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3549:2964 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3550:2965 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 3551:2966 */     nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3552:     */   }
/* 3553:     */   
/* 3554:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, IntBuffer pixels)
/* 3555:     */   {
/* 3556:2969 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3557:2970 */     long function_pointer = caps.glTexSubImage2D;
/* 3558:2971 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3559:2972 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3560:2973 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 3561:2974 */     nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3562:     */   }
/* 3563:     */   
/* 3564:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, ShortBuffer pixels)
/* 3565:     */   {
/* 3566:2977 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3567:2978 */     long function_pointer = caps.glTexSubImage2D;
/* 3568:2979 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3569:2980 */     GLChecks.ensureUnpackPBOdisabled(caps);
/* 3570:2981 */     BufferChecks.checkBuffer(pixels, GLChecks.calculateImageStorage(pixels, format, type, width, height, 1));
/* 3571:2982 */     nglTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, MemoryUtil.getAddress(pixels), function_pointer);
/* 3572:     */   }
/* 3573:     */   
/* 3574:     */   static native void nglTexSubImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 3575:     */   
/* 3576:     */   public static void glTexSubImage2D(int target, int level, int xoffset, int yoffset, int width, int height, int format, int type, long pixels_buffer_offset)
/* 3577:     */   {
/* 3578:2986 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3579:2987 */     long function_pointer = caps.glTexSubImage2D;
/* 3580:2988 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3581:2989 */     GLChecks.ensureUnpackPBOenabled(caps);
/* 3582:2990 */     nglTexSubImage2DBO(target, level, xoffset, yoffset, width, height, format, type, pixels_buffer_offset, function_pointer);
/* 3583:     */   }
/* 3584:     */   
/* 3585:     */   static native void nglTexSubImage2DBO(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, long paramLong1, long paramLong2);
/* 3586:     */   
/* 3587:     */   public static void glTexParameterf(int target, int pname, float param)
/* 3588:     */   {
/* 3589:2995 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3590:2996 */     long function_pointer = caps.glTexParameterf;
/* 3591:2997 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3592:2998 */     nglTexParameterf(target, pname, param, function_pointer);
/* 3593:     */   }
/* 3594:     */   
/* 3595:     */   static native void nglTexParameterf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 3596:     */   
/* 3597:     */   public static void glTexParameteri(int target, int pname, int param)
/* 3598:     */   {
/* 3599:3003 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3600:3004 */     long function_pointer = caps.glTexParameteri;
/* 3601:3005 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3602:3006 */     nglTexParameteri(target, pname, param, function_pointer);
/* 3603:     */   }
/* 3604:     */   
/* 3605:     */   static native void nglTexParameteri(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3606:     */   
/* 3607:     */   public static void glTexParameter(int target, int pname, FloatBuffer param)
/* 3608:     */   {
/* 3609:3011 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3610:3012 */     long function_pointer = caps.glTexParameterfv;
/* 3611:3013 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3612:3014 */     BufferChecks.checkBuffer(param, 4);
/* 3613:3015 */     nglTexParameterfv(target, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3614:     */   }
/* 3615:     */   
/* 3616:     */   static native void nglTexParameterfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3617:     */   
/* 3618:     */   public static void glTexParameter(int target, int pname, IntBuffer param)
/* 3619:     */   {
/* 3620:3020 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3621:3021 */     long function_pointer = caps.glTexParameteriv;
/* 3622:3022 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3623:3023 */     BufferChecks.checkBuffer(param, 4);
/* 3624:3024 */     nglTexParameteriv(target, pname, MemoryUtil.getAddress(param), function_pointer);
/* 3625:     */   }
/* 3626:     */   
/* 3627:     */   static native void nglTexParameteriv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3628:     */   
/* 3629:     */   public static void glTexGenf(int coord, int pname, float param)
/* 3630:     */   {
/* 3631:3029 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3632:3030 */     long function_pointer = caps.glTexGenf;
/* 3633:3031 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3634:3032 */     nglTexGenf(coord, pname, param, function_pointer);
/* 3635:     */   }
/* 3636:     */   
/* 3637:     */   static native void nglTexGenf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 3638:     */   
/* 3639:     */   public static void glTexGend(int coord, int pname, double param)
/* 3640:     */   {
/* 3641:3037 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3642:3038 */     long function_pointer = caps.glTexGend;
/* 3643:3039 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3644:3040 */     nglTexGend(coord, pname, param, function_pointer);
/* 3645:     */   }
/* 3646:     */   
/* 3647:     */   static native void nglTexGend(int paramInt1, int paramInt2, double paramDouble, long paramLong);
/* 3648:     */   
/* 3649:     */   public static void glTexGen(int coord, int pname, FloatBuffer params)
/* 3650:     */   {
/* 3651:3045 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3652:3046 */     long function_pointer = caps.glTexGenfv;
/* 3653:3047 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3654:3048 */     BufferChecks.checkBuffer(params, 4);
/* 3655:3049 */     nglTexGenfv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3656:     */   }
/* 3657:     */   
/* 3658:     */   static native void nglTexGenfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3659:     */   
/* 3660:     */   public static void glTexGen(int coord, int pname, DoubleBuffer params)
/* 3661:     */   {
/* 3662:3054 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3663:3055 */     long function_pointer = caps.glTexGendv;
/* 3664:3056 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3665:3057 */     BufferChecks.checkBuffer(params, 4);
/* 3666:3058 */     nglTexGendv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3667:     */   }
/* 3668:     */   
/* 3669:     */   static native void nglTexGendv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3670:     */   
/* 3671:     */   public static void glTexGeni(int coord, int pname, int param)
/* 3672:     */   {
/* 3673:3063 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3674:3064 */     long function_pointer = caps.glTexGeni;
/* 3675:3065 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3676:3066 */     nglTexGeni(coord, pname, param, function_pointer);
/* 3677:     */   }
/* 3678:     */   
/* 3679:     */   static native void nglTexGeni(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3680:     */   
/* 3681:     */   public static void glTexGen(int coord, int pname, IntBuffer params)
/* 3682:     */   {
/* 3683:3071 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3684:3072 */     long function_pointer = caps.glTexGeniv;
/* 3685:3073 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3686:3074 */     BufferChecks.checkBuffer(params, 4);
/* 3687:3075 */     nglTexGeniv(coord, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3688:     */   }
/* 3689:     */   
/* 3690:     */   static native void nglTexGeniv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3691:     */   
/* 3692:     */   public static void glTexEnvf(int target, int pname, float param)
/* 3693:     */   {
/* 3694:3080 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3695:3081 */     long function_pointer = caps.glTexEnvf;
/* 3696:3082 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3697:3083 */     nglTexEnvf(target, pname, param, function_pointer);
/* 3698:     */   }
/* 3699:     */   
/* 3700:     */   static native void nglTexEnvf(int paramInt1, int paramInt2, float paramFloat, long paramLong);
/* 3701:     */   
/* 3702:     */   public static void glTexEnvi(int target, int pname, int param)
/* 3703:     */   {
/* 3704:3088 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3705:3089 */     long function_pointer = caps.glTexEnvi;
/* 3706:3090 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3707:3091 */     nglTexEnvi(target, pname, param, function_pointer);
/* 3708:     */   }
/* 3709:     */   
/* 3710:     */   static native void nglTexEnvi(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3711:     */   
/* 3712:     */   public static void glTexEnv(int target, int pname, FloatBuffer params)
/* 3713:     */   {
/* 3714:3096 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3715:3097 */     long function_pointer = caps.glTexEnvfv;
/* 3716:3098 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3717:3099 */     BufferChecks.checkBuffer(params, 4);
/* 3718:3100 */     nglTexEnvfv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3719:     */   }
/* 3720:     */   
/* 3721:     */   static native void nglTexEnvfv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3722:     */   
/* 3723:     */   public static void glTexEnv(int target, int pname, IntBuffer params)
/* 3724:     */   {
/* 3725:3105 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3726:3106 */     long function_pointer = caps.glTexEnviv;
/* 3727:3107 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3728:3108 */     BufferChecks.checkBuffer(params, 4);
/* 3729:3109 */     nglTexEnviv(target, pname, MemoryUtil.getAddress(params), function_pointer);
/* 3730:     */   }
/* 3731:     */   
/* 3732:     */   static native void nglTexEnviv(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 3733:     */   
/* 3734:     */   public static void glTexCoordPointer(int size, int stride, DoubleBuffer pointer)
/* 3735:     */   {
/* 3736:3114 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3737:3115 */     long function_pointer = caps.glTexCoordPointer;
/* 3738:3116 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3739:3117 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3740:3118 */     BufferChecks.checkDirect(pointer);
/* 3741:3119 */     if (LWJGLUtil.CHECKS) {
/* 3742:3119 */       StateTracker.getReferences(caps).glTexCoordPointer_buffer[StateTracker.getReferences(caps).glClientActiveTexture] = pointer;
/* 3743:     */     }
/* 3744:3120 */     nglTexCoordPointer(size, 5130, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3745:     */   }
/* 3746:     */   
/* 3747:     */   public static void glTexCoordPointer(int size, int stride, FloatBuffer pointer)
/* 3748:     */   {
/* 3749:3123 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3750:3124 */     long function_pointer = caps.glTexCoordPointer;
/* 3751:3125 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3752:3126 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3753:3127 */     BufferChecks.checkDirect(pointer);
/* 3754:3128 */     if (LWJGLUtil.CHECKS) {
/* 3755:3128 */       StateTracker.getReferences(caps).glTexCoordPointer_buffer[StateTracker.getReferences(caps).glClientActiveTexture] = pointer;
/* 3756:     */     }
/* 3757:3129 */     nglTexCoordPointer(size, 5126, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3758:     */   }
/* 3759:     */   
/* 3760:     */   public static void glTexCoordPointer(int size, int stride, IntBuffer pointer)
/* 3761:     */   {
/* 3762:3132 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3763:3133 */     long function_pointer = caps.glTexCoordPointer;
/* 3764:3134 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3765:3135 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3766:3136 */     BufferChecks.checkDirect(pointer);
/* 3767:3137 */     if (LWJGLUtil.CHECKS) {
/* 3768:3137 */       StateTracker.getReferences(caps).glTexCoordPointer_buffer[StateTracker.getReferences(caps).glClientActiveTexture] = pointer;
/* 3769:     */     }
/* 3770:3138 */     nglTexCoordPointer(size, 5124, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3771:     */   }
/* 3772:     */   
/* 3773:     */   public static void glTexCoordPointer(int size, int stride, ShortBuffer pointer)
/* 3774:     */   {
/* 3775:3141 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3776:3142 */     long function_pointer = caps.glTexCoordPointer;
/* 3777:3143 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3778:3144 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3779:3145 */     BufferChecks.checkDirect(pointer);
/* 3780:3146 */     if (LWJGLUtil.CHECKS) {
/* 3781:3146 */       StateTracker.getReferences(caps).glTexCoordPointer_buffer[StateTracker.getReferences(caps).glClientActiveTexture] = pointer;
/* 3782:     */     }
/* 3783:3147 */     nglTexCoordPointer(size, 5122, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3784:     */   }
/* 3785:     */   
/* 3786:     */   static native void nglTexCoordPointer(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3787:     */   
/* 3788:     */   public static void glTexCoordPointer(int size, int type, int stride, long pointer_buffer_offset)
/* 3789:     */   {
/* 3790:3151 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3791:3152 */     long function_pointer = caps.glTexCoordPointer;
/* 3792:3153 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3793:3154 */     GLChecks.ensureArrayVBOenabled(caps);
/* 3794:3155 */     nglTexCoordPointerBO(size, type, stride, pointer_buffer_offset, function_pointer);
/* 3795:     */   }
/* 3796:     */   
/* 3797:     */   static native void nglTexCoordPointerBO(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/* 3798:     */   
/* 3799:     */   public static void glTexCoordPointer(int size, int type, int stride, ByteBuffer pointer)
/* 3800:     */   {
/* 3801:3161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3802:3162 */     long function_pointer = caps.glTexCoordPointer;
/* 3803:3163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3804:3164 */     GLChecks.ensureArrayVBOdisabled(caps);
/* 3805:3165 */     BufferChecks.checkDirect(pointer);
/* 3806:3166 */     if (LWJGLUtil.CHECKS) {
/* 3807:3166 */       StateTracker.getReferences(caps).glTexCoordPointer_buffer[StateTracker.getReferences(caps).glClientActiveTexture] = pointer;
/* 3808:     */     }
/* 3809:3167 */     nglTexCoordPointer(size, type, stride, MemoryUtil.getAddress(pointer), function_pointer);
/* 3810:     */   }
/* 3811:     */   
/* 3812:     */   public static void glTexCoord1f(float s)
/* 3813:     */   {
/* 3814:3171 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3815:3172 */     long function_pointer = caps.glTexCoord1f;
/* 3816:3173 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3817:3174 */     nglTexCoord1f(s, function_pointer);
/* 3818:     */   }
/* 3819:     */   
/* 3820:     */   static native void nglTexCoord1f(float paramFloat, long paramLong);
/* 3821:     */   
/* 3822:     */   public static void glTexCoord1d(double s)
/* 3823:     */   {
/* 3824:3179 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3825:3180 */     long function_pointer = caps.glTexCoord1d;
/* 3826:3181 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3827:3182 */     nglTexCoord1d(s, function_pointer);
/* 3828:     */   }
/* 3829:     */   
/* 3830:     */   static native void nglTexCoord1d(double paramDouble, long paramLong);
/* 3831:     */   
/* 3832:     */   public static void glTexCoord2f(float s, float t)
/* 3833:     */   {
/* 3834:3187 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3835:3188 */     long function_pointer = caps.glTexCoord2f;
/* 3836:3189 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3837:3190 */     nglTexCoord2f(s, t, function_pointer);
/* 3838:     */   }
/* 3839:     */   
/* 3840:     */   static native void nglTexCoord2f(float paramFloat1, float paramFloat2, long paramLong);
/* 3841:     */   
/* 3842:     */   public static void glTexCoord2d(double s, double t)
/* 3843:     */   {
/* 3844:3195 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3845:3196 */     long function_pointer = caps.glTexCoord2d;
/* 3846:3197 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3847:3198 */     nglTexCoord2d(s, t, function_pointer);
/* 3848:     */   }
/* 3849:     */   
/* 3850:     */   static native void nglTexCoord2d(double paramDouble1, double paramDouble2, long paramLong);
/* 3851:     */   
/* 3852:     */   public static void glTexCoord3f(float s, float t, float r)
/* 3853:     */   {
/* 3854:3203 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3855:3204 */     long function_pointer = caps.glTexCoord3f;
/* 3856:3205 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3857:3206 */     nglTexCoord3f(s, t, r, function_pointer);
/* 3858:     */   }
/* 3859:     */   
/* 3860:     */   static native void nglTexCoord3f(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong);
/* 3861:     */   
/* 3862:     */   public static void glTexCoord3d(double s, double t, double r)
/* 3863:     */   {
/* 3864:3211 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3865:3212 */     long function_pointer = caps.glTexCoord3d;
/* 3866:3213 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3867:3214 */     nglTexCoord3d(s, t, r, function_pointer);
/* 3868:     */   }
/* 3869:     */   
/* 3870:     */   static native void nglTexCoord3d(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
/* 3871:     */   
/* 3872:     */   public static void glTexCoord4f(float s, float t, float r, float q)
/* 3873:     */   {
/* 3874:3219 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3875:3220 */     long function_pointer = caps.glTexCoord4f;
/* 3876:3221 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3877:3222 */     nglTexCoord4f(s, t, r, q, function_pointer);
/* 3878:     */   }
/* 3879:     */   
/* 3880:     */   static native void nglTexCoord4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 3881:     */   
/* 3882:     */   public static void glTexCoord4d(double s, double t, double r, double q)
/* 3883:     */   {
/* 3884:3227 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3885:3228 */     long function_pointer = caps.glTexCoord4d;
/* 3886:3229 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3887:3230 */     nglTexCoord4d(s, t, r, q, function_pointer);
/* 3888:     */   }
/* 3889:     */   
/* 3890:     */   static native void nglTexCoord4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 3891:     */   
/* 3892:     */   public static void glStencilOp(int fail, int zfail, int zpass)
/* 3893:     */   {
/* 3894:3235 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3895:3236 */     long function_pointer = caps.glStencilOp;
/* 3896:3237 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3897:3238 */     nglStencilOp(fail, zfail, zpass, function_pointer);
/* 3898:     */   }
/* 3899:     */   
/* 3900:     */   static native void nglStencilOp(int paramInt1, int paramInt2, int paramInt3, long paramLong);
/* 3901:     */   
/* 3902:     */   public static void glStencilMask(int mask)
/* 3903:     */   {
/* 3904:3243 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3905:3244 */     long function_pointer = caps.glStencilMask;
/* 3906:3245 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3907:3246 */     nglStencilMask(mask, function_pointer);
/* 3908:     */   }
/* 3909:     */   
/* 3910:     */   static native void nglStencilMask(int paramInt, long paramLong);
/* 3911:     */   
/* 3912:     */   public static void glViewport(int x, int y, int width, int height)
/* 3913:     */   {
/* 3914:3251 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 3915:3252 */     long function_pointer = caps.glViewport;
/* 3916:3253 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 3917:3254 */     nglViewport(x, y, width, height, function_pointer);
/* 3918:     */   }
/* 3919:     */   
/* 3920:     */   static native void nglViewport(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
/* 3921:     */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.GL11
 * JD-Core Version:    0.7.0.1
 */