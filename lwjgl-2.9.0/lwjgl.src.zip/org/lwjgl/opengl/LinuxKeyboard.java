/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.CharBuffer;
/*   5:    */ import java.nio.charset.Charset;
/*   6:    */ import java.nio.charset.CharsetDecoder;
/*   7:    */ import org.lwjgl.BufferUtils;
/*   8:    */ import org.lwjgl.LWJGLUtil;
/*   9:    */ 
/*  10:    */ final class LinuxKeyboard
/*  11:    */ {
/*  12:    */   private static final int LockMapIndex = 1;
/*  13:    */   private static final long NoSymbol = 0L;
/*  14:    */   private static final long ShiftMask = 1L;
/*  15:    */   private static final long LockMask = 2L;
/*  16:    */   private static final int XLookupChars = 2;
/*  17:    */   private static final int XLookupBoth = 4;
/*  18:    */   private static final int KEYBOARD_BUFFER_SIZE = 50;
/*  19:    */   private final long xim;
/*  20:    */   private final long xic;
/*  21:    */   private final int numlock_mask;
/*  22:    */   private final int modeswitch_mask;
/*  23:    */   private final int caps_lock_mask;
/*  24:    */   private final int shift_lock_mask;
/*  25:    */   private final ByteBuffer compose_status;
/*  26: 67 */   private final byte[] key_down_buffer = new byte[256];
/*  27: 68 */   private final EventQueue event_queue = new EventQueue(18);
/*  28: 70 */   private final ByteBuffer tmp_event = ByteBuffer.allocate(18);
/*  29: 71 */   private final int[] temp_translation_buffer = new int[50];
/*  30: 72 */   private final ByteBuffer native_translation_buffer = BufferUtils.createByteBuffer(50);
/*  31: 73 */   private final CharsetDecoder utf8_decoder = Charset.forName("UTF-8").newDecoder();
/*  32: 74 */   private final CharBuffer char_buffer = CharBuffer.allocate(50);
/*  33:    */   private boolean has_deferred_event;
/*  34:    */   private int deferred_keycode;
/*  35:    */   private int deferred_event_keycode;
/*  36:    */   private long deferred_nanos;
/*  37:    */   private byte deferred_key_state;
/*  38:    */   
/*  39:    */   LinuxKeyboard(long display, long window)
/*  40:    */   {
/*  41: 84 */     long modifier_map = getModifierMapping(display);
/*  42: 85 */     int tmp_numlock_mask = 0;
/*  43: 86 */     int tmp_modeswitch_mask = 0;
/*  44: 87 */     int tmp_caps_lock_mask = 0;
/*  45: 88 */     int tmp_shift_lock_mask = 0;
/*  46: 89 */     if (modifier_map != 0L)
/*  47:    */     {
/*  48: 90 */       int max_keypermod = getMaxKeyPerMod(modifier_map);
/*  49: 93 */       for (int i = 0; i < 8; i++) {
/*  50: 94 */         for (int j = 0; j < max_keypermod; j++)
/*  51:    */         {
/*  52: 95 */           int key_code = lookupModifierMap(modifier_map, i * max_keypermod + j);
/*  53: 96 */           int key_sym = (int)keycodeToKeySym(display, key_code);
/*  54: 97 */           int mask = 1 << i;
/*  55: 98 */           switch (key_sym)
/*  56:    */           {
/*  57:    */           case 65407: 
/*  58:100 */             tmp_numlock_mask |= mask;
/*  59:101 */             break;
/*  60:    */           case 65406: 
/*  61:103 */             tmp_modeswitch_mask |= mask;
/*  62:104 */             break;
/*  63:    */           case 65509: 
/*  64:106 */             if (i == 1)
/*  65:    */             {
/*  66:107 */               tmp_caps_lock_mask = mask;
/*  67:108 */               tmp_shift_lock_mask = 0;
/*  68:    */             }
/*  69:    */             break;
/*  70:    */           case 65510: 
/*  71:112 */             if ((i == 1) && (tmp_caps_lock_mask == 0)) {
/*  72:113 */               tmp_shift_lock_mask = mask;
/*  73:    */             }
/*  74:    */             break;
/*  75:    */           }
/*  76:    */         }
/*  77:    */       }
/*  78:120 */       freeModifierMapping(modifier_map);
/*  79:    */     }
/*  80:122 */     this.numlock_mask = tmp_numlock_mask;
/*  81:123 */     this.modeswitch_mask = tmp_modeswitch_mask;
/*  82:124 */     this.caps_lock_mask = tmp_caps_lock_mask;
/*  83:125 */     this.shift_lock_mask = tmp_shift_lock_mask;
/*  84:126 */     setDetectableKeyRepeat(display, true);
/*  85:127 */     this.xim = openIM(display);
/*  86:128 */     if (this.xim != 0L)
/*  87:    */     {
/*  88:129 */       this.xic = createIC(this.xim, window);
/*  89:130 */       if (this.xic != 0L) {
/*  90:131 */         setupIMEventMask(display, window, this.xic);
/*  91:    */       } else {
/*  92:133 */         destroy(display);
/*  93:    */       }
/*  94:    */     }
/*  95:    */     else
/*  96:    */     {
/*  97:136 */       this.xic = 0L;
/*  98:    */     }
/*  99:138 */     this.compose_status = allocateComposeStatus();
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static native long getModifierMapping(long paramLong);
/* 103:    */   
/* 104:    */   private static native void freeModifierMapping(long paramLong);
/* 105:    */   
/* 106:    */   private static native int getMaxKeyPerMod(long paramLong);
/* 107:    */   
/* 108:    */   private static native int lookupModifierMap(long paramLong, int paramInt);
/* 109:    */   
/* 110:    */   private static native long keycodeToKeySym(long paramLong, int paramInt);
/* 111:    */   
/* 112:    */   private static native long openIM(long paramLong);
/* 113:    */   
/* 114:    */   private static native long createIC(long paramLong1, long paramLong2);
/* 115:    */   
/* 116:    */   private static native void setupIMEventMask(long paramLong1, long paramLong2, long paramLong3);
/* 117:    */   
/* 118:    */   private static native ByteBuffer allocateComposeStatus();
/* 119:    */   
/* 120:    */   private static void setDetectableKeyRepeat(long display, boolean enabled)
/* 121:    */   {
/* 122:152 */     boolean success = nSetDetectableKeyRepeat(display, enabled);
/* 123:153 */     if (!success) {
/* 124:154 */       LWJGLUtil.log("Failed to set detectable key repeat to " + enabled);
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   private static native boolean nSetDetectableKeyRepeat(long paramLong, boolean paramBoolean);
/* 129:    */   
/* 130:    */   public void destroy(long display)
/* 131:    */   {
/* 132:159 */     if (this.xic != 0L) {
/* 133:160 */       destroyIC(this.xic);
/* 134:    */     }
/* 135:161 */     if (this.xim != 0L) {
/* 136:162 */       closeIM(this.xim);
/* 137:    */     }
/* 138:163 */     setDetectableKeyRepeat(display, false);
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static native void destroyIC(long paramLong);
/* 142:    */   
/* 143:    */   private static native void closeIM(long paramLong);
/* 144:    */   
/* 145:    */   public void read(ByteBuffer buffer)
/* 146:    */   {
/* 147:169 */     flushDeferredEvent();
/* 148:170 */     this.event_queue.copyEvents(buffer);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public void poll(ByteBuffer keyDownBuffer)
/* 152:    */   {
/* 153:174 */     flushDeferredEvent();
/* 154:175 */     int old_position = keyDownBuffer.position();
/* 155:176 */     keyDownBuffer.put(this.key_down_buffer);
/* 156:177 */     keyDownBuffer.position(old_position);
/* 157:    */   }
/* 158:    */   
/* 159:    */   private void putKeyboardEvent(int keycode, byte state, int ch, long nanos, boolean repeat)
/* 160:    */   {
/* 161:181 */     this.tmp_event.clear();
/* 162:182 */     this.tmp_event.putInt(keycode).put(state).putInt(ch).putLong(nanos).put((byte)(repeat ? 1 : 0));
/* 163:183 */     this.tmp_event.flip();
/* 164:184 */     this.event_queue.putEvent(this.tmp_event);
/* 165:    */   }
/* 166:    */   
/* 167:    */   private int lookupStringISO88591(long event_ptr, int[] translation_buffer)
/* 168:    */   {
/* 169:190 */     int num_chars = lookupString(event_ptr, this.native_translation_buffer, this.compose_status);
/* 170:191 */     for (int i = 0; i < num_chars; i++) {
/* 171:192 */       translation_buffer[i] = (this.native_translation_buffer.get(i) & 0xFF);
/* 172:    */     }
/* 173:194 */     return num_chars;
/* 174:    */   }
/* 175:    */   
/* 176:    */   private static native int lookupString(long paramLong, ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2);
/* 177:    */   
/* 178:    */   private int lookupStringUnicode(long event_ptr, int[] translation_buffer)
/* 179:    */   {
/* 180:199 */     int status = utf8LookupString(this.xic, event_ptr, this.native_translation_buffer, this.native_translation_buffer.position(), this.native_translation_buffer.remaining());
/* 181:200 */     if ((status != 2) && (status != 4)) {
/* 182:201 */       return 0;
/* 183:    */     }
/* 184:202 */     this.native_translation_buffer.flip();
/* 185:203 */     this.utf8_decoder.decode(this.native_translation_buffer, this.char_buffer, true);
/* 186:204 */     this.native_translation_buffer.compact();
/* 187:205 */     this.char_buffer.flip();
/* 188:206 */     int i = 0;
/* 189:207 */     while ((this.char_buffer.hasRemaining()) && (i < translation_buffer.length)) {
/* 190:208 */       translation_buffer[(i++)] = this.char_buffer.get();
/* 191:    */     }
/* 192:210 */     this.char_buffer.compact();
/* 193:211 */     return i;
/* 194:    */   }
/* 195:    */   
/* 196:    */   private static native int utf8LookupString(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
/* 197:    */   
/* 198:    */   private int lookupString(long event_ptr, int[] translation_buffer)
/* 199:    */   {
/* 200:216 */     if (this.xic != 0L) {
/* 201:217 */       return lookupStringUnicode(event_ptr, translation_buffer);
/* 202:    */     }
/* 203:219 */     return lookupStringISO88591(event_ptr, translation_buffer);
/* 204:    */   }
/* 205:    */   
/* 206:    */   private void translateEvent(long event_ptr, int keycode, byte key_state, long nanos, boolean repeat)
/* 207:    */   {
/* 208:226 */     int num_chars = lookupString(event_ptr, this.temp_translation_buffer);
/* 209:227 */     if (num_chars > 0)
/* 210:    */     {
/* 211:228 */       int ch = this.temp_translation_buffer[0];
/* 212:229 */       putKeyboardEvent(keycode, key_state, ch, nanos, repeat);
/* 213:230 */       for (int i = 1; i < num_chars; i++)
/* 214:    */       {
/* 215:231 */         ch = this.temp_translation_buffer[i];
/* 216:232 */         putKeyboardEvent(0, (byte)0, ch, nanos, repeat);
/* 217:    */       }
/* 218:    */     }
/* 219:235 */     putKeyboardEvent(keycode, key_state, 0, nanos, repeat);
/* 220:    */   }
/* 221:    */   
/* 222:    */   private static boolean isKeypadKeysym(long keysym)
/* 223:    */   {
/* 224:240 */     return ((65408L <= keysym) && (keysym <= 65469L)) || ((285212672L <= keysym) && (keysym <= 285278207L));
/* 225:    */   }
/* 226:    */   
/* 227:    */   private static boolean isNoSymbolOrVendorSpecific(long keysym)
/* 228:    */   {
/* 229:245 */     return (keysym == 0L) || ((keysym & 0x10000000) != 0L);
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static long getKeySym(long event_ptr, int group, int index)
/* 233:    */   {
/* 234:249 */     long keysym = lookupKeysym(event_ptr, group * 2 + index);
/* 235:250 */     if ((isNoSymbolOrVendorSpecific(keysym)) && (index == 1)) {
/* 236:251 */       keysym = lookupKeysym(event_ptr, group * 2 + 0);
/* 237:    */     }
/* 238:253 */     if ((isNoSymbolOrVendorSpecific(keysym)) && (group == 1)) {
/* 239:254 */       keysym = getKeySym(event_ptr, 0, index);
/* 240:    */     }
/* 241:255 */     return keysym;
/* 242:    */   }
/* 243:    */   
/* 244:    */   private static native long lookupKeysym(long paramLong, int paramInt);
/* 245:    */   
/* 246:    */   private static native long toUpper(long paramLong);
/* 247:    */   
/* 248:    */   private long mapEventToKeySym(long event_ptr, int event_state)
/* 249:    */   {
/* 250:    */     int group;
/* 251:    */     int group;
/* 252:263 */     if ((event_state & this.modeswitch_mask) != 0) {
/* 253:264 */       group = 1;
/* 254:    */     } else {
/* 255:266 */       group = 0;
/* 256:    */     }
/* 257:    */     long keysym;
/* 258:267 */     if (((event_state & this.numlock_mask) != 0) && (isKeypadKeysym(keysym = getKeySym(event_ptr, group, 1))))
/* 259:    */     {
/* 260:268 */       if ((event_state & (1L | this.shift_lock_mask)) != 0L) {
/* 261:269 */         return getKeySym(event_ptr, group, 0);
/* 262:    */       }
/* 263:271 */       return keysym;
/* 264:    */     }
/* 265:273 */     if ((event_state & 0x3) == 0L) {
/* 266:274 */       return getKeySym(event_ptr, group, 0);
/* 267:    */     }
/* 268:275 */     if ((event_state & 1L) == 0L)
/* 269:    */     {
/* 270:276 */       long keysym = getKeySym(event_ptr, group, 0);
/* 271:277 */       if ((event_state & this.caps_lock_mask) != 0) {
/* 272:278 */         keysym = toUpper(keysym);
/* 273:    */       }
/* 274:279 */       return keysym;
/* 275:    */     }
/* 276:281 */     long keysym = getKeySym(event_ptr, group, 1);
/* 277:282 */     if ((event_state & this.caps_lock_mask) != 0) {
/* 278:283 */       keysym = toUpper(keysym);
/* 279:    */     }
/* 280:284 */     return keysym;
/* 281:    */   }
/* 282:    */   
/* 283:    */   private int getKeycode(long event_ptr, int event_state)
/* 284:    */   {
/* 285:289 */     long keysym = mapEventToKeySym(event_ptr, event_state);
/* 286:290 */     int keycode = LinuxKeycodes.mapKeySymToLWJGLKeyCode(keysym);
/* 287:291 */     if (keycode == 0)
/* 288:    */     {
/* 289:293 */       keysym = lookupKeysym(event_ptr, 0);
/* 290:294 */       keycode = LinuxKeycodes.mapKeySymToLWJGLKeyCode(keysym);
/* 291:    */     }
/* 292:296 */     return keycode;
/* 293:    */   }
/* 294:    */   
/* 295:    */   private byte getKeyState(int event_type)
/* 296:    */   {
/* 297:300 */     switch (event_type)
/* 298:    */     {
/* 299:    */     case 2: 
/* 300:302 */       return 1;
/* 301:    */     case 3: 
/* 302:304 */       return 0;
/* 303:    */     }
/* 304:306 */     throw new IllegalArgumentException("Unknown event_type: " + event_type);
/* 305:    */   }
/* 306:    */   
/* 307:    */   private void handleKeyEvent(long event_ptr, long millis, int event_type, int event_keycode, int event_state)
/* 308:    */   {
/* 309:311 */     int keycode = getKeycode(event_ptr, event_state);
/* 310:312 */     byte key_state = getKeyState(event_type);
/* 311:313 */     boolean repeat = key_state == this.key_down_buffer[keycode];
/* 312:314 */     this.key_down_buffer[keycode] = key_state;
/* 313:315 */     long nanos = millis * 1000000L;
/* 314:316 */     if (event_type == 2)
/* 315:    */     {
/* 316:317 */       if (this.has_deferred_event) {
/* 317:318 */         if ((nanos == this.deferred_nanos) && (event_keycode == this.deferred_event_keycode))
/* 318:    */         {
/* 319:319 */           this.has_deferred_event = false;
/* 320:320 */           repeat = true;
/* 321:    */         }
/* 322:    */         else
/* 323:    */         {
/* 324:322 */           flushDeferredEvent();
/* 325:    */         }
/* 326:    */       }
/* 327:324 */       translateEvent(event_ptr, keycode, key_state, nanos, repeat);
/* 328:    */     }
/* 329:    */     else
/* 330:    */     {
/* 331:326 */       flushDeferredEvent();
/* 332:327 */       this.has_deferred_event = true;
/* 333:328 */       this.deferred_keycode = keycode;
/* 334:329 */       this.deferred_event_keycode = event_keycode;
/* 335:330 */       this.deferred_nanos = nanos;
/* 336:331 */       this.deferred_key_state = key_state;
/* 337:    */     }
/* 338:    */   }
/* 339:    */   
/* 340:    */   private void flushDeferredEvent()
/* 341:    */   {
/* 342:336 */     if (this.has_deferred_event)
/* 343:    */     {
/* 344:337 */       putKeyboardEvent(this.deferred_keycode, this.deferred_key_state, 0, this.deferred_nanos, false);
/* 345:338 */       this.has_deferred_event = false;
/* 346:    */     }
/* 347:    */   }
/* 348:    */   
/* 349:    */   public boolean filterEvent(LinuxEvent event)
/* 350:    */   {
/* 351:343 */     switch (event.getType())
/* 352:    */     {
/* 353:    */     case 2: 
/* 354:    */     case 3: 
/* 355:346 */       handleKeyEvent(event.getKeyAddress(), event.getKeyTime(), event.getKeyType(), event.getKeyKeyCode(), event.getKeyState());
/* 356:347 */       return true;
/* 357:    */     }
/* 358:351 */     return false;
/* 359:    */   }
/* 360:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.LinuxKeyboard
 * JD-Core Version:    0.7.0.1
 */