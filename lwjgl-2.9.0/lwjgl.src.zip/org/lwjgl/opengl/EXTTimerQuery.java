/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.LongBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class EXTTimerQuery
/*  8:   */ {
/*  9:   */   public static final int GL_TIME_ELAPSED_EXT = 35007;
/* 10:   */   
/* 11:   */   public static void glGetQueryObjectEXT(int id, int pname, LongBuffer params)
/* 12:   */   {
/* 13:19 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 14:20 */     long function_pointer = caps.glGetQueryObjecti64vEXT;
/* 15:21 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 16:22 */     BufferChecks.checkBuffer(params, 1);
/* 17:23 */     nglGetQueryObjecti64vEXT(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglGetQueryObjecti64vEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 21:   */   
/* 22:   */   public static long glGetQueryObjectEXT(int id, int pname)
/* 23:   */   {
/* 24:29 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:30 */     long function_pointer = caps.glGetQueryObjecti64vEXT;
/* 26:31 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:32 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 28:33 */     nglGetQueryObjecti64vEXT(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 29:34 */     return params.get(0);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static void glGetQueryObjectuEXT(int id, int pname, LongBuffer params)
/* 33:   */   {
/* 34:38 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 35:39 */     long function_pointer = caps.glGetQueryObjectui64vEXT;
/* 36:40 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 37:41 */     BufferChecks.checkBuffer(params, 1);
/* 38:42 */     nglGetQueryObjectui64vEXT(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 39:   */   }
/* 40:   */   
/* 41:   */   static native void nglGetQueryObjectui64vEXT(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 42:   */   
/* 43:   */   public static long glGetQueryObjectuEXT(int id, int pname)
/* 44:   */   {
/* 45:48 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 46:49 */     long function_pointer = caps.glGetQueryObjectui64vEXT;
/* 47:50 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 48:51 */     LongBuffer params = APIUtil.getBufferLong(caps);
/* 49:52 */     nglGetQueryObjectui64vEXT(id, pname, MemoryUtil.getAddress(params), function_pointer);
/* 50:53 */     return params.get(0);
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTTimerQuery
 * JD-Core Version:    0.7.0.1
 */