/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.awt.Canvas;
/*   4:    */ import java.awt.Component;
/*   5:    */ import java.awt.Container;
/*   6:    */ import java.awt.Insets;
/*   7:    */ import java.awt.event.ComponentEvent;
/*   8:    */ import java.awt.event.ComponentListener;
/*   9:    */ import java.nio.ByteBuffer;
/*  10:    */ import org.lwjgl.LWJGLException;
/*  11:    */ 
/*  12:    */ abstract class MacOSXCanvasPeerInfo
/*  13:    */   extends MacOSXPeerInfo
/*  14:    */ {
/*  15: 53 */   private final AWTSurfaceLock awt_surface = new AWTSurfaceLock();
/*  16:    */   public ByteBuffer window_handle;
/*  17:    */   
/*  18:    */   protected MacOSXCanvasPeerInfo(PixelFormat pixel_format, ContextAttribs attribs, boolean support_pbuffer)
/*  19:    */     throws LWJGLException
/*  20:    */   {
/*  21: 57 */     super(pixel_format, attribs, true, true, support_pbuffer, true);
/*  22:    */   }
/*  23:    */   
/*  24:    */   protected void initHandle(Canvas component)
/*  25:    */     throws LWJGLException
/*  26:    */   {
/*  27: 61 */     boolean forceCALayer = true;
/*  28: 62 */     String javaVersion = System.getProperty("java.version");
/*  29: 64 */     if ((javaVersion.startsWith("1.5")) || (javaVersion.startsWith("1.6"))) {
/*  30: 68 */       forceCALayer = false;
/*  31:    */     }
/*  32: 71 */     Insets insets = getInsets(component);
/*  33:    */     
/*  34: 73 */     int top = insets != null ? insets.top : 0;
/*  35: 74 */     int left = insets != null ? insets.left : 0;
/*  36:    */     
/*  37: 76 */     this.window_handle = nInitHandle(this.awt_surface.lockAndGetHandle(component), getHandle(), this.window_handle, forceCALayer, component.getX() - left, component.getY() - top);
/*  38: 78 */     if (javaVersion.startsWith("1.7")) {
/*  39: 81 */       addComponentListener(component);
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   private void addComponentListener(final Canvas component)
/*  44:    */   {
/*  45: 87 */     ComponentListener[] components = component.getComponentListeners();
/*  46: 90 */     for (int i = 0; i < components.length; i++)
/*  47:    */     {
/*  48: 91 */       ComponentListener c = components[i];
/*  49: 92 */       if (c.toString() == "CanvasPeerInfoListener") {
/*  50: 93 */         return;
/*  51:    */       }
/*  52:    */     }
/*  53: 97 */     ComponentListener comp = new ComponentListener()
/*  54:    */     {
/*  55:    */       public void componentHidden(ComponentEvent e) {}
/*  56:    */       
/*  57:    */       public void componentMoved(ComponentEvent e)
/*  58:    */       {
/*  59:103 */         Insets insets = MacOSXCanvasPeerInfo.this.getInsets(component);
/*  60:    */         
/*  61:105 */         int top = insets != null ? insets.top : 0;
/*  62:106 */         int left = insets != null ? insets.left : 0;
/*  63:    */         
/*  64:108 */         MacOSXCanvasPeerInfo.nSetLayerPosition(MacOSXCanvasPeerInfo.this.getHandle(), component.getX() - left, component.getY() - top);
/*  65:    */       }
/*  66:    */       
/*  67:    */       public void componentResized(ComponentEvent e)
/*  68:    */       {
/*  69:112 */         Insets insets = MacOSXCanvasPeerInfo.this.getInsets(component);
/*  70:    */         
/*  71:114 */         int top = insets != null ? insets.top : 0;
/*  72:115 */         int left = insets != null ? insets.left : 0;
/*  73:    */         
/*  74:117 */         MacOSXCanvasPeerInfo.nSetLayerPosition(MacOSXCanvasPeerInfo.this.getHandle(), component.getX() - left, component.getY() - top);
/*  75:    */       }
/*  76:    */       
/*  77:    */       public void componentShown(ComponentEvent e) {}
/*  78:    */       
/*  79:    */       public String toString()
/*  80:    */       {
/*  81:125 */         return "CanvasPeerInfoListener";
/*  82:    */       }
/*  83:128 */     };
/*  84:129 */     component.addComponentListener(comp);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static native ByteBuffer nInitHandle(ByteBuffer paramByteBuffer1, ByteBuffer paramByteBuffer2, ByteBuffer paramByteBuffer3, boolean paramBoolean, int paramInt1, int paramInt2)
/*  88:    */     throws LWJGLException;
/*  89:    */   
/*  90:    */   private static native void nSetLayerPosition(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2);
/*  91:    */   
/*  92:    */   protected void doUnlock()
/*  93:    */     throws LWJGLException
/*  94:    */   {
/*  95:137 */     this.awt_surface.unlock();
/*  96:    */   }
/*  97:    */   
/*  98:    */   private Insets getInsets(Canvas component)
/*  99:    */   {
/* 100:141 */     Component parent = component.getParent();
/* 101:143 */     while (parent != null)
/* 102:    */     {
/* 103:144 */       if ((parent instanceof Container)) {
/* 104:145 */         return ((Container)parent).getInsets();
/* 105:    */       }
/* 106:147 */       parent = parent.getParent();
/* 107:    */     }
/* 108:150 */     return null;
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.MacOSXCanvasPeerInfo
 * JD-Core Version:    0.7.0.1
 */