/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.FloatBuffer;
/*  5:   */ import java.nio.IntBuffer;
/*  6:   */ import org.lwjgl.BufferChecks;
/*  7:   */ import org.lwjgl.MemoryUtil;
/*  8:   */ 
/*  9:   */ public final class NVExplicitMultisample
/* 10:   */ {
/* 11:   */   public static final int GL_SAMPLE_POSITION_NV = 36432;
/* 12:   */   public static final int GL_SAMPLE_MASK_NV = 36433;
/* 13:   */   public static final int GL_SAMPLE_MASK_VALUE_NV = 36434;
/* 14:   */   public static final int GL_TEXTURE_BINDING_RENDERBUFFER_NV = 36435;
/* 15:   */   public static final int GL_TEXTURE_RENDERBUFFER_DATA_STORE_BINDING_NV = 36436;
/* 16:   */   public static final int GL_MAX_SAMPLE_MASK_WORDS_NV = 36441;
/* 17:   */   public static final int GL_TEXTURE_RENDERBUFFER_NV = 36437;
/* 18:   */   public static final int GL_SAMPLER_RENDERBUFFER_NV = 36438;
/* 19:   */   public static final int GL_INT_SAMPLER_RENDERBUFFER_NV = 36439;
/* 20:   */   public static final int GL_UNSIGNED_INT_SAMPLER_RENDERBUFFER_NV = 36440;
/* 21:   */   
/* 22:   */   public static void glGetBooleanIndexedEXT(int pname, int index, ByteBuffer data)
/* 23:   */   {
/* 24:51 */     EXTDrawBuffers2.glGetBooleanIndexedEXT(pname, index, data);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public static boolean glGetBooleanIndexedEXT(int pname, int index)
/* 28:   */   {
/* 29:56 */     return EXTDrawBuffers2.glGetBooleanIndexedEXT(pname, index);
/* 30:   */   }
/* 31:   */   
/* 32:   */   public static void glGetIntegerIndexedEXT(int pname, int index, IntBuffer data)
/* 33:   */   {
/* 34:60 */     EXTDrawBuffers2.glGetIntegerIndexedEXT(pname, index, data);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public static int glGetIntegerIndexedEXT(int pname, int index)
/* 38:   */   {
/* 39:65 */     return EXTDrawBuffers2.glGetIntegerIndexedEXT(pname, index);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static void glGetMultisampleNV(int pname, int index, FloatBuffer val)
/* 43:   */   {
/* 44:69 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 45:70 */     long function_pointer = caps.glGetMultisamplefvNV;
/* 46:71 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 47:72 */     BufferChecks.checkBuffer(val, 2);
/* 48:73 */     nglGetMultisamplefvNV(pname, index, MemoryUtil.getAddress(val), function_pointer);
/* 49:   */   }
/* 50:   */   
/* 51:   */   static native void nglGetMultisamplefvNV(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 52:   */   
/* 53:   */   public static void glSampleMaskIndexedNV(int index, int mask)
/* 54:   */   {
/* 55:78 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 56:79 */     long function_pointer = caps.glSampleMaskIndexedNV;
/* 57:80 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 58:81 */     nglSampleMaskIndexedNV(index, mask, function_pointer);
/* 59:   */   }
/* 60:   */   
/* 61:   */   static native void nglSampleMaskIndexedNV(int paramInt1, int paramInt2, long paramLong);
/* 62:   */   
/* 63:   */   public static void glTexRenderbufferNV(int target, int renderbuffer)
/* 64:   */   {
/* 65:86 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 66:87 */     long function_pointer = caps.glTexRenderbufferNV;
/* 67:88 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 68:89 */     nglTexRenderbufferNV(target, renderbuffer, function_pointer);
/* 69:   */   }
/* 70:   */   
/* 71:   */   static native void nglTexRenderbufferNV(int paramInt1, int paramInt2, long paramLong);
/* 72:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.NVExplicitMultisample
 * JD-Core Version:    0.7.0.1
 */