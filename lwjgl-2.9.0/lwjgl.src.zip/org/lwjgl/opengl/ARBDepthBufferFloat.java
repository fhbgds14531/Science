package org.lwjgl.opengl;

public final class ARBDepthBufferFloat
{
  public static final int GL_DEPTH_COMPONENT32F = 36012;
  public static final int GL_DEPTH32F_STENCIL8 = 36013;
  public static final int GL_FLOAT_32_UNSIGNED_INT_24_8_REV = 36269;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBDepthBufferFloat
 * JD-Core Version:    0.7.0.1
 */