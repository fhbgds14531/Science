package org.lwjgl.opengl;

public final class HPOcclusionTest
{
  public static final int GL_OCCLUSION_TEST_HP = 33125;
  public static final int GL_OCCLUSION_TEST_RESULT_HP = 33126;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.HPOcclusionTest
 * JD-Core Version:    0.7.0.1
 */