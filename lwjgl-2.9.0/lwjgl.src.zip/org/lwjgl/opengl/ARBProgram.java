/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.ByteBuffer;
/*   4:    */ import java.nio.DoubleBuffer;
/*   5:    */ import java.nio.FloatBuffer;
/*   6:    */ import java.nio.IntBuffer;
/*   7:    */ import org.lwjgl.BufferChecks;
/*   8:    */ import org.lwjgl.MemoryUtil;
/*   9:    */ 
/*  10:    */ public class ARBProgram
/*  11:    */ {
/*  12:    */   public static final int GL_PROGRAM_FORMAT_ASCII_ARB = 34933;
/*  13:    */   public static final int GL_PROGRAM_LENGTH_ARB = 34343;
/*  14:    */   public static final int GL_PROGRAM_FORMAT_ARB = 34934;
/*  15:    */   public static final int GL_PROGRAM_BINDING_ARB = 34423;
/*  16:    */   public static final int GL_PROGRAM_INSTRUCTIONS_ARB = 34976;
/*  17:    */   public static final int GL_MAX_PROGRAM_INSTRUCTIONS_ARB = 34977;
/*  18:    */   public static final int GL_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34978;
/*  19:    */   public static final int GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB = 34979;
/*  20:    */   public static final int GL_PROGRAM_TEMPORARIES_ARB = 34980;
/*  21:    */   public static final int GL_MAX_PROGRAM_TEMPORARIES_ARB = 34981;
/*  22:    */   public static final int GL_PROGRAM_NATIVE_TEMPORARIES_ARB = 34982;
/*  23:    */   public static final int GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB = 34983;
/*  24:    */   public static final int GL_PROGRAM_PARAMETERS_ARB = 34984;
/*  25:    */   public static final int GL_MAX_PROGRAM_PARAMETERS_ARB = 34985;
/*  26:    */   public static final int GL_PROGRAM_NATIVE_PARAMETERS_ARB = 34986;
/*  27:    */   public static final int GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB = 34987;
/*  28:    */   public static final int GL_PROGRAM_ATTRIBS_ARB = 34988;
/*  29:    */   public static final int GL_MAX_PROGRAM_ATTRIBS_ARB = 34989;
/*  30:    */   public static final int GL_PROGRAM_NATIVE_ATTRIBS_ARB = 34990;
/*  31:    */   public static final int GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB = 34991;
/*  32:    */   public static final int GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB = 34996;
/*  33:    */   public static final int GL_MAX_PROGRAM_ENV_PARAMETERS_ARB = 34997;
/*  34:    */   public static final int GL_PROGRAM_UNDER_NATIVE_LIMITS_ARB = 34998;
/*  35:    */   public static final int GL_PROGRAM_STRING_ARB = 34344;
/*  36:    */   public static final int GL_PROGRAM_ERROR_POSITION_ARB = 34379;
/*  37:    */   public static final int GL_CURRENT_MATRIX_ARB = 34369;
/*  38:    */   public static final int GL_TRANSPOSE_CURRENT_MATRIX_ARB = 34999;
/*  39:    */   public static final int GL_CURRENT_MATRIX_STACK_DEPTH_ARB = 34368;
/*  40:    */   public static final int GL_MAX_PROGRAM_MATRICES_ARB = 34351;
/*  41:    */   public static final int GL_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB = 34350;
/*  42:    */   public static final int GL_PROGRAM_ERROR_STRING_ARB = 34932;
/*  43:    */   public static final int GL_MATRIX0_ARB = 35008;
/*  44:    */   public static final int GL_MATRIX1_ARB = 35009;
/*  45:    */   public static final int GL_MATRIX2_ARB = 35010;
/*  46:    */   public static final int GL_MATRIX3_ARB = 35011;
/*  47:    */   public static final int GL_MATRIX4_ARB = 35012;
/*  48:    */   public static final int GL_MATRIX5_ARB = 35013;
/*  49:    */   public static final int GL_MATRIX6_ARB = 35014;
/*  50:    */   public static final int GL_MATRIX7_ARB = 35015;
/*  51:    */   public static final int GL_MATRIX8_ARB = 35016;
/*  52:    */   public static final int GL_MATRIX9_ARB = 35017;
/*  53:    */   public static final int GL_MATRIX10_ARB = 35018;
/*  54:    */   public static final int GL_MATRIX11_ARB = 35019;
/*  55:    */   public static final int GL_MATRIX12_ARB = 35020;
/*  56:    */   public static final int GL_MATRIX13_ARB = 35021;
/*  57:    */   public static final int GL_MATRIX14_ARB = 35022;
/*  58:    */   public static final int GL_MATRIX15_ARB = 35023;
/*  59:    */   public static final int GL_MATRIX16_ARB = 35024;
/*  60:    */   public static final int GL_MATRIX17_ARB = 35025;
/*  61:    */   public static final int GL_MATRIX18_ARB = 35026;
/*  62:    */   public static final int GL_MATRIX19_ARB = 35027;
/*  63:    */   public static final int GL_MATRIX20_ARB = 35028;
/*  64:    */   public static final int GL_MATRIX21_ARB = 35029;
/*  65:    */   public static final int GL_MATRIX22_ARB = 35030;
/*  66:    */   public static final int GL_MATRIX23_ARB = 35031;
/*  67:    */   public static final int GL_MATRIX24_ARB = 35032;
/*  68:    */   public static final int GL_MATRIX25_ARB = 35033;
/*  69:    */   public static final int GL_MATRIX26_ARB = 35034;
/*  70:    */   public static final int GL_MATRIX27_ARB = 35035;
/*  71:    */   public static final int GL_MATRIX28_ARB = 35036;
/*  72:    */   public static final int GL_MATRIX29_ARB = 35037;
/*  73:    */   public static final int GL_MATRIX30_ARB = 35038;
/*  74:    */   public static final int GL_MATRIX31_ARB = 35039;
/*  75:    */   
/*  76:    */   public static void glProgramStringARB(int target, int format, ByteBuffer string)
/*  77:    */   {
/*  78:100 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  79:101 */     long function_pointer = caps.glProgramStringARB;
/*  80:102 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  81:103 */     BufferChecks.checkDirect(string);
/*  82:104 */     nglProgramStringARB(target, format, string.remaining(), MemoryUtil.getAddress(string), function_pointer);
/*  83:    */   }
/*  84:    */   
/*  85:    */   static native void nglProgramStringARB(int paramInt1, int paramInt2, int paramInt3, long paramLong1, long paramLong2);
/*  86:    */   
/*  87:    */   public static void glProgramStringARB(int target, int format, CharSequence string)
/*  88:    */   {
/*  89:110 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  90:111 */     long function_pointer = caps.glProgramStringARB;
/*  91:112 */     BufferChecks.checkFunctionAddress(function_pointer);
/*  92:113 */     nglProgramStringARB(target, format, string.length(), APIUtil.getBuffer(caps, string), function_pointer);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static void glBindProgramARB(int target, int program)
/*  96:    */   {
/*  97:117 */     ContextCapabilities caps = GLContext.getCapabilities();
/*  98:118 */     long function_pointer = caps.glBindProgramARB;
/*  99:119 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 100:120 */     nglBindProgramARB(target, program, function_pointer);
/* 101:    */   }
/* 102:    */   
/* 103:    */   static native void nglBindProgramARB(int paramInt1, int paramInt2, long paramLong);
/* 104:    */   
/* 105:    */   public static void glDeleteProgramsARB(IntBuffer programs)
/* 106:    */   {
/* 107:125 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 108:126 */     long function_pointer = caps.glDeleteProgramsARB;
/* 109:127 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 110:128 */     BufferChecks.checkDirect(programs);
/* 111:129 */     nglDeleteProgramsARB(programs.remaining(), MemoryUtil.getAddress(programs), function_pointer);
/* 112:    */   }
/* 113:    */   
/* 114:    */   static native void nglDeleteProgramsARB(int paramInt, long paramLong1, long paramLong2);
/* 115:    */   
/* 116:    */   public static void glDeleteProgramsARB(int program)
/* 117:    */   {
/* 118:135 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 119:136 */     long function_pointer = caps.glDeleteProgramsARB;
/* 120:137 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 121:138 */     nglDeleteProgramsARB(1, APIUtil.getInt(caps, program), function_pointer);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static void glGenProgramsARB(IntBuffer programs)
/* 125:    */   {
/* 126:142 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 127:143 */     long function_pointer = caps.glGenProgramsARB;
/* 128:144 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 129:145 */     BufferChecks.checkDirect(programs);
/* 130:146 */     nglGenProgramsARB(programs.remaining(), MemoryUtil.getAddress(programs), function_pointer);
/* 131:    */   }
/* 132:    */   
/* 133:    */   static native void nglGenProgramsARB(int paramInt, long paramLong1, long paramLong2);
/* 134:    */   
/* 135:    */   public static int glGenProgramsARB()
/* 136:    */   {
/* 137:152 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 138:153 */     long function_pointer = caps.glGenProgramsARB;
/* 139:154 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 140:155 */     IntBuffer programs = APIUtil.getBufferInt(caps);
/* 141:156 */     nglGenProgramsARB(1, MemoryUtil.getAddress(programs), function_pointer);
/* 142:157 */     return programs.get(0);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public static void glProgramEnvParameter4fARB(int target, int index, float x, float y, float z, float w)
/* 146:    */   {
/* 147:161 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 148:162 */     long function_pointer = caps.glProgramEnvParameter4fARB;
/* 149:163 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 150:164 */     nglProgramEnvParameter4fARB(target, index, x, y, z, w, function_pointer);
/* 151:    */   }
/* 152:    */   
/* 153:    */   static native void nglProgramEnvParameter4fARB(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 154:    */   
/* 155:    */   public static void glProgramEnvParameter4dARB(int target, int index, double x, double y, double z, double w)
/* 156:    */   {
/* 157:169 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 158:170 */     long function_pointer = caps.glProgramEnvParameter4dARB;
/* 159:171 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 160:172 */     nglProgramEnvParameter4dARB(target, index, x, y, z, w, function_pointer);
/* 161:    */   }
/* 162:    */   
/* 163:    */   static native void nglProgramEnvParameter4dARB(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 164:    */   
/* 165:    */   public static void glProgramEnvParameter4ARB(int target, int index, FloatBuffer params)
/* 166:    */   {
/* 167:177 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 168:178 */     long function_pointer = caps.glProgramEnvParameter4fvARB;
/* 169:179 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 170:180 */     BufferChecks.checkBuffer(params, 4);
/* 171:181 */     nglProgramEnvParameter4fvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 172:    */   }
/* 173:    */   
/* 174:    */   static native void nglProgramEnvParameter4fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 175:    */   
/* 176:    */   public static void glProgramEnvParameter4ARB(int target, int index, DoubleBuffer params)
/* 177:    */   {
/* 178:186 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 179:187 */     long function_pointer = caps.glProgramEnvParameter4dvARB;
/* 180:188 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 181:189 */     BufferChecks.checkBuffer(params, 4);
/* 182:190 */     nglProgramEnvParameter4dvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 183:    */   }
/* 184:    */   
/* 185:    */   static native void nglProgramEnvParameter4dvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 186:    */   
/* 187:    */   public static void glProgramLocalParameter4fARB(int target, int index, float x, float y, float z, float w)
/* 188:    */   {
/* 189:195 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 190:196 */     long function_pointer = caps.glProgramLocalParameter4fARB;
/* 191:197 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 192:198 */     nglProgramLocalParameter4fARB(target, index, x, y, z, w, function_pointer);
/* 193:    */   }
/* 194:    */   
/* 195:    */   static native void nglProgramLocalParameter4fARB(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, long paramLong);
/* 196:    */   
/* 197:    */   public static void glProgramLocalParameter4dARB(int target, int index, double x, double y, double z, double w)
/* 198:    */   {
/* 199:203 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 200:204 */     long function_pointer = caps.glProgramLocalParameter4dARB;
/* 201:205 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 202:206 */     nglProgramLocalParameter4dARB(target, index, x, y, z, w, function_pointer);
/* 203:    */   }
/* 204:    */   
/* 205:    */   static native void nglProgramLocalParameter4dARB(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, long paramLong);
/* 206:    */   
/* 207:    */   public static void glProgramLocalParameter4ARB(int target, int index, FloatBuffer params)
/* 208:    */   {
/* 209:211 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 210:212 */     long function_pointer = caps.glProgramLocalParameter4fvARB;
/* 211:213 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 212:214 */     BufferChecks.checkBuffer(params, 4);
/* 213:215 */     nglProgramLocalParameter4fvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 214:    */   }
/* 215:    */   
/* 216:    */   static native void nglProgramLocalParameter4fvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 217:    */   
/* 218:    */   public static void glProgramLocalParameter4ARB(int target, int index, DoubleBuffer params)
/* 219:    */   {
/* 220:220 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 221:221 */     long function_pointer = caps.glProgramLocalParameter4dvARB;
/* 222:222 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 223:223 */     BufferChecks.checkBuffer(params, 4);
/* 224:224 */     nglProgramLocalParameter4dvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 225:    */   }
/* 226:    */   
/* 227:    */   static native void nglProgramLocalParameter4dvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 228:    */   
/* 229:    */   public static void glGetProgramEnvParameterARB(int target, int index, FloatBuffer params)
/* 230:    */   {
/* 231:229 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 232:230 */     long function_pointer = caps.glGetProgramEnvParameterfvARB;
/* 233:231 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 234:232 */     BufferChecks.checkBuffer(params, 4);
/* 235:233 */     nglGetProgramEnvParameterfvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 236:    */   }
/* 237:    */   
/* 238:    */   static native void nglGetProgramEnvParameterfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 239:    */   
/* 240:    */   public static void glGetProgramEnvParameterARB(int target, int index, DoubleBuffer params)
/* 241:    */   {
/* 242:238 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 243:239 */     long function_pointer = caps.glGetProgramEnvParameterdvARB;
/* 244:240 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 245:241 */     BufferChecks.checkBuffer(params, 4);
/* 246:242 */     nglGetProgramEnvParameterdvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 247:    */   }
/* 248:    */   
/* 249:    */   static native void nglGetProgramEnvParameterdvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 250:    */   
/* 251:    */   public static void glGetProgramLocalParameterARB(int target, int index, FloatBuffer params)
/* 252:    */   {
/* 253:247 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 254:248 */     long function_pointer = caps.glGetProgramLocalParameterfvARB;
/* 255:249 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 256:250 */     BufferChecks.checkBuffer(params, 4);
/* 257:251 */     nglGetProgramLocalParameterfvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 258:    */   }
/* 259:    */   
/* 260:    */   static native void nglGetProgramLocalParameterfvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 261:    */   
/* 262:    */   public static void glGetProgramLocalParameterARB(int target, int index, DoubleBuffer params)
/* 263:    */   {
/* 264:256 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 265:257 */     long function_pointer = caps.glGetProgramLocalParameterdvARB;
/* 266:258 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 267:259 */     BufferChecks.checkBuffer(params, 4);
/* 268:260 */     nglGetProgramLocalParameterdvARB(target, index, MemoryUtil.getAddress(params), function_pointer);
/* 269:    */   }
/* 270:    */   
/* 271:    */   static native void nglGetProgramLocalParameterdvARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 272:    */   
/* 273:    */   public static void glGetProgramARB(int target, int parameterName, IntBuffer params)
/* 274:    */   {
/* 275:265 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 276:266 */     long function_pointer = caps.glGetProgramivARB;
/* 277:267 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 278:268 */     BufferChecks.checkBuffer(params, 4);
/* 279:269 */     nglGetProgramivARB(target, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 280:    */   }
/* 281:    */   
/* 282:    */   static native void nglGetProgramivARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 283:    */   
/* 284:    */   @Deprecated
/* 285:    */   public static int glGetProgramARB(int target, int parameterName)
/* 286:    */   {
/* 287:280 */     return glGetProgramiARB(target, parameterName);
/* 288:    */   }
/* 289:    */   
/* 290:    */   public static int glGetProgramiARB(int target, int parameterName)
/* 291:    */   {
/* 292:285 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 293:286 */     long function_pointer = caps.glGetProgramivARB;
/* 294:287 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 295:288 */     IntBuffer params = APIUtil.getBufferInt(caps);
/* 296:289 */     nglGetProgramivARB(target, parameterName, MemoryUtil.getAddress(params), function_pointer);
/* 297:290 */     return params.get(0);
/* 298:    */   }
/* 299:    */   
/* 300:    */   public static void glGetProgramStringARB(int target, int parameterName, ByteBuffer paramString)
/* 301:    */   {
/* 302:294 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 303:295 */     long function_pointer = caps.glGetProgramStringARB;
/* 304:296 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 305:297 */     BufferChecks.checkDirect(paramString);
/* 306:298 */     nglGetProgramStringARB(target, parameterName, MemoryUtil.getAddress(paramString), function_pointer);
/* 307:    */   }
/* 308:    */   
/* 309:    */   static native void nglGetProgramStringARB(int paramInt1, int paramInt2, long paramLong1, long paramLong2);
/* 310:    */   
/* 311:    */   public static String glGetProgramStringARB(int target, int parameterName)
/* 312:    */   {
/* 313:304 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 314:305 */     long function_pointer = caps.glGetProgramStringARB;
/* 315:306 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 316:307 */     int programLength = glGetProgramiARB(target, 34343);
/* 317:308 */     ByteBuffer paramString = APIUtil.getBufferByte(caps, programLength);
/* 318:309 */     nglGetProgramStringARB(target, parameterName, MemoryUtil.getAddress(paramString), function_pointer);
/* 319:310 */     paramString.limit(programLength);
/* 320:311 */     return APIUtil.getString(caps, paramString);
/* 321:    */   }
/* 322:    */   
/* 323:    */   public static boolean glIsProgramARB(int program)
/* 324:    */   {
/* 325:315 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 326:316 */     long function_pointer = caps.glIsProgramARB;
/* 327:317 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 328:318 */     boolean __result = nglIsProgramARB(program, function_pointer);
/* 329:319 */     return __result;
/* 330:    */   }
/* 331:    */   
/* 332:    */   static native boolean nglIsProgramARB(int paramInt, long paramLong);
/* 333:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBProgram
 * JD-Core Version:    0.7.0.1
 */