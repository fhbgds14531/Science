/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.DoubleBuffer;
/*   4:    */ import java.nio.FloatBuffer;
/*   5:    */ import java.nio.IntBuffer;
/*   6:    */ 
/*   7:    */ public final class ARBViewportArray
/*   8:    */ {
/*   9:    */   public static final int GL_MAX_VIEWPORTS = 33371;
/*  10:    */   public static final int GL_VIEWPORT_SUBPIXEL_BITS = 33372;
/*  11:    */   public static final int GL_VIEWPORT_BOUNDS_RANGE = 33373;
/*  12:    */   public static final int GL_LAYER_PROVOKING_VERTEX = 33374;
/*  13:    */   public static final int GL_VIEWPORT_INDEX_PROVOKING_VERTEX = 33375;
/*  14:    */   public static final int GL_SCISSOR_BOX = 3088;
/*  15:    */   public static final int GL_VIEWPORT = 2978;
/*  16:    */   public static final int GL_DEPTH_RANGE = 2928;
/*  17:    */   public static final int GL_SCISSOR_TEST = 3089;
/*  18:    */   public static final int GL_FIRST_VERTEX_CONVENTION = 36429;
/*  19:    */   public static final int GL_LAST_VERTEX_CONVENTION = 36430;
/*  20:    */   public static final int GL_PROVOKING_VERTEX = 36431;
/*  21:    */   public static final int GL_UNDEFINED_VERTEX = 33376;
/*  22:    */   
/*  23:    */   public static void glViewportArray(int first, FloatBuffer v)
/*  24:    */   {
/*  25: 52 */     GL41.glViewportArray(first, v);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static void glViewportIndexedf(int index, float x, float y, float w, float h)
/*  29:    */   {
/*  30: 56 */     GL41.glViewportIndexedf(index, x, y, w, h);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static void glViewportIndexed(int index, FloatBuffer v)
/*  34:    */   {
/*  35: 60 */     GL41.glViewportIndexed(index, v);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static void glScissorArray(int first, IntBuffer v)
/*  39:    */   {
/*  40: 64 */     GL41.glScissorArray(first, v);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void glScissorIndexed(int index, int left, int bottom, int width, int height)
/*  44:    */   {
/*  45: 68 */     GL41.glScissorIndexed(index, left, bottom, width, height);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static void glScissorIndexed(int index, IntBuffer v)
/*  49:    */   {
/*  50: 72 */     GL41.glScissorIndexed(index, v);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static void glDepthRangeArray(int first, DoubleBuffer v)
/*  54:    */   {
/*  55: 76 */     GL41.glDepthRangeArray(first, v);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static void glDepthRangeIndexed(int index, double n, double f)
/*  59:    */   {
/*  60: 80 */     GL41.glDepthRangeIndexed(index, n, f);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void glGetFloat(int target, int index, FloatBuffer data)
/*  64:    */   {
/*  65: 84 */     GL41.glGetFloat(target, index, data);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static float glGetFloat(int target, int index)
/*  69:    */   {
/*  70: 89 */     return GL41.glGetFloat(target, index);
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static void glGetDouble(int target, int index, DoubleBuffer data)
/*  74:    */   {
/*  75: 93 */     GL41.glGetDouble(target, index, data);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static double glGetDouble(int target, int index)
/*  79:    */   {
/*  80: 98 */     return GL41.glGetDouble(target, index);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static void glGetIntegerIndexedEXT(int target, int index, IntBuffer v)
/*  84:    */   {
/*  85:102 */     EXTDrawBuffers2.glGetIntegerIndexedEXT(target, index, v);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static int glGetIntegerIndexedEXT(int target, int index)
/*  89:    */   {
/*  90:107 */     return EXTDrawBuffers2.glGetIntegerIndexedEXT(target, index);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static void glEnableIndexedEXT(int target, int index)
/*  94:    */   {
/*  95:111 */     EXTDrawBuffers2.glEnableIndexedEXT(target, index);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void glDisableIndexedEXT(int target, int index)
/*  99:    */   {
/* 100:115 */     EXTDrawBuffers2.glDisableIndexedEXT(target, index);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static boolean glIsEnabledIndexedEXT(int target, int index)
/* 104:    */   {
/* 105:119 */     return EXTDrawBuffers2.glIsEnabledIndexedEXT(target, index);
/* 106:    */   }
/* 107:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBViewportArray
 * JD-Core Version:    0.7.0.1
 */