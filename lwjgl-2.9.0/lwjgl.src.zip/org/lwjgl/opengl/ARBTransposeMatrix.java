/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.FloatBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ 
/*  7:   */ public final class ARBTransposeMatrix
/*  8:   */ {
/*  9:   */   public static final int GL_TRANSPOSE_MODELVIEW_MATRIX_ARB = 34019;
/* 10:   */   public static final int GL_TRANSPOSE_PROJECTION_MATRIX_ARB = 34020;
/* 11:   */   public static final int GL_TRANSPOSE_TEXTURE_MATRIX_ARB = 34021;
/* 12:   */   public static final int GL_TRANSPOSE_COLOR_MATRIX_ARB = 34022;
/* 13:   */   
/* 14:   */   public static void glLoadTransposeMatrixARB(FloatBuffer pfMtx)
/* 15:   */   {
/* 16:18 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 17:19 */     long function_pointer = caps.glLoadTransposeMatrixfARB;
/* 18:20 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 19:21 */     BufferChecks.checkBuffer(pfMtx, 16);
/* 20:22 */     nglLoadTransposeMatrixfARB(MemoryUtil.getAddress(pfMtx), function_pointer);
/* 21:   */   }
/* 22:   */   
/* 23:   */   static native void nglLoadTransposeMatrixfARB(long paramLong1, long paramLong2);
/* 24:   */   
/* 25:   */   public static void glMultTransposeMatrixARB(FloatBuffer pfMtx)
/* 26:   */   {
/* 27:27 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 28:28 */     long function_pointer = caps.glMultTransposeMatrixfARB;
/* 29:29 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 30:30 */     BufferChecks.checkBuffer(pfMtx, 16);
/* 31:31 */     nglMultTransposeMatrixfARB(MemoryUtil.getAddress(pfMtx), function_pointer);
/* 32:   */   }
/* 33:   */   
/* 34:   */   static native void nglMultTransposeMatrixfARB(long paramLong1, long paramLong2);
/* 35:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ARBTransposeMatrix
 * JD-Core Version:    0.7.0.1
 */