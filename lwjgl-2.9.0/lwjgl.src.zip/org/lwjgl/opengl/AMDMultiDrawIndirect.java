/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import java.nio.IntBuffer;
/*  5:   */ import org.lwjgl.BufferChecks;
/*  6:   */ import org.lwjgl.MemoryUtil;
/*  7:   */ 
/*  8:   */ public final class AMDMultiDrawIndirect
/*  9:   */ {
/* 10:   */   public static void glMultiDrawArraysIndirectAMD(int mode, ByteBuffer indirect, int primcount, int stride)
/* 11:   */   {
/* 12:13 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:14 */     long function_pointer = caps.glMultiDrawArraysIndirectAMD;
/* 14:15 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:16 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 16:17 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 16 : stride) * primcount);
/* 17:18 */     nglMultiDrawArraysIndirectAMD(mode, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/* 18:   */   }
/* 19:   */   
/* 20:   */   static native void nglMultiDrawArraysIndirectAMD(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2);
/* 21:   */   
/* 22:   */   public static void glMultiDrawArraysIndirectAMD(int mode, long indirect_buffer_offset, int primcount, int stride)
/* 23:   */   {
/* 24:22 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 25:23 */     long function_pointer = caps.glMultiDrawArraysIndirectAMD;
/* 26:24 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 27:25 */     GLChecks.ensureIndirectBOenabled(caps);
/* 28:26 */     nglMultiDrawArraysIndirectAMDBO(mode, indirect_buffer_offset, primcount, stride, function_pointer);
/* 29:   */   }
/* 30:   */   
/* 31:   */   static native void nglMultiDrawArraysIndirectAMDBO(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2);
/* 32:   */   
/* 33:   */   public static void glMultiDrawArraysIndirectAMD(int mode, IntBuffer indirect, int primcount, int stride)
/* 34:   */   {
/* 35:32 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 36:33 */     long function_pointer = caps.glMultiDrawArraysIndirectAMD;
/* 37:34 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 38:35 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 39:36 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 4 : stride >> 2) * primcount);
/* 40:37 */     nglMultiDrawArraysIndirectAMD(mode, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static void glMultiDrawElementsIndirectAMD(int mode, int type, ByteBuffer indirect, int primcount, int stride)
/* 44:   */   {
/* 45:41 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 46:42 */     long function_pointer = caps.glMultiDrawElementsIndirectAMD;
/* 47:43 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 48:44 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 49:45 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 20 : stride) * primcount);
/* 50:46 */     nglMultiDrawElementsIndirectAMD(mode, type, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/* 51:   */   }
/* 52:   */   
/* 53:   */   static native void nglMultiDrawElementsIndirectAMD(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2);
/* 54:   */   
/* 55:   */   public static void glMultiDrawElementsIndirectAMD(int mode, int type, long indirect_buffer_offset, int primcount, int stride)
/* 56:   */   {
/* 57:50 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 58:51 */     long function_pointer = caps.glMultiDrawElementsIndirectAMD;
/* 59:52 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 60:53 */     GLChecks.ensureIndirectBOenabled(caps);
/* 61:54 */     nglMultiDrawElementsIndirectAMDBO(mode, type, indirect_buffer_offset, primcount, stride, function_pointer);
/* 62:   */   }
/* 63:   */   
/* 64:   */   static native void nglMultiDrawElementsIndirectAMDBO(int paramInt1, int paramInt2, long paramLong1, int paramInt3, int paramInt4, long paramLong2);
/* 65:   */   
/* 66:   */   public static void glMultiDrawElementsIndirectAMD(int mode, int type, IntBuffer indirect, int primcount, int stride)
/* 67:   */   {
/* 68:60 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 69:61 */     long function_pointer = caps.glMultiDrawElementsIndirectAMD;
/* 70:62 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 71:63 */     GLChecks.ensureIndirectBOdisabled(caps);
/* 72:64 */     BufferChecks.checkBuffer(indirect, (stride == 0 ? 5 : stride >> 2) * primcount);
/* 73:65 */     nglMultiDrawElementsIndirectAMD(mode, type, MemoryUtil.getAddress(indirect), primcount, stride, function_pointer);
/* 74:   */   }
/* 75:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDMultiDrawIndirect
 * JD-Core Version:    0.7.0.1
 */