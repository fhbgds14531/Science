/*  1:   */ package org.lwjgl.opencl;
/*  2:   */ 
/*  3:   */ import java.nio.ByteBuffer;
/*  4:   */ import org.lwjgl.BufferChecks;
/*  5:   */ import org.lwjgl.MemoryUtil;
/*  6:   */ import org.lwjgl.PointerBuffer;
/*  7:   */ 
/*  8:   */ public final class KHRGLSharing
/*  9:   */ {
/* 10:   */   public static final int CL_INVALID_GL_SHAREGROUP_REFERENCE_KHR = -1000;
/* 11:   */   public static final int CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR = 8198;
/* 12:   */   public static final int CL_DEVICES_FOR_GL_CONTEXT_KHR = 8199;
/* 13:   */   public static final int CL_GL_CONTEXT_KHR = 8200;
/* 14:   */   public static final int CL_EGL_DISPLAY_KHR = 8201;
/* 15:   */   public static final int CL_GLX_DISPLAY_KHR = 8202;
/* 16:   */   public static final int CL_WGL_HDC_KHR = 8203;
/* 17:   */   public static final int CL_CGL_SHAREGROUP_KHR = 8204;
/* 18:   */   
/* 19:   */   public static int clGetGLContextInfoKHR(PointerBuffer properties, int param_name, ByteBuffer param_value, PointerBuffer param_value_size_ret)
/* 20:   */   {
/* 21:36 */     long function_pointer = CLCapabilities.clGetGLContextInfoKHR;
/* 22:37 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 23:38 */     BufferChecks.checkDirect(properties);
/* 24:39 */     BufferChecks.checkNullTerminated(properties);
/* 25:40 */     if (param_value != null) {
/* 26:41 */       BufferChecks.checkDirect(param_value);
/* 27:   */     }
/* 28:42 */     if (param_value_size_ret != null) {
/* 29:43 */       BufferChecks.checkBuffer(param_value_size_ret, 1);
/* 30:   */     }
/* 31:44 */     if ((param_value_size_ret == null) && (APIUtil.isDevicesParam(param_name))) {
/* 32:44 */       param_value_size_ret = APIUtil.getBufferPointer();
/* 33:   */     }
/* 34:45 */     int __result = nclGetGLContextInfoKHR(MemoryUtil.getAddress(properties), param_name, param_value == null ? 0 : param_value.remaining(), MemoryUtil.getAddressSafe(param_value), MemoryUtil.getAddressSafe(param_value_size_ret), function_pointer);
/* 35:46 */     if ((__result == 0) && (param_value != null) && (APIUtil.isDevicesParam(param_name))) {
/* 36:46 */       APIUtil.getCLPlatform(properties).registerCLDevices(param_value, param_value_size_ret);
/* 37:   */     }
/* 38:47 */     return __result;
/* 39:   */   }
/* 40:   */   
/* 41:   */   static native int nclGetGLContextInfoKHR(long paramLong1, int paramInt, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/* 42:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.KHRGLSharing
 * JD-Core Version:    0.7.0.1
 */