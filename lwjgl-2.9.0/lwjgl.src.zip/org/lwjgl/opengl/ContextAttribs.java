/*   1:    */ package org.lwjgl.opengl;
/*   2:    */ 
/*   3:    */ import java.nio.IntBuffer;
/*   4:    */ import org.lwjgl.BufferUtils;
/*   5:    */ import org.lwjgl.LWJGLUtil;
/*   6:    */ 
/*   7:    */ public final class ContextAttribs
/*   8:    */ {
/*   9:    */   private static final int CONTEXT_ES2_PROFILE_BIT_EXT = 4;
/*  10:    */   private static final int CONTEXT_ROBUST_ACCESS_BIT_ARB = 4;
/*  11:    */   private static final int CONTEXT_RESET_NOTIFICATION_STRATEGY_ARB = 33366;
/*  12:    */   private static final int NO_RESET_NOTIFICATION_ARB = 33377;
/*  13:    */   private static final int LOSE_CONTEXT_ON_RESET_ARB = 33362;
/*  14:    */   private static final int CONTEXT_RESET_ISOLATION_BIT_ARB = 8;
/*  15:    */   private int majorVersion;
/*  16:    */   private int minorVersion;
/*  17:    */   private int layerPlane;
/*  18:    */   private boolean debug;
/*  19:    */   private boolean forwardCompatible;
/*  20:    */   private boolean robustAccess;
/*  21:    */   private boolean profileCore;
/*  22:    */   private boolean profileCompatibility;
/*  23:    */   private boolean profileES;
/*  24:    */   private boolean loseContextOnReset;
/*  25:    */   private boolean contextResetIsolation;
/*  26:    */   
/*  27:    */   public ContextAttribs()
/*  28:    */   {
/*  29: 91 */     this(1, 0);
/*  30:    */   }
/*  31:    */   
/*  32:    */   public ContextAttribs(int majorVersion, int minorVersion)
/*  33:    */   {
/*  34: 95 */     if ((majorVersion < 0) || (4 < majorVersion) || (minorVersion < 0) || ((majorVersion == 4) && (3 < minorVersion)) || ((majorVersion == 3) && (3 < minorVersion)) || ((majorVersion == 2) && (1 < minorVersion)) || ((majorVersion == 1) && (5 < minorVersion))) {
/*  35:101 */       throw new IllegalArgumentException("Invalid OpenGL version specified: " + majorVersion + '.' + minorVersion);
/*  36:    */     }
/*  37:103 */     this.majorVersion = majorVersion;
/*  38:104 */     this.minorVersion = minorVersion;
/*  39:    */   }
/*  40:    */   
/*  41:    */   private ContextAttribs(ContextAttribs attribs)
/*  42:    */   {
/*  43:108 */     this.majorVersion = attribs.majorVersion;
/*  44:109 */     this.minorVersion = attribs.minorVersion;
/*  45:    */     
/*  46:111 */     this.layerPlane = attribs.layerPlane;
/*  47:    */     
/*  48:113 */     this.debug = attribs.debug;
/*  49:114 */     this.forwardCompatible = attribs.forwardCompatible;
/*  50:115 */     this.robustAccess = attribs.robustAccess;
/*  51:    */     
/*  52:117 */     this.profileCore = attribs.profileCore;
/*  53:118 */     this.profileCompatibility = attribs.profileCompatibility;
/*  54:119 */     this.profileES = attribs.profileES;
/*  55:    */     
/*  56:121 */     this.loseContextOnReset = attribs.loseContextOnReset;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public int getMajorVersion()
/*  60:    */   {
/*  61:125 */     return this.majorVersion;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public int getMinorVersion()
/*  65:    */   {
/*  66:129 */     return this.minorVersion;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public int getLayerPlane()
/*  70:    */   {
/*  71:133 */     return this.layerPlane;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean isDebug()
/*  75:    */   {
/*  76:137 */     return this.debug;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isForwardCompatible()
/*  80:    */   {
/*  81:141 */     return this.forwardCompatible;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isProfileCore()
/*  85:    */   {
/*  86:145 */     return this.profileCore;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean isProfileCompatibility()
/*  90:    */   {
/*  91:149 */     return this.profileCompatibility;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean isProfileES()
/*  95:    */   {
/*  96:153 */     return this.profileES;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public ContextAttribs withLayer(int layerPlane)
/* 100:    */   {
/* 101:157 */     if (layerPlane < 0) {
/* 102:158 */       throw new IllegalArgumentException("Invalid layer plane specified: " + layerPlane);
/* 103:    */     }
/* 104:160 */     if (layerPlane == this.layerPlane) {
/* 105:161 */       return this;
/* 106:    */     }
/* 107:163 */     ContextAttribs attribs = new ContextAttribs(this);
/* 108:164 */     attribs.layerPlane = layerPlane;
/* 109:165 */     return attribs;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public ContextAttribs withDebug(boolean debug)
/* 113:    */   {
/* 114:169 */     if (debug == this.debug) {
/* 115:170 */       return this;
/* 116:    */     }
/* 117:172 */     ContextAttribs attribs = new ContextAttribs(this);
/* 118:173 */     attribs.debug = debug;
/* 119:174 */     return attribs;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public ContextAttribs withForwardCompatible(boolean forwardCompatible)
/* 123:    */   {
/* 124:178 */     if (forwardCompatible == this.forwardCompatible) {
/* 125:179 */       return this;
/* 126:    */     }
/* 127:181 */     ContextAttribs attribs = new ContextAttribs(this);
/* 128:182 */     attribs.forwardCompatible = forwardCompatible;
/* 129:183 */     return attribs;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public ContextAttribs withProfileCore(boolean profileCore)
/* 133:    */   {
/* 134:187 */     if ((this.majorVersion < 3) || ((this.majorVersion == 3) && (this.minorVersion < 2))) {
/* 135:188 */       throw new IllegalArgumentException("Profiles are only supported on OpenGL version 3.2 or higher.");
/* 136:    */     }
/* 137:190 */     if (profileCore == this.profileCore) {
/* 138:191 */       return this;
/* 139:    */     }
/* 140:193 */     ContextAttribs attribs = new ContextAttribs(this);
/* 141:194 */     attribs.profileCore = profileCore;
/* 142:195 */     if (profileCore) {
/* 143:196 */       attribs.profileCompatibility = false;
/* 144:    */     }
/* 145:198 */     return attribs;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public ContextAttribs withProfileCompatibility(boolean profileCompatibility)
/* 149:    */   {
/* 150:202 */     if ((this.majorVersion < 3) || ((this.majorVersion == 3) && (this.minorVersion < 2))) {
/* 151:203 */       throw new IllegalArgumentException("Profiles are only supported on OpenGL version 3.2 or higher.");
/* 152:    */     }
/* 153:205 */     if (profileCompatibility == this.profileCompatibility) {
/* 154:206 */       return this;
/* 155:    */     }
/* 156:208 */     ContextAttribs attribs = new ContextAttribs(this);
/* 157:209 */     attribs.profileCompatibility = profileCompatibility;
/* 158:210 */     if (profileCompatibility) {
/* 159:211 */       attribs.profileCore = false;
/* 160:    */     }
/* 161:213 */     return attribs;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public ContextAttribs withProfileES(boolean profileES)
/* 165:    */   {
/* 166:217 */     if ((this.majorVersion != 2) || (this.minorVersion != 0)) {
/* 167:218 */       throw new IllegalArgumentException("The OpenGL ES profiles is only supported for OpenGL version 2.0.");
/* 168:    */     }
/* 169:220 */     if (profileES == this.profileES) {
/* 170:221 */       return this;
/* 171:    */     }
/* 172:223 */     ContextAttribs attribs = new ContextAttribs(this);
/* 173:224 */     attribs.profileES = profileES;
/* 174:    */     
/* 175:226 */     return attribs;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public ContextAttribs withLoseContextOnReset(boolean loseContextOnReset)
/* 179:    */   {
/* 180:239 */     if (loseContextOnReset == this.loseContextOnReset) {
/* 181:240 */       return this;
/* 182:    */     }
/* 183:242 */     ContextAttribs attribs = new ContextAttribs(this);
/* 184:243 */     attribs.loseContextOnReset = loseContextOnReset;
/* 185:244 */     return attribs;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public ContextAttribs withContextResetIsolation(boolean contextResetIsolation)
/* 189:    */   {
/* 190:248 */     if (contextResetIsolation == this.contextResetIsolation) {
/* 191:249 */       return this;
/* 192:    */     }
/* 193:251 */     ContextAttribs attribs = new ContextAttribs(this);
/* 194:252 */     attribs.contextResetIsolation = contextResetIsolation;
/* 195:253 */     return attribs;
/* 196:    */   }
/* 197:    */   
/* 198:    */   private static ContextAttribsImplementation getImplementation()
/* 199:    */   {
/* 200:257 */     switch ()
/* 201:    */     {
/* 202:    */     case 1: 
/* 203:259 */       return new LinuxContextAttribs();
/* 204:    */     case 3: 
/* 205:261 */       return new WindowsContextAttribs();
/* 206:    */     }
/* 207:263 */     throw new IllegalStateException("Unsupported platform");
/* 208:    */   }
/* 209:    */   
/* 210:    */   IntBuffer getAttribList()
/* 211:    */   {
/* 212:268 */     if (LWJGLUtil.getPlatform() == 2) {
/* 213:269 */       return null;
/* 214:    */     }
/* 215:271 */     ContextAttribsImplementation implementation = getImplementation();
/* 216:    */     
/* 217:273 */     int attribCount = 0;
/* 218:275 */     if ((this.majorVersion != 1) || (this.minorVersion != 0)) {
/* 219:276 */       attribCount += 2;
/* 220:    */     }
/* 221:277 */     if (0 < this.layerPlane) {
/* 222:278 */       attribCount++;
/* 223:    */     }
/* 224:280 */     int flags = 0;
/* 225:281 */     if (this.debug) {
/* 226:282 */       flags |= implementation.getDebugBit();
/* 227:    */     }
/* 228:283 */     if (this.forwardCompatible) {
/* 229:284 */       flags |= implementation.getForwardCompatibleBit();
/* 230:    */     }
/* 231:285 */     if (this.robustAccess) {
/* 232:286 */       flags |= 0x4;
/* 233:    */     }
/* 234:287 */     if (this.contextResetIsolation) {
/* 235:288 */       flags |= 0x8;
/* 236:    */     }
/* 237:289 */     if (0 < flags) {
/* 238:290 */       attribCount++;
/* 239:    */     }
/* 240:292 */     int profileMask = 0;
/* 241:293 */     if (this.profileCore) {
/* 242:294 */       profileMask |= implementation.getProfileCoreBit();
/* 243:295 */     } else if (this.profileCompatibility) {
/* 244:296 */       profileMask |= implementation.getProfileCompatibilityBit();
/* 245:297 */     } else if (this.profileES) {
/* 246:298 */       profileMask |= 0x4;
/* 247:    */     }
/* 248:299 */     if (0 < profileMask) {
/* 249:300 */       attribCount++;
/* 250:    */     }
/* 251:302 */     if (this.loseContextOnReset) {
/* 252:303 */       attribCount++;
/* 253:    */     }
/* 254:305 */     if (attribCount == 0) {
/* 255:306 */       return null;
/* 256:    */     }
/* 257:308 */     IntBuffer attribs = BufferUtils.createIntBuffer(attribCount * 2 + 1);
/* 258:310 */     if ((this.majorVersion != 1) || (this.minorVersion != 0))
/* 259:    */     {
/* 260:311 */       attribs.put(implementation.getMajorVersionAttrib()).put(this.majorVersion);
/* 261:312 */       attribs.put(implementation.getMinorVersionAttrib()).put(this.minorVersion);
/* 262:    */     }
/* 263:314 */     if (0 < this.layerPlane) {
/* 264:315 */       attribs.put(implementation.getLayerPlaneAttrib()).put(this.layerPlane);
/* 265:    */     }
/* 266:316 */     if (0 < flags) {
/* 267:317 */       attribs.put(implementation.getFlagsAttrib()).put(flags);
/* 268:    */     }
/* 269:318 */     if (0 < profileMask) {
/* 270:319 */       attribs.put(implementation.getProfileMaskAttrib()).put(profileMask);
/* 271:    */     }
/* 272:320 */     if (this.loseContextOnReset) {
/* 273:321 */       attribs.put(33366).put(33362);
/* 274:    */     }
/* 275:323 */     attribs.put(0);
/* 276:324 */     attribs.rewind();
/* 277:325 */     return attribs;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public String toString()
/* 281:    */   {
/* 282:329 */     StringBuilder sb = new StringBuilder(32);
/* 283:    */     
/* 284:331 */     sb.append("ContextAttribs:");
/* 285:332 */     sb.append(" Version=").append(this.majorVersion).append('.').append(this.minorVersion);
/* 286:333 */     sb.append(" - Layer=").append(this.layerPlane);
/* 287:334 */     sb.append(" - Debug=").append(this.debug);
/* 288:335 */     sb.append(" - ForwardCompatible=").append(this.forwardCompatible);
/* 289:336 */     sb.append(" - RobustAccess=").append(this.robustAccess);
/* 290:337 */     if (this.robustAccess) {
/* 291:338 */       sb.append(" (").append(this.loseContextOnReset ? "LOSE_CONTEXT_ON_RESET" : "NO_RESET_NOTIFICATION");
/* 292:    */     }
/* 293:339 */     sb.append(" - Profile=");
/* 294:340 */     if (this.profileCore) {
/* 295:341 */       sb.append("Core");
/* 296:342 */     } else if (this.profileCompatibility) {
/* 297:343 */       sb.append("Compatibility");
/* 298:    */     } else {
/* 299:345 */       sb.append("None");
/* 300:    */     }
/* 301:347 */     return sb.toString();
/* 302:    */   }
/* 303:    */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.ContextAttribs
 * JD-Core Version:    0.7.0.1
 */