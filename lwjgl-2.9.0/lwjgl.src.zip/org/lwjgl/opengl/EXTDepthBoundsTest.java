/*  1:   */ package org.lwjgl.opengl;
/*  2:   */ 
/*  3:   */ import org.lwjgl.BufferChecks;
/*  4:   */ 
/*  5:   */ public final class EXTDepthBoundsTest
/*  6:   */ {
/*  7:   */   public static final int GL_DEPTH_BOUNDS_TEST_EXT = 34960;
/*  8:   */   public static final int GL_DEPTH_BOUNDS_EXT = 34961;
/*  9:   */   
/* 10:   */   public static void glDepthBoundsEXT(double zmin, double zmax)
/* 11:   */   {
/* 12:26 */     ContextCapabilities caps = GLContext.getCapabilities();
/* 13:27 */     long function_pointer = caps.glDepthBoundsEXT;
/* 14:28 */     BufferChecks.checkFunctionAddress(function_pointer);
/* 15:29 */     nglDepthBoundsEXT(zmin, zmax, function_pointer);
/* 16:   */   }
/* 17:   */   
/* 18:   */   static native void nglDepthBoundsEXT(double paramDouble1, double paramDouble2, long paramLong);
/* 19:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.EXTDepthBoundsTest
 * JD-Core Version:    0.7.0.1
 */