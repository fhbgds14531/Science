/*  1:   */ package org.lwjgl.opencl.api;
/*  2:   */ 
/*  3:   */ import org.lwjgl.PointerBuffer;
/*  4:   */ 
/*  5:   */ public final class CLBufferRegion
/*  6:   */ {
/*  7:44 */   public static final int STRUCT_SIZE = 2 * PointerBuffer.getPointerSize();
/*  8:   */   private final int origin;
/*  9:   */   private final int size;
/* 10:   */   
/* 11:   */   public CLBufferRegion(int origin, int size)
/* 12:   */   {
/* 13:50 */     this.origin = origin;
/* 14:51 */     this.size = size;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public int getOrigin()
/* 18:   */   {
/* 19:55 */     return this.origin;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int getSize()
/* 23:   */   {
/* 24:59 */     return this.size;
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opencl.api.CLBufferRegion
 * JD-Core Version:    0.7.0.1
 */