package org.lwjgl.opengl;

public final class AMDDepthClampSeparate
{
  public static final int GL_DEPTH_CLAMP_NEAR_AMD = 36894;
  public static final int GL_DEPTH_CLAMP_FAR_AMD = 36895;
}


/* Location:           C:\Users\fhbgds\Science\lwjgl-2.9.0\jar\lwjgl.jar
 * Qualified Name:     org.lwjgl.opengl.AMDDepthClampSeparate
 * JD-Core Version:    0.7.0.1
 */